
cat TextEditorForJava.tar.gza* | tar -zxvpf - TextEditorForJava
   
if [ ! -e "./TextEditorForJava/TextEditorForJava" ]; then
   echo "./TextEditorForJava/TextEditorForJava not exist."
   exit
fi
cd ./TextEditorForJava/TextEditorForJava

if [ ! -e "./janeSoft" ]; then
	mkdir ./janeSoft
fi
   
if [ ! -e "./TextEditorForJava.desktop" ]; then
   echo "TextEditorForJava.desktop not exist."
   exit
fi
cp ./TextEditorForJava.desktop $HOME/Desktop
   
if [ ! -e "./TextEditorForJava.jar" ]; then
   echo "TextEditorForJava.jar not exist."
   exit
fi
java -Xms512m -Xmx1024m -jar ./TextEditorForJava.jar

exit
