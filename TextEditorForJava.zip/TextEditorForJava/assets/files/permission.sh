su
chmod 777 /data
chmod 777 /data/data