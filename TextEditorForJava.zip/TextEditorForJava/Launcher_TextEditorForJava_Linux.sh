 if [ ! -e "./TextEditorForJava.jar" ]; then
   echo "./TextEditorForJava.jar not exist."
   exit
fi
java -Xms512m -Xmx1024m -jar ./TextEditorForJava.jar

exit
