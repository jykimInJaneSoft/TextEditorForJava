#include "jni_common.h"

//extern jint JNI_AttachCurrentThread(JavaVM *vm, void **p_env, void *thr_args);

/**thiz : com_gsoft_common_gui_edittext_EditText
text : HighArray_CodeChar*/
jobject Java_com_gsoft_common_gui_edittext_EditText_setTextScrollBoth2(JNIEnv* env, jobject thiz, jint startLine, jobject text) {
	jvalue params;
	jvalue result;
	params.i = 0;

	//JNI_AttachCurrentThread(vm, (void**)&newEnv, (void*)NULL);


	jniCallObjectMethod(newEnv, text, "charAt", "(I)Lcom/gsoft/common/Code$CodeChar;", &params, &result);
	
	return result.l;


}

jint Java_com_gsoft_common_gui_edittext_EditText_addVals(JNIEnv* env, jint c1, jint c2) {
	return c1+c2;
}

/*jint Java_com_gsoft_common_gui_edittext_EditText_subVals(JNIEnv* env, jint startLine, jobject text) {
	jvalue params;
	jvalue result;
	params.i = 0;

	jniCallObjectMethod_ccp(env, text, "charAt", "(I)C", &params, &result);
	
	return result.c;
}*/


//int main() {
	/*char result[5];
	int len = getReturnDesc_ccp(NULL, "(I)C", result);
	printf("result=%s, len=%d\n", result, len);*/

	/*jint methodDescLenInByte;

	jint i;
	jchar c;
	char result[5];
	char* cp_result = "abcd";
	char* cp_result2 = (char*)malloc(5);
	int resultCount = 0;

	//methodDescLenInByte = strlen(result);
	methodDescLenInByte = strlen(cp_result);
	methodDescLenInByte = sizeof(cp_result2);
	printf("result=%s, methodDescLenInByte=%d\n", cp_result, methodDescLenInByte);*/

	/*jint methodDescLenInByte;

	jint i;
	jchar c;
	int resultCount = 0;
	const char* ccpMethodDesc = "(I)C";
	char* result = (char*)malloc(5);

	// methodDescLen = methodDesc.length();
	methodDescLenInByte = sizeof(ccpMethodDesc);
	printf("ccpMethodDesc=%s, methodDescLenInByte=%d\n", ccpMethodDesc, methodDescLenInByte);*/

	/*for (i=0; i<methodDescLenInByte; i++) {
		// char c = methodDesc.charAt(i);
		c = ccpMethodDesc[i];
		
		if (c==')') {
			break;
		}
	}

	for (i=i+1; i<methodDescLenInByte; i++) {
		c = ccpMethodDesc[i];
		result[resultCount] = c;
		resultCount++;
	}

	printf("result=%s, resultCount=%d\n", result, resultCount);*/


//	return 0;
//}

