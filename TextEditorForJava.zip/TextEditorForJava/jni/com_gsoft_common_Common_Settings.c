#include "jni_common.h"



/**classPathProperty:"-Djava.class.path=c:\mylibs"
libraryPathProperty:"-Djava.library.path=c:\mylibs"
*/
void Java_com_gsoft_common_Common_1Settings_initJavaVM2(JNIEnv* env, jstring classPathProperty, jstring libraryPathProperty) {	
	jint res;
	JavaVMInitArgs vm_args;
	JavaVMOption options[3];

	char *cpClassPathProperty;
	char *cpLibraryPathProperty;

	JavaVM *curVM=NULL;

	printf("initJavaVM(). \n");
	
	/*(*env)->GetJavaVM(env, &curVM);


	if (curVM!=NULL) {
		printf("curVM=%p\n", curVM);
		(*curVM)->DestroyJavaVM(curVM);
		printf("JavaVM destroyed. \n");
	}*/

	if (vm!=NULL) return;

cpClassPathProperty = (char*)(*env)->GetStringUTFChars(env, classPathProperty, NULL);
	//cpClassPathProperty = (char*)toConstCharPointer(env, classPathProperty);
   printf("%s\n", cpClassPathProperty);
	
	cpLibraryPathProperty = (char*)toConstCharPointer(env, libraryPathProperty);
   printf("%s\n", cpLibraryPathProperty);
	
	options[0].optionString = cpClassPathProperty; /* user classes */
	options[1].optionString = cpLibraryPathProperty;  /* set native library path */
	options[2].optionString = "-verbose:jni";                   /* print JNI-related messages */

	vm_args.version = (*env)->GetVersion(env);
	vm_args.options = options;
	vm_args.nOptions = 3;
	vm_args.ignoreUnrecognized = JNI_FALSE;

	/* Note that in the JDK/JRE, there is no longer any need to call
	 * JNI_GetDefaultJavaVMInitArgs.
	 */
	res = JNI_CreateJavaVM(&vm, (void **)&env, &vm_args);
	if (res < 0) { // error
		printf("JavaVM creation failed. \n");
		return;
	}
	//free(options);

	printf("JavaVM created. \n");
	printf("%s, %s\n", cpClassPathProperty, cpLibraryPathProperty);
}



/**classPathProperty:"-Djava.class.path=c:\mylibs"
libraryPathProperty:"-Djava.library.path=c:\mylibs"
*/
void Java_com_gsoft_common_Common_1Settings_initJavaVM() {	
	jint res;
	JavaVMInitArgs vm_args;
	JavaVMOption options[1];

	char *cpClassPathProperty;

	JavaVM *curVM;
	JNIEnv* env;

	printf("initJavaVM(). \n");
	
	/*(*env)->GetJavaVM(env, &curVM);


	if (curVM!=NULL) {
		printf("curVM=%p\n", curVM);
		(*curVM)->DestroyJavaVM(curVM);
		printf("JavaVM destroyed. \n");
	}*/

	if (vm!=NULL) return;

   cpClassPathProperty = "-Djava.class.path=/usr/lib/jvm/java-8-openjdk-i386/jre/lib";
   printf("%s\n", cpClassPathProperty);

	
	options[0].optionString = cpClassPathProperty; /* user classes */

	vm_args.version = JNI_VERSION_1_6;
	vm_args.options = options;
	vm_args.nOptions = 1;
	vm_args.ignoreUnrecognized = JNI_FALSE;

	/* Note that in the JDK/JRE, there is no longer any need to call
	 * JNI_GetDefaultJavaVMInitArgs.
	 */
	res = JNI_CreateJavaVM(&curVM, (void **)&env, &vm_args);
	if (res < 0) { // error
		printf("JavaVM creation failed. \n");
		return;
	}
	//free(options);

	printf("JavaVM created. \n");
	printf("%s\n", cpClassPathProperty);
}

