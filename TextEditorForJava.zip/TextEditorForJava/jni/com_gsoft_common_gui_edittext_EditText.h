#include "jni_common.h"

#ifndef _com_gsoft_common_gui_edittext_EditText_h
#define _com_gsoft_common_gui_edittext_EditText_h

jchar Java_com_gsoft_common_gui_edittext_EditText_setTextScrollBoth2(JNIEnv* env/*, jobject thiz, jint startLine, jobject text*/);

jint Java_com_gsoft_common_gui_edittext_EditText_addVals(JNIEnv* env, jint c1, jint c2);

#endif
