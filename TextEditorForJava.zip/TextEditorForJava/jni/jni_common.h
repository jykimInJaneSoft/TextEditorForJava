#include "jni.h"
#include <stdlib.h>
#include <string.h>

jboolean gIsDebugMode = JNI_TRUE;

const jint MAX_RETURN_DESC_LEN = 100;

JavaVM* vm = NULL;
JNIEnv* newEnv = NULL;

jint gJNIVersion = JNI_VERSION_1_1;

jint JNI_OnLoad(JavaVM *vm, void *reserved) {
   jint ret = (*vm)->AttachCurrentThread(vm, (void **)&newEnv, NULL);
   if (ret<0) {
      printf("JNI_OnLoad failed\n");
   }   
   gJNIVersion = (*newEnv)->GetVersion(newEnv);
   printf("JNI_OnLoad() successed. gJNIVersion=%d\n", gJNIVersion);

   return gJNIVersion;
}

void jniCallObjectMethod(JNIEnv* env, jobject object, const char* ccpMethodName, const char* ccpMethodDesc, jvalue* params, jvalue* resultValue);

jint get_jstringLength(JNIEnv* env, jstring str) {
   jint strLen = -1;
   const char* ccpMethodName = "java/lang/String";
   const char* ccpMethodDesc = "()I";
   jvalue* params = NULL;
   jvalue resultValue;
   
   jniCallObjectMethod(env, str, ccpMethodName, ccpMethodDesc, params, &resultValue); 
   return resultValue.i;
}

void initBooleanBuf(jboolean *booleanBuf, jint bufLen, jboolean bValue) {
	int i;
	for (i=0; i<bufLen; i++) {
		booleanBuf[i] = bValue;
	}
}

const char* toConstCharPointer(JNIEnv* env, jstring str) {
	jboolean *isCopy;
	const char * charsBuf;
	jint bufLen;

   if (gIsDebugMode) printf("toConstCharPointer()\n");

   //bufLen = get_jstringLength(env, str);
	bufLen = (*env)->GetStringUTFLength(env, str);
   if (gIsDebugMode) printf("toConstCharPointer(), bufLen=%d\n", bufLen);

	isCopy = malloc(bufLen);
	initBooleanBuf(isCopy, bufLen, JNI_TRUE);
	charsBuf = (*env)->GetStringUTFChars(env, str, isCopy);

   if (gIsDebugMode) printf("toConstCharPointer(), charsBuf=%s\n", charsBuf);

	free(isCopy);
	return charsBuf;
}


jint getReturnDesc(JNIEnv* env, const char* ccpMethodDesc, char* result) {
	jint methodDescLenInByte;

	jint i;
	jchar c;
	int resultCount = 0;
	
	methodDescLenInByte = strlen(ccpMethodDesc);
	

	for (i=0; i<methodDescLenInByte; ) {
		c = ccpMethodDesc[i];
				
		if (c==')') {
			break;
		}
		i++;
		/*if (0<=c && c<=127) {
			i++;
		}
		else {
			i+=2;
		}*/
	}

	for (i=i+1; i<methodDescLenInByte; i++) {
		c = ccpMethodDesc[i];
		result[resultCount] = c;
		resultCount++;
	}
	
	if (gIsDebugMode) printf("getReturnDesc, result=%s, resultCount=%d\n", result, resultCount);
	return resultCount;
}

/**params : params of slashedFullClassName.method(methodDesc)
resultValue : return value of slashedFullClassName.method(methodDesc)*/
void jniCallStaticMethod(JNIEnv* env, const char* slashedFullClassName, const char* methodName, const char* methodDesc, jvalue* params, jvalue* resultValue) {	

	char* cpReturnDesc;
	jint returnDescLen;

	jint i;
	jchar c;

	jclass jklass;
	jmethodID jmethod;

	jint dimensionArray=0;

		

	jklass = (*env)->FindClass(env, slashedFullClassName);
	jmethod = (*env)->GetMethodID(env, jklass, methodName, methodDesc);
	if (jmethod==NULL) return;


	/*typedef union jvalue {
	    jboolean z;
	    jbyte    b;
	    jchar    c;
	    jshort   s;
	    jint     i;
	    jlong    j;
	    jfloat   f;
	    jdouble  d;
	    jobject  l;
	} jvalue;*/
		
	cpReturnDesc = (char*)malloc(MAX_RETURN_DESC_LEN);
	returnDescLen = getReturnDesc(env, methodDesc, cpReturnDesc);

	// 리턴 타입
	for (i=0; i<returnDescLen; i++) {
		c = cpReturnDesc[i];

		if (c=='[') {
			dimensionArray++;
		}
		else if (c=='L') {
			resultValue->l = (*env)->CallStaticObjectMethodA(env, jklass, jmethod, params);
		}
		else  
		{
			switch (c) {
			case 'V': (*env)->CallStaticVoidMethodA(env, jklass, jmethod, params); break;
			case 'B': resultValue->b = (*env)->CallStaticByteMethodA(env, jklass, jmethod, params); break;
			case 'C': resultValue->c = (*env)->CallStaticCharMethodA(env, jklass, jmethod, params); break;
			case 'D': resultValue->d = (*env)->CallStaticDoubleMethodA(env, jklass, jmethod, params); break;
			case 'F': resultValue->f = (*env)->CallStaticFloatMethodA(env, jklass, jmethod, params); break;
			case 'I': resultValue->i = (*env)->CallStaticIntMethodA(env, jklass, jmethod, params); break;
			case 'J': resultValue->j = (*env)->CallStaticLongMethodA(env, jklass, jmethod, params); break;
			case 'S': resultValue->s = (*env)->CallStaticShortMethodA(env, jklass, jmethod, params); break;
			case 'Z': resultValue->z = (*env)->CallStaticBooleanMethodA(env, jklass, jmethod, params); break;
			}
		}
	}

}



/**params : params of slashedFullClassName.method(methodDesc)
resultValue : return value of slashedFullClassName.method(methodDesc)

In (c = text.charAt(i)), 
	object is text, ccpMethodName is "charAt", ccpMethodDesc is "(I)C", 
	params are {i}, resultValue is c.*/
void jniCallObjectMethod(JNIEnv* env, jobject object, const char* ccpMethodName, const char* ccpMethodDesc, jvalue* params, jvalue* resultValue) {	
	char* cpReturnDesc;
	jint returnDescLen;

	jint i;
	jchar c;

	jclass jklass;
	jmethodID jmethod;

	jint dimensionArray=0;

	if (gIsDebugMode) printf("ccpMethodName=%s, ccpMethodDesc=%s\n", ccpMethodName, ccpMethodDesc);

/*typedef union jvalue {
	    jboolean z;
	    jbyte    b;
	    jchar    c;
	    jshort   s;
	    jint     i;
	    jlong    j;
	    jfloat   f;
	    jdouble  d;
	    jobject  l;
	} jvalue;*/
   if (gIsDebugMode) printf("jniCallObjectMethod() env=%p\n", env);

	jklass = (*env)->GetObjectClass(env, object);
	if (jklass==NULL) {
	   if (gIsDebugMode) printf("jniCallObjectMethod() failded. jklass not found.\n");
	   return;
	}

	jmethod = (*env)->GetMethodID(env, jklass, ccpMethodName, ccpMethodDesc);
	if (jmethod==NULL) {
	   if (gIsDebugMode) printf("jniCallObjectMethod() failded. jmethod not found.\n");
	   return;
	}
		

	cpReturnDesc = (char*)malloc(MAX_RETURN_DESC_LEN);
	returnDescLen = getReturnDesc(env, ccpMethodDesc, cpReturnDesc);

	// 리턴 타입
	for (i=0; i<returnDescLen; i++) {
		c = cpReturnDesc[i];

		if (c=='[') {
			dimensionArray++;
		}
		else if (c=='L') {
			resultValue->l = (*env)->CallObjectMethodA(env, object, jmethod, params);
		}
		else  
		{
			switch (c) {
			case 'V': (*env)->CallVoidMethodA(env, object, jmethod, params); break;
			case 'B': resultValue->b = (*env)->CallByteMethodA(env, object, jmethod, params); break;
			case 'C': resultValue->c = (*env)->CallCharMethodA(env, object, jmethod, params); break;
			case 'D': resultValue->d = (*env)->CallDoubleMethodA(env, object, jmethod, params); break;
			case 'F': resultValue->f = (*env)->CallFloatMethodA(env, object, jmethod, params); break;
			case 'I': resultValue->i = (*env)->CallIntMethodA(env, object, jmethod, params); break;
			case 'J': resultValue->j = (*env)->CallLongMethodA(env, object, jmethod, params); break;
			case 'S': resultValue->s = (*env)->CallShortMethodA(env, object, jmethod, params); break;
			case 'Z': resultValue->z = (*env)->CallBooleanMethodA(env, object, jmethod, params); break;
			}
		}
	}
}



void jniGetField(JNIEnv* env, jclass clazz, jobject object, jstring fieldName, jstring typeDescOfField, jvalue* resultValue) {

	jfieldID fieldID = (*env)->GetFieldID(env, clazz, toConstCharPointer(env, fieldName), toConstCharPointer(env, typeDescOfField));













}
