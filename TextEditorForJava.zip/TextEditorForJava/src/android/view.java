package android;

import java.awt.Insets;
import java.awt.event.KeyListener;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JFrame;

import android.content.Context;

import com.gsoft.common.gui.Control;

public class view {
	public static class KeyCharacterMap {

		public static KeyCharacterMap load(int deviceId) {
			
			return null;
		}

	}

	public static class MotionEvent {
		int x;
		int y;
		int action;
		long eventTime;
		long downTime;

		public static final int ACTION_MOVE = 0;
		public static final int ACTION_DOWN = 1;
		public static final int ACTION_DOUBLE_CLICKED = 2;
		public static final int ACTION_UP = 3;
		
		public MotionEvent(int x, int y, int action, long eventTime) {
			this.x = x;
			this.y = y;
			this.action = action;
			this.eventTime = eventTime;
		}

		public int getAction() {
			
			return action;
		}

		public int getX() {
			
			return x;
		}

		public int getY() {
			
			return y;
		}

		public long getEventTime() {
			
			return eventTime;
		}

		public long getDownTime() {
			
			return downTime;
		}

	}

	public static class WindowManager {

		public static class LayoutParams {

			public static final int FLAG_KEEP_SCREEN_ON = 128;
			
		}

	}

	public static class KeyEvent {
		int action;
		int keyCode;
		public java.awt.event.KeyEvent awtKeyEvent;

		public static final int ACTION_DOWN = 0;

		public static final int KEYCODE_BACK = 4;
		public static final int KEYCODE_ESCAPE = 111;

		public static final int KEYCODE_PAGE_UP = 92;

		public static final int KEYCODE_PAGE_DOWN = 93;

		public static final int KEYCODE_SHIFT_LEFT = 59;

		public static final int KEYCODE_SHIFT_RIGHT = 60;
		public static final int KEYCODE_ENTER = 66;
		public static final int KEYCODE_DEL = 67;
		public static final int KEYCODE_DPAD_LEFT = 0;
		public static final int KEYCODE_DPAD_RIGHT = 0;
		public static final int KEYCODE_DPAD_UP = 0;
		public static final int KEYCODE_DPAD_DOWN = 0;
		public static final int KEYCODE_HOME = 0;
		public static final int KEYCODE_ENDCALL = 0;
		public static final int KEYCODE_Z = 0;
		public static final int KEYCODE_Y = 0;
		public static final int KEYCODE_F = 0;
		public static final int KEYCODE_C = 0;
		public static final int KEYCODE_X = 0;
		public static final int KEYCODE_V = 0;
		public static final int KEYCODE_A = 0;

		public KeyEvent(java.awt.event.KeyEvent e) {
			
			action = ACTION_DOWN;
			awtKeyEvent = e;
			if (e.getKeyCode()==java.awt.event.KeyEvent.VK_BACK_SPACE)
				keyCode = KEYCODE_BACK;
			else if (e.getKeyCode()==java.awt.event.KeyEvent.VK_ESCAPE)
				keyCode = KEYCODE_ESCAPE;
			else if (e.getKeyCode()==java.awt.event.KeyEvent.VK_PAGE_UP)
				keyCode = KEYCODE_PAGE_UP;
			else if (e.getKeyCode()==java.awt.event.KeyEvent.VK_PAGE_DOWN)
				keyCode = KEYCODE_PAGE_DOWN;
			else if (e.getKeyCode()==java.awt.event.KeyEvent.VK_SHIFT)
				keyCode = KEYCODE_SHIFT_LEFT;
			else if (e.getKeyCode()==java.awt.event.KeyEvent.VK_ENTER)
				keyCode = KEYCODE_ENTER;
			else if (e.getKeyCode()==java.awt.event.KeyEvent.VK_DELETE)
				keyCode = KEYCODE_DEL;
			else keyCode = -1;
		}

		public int getAction() {
			
			return action;
		}

		public int getDeviceId() {
			
			return 0;
		}

		public int getMetaState() {
			
			return 0;
		}

		public int getUnicodeChar(int metaState) {
			
			char c = this.awtKeyEvent.getKeyChar();
			return c;
		}

		public boolean isAltPressed() {
			
			boolean b = this.awtKeyEvent.isAltDown();
			return b;
		}

		public boolean isShiftPressed() {
			
			boolean b = this.awtKeyEvent.isShiftDown();
			return b;
		}

		public boolean isCtrlPressed() {
			
			return false;
		}

	}
	
	
	
	@SuppressWarnings("serial")
	public static class View extends JFrame implements WindowListener, KeyListener {
		
		Context context;
		public Insets insets;
		//public boolean invalidateAll = true;
		
		public static interface OnTouchListener extends MouseListener, MouseMotionListener {
			public boolean onTouch(View v, MotionEvent event);
		}
		
		public View(Context context) {
			
			this.context = context;
			this.addWindowListener(this);
			this.setUndecorated(true);
			this.setResizable(false);
			this.addKeyListener(this);
			
		}
		
		public void setSize(int width, int height) {
			
			super.setSize(width, height);
			insets = this.getInsets();
		}
		
		public void setBounds(int x, int y, int width, int height) {
			
			super.setBounds(x, y, width, height);
			insets = this.getInsets();
		}
		
		public void postInvalidate() {
			
			//invalidate();
			this.paint();
			
		}
		
		

		/** MouseListener와 MouseMotionListener는 매개변수의 onTouchListener이다.*/
		public void setOnTouchListener(OnTouchListener onTouchListener) {
			
			this.addMouseListener(onTouchListener);
			this.addMouseMotionListener(onTouchListener);
		}

		public int getHeight() {
			
			return getBounds().height;
		}

		public void invalidate() {
			
			// Windows			
			this.repaint();
			
			//paint();
		}
		public void paint() {
			
		}

		public Context getContext() {
			
			return context;
		}

		public int getWidth() {
			
			return getBounds().width;
		}

		@Override
		public void windowActivated(WindowEvent arg0) {
			
			insets = this.getInsets();
		}

		@Override
		public void windowClosed(WindowEvent arg0) {
			
			//Control.activity.finish();
			System.exit(0);
		}

		@Override
		public void windowClosing(WindowEvent arg0) {
			
			//Control.activity.finish();
			Control.exit(false);
		}
		
		public void processWindowEvent(WindowEvent event) {
			if (event.getID()!=WindowEvent.WINDOW_CLOSING) {
				super.processWindowEvent(event);
			}
			else {
				Control.exit(false);
			}
		}

		@Override
		public void windowDeactivated(WindowEvent arg0) {
			
			
		}

		@Override
		public void windowDeiconified(WindowEvent arg0) {
			
			
		}

		@Override
		public void windowIconified(WindowEvent arg0) {
			
		}

		@Override
		public void windowOpened(WindowEvent arg0) {
			
			insets = this.getInsets();
		}

		@Override
		public void keyPressed(java.awt.event.KeyEvent e) {
			
			KeyEvent event = new KeyEvent(e);
			Control.activity.onKeyDown(event.keyCode, event);
		}

		@Override
		public void keyReleased(java.awt.event.KeyEvent arg0) {
			
			
		}

		@Override
		public void keyTyped(java.awt.event.KeyEvent e) {
			
			//KeyEvent event = new KeyEvent(e); 
			//Control.activity.onKeyDown(event.keyCode, event);
		}
		
	}
	
	public static class Window {

		public void setFlags(int flagKeepScreenOn, int flagKeepScreenOn2) {
			
			
		}

		public void clearFlags(int flagKeepScreenOn) {
			
			
		}
		
	}
}