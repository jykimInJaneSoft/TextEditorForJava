package android;

public class util {

	public static class Log {

		public static void e(String tag, String message) {
			
			
		}

	}
	
}