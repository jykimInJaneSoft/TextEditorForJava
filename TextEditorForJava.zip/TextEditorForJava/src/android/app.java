package android;

import android.content.Context;
import android.content.Intent;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;

public class app {
	public static class Activity {
		public View view;
		Context context = new Context();
		Window window = new Window();
		boolean isFinishing;
		
		public Context getApplicationContext() {
			
			return context;
		}


		public void finish() {
			
			isFinishing = true;
			onDestroy();
			//Control.view.dispose();
		}

		protected void onResume() {
			
			
		}

		protected void onPause() {
			
			
		}
		
		public boolean isFinishing() {
			
			return isFinishing;
		}

		protected void onDestroy() {
			
			
		}
		
		public Window getWindow() {
			
			return window;
		}


		public void startActivity(Intent intent) {
			
			
		}
		
		public void setContentView(View view) {
			
			this.view = view;			
			this.view.setVisible(true);
		}
		
		public boolean onKeyDown(int keyCode, KeyEvent event) {
			return true;
		}
	}
	
	
}