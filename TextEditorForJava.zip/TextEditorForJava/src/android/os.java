package android;

import java.io.File;

import android.content.Context;

public class os {
	public static class PowerManager {

		public static class WakeLock {

			public void acquire() {
				
				
			}

			public void release() {
				
				
			}

		}

		public static final int PARTIAL_WAKE_LOCK = 1;

		public void goToSleep(long time) {
			
			
		}

		/** wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "My Lock");*/
		public WakeLock newWakeLock(int levelAndFlags, String tag) {
			
			return new WakeLock();
		}

	}

	public static class Build {

		public static class VERSION {

			public static int SDK_INT = 18;
			
		}

	}

	public static class Process {

		public static int myPid() {
			
			return 0;
		}

		public static void killProcess(int myPId) {
			
			
		}

	}

	public static class Bundle {

	}

	public static class Environment {

		/** 윈도우즈의 경우 예를들어 c:\TextEditorForJava 가 되고, 
		 * 안드로이드의 경우는 /mnt/sdcard 가 된다.
		 */
		public static File getExternalStorageDirectory() {
			
			return new File(Context.ExternalStorage_path);
		}

		public static File getRootDirectory() {
			
			return new File(Context.Root_path);
		}
		
	}
}