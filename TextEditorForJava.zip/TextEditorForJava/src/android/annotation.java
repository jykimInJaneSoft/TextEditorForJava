package android;

public class annotation {

	public static class SuppressLint {

	}

}