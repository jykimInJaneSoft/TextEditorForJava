package test6;

class IncThread extends Thread
{
   public IncThread(String stg) {
   super(stg);
   }
   public void run()
   {
      for(int i=1;i<=10;i++) {
         System.out.println(getName()+" 번호 -> "+ i);
         try {
            sleep((int)3*100);
         }
         catch(InterruptedException e) {}
      }
      System.out.println(getName()+" 11111111");
    }      
}