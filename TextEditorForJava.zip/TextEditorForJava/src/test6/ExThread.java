package test6;

import test6.IncThread;
import test6.DecThread;
public class ExThread {
	public static void main(String[] args) {
		IncThread t1=new IncThread("쓰레드 1");
      t1.start();
      DecThread t2= new DecThread("쓰레드 2");
      t2.start();
	}
}
