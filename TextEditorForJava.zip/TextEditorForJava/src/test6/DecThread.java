package test6;

class DecThread extends Thread
{
   public DecThread(String stg) {
      super(stg);
   }
   public void run()
   {
      for(int i=10;i>=1;i--) {
         System.out.println(getName()+" 번호 -> "+ i);
         try {
            sleep((int)3*100);
         }
         catch(InterruptedException e) {}
      }
      System.out.println(getName()+" ooo");
   }
}   