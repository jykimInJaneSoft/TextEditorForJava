package janesoft.common;

public class Array {
	public int length;
}
