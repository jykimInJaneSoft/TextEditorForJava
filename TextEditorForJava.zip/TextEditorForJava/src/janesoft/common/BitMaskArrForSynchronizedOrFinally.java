package janesoft.common;


/** called at run-time, not compile-time*/
public class BitMaskArrForSynchronizedOrFinally {
	
	/** synchronized func()*/
	public static Object lockForSynchronizedFunc = new Integer(1);
	
	/** Gets monitor state of serialNumberInBitMaskArr from bitMaskArrForSynchronized variable
	 * @return : true(MonitorEnter, ExceptionOccurred), false(MonitorExit, ExceptionNotOccurred)*/
	public static boolean getBooleanValueFromBitMaskArr(int serialNumberInBitMaskArr, int bitMaskArr) {
		//int sn = getSerialNumberInBitMaskArr(func, mBufferIndexOfSyncKeyword);
		int sn = serialNumberInBitMaskArr;
		int mask = 1;
		int i;
		for (i=0; i<sn; i++) {
			mask *= 2;
		}
		int value = bitMaskArr & mask;
		if (value==0) return false;
		return true;
	}
	
	/**@booleanValue : true(MonitorEnter, ExceptionOccurred), false(MonitorExit, ExceptionNotOccurred)*/
	public static int setBooleanValueToBitMaskArr(int serialNumberInBitMaskArr, int bitMaskArr, boolean booleanValue) {
		//int sn = getSerialNumberInBitMaskArr(func, mBufferIndexOfSyncKeyword);
		int sn = serialNumberInBitMaskArr;
		int mask = 1;
		int i;
		for (i=0; i<sn; i++) {
			mask *= 2;
		}
		if (booleanValue) {	
			// monitor enter, ExceptionOccurred
			int newBitMask = bitMaskArr | mask;
			return newBitMask;
		}
		else {
			// monitor exit, ExceptionNotOccurred
			int newBitMask = bitMaskArr ^ mask;
			return newBitMask;
		}
	}
}
