package janesoft.common;

import java.lang.reflect.Field;


@SuppressWarnings("rawtypes")
public class MemoryManager {
	/**물리적 메모리*/
	byte[] mem;
		
	public static Object[] listOfNewCalls = new Object[1000];
	public static int countOflistOfNewCalls = 0;
	
	
	static void addToList(Object obj) {
		if (countOflistOfNewCalls<listOfNewCalls.length) {
			listOfNewCalls[countOflistOfNewCalls] = obj;
		}
		else {
			Object[] listOfNewCalls_new = new Object[3*listOfNewCalls.length];
			Copy(listOfNewCalls, 0, listOfNewCalls_new, 0, countOflistOfNewCalls);
			listOfNewCalls = listOfNewCalls_new;
			listOfNewCalls[countOflistOfNewCalls] = obj;
		}
		countOflistOfNewCalls++;
	}
	
	public static void Copy(Object[] src, int srcIndex, Object[] dest, int destIndex, int len) {
		int i;
		for (i=srcIndex; i<srcIndex+len; i++) {
			dest[destIndex++] = src[i];
		}		
	}
	
	public static void newObject(Object obj) {
		// public static ArrayList listOfNewCalls = new ArrayList(1000);에서 
		// ArrayList()의 Object[] list = new Object[1000]에서 newObject()가 호출될때 listOfNewCalls는 null이므로
		// Object[]는 listOfNewCalls에 등록되지 않는다.
		if (listOfNewCalls!=null) {
			addToList(obj);
		}
	}
	
	/**힙 오브젝트의 리스트를 스트링으로 리턴해준다.*/
	public static StringBuffer getMessage() {
		int i;
		StringBuffer r = new StringBuffer(50);
		
		if (countOflistOfNewCalls>0) {
			Object obj = listOfNewCalls[0];
			Class c = obj.getClass();
			String typeName = c.getSimpleName();		
			r.append(typeName);
			int numberOfUsedMemory = getNumberOfUsedMemory(obj);
			r.append("("+numberOfUsedMemory+")");
		}
		
		for (i=1; i<countOflistOfNewCalls; i++) {
			Object obj = listOfNewCalls[i];
			Class c = obj.getClass();
			String typeName = c.getSimpleName();
			r.append(", ");
			r.append(typeName);
			int numberOfUsedMemory = getNumberOfUsedMemory(obj);
			r.append("("+numberOfUsedMemory+")");
		}
		return r;
	}
	
	/**메모리 사용량*/
	public static long sumMemory() {
		int i;
		long r = 0;
		for (i=0; i<countOflistOfNewCalls; i++) {
			Object obj = listOfNewCalls[i];
			r += getNumberOfUsedMemory(obj);			
		}
		return r;
	}
	
	
	static int getNumberOfUsedMemory(Object obj) {
		Class c = obj.getClass();
		int r=0;
		if (!c.isArray()) {
			Field[] arrFields = c.getDeclaredFields();
			int i;
			for (i=0; i<arrFields.length; i++) {
				String typeName = arrFields[i].getType().getName();
				if (typeName.equals("byte")) r += 1;
				else if (typeName.equals("char")) r += 1;
				else if (typeName.equals("short")) r += 2;
				else if (typeName.equals("int")) r += 4;
				else if (typeName.equals("long")) r += 8;
				else if (typeName.equals("float")) r += 4;
				else if (typeName.equals("double")) r += 8;
				else {
					r += 4;
				}
			}
		}
		else {
			int length = java.lang.reflect.Array.getLength(obj);
			String typeName = c.getSimpleName();
			String elementTypeName = null;
			int indexOfLeftPair = typeName.indexOf('[');
			elementTypeName = typeName.substring(0, indexOfLeftPair);
			int numOfBytes = 4;
			if (elementTypeName.equals("byte")) numOfBytes = 1;
			else if (elementTypeName.equals("char")) numOfBytes = 1;
			else if (elementTypeName.equals("short")) numOfBytes = 2;
			else if (elementTypeName.equals("int")) numOfBytes = 4;
			else if (elementTypeName.equals("long")) numOfBytes = 8;
			else if (elementTypeName.equals("float")) numOfBytes = 4;
			else if (elementTypeName.equals("double")) numOfBytes = 8;
			else {
				numOfBytes = 4;
			}
			r += numOfBytes*length;
		}
		return r;
	}
	
	public static void deleteObject(Object obj) {
		
	}
}
