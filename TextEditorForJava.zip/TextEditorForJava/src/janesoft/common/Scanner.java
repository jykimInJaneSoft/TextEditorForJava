package janesoft.common;

import java.io.File;
import java.io.InputStream;

import com.gsoft.common.IO;
import com.gsoft.common.IO_types.ReturnOfReadString;
import com.gsoft.common.util.HighArray_char;

public class Scanner {
	String curDir = System.getenv("user.dir");
	String inputFilePath = curDir+File.separator+"temp"+File.separator+"input";
	/**per a process*/
	static long oldFileLen;
	
	public Scanner(InputStream is) {
		
	}
	
	public String next() {
		// Receives Common_Settings.pathProject from parent process(ClassFileRunner)
		File inputFile = new File(inputFilePath);
		while (true) {
			if (oldFileLen!=inputFile.length()) {
				// 추가된 부분만 읽는다.
				ReturnOfReadString str = IO.readStringUTF8(inputFile.getAbsolutePath(), oldFileLen);
				
				HighArray_char str2 = str.result;
				
				oldFileLen = inputFile.length();
				String result = str2.getItems();
								
				// ClassFileRunner에서 리다이렉트를 했으므로 사용자가 입력한 스트링을 System.out에 출력을 해야 한다.
				// Adds blank to console
				System.out.print(result);
				
				// Deletes blank to next() call
				result = result.trim();
								
				return result;
			}
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
		}
	}
	
	public String nextLine() {
		// Receives Common_Settings.pathProject from parent process(ClassFileRunner)
		File inputFile = new File(inputFilePath);
		HighArray_char lineResult = new HighArray_char(10);
		while (true) {
			if (oldFileLen!=inputFile.length()) {
				// 추가된 부분만 읽는다.
				ReturnOfReadString str = IO.readStringUTF8(inputFile.getAbsolutePath(), oldFileLen);
				
				HighArray_char str2 = str.result;
				
				oldFileLen = inputFile.length();
				String strResult = str2.getItems();
								
				// ClassFileRunner에서 리다이렉트를 했으므로 사용자가 입력한 스트링을 System.out에 출력을 해야 한다.
				// Adds blank to console
				System.out.print(strResult);
				if (strResult.charAt(strResult.length()-1)!='\n') {
					lineResult.add(strResult);
				}
				else {
					// Remove '\n'
					lineResult.add(strResult.substring(0, strResult.length()-1));
					return lineResult.getItems();
				}
			}
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
		}
	}
	
	
	
	public int nextInt() {
		String str = next();
		return Integer.parseInt(str);
	}
	
	public float nextFloat() {
		String str = next();
		return Float.parseFloat(str);
	}
	
	public double nextDouble() {
		String str = next();
		return Double.parseDouble(str);
	}
	
	public long nextLong() {
		String str = next();
		return Long.parseLong(str);
	}
	
	public boolean nextBoolean() {
		String str = next();
		return Boolean.parseBoolean(str);
	}
	
	public byte nextByte() {
		String str = next();
		return Byte.parseByte(str);
	}
	public short nextShort() {
		String str = next();
		return Short.parseShort(str);
	}
	
	public void close() {
	}

}
