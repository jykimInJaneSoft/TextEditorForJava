package com.gsoft.common;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import com.gsoft.common.IO_types.ReturnOfReadString;
import com.gsoft.common.IO_types.TextFormat;
import com.gsoft.common.gui.FileDialog.Category;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListString;

import com.gsoft.common.MultiMedia;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.IO;

public class FileHelper {
	
	public static Category getFileCategory(String filePath) {
		if (new File(filePath).isDirectory()) return null;
		
		String ext = FileHelper.getExt(filePath);
		//if (ext.equals(".bmp") | ext.equals(".png") | ext.equals(".jpg") |
		//		 ext.equals(".gif")) {
		int k;
		for (k=0; k<MultiMedia.extensionOfImage.length; k++) {
			if (ext.contains(MultiMedia.extensionOfImage[k])) {
				return Category.Image;
			}
		}
		
		for (k=0; k<MultiMedia.extensionOfAudio.length; k++) {
			if (ext.contains(MultiMedia.extensionOfAudio[k])) {
				return Category.Music;
			}
		}
		for (k=0; k<MultiMedia.extensionOfVideo.length; k++) {
			if (ext.contains(MultiMedia.extensionOfVideo[k])) {
				return Category.Video;
			}
		}
		for (k=0; k<MultiMedia.extensionOfCompression.length; k++) {
			if (ext.contains(MultiMedia.extensionOfCompression[k])) {
				return Category.Compression;
			}
		}
		if (ext.equals(".kjy")) {
			return Category.Custom;
		}
		return Category.Text;
	}
	
	/** 윈도우즈의 경우에는 c:, d: 등을 리턴하고 안드로이드의 경우에는 ""을 리턴한다.*/
	public static String getPartitionName() {
		String curDir = System.getProperties().getProperty("user.dir");
		if (curDir.length()>1 && curDir.charAt(1)==':') {
			return curDir.substring(0, 2);
		}
		return ""; 
	}
	
	public static class LanguageAndTextFormat {
		public com.gsoft.common.compiler.Compiler_types.Language lang;
		public TextFormat format;
		
		public LanguageAndTextFormat(com.gsoft.common.compiler.Compiler_types.Language lang, TextFormat format) {
			this.lang = lang;
			this.format = format;
		}
	}
	
	/** 파일 확장자별로 language 와 textFormat 을 가져온다. 
	 * 확장자 txt 등은 null 을 리턴한다.*/
	public static LanguageAndTextFormat getLanguageAndTextFormat(String path) {
		String filenameExceptExt;
		String ext;	
		
		filenameExceptExt = FileHelper.getFilenameExceptExt(path);
		ext = FileHelper.getExt(path);
		path = filenameExceptExt + ext;
		
			
		
		TextFormat format = null;
		com.gsoft.common.compiler.Compiler_types.Language lang = null;
		
		if (ext.equals(".java")) {
			format = TextFormat.UTF_8;
			lang = com.gsoft.common.compiler.Compiler_types.Language.Java;
			//CommonGUI_SettingsDialog.settingsDialog.setTextSaveFormat(0);
		}
		else if (ext.equals(".c") || ext.equals(".cpp") || ext.equals(".h")) {
			format = TextFormat.UTF_8;
			lang = com.gsoft.common.compiler.Compiler_types.Language.C;
			//CommonGUI_SettingsDialog.settingsDialog.setTextSaveFormat(2);
		}
		else if (ext.equals(".htm") || ext.equals(".html")) {
			format = TextFormat.UTF_8;
			lang = com.gsoft.common.compiler.Compiler_types.Language.Html;
			//CommonGUI_SettingsDialog.settingsDialog.setTextSaveFormat(0);
		}
		else if (ext.equals(".sh")) {
			format = TextFormat.UTF_8;
			//CommonGUI_SettingsDialog.settingsDialog.setTextSaveFormat(0);
		}
		else if (ext.equals(".class")) {
			format = TextFormat.UTF_8;
			lang = com.gsoft.common.compiler.Compiler_types.Language.Class;
			//CommonGUI_SettingsDialog.settingsDialog.setTextSaveFormat(0);
		}
		else {
			return null;
		}
		
		return new LanguageAndTextFormat(lang, format);
		
	}
	
	/** 파일 확장자별로 textFormat 을 가져온다. 
	 * 확장자 txt 등은 null 을 리턴한다.*/
	public static TextFormat getTextFormat(String path) {
		String filenameExceptExt;
		String ext;	
		
		filenameExceptExt = FileHelper.getFilenameExceptExt(path);
		ext = FileHelper.getExt(path);
		path = filenameExceptExt + ext;
		
			
		
		TextFormat format = null;
		
		if (ext.equals(".java")) {
			format = TextFormat.UTF_8;
		}
		else if (ext.equals(".c") || ext.equals(".cpp")) {
			format = TextFormat.UTF_8;
		}
		else if (ext.equals(".htm") || ext.equals(".html")) {
			format = TextFormat.UTF_8;
		}
		else if (ext.equals(".sh")) {
			format = TextFormat.UTF_8;
		}
		else if (ext.equals(".class")) {
			format = TextFormat.UTF_8;
		}
		else {
			return null;
		}
		
		return format;
		
	}
	
	
	public static int getCount(String path, char c) {
		int i;
		char[] buf = path.toCharArray();
		int count=0;
		for (i=0; i<buf.length; i++) {
			if (buf[i]==c) count++;
		}
		return count;
	}
	
	public static boolean isSeparator(String str)
    {
        if (str.equals(File.separator)/* || str.equals("\\")*/)
            return true;
        return false;
    }
	
	public static boolean isSeparator(char c)
    {
        if (c==File.separator.charAt(0)/* || c=='\\'*/)
            return true;
        return false;
    }
	
	private static boolean equals(String[] strs1, String[] strs2) {
		if (strs1.length!=strs2.length) return false;
		int i, j;
		boolean found;
		for (i=0; i<strs1.length; i++) {
			found=false;
			for (j=0; j<strs2.length; j++) {
				if (strs1[i].equals(strs2[i])) {
					found = true;
					break;
				}
			}
			if (!found) return false;
		}
		return true;
	}
	
	public static boolean equals(File file1, File file2) {
		String name1 = file1.getName();
		String name2 = file2.getName();
		if (!name1.equals(name2)) return false;
		
		long len1 = file1.length();
		long len2 = file2.length();
		if (len1!=len2) return false;
		
		long time1 = file1.lastModified();
		long time2 = file2.lastModified();
		if (time1!=time2) return false;
				
		
		boolean isDir1 = file1.isDirectory();
		boolean isDir2 = file2.isDirectory();
		if (isDir1!=isDir2) return false;
		if (isDir1 && isDir2) {
			String[] fileList1 = file1.list();
			String[] fileList2 = file2.list();
			if (!equals(fileList1, fileList2)) return false;
		}
		return true;
	}
	
	
	/** 파일 작업이 가능한지 테스트해본다.*/
	/*public static boolean testFileWork() {
		OutputStream os = null;
		InputStream is = null;
		byte[] buf = new byte[1000];
		
		try {			
			Context context = Control.view.getContext();
			AssetManager asset = context.getAssets();
			is = asset.open("lib/Test.txt");
			String srcFilename = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Test.txt";
			File srcFile = new File(srcFilename);
			
			try {
				os = new FileOutputStream(srcFile);
				FileHelper.move(buf, is, os);
			}catch(Exception e) {
				return false;
			}
		}catch(Exception e) {
			return false;
		}
		finally {
			FileHelper.close(is);
			FileHelper.close(os);
		}
		return true;
	}*/
	
	/** absFilename 안에 있는 모든 디렉토리와 파일들을 리스트(File[])로 리턴한다.
	 * @param isRecursive : true이면 absFilename에 있는 디렉토리 안에 있는 디렉토리와 파일도 리스트에 포함한다.
	 * false이면 absFilename 안에 있는 디렉토리와 파일들만 포함한다.*/
	public static ArrayList getFileList(String absFilename, boolean isRecursive) {
		ArrayList result = null;
		if (isRecursive) {
			result = getFileListRecursively(absFilename);
		}
		else {
			result = new ArrayList(10);
			
			File file = new File(absFilename); 
			if (file.isDirectory()) {
				result.add(file); // 디렉토리
				
				String[] fileList = file.list();
				if (fileList!=null && fileList.length>0) {
					int i;				
					for (i=0; i<fileList.length; i++) {
						String filename = null;
						if (!isSeparator( absFilename.charAt(absFilename.length()-1) ))
							filename = absFilename+File.separator+fileList[i];
						else 
							filename = absFilename+fileList[i];
						result.add(new File(filename));
					}
				}
			}
			else {
				result.add(file);
			}			
		}
		return result;
	}
	
	/** absFilename 안에 있는 모든 디렉토리와 파일들을 리스트(File[])로 리턴한다.*/
	static ArrayList getFileListRecursively(String absFilename) {
		
		ArrayList result = new ArrayList(10);
		getFileListRecursively(absFilename, result);
		return result;
	}
	
	/**﻿하위 디렉토리들을 포함하여 모든 파일들의 리스트를 얻는다.*/
	static void getFileListRecursively(String absFilename, ArrayList result) {		
		File file = new File(absFilename); 
		if (file.isDirectory()) {
			result.add(file); // 디렉토리
			
			String[] fileList = file.list();
			if (fileList!=null && fileList.length>0) {
				int i;				
				for (i=0; i<fileList.length; i++) {
					if (!isSeparator( absFilename.charAt(absFilename.length()-1) ))
						FileHelper.getFileListRecursively(absFilename+File.separator+fileList[i], result);
					else 
						FileHelper.getFileListRecursively(absFilename+fileList[i], result);					
				}
			}
		}
		else {
			result.add(file);
		}
	}
	
	public static class SizeAndCount {
		public long size;
		public int count;
		public SizeAndCount() {
			
		}
		public SizeAndCount(long size, int count) {
			this.size = size;
			this.count = count;
		}
	}
	
	public static SizeAndCount getFileSizeAndCount(String absFilename) {
		long curTimeMillS = System.currentTimeMillis();
		SizeAndCount r = getFileSizeAndCount_sub(absFilename, curTimeMillS);
		if (r==null) {
			return new SizeAndCount(0, 0);
		}
		return r;
	}
	
	private static SizeAndCount getFileSizeAndCount_sub(String absFilename, long callTimeMillS) {
		long curTimeMillS = System.currentTimeMillis();
		if (curTimeMillS-callTimeMillS>1000*60*2) {
			return null;
		}
		SizeAndCount sizeAndCount = null;
		long size = 0;
		int count = 0;
		File file = new File(absFilename); 
		if (file.isDirectory()) {
			String[] fileList = file.list();
			if (fileList!=null && fileList.length>0) {
				int i;				
				for (i=0; i<fileList.length; i++) {
					SizeAndCount sc = null;
					if (!isSeparator( absFilename.charAt(absFilename.length()-1) ))
						sc = FileHelper.getFileSizeAndCount_sub(absFilename+File.separator+fileList[i], callTimeMillS);
					else 
						sc = FileHelper.getFileSizeAndCount_sub(absFilename+fileList[i], callTimeMillS);
					if (sc!=null) {
						size += sc.size;
						count += sc.count;
					}
					//return r;
				}
			}
			
			size += 0; // 디렉토리
			count++;
			sizeAndCount = new SizeAndCount(size,count);
			return sizeAndCount;
		}
		else {
			size += file.length();
			count++;
			sizeAndCount = new SizeAndCount(size,count);
			return sizeAndCount;
		}
	}
	
	/** 디렉토리일 경우 아래에 있는 파일이나 디렉토리 모두 센다.*/
	public static long getFileSize(String absFilename) {
		/*if (firstCall) {
			directoryForPath.reset();
		}*/
		long r=0;
		File file = new File(absFilename); 
		if (file.isDirectory()) {
			/*boolean directoryFound = isDirectoryFound(absFilename);
			if (directoryFound) {
				return 0;
			}
			directoryForPath.add(absFilename);*/
			String[] fileList = file.list();
			if (fileList!=null && fileList.length>0) {
				int i;				
				for (i=0; i<fileList.length; i++) {
					if (!isSeparator( absFilename.charAt(absFilename.length()-1) ))
						r += FileHelper.getFileSize(absFilename+File.separator+fileList[i]);
					else 
						r += FileHelper.getFileSize(absFilename+fileList[i]);
					//return r;
				}
			}
			
			r += 0; // 디렉토리
			return r;
		}
		else {
			r += file.length();
			return r;
		}
	}
	
	public static int getFileCountExceptDirectory(String absFilename) {
		
		int r=0;
		File file = new File(absFilename); 
		if (file.isDirectory()) {
			String[] fileList = file.list();
			if (fileList!=null && fileList.length>0) {
				int i;				
				for (i=0; i<fileList.length; i++) {
					if (!isSeparator( absFilename.charAt(absFilename.length()-1) ))
						r += FileHelper.getFileCountExceptDirectory(absFilename+File.separator+fileList[i]);
					else 
						r += FileHelper.getFileCountExceptDirectory(absFilename+fileList[i]);
					//return r;
				}
			}
			
			//r += 1; // 디렉토리
			return r;
		}
		else {
			r += 1;
			return r;
		}
	}
	
	
	
	public static String getJavaBinPath(boolean includesJRE) {
		if (File.separator.equals("/")) {
			String exePath = FileHelper.getJavaExePath(File.separator, includesJRE);
			return FileHelper.getDirectory(exePath);
		}
		else {
			String[] partitionNames = {"c:\\", "d:\\", "e:\\", "f:\\", "g:\\"};
			int i;
			String exePath = null;
			for (i=0; i<partitionNames.length; i++) {
				exePath = FileHelper.getJavaExePath(partitionNames[i], includesJRE);
				if (exePath!=null) {
					return FileHelper.getDirectory(exePath);
				}
			}
		}
		return null;
	}
	
	/**absFilename 디렉토리내에서 java.exe를 찾아 java.exe가 있는 디렉토리를 리턴한다.
	 * @param absFilename : 처음 호출시에는 /, c:\\와 같은 루트 디렉토리를 적는다.*/
	public static String getJavaExePath(String absFilename, boolean includesJRE) {
		File file = new File(absFilename);
		if (file.isDirectory()) {			
			String[] fileList = file.list();
			if (fileList!=null && fileList.length>0) {
				int i;
				String r = null;
				for (i=0; i<fileList.length; i++) {
					if (!isSeparator( absFilename.charAt(absFilename.length()-1) )) 
						r = FileHelper.getJavaExePath(absFilename+File.separator+fileList[i], includesJRE);					
					else 
						r = FileHelper.getJavaExePath(absFilename+fileList[i], includesJRE);
					if (r!=null) return r;
				}
			}
			
			return null;
		}
		else {
			String filename = FileHelper.getFilename(absFilename);
			String javaExe = null;
			if (File.separatorChar=='\\') {
				javaExe = "java.exe";
			}
			else {
				javaExe = "java";
			}
			if (filename.equals(javaExe)) {
				String lowerCaseFilePath = absFilename.toLowerCase();				
				if (!includesJRE) {
					if (lowerCaseFilePath.contains("jre")) {
						return null;
					}
				}
				String binPath = FileHelper.getDirectory(absFilename);
				String homePath = FileHelper.getDirectory(binPath);
				binPath = jdbExists(homePath);
				if (binPath!=null) {
					return absFilename;
				}
			}
			return null;
		}
	}
		
	/**@return javaHomePath + File.separator + bin에 jdb가 존재하면 이 디렉토리를 리턴한다. 
	 * 존재하지 않으면 null을 리턴*/
	public static String jdbExists(String javaHomePath) {
		String javaPath = null;
		String jdbPath = null;
		if (File.separatorChar=='\\') {
			jdbPath = javaHomePath + File.separator + "bin" + File.separator + "jdb.exe";
		}
		else {
			jdbPath = javaHomePath + File.separator + "bin" + File.separator + "jdb";
		}
		File jdbFile = new File(jdbPath);
		if (jdbFile.exists()) {
			javaPath = javaHomePath + File.separator + "bin";
		}
		return javaPath;
	}
	
	static String getJavaExePath_link(String absFilename, boolean includesJRE) {
		String javaExe = null;
		if (File.separatorChar=='\\') {
			javaExe = "java.exe";
		}
		else {
			javaExe = "java";
		}
		ReturnOfReadString fileContents = IO.readString(absFilename);
		if (fileContents!=null) {
			String path = fileContents.result.getItems();
			if (path!=null && (new File(path).exists())) {
				String javaFileName = FileHelper.getFilename(path);
				if (javaFileName.equals(javaExe)) {
					String lowerCaseFilePath = path.toLowerCase();				
					if (!includesJRE) {
						if (lowerCaseFilePath.contains("jre")) {
							return null;
						}
					}
					File javaFile = new File(path);
					if (javaFile.length()>1024*1024*1024) {
						return absFilename;
					}
					else {
						String r = getJavaExePath_link(path, includesJRE);
						if (r!=null) return r;
					}
				}
			}
		}
		return null;
	}
	
	/** 디렉토리일 경우 아래에 있는 파일이나 디렉토리 모두 센다.*/
	public static int getFileCount(String absFilename) {
		/*if (firstCall) {
			directoryForPath.reset();
		}*/
		int r=0;
		File file = new File(absFilename); 
		if (file.isDirectory()) {			
			String[] fileList = file.list();
			if (fileList!=null && fileList.length>0) {
				int i;				
				for (i=0; i<fileList.length; i++) {
					if (!isSeparator( absFilename.charAt(absFilename.length()-1) ))
						r += FileHelper.getFileCount(absFilename+File.separator+fileList[i]);
					else 
						r += FileHelper.getFileCount(absFilename+fileList[i]);
				}
			}
			
			r += 1; // 디렉토리
			return r;
		}
		else {
			r += 1;
			return r;
		}
	}
	
	/** 디렉토리일 경우 아래에 있는 파일이나 디렉토리 모두 지운다.*/
	public static boolean delete(String absFilename) {
		boolean r=false;
		File file = new File(absFilename); 
		if (file.isDirectory()) {
			String[] fileList = file.list();
			if (fileList!=null && fileList.length>0) {
				int i;				
				for (i=0; i<fileList.length; i++) {
					if (!isSeparator( absFilename.charAt(absFilename.length()-1) ))
						r = FileHelper.delete(absFilename+File.separator+fileList[i]);
					else 
						r = FileHelper.delete(absFilename+fileList[i]);
					//if (!r) return false;
				}
			}
			
			r = file.delete(); // 빈 디렉토리
			if (!r) return false;
		}
		else {
			r = file.delete();
			if (!r) return false;
		}
		return true;
	}
	
	/** 윈도우즈에서만 가능하다.
	 * @return 콜론을 뺀 c 나 d 등*/
	public static String[] getPartitionSymbols() {
		ArrayListString r = new ArrayListString(10); 
		for (char c='a'; c<='z'; c++) {
			char[] arr = {c};
			String path = new String(arr);
			File file = new File(path+":"+File.separator);
			if (file.exists()) {
				String partition = file.getAbsolutePath();
				r.add(partition);
			}
		}
		return r.getItems();
	}
	
	/** 윈도우즈에서만 가능하다.
	 * @return 콜론을 뺀 c 나 d 등*/
	public static String getPartition(String absFilename) {
		int indexColon = absFilename.indexOf(':');
		String r = absFilename.substring(0, indexColon);
		return r;
	}
	
	public static boolean isRoot(String filename) {
		if (Common_Settings.CurrentSystem.equals(Common_Settings.CurrentSystemIsJava)) {
			int indexColon = filename.indexOf(':');
			if (indexColon!=-1) {
				// "c:"나 "c:\"
				if (filename.length()==indexColon+1 || filename.length()==indexColon+2)
					return true;
			}
			else {
				// "\"
				if (filename.equals(File.separator)) return true;
			}
			return false;
		}
		else {
			if (filename.equals(File.separator)) return true;
			return false;
		}
	}
	
	/** 리턴값은 /을 포함한다. 
	 * 윈도우즈(자바)이면 루트이더라도 파티션이 있을수 있으므로 매개변수가 루트이면
	 * IO.LocalComputer을 리턴하고 리눅스(안드로이드)이면 루트를 리턴한다.*/
	public static String upDirectory(String filename) {
		int i;
		// 루트상태에서 up을 클릭한 경우
		if (isRoot(filename)) {
			if (File.separator.equals("/")) {
				return File.separator;	
			}
			else {
				// 파티션들이 나와야하므로
				return IO.LocalComputer+File.separator;
			}
			
		}
		for (i=filename.length()-2; i>=0; i--) {
			if (filename.charAt(i)==File.separator.charAt(0)/* || filename.charAt(i)=='\\'*/) {
				break;
			}
		}
		return filename.substring(0,i+1);
	}
	
	/** '.'을 포함하여 확장자를 리턴한다. 예를들어 .java, .class 등을 리턴한다. 확장자가 없으면 ""을 리턴한다.*/
	public static String getExt(String filename)
    {
        int i;
        char[] name = new char[filename.length()];
        filename.getChars(0, name.length, name, 0);
        for (i = name.length - 1; i >= 0; i--)
        {
            if (name[i] == '.')
            {
                break;
            }
        }
        if (i==-1) return "";
        String ext = filename.substring(i);
        return ext;
    }

	/**c:\Test\A.java는 c:\Test\A를 리턴한다.*/
	public static String getFilenameExceptExt(String filename)
    {
        int i;
        char[] name = new char[filename.length()];
        filename.getChars(0, name.length, name, 0);
        for (i = name.length - 1; i >= 0; i--)
        {
            if (name[i] == '.')
            {
                break;
            }
        }
        if (i==-1) return filename;
        return filename.substring(0, i);
    }
	
	/**대소문자를 구별해서 path가 디렉토리인지를 확인한다.*/
	public static boolean isDirectory(String path) {
		String dir = getDirectory(path);
		String filename = getFilename(path);
		File file = new File(dir);
		String[] list = file.list();
		int i;
		if (list==null) {
			return false;
		}
		for (i=0; i<list.length; i++) {
			String ext = FileHelper.getExt(list[i]);
			String filenameExceptExt = FileHelper.getFilenameExceptExt(list[i]);
			if (filenameExceptExt.equals(filename)) {
				if (!ext.equals("")) return false; // 확장자가 있는 파일인 경우
				if (new File(path).isDirectory()) {
					return true;
				}
				return false;
			}
		}
		return false;
	}
	
	/** path 에서 디렉토리를 추출해서 리턴한다.*/
	public static String getDirectory(String path)
    {
        int i;
        char[] name = new char[path.length()];
        path.getChars(0, name.length, name, 0);
        for (i = name.length - 1; i >= 0; i--)
        {
            if (name[i] == File.separator.charAt(0))
            {
                break;
            }
        }
        if (i==-1) return "";
        return path.substring(0, i);
    }
	
	/**c:\Test\A.java는 A.java를 리턴한다.*/
	public static String getFilename(String path)
    {
        int i;
        char[] name = new char[path.length()];
        path.getChars(0, name.length, name, 0);
        for (i = name.length - 1; i >= 0; i--)
        {
            if (name[i] == File.separator.charAt(0))
            {
                break;
            }
        }
        if (i==-1) return path;
        return path.substring(i+1, name.length);
    }
	
	
	public static void close(InputStream stream) {
		try {
			if (stream!=null) stream.close();
		}
		catch(Exception e) {}			
	}
	
	public static void close(OutputStream stream) {
		try {
			if (stream!=null) stream.close();
		}
		catch(Exception e) {}			
	}
	
	/**@param srcFilename : directory or file
	 * @param dstFilename : directory
	 * @param isRecursive : asks if including inner directory or files
	 */
	public static void copyFiles(String srcFilename, String dstFilename, boolean isRecursive) {
		ArrayList fileList = FileHelper.getFileList(srcFilename, isRecursive);
		int i;
		String srcDir = FileHelper.getDirectory(srcFilename);
		byte[] buf = new byte[1000];
		for (i=0; i<fileList.count; i++) {
			File srcFile = (File) fileList.getItem(i);
			String srcFilePath = srcFile.getAbsolutePath(); 
			String remainder = srcFilePath.substring(srcDir.length()+1, srcFilePath.length());
			String dstFilePath = dstFilename + File.separator + remainder;
			if (srcFile.isDirectory()) {
				File dstDir = new File(dstFilePath);
				dstDir.mkdir();
			}
			else {				
				try {
					FileHelper.move(buf, srcFilePath, dstFilePath);
				} catch (IOException e) {
					
					e.printStackTrace();
				}	
			}
			
		}
	}
	
	/**@param srcFilename : directory or file
	 * @param dstFilename : directory
	 * @param isRecursive : asks if including inner directory or files
	 */
	public static void copyFilesIfNotExists(String srcFilename, String dstFilename, boolean isRecursive) {
		ArrayList fileList = FileHelper.getFileList(srcFilename, isRecursive);
		int i;
		String srcDir = FileHelper.getDirectory(srcFilename);
		byte[] buf = new byte[1000];
		for (i=0; i<fileList.count; i++) {
			File srcFile = (File) fileList.getItem(i);
			String srcFilePath = srcFile.getAbsolutePath(); 
			String remainder = srcFilePath.substring(srcDir.length()+1, srcFilePath.length());
			String dstFilePath = dstFilename + File.separator + remainder;
			if (srcFile.isDirectory()) {
				File dstDir = new File(dstFilePath);
				if (dstDir.exists()) continue;
				dstDir.mkdir();
			}
			else {
				File dstFile = new File(dstFilePath);
				if (dstFile.exists()) continue;
				try {
					FileHelper.move(buf, srcFilePath, dstFilePath);
				} catch (IOException e) {
					
					e.printStackTrace();
				}	
			}
			
		}
	}
	
	public static void move(byte[] buf, InputStream input, OutputStream output) 
			throws IOException {			
		
		try {
			do {
				int readed;
				readed = input.read(buf, 0, buf.length);
				if (readed<0) {
						break;
				}
				output.write(buf,0,readed);
				
			}while(true);
			output.flush();
		}catch(IOException e) {
			throw e;
		}
	}
	
	public static void move(byte[] buf, String srcPath, String destPath) 
			throws IOException {			
		
		try {
			FileInputStream inputStream = new FileInputStream(srcPath);
			FileOutputStream outputStream = new FileOutputStream(destPath);
			BufferedInputStream input = new BufferedInputStream(inputStream);
			BufferedOutputStream output = new BufferedOutputStream(outputStream);
			
			FileHelper.move(buf, input, output);
		}catch(IOException e) {
			throw e;
		}
	}
}