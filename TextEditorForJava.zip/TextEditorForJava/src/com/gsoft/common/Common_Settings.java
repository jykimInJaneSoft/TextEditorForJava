package com.gsoft.common;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import android.content.Context;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.Color;
import android.util.Log;

import com.gsoft.common.Sizing.Rectangle;
import com.gsoft.common.R.R;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.util.Decompressor;
import com.gsoft.common.gui.Control;
import com.gsoft.common.gui.SettingsDialog;
import com.gsoft.common.gui.SettingsDialog.Settings;
import com.gsoft.common.gui.ViewEx;
import com.gsoft.common.gui.edittext.Edit;
import com.gsoft.common.util.ArrayListString;

import com.gsoft.common.ColorEx;
import com.gsoft.common.FileHelper;
import com.gsoft.common.CommonGUI;
import com.gsoft.common.IO;

public class Common_Settings {
	/**newObject()를 new 할때 바이트코드에 추가한다. 오브젝트, 배열을 생성할때 추가한다.
	 * MemoryManager를 빌드할 때는 이 속성을 false로 하고 빌드를 해야 한다.
	 * (그렇지 않으면 Object[]를 newObject 할때 StackOverflowException을 일으킨다.)*/
	public static boolean enablesGarbageCollector = false;
	
	/** e.printStackTrace()를 출력하면 true, 그렇지 않으면 false*/
	public static boolean g_printsLog = false;
	
	
	/**ViewEx의 sized()에서 createSettingsDialog(View view)가 호출되어 생성되고 
	 * CommonGUI_SettingsDialog.settingsDialog에 저장된다.*/
	public static SettingsDialog settingsDialog;
	
	
	 /** 현재 시스템이 자바(윈도우즈, 리눅스)이면 "JAVA", 안드로이드(휴대폰)면 "ANDROID"*/
    public static String CurrentSystem = Control.CurrentSystem;
    /** 현재 시스템이 자바(윈도우즈, 리눅스)이다*/
    public static String CurrentSystemIsJava = "JAVA"; 
    /** 현재 시스템이 안드로이드(휴대폰)이다*/
    public static String CurrentSystemIsAndroid = "ANDROID";
    
   
    
	
	/** Button, EditText 등의 isTripleBuffering(static)속성은 여기를 참조한다.
	 * ViewEx의 settings는 여기를 참조한다. 가장 먼저 실행되는 곳이다.*/
	public static Settings settings;
	
	public static int backColor = Color.WHITE;
	public static int textColor = Color.BLACK;
	public static int keywordColor = Color.MAGENTA;
	public static int varUseColor = ColorEx.darkerOrLighter(Color.YELLOW, -80);
	public static int funcUseColor = Color.CYAN;
	public static int memberDeclColor = Color.BLUE;
	public static int commentColor = Color.GREEN;
	public static int docuCommentColor = ColorEx.darkerOrLighter(Color.GREEN, -50);
	public static int errorColor = Color.RED;
	
	
	
	
	 /**프로그램이 실행되어 최초로 RUN을 할때 
     * copyJarExeFromAssetToJDKOrJRE()에서 설정된 후 null이 아니다. 
     * setting 파일에 저장되지 않는다.*/
    public static String pathJavaBin;
    
    
    
    
    public static String curDir = System.getProperty("user.dir");
    
	
	/** /mnt/sdcard/janeSoft 를 말한다.*/
	public static String pathJaneSoft = curDir + File.separator + "janeSoft";
	
	
	/** 디폴트 패스, 안드로이드 라이브러리(SDK)의 path, 즉 /mnt/sdcard/janeSoft/gsoft 를 말한다.
	 * pathAndroid는 어디서이든 (예를들면 SettingsDialog.restoreSettings()) 바뀔 수 있다는 것을 주의한다.*/
	public static String pathAndroid = pathJaneSoft + File.separator + "gsoft";
	
	/** pathAndroid는 어디서이든 (예를들면 SettingsDialog.restoreSettings()) 바뀔 수 있기 때문에
	 * final 로 선언된 pathAndroid 가 필요하다./mnt/sdcard/janeSoft/gsoft
	 */
	//public static final String pathAndroid_Final = pathAndroid;
	
	/** 디폴트 패스, 안드로이드 라이브러리의 path, 즉 /mnt/sdcard/janeSoft/gsoft-files 를 말한다.*/
	public static String pathGSoftFiles = pathJaneSoft + File.separator + "gsoft-files";
	
	
	/** wifi 디렉토리의 path, 즉 /mnt/sdcard/janeSoft/wifi 를 말한다.*/
	public static String pathWifi = pathJaneSoft + File.separator + "wifi";
	
	/** help 디렉토리의 path, 즉 /mnt/sdcard/janeSoft/help 를 말한다.*/
	public static String pathHelpFiles = pathJaneSoft + File.separator + "help";
	
	
	
	/** 프로젝트소스의 path, 즉 /mnt/sdcard/janeSoft/project/ProjectName 를 말한다.*/
	public static String pathProject = null;
	
	/**get Common_Settings.pathProject*/
	public static String get_pathProject() {
		return pathProject;
	}
	
	/**set Common_Settings.pathProject*/
	public static void set_pathProject(String projectLoc) {
		pathProject = projectLoc;
	}
	
	
	
	/** 프로젝트소스의 path, 즉 /mnt/sdcard/janeSoft/project/ProjectName/src 를 말한다.*/
	public static String pathProjectSrc = null;
	
	/** output 디렉토리의 path, 즉 /mnt/sdcard/janeSoft/project/ProjectName/output 를 말한다.*/
	public static String pathOutput = null;
		
	/** /mnt/sdcard/janeSoft/project/ProjectName/temp*/
	public static String pathConsoleInputAndError = null;
	
	/** /mnt/sdcard/janeSoft/project/ProjectName/temp/input, InputStream file 를 말한다.*/
	public static String pathInput = null;
	
	/** /mnt/sdcard/janeSoft/project/ProjectName/doc*/
	public static String pathDoc = null;
	
	/** other_lib 디렉토리의 path, 즉 /mnt/sdcard/janeSoft/project/ProjectName/other_lib 를 말한다.*/
	public static String pathOther_Lib = null;
	
	/** jni 디렉토리의 path, 즉 /mnt/sdcard/jni 를 말한다.*/
	public static final String path_jni = /*curDir + File.separator + "jni"*/ 
			/*"/home/jiyun/Documents/eclipse_workspace/TextEditorForJava/TextEditorForJava/jni"*/
			"/home/TextEditorForJava/TextEditorForJava/jni";
	
	public static String projectName = null;
	
	
	/**외부 라이브러리 jl1.0.1.jar 등의 압축을 해제한 Control.pathOther_Lib/jl1.0.1와 같은 디렉토리들의 full path 리스트*/
	public static ArrayListString listOfOtherLibs = new ArrayListString(1);
	
	/**외부 라이브러리 jl1.0.1.jar 등의  full path 리스트, 대화상자로 등록되고 listOfOtherLibs에 압축이 해제된다.*/
	//public static ArrayListString listOfJarFile = new ArrayListString(1);
	
	
	/** EditRichText에서 삽입된 image 파일들의 패스, 
	 * 윈도우즈에서는 이미지가 삽입될 경우 이미지 다음에 있는 문자들을 잘못 읽는다.(스트림이상)
	 * DownloadedImage 디렉토리의 path, 즉 /mnt/sdcard/janeSoft/DownloadedImage 를 말한다.*/
	public static String DownloadedImageDirPath = curDir + File.separator + "janeSoft" 
			+ File.separator + "DownloadedImage";
	
	public static String pipePath = System.getProperties().getProperty("user.dir") + File.separator + "pipe";

	/**소스파일을 읽거나 수정(InterfaceErrorResolver)하고 빌드(InterfaceErrorResolver)할때 
	 * 같은 패키지내 소스파일들을 읽거나 수정하고 빌드하는지 여부*/
	public static boolean g_findsPackageLibrary;
	/**소스파일을 읽거나 수정(InterfaceErrorResolver)하고 빌드(InterfaceErrorResolver)할때  
	 * 소스파일들을 import *내 소스파일들을 읽거나 수정하고 빌드하는지 여부, <br> 
	 * false이면 CompilerStack.loadImportStar에서 각각의 클래스를 import하라는 error를 낸다.*/
	public static boolean g_loadsImportStarInSource;
	
	/** set Common_Settings.pathProject, Common_Settings.projectName, Common_Settings.pathProjectSrc, 
	 * Common_Settings.pathOutput, Common_Settings.pathJar, Common_Settings.pathOther_Lib, Common_Settings.pathDoc 
	 * with projectPath*/
	public static void setProjectPath(String projectPath) {
		if (projectPath!=null) {
			Common_Settings.pathProject = projectPath;
			Common_Settings.projectName = FileHelper.getFilename(Common_Settings.pathProject);
			
			Common_Settings.pathProjectSrc = Common_Settings.pathProject + File.separator + "src";
			Common_Settings.pathOutput = Common_Settings.pathProject + File.separator + "output";
			Common_Settings.pathConsoleInputAndError = Common_Settings.pathProject + File.separator + "temp";
			Common_Settings.pathOther_Lib = Common_Settings.pathProject + File.separator + "other_lib";
			Common_Settings.pathDoc = Common_Settings.pathProject + File.separator + "doc";
			Common_Settings.pathInput = Common_Settings.pathConsoleInputAndError + File.separator + "input";
			//Common_Settings.path_jni_lib = Common_Settings.pathProject + File.separator + "jni_lib";
		}
		else {
			Common_Settings.pathProject = null;
			Common_Settings.projectName = null;
			
			Common_Settings.pathProjectSrc = null;
			Common_Settings.pathOutput = null;
			Common_Settings.pathConsoleInputAndError = null;
			Common_Settings.pathOther_Lib = null;
			Common_Settings.pathDoc = null;
			Common_Settings.pathInput = null;
			//Common_Settings.path_jni_lib = null;
		}
	}
	
	
	
	/** 프로그램 시작시 맨처음 실행된다.*/
	static {
		
		
		File fileJaneSoft = new File(Common_Settings.pathJaneSoft);
		fileJaneSoft.mkdirs();
		
		//프로그램이 설치되어 처음으로 실행될 때 호출된다.
		
		
		//if (!Common_Settings.backupFilesExists()) {
			Common_Settings.moveFilesToSDCard();
		//}
		
		if (!Common_Settings.backupHelpFilesExists()) {
			Common_Settings.moveHelpFilesToSDCard();
		}
		
		if (!Common_Settings.backupDownloadedImageExists()) {
			Common_Settings.moveDownloadedImagesToSDCard();
		}
		
		if (settings==null) {
			settings = SettingsDialog.restoreSettings();
		}
		
				
		// 디폴트 세팅
		if (settings==null) {
			settings = new Settings();
		}
		
		CompilerHelper.setJavaClassPathAndJavaLibraryPathIfNotExists();
		
		if (settings.EnablesUnzipLibrary) {
			Decompressor.decompressAndroidAndProjectSrc();
		}
		
	}
	
	
	public static void setBackColor(int backColor) {
		if (backColor==Color.WHITE) {
			Common_Settings.backColor = Color.WHITE;
			Common_Settings.textColor = Color.BLACK;
			Common_Settings.keywordColor = Color.MAGENTA;
			Common_Settings.varUseColor = Color.RED;
			Common_Settings.funcUseColor = Color.CYAN;
			Common_Settings.memberDeclColor = Color.BLUE;
			Common_Settings.commentColor = Color.GREEN;
			Common_Settings.docuCommentColor = ColorEx.darkerOrLighter(Color.GREEN, -100);
			Common_Settings.errorColor = Color.RED;
			Edit.selectColor = Color.YELLOW;
			Edit.foundColor = Color.LTGRAY;
		}
		else if (backColor==Color.BLACK) {
			Common_Settings.backColor = Color.BLACK;
			Common_Settings.textColor = Color.WHITE;
			Common_Settings.keywordColor = Color.MAGENTA;
			Common_Settings.varUseColor = Color.RED;
			Common_Settings.funcUseColor = Color.CYAN;
			Common_Settings.memberDeclColor = Color.BLUE;
			Common_Settings.commentColor = Color.GREEN;
			Common_Settings.docuCommentColor = ColorEx.darkerOrLighter(Color.GREEN, -100);
			Common_Settings.errorColor = Color.RED;
			Edit.selectColor = Color.LTGRAY;
			Edit.foundColor = Color.YELLOW;
		}
		else if (backColor==Color.RED) {
			Common_Settings.backColor = Color.RED;
			Common_Settings.textColor = Color.CYAN; // CYAN
			Common_Settings.keywordColor = Color.MAGENTA;
			Common_Settings.varUseColor = Color.WHITE;
			Common_Settings.funcUseColor = Color.BLACK;
			Common_Settings.memberDeclColor = Color.BLUE;
			Common_Settings.commentColor = Color.GREEN;
			Common_Settings.docuCommentColor = ColorEx.darkerOrLighter(Color.GREEN, -100);
			Common_Settings.errorColor = Color.WHITE;
			Edit.selectColor = Color.YELLOW;
			Edit.foundColor = Color.LTGRAY;
		}
		else if (backColor==Color.YELLOW) {
			Common_Settings.backColor = Color.YELLOW;
			Common_Settings.textColor = Color.BLUE;
			Common_Settings.keywordColor = Color.MAGENTA;
			Common_Settings.varUseColor = Color.RED;
			Common_Settings.funcUseColor = Color.CYAN;
			Common_Settings.memberDeclColor = Color.WHITE;
			Common_Settings.commentColor = Color.GREEN;
			Common_Settings.docuCommentColor = ColorEx.darkerOrLighter(Color.GREEN, -100);
			Common_Settings.errorColor = Color.RED;
			Edit.selectColor = Color.BLACK;
			Edit.foundColor = Color.LTGRAY;
		}
		else if (backColor==Color.BLUE) {
			Common_Settings.backColor = Color.BLUE;
			Common_Settings.textColor = Color.GREEN;
			Common_Settings.keywordColor = Color.MAGENTA;
			Common_Settings.varUseColor = Color.RED;
			Common_Settings.funcUseColor = Color.CYAN;
			Common_Settings.memberDeclColor = Color.BLACK;
			Common_Settings.commentColor = Color.WHITE;
			Common_Settings.docuCommentColor = ColorEx.darkerOrLighter(Color.WHITE, -100);
			Common_Settings.errorColor = Color.RED;
			Edit.selectColor = Color.YELLOW;
			Edit.foundColor = Color.LTGRAY;
		}
		else if (backColor==Color.GREEN) {
			Common_Settings.backColor = Color.GREEN;
			Common_Settings.textColor = Color.BLACK;	// MAGENTA
			Common_Settings.keywordColor = Color.MAGENTA;
			Common_Settings.varUseColor = Color.RED;
			Common_Settings.funcUseColor = Color.CYAN;
			Common_Settings.memberDeclColor = Color.BLUE;
			Common_Settings.commentColor = Color.WHITE;
			Common_Settings.docuCommentColor = ColorEx.darkerOrLighter(Color.WHITE, -100);
			Common_Settings.errorColor = Color.RED;
			Edit.selectColor = Color.YELLOW;
			Edit.foundColor = Color.LTGRAY;
		}
		else if (backColor==Color.MAGENTA) {
			Common_Settings.backColor = Color.MAGENTA;
			Common_Settings.textColor = Color.BLACK;	// GREEN
			Common_Settings.keywordColor = Color.GREEN;
			Common_Settings.varUseColor = Color.RED;
			Common_Settings.funcUseColor = Color.CYAN;
			Common_Settings.memberDeclColor = Color.BLUE;
			Common_Settings.commentColor = Color.WHITE;
			Common_Settings.docuCommentColor = ColorEx.darkerOrLighter(Color.WHITE, -100);
			Common_Settings.errorColor = Color.WHITE;
			Edit.selectColor = Color.YELLOW;
			Edit.foundColor = Color.LTGRAY;
		}
		else if (backColor==Color.CYAN) {
			Common_Settings.backColor = Color.CYAN;
			Common_Settings.textColor = Color.BLACK;	// MAGENTA
			Common_Settings.keywordColor = Color.WHITE;
			Common_Settings.varUseColor = Color.RED;
			Common_Settings.funcUseColor = Color.BLUE;
			Common_Settings.memberDeclColor = Color.MAGENTA;
			Common_Settings.commentColor = Color.GREEN;
			Common_Settings.docuCommentColor = ColorEx.darkerOrLighter(Color.GREEN, -100);
			Common_Settings.errorColor = Color.RED;
			Edit.selectColor = Color.YELLOW;
			Edit.foundColor = Color.LTGRAY;
		}
		else if (backColor==Color.LTGRAY) {
			Common_Settings.backColor = Color.LTGRAY;
			Common_Settings.textColor = Color.BLACK;
			Common_Settings.keywordColor = Color.MAGENTA;
			Common_Settings.varUseColor = Color.RED;
			Common_Settings.funcUseColor = Color.CYAN;
			Common_Settings.memberDeclColor = Color.BLUE;
			Common_Settings.commentColor = Color.GREEN;
			Common_Settings.docuCommentColor = ColorEx.darkerOrLighter(Color.GREEN, -100);
			Common_Settings.errorColor = Color.RED;
			Edit.selectColor = Color.YELLOW;
			Edit.foundColor = Color.WHITE;
		}
	}
	
	/**SettingsDialog.buttonShowsCopyRight의 선택상태에 따라 저작권 메시지를 보여준다.*/
	public static void showsCopyRight() {
		if (Common_Settings.settingsDialog.buttonShowsCopyRight.getIsSelected()) {
			String copyRight = Control.res.getString(R.string.copy_right);
			CommonGUI.loggingForMessageBox.setText(true, copyRight, false);
			CommonGUI.loggingForMessageBox.setHides(false);
		}
	}
	
	/**바이트코드와 포스트픽스 메시지와 클래스파일을 보여줄 수 있는지를 결정한다.*/
	public static boolean showsByteCodes() {
		/*File passwordFile = new File(Common_Settings.pathGSoftFiles+File.separator+"password_kjy.txt");
		if (passwordFile.exists()) return true;
		return false;*/
		return true;
	}
	
	
	
	/** 종료시 finish()를 호출했으면 1을 저장하고,
	 *  아니면 0을 backup_IsFinishingWhenExitingPrevly에 저장한다.
	 *  그리고 마우스로 윈도우 크기를 바꿀때 그 좌표와 크기를 저장하기 위해 사용한다.*/
	public static void backupIsFinishingWhenExitingPrevly() {
		FileOutputStream stream=null;
		boolean r = false;
		String absFilename=null;
		try {
			absFilename = pathGSoftFiles + File.separator + "backup_IsFinishingWhenExitingPrevly";
			stream = new FileOutputStream(absFilename);
			int v = Control.activity.isFinishing() ? 1 : 0;
			IO.writeInt(stream, v, true);			
			/*if (Common_Settings.CurrentSystem.equals(Common_Settings.CurrentSystemIsJava)) {
				ViewEx view = Control.viewEx;
				IO.writeInt(stream, view.x, true);
				IO.writeInt(stream, view.y, true);
				IO.writeInt(stream, view.width, true);
				IO.writeInt(stream, view.height, true);
			}*/
			r = true;
		} catch (FileNotFoundException e) {
			r= false;
		}
		catch (Exception e) {
			r = false;
		}
		finally {
			FileHelper.close(stream);
			if (!r) {
				if (absFilename!=null) {
					File file = new File(absFilename);
					file.delete();
				}
			}
		}
	}
	
	/** 이전에 종료시 finish()를 호출했으면 1을 로드하고,
	 *  아니면 0을 로드한다. backup_IsFinishingWhenExitingPrevly에서 로드한다.
	 *  그리고 마우스로 윈도우 크기를 바꿀때 그 좌표와 크기를 저장하기 위해 사용한다.*/
	public static int restoreIsFinishingWhenExitingPrevly() {
		FileInputStream stream=null;
		String absFilename=null;
		boolean r = false;
		try {
			//File contextDir = context.getFilesDir();
			absFilename = pathGSoftFiles + File.separator + "backup_IsFinishingWhenExitingPrevly";
			stream = new FileInputStream(absFilename);
			int isFinishingWhenExitingPrevly = IO.readInt(stream, true);
			/*if (Common_Settings.CurrentSystem.equals(Common_Settings.CurrentSystemIsJava)) {
				int x = IO.readInt(stream, true);
				Common_Settings.settings.viewX = x;
				int y = IO.readInt(stream, true);
				Common_Settings.settings.viewY = y;
				int width = IO.readInt(stream, true);
				if (width!=0) {
					Common_Settings.settings.viewWidth = width;
				}
				int height = IO.readInt(stream, true);
				if (height!=0) {
					Common_Settings.settings.viewHeight = height;
				}
			}*/
			return isFinishingWhenExitingPrevly;
		} 
		catch (Exception e) {
			//settings = new Settings();
			return -1;
		}
		finally {
			FileHelper.close(stream);
			if (!r) {
				if (absFilename!=null) {
					//File file = new File(absFilename);
					//file.delete();
				}
			}
		}
	}
	
	/*void moveAssetEtcFilesToEtc() {
		Context context = getContext();
		Resources r = context.getResources();
		AssetManager asset = r.getAssets();
		
		String[] list=null;
		try {
			list = asset.list("etc");
		} catch (IOException e) {
			
			Log.e("moveEtcFilesToSystem", e.toString());
		}
		int i;
		InputStream inputStream=null;
		FileOutputStream outputStream=null;
		BufferedOutputStream os=null;
		File etcDir = new File("/system/etc");
		
		for (i=0; i<list.length; i++) {
			try {				
				String absFilename = etcDir.getAbsolutePath() + File.separator + list[i];
				File file = new File(absFilename);
				if (file.exists()) continue;
				inputStream = asset.open("etc/"+list[i]);
				//outputStream = context.openFileOutput(list[i], Context.MODE_PRIVATE);
				outputStream = new FileOutputStream(file);
				//os = new BufferedOutputStream(outputStream, fileLen);
				
				FileHelper.move(inputStream, os);
				
		
			} catch (Exception e) {
				
				e.printStackTrace();
			}
			finally {
				FileHelper.close(inputStream);
				FileHelper.close(outputStream);
				FileHelper.close(os);
				inputStream=null;
				outputStream=null;
				os=null;
			}
		}
	}*/
	
	
	void moveFiles(String directoryName, File outputFile) {
		Context context = Control.activity.getApplicationContext();
		Resources r = context.getResources();
		AssetManager asset = r.getAssets();
		
		String relativePath;
		int indexIndirectoryName = new String("files").length()+1;
		relativePath = directoryName.substring(indexIndirectoryName, directoryName.length());
		String[] list=null;
		try {
			list = asset.list(directoryName);
		} catch (IOException e) {
			
			Log.e("moveImagesToAppPackage", e.toString());
		}
		int i;
		InputStream inputStream=null;
		FileOutputStream outputStream=null;
		BufferedOutputStream os=null;
	
		byte[] buf = new byte[1000];
		
		for (i=0; i<list.length; i++) {
			try {				
				String absFilename = outputFile.getAbsolutePath() + File.separator + 
						relativePath + File.separator + list[i];
				File file = new File(absFilename);
				
				if (file.isDirectory()) {
					file.mkdir();
					this.moveFiles("files"+File.separator+relativePath + File.separator + list[i], file);
					continue;
				}
				if (file.exists()) continue;
				
				inputStream = asset.open(directoryName+File.separator+list[i]);
				
				outputStream = new FileOutputStream(file);
				
				FileHelper.move(buf, inputStream, outputStream);				
				
			} catch (Exception e) {
				
				e.printStackTrace();
			}
			finally {
				FileHelper.close(inputStream);
				FileHelper.close(outputStream);
				FileHelper.close(os);
				inputStream=null;
				outputStream=null;
				os=null;
			}
		}
	}
	
	void moveFilesToContextAppPackage() {
		Context context = Control.view.getContext();
		Resources r = context.getResources();
		AssetManager asset = r.getAssets();
		
		String[] list=null;
		try {
			list = asset.list("files");
		} catch (IOException e) {
			
			Log.e("moveImagesToAppPackage", e.toString());
		}
		int i;
		InputStream inputStream=null;
		FileOutputStream outputStream=null;
		BufferedOutputStream os=null;
		File contextDir = context.getFilesDir();
	
		byte[] buf = new byte[1000];
		
		for (i=0; i<list.length; i++) {
			try {				
				String absFilename = contextDir.getAbsolutePath() + File.separator + list[i];
				File file = new File(absFilename);
				
				if (file.isDirectory()) {
					file.mkdir();
					this.moveFiles("files"+File.separator+list[i], contextDir);
					continue;
				}
				if (file.exists()) continue;
				
				inputStream = asset.open("files"+File.separator+list[i]);
				
				outputStream = new FileOutputStream(file);
				
				FileHelper.move(buf, inputStream, outputStream);				
				
			} catch (Exception e) {
				
				e.printStackTrace();
			}
			finally {
				FileHelper.close(inputStream);
				FileHelper.close(outputStream);
				FileHelper.close(os);
				inputStream=null;
				outputStream=null;
				os=null;
			}
		}
		
	}
	
	/**Control.pathGSoftFiles에 backup_settings, backup_EditRichText.kjy, backup_EditText.txt,
	 * backup_playlist.txt, backup_text.kjy 등의 파일이 있는지 확인한다.
	 * @return
	 */
	public static boolean backupFilesExists() {
		
		File sdCardDir = new File(pathGSoftFiles);
		String[] fileList = sdCardDir.list();
		if (fileList!=null && fileList.length==56) return true;
		else return false;
	}
	
	/** Control.pathHelpFiles에 "ListenToMusic.kjy" 파일이 있는지 확인한다.*/
	public static boolean backupHelpFilesExists() {
		/*File sdCardDir = new File(Control.pathHelpFiles+File.separator+"ListenToMusic.kjy");
		if (sdCardDir.exists()) return true;
		else return false;*/
		
		File sdCardDir = new File(pathHelpFiles);
		String[] fileList = sdCardDir.list();
		if (fileList!=null && fileList.length==4) return true;
		else return false;
		
	}
	
	/** Control.DownloadedImageDirPath 에 "Func.jpg" 파일이 있는지 확인한다.*/
	public static boolean backupDownloadedImageExists() {
		/*File sdCardDir = new File(Control.DownloadedImageDirPath+File.separator+"Func.jpg");
		if (sdCardDir.exists()) return true;
		else return false;*/
		
		File sdCardDir = new File(DownloadedImageDirPath);
		String[] fileList = sdCardDir.list();
		if (fileList!=null && fileList.length==24) return true;
		else return false;
		
	}
	
	
	/** asset 에 있는 files 들을 /mnt/sdcard/gsoft-files 로 복사한다.*/
	public static void moveFilesToSDCard() {
		Context context = Control.activity.getApplicationContext();
		Resources r = context.getResources();
		AssetManager asset = r.getAssets();
		
		String[] list=null;
		try {
			list = asset.list("files");
		} catch (IOException e) {
			
			Log.e("moveImagesToAppPackage", e.toString());
		}
		if (list==null) return;
		int i;
		InputStream inputStream=null;
		FileOutputStream outputStream=null;
		BufferedOutputStream os=null;
		File sdCardDir = new File(pathGSoftFiles);
		if (!sdCardDir.exists()) {
			sdCardDir.mkdirs();
		}
		
		File filesDir = context.getFilesDir();
		String pathFilesDir = filesDir.getAbsolutePath();
		
		byte[] buf = new byte[1000];
		
		for (i=0; i<list.length; i++) {
			try {
				String absFilename = sdCardDir.getAbsolutePath() + File.separator + list[i];
				File outputFile = new File(absFilename);				
				
				File assetFile = new File(pathFilesDir+File.separator+list[i]);
				if (outputFile.exists()) {				
					long modifiedTimeOfAssetFile = assetFile.lastModified();
					long modifiedTimeOfOutputFile = outputFile.lastModified();
					// asset/files/backup_settings와 기존 backup_settings을 비교하여
					// 카피 여부를 결정한다.
					if (modifiedTimeOfAssetFile < modifiedTimeOfOutputFile) continue;
				}
				
				inputStream = asset.open("files"+File.separator+list[i]);
								
				outputStream = new FileOutputStream(outputFile);
				
				FileHelper.move(buf, inputStream, outputStream);				
				
			} catch (Exception e) {
				
				e.printStackTrace();
			}
			finally {
				FileHelper.close(inputStream);
				FileHelper.close(outputStream);
				FileHelper.close(os);
				inputStream=null;
				outputStream=null;
				os=null;
			}
		}//for
		
	}
	
	
	/** asset 에 있는 help_files 들을 /mnt/sdcard/janeSoft/help_files 로 복사한다.*/
	public static void moveHelpFilesToSDCard() {
		Context context = Control.activity.getApplicationContext();
		Resources r = context.getResources();
		AssetManager asset = r.getAssets();
		
		String[] list=null;
		try {
			list = asset.list("help_files");
		} catch (IOException e) {
			
			Log.e("moveHelpFilesToSDCard", e.toString());
		}
		if (list==null) return;
		int i;
		InputStream inputStream=null;
		FileOutputStream outputStream=null;
		BufferedOutputStream os=null;
		File sdCardDir = new File(pathHelpFiles);
		if (!sdCardDir.exists()) {
			sdCardDir.mkdirs();
		}
		
		byte[] buf = new byte[1000];
		
		for (i=0; i<list.length; i++) {
			try {
				String absFilename = sdCardDir.getAbsolutePath() + File.separator + list[i];
				File file = new File(absFilename);				
				
				if (file.exists()) continue;
				
				inputStream = asset.open("help_files"+File.separator+list[i]);
				
				file.createNewFile();
				outputStream = new FileOutputStream(file);
				
				FileHelper.move(buf, inputStream, outputStream);				
				
			} catch (Exception e) {
				
				e.printStackTrace();
			}
			finally {
				FileHelper.close(inputStream);
				FileHelper.close(outputStream);
				FileHelper.close(os);
				inputStream=null;
				outputStream=null;
				os=null;
			}
		}//for
		
	}
	
	
	/** asset 에 있는 DownloadedImage 들을 /mnt/sdcard/janeSoft/DownloadedImage 로 복사한다.*/
	public static void moveDownloadedImagesToSDCard() {
		Context context = Control.activity.getApplicationContext();
		Resources r = context.getResources();
		AssetManager asset = r.getAssets();
		
		String[] list=null;
		try {
			list = asset.list("DownloadedImage");
		} catch (IOException e) {
			
			Log.e("moveDownloadedImagesToSDCard", e.toString());
		}
		if (list==null) return;
		int i;
		InputStream inputStream=null;
		FileOutputStream outputStream=null;
		BufferedOutputStream os=null;
		File sdCardDir = new File(DownloadedImageDirPath);
		if (!sdCardDir.exists()) {
			sdCardDir.mkdirs();
		}
		
		byte[] buf = new byte[1000];
		
		for (i=0; i<list.length; i++) {
			try {
				String absFilename = sdCardDir.getAbsolutePath() + File.separator + list[i];
				File file = new File(absFilename);				
				
				if (file.exists()) continue;
				
				inputStream = asset.open("DownloadedImage"+File.separator+list[i]);
				
				file.createNewFile();
				outputStream = new FileOutputStream(file);
				
				FileHelper.move(buf, inputStream, outputStream);				
				
			} catch (Exception e) {
				
				e.printStackTrace();
			}
			finally {
				FileHelper.close(inputStream);
				FileHelper.close(outputStream);
				FileHelper.close(os);
				inputStream=null;
				outputStream=null;
				os=null;
			}
		}//for
		
	}
	
	/** 최대창일 때 이전 뷰 사이즈를 저장한다.*/
	public static void backupPrevViewSize() {
		ViewEx view = Control.viewEx;
		view.prevX = view.x;
		view.prevY = view.y;
		view.prevWidth = view.width;
		view.prevHeight = view.height;
	}
	
	/** 최대창일 때 이전 뷰 사이즈를 저장한다.*/
	public static void backupPrevViewSizeToFile() {
		FileOutputStream outputStream = null;
		BufferedOutputStream output = null;
		String filename = pathGSoftFiles + File.separator + "backupPrevViewSize";
		
		try {
			outputStream = new FileOutputStream(filename);
			output = new BufferedOutputStream(outputStream);
			ViewEx view = Control.viewEx;
			IO.writeInt(output, view.x, true);
			IO.writeInt(output, view.y, true);
			IO.writeInt(output, view.width, true);
			IO.writeInt(output, view.height, true);
			output.flush();
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}catch (Exception e) {
			e.printStackTrace();			
		} finally {
			if (output!=null) {
				try {
					output.close();
				} catch (IOException e1) {
					
					e1.printStackTrace();
				}
			}
			if (outputStream!=null) {
				try {
					outputStream.close();
				} catch (IOException e1) {
					
					e1.printStackTrace();
				}
			}
		}
	}
	
	/** 최대창에서 이전 뷰 사이즈로 복구할 때 호출한다.*/
	public static Rectangle restorePrevViewSize() {
		/*ViewEx view = Control.viewEx;
		view.width = view.prevWidth;
		view.prevHeight = view.prevHeight;*/
		ViewEx view = Control.viewEx;
		return new Rectangle(view.prevX, view.prevY, view.prevWidth, view.prevHeight);
	}
	
	/** 최대창에서 이전 뷰 사이즈로 복구할 때 호출한다.*/
	public static Rectangle restorePrevViewSizeFromFile() {
		FileInputStream inputStream = null;
		BufferedInputStream input = null;
		String filename = pathGSoftFiles + File.separator + "backupPrevViewSize";
		
		try {
			inputStream = new FileInputStream(filename);
			input = new BufferedInputStream(inputStream);
			int x = IO.readInt(input, true);
			int y = IO.readInt(input, true);
			int w = IO.readInt(input, true);
			int h = IO.readInt(input, true);
			return new Rectangle(x, y, w, h);
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}catch (Exception e) {
			e.printStackTrace();			
		} finally {
			if (input!=null) {
				try {
					input.close();
				} catch (IOException e1) {
					
					e1.printStackTrace();
				}
			}
			if (inputStream!=null) {
				try {
					inputStream.close();
				} catch (IOException e1) {
					
					e1.printStackTrace();
				}
			}
		}
		return null;
	}
	
	boolean isFileExistInContextAppPackage(String path) {
		return false;
	}
	
	boolean isAndroidLibExistInContextAppPackage() {
		File contextDir = Control.view.getContext().getFilesDir();
		String absFilename = contextDir.getAbsolutePath() + File.separator + "android.jar";
		File file = new File(absFilename);
		if (file.exists()) return true;
		return false;
	}
	
	/*void extractAndroidJar() {
		File contextDir = Control.view.getContext().getFilesDir();
		String jarPath = contextDir.getAbsolutePath() + File.separator + "android.jar";
		
		try {
			JarFile jarFile = new JarFile(jarPath, false);
			Enumeration<JarEntry> e = jarFile.entries();
			while (e.hasMoreElements()) {
				JarEntry entry = e.nextElement();
				String name = entry.getName();
			}
			jarFile.close();
			
		} catch (IOException e) {
			
			e.printStackTrace();
		} 
		
	}*/
	
	void moveAndroidLibraryToContextAppPackage() {
		//if (isAndroidLibExistInContextAppPackage()) return;
		
		Context context = Control.view.getContext();
		Resources r = context.getResources();
		AssetManager asset = r.getAssets();
		
		String[] list=null;
		try {
			list = asset.list("lib");
		} catch (IOException e) {
			
			Log.e("moveAndroidLibraryToContextAppPackage", e.toString());
		}
		int i;
		InputStream inputStream=null;
		FileOutputStream outputStream=null;
		BufferedOutputStream os=null;
		File contextDir = Control.view.getContext().getFilesDir();
		
		byte[] buf = new byte[1000];
		
		for (i=0; i<list.length; i++) {
			try {				
				String absFilename = contextDir.getAbsolutePath() + File.separator + list[i];
				//String absFilename = Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + list[i];
				File file = new File(absFilename);
				//if (file.exists()) continue;
				
				inputStream = asset.open("lib"+File.separator+list[i]);
				outputStream = new FileOutputStream(file);
				
				FileHelper.move(buf, inputStream, outputStream);
				
				
			} catch (Exception e) {
				
				e.printStackTrace();
			}
			finally {
				FileHelper.close(inputStream);
				FileHelper.close(outputStream);
				FileHelper.close(os);
				inputStream=null;
				outputStream=null;
				os=null;
			}
		}
		
	}
}