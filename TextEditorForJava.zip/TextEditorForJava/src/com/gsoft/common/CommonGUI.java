package com.gsoft.common;

import com.gsoft.common.compiler.EditText_Compiler;
import com.gsoft.common.compiler.debug.DebugView;
import com.gsoft.common.compiler.gui.InputTextView;
import com.gsoft.common.gui.ColorDialog;
import com.gsoft.common.gui.Control;
import com.gsoft.common.gui.FileDialog;
import com.gsoft.common.gui.IntegrationKeyboard;
import com.gsoft.common.gui.LoggingScrollable;
import com.gsoft.common.gui.SettingsDialog;
import com.gsoft.common.gui.TextView;

public class CommonGUI {
	
	public static FileDialog fileDialog;
	
	public static ColorDialog colorDialog;
	
	public static SettingsDialog settingsDialog;
	
	public static EditText_Compiler editText_compiler;
	
	
	public static IntegrationKeyboard keyboard;
	
	
	/**logBird창*/
	public static TextView textViewLogBird;
	/**Console창*/
	public static TextView textViewConsole;
	/**Debug창*/
	public static DebugView textViewDebug;
	/**Input창, InputStream*/
	public static InputTextView textViewInput;
	
	public static LoggingScrollable loggingForMessageBox;
	
	//public static LoggingScrollable loggingForNetwork;
	
	
	
	static public void showMessage(boolean replaceOrAdd, String message) {
		if (CommonGUI.loggingForMessageBox!=null) {
			CommonGUI.loggingForMessageBox.setText(replaceOrAdd, message, false);
			CommonGUI.loggingForMessageBox.setHides(false);
			
			Control.view.postInvalidate();
		}
	}
}