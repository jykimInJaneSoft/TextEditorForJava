package com.gsoft.common;

import com.gsoft.common.util.HighArray_char;

public class IO_types {
	public static enum TextFormat {
		UTF_8,
		UTF_16,
		MS949_Korean
	}
	
	public static class ReturnOfReadString {
		public HighArray_char result;
		public TextFormat textFormat;
		ReturnOfReadString(HighArray_char result, TextFormat textFormat) {
			this.result = result;
			this.textFormat = textFormat;
		}
		
		public void destroy() {
			if (result!=null) {
				result.destroy();
				result = null;
			}
			textFormat = null;
		}
	}
}
