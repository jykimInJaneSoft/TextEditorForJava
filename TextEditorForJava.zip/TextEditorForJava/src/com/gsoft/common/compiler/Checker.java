package com.gsoft.common.compiler;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.Code.CodeStringType;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.FileHelper;
import com.gsoft.common.compiler.CompilerStack.ReturnOfFindAccessModifier;
import com.gsoft.common.compiler.Compiler_types.CategoryOfBlock;
import com.gsoft.common.compiler.Compiler_types.CategoryOfControls;
import com.gsoft.common.compiler.Compiler_types.FindAssignStatementParams;
import com.gsoft.common.compiler.Compiler_types.FindBlockParams;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.Compiler_types.FindControlBlockParams;
import com.gsoft.common.compiler.Compiler_types.FindFuncCallParam;
import com.gsoft.common.compiler.Compiler_types.FindFunctionParams;
import com.gsoft.common.compiler.Compiler_types.FindVarParams;
import com.gsoft.common.compiler.Compiler_types.FindVarUseParams;
import com.gsoft.common.compiler.Compiler_types.Language;
import com.gsoft.common.compiler.Compiler_types.ModeAllOrUpdate;
import com.gsoft.common.compiler.Compiler_types_Base.Block;
import com.gsoft.common.compiler.Compiler_types_Base.DocuComment;
import com.gsoft.common.compiler.Compiler_types_Base.Error;
import com.gsoft.common.compiler.Compiler_types_Base.FindStatementParams;
import com.gsoft.common.compiler.Compiler_types_Base.ReturnOfIsType;
import com.gsoft.common.compiler.Compiler_types_Special.Constructor;
import com.gsoft.common.compiler.Compiler_types_Special.FindLargeBlockParams;
import com.gsoft.common.compiler.Compiler_types_Special.FindSmallBlockParams;
import com.gsoft.common.compiler.Compiler_types_Special.FindSpecialBlockParams;
import com.gsoft.common.compiler.Compiler_types_Special.FindSpecialStatementParams;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListChar;
import com.gsoft.common.util.ArrayListIReset;
import com.gsoft.common.util.ArrayListString;
import com.gsoft.common.util.HighArray;
import com.gsoft.common.util.Stack;

import com.gsoft.common.compiler.CompilerStatic;
import com.gsoft.common.compiler.IndexForHighArray;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.HighArray_CodeString;
import com.gsoft.common.compiler.Fullname;
import com.gsoft.common.compiler.CodeStringEx;
import com.gsoft.common.compiler.TypeCast_Syntax;
import com.gsoft.common.compiler.CompilerData;
import com.gsoft.common.compiler.Compiler;

@SuppressWarnings("unused")
public class Checker {
	/** '{', '}' 괄호 에러를 체크한다.*/
	public static void checkParenthesis(Compiler compiler) {
		int i;
		ArrayListIReset listOfBlocks = compiler.data.mlistOfBlocks; 
		for (i=0; i<listOfBlocks.count; i++) {
			FindBlockParams block = (FindBlockParams) listOfBlocks.getItem(i);
			if (block.parent instanceof FindFunctionParams) {
				FindFunctionParams func = (FindFunctionParams) block.parent;
				if (func.isAbstractMethod) continue;
			}
			if (block.startIndex()==-1 || block.endIndex()==-1) {
				if (block.startIndex()!=-1) {
					CompilerStatic.errors.add(new Error(compiler, block.startIndex(), block.startIndex(), "'}' of "+block.blockName+" not exists"));
				}
				else if (block.endIndex()!=-1) {
					CompilerStatic.errors.add(new Error(compiler, block.endIndex(), block.endIndex(), "'{' of "+block.blockName+" not exists"));
				}
				compiler.PairErrorExists = true;
				break;
			}
			
		}
	}
	
	
	
	/**startIndex, endIndex 모두 포함*/
	public static void changeKeywordAndConstantColorAndTextColor(Compiler compiler, HighArray_CodeString src, 
			boolean allOrPart, int startIndex, int endIndex) {
		int i;
		if (compiler.data.language!=Language.Html) {
			for (i=startIndex; i<=endIndex; i++) {
				CodeString str = src.getItem(i);
				if (CompilerHelper.IsDocuComment(str)) {
					str.setColor(Common_Settings.docuCommentColor);
					str.setType(CodeStringType.DocuComment);
				}
				else if (CompilerHelper.IsComment(str)) {
					str.setColor(Common_Settings.commentColor);
					str.setType(CodeStringType.Comment);
				}
				else if (CompilerHelper.IsKeyword(str, compiler) || CompilerHelper.IsDefaultType(str, compiler)) {
					str.setColor(Common_Settings.keywordColor);
					str.setType(CodeStringType.Keyword);
				}
				else if (CompilerHelper.IsConstant(str)) {
					str.setColor(Common_Settings.keywordColor);
					str.setType(CodeStringType.Constant);
				}
				else {
					str.setColor(Common_Settings.textColor);
					str.setType(CodeStringType.Text);
				}
			}
		}
		else {	// html
			for (i=0; i<src.count; i++) {
				CodeString str = src.getItem(i);
				if (CompilerHelper.IsComment(str)) {
					str.setColor(Common_Settings.commentColor);
					str.setType(CodeStringType.Comment);
				}
				else if (CompilerHelper.IsKeyword(str, compiler) || CompilerHelper.IsDefaultType(str, compiler)) {
					int leftParent = CompilerHelper.SkipBlank(src, true, 0, i-1);
					if (leftParent==-1) continue;
					CodeString left = src.getItem(leftParent); 
					if (!(left.equals("<") || left.equals("/"))) continue;
					
					int rightParent = CompilerHelper.SkipBlank(src, false, i+1, src.count-1);
					if (rightParent==src.count) continue;
					//CodeString right = src.getItem(rightParent); 
					//if (right.equals(">")==false) continue;
					
					str.setColor(Common_Settings.keywordColor);
					str.setType(CodeStringType.Keyword);
				}
			}
		}
	}
	
	/** @param listOfClass : 최상위 클래스 리스트
	 * @param endIndex 
	 * @param startIndex 
	 * @param allOrPart */
	public static void changeVarUseColor(HighArray_CodeString src, ArrayListIReset listOfClass, 
			boolean allOrPart, int startIndex, int endIndex) {
		
		int i;
		if (allOrPart) {
			for (i=0; i<listOfClass.count; i++) {
				FindClassParams classParams = (FindClassParams)listOfClass.getItem(i);
				changeVarUseColor_sub(src, classParams, allOrPart, startIndex, endIndex);
			}
		}
		else {
			for (i=0; i<listOfClass.count; i++) {
				FindClassParams classParams = (FindClassParams)listOfClass.getItem(i);
				if (!(classParams.startIndex()<=startIndex && endIndex<=classParams.endIndex())) continue;
				changeVarUseColor_sub(src, classParams, allOrPart, startIndex, endIndex);
			}
		}
	}
	
	/** 파일에서 사용된 모든 varUse 색깔을 바꾼다. 또한 자식(inner)클래스도 포함한다.
	 * @param classParams : 최상위 클래스*/
	public static void changeVarUseColor_sub(HighArray_CodeString src, FindClassParams classParams,
			boolean allOrPart, int startIndex, int endIndex) {
		int i;
		if (classParams.listOfAllVarUses!=null) {
			int len = classParams.listOfAllVarUses.getCount();
			for (i=0; i<len; i++) {
				FindVarUseParams varUse = (FindVarUseParams)classParams.listOfAllVarUses.getItem(i);
				if (!(startIndex<=varUse.index() && varUse.index()<=endIndex)) continue;
				if (varUse.varDecl!=null) { // 멤버변수의 사용만 색깔을 바꾼다.
					if (!varUse.isLocal) {
						src.getItem(varUse.index()).setColor(Common_Settings.varUseColor);
						src.getItem(varUse.index()).setType(CodeStringType.MemberVarUse);
					}
					else {
						src.getItem(varUse.index()).setColor(Common_Settings.textColor);
						src.getItem(varUse.index()).setType(CodeStringType.Text);
					}
				}
				else if (varUse.memberDecl!=null) {
					src.getItem(varUse.index()).setColor(Common_Settings.varUseColor);
					src.getItem(varUse.index()).setType(CodeStringType.MemberVarUse);
				}
				else if (varUse.funcDecl!=null) { // 함수호출
					src.getItem(varUse.index()).setColor(Common_Settings.funcUseColor);
					src.getItem(varUse.index()).setType(CodeStringType.FuncUse);
				}
			}
		}
		
		if (classParams.childClasses!=null) {
			for (i=0; i<classParams.childClasses.count; i++) {
				FindClassParams child = (FindClassParams) classParams.childClasses.getItem(i);
				changeVarUseColor_sub(src, child, allOrPart, startIndex, endIndex);
			}
			
		}
	}
	
	
	
	public static void checkVarUse(Compiler compiler, HighArray_CodeString src, 
			boolean allOrPart, int startIndex, int endIndex) {
		int i;
		FindVarUseParams varUse=null;
		
		HighArray mlistOfAllVarUses = compiler.data.mlistOfAllVarUses;
		int len = mlistOfAllVarUses.getCount();
		
		for (i=0; i<len; i++) {
			varUse = (FindVarUseParams)mlistOfAllVarUses.getItem(i);
			if (varUse.index()==2236) {
				int a;
				a=0;
				a++;
			}
			if (!(startIndex<=varUse.index() && varUse.index()<=endIndex)) continue;
			
			if ( CompilerHelper.IsConstant( src.getItem(varUse.index()) ) ) continue;
			
			if (!CheckVarNameOrVarUseName(compiler, varUse.originName)) {
				CompilerStatic.errors.add(new Error(compiler, varUse.index(), varUse.index(), 
						"invalid var use name : " + src.getItem(varUse.index())));
			}
			if (varUse.varDecl==null && varUse.funcDecl==null && varUse.memberDecl==null) {
				if (varUse.isEnumElement) continue; // varUse가 enum 원소일 경우에도 제외한다.
				//if (varUse.typeCast!=null) continue; // varUse가 타입캐스트일 경우에도 제외한다.(int)a에서 int
				if (CompilerHelper.IsDefaultType(varUse.originName, compiler)) continue; // int, char 등일 경우
				
				CodeString str = compiler.data.mBuffer.getItem(varUse.index());
				str.setType(CodeStringType.Text);
				str.setColor(Common_Settings.textColor);
				if (varUse.index()==179) {
					int a;
					a=0;
					a++;
				}
				CompilerStatic.errors.add(new Error(compiler, varUse.index(), varUse.index(), 
						"invalid var use : " + src.getItem(varUse.index())));
			}
		}
	}
	
	/**@param compiler : compiler to be checked*/
	public static void checkThrowReturnContinueAndBreak(Compiler compiler, int coreThreadID) {
		int i;
		CompilerData data = compiler.data;
		for (i=0; i<data.mlistOfSpecialStatement.count; i++) {
			FindSpecialStatementParams statement = (FindSpecialStatementParams) data.mlistOfSpecialStatement.getItem(i);
			String keyword = data.mBuffer.getItem(statement.kewordIndex()).str;			
			
			if (keyword.equals("return")) {
				if (statement.funcCall!=null) {
					CodeStringEx typeFullName = statement.funcCall.typeFullName;
					int startIndex = statement.funcCall.startIndex();
					int endIndex = statement.funcCall.endIndex();
					FindFunctionParams func = (FindFunctionParams) CompilerStatic.getParent(statement.parent);
					if (typeFullName==null) {
						if (func.isConstructor || func.returnType==null || func.returnType.equals("") || func.returnType.equals("void")) {						
						}
						else {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid return : "+ "func return type("+func.returnType+"), return type("+typeFullName+")"));
						}
					}
					else {
						if (func.isConstructor || func.returnType==null || func.returnType.equals("") || func.returnType.equals("void")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid return : "+ "func return type("+func.returnType+"), return type("+typeFullName.str+")"));
						}
						else if (typeFullName.str!=null) {
							if (!typeFullName.str.equals(func.returnType)) {
								if (!TypeCast_Syntax.isCompatibleType(compiler, compiler, 
										new CodeStringEx(func.returnType), new CodeStringEx(typeFullName.str), 1, null, coreThreadID)) {
									CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid return : "+ "func return type("+func.returnType+"), return type("+typeFullName.str+")"));
								}
							}
						}
					}
				}// if (statement.funcCall!=null) {
				else {
					FindFunctionParams func = (FindFunctionParams) CompilerStatic.getParent(statement.parent);
					if (func.isConstructor || func.returnType==null || func.returnType.equals("") || func.returnType.equals("void")) {						
					}
					else {
						// If func.returnType is not void,
						CompilerStatic.errors.add(new Error(compiler, statement.startIndex(), statement.endIndex(), "invalid return : "+ "func return type("+func.returnType+"), return type("+"void"+")"));
					}
				}
			}// if (keyword.equals("return")) {
			else if (keyword.equals("continue") || keyword.equals("break")) {
				FindControlBlockParams controlBlock = 
						(FindControlBlockParams) CompilerStatic.getParentIterationBlock(statement.parent);
				if (controlBlock==null) {
					CompilerStatic.errors.add(new Error(compiler, statement.startIndex(), statement.endIndex(), "invalid continue or break : doesn't have a control block"));
				}
			}// else if (keyword.equals("continue") || keyword.equals("break")) {
		}// for (i=0; i<data.mlistOfSpecialStatement.count; i++) {
	}
	
	/** 지역변수가 초기화되지 않았으면 에러를 출력한다. 지역변수에 access modifier(public, private등)이 있는지 확인한다.
	 * @param endIndex 
	 * @param startIndex 
	 * @param allOrPart */
	public static  void checkLocalVar(Compiler compiler, HighArray_CodeString src,
			ArrayListIReset listOfAllFunctions, boolean allOrPart, FindFunctionParams funcForPart) {		
		
		int i, j;
		boolean showError;
		if (allOrPart) {
			for (i=0; i<listOfAllFunctions.count; i++) {			
				FindFunctionParams func = (FindFunctionParams)listOfAllFunctions.getItem(i);
				ArrayListIReset listOfLocalVars = func.listOfVariableParams;
							
				for (j=0; j<listOfLocalVars.count; j++) {
					FindVarParams localVar = (FindVarParams)listOfLocalVars.getItem(j);
					showError = hasAccessModifierExceptFinal(localVar, null); 
					if (showError) {
						CompilerStatic.errors.add(new Error(compiler, func.functionNameIndex(), func.functionNameIndex(), 
								"invalid access modifier"));
					}
				} // for j	
			}
		}
		else {
			FindFunctionParams func = funcForPart;
			ArrayListIReset listOfLocalVars = func.listOfVariableParams;
						
			for (j=0; j<listOfLocalVars.count; j++) {
				FindVarParams localVar = (FindVarParams)listOfLocalVars.getItem(j);
				showError = hasAccessModifierExceptFinal(localVar, null); 
				if (showError) {
					CompilerStatic.errors.add(new Error(compiler, func.functionNameIndex(), func.functionNameIndex(), 
							"invalid access modifier"));
				}
			} // for j
		}
	}

	
	static boolean hasAccessModifierExceptFinal(FindVarParams var, FindFunctionParams func) {
		if (var!=null) {
			if (var.accessModifier!=null) {
				if (var.accessModifier.isFinal) return false;
				if (var.accessModifier.isStatic) return true;
				if (var.accessModifier.accessPermission!=null) return true;
			}
			else {
				return false;
			}
		}
		else if (func!=null) {
			if (func.accessModifier!=null) {
				if (func.accessModifier.isFinal) return true;
				if (func.accessModifier.isStatic) return true;
				if (func.accessModifier.accessPermission!=null) return true;
			}
			else {
				return false;
			}
		}
		return false;
	}

	/**
	 * class A { <br>
		 public A(char c) {   }<br>
		}<br>
		class B extends A {<br>
		 public B(char c) { <br>
		 }<br>
		}<br>
    */
	public static void checkConstructor(Compiler compiler) {
		for (int i=0; i<compiler.data.mlistOfAllFunctions.count; i++) {
			FindFunctionParams func = (FindFunctionParams) compiler.data.mlistOfAllFunctions.getItem(i);
			FindClassParams baseClass = ((FindClassParams)func.parent).classToExtend;
			if (func.isConstructor && !func.isConstructorThatInitializesStaticFields) {
				//if (func.listOfFuncArgs.count>0) {
					if (!CompilerHelper.hasFuncCallToConstructorOfSuperClass(compiler, func)) {
						// 컴파일러는 ByteCodeGeneneratorForClass.printFunction()에서 super()를 넣는다.
						int j;
						for (j=0; j<baseClass.listOfFunctionParams.count; j++) {
							FindFunctionParams func2 = (FindFunctionParams) baseClass.listOfFunctionParams.getItem(j);
							if (func2.isConstructor  && !func2.isConstructorThatInitializesStaticFields) {
								if (func2.listOfFuncArgs.count==0) break;
							}
						}
						if (j==baseClass.listOfFunctionParams.count) {
							// not found
							CompilerStatic.errors.add(new Error(compiler, func.functionNameIndex(), func.functionNameIndex(), 
									"Default constructor not exists to inherit. or Add an explicit super()."));
						}
					}
				//}
			}
		}
	}


	public static void checkControlBlocks(Compiler compiler, HighArray_CodeString src, 
			boolean allOrPart, int startIndex, int endIndex) {
		int i;
		ArrayListIReset mlistOfAllControlBlocks = compiler.data.mlistOfAllControlBlocks;
		for (i=0; i<mlistOfAllControlBlocks.count; i++) {
			FindControlBlockParams control =  (FindControlBlockParams) mlistOfAllControlBlocks.getItem(i);
			if (!(startIndex<=control.startIndex() && control.endIndex()<=endIndex)) continue;
			if (control.parent==null) {
				CompilerStatic.errors.add(new Error(compiler, control.startIndex(), control.startIndex(), "invalid "+control.catOfControls.toString()));
			}
		}
	}
	
	
	public static boolean isParenthesisOfForLoop(Compiler compiler, int indexOfPairOfForLoop, boolean isReverse) {
		/*int i;
		ArrayListIReset listForLoops = compiler.data.mlistOfAllForLoops; 
		for (i=0; i<listForLoops.count; i++) {
			FindControlBlockParams forLoop = (FindControlBlockParams) listForLoops.getItem(i);
			if (forLoop.indexOfLeftParenthesis()==index || forLoop.indexOfRightParenthesis()==index) {
				return true;
			}
		}
		return false;*/
		if (indexOfPairOfForLoop==-1) {
			return false;
		}
		try {
			if (!isReverse) {
				int indexOfFor = CompilerHelper.SkipBlank(compiler.data.mBuffer, true, 0, indexOfPairOfForLoop-1);
				if (compiler.data.mBuffer.getItem(indexOfFor).equals("for")) return true;
			}
			else {
				int leftPair = Checker.CheckParenthesisWithoutCheckingSemicolon(compiler, compiler.data.mBuffer, 
						"(", ")", 0, indexOfPairOfForLoop, true);
				if (leftPair==-1) {
					return false;
				}
				int indexOfFor = CompilerHelper.SkipBlank(compiler.data.mBuffer, true, 0, leftPair-1);
				if (compiler.data.mBuffer.getItem(indexOfFor).equals("for")) return true;
			}
			return false;
		}catch(Exception e) {
			return false;
		}
	}
	
	
	/** <summary>처음부터 끝까지 '{,(,['와 '},),]'을 스택에 넣고 빼며 쌍이 맞는지 확인한다. 
	    * 괄호에러가 있을 때, block단위로 확인하지 않으므로 정확한 pair를 찾을 수 없지만
	    * 괄호에러가 있다는 것은 알 수 있다. 
	    * 괄호에러가 없을 때에 한해, listOfBlocks등 캐시를 사용하므로 더욱 빠르게 괄호의 쌍을
	    * 알 수 있다.</summary>*/
	    public static boolean CheckParenthesisAll(Compiler compiler, HighArray_CodeString src, 
	    		ArrayListIReset listOfBlocks, ArrayListIReset listOfSmallBlocks, ArrayListIReset listOfLargeBlocks) 
	    {
	        int i;
	        listOfBlocks.reset2();
	        listOfSmallBlocks.reset2();
	        listOfLargeBlocks.reset2();
	        //mlistOfIndexOfMiddlePair.reset();
	        
	        Stack stack = new Stack();
	        Stack stackSmall = new Stack();
	        Stack stackLarge = new Stack();        
	        
	        for (i = 0; i < src.count; i++)
	        {
	        	CodeString str = src.getItem(i);
	        	if (CompilerHelper.IsComment(str)) continue;
	            if (str.equals("{"))
	            {
	            	//mlistOfIndexOfMiddlePair.add(i);
	            	FindBlockParams block = new FindBlockParams(compiler, i, -1); 
	                stack.Push(block);
	                listOfBlocks.add(block);
	            }
	            else if (str.equals("}"))
	            {
	            	//mlistOfIndexOfMiddlePair.add(i);
	            	if (stack.len==2) {
	            	}
	                //try
	            	if (stack.len>0)
	                {
	            		FindBlockParams block = (FindBlockParams) stack.Pop();
	            		block.endIndex = IndexForHighArray.indexRelative(block, src, i);
	                }
	                //catch (Exception e)
	            	else
	                {
	                	//throw new Exception("}가 {보다 많습니다");
	                    //errors.add(new Error(this, i, i, "The num of '}' larger than '{'", Error.Error_MiddlePair));
	            		//hasPairError = true;
	                }
	            }
	            
	            
	            else if (str.equals("("))
	            {
	            	FindSmallBlockParams  block = new FindSmallBlockParams(compiler, i, -1); 
	            	stackSmall.Push(block);
	                listOfSmallBlocks.add(block);
	            }
	            else if (str.equals(")"))
	            {	
	                //try
	            	if (stackSmall.len>0)
	                {
	                	FindSmallBlockParams  block = (FindSmallBlockParams) stackSmall.Pop();
	                	block.endIndex = IndexForHighArray.indexRelative(block, src, i);
	                }
	                //catch (Exception e)
	            	else
	                {
	                	//throw new Exception("}가 {보다 많습니다");
	                    //errors.add(new Error(this, i, i, "The num of ')' larger than '('", Error.Error_SmallPair));
	            		//hasPairError = true;
	                }
	            }
	            
	            else if (str.equals("["))
	            {
	            	FindLargeBlockParams  block = new FindLargeBlockParams(compiler, i, -1); 
	            	stackLarge.Push(block);
	                listOfLargeBlocks.add(block);
	            }
	            else if (str.equals("]"))
	            {	
	                //try
	            	if (stackLarge.len>0)
	                {
	                	FindLargeBlockParams  block = (FindLargeBlockParams) stackLarge.Pop();
	                	block.endIndex = IndexForHighArray.indexRelative(block, src, i);
	                }
	                //catch (Exception e)
	            	else
	                {
	                	//throw new Exception("}가 {보다 많습니다");
	                    //errors.add(new Error(this, i, i, "The num of ']' larger than '['", Error.Error_LargePair));
	            		//hasPairError = true;
	                }
	            }
	        }
	        
	        int j;
			for (j=0; j<listOfBlocks.count; j++) {
	            FindBlockParams block = (FindBlockParams)listOfBlocks.getItem(j);
	            if (block.endIndex()==-1) {
	            	
	            }
	            else {
	            	src.getItem(block.startIndex()).setColor(Common_Settings.keywordColor);
	            	src.getItem(block.startIndex()).setType(CodeStringType.Parenthesis);
	            	src.getItem(block.endIndex()).setColor(Common_Settings.keywordColor);
	            	src.getItem(block.endIndex()).setType(CodeStringType.Parenthesis);
	            }
	        }
	    

			if (stack.len>0)
	        {	        	
	        	//errors.add(new Error(this, i-1, i-1, "The num of '{' larger than '}'", Error.Error_MiddlePair));
	        	//hasPairError = true;
	        }
	        
	        if (stackSmall.len>0)
	        {
	        	CompilerStatic.errors.add(new Error(compiler, i-1, i-1, "The num of '(' larger than ')'"));
	        	//hasPairError = true;
	        	return false;
	        }
	        
	        if (stackLarge.len>0)
	        {
	        	CompilerStatic.errors.add(new Error(compiler, i-1, i-1, "The num of '[' larger than ']'"));
	        	return false;
	        }
			return true;
			
	    }
	    
	    
	    /** @param checksChildBlock : true이면 func안에 있는 제어블럭 안에 있는 문장들까지 고려한다.
		 * if, while, do while 등에 들어있는 할당문장은 제외한다. 
		 * for루프의 경우에는 괄호안 초기화 문장도 세야 한다.
		 * for, finally, synchronized만 가능하다.*/
	    public static boolean containsLocalVarThatDoesNotInitialize(Compiler compiler, FindFunctionParams func, boolean checksChildBlock) {
			int i;
			ArrayList listOfAssignments = new ArrayList(10);
			for (i=0; i<func.listOfStatements.count; i++) {
				FindStatementParams statement = (FindStatementParams) func.listOfStatements.getItem(i);
				if (statement instanceof FindControlBlockParams) {
					if (checksChildBlock) {
						FindControlBlockParams childBlock = (FindControlBlockParams) statement;
						if (childBlock.nameIndex()==1470) {
						}
						ArrayList childResult = containsLocalVarThatDoesNotInitialize_sub(compiler, childBlock);
						int j;
						for (j=0; j<childResult.count; j++) {
							listOfAssignments.add(childResult.getItem(j));
						}
					}// if (checksChildBlock) {			
				} // if (statement instanceof FindControlBlockParams) {
				if (statement instanceof FindAssignStatementParams) {
					listOfAssignments.add(statement);
				}
			} // for (i=0; i<func.listOfStatements.count; i++) {
			
			boolean[] arrInitializeStates = new boolean[func.listOfVariableParamsBeforeProcessLocalVars.count];
			
			// 함수 인자는 호출시 값을 갖게 되므로 초기화되었다고 가정한다.
			for (i=0; i<func.listOfFuncArgs.count; i++) {
				FindVarParams arg = (FindVarParams) func.listOfFuncArgs.getItem(i);
				arrInitializeStates[arg.indexOfLocalVarsInFunctionBeforeProcessLocalVars] = true;
			}
			
			// finally에서 던지는 Throwable 예외 변수도 초기화되었다고 가정한다.
			FindVarParams varThrowable = func.getVar("__varForLocalVarForFinallyBlock");
			if (varThrowable!=null) {
				arrInitializeStates[varThrowable.indexOfLocalVarsInFunctionBeforeProcessLocalVars] = true;
			}
			
			// catch의 괄호안에 선언된 예외 변수도 초기화되었다고 가정한다.
			for (i=0; i<func.listOfVariableParamsBeforeProcessLocalVars.count; i++) {
				FindVarParams var = (FindVarParams) func.listOfVariableParamsBeforeProcessLocalVars.getItem(i);
				if (var.varNameIndex()==683) {
					int a;
					a=0;
					a++;
				}
				if (var.parent instanceof FindControlBlockParams) {
					FindControlBlockParams block = (FindControlBlockParams) var.parent;
					if (block.catOfControls==null) {
						FindSpecialBlockParams special = (FindSpecialBlockParams) block;
						if ( special.specialBlockType==FindSpecialBlockParams.SpecialBlockType_catch && 
							 special.isVarDefinedInParenthesis(var) ) {
							try {
							arrInitializeStates[var.indexOfLocalVarsInFunctionBeforeProcessLocalVars] = true;
							}catch(Exception e) {
								if (Common_Settings.g_printsLog) e.printStackTrace();
							}
						}
					}
				}
				// switch 안에서 선언되었다가 LocalVar.processLocalVarsDefinedInSwitch()에 의해 밖으로 빼내진
				// 지역변수는 초기화되었다가 가정한다.
				/*if (var.movedFromSwitch) {
					arrInitializeStates[var.indexOfLocalVarsInFunctionBeforeProcessLocalVars] = true;
				}*/
			}// for (i=0; i<func.listOfVariableParams.count; i++) {
					
			
			for (i=0; i<listOfAssignments.count; i++) {
				FindAssignStatementParams assign = (FindAssignStatementParams)listOfAssignments.getItem(i);
				
				FindVarParams var = null;
				// 공유변수가 아니라 원래 변수를 찾는다.
				if (assign.lValue.varDeclBeforeProcessLocalVars==null) {
					var = assign.lValue.varDecl;
				}
				else {				
					var = assign.lValue.varDeclBeforeProcessLocalVars;
				}
				if (var==null) continue;
				if (var.isMemberOrLocal) continue; // 멤버변수는 제외
				
				/*if (func!=func2) {
					continue;
				}*/
				if (assignStatementInitializeLocalVarCertainly(compiler, assign)) {
					if (var.assignStatementThatInitializeLocalVarFirst==null) {
						var.assignStatementThatInitializeLocalVarFirst = assign;
					}
					try {
						if (0<=var.indexOfLocalVarsInFunctionBeforeProcessLocalVars && 
								var.indexOfLocalVarsInFunctionBeforeProcessLocalVars<arrInitializeStates.length) {
							arrInitializeStates[var.indexOfLocalVarsInFunctionBeforeProcessLocalVars] = true;
						}
					}catch(Exception e) {
						if (Common_Settings.g_printsLog) e.printStackTrace();
					}
					/*if (var.sharedVar!=null) {
						assign.lValue.varDeclBeforeProcessLocalVars = assign.lValue.varDecl; 
						assign.lValue.varDecl = var.sharedVar;
						var = assign.lValue.varDecl;
					}*/
				}			
			}		
			
			
			boolean r = true;
			for (i=0; i<arrInitializeStates.length; i++) {
				if (!arrInitializeStates[i]) {
					FindVarParams var = (FindVarParams) func.listOfVariableParamsBeforeProcessLocalVars.getItem(i);
					if (var.varNameIndex()==683) {
						int a;
						a=0;
						a++;
					}
					//CompilerStatic.errors.add(new com.gsoft.common.this.Compiler_types.Error(this, 
					//	var.startIndex(), var.endIndex(), 
					//	"Local "+ var.typeName + " " + var.fieldName + " does not have any value"));
					var.isNotInitialized = true;
					r = false;
				}
			}
			return r;
		}
		
		
		
		/**assign이 반드시 실행되어 지역변수 lValue를 초기화하는지를 검사한다.
		 * function이나 class가 나올때까지 루프를 돌면서 if, while, do while 등에 들어있는 할당문장은 제외한다.
			for루프의 경우에는 괄호안 초기화 문장도 세야 한다. 
			try, finally, synchronized는 세고 catch는 제외한다.*/
		public static boolean assignStatementInitializeLocalVarCertainly(Compiler compiler, FindAssignStatementParams assign) {		
			FindVarParams var = null;
			if (assign.lValue.varDeclBeforeProcessLocalVars==null) {
				var = assign.lValue.varDecl;
			}
			else {				
				var = assign.lValue.varDeclBeforeProcessLocalVars;
			}
			if (var.isMemberOrLocal) return false; // 멤버변수는 제외
			
			if (var.varNameIndex()==470) {
			}
			
			var.blockInitializing = assign.parent;
			
			// 같은 블록일 경우
			if (var.parent==assign.parent) return true;			
			
			
			Block childBlock = assign.parent;
			while (true) {
				try {
					if (childBlock==null) continue;
					if (var.parent==childBlock) return true;
					if (childBlock instanceof FindControlBlockParams) {
						FindControlBlockParams controlBlock = (FindControlBlockParams) childBlock;
						
						if (controlBlock.catOfControls!=null)	{
							if (controlBlock.catOfControls.category==CategoryOfControls.Control_for) {
								if (controlBlock.funcCall!=null) {
									int indexOfSemicolon1 = controlBlock.funcCall.startIndex();
									indexOfSemicolon1 = 
											CompilerHelper.SkipBlank(compiler.data.mBuffer, true, 0, indexOfSemicolon1-1);
									// for루프의 경우에는 괄호안 초기화 문장도 세야 한다. 
									// 가장 바깥 for루프의 괄호안 초기화 문장은 반드시 실행된다.
									if (controlBlock.indexOfLeftParenthesis()<=assign.startIndex() && 
											assign.endIndex()<=indexOfSemicolon1) {
										var.blockInitializing = controlBlock;
										continue;
									}
								}
								
							}
							// if, while, do while, for 등에 들어있는 할당문장은 제외한다. 
							return false;
						}
						else {
							FindSpecialBlockParams special = (FindSpecialBlockParams) controlBlock;
							String keyword = special.getName();
							if (keyword.equals("catch")) {
								// catch안에 선언된 할당문은 제외
								return false;
							}
							//else if (blockName.equals("try")) continue;
							else if (keyword.equals("try")) return false;
							else { // try, finally, synchronized만 가능
								var.blockInitializing = controlBlock;
								continue;
							}
						}
					}//if (childBlock instanceof FindControlBlockParams) {
					// function이나 class가 나올때까지 루프를 돌면서 if, while, do while 등에 들어있는 할당문장은 제외한다.
					else if (childBlock instanceof FindFunctionParams) return true;
					else if (childBlock instanceof FindClassParams) return true;
					
				}
				finally {
					if (childBlock!=null) {
						childBlock = childBlock.parent;
					}
					else {
						return false;
					}
				}
			}
		}
		
		
		/**모든 할당문들을 넣는다.*/
		public static ArrayList containsLocalVarThatDoesNotInitialize_sub(Compiler compiler, Block block) {
			int i;
			ArrayList listOfAssignments = new ArrayList(10);
			
			if (block instanceof FindControlBlockParams) {
				FindControlBlockParams controlBlock = (FindControlBlockParams) block;
				if (controlBlock.catOfControls!=null)	{					
					// for루프의 경우에는 괄호안 초기화 문장도 세야 한다. 
					if (controlBlock.catOfControls.category==CategoryOfControls.Control_for) {
						if (controlBlock.funcCall!=null) {
							int indexOfSemicolon1 = controlBlock.funcCall.startIndex();
							indexOfSemicolon1 = 
									CompilerHelper.SkipBlank(compiler.data.mBuffer, true, 0, indexOfSemicolon1-1);
							if (indexOfSemicolon1==1478) {
							}
							for (int k=0; k<controlBlock.listOfStatementsInParenthesis.count; k++) {
								FindStatementParams initial = (FindStatementParams) controlBlock.listOfStatementsInParenthesis.getItem(k);
								if (initial.startIndex()==996) {
								}
								if (initial.endIndex()<=indexOfSemicolon1) {
									if (initial instanceof FindAssignStatementParams) {
										listOfAssignments.add(initial);
									}
								}
							}
						}
					}
					// if, while, do while 등에 들어있는 할당문장은 제외한다.  
					//else continue;
				}
			}
			
			
			for (i=0; i<block.listOfStatements.count; i++) {
				FindStatementParams statement = (FindStatementParams) block.listOfStatements.getItem(i);
				if (statement instanceof FindControlBlockParams) {
					FindControlBlockParams childBlock = (FindControlBlockParams) statement;
					// if, for, while, do while 등에 들어있는 초기화문장은 제외한다.
					
					ArrayList childResult = containsLocalVarThatDoesNotInitialize_sub(compiler, childBlock);
					int j;
					for (j=0; j<childResult.count; j++) {
						listOfAssignments.add(childResult.getItem(j));
					}
				}
				else if (statement instanceof FindAssignStatementParams) {
					listOfAssignments.add(statement);
				}
			}
			return listOfAssignments;
		}
		
		/** (int i, com.gsoft.common.gui.ColorDialog dialog)와 같은 파라미터 리스트인지를 확인한다*/ 
		public static boolean checkFunctionParameters(Compiler compiler, int indexOfLeftPair, int indexOfRightPair) {
			int i;
			if (indexOfLeftPair>=indexOfRightPair) return false;
			
			for (i=indexOfRightPair; i>=indexOfLeftPair; ) {
				if (i==indexOfLeftPair) return true;
				
				int indexCommaOrRightPair = i;
				CodeString commaOrRightPair = compiler.data.mBuffer.getItem(indexCommaOrRightPair); 
				if (!(commaOrRightPair.equals(",") || commaOrRightPair.equals(")"))) {
					return false;
				}
				
				int index = CompilerHelper.SkipBlank(compiler.data.mBuffer, true, indexOfLeftPair, indexCommaOrRightPair-1);
				
				if (index==indexOfLeftPair) return true;
				
				// 현재 index는 id의 인덱스이거나 void의 인덱스이다.
				CodeString id = compiler.data.mBuffer.getItem(index);
				
				if (id.equals("void")) {
					// func(void)와 같은 경우
					index = CompilerHelper.SkipBlank(compiler.data.mBuffer, true, indexOfLeftPair, index-1);
					if (index==indexOfLeftPair) return true;
					else return false;
				}
				
				if (!CompilerHelper.IsIdentifier(id, compiler)) return false;
				
				index = CompilerHelper.SkipBlank(compiler.data.mBuffer, true, indexOfLeftPair, index-1);
				
				ReturnOfIsType type = compiler.IsType(compiler.data.mBuffer, true, index);
				if (type.index!=-1) {
					index = type.index;
				}
				else return false;
				
				index = CompilerHelper.SkipBlank(compiler.data.mBuffer, true, indexOfLeftPair, index-1);
				i = index;
				
			}
			return true;
		}
		
		
		
		/** i(functionNameIndex)부터 ()와 {}이 제대로 있는지를 확인한다. 함수정의인지를 확인한다.
		 * @param stack */
		public static boolean CheckBody(Compiler compiler, HighArray_CodeString src, int i, Stack stack) {
			
			int startIndexOfName = Fullname.getFullNameIndex(compiler,  true, i, false);
			int indexOfnew = CompilerHelper.SkipBlank(src, true, 0, startIndexOfName);
			if (indexOfnew>=0 && src.getItem(indexOfnew).equals("new")) {
				return false;
			}
	        
	        int indexOfLeftParenthesis = CompilerHelper.SkipBlank(src, false, i+1, src.count-1);
	        if (indexOfLeftParenthesis == src.count) {
	        	return false;
	        }
	        if (!src.getItem(indexOfLeftParenthesis).equals("(")) return false;
	               
	        //findFunctionParams.indexOfRightParenthesis = Skip(src, false, ")", findFunctionParams.indexOfLeftParenthesis+1, endIndex);
	        int indexOfRightParenthesis =	        		
	        		CheckParenthesis(compiler,  "(", ")", indexOfLeftParenthesis, src.count-1, false);
	        if (indexOfRightParenthesis == -1) {
	        	return false;
	        }
	        
	        // fo (i=0; i<3; i++)과 같은 에러를 찾는다.
	        if (!checkFunctionParameters(compiler, indexOfLeftParenthesis, indexOfRightParenthesis)) {
	        	return false;
	        }
	        
	        Block parentBlock = (Block) stack.Get();
	        if (!(parentBlock instanceof FindClassParams)) {
	        	// cach (Exception e)와 같이 에러가 있는 경우 함수정의로 인식하므로 
	        	// parentBlock이 클래스인지를 이용하여 해결한다.
	        	return false;
	        }
	        
	        
	        int separator = CompilerHelper.SkipBlank(src, false, indexOfRightParenthesis + 1, src.count-1); // 공백 스킵
	    	int indexOfSeparator=separator;
	    	if (separator==src.count) {
	    		return false;        		
	    	}
	    	//if (showsError==false) return false;
			CodeString strSeparator = src.getItem(separator);
			int index=separator;
			if (strSeparator.equals("throws")) {
	    		while (true) {
	        		index = CompilerHelper.SkipBlank(src, false, index+1, src.count-1);
	                if (index==src.count) break;
	                index = Fullname.getFullNameIndex(compiler,  false, index, true);
	                //index = getFullNames(src, "throws", null, findFunctionParams, index);
	                if (index!=-1) {
	                	index = CompilerHelper.SkipBlank(src, false, index+1, src.count-1);
	                	CodeString codeStr = src.getItem(index);
	                	if (codeStr.equals("{")) {
	                		i = index;
	                		break;
	                	}
	                	else if (codeStr.equals(",")) {
	                	}
	                	else {
	                		CompilerStatic.errors.add(new Error(compiler, index, index, "\"{\" or \",\" not exist"));
	                		break;
	                	}
	                }
	                else {	// '{'이 없을 때
	                	index = separator;
	                	break;
	                }
	    		}
	    	}
			indexOfSeparator = index;
			
			strSeparator = src.getItem(indexOfSeparator);
			if (!strSeparator.equals("{")) {
				return false;
			}
	    	
	    	
	    	// 반드시 ) 다음에는 { 이다.	
	        return true;

		}
		
		/** i(functionNameIndex())부터 startIndex, endIndex사이에서 ()와 {}이 제대로 있는지를 확인한다.
		 * @param checkType : 0(함수,클래스), 1(생성자)이면 블록 시작({)이 없는 에러를 확인하고(함수, 클래스, 생성자 정의), 
	     * 		2이면 시작괄호에러를 확인하지 않는다.*/
		public static boolean CheckBody(Compiler compiler, HighArray_CodeString src, FindFunctionParams findFunctionParams, 
				int startIndex, int endIndex, int i) {
			findFunctionParams.functionNameIndex = IndexForHighArray.indexRelative(findFunctionParams, src, i);
			
			if (i==2073) {
			}
	        
	        //i = SkipBlank(src, false, i + 1, endIndex); // 공백 스킵
	        
	        findFunctionParams.indexOfLeftParenthesis = IndexForHighArray.indexRelative(findFunctionParams, src, 
	        		CompilerHelper.SkipBlank(src, false, i + 1, endIndex));
	        if (findFunctionParams.indexOfLeftParenthesis() == endIndex+1) {
				//errors.add(new Error(compiler, findFunctionParams.indexOfLeftParenthesis, findFunctionParams.indexOfLeftParenthesis, "( not exists."));
				return false;
	        }
	        if (!src.getItem(findFunctionParams.indexOfLeftParenthesis()).equals("(")) {
	        	//errors.add(new Error(compiler, findFunctionParams.indexOfLeftParenthesis, findFunctionParams.indexOfLeftParenthesis, "( not exists."));
				return false;
	        }
	               
	        //findFunctionParams.indexOfRightParenthesis = Skip(src, false, ")", findFunctionParams.indexOfLeftParenthesis+1, endIndex);
	        findFunctionParams.indexOfRightParenthesis = IndexForHighArray.indexRelative(findFunctionParams, src, 	        		
	        		CheckParenthesis(compiler, "(", ")", findFunctionParams.indexOfLeftParenthesis(), endIndex, false));
	        if (findFunctionParams.indexOfRightParenthesis() == -1) {
	        	CompilerStatic.errors.add(new Error(compiler, findFunctionParams.indexOfLeftParenthesis(), findFunctionParams.indexOfLeftParenthesis(), ") not exists."));
				return false;
	        }
	        else {
	        	boolean checkParams = Checker.checkFunctionParameters(compiler, 
	        			findFunctionParams.indexOfLeftParenthesis(), findFunctionParams.indexOfRightParenthesis());
	        	if (!checkParams) {
	        		// System.out.pri ntln("A()"); 이와같은 경우를 체크한다.
	        		return false;
	        	}
	        	
	        	int separator = CompilerHelper.SkipBlank(src, false, findFunctionParams.indexOfRightParenthesis() + 1, endIndex); // 공백 스킵
	        	int indexOfSeparator=separator;
	        	if (separator==endIndex+1) {
	        		return false;        		
	        	}
	        	else {
	        		//if (showsError==false) return false;
	        		CodeString strSeparator = src.getItem(separator);
	        		int index=separator;
	        		if (strSeparator.equals("throws")) {
	            		while (true) {
	                		index = CompilerHelper.SkipBlank(src, false, index+1, endIndex);
	                        if (index==endIndex+1) break;
	                        index = Fullname.getFullNames(compiler, "throws", null, findFunctionParams, index);
	                        if (index!=-1) {
	                        	CodeString codeStr = src.getItem(index);
	                        	if (codeStr.equals("{")) {
	                        		i = index;
	                        		break;
	                        	}
	                        	else if (codeStr.equals(",")) {
	                        	}
	                        	else if (codeStr.equals(";")) {
	                        		break;
	                        	}
	                        }
	                        else {	// '{'이 없을 때
	                        	index = separator;
	                        	break;
	                        }
	            		}
	            	}
	        		indexOfSeparator = index;
	        		
	        		strSeparator = src.getItem(indexOfSeparator);
	        		if (strSeparator.equals(";")) {
	        			if (findFunctionParams.hasReturnType()) {// 함수foward선언
	        				findFunctionParams.isAbstractMethod = true;
	        			}
	        			else { // 함수호출
	        				return false;
	        			}
	        		}
	        		else if (!strSeparator.equals("{")) {// 함수호출
	        			return false;
	        		}
	        		
	        		// 함수 정의
	        	}
	        	
	        	
	        	// 반드시 ) 다음에는 { 이다.
	        	int startParenthesis = indexOfSeparator;
	            int endParenthesis = -1;
	            FindBlockParams findBlockParams = new FindBlockParams(compiler, startParenthesis, endParenthesis);
	            
	            int k = -1;
	            ReturnOfFindAccessModifier r;
	            
	            if (findFunctionParams.hasReturnType()) { // 일반함수
	            	r = compiler.compilerStack.FindAccessModifier(src, startIndex, findFunctionParams.returnTypeStartIndex() - 1, findFunctionParams.accessModifier);
	            }
	            else { // 생성자
	            	r = compiler.compilerStack.FindAccessModifier(src, startIndex, findFunctionParams.functionNameIndex() - 1, findFunctionParams.accessModifier);
	            }
	            k = r.r;
	            
	            
	            boolean hasAccess = compiler.hasAccessModifier(null, findFunctionParams);
	            if (findBlockParams.startIndex()!=-1/* && findBlockParams.endIndex!=-1*/) {
	            	if (hasAccess) findFunctionParams.startIndex = IndexForHighArray.indexRelative(findFunctionParams, src, k);
	            	//else findFunctionParams.startIndex = -1;
	            	else findFunctionParams.startIndex = IndexForHighArray.indexRelative(findFunctionParams, src, k);
	            	findFunctionParams.startIndex = IndexForHighArray.indexRelative(findFunctionParams, src, 
	            			CompilerStatic.getIndexWhickRemoveLeftBlankAndCommentAndAnnotation(src, r));
	            	//findFunctionParams.endIndex = findBlockParams.endIndex;
	            	findFunctionParams.found = true;
	            	findFunctionParams.findBlockParams = findBlockParams;
	            	findFunctionParams.findBlockParams.blockName = src.getItem(findFunctionParams.functionNameIndex()).str;
	            	
	            	findBlockParams.categoryOfBlock = new CategoryOfBlock(CategoryOfBlock.Function, null);
	            	findBlockParams.parent = findFunctionParams;
	            	compiler.data.mlistOfBlocks.add(findBlockParams);
	            	
	            	
	            	int docuIndex;
	            	if (hasAccess) docuIndex = k;
	            	else {
	            		if (findFunctionParams.hasReturnType()) { // 일반함수
	            			docuIndex = findFunctionParams.returnTypeStartIndex() - 1;
	            		}
	            		else { //생성자
	            			docuIndex = findFunctionParams.functionNameIndex() - 1;
	            		}
	            	}
	            	int indexOfDocuEnd = CompilerHelper.SkipOnlyBlankAndAnnotationAndRegularComment(src, true, startIndex, docuIndex); // 공백 스킵
	            	DocuComment docu = 
	            			compiler.FindDocuComment( /*true, findFunctionParams, null,*/ 0, indexOfDocuEnd);
	            	findFunctionParams.docuComment = docu;
	            	
	            	return true;
	            }
	        }   
	        return false;

		}
		
		
		
		public static boolean CheckControlBody_case(Compiler compiler, HighArray_CodeString src, 
				CategoryOfControls category, FindControlBlockParams findControlParams, 
				int startIndex, int endIndex, int i) {
			if (i==8985) {
			}
			if (category==null) return false;
			
			findControlParams.nameIndex = IndexForHighArray.indexRelative(findControlParams, src, i);		
			findControlParams.catOfControls = category;
			findControlParams.startIndex = IndexForHighArray.indexRelative(findControlParams, src, i);
			
			boolean noError=true;
			int indexOfNext = 0;
			
			if (category.category==CategoryOfControls.Control_case) {
				findControlParams.indexOfLeftParenthesis = IndexForHighArray.indexRelative(findControlParams, src, i+1);	        
		        
		        findControlParams.indexOfRightParenthesis =	        		
		        		IndexForHighArray.indexRelative(findControlParams, src, 
		        				CompilerHelper.Skip(src, false, ":", i+1, endIndex));
		        
		        if (findControlParams.indexOfRightParenthesis() == endIndex+1) {
					try {
						throw new Exception(":가 없습니다.");
					} catch (Exception e) {
						
						//if (Common_Settings.g_printsLog) e.printStackTrace();
						return false;
					} 
		        }
		        //findControlParams.indexOfRightParenthesis = Skip(src, false, ")", findControlParams.indexOfLeftParenthesis+1, endIndex);
		        
		        // if, else if, while등은 ) 다음부터, case는 ":" 다음
		        indexOfNext = findControlParams.indexOfRightParenthesis() + 1;
			}
			
			if (noError) {
	        	int separator = CompilerHelper.SkipBlank(src, false, indexOfNext, endIndex); // 공백 스킵
	        	if (separator==endIndex+1)
	        		return false;
	        	
	        	int startParenthesis = separator;
	            int endParenthesis = -1;
	        			
	        	CodeString leftParent = src.getItem(separator);
	        	if (!leftParent.equals("{")) { // block이 아닌 제어문이거나 error
	        		// error
	        		//errors.add(new Error(compiler, separator, separator, packageName));
	        		int nextCaseIndex = CompilerHelper.Skip(src, false, "case", i+1, endIndex);
	        		endParenthesis = nextCaseIndex-1;        		
	        		//findControlParams.endIndex = endParenthesis;
	        		findControlParams.isBlock = false;
	        	}
	        	else {	// block
	        		endParenthesis = CheckParenthesis(compiler,  "{", "}", startParenthesis, src.count-1, false);
	        		//findControlParams.endIndex = endParenthesis;
	        		findControlParams.isBlock = true;
	        	}
	        	
	        	FindBlockParams findBlockParams = new FindBlockParams(compiler, startParenthesis, endParenthesis);
	        	
	        	
	        	findControlParams.found = true;
	        	findBlockParams.categoryOfBlock = new CategoryOfBlock(0, category);
	        	findControlParams.findBlockParams = findBlockParams;
	        	
	        	// 조건문을 연결
	        	// findControlParams.indexOfRightParenthesis는 case문의 경우 ':'이다.
	        	if (findControlParams.indexOfLeftParenthesis()!=-1 && findControlParams.indexOfRightParenthesis()!=-1) {
	            	ArrayListChar list = new ArrayListChar(50);
	            	int start = findControlParams.indexOfLeftParenthesis();
	            	int end = findControlParams.indexOfRightParenthesis();
	            	for (i=start; i<end; i++) {
	            		CodeString str = src.getItem(i);
	            		if (CompilerHelper.IsBlank(str)) continue;
	            		list.add(str.str);
	            	}
	            	findControlParams.findBlockParams.blockName = new String(list.getItems());
	        	}
	        	else {
	        		findControlParams.findBlockParams.blockName = "";
	        	}
	        	
	        	if (findControlParams.isBlock) {
	        		//mlistOfBlocks.add(findBlockParams)
	        		compiler.compilerStack.core.putFindBlockParams(findBlockParams);
	        	}
	        	return true;
	            
	        }
	        return false;
		}
		
		
		/** i(nameIndex)부터 startIndex, endIndex사이에서 ()와 {}이 제대로 있는지를 확인한다.
		 * ) 다음에 { 이 아니면 block이 아닌 제어문이거나 error이고, 
		 * { 이면 쌍이 되는 }을 찾아 block임을 확인한다.
		 * @param i : if, else, else if, while 등의 index*/
		public static boolean CheckControlBody(Compiler compiler, HighArray_CodeString src, 
				CategoryOfControls category, FindControlBlockParams findControlParams, 
				int startIndex, int endIndex, int i) {
			try {
				if (category==null) return false;
				
				if (category.category==CategoryOfControls.Control_case) {
					return CheckControlBody_case(compiler, src, category, findControlParams, startIndex, endIndex, i);
				}
				
				findControlParams.nameIndex = IndexForHighArray.indexRelative(findControlParams, src, i);		
				findControlParams.catOfControls = category;
				findControlParams.startIndex = IndexForHighArray.indexRelative(findControlParams, src, i);
				
				boolean noError=true;
				int indexOfNext;
				int indexOfEndOfdowhile=-1;
		        
				if (category.category==CategoryOfControls.Control_dowhile) {
					// else는 else 다음부터
					indexOfNext = i+1;
					
					int indexOfWhile = -1;
					int leftPair = -1;
					int rightPair = -1;
					int semicolon = -1;
					
					int indexOfMiddleLeftPair = CompilerHelper.SkipBlank(src, false, i+1, endIndex);
					int indexOfMiddleRightPair = CheckParenthesis(compiler,  "{", "}", indexOfMiddleLeftPair, endIndex, false);
					
					
					//while (true) {
						indexOfWhile = CompilerHelper.SkipBlank(src, false, indexOfMiddleRightPair+1, endIndex);
						leftPair = CompilerHelper.SkipBlank(src, false, indexOfWhile+1, endIndex);
						
						if (leftPair>=endIndex+1 || !src.getItem(leftPair).equals("(")) {
							CompilerStatic.errors.add(new Error(compiler, leftPair, leftPair, "( not exists"));
							compiler.PairErrorExists = true;
							return false;
				        }
					
						rightPair =
								CheckParenthesis(compiler, "(", ")", leftPair, endIndex, false);
						semicolon = CompilerHelper.SkipBlank(src, false, rightPair+1, endIndex);
						
						CodeString strSemicolon = src.getItem(semicolon); 
						if (strSemicolon.equals(";")) {
							findControlParams.indexOfLeftParenthesis = IndexForHighArray.indexRelative(findControlParams, src, leftPair);
							findControlParams.indexOfRightParenthesis = IndexForHighArray.indexRelative(findControlParams, src, rightPair);
							findControlParams.endIndex = IndexForHighArray.indexRelative(findControlParams, src, semicolon);
							indexOfEndOfdowhile = semicolon;
							// findBlockParams은 아랫부분에서 만들어 endIndex를 넣는다.
						}
					//}
					
			        
			       
				}
				else if (category.category!=CategoryOfControls.Control_else) {
					if (category.category!=CategoryOfControls.Control_else && 
							category.category!=CategoryOfControls.Control_elseif) {
						// if, for, while 등
						int leftPair = CompilerHelper.SkipBlank(src, false, i+1, endIndex);
						if (!src.getItem(leftPair).equals("(")) {
							CompilerStatic.errors.add(new Error(compiler, leftPair, leftPair, "( not exists"));
							compiler.PairErrorExists = true;
							return false;
						}
						findControlParams.indexOfLeftParenthesis = IndexForHighArray.indexRelative(findControlParams, src, leftPair);
					}
					else if (category.category==CategoryOfControls.Control_elseif) {
						int indexOfIf = CompilerHelper.SkipBlank(src, false, i+1, endIndex);
						int leftPair = CompilerHelper.SkipBlank(src, false, indexOfIf+1, endIndex);
						if (!src.getItem(leftPair).equals("(")) {
							CompilerStatic.errors.add(new Error(compiler, leftPair, leftPair, "( not exists"));
							compiler.PairErrorExists = true;
							return false;
						}
						findControlParams.indexOfLeftParenthesis = IndexForHighArray.indexRelative(findControlParams, src, 
								leftPair);
					}
					//findControlParams.indexOfLeftParenthesis = Skip(src, false, "(", i+1, endIndex);
			        if (findControlParams.indexOfLeftParenthesis() == endIndex+1) {
						try {
							throw new Exception("(가 없습니다.");
						} catch (Exception e) {
							
							//if (Common_Settings.g_printsLog) e.printStackTrace();
							return false;
						} 
			        }
			        
			        
			        if (category.category==CategoryOfControls.Control_for) {
			        	compiler.data.mlistOfAllForLoops.add(findControlParams);
			        }
			        
			        findControlParams.indexOfRightParenthesis =	 IndexForHighArray.indexRelative(findControlParams, src,        		
			        		CheckParenthesis(compiler,  "(", ")", findControlParams.indexOfLeftParenthesis(), endIndex, false));
			        
			        //findControlParams.indexOfRightParenthesis = Skip(src, false, ")", findControlParams.indexOfLeftParenthesis+1, endIndex);
			        
			        // if, else if, while등은 ) 다음부터
			        indexOfNext = findControlParams.indexOfRightParenthesis() + 1;
				}
				else {
					// else는 else 다음부터
					indexOfNext = i+1;
				}
		        
				if (noError) {
		        	int separator = CompilerHelper.SkipBlank(src, false, indexOfNext, endIndex); // 공백 스킵
		        	if (separator==endIndex+1)
		        		return false;
		        	
		        	int startParenthesis = separator;
		            int endParenthesis = -1;
		        			
		        	CodeString leftParent = src.getItem(startParenthesis);
		        	if (!leftParent.equals("{")) { // block이 아닌 제어문이거나 error
		        		// error
		        		//errors.add(new Error(compiler, separator, separator, packageName));
		        		findControlParams.isBlock = false;
		        		findControlParams.found = true;
		        		return true;
		        		    		
		        	}
		        	else {	// block
		        		
		        		findControlParams.isBlock = true;
		        		FindBlockParams findBlockParams = new FindBlockParams(compiler, startParenthesis, endParenthesis);
		            	if (category.category!=CategoryOfControls.Control_dowhile) {
		            		endParenthesis = CheckParenthesis(compiler, "{", "}", startParenthesis, src.count-1, false);
		            		findControlParams.endIndex = IndexForHighArray.indexRelative(findControlParams, src, endParenthesis);
		            		findBlockParams.endIndex = IndexForHighArray.indexRelative(findBlockParams, src, endParenthesis);
		            	}
		            	else { // do while
		            		//findBlockParams.startIndex = IndexForHighArray.indexRelative(findBlockParams, src, i);	        		
		            		findBlockParams.endIndex = IndexForHighArray.indexRelative(findBlockParams, src, indexOfEndOfdowhile);
		            		findControlParams.startIndex = IndexForHighArray.indexRelative(findControlParams, src, i);
		            		findControlParams.endIndex = IndexForHighArray.indexRelative(findControlParams, src, indexOfEndOfdowhile);
		            	}
		            	findControlParams.found = true;
		            	findBlockParams.categoryOfBlock = new CategoryOfBlock(0, category);
		            	findControlParams.findBlockParams = findBlockParams;
		            	
		            	// 조건문을 연결
		            	if (findControlParams.indexOfLeftParenthesis()!=-1 && findControlParams.indexOfRightParenthesis()!=-1) {
			            	ArrayListChar list = new ArrayListChar(50);
			            	int start = findControlParams.indexOfLeftParenthesis();
			            	int end = findControlParams.indexOfRightParenthesis();
			            	for (i=start; i<=end; i++) {
			            		list.add(src.getItem(i).str);
			            	}
			            	findControlParams.findBlockParams.blockName = new String(list.getItems());
		            	}
		            	else {
		            		findControlParams.findBlockParams.blockName = "";
		            	}
		            	
		            	compiler.compilerStack.core.putFindBlockParams(findBlockParams);
		            	return true;
		        		
		        	}
		            
		        }
		        return false;
			}catch(Exception e) {
				return false;
			}
		}
		
		public static void checkDuplicateNames(Compiler compiler, int coreThreadID) {
			CompilerData data = compiler.data;
			int i, j, k;
						
			//구현인터페이스이름을 정확한 fullname으로 바꿔준다.
			for (i=0; i<data.mlistOfAllDefinedClasses.count; i++) {
				FindClassParams c = (FindClassParams) data.mlistOfAllDefinedClasses.getItem(i);
				if (c.interfaceNamesToImplement!=null) {
					for (j=0; j<c.interfaceNamesToImplement.count; j++) {					
						String name = c.interfaceNamesToImplement.getItem(j);
						for (k=j+1; k<c.interfaceNamesToImplement.count; k++) {
							String name2 = c.interfaceNamesToImplement.getItem(k);
							if (name.equals(name2)) {
								IndexForHighArray startIndex = (IndexForHighArray) c.listOfStartIndexOfInterfaceNamesToImplement.getItem(k);
								IndexForHighArray endIndex = (IndexForHighArray) c.listOfEndIndexOfInterfaceNamesToImplement.getItem(k);
								CompilerStatic.errors.add(new Error(compiler, startIndex.index(), endIndex.index(), "Duplicate inteface name"));
							}
						}
					}
				}
			}
			
			
			for (i=0; i<data.mlistOfAllFunctions.count; i++) {
				FindFunctionParams func = (FindFunctionParams) data.mlistOfAllFunctions.getItem(i);	
				for (j=i+1; j<data.mlistOfAllFunctions.count; j++) {					
					FindFunctionParams func2 = (FindFunctionParams) data.mlistOfAllFunctions.getItem(j);
					if (func.parent==func2.parent && func.equals(func2, coreThreadID)) {
						IndexForHighArray index = func2.functionNameIndex;
						CompilerStatic.errors.add(new Error(compiler, index.index(), index.index(), "Duplicate function name"));
					}
				}
			}
		}
		
		public static boolean CheckVarNameOrVarUseName(Compiler compiler, String varNameOrVarUseName) {
			char ch = varNameOrVarUseName.charAt(0);
	    	if (('0'<=ch && ch<='9') || (ch=='-' || ch=='+')) return false;
	    	return true;
		}
		
		/** var의 scope를 확인한다.*/
		public static boolean CheckVarScope(Compiler compiler, HighArray_CodeString src, FindVarParams var) {
			int i;
			if (var.isThis || var.isSuper) return false;
			CodeString varName = src.getItem(var.varNameIndex());
			if (var.varNameIndex()==802) {
				int a;
				a=0;
				a++;
			}
			
			Object parent = var.parent;
			/*if (var.isDefinedInPairsOfForLoop!=null) {
				parent = var.isDefinedInPairsOfForLoop;
			}*/
			Block parentBlock = CompilerStatic.getParent((Block)parent);
			// 변수가 제어블럭 포함하여 함수 내에 정의된 경우,  parent블록에 이미 같은 이름의 변수가 선언되어 있는지 조사한다.
			if (parentBlock instanceof FindFunctionParams) {
				for (i=0; i<parentBlock.listOfVariableParams.count; i++) {
					FindVarParams varInList = (FindVarParams)parentBlock.listOfVariableParams.getItem(i);				
					String varNameInList = src.getItem(varInList.varNameIndex()).str;
					Block parent2 = varInList.parent;
					/*if (varInList.isDefinedInPairsOfForLoop!=null) {
						parent2 = varInList.isDefinedInPairsOfForLoop;
					}*/
					if (varName.equals(varNameInList)) {
						if (var.varNameIndex()==802) {
							int a;
							a=0;
							a++;
						}
						boolean isParent = CompilerStatic.isParent(parent2, (Block)parent/*, parentBlock*/);
						if (isParent) {
							CompilerStatic.errors.add(new Error(compiler, var.varNameIndex(), var.varNameIndex(), "var name is duplicated. : " + varName));
							return false;
						}
					}
				}
			}
			// 변수가 클래스에 정의된 경우 내부클래스관계에서 parent블록에 이미 같은 이름의 변수가 선언되어 있어도 허용된다.
			// 그러나 같은 클래스에 같은 이름의 변수 정의는 허용되지 않는다.
			else if (parentBlock instanceof FindClassParams) {
				for (i=0; i<parentBlock.listOfVariableParams.count; i++) {
					FindVarParams varInList = (FindVarParams)parentBlock.listOfVariableParams.getItem(i);			
					CodeString varNameInList = src.getItem(varInList.varNameIndex());
					if (varName.equals(varNameInList)) {
						CompilerStatic.errors.add(new Error(compiler, var.varNameIndex(), var.varNameIndex(), "var name is duplicated. : " + varName));
						return false;
					}
				}
			}
			
			return true;
			
			
		}
		
		/** 괄호에러가 있으면 CheckParenthesis을 사용하고
		 * (BASIC언어, end function, end if, end class 등), 
		 * 괄호에러가 없으면 CheckParenthesisAll을 호출
		 * (C언어, class, function, if 등의 {, }이 모두 같다.)한 후의 캐시(listOfBlocks등)를 사용한다. 
		 * @param errors : Error[], 멤버변수로 호출
		 * @return : 괄호에러가 있으면 true, 없으면 false
		 */
		public static boolean hasPairError(ArrayListIReset errors) {
			int i;
			for (i=0; i<errors.count; i++) {
				Error error = (Error)errors.getItem(i);
				if (error.errorNum==Error.Error_MiddlePair || error.errorNum==Error.Error_SmallPair ||
						error.errorNum==Error.Error_LargePair ) {
					return true;
				}
			}
			return false;
		}	
		
		
		/** <summary>startIndex부터 endIndex까지 
	     * '{,(,['(charOfLeftPair)와 '},),]'(charOfRightPair)을 스택에 넣고 빼며 쌍이 맞는지 확인한다. 
	    * block단위로 확인해야 정확한 pair를 찾을 수 있다. 
	    * 다시말해 괄호에러를 고칠 수 있다. 처음 만난 괄호의 쌍의 인덱스를 리턴한다. 
	    * reverse가 false이면 startIndex부터 endIndex까지 인덱스를 증가시키면서 검색, 못 찾으면 -1을 리턴
		 *  reverse가 true이면 endIndex부터 startIndex까지 인덱스를 감소시키면서 검색, 못 찾으면 -1을 리턴
		 *  </summary>
		 *  @param startIndex : isReverse가 false일 경우 charOfLeftPair의 인덱스여야 한다.
		 *  그래야 괄호의 쌍이 맞는다.
		 *  @param endIndex :	isReverse가 true일 경우 charOfRightPair의 인덱스여야 한다. 
		 *  그래야 괄호의 쌍이 맞는다.*/
	    public static int CheckParenthesis(Compiler compiler, 
	    		String charOfLeftPair, String charOfRightPair, 
	    		int startIndex, int endIndex, boolean isReverse) 
	    {
	    	return CheckParenthesis_postfix(compiler, compiler.data.mBuffer, 
	    			charOfLeftPair, charOfRightPair, startIndex, endIndex, isReverse);
	    }
	    
	    
	    /** <summary>startIndex부터 endIndex까지 
	     * '{,(,['(charOfLeftPair)와 '},),]'(charOfRightPair)을 스택에 넣고 빼며 쌍이 맞는지 확인한다. 
	    * block단위로 확인해야 정확한 pair를 찾을 수 있다. 
	    * 다시말해 괄호에러를 고칠 수 있다. 처음 만난 괄호의 쌍의 인덱스를 리턴한다. 
	    * reverse가 false이면 startIndex부터 endIndex까지 인덱스를 증가시키면서 검색, 못 찾으면 -1을 리턴
		 *  reverse가 true이면 endIndex부터 startIndex까지 인덱스를 감소시키면서 검색, 못 찾으면 -1을 리턴
		 *  </summary>
		 *  @param startIndex : isReverse가 false일 경우 charOfLeftPair의 인덱스여야 한다.
		 *  그래야 괄호의 쌍이 맞는다.
		 *  @param endIndex :	isReverse가 true일 경우 charOfRightPair의 인덱스여야 한다. 
		 *  그래야 괄호의 쌍이 맞는다.*/
	    public static int CheckParenthesis_postfix(Compiler compiler, HighArray_CodeString src,
	    		String charOfLeftPair, String charOfRightPair, 
	    		int startIndex, int endIndex, boolean isReverse) 
	    {
	    	if (isReverse && endIndex==3392) {
	    		int a;
	    		a=0;
	    		a++;
	    	}
	        int i;
	        int indexFirstChar = -1;
	        Stack stack = new Stack();
	        if (!isReverse) {
	        	if (startIndex<0) return -1;
	        	if (!charOfLeftPair.equals("<")) {
			        for (i = startIndex; i <= endIndex; i++)
			        {
			        	CodeString str = src.getItem(i);
			        	if (CompilerHelper.IsComment(str)) continue;
			        	if (CompilerHelper.IsConstant(str)) continue;
			            if (str.equals(charOfLeftPair))
			            { 
			            	if (indexFirstChar==-1) indexFirstChar = i;
			                stack.Push(charOfLeftPair);
			            }
			            else if (str.equals(charOfRightPair))
			            {
			            	if (stack.len>0)
			                {
			            		stack.Pop();
			            		if (stack.len==0) {
			            			return i;
			            		}
			                }
			            }
			            else if (str.equals(";")) {
			            	if (charOfLeftPair.equals("(") || charOfLeftPair.equals("<") || charOfLeftPair.equals("[")) {
			            		if (charOfLeftPair.equals("(")) {
			            			// for루프 안에 있는 ';', 괄호 에러를 찾기 위해서
			            			if (Checker.isParenthesisOfForLoop(compiler, indexFirstChar, false)) {
			            				continue;
			            			}
			            		}
			            		break;
			            	}
			            }
			            	
			        } // for
	        	}//if (!charOfLeftPair.equals("<")) {
	        	else {
	        		// 템플릿 기호 "<"
	        		for (i = startIndex; i <= endIndex; i++)
			        {
			        	CodeString str = src.getItem(i);
			        	if (CompilerHelper.IsComment(str)) continue;
			        	if (CompilerHelper.IsConstant(str)) continue;
			            if (str.equals(charOfLeftPair))
			            { 
			            	if (indexFirstChar==-1) indexFirstChar = i;
			                stack.Push(charOfLeftPair);
			                int indexFullname = CompilerHelper.SkipBlank(src, false, i+1, endIndex);
			            	indexFullname = Fullname.getFullNameIndex_OnlyType_postfix(compiler, src, false, indexFullname, true);
			            	indexFullname = CompilerHelper.SkipBlank(src, false, indexFullname+1, endIndex);
			            	
			            	if (indexFullname<0 || indexFullname>=src.count) {
			            		return -1;
			            	}
			            	if (!src.getItem(indexFullname).equals(">")) {
			            		return -1;
			            	}
			            	else {
			            		return indexFullname;
			            	}
			            }
			        } // for
	        	}
	        }// isReverse==false
	        else {
	        	if (!charOfRightPair.equals(">")) {
		        	for (i = endIndex; i >= startIndex; i--)
			        {
			        	CodeString str = src.getItem(i);
			        	if (CompilerHelper.IsComment(str)) continue;
			        	if (CompilerHelper.IsConstant(str)) continue;
			            if (str.equals(charOfRightPair))
			            { 
			            	if (indexFirstChar==-1) indexFirstChar = i;
			                stack.Push(charOfRightPair);
			            }
			            else if (str.equals(charOfLeftPair))
			            {
			            	if (stack.len==2) {
			            	}
			            	if (stack.len>0)
			                {
			            		stack.Pop();
			            		if (stack.len==0) {
			            			return i;
			            		}
			                }
			            }
			            else if (str.equals(";") || str.equals("{") || str.equals("}")) {
			            	if (charOfLeftPair.equals("(") || charOfLeftPair.equals("<") || charOfLeftPair.equals("[")) {
			            		if (charOfLeftPair.equals("(")) {
			            			// for루프 안에 있는 ';', 괄호 에러를 찾기 위해서
			            			if (Checker.isParenthesisOfForLoop(compiler, indexFirstChar, true)) {
			            				continue;
			            			}
			            		}
			            		break;
			            	}
			            }
			        } // for
	        	}//if (!charOfRightPair.equals(">")) {
	        	else {
	        		// 템플릿 기호 ">"일 때
	        		for (i = endIndex; i >= startIndex; i--)
			        {
			        	CodeString str = src.getItem(i);
			        	if (CompilerHelper.IsComment(str)) continue;
			        	if (CompilerHelper.IsConstant(str)) continue;
			            if (str.equals(charOfRightPair))
			            { 
			            	if (indexFirstChar==-1) indexFirstChar = i;
			                stack.Push(charOfRightPair);
			                
			                int indexFullname = CompilerHelper.SkipBlank(src, true, startIndex, i-1);
			            	indexFullname = Fullname.getFullNameIndex(compiler,  true, indexFullname, true);
			            	indexFullname = CompilerHelper.SkipBlank(src, true, startIndex, indexFullname-1);
			            	
			            	if (!src.getItem(indexFullname).equals("<")) {
			            		return -1;
			            	}
			            	else {
			            		return indexFullname;
			            	}
			            }
			        } // for
	        	}
	        }
	        
	        if (charOfLeftPair.equals("(") || /*charOfLeftPair.equals("<") ||*/ charOfLeftPair.equals("[")) {
	        	if (!isReverse) {
	        		CompilerStatic.errors.add(new Error(compiler, startIndex, startIndex, charOfLeftPair+" is invalid"));
	        	}
	        	else {
	        		CompilerStatic.errors.add(new Error(compiler, endIndex, endIndex, charOfRightPair+" is invalid"));
	        	}
	        	compiler.PairErrorExists = true;
	        }
	        return -1;
	    }
	    
	    
	  
	    
	    /** 나중에 추가할 leftPair나 rightPair의 쌍을 찾는다.*/
	    public static int CheckParenthesisAddingFirstPair(Compiler compiler, HighArray_CodeString src, 
	    		String charOfLeftPair, String charOfRightPair, 
	    		int startIndex, int endIndex, boolean isReverse) 
	    {
	        int i;
	        int indexFirstChar = -1;
	        Stack stack = new Stack();
	        if (!isReverse) {
	        	if (startIndex<0) return -1;
	        	// leftPair를 먼저 추가한다.
	        	stack.Push(charOfLeftPair);
	        	
	        	for (i = startIndex; i <= endIndex; i++)
		        {
		        	CodeString str = src.getItem(i);
		        	if (CompilerHelper.IsComment(str)) continue;
		        	if (CompilerHelper.IsConstant(str)) continue;
		            if (str.equals(charOfLeftPair))
		            { 
		            	if (indexFirstChar==-1) indexFirstChar = i;
		                stack.Push(charOfLeftPair);
		            }
		            else if (str.equals(charOfRightPair))
		            {
		            	if (stack.len==2) {
		            	}
		            	if (stack.len>0)
		                {
		            		stack.Pop();
		            		if (stack.len==0) {
		            			return i;
		            		}
		                }
		            }		            	
		        } // for	        	
	        }// isReverse==false
	        else {
	        	// rightPair를 먼저 추가한다.
	        	stack.Push(charOfRightPair);
	        	for (i = endIndex; i >= startIndex; i--)
		        {
		        	CodeString str = src.getItem(i);
		        	if (CompilerHelper.IsComment(str)) continue;
		        	if (CompilerHelper.IsConstant(str)) continue;
		            if (str.equals(charOfRightPair))
		            { 
		            	if (indexFirstChar==-1) indexFirstChar = i;
		                stack.Push(charOfRightPair);
		            }
		            else if (str.equals(charOfLeftPair))
		            {
		            	if (stack.len==2) {
		            	}
		            	if (stack.len>0)
		                {
		            		stack.Pop();
		            		if (stack.len==0) {
		            			return i;
		            		}
		                }
		            }
		        } // for	        	
	        }
	        
	      
	        return -1;
	    }
	    
	    
	    public static void checkParenthesisError(Compiler compiler, HighArray_CodeString src, int startIndex, int endIndex) {
	    	if (startIndex==633) {
	    		int a;
	    		a=0;
	    		a++;
	    	}
	    	int i = startIndex;        
			while (i<=endIndex) {
				CodeString str = src.getItem(i);
	        	if (CompilerHelper.IsBlank(str) || CompilerHelper.IsComment(str)) {
	        		i++;
	        	}
	        	else if (CompilerHelper.IsIdentifier(str, compiler) || CompilerHelper.IsDefaultType(str, compiler)) {
			        i++;
	        	}
	        	else if (str.equals("[")) { // 배열원소
		        	int rightPair = 
			        		Checker.CheckParenthesis(compiler,  "[", "]", i, endIndex, false);
		        	if (rightPair==-1) {
		        		i = endIndex;
		        		break;
		        	}
		        	i = rightPair;		        	
		        	i++;
			    }
	        	else if (str.equals("(")) { // 함수호출, 타입캐스트
	        		int rightPair = 
			        		Checker.CheckParenthesis(compiler, "(", ")", i, endIndex, false);
	        		if (rightPair==-1) {
		        		i = endIndex;
		        		break;
		        	}
		        	i = rightPair;		        	
		        	i++;
	        	}
		        else if (str.equals(",")) break;
		        else if (str.equals(";")) break;
		        else if (str.equals(")")) {
		        	// )의 짝을 찾는다.
	        		int leftPair = 
			        		Checker.CheckParenthesis(compiler,  "(", ")", startIndex, i, true);
	        		if (leftPair==-1) {
		        		break;
		        	}
	        		i++;
		        }
		        else if (str.equals("]")) {
		        	// ]의 짝을 찾는다.
	        		int leftPair = 
			        		Checker.CheckParenthesis(compiler,  "[", "]", startIndex, i, true);
	        		if (leftPair==-1) {
		        		break;
		        	}
	        		i++;
		        }
		        else {
		        	i++;
		        }        	
	        }
	    }
	    
	    /** <summary>startIndex부터 endIndex까지 
	     * '{,(,['(charOfLeftPair)와 '},),]'(charOfRightPair)을 스택에 넣고 빼며 쌍이 맞는지 확인한다. 
	    * block단위로 확인해야 정확한 pair를 찾을 수 있다. 
	    * 다시말해 괄호에러를 고칠 수 있다. 처음 만난 괄호의 쌍의 인덱스를 리턴한다. 
	    * reverse가 false이면 startIndex부터 endIndex까지 인덱스를 증가시키면서 검색, 못 찾으면 -1을 리턴
		 *  reverse가 true이면 endIndex부터 startIndex까지 인덱스를 감소시키면서 검색, 못 찾으면 -1을 리턴
		 *  </summary>
		 *  @param startIndex : isReverse가 false일 경우 charOfLeftPair의 인덱스여야 한다.
		 *  그래야 괄호의 쌍이 맞는다.
		 *  @param endIndex :	isReverse가 true일 경우 charOfRightPair의 인덱스여야 한다. 
		 *  그래야 괄호의 쌍이 맞는다.*/
	    public static int CheckParenthesisWithoutCheckingSemicolon(Compiler compiler, HighArray_CodeString src, 
	    		String charOfLeftPair, String charOfRightPair, 
	    		int startIndex, int endIndex, boolean isReverse) 
	    {
	        int i;
	        
	        Stack stack = new Stack();
	        if (!isReverse) {
		        for (i = startIndex; i <= endIndex; i++)
		        {
		        	CodeString str = src.getItem(i);
		        	if (CompilerHelper.IsComment(str)) continue;
		        	if (CompilerHelper.IsBlank(str)) continue;
		            if (str.equals(charOfLeftPair))
		            { 
		                stack.Push(charOfLeftPair);
		            }
		            else if (str.equals(charOfRightPair))
		            {
		            	if (stack.len>0)
		                {
		            		stack.Pop();
		            		if (stack.len==0) {
		            			return i;
		            		}
		                }
		            }            
		        } // for
	        }
	        else {
	        	for (i = endIndex; i >= startIndex; i--)
		        {
	        		CodeString str = src.getItem(i);
		        	if (CompilerHelper.IsComment(str)) continue;
		        	if (CompilerHelper.IsBlank(str)) continue;
		            if (str.equals(charOfRightPair))
		            { 
		                stack.Push(charOfRightPair);
		            }
		            else if (str.equals(charOfLeftPair))
		            {
		            	if (stack.len>0)
		                {
		            		stack.Pop();
		            		if (stack.len==0) {
		            			return i;
		            		}
		                }
		            }            
		        } // for
	        }
	        
	        return -1;
	    }
	    
	    
	    /** <summary>startIndex부터 endIndex까지 
	     * '{,(,['(charOfLeftPair)와 '},),]'(charOfRightPair)을 스택에 넣고 빼며 쌍이 맞는지 확인한다. 
	    * block단위로 확인해야 정확한 pair를 찾을 수 있다. 
	    * 다시말해 괄호에러를 고칠 수 있다. 처음 만난 괄호의 쌍의 인덱스를 리턴한다. 
	    * reverse가 false이면 startIndex부터 endIndex까지 인덱스를 증가시키면서 검색, 못 찾으면 -1을 리턴
		 *  reverse가 true이면 endIndex부터 startIndex까지 인덱스를 감소시키면서 검색, 못 찾으면 -1을 리턴
		 *  주의사항 : 스트링에 주석이 있어서는 안된다.
		 *  </summary>*/
	    public static int CheckParenthesis(String str, 
	    		String charOfLeftPair, String charOfRightPair, 
	    		int startIndex, int endIndex, boolean isReverse) 
	    {
	        int i;
	        
	        Stack stack = new Stack();
	        if (!isReverse) {
		        for (i = startIndex; i <= endIndex; i++)
		        {
		        	char c = str.charAt(i);
		        	//if (CompilerHelper.IsComment(c)) continue;
		        	//if (CompilerHelper.IsBlank(c.c)) continue;
		            if (c==charOfLeftPair.charAt(0))
		            { 
		                stack.Push(charOfLeftPair);
		            }
		            else if (c==charOfRightPair.charAt(0))
		            {
		            	if (stack.len==2) {
		            	}
		            	if (stack.len>0)
		                {
		            		stack.Pop();
		            		if (stack.len==0) {
		            			return i;
		            		}
		                }
		            }            
		        } // for
	        }
	        else {
	        	for (i = endIndex; i >= startIndex; i--)
		        {
		        	char c = str.charAt(i);
		        	//if (CompilerHelper.IsComment(c)) continue;
		        	//if (CompilerHelper.IsBlank(c.c)) continue;
		            if (c==charOfRightPair.charAt(0))
		            { 
		                stack.Push(charOfRightPair);
		            }
		            else if (c==charOfLeftPair.charAt(0))
		            {
		            	if (stack.len==2) {
		            	}
		            	if (stack.len>0)
		                {
		            		stack.Pop();
		            		if (stack.len==0) {
		            			return i;
		            		}
		                }
		            }            
		        } // for
	        }
	        
	        return -1;
	    }
	
}
