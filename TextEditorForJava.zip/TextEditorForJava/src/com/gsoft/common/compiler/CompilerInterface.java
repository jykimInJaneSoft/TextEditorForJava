package com.gsoft.common.compiler;

import android.graphics.Color;
import android.view.View;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.Code.CodeStringType;
import com.gsoft.common.CommonGUI;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.FileHelper;
import com.gsoft.common.FileHelper.LanguageAndTextFormat;
import com.gsoft.common.IO;
import com.gsoft.common.IO_types.ReturnOfReadString;
import com.gsoft.common.IO_types.TextFormat;
import com.gsoft.common.Sizing.Rectangle;
import com.gsoft.common.compiler.Compiler_types.FindAssignStatementParams;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.Compiler_types.FindControlBlockParams;
import com.gsoft.common.compiler.Compiler_types.FindFuncCallParam;
import com.gsoft.common.compiler.Compiler_types.FindFunctionParams;
import com.gsoft.common.compiler.Compiler_types.FindVarParams;
import com.gsoft.common.compiler.Compiler_types.FindVarUseParams;
import com.gsoft.common.compiler.Compiler_types.Language;
import com.gsoft.common.compiler.Compiler_types.LoadWayOfFindClassParams;
import com.gsoft.common.compiler.Compiler_types.ModeAllOrUpdate;
import com.gsoft.common.compiler.Compiler_types_Base.Block;
import com.gsoft.common.compiler.Compiler_types_Base.Comment;
import com.gsoft.common.compiler.Compiler_types_Base.Error;
import com.gsoft.common.compiler.Compiler_types_Base.FindPackageParams;
import com.gsoft.common.compiler.Compiler_types_Base.FindStatementParams;
import com.gsoft.common.compiler.Compiler_types_Special.FindArrayInitializerParams;
import com.gsoft.common.compiler.Compiler_types_Special.FindSpecialStatementParams;
import com.gsoft.common.compiler.bytecode.ByteCodeGenerator;
import com.gsoft.common.compiler.classloader.Loader;
import com.gsoft.common.compiler.classloader.PathClassLoader;
import com.gsoft.common.compiler.debug.DebugView;
import com.gsoft.common.compiler.gui.InputTextView;
import com.gsoft.common.compiler.gui.MenuClassAndMemberList;
import com.gsoft.common.compiler.gui.MenuClassAndMemberListWhenInputtingDot;
import com.gsoft.common.compiler.gui.MenuProblemList_EditText;
import com.gsoft.common.compiler.util.Builder.RunOrDebug;
import com.gsoft.common.gui.Buttons.Button;
import com.gsoft.common.gui.Control;
import com.gsoft.common.gui.TextView;
import com.gsoft.common.gui.edittext.Edit.ScrollMode;
import com.gsoft.common.gui.edittext.EditText;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListIReset;
import com.gsoft.common.util.ArrayListInt;
import com.gsoft.common.util.HighArray_CodeChar;
import com.gsoft.common.util.HighArray_char;
import com.gsoft.common.compiler.HighArray_CodeString;
import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.CodeStringEx;
import com.gsoft.common.compiler.StringTokenizer;
import com.gsoft.common.compiler.CompilerStatic;
import com.gsoft.common.compiler.Checker;
import com.gsoft.common.compiler.CompilerCache;
import com.gsoft.common.compiler.Fullname;
import com.gsoft.common.compiler.Member;
import com.gsoft.common.compiler.Array;
import com.gsoft.common.compiler.CompilerData;
import com.gsoft.common.compiler.Number;


public class CompilerInterface extends Compiler {
	
	
	static class ThreadFindNode extends Thread {
		CompilerInterface owner;
		HighArray_CodeString src;
		int indexInmBuffer;
		
		ThreadFindNode(CompilerInterface owner, int indexInmBuffer) {
			this.owner = owner;
			this.src = owner.data.mBuffer;
			this.indexInmBuffer = indexInmBuffer;
		}
		public void run() {
			HighArray_CodeChar message = owner.findNode_ByThread( indexInmBuffer);
			if (message!=null && message.count!=0) {
				try {
					Thread.sleep(10);
				} catch (InterruptedException e) {
					
					if (Common_Settings.g_printsLog) e.printStackTrace();
				}
				CompilerStatic.textViewExpressionTreeAndMessage.initCursorAndScrollPos();
				CompilerStatic.textViewExpressionTreeAndMessage.setText(0, message);
				CompilerStatic.textViewExpressionTreeAndMessage.setHides(false);
				Control.view.postInvalidate();
			}
		}
	}
	


	/** 타입선언문에서 변수 타입이나 변수를 또는 클래스 선언문, 변수사용, 함수선언, 제어블록의 키워드부분을 
	 * 사용자가 터치시 나타나는 툴팁을 위한 호출이다.*/
	public HighArray_CodeChar findNode( int indexInmBuffer) {
		ThreadFindNode thread = new ThreadFindNode(this, indexInmBuffer);
		thread.start();
		
		return null;	
	}
	
	HighArray_CodeChar findNode_ByThread( int indexInmBuffer) {
		try{
			HighArray_CodeChar r = findNode_sub( data.mlistOfClass, indexInmBuffer);
		if (r==null) {
			r = findNode_sub( null, indexInmBuffer);			
		}
		if (r==null) {
			r = new HighArray_CodeChar(indexInmBuffer+"\n", Common_Settings.textColor);
		}
		else {
			CodeString str = new CodeString(indexInmBuffer+"\n", Common_Settings.textColor);
			//r = str.concate(r);
			r.insert(0, str);
		}
		Error err = getError(indexInmBuffer);
		CodeString errStr;
		if (err!=null) {
			errStr = new CodeString("(Error)"+err.msg+"\n", Common_Settings.keywordColor);
		}
		else errStr = new CodeString("", Common_Settings.textColor);
		
		if (r!=null) {
			//result = result.concate(r);
			r.insert(0, errStr);
		}
		
		return r;
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
			if (Common_Settings.g_printsLog) CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
		}
		return null;
		
	}
	
	public HighArray_CodeChar findNode_sub( ArrayListIReset listOfClasses, 
			int indexInmBuffer) {
		HighArray_CodeString src = this.data.mBuffer;
		CodeString str = src.getItem(indexInmBuffer);
		if (str.equals(" ") || str.equals("\r") || str.equals("\t") || str.equals("\n") || str.equals("\b")) {
			return null;
		}
		int i;
		HighArray_CodeChar r=null;
		if (listOfClasses==null) {
			r = findNode_sub_sub( null, indexInmBuffer);
			return r;
		}
		for (i=0; i<listOfClasses.count; i++) {
			FindClassParams classParams = (FindClassParams) listOfClasses.getItem(i);
			r = findNode_sub_sub( classParams, indexInmBuffer);
			if (r!=null) return r;
		}
		return r;
		
	}
	
	public Object findNode_sub2( ArrayListIReset listOfClasses, 
			int indexInmBuffer) {
		HighArray_CodeString src = this.data.mBuffer;
		CodeString str = src.getItem(indexInmBuffer);
		if (str.equals(" ") || str.equals("\r") || str.equals("\t") || str.equals("\n") || str.equals("\b")) {
			return null;
		}
		int i;
		Object r=null;
		if (listOfClasses==null) {
			r = findNode_sub_sub2( null, indexInmBuffer);
			return r;
		}
		for (i=0; i<listOfClasses.count; i++) {
			FindClassParams classParams = (FindClassParams) listOfClasses.getItem(i);
			r = findNode_sub_sub2( classParams, indexInmBuffer);
			if (r!=null) return r;
		}
		return r;
		
	}
	
	static class ResultOfFindNode_arrayIntializer_makeString_postfix {
		HighArray_CodeChar r;
		ResultOfFindNode_arrayIntializer_makeString_postfix(HighArray_CodeChar r) {
			this.r = r;
		}
	}
	
	/**int[][][] colors2 = {<br>
	{//a0<br>
		{Color.BLACK, Color.WHITE, Color.RED}, //a00<br>
		{Color.YELLOW,Color.BLUE, Color.GREEN} //a01<br>
	},
	 
	{//a1<br>
		{Color.BLACK, Color.WHITE, Color.RED}, //a10<br>
	    {Color.YELLOW,Color.BLUE, Color.GREEN} //a11<br>
	}
	};//2면 2행 3열<br>
	colors2->a0->a00->Color.BLACK, Color.WHITE, Color.RED <br>
		   ->a01->Color.YELLOW,Color.BLUE, Color.GREEN <br>
	->a1->a10->Color.BLACK, Color.WHITE, Color.RED <br>
	   ->a11->Color.YELLOW,Color.BLUE, Color.GREEN <br>
	깊이 :0    1    2*/
	public void findNode_arrayIntializer_makeString_postfix(HighArray_CodeString src, FindArrayInitializerParams topArray, FindArrayInitializerParams array, ResultOfFindNode_arrayIntializer_makeString_postfix r) {
	if (!Common_Settings.showsByteCodes()) {
		return;
	}
	if (array.listOfFindArrayInitializerParams.count>0) { // 중첩된 배열
		int i;
		for (i=0; i<array.listOfFindArrayInitializerParams.count; i++) {
			FindArrayInitializerParams child = (FindArrayInitializerParams) array.listOfFindArrayInitializerParams.getItem(i);
			findNode_arrayIntializer_makeString_postfix(src, topArray, child, r);
		}
	}
	else { // 수식, 가장 하위 노드
		CodeString indexOfArray = new CodeString("",Common_Settings.textColor);
		ArrayListInt indices = array.getIndicesOfParentArrayIncludingOwnIndex(array);
		for (int m=indices.count-1; m>=0; m--) {
			int index = indices.getItem(m);
			indexOfArray = indexOfArray.concate(new CodeString("[",Common_Settings.textColor));
			String strIndex = String.valueOf(index);
			CodeString cstrIndex = new CodeString(strIndex,Common_Settings.textColor);
			indexOfArray = indexOfArray.concate(cstrIndex).concate(new CodeString("]",Common_Settings.textColor));
		}
		String strIndexOfArray = indexOfArray.toString();
		
		int i, j, k;
		HighArray_CodeChar result = new HighArray_CodeChar("", Color.BLACK);
		HighArray_CodeChar indexOfArray2;
		for (i=0; i<array.listOfFindFuncCallParam.count; i++) {
			FindFuncCallParam funcCallParam = (FindFuncCallParam) array.listOfFindFuncCallParam.getItem(i);
			indexOfArray2 = new HighArray_CodeChar(strIndexOfArray + "["+i+"]", Common_Settings.textColor);
			result = result.concate(indexOfArray2);
			
			if (funcCallParam.expression.postfix!=null) {					
				
				// 수식트리에서 상위 노드의 포스트픽스
				// f2(1+2) 3 +
				for (j=0; j<funcCallParam.expression.postfix.length; j++) {						
					CodeStringEx token = funcCallParam.expression.postfix[j];
					result = getPostfixPrint( result, token);
				}
									
				HighArray_CodeChar r2= new HighArray_CodeChar("",Common_Settings.varUseColor);
				// 1 2 +
				// 수식트리에서 자식노드들을 방문하기위해 재귀적호출
				for (j=0; j<funcCallParam.expression.postfix.length; j++) {
					CodeStringEx token = funcCallParam.expression.postfix[j];
					for (k=0; k<token.listOfVarUses.count; k++) {
						FindVarUseParams child = null;
						try {
						child = (FindVarUseParams) token.listOfVarUses.getItem(k);
						}catch(Exception e) {
						}
						HighArray_CodeChar childStr;
						if (child!=null) {
							// child를 varUse로 recursive call
							childStr = 
								findNode_varUse_makeString_postfix( child, child.index());
							if (childStr!=null) {
								r2 = r2.concate(childStr).concate(new HighArray_CodeChar("  ",Common_Settings.textColor));
							}
							
							k = getIndex(token, child, k);
						}//if (child!=null) {
					}//for (k=0; k<token.listOfVarUses.count; k++) {
				}//for (j=0; j<funcCallParam.expression.postfix.length; j++) {
				if (!r2.equals("")) {
					result = result.concate(new HighArray_CodeChar(" --> ",Common_Settings.textColor));
					result = result.concate(r2);
				}
					
				//r = r.concat("\n");
				result = result.concate(new HighArray_CodeChar("\n",Common_Settings.textColor));
			}//if (funcCallParam.expression.postfix!=null) {
		}//for (i=0; i<array.listOfFindFuncCallParam.count; i++) {
		
		r.r = r.r.concate(result);
	}// else
	
	}
	
	/** 수식 트리를 순회한다.
	* @param src
	* @param varUse : 처음 호출시 사용자가 터치한 varUse, 아니면 자식노드의 varUse
	* @param indexInmBuffer : 처음 호출시 사용자가 터치한 varUse의 mBuffer에서의 인덱스,
	* , 아니면 자식노드의 varUse의 mBuffer에서의 인덱스
	* @return : 수식트리를 순회하면서 함수 파라미터(FindFuncCallParam)에 있는 수식의 포스트픽스 표현들의 리스트
	*/
	public HighArray_CodeChar findNode_varUse_makeString_postfix( FindVarUseParams varUse, int indexInmBuffer) {
		HighArray_CodeString src = this.data.mBuffer;
		int i, j, k;
		HighArray_CodeChar r = new HighArray_CodeChar("",Common_Settings.varUseColor);
		if (varUse.index()==5248) {
		}
		
		if (!Common_Settings.showsByteCodes()) {
			return r;
		}
		int indexOfEqual = IsLValue(src, varUse);
		
		if (indexOfEqual!=-1) { // varUse가 LValue이면
			
			int startIndex = CompilerStatic.getIndexInmListOfAllVarUses(src, data.mlistOfAllVarUses, 0, indexOfEqual+1, true);
			int endIndex=-1;
			
			
			
			HighArray_CodeChar r2= new HighArray_CodeChar("",Common_Settings.varUseColor);
			
			
			if (varUse.arrayInitializer!=null) {
				ResultOfFindNode_arrayIntializer_makeString_postfix result = new ResultOfFindNode_arrayIntializer_makeString_postfix(r);
					findNode_arrayIntializer_makeString_postfix(src, 
							varUse.arrayInitializer, varUse.arrayInitializer, result);
				return result.r;
			}
			
			if (varUse.rValue==null || varUse.rValue.expression==null) return null;
			
			if (varUse.rValue.expression.postfix==null) return r;
			
			startIndex = CompilerStatic.getIndexInmListOfAllVarUses(src, data.mlistOfAllVarUses, 0, varUse.rValue.startIndex(), true);
			endIndex = CompilerStatic.getIndexInmListOfAllVarUses(src, data.mlistOfAllVarUses, 0, varUse.rValue.endIndex(), false);
			
			
			// 수식트리에서 상위 노드의 포스트픽스를 출력한다.
			for (j=0; j<varUse.rValue.expression.postfix.length; j++) {
				CodeStringEx token = varUse.rValue.expression.postfix[j];
				r = getPostfixPrint( r, token);				
			}
			
			
			for (k=startIndex; k<=endIndex; k++) {
				if (k==35) {
				}
				FindVarUseParams child = (FindVarUseParams) data.mlistOfAllVarUses.getItem(k);
								
				HighArray_CodeChar childStr;
				r2= new HighArray_CodeChar("",Common_Settings.varUseColor);
				
				// 수식트리에서 자식노드들을 방문하기위해 재귀적호출
				childStr = findNode_varUse_makeString_postfix( child, child.index());
				if (childStr!=null) {
					r2 = r2.concate(childStr).concate(new HighArray_CodeChar("  ",Common_Settings.textColor));
				}
				
				// 중복되어 출력될수있으므로 인덱스값을 처리한 위치 다음으로 바꿔준다.
				boolean isFuncCallAndArrayElement = false;
				if (child.funcDecl!=null && child.isArrayElement)
					isFuncCallAndArrayElement = true;
				
				if (child.funcDecl!=null) {
					if (child.listOfFuncCallParams.count>0) {
						FindFuncCallParam funcCall = (FindFuncCallParam) 
							child.listOfFuncCallParams.getItem(child.listOfFuncCallParams.count-1);
						int endIndexOfFuncCall = funcCall.endIndex()+1;
						k = CompilerStatic.getIndexInmListOfAllVarUses2(data.mlistOfAllVarUses, k, endIndexOfFuncCall, true);
						k--;
					}
				}
				if (child.isArrayElement && child.listOfArrayElementParams!=null) {
					FindFuncCallParam funcCall = (FindFuncCallParam) 
							child.listOfArrayElementParams.getItem(child.listOfArrayElementParams.count-1);
					int endIndexOfFuncCall = funcCall.endIndex()+1;
					k = CompilerStatic.getIndexInmListOfAllVarUses2(data.mlistOfAllVarUses, k, endIndexOfFuncCall, true);
					k--;										
				}
				if (child.typeCast!=null && child.typeCast.funcCall!=null) {
					FindFuncCallParam funcCall = (FindFuncCallParam) child.typeCast.funcCall;
					int endIndexOfFuncCall = funcCall.endIndex()+1;
					k = CompilerStatic.getIndexInmListOfAllVarUses2(data.mlistOfAllVarUses, k, endIndexOfFuncCall, true);
					k--;
				}
				if (isFuncCallAndArrayElement && child.listOfFuncCallParams.count>0) k++;
				
				if (!r2.equals("")) {
					r = r.concate(new HighArray_CodeChar(" --> ",Common_Settings.textColor));
					r = r.concate(r2);
				}				
				
				r = r.concate(new HighArray_CodeChar("\n",Common_Settings.textColor));
			}
		}//if (IsLValue(src, varUse)!=-1) { // varUse가 LValue이면
		
		if (varUse.funcDecl!=null) {
			// f1(f2(1+2)+3)
			for (i=0; i<varUse.listOfFuncCallParams.count; i++) {
				// 파라미터 한개
				FindFuncCallParam funcCallParam = 
						(FindFuncCallParam) varUse.listOfFuncCallParams.getItem(i);
				r = getFuncCallParamTypePrint( r, funcCallParam.typeFullName);
								
				if (funcCallParam.expression!=null) {
					if (funcCallParam.expression.postfix!=null) {					
						
						// 수식트리에서 상위 노드의 포스트픽스
						// f2(1+2) 3 +
						for (j=0; j<funcCallParam.expression.postfix.length; j++) {
							
							CodeStringEx token = funcCallParam.expression.postfix[j];
							r = getPostfixPrint( r, token);
						}
						
											
						HighArray_CodeChar r2= new HighArray_CodeChar("",Common_Settings.varUseColor);
						// 1 2 +
						// 수식트리에서 자식노드들을 방문하기위해 재귀적호출
						for (j=0; j<funcCallParam.expression.postfix.length; j++) {
							CodeStringEx token = funcCallParam.expression.postfix[j];
							for (k=0; k<token.listOfVarUses.count; k++) {
								FindVarUseParams child = null;
								try {
								child = (FindVarUseParams) token.listOfVarUses.getItem(k);
								}catch(Exception e) {
								}
								HighArray_CodeChar childStr;
								if (child!=null) {
									// child를 varUse로 recursive call
									childStr = 
										findNode_varUse_makeString_postfix( child, child.index());
									if (childStr!=null) {
										r2 = r2.concate(childStr).concate(new HighArray_CodeChar("  ",Common_Settings.textColor));
									}
									
									k = getIndex(token, child, k);
								}//if (child!=null) {
							}//for (k=0; k<token.listOfVarUses.count; k++) {
						}//for (j=0; j<funcCallParam.expression.postfix.length; j++) {
						if (!r2.equals("")) {
							r = r.concate(new HighArray_CodeChar(" --> ",Common_Settings.textColor));
							r = r.concate(r2);
						}
						
						r = r.concate(new HighArray_CodeChar("\n",Common_Settings.textColor));
					}//if (funcCallParam.expression.postfix!=null) {
					
				} //if (funcCallParam.expression!=null) {
			} //for (i=0; i<varUse.listOfFuncCallParams.count; i++) {
		} // if (varUse.funcDecl!=null) {
		
		
		if (varUse.isArrayElement) { // 배열첨자 처리
			if (varUse.listOfArrayElementParams==null) return r;
			for (i=0; i<varUse.listOfArrayElementParams.count; i++) {
				FindFuncCallParam funcCallParam = 
						(FindFuncCallParam) varUse.listOfArrayElementParams.getItem(i);
								
				if (funcCallParam.expression!=null) {
					if (funcCallParam.expression.postfix!=null) {					
						
						// 수식트리에서 상위 노드의 포스트픽스
						// f2(1+2) 3 +
						for (j=0; j<funcCallParam.expression.postfix.length; j++) {
							CodeStringEx token = funcCallParam.expression.postfix[j];
							r = getPostfixPrint( r, token);
						}
					
											
						HighArray_CodeChar r2= new HighArray_CodeChar("",Common_Settings.varUseColor);
						// 1 2 +
						// 수식트리에서 자식노드들을 방문하기위해 재귀적호출
						for (j=0; j<funcCallParam.expression.postfix.length; j++) {
							CodeStringEx token = funcCallParam.expression.postfix[j];
							if (token==null) continue;
							for (k=0; k<token.listOfVarUses.count; k++) {
								FindVarUseParams child = 
										(FindVarUseParams) token.listOfVarUses.getItem(k);
								HighArray_CodeChar childStr;
								if (child!=null) {
									// child를 varUse로 recursive call 
									childStr = 
										findNode_varUse_makeString_postfix( child, child.index());
									if (childStr!=null) {
										r2 = r2.concate(childStr).concate(new HighArray_CodeChar("  ",Common_Settings.textColor));
									}
									
									k = getIndex(token, child, k);
								}//if (child!=null) {
							}
						}
						if (!r2.equals("")) {
							r = r.concate(new HighArray_CodeChar(" --> ",Common_Settings.textColor));
							r = r.concate(r2);
						}
						r = r.concate(new HighArray_CodeChar("\n",Common_Settings.textColor));
					}//if (funcCallParam.expression.postfix!=null) {
					
				} //if (funcCallParam.expression!=null) {
			} //for (i=0; i<varUse.listOfFuncCallParams.count; i++) {
		}//else if (varUse.isArrayElement) {
		
		if (varUse.typeCast!=null && varUse.typeCast.funcCall!=null) { // (타입)(수식)인 경우 varUse는 타입
			FindFuncCallParam funcCallParam = varUse.typeCast.funcCall;
						
			if (funcCallParam.expression!=null) {
				if (funcCallParam.expression.postfix!=null) {					
					
					// 수식트리에서 상위 노드의 포스트픽스
					// f2(1+2) 3 +
					for (j=0; j<funcCallParam.expression.postfix.length; j++) {
						CodeStringEx token = funcCallParam.expression.postfix[j];
						r = getPostfixPrint( r, token);
					}
					
										
					//String r2="";
					HighArray_CodeChar r2= new HighArray_CodeChar("",Common_Settings.varUseColor);
					// 1 2 +
					// 수식트리에서 자식노드들을 방문하기위해 재귀적호출
					for (j=0; j<funcCallParam.expression.postfix.length; j++) {
						CodeStringEx token = funcCallParam.expression.postfix[j];
						for (k=0; k<token.listOfVarUses.count; k++) {
							FindVarUseParams child = 
									(FindVarUseParams) token.listOfVarUses.getItem(k);
							HighArray_CodeChar childStr;
							if (child!=null) {
								// child를 varUse로 recursive call 
								childStr = 
									findNode_varUse_makeString_postfix( child, child.index());
								if (childStr!=null) {
									r2 = r2.concate(childStr).concate(new HighArray_CodeChar("  ",Common_Settings.textColor));
								}
								
								k = getIndex(token, child, k);
							}//if (child!=null) {
						}
					}
					if (!r2.equals("")) {
						r = r.concate(new HighArray_CodeChar(" --> ",Common_Settings.textColor));
						r = r.concate(r2);
					}
					r = r.concate(new HighArray_CodeChar("\n",Common_Settings.textColor));
				}//if (funcCallParam.expression.postfix!=null) {
				
			} //if (funcCallParam.expression!=null) {
			
		}//else if (varUse.typeCast!=null) {
		
		if (r.equals("") && indexOfEqual==-1) { // 일반변수(배열이나 함수호출이 아닌), 상수 등
			return null;
		}
		
		return r;
	
	} // findNode_varUse_makeString_postfix
	
	
	
	public HighArray_CodeChar findNode_varUse_makeString(FindVarUseParams varUse, int indexInmBuffer, int coreThreadID) {
		HighArray_CodeString src = this.data.mBuffer;
		
		if (varUse.memberDecl!=null) {
			 
			if (varUse.memberDecl instanceof FindClassParams) { // 멤버클래스
				FindClassParams classDecl = (FindClassParams) varUse.memberDecl;
				//if (classDecl.parent!=null) { // 클래스를 포함하는 클래스
					String fileName = classDecl.compiler.data.filename;
					
					String docuComment = null;
					if (classDecl.docuComment!=null && classDecl.docuComment.str!=null) {
						docuComment = classDecl.docuComment.str;
					}
					String typeName;
					
					typeName = classDecl.name;
									
					String message = classDecl.accessModifier.toString();
					
					if (docuComment!=null)
						return new HighArray_CodeChar(fileName + "\n\n" + docuComment + "\n" + message + typeName,Common_Settings.textColor);
					else
						return new HighArray_CodeChar(fileName + "\n\n" + message + typeName,Common_Settings.textColor);
				//}
			}	// if (varUse.memberDecl instanceof FindClassParams) { // 멤버클래스
			else if (varUse.memberDecl instanceof FindPackageParams) { // 패키지
				FindPackageParams packageDecl = (FindPackageParams) varUse.memberDecl;
				//if (packageDecl.parent!=null) { // 클래스를 포함하는 클래스
					
					String typeName;
					typeName = packageDecl.getFullName(0);
					typeName = "P : " + typeName;
					return new HighArray_CodeChar(typeName,Common_Settings.textColor);
				//}
			}	// else if (varUse.memberDecl instanceof FindPackageParams) { // 패키지	
		} // if (varUse.memberDecl!=null) {
		else if (varUse.varDecl!=null) {
			FindVarParams varDecl = null;
			if (varUse.varDeclBeforeProcessLocalVars!=null) {
				varDecl = varUse.varDeclBeforeProcessLocalVars;
			}
			else {
				varDecl = varUse.varDecl;
			}
			if (!varUse.isLocal) { // 멤버변수		
				if (varDecl.parent!=null) { // 변수선언을 포함하는 클래스
					String fileName = varDecl.compiler.data.filename;
					
					String docuComment = null;
					if (varDecl.docuComment!=null && varDecl.docuComment.str!=null) {
						docuComment = varDecl.docuComment.str;
					}
					// 클래스이름뒤에 "."이 붙게됨을 주의한다.
					FindClassParams classP = (FindClassParams)varDecl.parent; 
					String classFullNameDot = "";
					classFullNameDot = classP.name + ".";
					
					String typeName = null;
					String varName;
					if (!varDecl.isThis  && !varDecl.isSuper) { // 외부 클래스
						typeName = varDecl.typeName;
					}
					else {
						if (!varDecl.isThis && !varDecl.isSuper)
							typeName = varDecl.getType(varDecl.typeStartIndex(), varDecl.typeEndIndex(), coreThreadID);
						else if (varDecl.isThis) {
							typeName = classP.name;
						}
						else if (varDecl.isSuper) {
							typeName = classP.classNameToExtend;
						}
					}
				
					if (!varDecl.isThis && !varDecl.isSuper) {// 외부 클래스
						varName = varDecl.fieldName;
					}
					else if (varDecl.isThis)
						varName = "this";
					else if (varDecl.isSuper)
						varName = "super";
					else varName = typeName;
					
					if (!varDecl.isThis && varDecl.accessModifier!=null) {
					} else if (varDecl.isThis || varDecl.isSuper) {
					}
				
					String message = null;
					if (varDecl.accessModifier!=null) {
						message = varDecl.accessModifier.toString() + "Member Variable ";
					}
					
					if (docuComment!=null)
						return new HighArray_CodeChar(fileName + "\n\n" + docuComment + "\n" + message + typeName + " " + classFullNameDot + varName,Common_Settings.textColor);
					else
						return new HighArray_CodeChar(fileName + "\n\n" + message + typeName + " " + classFullNameDot + varName, Common_Settings.textColor);
				}
			}
			else { // 지역변수
				if (varDecl.parent!=null) {						
					FindFunctionParams func = (FindFunctionParams)CompilerStatic.getParent((Block)varDecl.parent); 
					String funcName = ((FindClassParams)func.parent).name + "." + func.name;
					String returnTypeOfFunc;
					returnTypeOfFunc = func.getReturnType( 
							func.returnTypeStartIndex(), func.returnTypeEndIndex(), coreThreadID);
					String typeName = varDecl.getType(varDecl.typeStartIndex(), varDecl.typeEndIndex(), coreThreadID);
								
					String varName = src.getItem(varDecl.varNameIndex()).toString();
					String scope = "(scope : " + varDecl.startIndexOfScope + ", " + varDecl.endIndexOfScope + ")";
					return new HighArray_CodeChar("Local Variable " + typeName + " " + varName + scope + " - " + returnTypeOfFunc + " " + funcName + "()", Common_Settings.textColor);
				}
			}
		} // if (varUse.varDecl!=null) {
		else if (varUse.funcDecl!=null) { // function call
			FindFunctionParams func = varUse.funcDecl;
			String fileName = func.compiler.data.filename;
			int k;
			String docuComment = null;
			if (func.docuComment!=null && func.docuComment.str!=null) {
				docuComment = func.docuComment.str;
			}
			
			String className = "";
			if (func.parent!=null) {
				FindClassParams classP = (FindClassParams)func.parent;
				className = classP.name + ".";
			}
			
			String funcName;
			funcName = func.name;
			String returnTypeOfFunc;
			returnTypeOfFunc = func.getReturnType( 
					func.returnTypeStartIndex(), func.returnTypeEndIndex(), coreThreadID);
					
			String args = "";
			for (k=0; k<func.listOfFuncArgs.count; k++) {
				FindVarParams arg = (FindVarParams)func.listOfFuncArgs.getItem(k);
				if (arg.fieldName==null) {// 외부 클래스
					String typeName = arg.typeName;
					args += typeName;
				}
				else {
					String typeName = arg.getType(arg.typeStartIndex(), arg.typeEndIndex(), coreThreadID);
					args += typeName + " " + arg.fieldName;
				}
				if (k!=func.listOfFuncArgs.count-1) {
					args += ", ";
				}
			}
			
			//String message = isStatic ? "S : " : "";
			String message = func.accessModifier.toString();
			
			if (data.packageName.equals("")) { // C의 경우
				
			}
			else {
			}
			
			if (docuComment!=null)
				return new HighArray_CodeChar(fileName + "\n\n" + docuComment + "\n" + message + returnTypeOfFunc + " " + className + funcName + "(" + args + ")", Common_Settings.textColor);
			else 
				return new HighArray_CodeChar(fileName + "\n\n" + message + returnTypeOfFunc + " " + className + funcName + "(" + args + ")", Common_Settings.textColor);
		} // else if (varUse.funcDecl!=null) { // function call
		else {
			String varUseName = src.getItem(varUse.index()).str;
			HighArray_CodeChar varUseName2 = new HighArray_CodeChar(varUseName,Common_Settings.textColor);
			if (CompilerHelper.IsDefaultType(varUseName, this)) { // a = new int[5+1]; 에서 int
				return varUseName2;
			}
			else {
				int numberType = Number.IsNumber2(varUseName2);
				if (numberType!=0) {
					HighArray_CodeChar type = new HighArray_CodeChar(" : " + 
							Number.getNumberString(numberType),Common_Settings.keywordColor);
					
					return varUseName2.concate(type);
				}				
			}
		}
		
		
		// varUse가 함수호출일 경우 함수에 바인딩이 안되면 파라미터들과 그것의 타입 리스트를 출력한다.
		if (varUse.listOfFuncCallParams!=null && varUse.listOfFuncCallParams.count>0 &&
			varUse.funcDecl==null) {
			int i;
			HighArray_char r = new HighArray_char(20);
			r.add("func decl not bound. Check a parameter list.\n\n");
			for (i=0; i<varUse.listOfFuncCallParams.count; i++) {
				FindFuncCallParam funcCall = (FindFuncCallParam) varUse.listOfFuncCallParams.getItem(i);
				String str = Fullname.getFullName(src, funcCall.startIndex(), funcCall.endIndex()).str;
				r.add(str);
				r.add(" : ");
				if (funcCall.typeFullName!=null) 	r.add(funcCall.typeFullName.str);
				r.add('\n');
			}
			
			printAllFunctionsHavingFuncName(varUse, coreThreadID, r);
			
			
			return new HighArray_CodeChar(r.getItems(), Common_Settings.textColor);
		}
	
		return null;
	}
	
	/** 함수호출이 매핑이 안되면 동일한 함수 이름을 갖는 모든 함수들을 출력해서
		사용자가 찾기 쉽도록 한다.*/
	void printAllFunctionsHavingFuncName(FindVarUseParams varUse, int coreThreadID, HighArray_char r) {
		FindClassParams parentClass = null;
		ArrayList allFunctions;
		if (varUse.parent!=null) {
			FindVarUseParams parentVarUse = varUse.parent;
			if (parentVarUse.varDecl!=null) {
				String typeName = parentVarUse.varDecl.typeName;
				parentClass = Loader.loadClass(this, typeName, coreThreadID);
			}
			else if (parentVarUse.funcDecl!=null) {
				String returnTypeName = parentVarUse.funcDecl.returnType;
				parentClass = Loader.loadClass(this, returnTypeName, coreThreadID);
			}
			else if (parentVarUse.memberDecl!=null) parentClass = (FindClassParams) parentVarUse.memberDecl;
			
			allFunctions = Member.getAllFunctionsHavingFuncName(this, parentClass, varUse, coreThreadID);
		}
		else {
			parentClass = varUse.classToDefineThisVarUse;
			// member func or constuctor( new AAA(...) )
			allFunctions = Member.getAllFunctionsHavingFuncName(this, parentClass, varUse, coreThreadID);
			//String shortName = CompilerHelper.getShortName(parentClass.name);
			//if (!shortName.equals(varUse.name)) {
			if (allFunctions.count==0) {
				// constuctor( new AAA(...) )
				String fullTypeName = Fullname.getFullNameType2(this, varUse.name, varUse.index(), coreThreadID);
				parentClass = Loader.loadClass(this, fullTypeName, coreThreadID);
				allFunctions = Member.getAllFunctionsHavingFuncName(this, parentClass, varUse, coreThreadID);			
			}
		}
		r.add("\n\n<All Function List>\n");
		
		for (int i=0; i<allFunctions.count; i++) {
			FindFunctionParams func = (FindFunctionParams) allFunctions.getItem(i);
			String parentClassName = ((FindClassParams)func.parent).name; 
			r.add(parentClassName+".");
			r.add(func.toString());
			r.add('\n');
		}
	}
	
	
	/** 클래스 정의나 enum 정의의 머릿부분을 사용자가 터치시 호출이 된다.*/
	public HighArray_CodeChar findNode_class_makeString( FindClassParams classP, int indexInmBuffer) {
		HighArray_CodeString src = this.data.mBuffer;
		if (classP.classNameIndex()==indexInmBuffer) {		// 클래스 정의문에서 클래스이름을 터치시
			String docuComment = null;
			if (classP.docuComment!=null && classP.docuComment.str!=null) {
				docuComment = classP.docuComment.str;
			}
			/*if (classP.accessModifier!=null)
					isStatic = classP.accessModifier.isStatic;					
			String message = isStatic ? "S" : "";*/
			String message = classP.accessModifier.toString();
			if (!classP.isEnum) { // class
				if (message.length()>0) {
					message = message + ", Class : ";
				}
				else {
					message = "Class : ";
				}
			}
			else { // enum
				if (message.length()>0) {
					message = message + ", Enum : ";
				}
				else {
					message = "Enum : ";
				}
			}
			
			String classNameStr = Fullname.getFullNameExceptPackageName(src, classP  );
			classNameStr = classNameStr.substring(0, classNameStr.length()-1);
			if (docuComment!=null)
				return new HighArray_CodeChar(docuComment + "\n" + message + data.packageName + "." + classNameStr, Common_Settings.textColor);
			else
				return new HighArray_CodeChar(message + data.packageName + "." + classNameStr, Common_Settings.textColor);
		}//if (classP.classNameIndex==indexInmBuffer) {		// 변수를 터치시
		return null;
	}
	
	/** 사용자가 변수선언을 터치시 호출된다.
	 * @param coreThreadID */
	public HighArray_CodeChar findNode_var_makeString( FindVarParams var, int indexInmBuffer, int coreThreadID) {
		HighArray_CodeString src = this.data.mBuffer;
		src = var.compiler.data.mBuffer;
		String packageName = var.compiler.data.packageName; 
		
		HighArray_CodeChar r;
		// var.varNameIndex()==-1인 경우는 MenuClassAndMemberList에서 상속 변수선언을 터치한 경우이다.
		if (var.varNameIndex()==indexInmBuffer || var.varNameIndex()==-1) {		// 변수를 터치시
			CodeString varName = new CodeString(var.fieldName,Common_Settings.textColor);
			if (var.isMemberOrLocal || var.isEnumElement) {
				String docuComment = null;
				if (var.docuComment!=null && var.docuComment.str!=null) {
					docuComment = var.docuComment.str;
				}
				/*if (var.accessModifier!=null)
						isStatic = var.accessModifier.isStatic;					
				String message = isStatic ? "S,M : " : "M : ";*/
				String message = var.accessModifier.toString();
				message += "Member Variable ";
				String typeName = "";
				//if (var.typeStartIndex()!=-1 && var.typeEndIndex()!=-1)
				//	typeName = var.getType(src, var.typeStartIndex(), var.typeEndIndex());
				typeName = var.typeName;
				String className;
				if (var.varNameIndex()!=-1) {
					className = Fullname.getFullNameExceptPackageName(src, (FindClassParams)CompilerStatic.getParent( (Block)(var.parent) ) );
					if (docuComment!=null)
						return new HighArray_CodeChar(docuComment + "\n" + message + typeName + " " + packageName + "." + className + varName, Common_Settings.textColor);
					else
						return new HighArray_CodeChar(message + typeName + " " + packageName + "." + className + varName, Common_Settings.textColor);
				}
				else {
					className = ((FindClassParams)var.parent).name;
					if (docuComment!=null)
						return new HighArray_CodeChar(docuComment + "\n" + message + typeName + " " + className + "." + varName, Common_Settings.textColor);
					else
						return new HighArray_CodeChar(message + typeName + " " + className + "." + varName, Common_Settings.textColor);
				}
				
				
			}
			else if (!var.isMemberOrLocal) {
				FindFunctionParams func = (FindFunctionParams)CompilerStatic.getParent( (Block)(var.parent) ); 
				String funcName = ((FindClassParams)func.parent).name + "." + src.getItem(func.functionNameIndex()).toString();
				String returnTypeOfFunc;
				if (func.returnTypeEndIndex()<0) {
					returnTypeOfFunc = "";
				}
				else {
					returnTypeOfFunc = func.getReturnType( 
							func.returnTypeStartIndex(), func.returnTypeEndIndex(), coreThreadID);
				}
				String typeName = var.getType(var.typeStartIndex(), var.typeEndIndex(), coreThreadID);
				
				String scope = "(scope : " + var.startIndexOfScope + ", " + var.endIndexOfScope + ")";
				
				return new HighArray_CodeChar("Local Variable " + typeName + " " + varName + scope + " - " + returnTypeOfFunc + " " + funcName + "()", Common_Settings.textColor);
				
			}
			
			
		}//if (var.varNameIndex()==indexInmBuffer) {		// 변수를 터치시
		// 변수선언의 타입을 터치시
		else if (var.typeStartIndex()<=indexInmBuffer && indexInmBuffer<=var.typeEndIndex()) {
			String docuComment = null;
			FindClassParams typeClassParams = Loader.loadClass(this, var.typeName, coreThreadID);
			if (typeClassParams!=null && typeClassParams.docuComment!=null && typeClassParams.docuComment.str!=null) {
				docuComment = typeClassParams.docuComment.str;
			}
			if (docuComment!=null) {
				r = new HighArray_CodeChar(docuComment + "\n" + 
						var.getType(var.typeStartIndex(), var.typeEndIndex(), coreThreadID), 
						Common_Settings.textColor);
			}
			else {
				r = new HighArray_CodeChar(var.getType(var.typeStartIndex(), var.typeEndIndex(), coreThreadID), 
						Common_Settings.textColor);
			}
			return r;
		}
		
		return null;
	}
	
	
	public FindStatementParams findLocationWhenNotPaired( ArrayListIReset listOfClasses, 
			int indexInmBuffer) {
		ArrayList listFuncs = new ArrayList(3);
		int i;
		for (i=0; i<data.mlistOfAllFunctions.count; i++) {
			FindFunctionParams func = (FindFunctionParams) data.mlistOfAllFunctions.getItem(i);
			if (func.startIndex()<=indexInmBuffer && indexInmBuffer<=func.endIndex()) {
				listFuncs.add(func);
			}
		}
		if (listFuncs.count==2) {
			return (FindFunctionParams)listFuncs.getItem(1);
		}
		else if (listFuncs.count==1) {
			return (FindFunctionParams)listFuncs.getItem(0);
		}
		return null;
		
	}
	
	
	
	public FindStatementParams findLocation( ArrayListIReset mlistOfClass, int indexInmBuffer) {
		for (int q=0; q<mlistOfClass.count; q++) {
			FindClassParams classParams = (FindClassParams)mlistOfClass.getItem(q);
			FindStatementParams r = findLocation_sub( classParams, indexInmBuffer);
			if (r!=null) return r;
		}
		return null;
	}
	
	
	
	/**@param classParams : 처음 호출시에는 최상위클래스*/
	public FindStatementParams findLocation_sub( FindClassParams classParams, int indexInmBuffer) {
		if (classParams==null) return null;
		if (classParams.startIndex()<=indexInmBuffer && indexInmBuffer<=classParams.endIndex()) {
			int i;
			if (classParams.childClasses!=null) {
				for (i=0; i<classParams.childClasses.count; i++) {
					FindClassParams child = (FindClassParams) classParams.childClasses.getItem(i);
					FindStatementParams r = findLocation_sub( child, indexInmBuffer);
					if (r!=null) return r;
				}
			}
			for (i=0; i<classParams.listOfFunctionParams.count; i++) {
				FindFunctionParams func = (FindFunctionParams) classParams.listOfFunctionParams.getItem(i);
				if (func.startIndex()<=indexInmBuffer && indexInmBuffer<=func.endIndex()) {
					return func;
				}
			}
			
			for (i=0; i<classParams.listOfVariableParams.count; i++) {
				FindVarParams var = (FindVarParams) classParams.listOfVariableParams.getItem(i);
				if (var.startIndex()<=indexInmBuffer && indexInmBuffer<=var.endIndex()) {
					return var;
				}
			}
			
			return classParams;
		}
		return null;
	}
	
	
	/** 타입선언문에서 변수 타입이나 변수를 사용자가 터치시 나타나는 툴팁을 위한 호출의 sub_sub이다.*/
	public HighArray_CodeChar findNode_sub_sub( FindClassParams classParams, int indexInmBuffer) {
		if (classParams==null) {
			Object node=null;
			node = findNode_NodeType( classParams, indexInmBuffer);			
			if (node instanceof FindVarUseParams) {
				FindVarUseParams varUse = (FindVarUseParams) node;
				
				HighArray_CodeChar r = null;			
				
				HighArray_CodeChar r1 =  findNode_varUse_makeString_postfix( varUse, indexInmBuffer);
				
				if (r1!=null) {
					r = r1.concate(new HighArray_CodeChar("\n",Common_Settings.textColor));
					HighArray_CodeChar r2 = findNode_varUse_makeString(varUse, indexInmBuffer, 0);
					if (r2!=null) {
						r = r.concate(r2);
					}
				}
				else {
					HighArray_CodeChar r2 = findNode_varUse_makeString(varUse, indexInmBuffer, 0);
					r = r2;
				}
				return r;
			} 
		}//if (classParams==null) {
		else if (classParams.startIndex()<=indexInmBuffer && indexInmBuffer<=classParams.endIndex()) {
			HighArray_CodeChar r=null;
			int i;
			if (classParams.childClasses!=null) {
				for (i=0; i<classParams.childClasses.count; i++) {
					FindClassParams child = (FindClassParams) classParams.childClasses.getItem(i);
					r = findNode_sub_sub( child, indexInmBuffer);
					if (r!=null) return r;
				}
			}
			
			Object node=null;
			node = findNode_NodeType( classParams, indexInmBuffer);
			
			if (node==null) {
				
			}//if (node==null) {
			
			if (node instanceof FindClassParams) {
				FindClassParams classP = (FindClassParams)node;
				
				String byteCodeStr = null;
				if (CompilerStatic.errors.count==0) {
					ByteCodeGenerator codeGen = new ByteCodeGenerator(this, this.data.mlistOfClass, 0);
					byteCodeStr = codeGen.print_findNode(node, null);
				}
				
				
				// 바이트코드 제너레이터에서 새로 추가되는 에러들을 menuProblemList_EditText에 넣는다.
				EditText[] problemList = CompilerStatic.menuProblemList_EditText.getMenuListEditTexts(CompilerStatic.errors);
				CompilerStatic.menuProblemList_EditText.setEditTexts(problemList);
				
				
				HighArray_CodeChar byteCodes = null;
				int colorByteCodes = Common_Settings.textColor;
				if (CompilerStatic.errors.count>0) {
					byteCodeStr = "(Error) Errors occurred while compiling. Refer to problems list.\n\n";
					colorByteCodes = Common_Settings.keywordColor;
				}
				else {
					CommonGUI.loggingForMessageBox.setText(true, "Succeeded building "+classP.name, false);
					CommonGUI.loggingForMessageBox.setHides(false);
				}
				
				if (byteCodeStr!=null) {
					byteCodes = new HighArray_CodeChar(byteCodeStr, colorByteCodes);
				}
				HighArray_CodeChar classString = 
						findNode_class_makeString( classP, indexInmBuffer);
				if (classString!=null) {
					if (byteCodes!=null) {
						return byteCodes.concate(classString);
					}					
				}
				return byteCodes;
			}// if (node instanceof FindVarParams) {
			
			else if (node instanceof FindVarUseParams) {
				FindVarUseParams varUse = (FindVarUseParams) node;
				
				if (CommonGUI.editText_compiler.runOrDebug==RunOrDebug.Debug) {
					CommonGUI.textViewDebug.callDebugCommand(varUse);
				}
				
				HighArray_CodeChar result = null;
				
				mByteCodeResult.reset2();
				ByteCodeGenerator codeGen = new ByteCodeGenerator(this, this.data.mlistOfClass, 0);
				String byteCodeStr = codeGen.print_findNode(node, mByteCodeResult);
				
				// 바이트코드 제너레이터에서 새로 추가되는 에러들을 menuProblemList_EditText에 넣는다.
				EditText[] problemList = CompilerStatic.menuProblemList_EditText.getMenuListEditTexts(CompilerStatic.errors);
				CompilerStatic.menuProblemList_EditText.setEditTexts(problemList);
				
				HighArray_CodeChar byteCode = null;
				if (byteCodeStr!=null) {
					byteCode = new HighArray_CodeChar(byteCodeStr, Common_Settings.textColor);
				}
						
				HighArray_CodeChar r1 =  findNode_varUse_makeString_postfix( varUse, indexInmBuffer);
												
				if (r1!=null) {
					result = r1.concate(new CodeString("\n",Common_Settings.textColor));
					
					HighArray_CodeChar r2 = findNode_varUse_makeString( varUse, indexInmBuffer, 0);
					if (r2!=null) {
						result = result.concate(r2);
					}
				}
				else {
					HighArray_CodeChar r2 = findNode_varUse_makeString( varUse, indexInmBuffer, 0);
					result = r2;
				}
				
				if (result!=null) {
					if (byteCode!=null) {
						result = byteCode.concate(result);
					}
				}
				else {
					result = byteCode;
				}
				
				return result;
			}//else if (node instanceof FindVarUseParams) {
			else if (node instanceof FindVarParams) {
				FindVarParams var = (FindVarParams)node;
				if (CommonGUI.editText_compiler.runOrDebug==RunOrDebug.Debug) {
					CommonGUI.textViewDebug.callDebugCommand(var);
				}
				return findNode_var_makeString( var, indexInmBuffer, 0);
			}// if (node instanceof FindVarParams) {
			
			else if (node instanceof FindFunctionParams) {
				HighArray_CodeChar result = null;
				FindFunctionParams func = (FindFunctionParams) node;
				result = findNode_func_makeString( func, indexInmBuffer, 0);
								
				HighArray_CodeChar byteCode = null;
				
				mByteCodeResult.reset2();
				
				ByteCodeGenerator codeGen = new ByteCodeGenerator(this, this.data.mlistOfClass, 0);
				String byteCodeStr = codeGen.print_findNode(node, mByteCodeResult);
				
				// 바이트코드 제너레이터에서 새로 추가되는 에러들을 menuProblemList_EditText에 넣는다.
				EditText[] problemList = CompilerStatic.menuProblemList_EditText.getMenuListEditTexts(CompilerStatic.errors);
				CompilerStatic.menuProblemList_EditText.setEditTexts(problemList);
				
				if (byteCodeStr!=null) {
					byteCode = new HighArray_CodeChar(byteCodeStr, Common_Settings.textColor);
					if (result!=null) {
						byteCode = byteCode.concate(result);
					}					
					result = byteCode;
				}			
				
				return result;
			}//else if (node instanceof FindFunctionParams) {
			else if (node instanceof FindControlBlockParams) {
				FindControlBlockParams controlBlock = (FindControlBlockParams) node;
				
				HighArray_CodeChar result = null;
				
				HighArray_CodeChar byteCode = null;
				
				mByteCodeResult.reset2();
				ByteCodeGenerator codeGen = new ByteCodeGenerator(this, this.data.mlistOfClass, 0);
				String byteCodeStr = codeGen.print_findNode(node, mByteCodeResult);	
				
				// 바이트코드 제너레이터에서 새로 추가되는 에러들을 menuProblemList_EditText에 넣는다.
				EditText[] problemList = CompilerStatic.menuProblemList_EditText.getMenuListEditTexts(CompilerStatic.errors);
				CompilerStatic.menuProblemList_EditText.setEditTexts(problemList);
				
				if (byteCodeStr!=null) {
					byteCode = new HighArray_CodeChar(byteCodeStr, Common_Settings.textColor);
					result = byteCode;
				}
				
				HighArray_CodeChar makeString = findNode_controlBlock_makeString( controlBlock, indexInmBuffer);
				if (result!=null) {
					if (makeString!=null) {
						result = result.concate(makeString);
					}
				}
				
				return result;
			}
			else if (node instanceof FindSpecialStatementParams) {
				//FindSpecialStatementParams specialStatement = (FindSpecialStatementParams) node;
				
				HighArray_CodeChar result = null;
				
				HighArray_CodeChar byteCode = null;
				
				mByteCodeResult.reset2();
				ByteCodeGenerator codeGen = new ByteCodeGenerator(this, this.data.mlistOfClass, 0);
				String byteCodeStr = codeGen.print_findNode(node, mByteCodeResult);	
				
				// 바이트코드 제너레이터에서 새로 추가되는 에러들을 menuProblemList_EditText에 넣는다.
				EditText[] problemList = CompilerStatic.menuProblemList_EditText.getMenuListEditTexts(CompilerStatic.errors);
				CompilerStatic.menuProblemList_EditText.setEditTexts(problemList);
				
				if (byteCodeStr!=null) {
					byteCode = new HighArray_CodeChar(byteCodeStr, Common_Settings.textColor);
					result = byteCode;
				}
				
				return result;
			}
			
		}//else if (classParams.startIndex()<=indexInmBuffer/* && indexInmBuffer<=classParams.endIndex()*/) { 
		
		return null;
		
	}
	
	
	public Object findNode_sub_sub2( FindClassParams classParams, int indexInmBuffer) {
		if (classParams==null) {
			Object node=null;
			node = findNode_NodeType( classParams, indexInmBuffer);			
			return node;
		}//if (classParams==null) {
		else if (classParams.startIndex()<=indexInmBuffer && indexInmBuffer<=classParams.endIndex()) {
			Object r=null;
			int i;
			if (classParams.childClasses!=null) {
				for (i=0; i<classParams.childClasses.count; i++) {
					FindClassParams child = (FindClassParams) classParams.childClasses.getItem(i);
					r = findNode_sub_sub2( child, indexInmBuffer);
					if (r!=null) return r;
				}
			}
			
			Object node=null;
			node = findNode_NodeType( classParams, indexInmBuffer);
			return node;
			
			
		}//else if (classParams.startIndex()<=indexInmBuffer/* && indexInmBuffer<=classParams.endIndex()*/) { 
		return null;
		
	}
	
	
	
	
	static enum StatementType {
		ClassHead,
		ClassInitializer,
		FunctionHead,
		FunctionBody
	}
	
	static class RetunOffindStatement_main {
		StatementType type;
		FindStatementParams statement;
		RetunOffindStatement_main(StatementType type, FindStatementParams statement) {
			this.type = type;
			this.statement = statement;
		}
	}
	
	
	/**Calls to get current statement when debuging 
	 * @param classParams : 처음 호출시에는 최상위클래스*/
	public FindStatementParams findStatement_main_debuging( FindClassParams classParams, int indexInmBuffer) {
		if (classParams.startIndex()<=indexInmBuffer && indexInmBuffer<=classParams.endIndex()) {
			int i;
			if (classParams.childClasses!=null) {
				for (i=0; i<classParams.childClasses.count; i++) {
					FindClassParams child = (FindClassParams) classParams.childClasses.getItem(i);
					FindStatementParams r = findStatement_main_debuging( child, indexInmBuffer);
					if (r!=null) return r;
				}
			}
			for (i=0; i<classParams.listOfStatements.count; i++) {
				FindStatementParams statement = (FindStatementParams) classParams.listOfStatements.getItem(i);			
				int startIndex = statement.startIndex();
				int endIndex = statement.endIndex();
				if (startIndex<=indexInmBuffer && indexInmBuffer<=endIndex) {
					if (statement instanceof FindVarParams) {
						// 클래스의 초기화 문장
						FindVarParams var = (FindVarParams) statement;
						
						return var;
					}
					else if (statement instanceof FindAssignStatementParams) {
						return statement;
					}
					else if (statement instanceof FindClassParams) {
						//continue;
						FindStatementParams r = findStatement_main_debuging( (FindClassParams)statement, indexInmBuffer);
						if (r!=null) return r;
						return statement;
					}
					else if (statement instanceof FindFunctionParams) {
						FindFunctionParams func = (FindFunctionParams) statement;
						//continue;
						FindStatementParams r = 
								this.findStatement_debuging(indexInmBuffer, func);
						if (r!=null) return r;
						// r = null이다.
						if (func.startIndex()<=indexInmBuffer && indexInmBuffer<=func.findBlockParams.startIndex()) {
							return null;
						}
						else {
							return null;
						}
					}
					else {
						return null;
					}
				}
				
			}
			return null;
		}//if (classParams.startIndex()<=indexInmBuffer && indexInmBuffer<=classParams.endIndex()) {
		return null;
	}
	
	
	
	/** varUse를 포함하는 함수 또는 클래스 내에서 varUse를 갖는 최소의 문장을 찾아 리턴한다.
	 * 클래스인 경우 멤버변수 초기화 문장을 찾는다.*/
	public FindStatementParams findStatement_debuging(int indexInmBuffer, FindFunctionParams func) {
		int i;
		for (i=0; i<func.listOfVariableParamsBeforeProcessLocalVars.count; i++) {
			FindVarParams var = (FindVarParams) func.listOfVariableParamsBeforeProcessLocalVars.getItem(i);
			if (var.startIndex()<=indexInmBuffer && indexInmBuffer<=var.endIndex()) {
				FindVarUseParams lValue = 
						CompilerStatic.getVarUseWithIndex(data.mlistOfAllVarUsesHashed, data.mBuffer.getItem(var.varNameIndex()).str, var.varNameIndex());
				if (lValue==null) {
					// int a=5;와 같은 경우에는 a=5를 리턴한다.
					return var;
				}
				else {
					indexInmBuffer = lValue.index();
					break;
				}
			}
		}
		for (i=0; i<func.listOfStatements.count; i++) {
			FindStatementParams statement = (FindStatementParams) func.listOfStatements.getItem(i);
			
			int startIndex = statement.startIndex();
			int endIndex = statement.endIndex();
			if (startIndex<=indexInmBuffer && indexInmBuffer<=endIndex) {
				if (statement instanceof FindControlBlockParams) {
					FindControlBlockParams controlBlock = (FindControlBlockParams) statement;
					// 제어구조의 괄호내에 있는 varUse를 클릭했을때
					if (controlBlock.indexOfLeftParenthesis()<=indexInmBuffer && indexInmBuffer<=controlBlock.indexOfRightParenthesis()) {							
						return controlBlock;
					}
					// 제어구조내에서 문장찾기
					FindStatementParams r = findStatement_debuging(indexInmBuffer, controlBlock);
					if (r!=null) return r;
					return controlBlock;
				}
				else {
					return statement;
				}
			}
			
		}
		
		return null;
	}
	
	/** varUse를 포함하는 제어구조 내에서 varUse를 갖는 최소의 문장을 찾아 리턴한다.*/
	FindStatementParams findStatement_debuging(int indexInmBuffer, FindControlBlockParams controlBlock) {
		int i;
		if (controlBlock.indexOfLeftParenthesis()==31700) {
		}
		for (i=0; i<controlBlock.listOfStatements.count; i++) {
			FindStatementParams statement = (FindStatementParams) controlBlock.listOfStatements.getItem(i);
			//if (statement instanceof FindVarParams) continue;
			int startIndex = statement.startIndex();
			int endIndex = statement.endIndex();
			
			if (startIndex<=indexInmBuffer && indexInmBuffer<=endIndex) {
				if (statement instanceof FindControlBlockParams) {
					FindControlBlockParams child = (FindControlBlockParams) statement;
					if (child.indexOfLeftParenthesis()<=indexInmBuffer && indexInmBuffer<=child.indexOfRightParenthesis())
						return child;
					FindStatementParams r = findStatement_debuging(indexInmBuffer, child);
					if (r!=null) return r;
					return child;
				}
				else {
					return statement;
				}
			}
		}
		return null;
	}
	
	
	/**Calls in EditText_Compiler.update()
	 * @param classParams : 처음 호출시에는 최상위클래스*/
	public FindStatementParams findStatement_main( FindClassParams classParams, int indexInmBuffer) {
		if (classParams.startIndex()<=indexInmBuffer && indexInmBuffer<=classParams.endIndex()) {
			int i;
			if (classParams.childClasses!=null) {
				for (i=0; i<classParams.childClasses.count; i++) {
					FindClassParams child = (FindClassParams) classParams.childClasses.getItem(i);
					FindStatementParams r = findStatement_main( child, indexInmBuffer);
					if (r!=null) return r;
				}
			}
			for (i=0; i<classParams.listOfStatements.count; i++) {
				FindStatementParams statement = (FindStatementParams) classParams.listOfStatements.getItem(i);			
				int startIndex = statement.startIndex();
				int endIndex = statement.endIndex();
				if (startIndex<=indexInmBuffer && indexInmBuffer<=endIndex) {
					if (statement instanceof FindVarParams) {
						// 클래스의 초기화 문장
						FindVarParams var = (FindVarParams) statement;
						/*if (var.typeStartIndex()<=indexInmBuffer && indexInmBuffer<=var.typeEndIndex())
							return var;
						else {
							FindVarUseParams lValue = 
									CompilerStatic.getVarUseWithIndex(data.mlistOfAllVarUsesHashed, data.mBuffer.getItem(var.varNameIndex()).str, var.varNameIndex());
							if (lValue==null) {
								// int a=5;와 같은 경우에는 a=5를 리턴한다.
								return var;
							}
						}*/
						return var.parent;
					}
					else if (statement instanceof FindAssignStatementParams) {
						return statement.parent;
					}
					else if (statement instanceof FindClassParams) {
						//continue;
						FindStatementParams r = findStatement_main( (FindClassParams)statement, indexInmBuffer);
						if (r!=null) return r;
						return statement;
					}
					else if (statement instanceof FindFunctionParams) {
						FindFunctionParams func = (FindFunctionParams) statement;
						//continue;
						FindStatementParams r = 
								this.findStatement(indexInmBuffer, func);
						if (r!=null) return func;
						// r = null이다.
						if (func.startIndex()<=indexInmBuffer && indexInmBuffer<=func.findBlockParams.startIndex()) {
							return func.parent;
						}
						else {
							return func;
						}
					}
					else {
						return classParams;
					}
				}
				
			}
			return classParams;
		}//if (classParams.startIndex()<=indexInmBuffer && indexInmBuffer<=classParams.endIndex()) {
		return null;
	}
	
	
	
	/** varUse를 포함하는 함수 또는 클래스 내에서 varUse를 갖는 최소의 문장을 찾아 리턴한다.
	 * 클래스인 경우 멤버변수 초기화 문장을 찾는다.*/
	public FindStatementParams findStatement(int indexInmBuffer, FindFunctionParams func) {
		int i;
		for (i=0; i<func.listOfStatements.count; i++) {
			FindStatementParams statement = (FindStatementParams) func.listOfStatements.getItem(i);
			
			int startIndex = statement.startIndex();
			int endIndex = statement.endIndex();
			if (startIndex<=indexInmBuffer && indexInmBuffer<=endIndex) {
				if (statement instanceof FindVarParams) {
					FindVarParams var = (FindVarParams) statement;
					if (var.typeStartIndex()<=indexInmBuffer && indexInmBuffer<=var.typeEndIndex())
						return var;
					else {
						FindVarUseParams lValue = 
								CompilerStatic.getVarUseWithIndex(data.mlistOfAllVarUsesHashed, data.mBuffer.getItem(var.varNameIndex()).str, var.varNameIndex());
						if (lValue==null) {
							// int a=5;와 같은 경우에는 a=5를 리턴한다.
							return var;
						}
					}
				}
				else if (statement instanceof FindControlBlockParams) {
					FindControlBlockParams controlBlock = (FindControlBlockParams) statement;
					// 제어구조의 괄호내에 있는 varUse를 클릭했을때
					if (controlBlock.indexOfLeftParenthesis()<=indexInmBuffer && indexInmBuffer<=controlBlock.indexOfRightParenthesis()) {							
						return controlBlock;
					}
					// 제어구조내에서 문장찾기
					FindStatementParams r = findStatement(indexInmBuffer, controlBlock);
					return r;
				}
				else {
					return statement;
				}
			}
			
		}
		
		return null;
	}
	
	/** varUse를 포함하는 제어구조 내에서 varUse를 갖는 최소의 문장을 찾아 리턴한다.*/
	FindStatementParams findStatement(int indexInmBuffer, FindControlBlockParams controlBlock) {
		int i;
		if (controlBlock.indexOfLeftParenthesis()==31700) {
		}
		for (i=0; i<controlBlock.listOfStatements.count; i++) {
			FindStatementParams statement = (FindStatementParams) controlBlock.listOfStatements.getItem(i);
			//if (statement instanceof FindVarParams) continue;
			int startIndex = statement.startIndex();
			int endIndex = statement.endIndex();
			
			if (startIndex<=indexInmBuffer && indexInmBuffer<=endIndex) {
				if (statement instanceof FindVarParams) {
					FindVarParams var = (FindVarParams) statement;
					if (var.typeStartIndex()<=indexInmBuffer && indexInmBuffer<=var.typeEndIndex())
						return var;
					else {
						FindVarUseParams lValue = 
								CompilerStatic.getVarUseWithIndex(data.mlistOfAllVarUsesHashed, data.mBuffer.getItem(var.varNameIndex()).str, var.varNameIndex());
						if (lValue==null) {
							// int a=5;와 같은 경우에는 a=5를 리턴한다.
							return var;
						}
					}
				}
				else if (statement instanceof FindControlBlockParams) {
					FindControlBlockParams child = (FindControlBlockParams) statement;
					if (child.indexOfLeftParenthesis()<=indexInmBuffer && indexInmBuffer<=child.indexOfRightParenthesis())
						return child;
					return findStatement(indexInmBuffer, child);
				}
				else {
					return statement;
				}
			}
		}
		return null;
	}
	
	
	/** 변수타입선언문인지 변수사용(또는 함수호출)인지 확인한다. 
	 * 또한 함수정의문인지 클래스선언문, 또는 제어블럭(if, for블록등의 키워드)인지 확인한다.*/	
	public Object findNode_NodeType( FindClassParams classParams, int indexInmBuffer) {
		HighArray_CodeString src = this.data.mBuffer;
		int i;
		if (classParams==null) {
			int len = data.mlistOfAllVarUses.getCount();
			for (i=0; i<len; i++) {
				FindVarUseParams varUse = (FindVarUseParams) data.mlistOfAllVarUses.getItem(i);
				if (varUse.index()==indexInmBuffer) return varUse;
			}
			return null;
		}
		
		// 클래스 정의문이나 enum 정의문인지 확인
		if (classParams.classNameIndex()==indexInmBuffer) {
			return classParams;
		}
		
		int j;
		
		
		for (i=0; i<data.mlistOfAllControlBlocks.count; i++) {
			FindControlBlockParams controlBlock = (FindControlBlockParams) data.mlistOfAllControlBlocks.getItem(i);
			if (controlBlock.nameIndex()==indexInmBuffer) {
				return controlBlock;
			}
		}
		
		boolean isVarUseOrFuncCall;
		int nextIndex = CompilerHelper.SkipBlank(src, false, indexInmBuffer+1, src.count-1);
		if (nextIndex==src.count) return null;
		
		if (src.getItem(nextIndex).equals("(")) {
			isVarUseOrFuncCall = false;
		}
		else {
			isVarUseOrFuncCall = true;
		}
		
		// 변수사용이 가장 하위 자식 클래스에 등록이 되어 있기 때문이다.
		if (isVarUseOrFuncCall) {	// 변수참조 해시테이블에서 찾기
			String dataName = src.getItem(indexInmBuffer).str;
			if (classParams.listOfAllVarUsesForVarHashed!=null) {
				FindVarUseParams varUse = 
						Compiler.getVarUseWithIndex(classParams.listOfAllVarUsesForVarHashed, dataName, indexInmBuffer);
				if (varUse!=null) return varUse;
			}
		}
		else {	// 함수호출 리스트에서 찾기
			if (classParams.listOfAllVarUsesForFunc!=null) {
				int len = classParams.listOfAllVarUsesForFunc.getCount();
				for (j=0; j<len; j++) {
					FindVarUseParams varUse = (FindVarUseParams)classParams.listOfAllVarUsesForFunc.getItem(j);
					if (src.getItem(varUse.index()).equals("a")) {
					}
					if (varUse.index()==indexInmBuffer) {
						return varUse;
					}
					else if (indexInmBuffer<varUse.index()) {
						break;
					}
				}
			}
			
		}
		
		if (classParams.listOfVariableParams!=null) {		
			FindVarParams var=null;			
			// 멤버변수선언인지 확인
			ArrayListIReset listOfVarDeclaratons = classParams.listOfVariableParams; 
			for (i=0; i<listOfVarDeclaratons.count; i++) {
				var = (FindVarParams)listOfVarDeclaratons.getItem(i);
				if (var.typeEndIndex()==1364) {
				}
				if (var.isEnumElement && var.varNameIndex()==indexInmBuffer) {	
					// enum 변수를 터치시
					return var;
				}
				if (var.startIndex()==-1 || var.endIndex()==-1) continue;			
				if (var.typeStartIndex()==-1 || var.typeEndIndex()==-1) continue;
				if (var.typeStartIndex()<=indexInmBuffer && indexInmBuffer<=var.typeEndIndex()) {
					FindVarUseParams varUse = 
							Compiler.getVarUseWithIndex(data.mlistOfAllVarUsesHashed, data.mBuffer.getItem(indexInmBuffer).str, indexInmBuffer);
					if (varUse!=null) return varUse;
					return var;
				}
				if (var.varNameIndex()==indexInmBuffer) {		// 변수를 터치시
					return var;
				}
			}
		}
		
		if (classParams.listOfFunctionParams!=null) {
			// 지역변수선언인지 확인		
			ArrayListIReset listOfFuncs = classParams.listOfFunctionParams; 
			FindFunctionParams func = null;
			boolean found = false;
			for (j=0; j<listOfFuncs.count; j++) {
				func = (FindFunctionParams) listOfFuncs.getItem(j);
				if (func.startIndex()<indexInmBuffer && indexInmBuffer<func.endIndex()) {
					found = true;
					break;
				}					
			}
			if (found) {
				ArrayListIReset listOfLocalVars = func.listOfVariableParams;
				for (j=0; j<listOfLocalVars.count; j++) {
					FindVarParams var = (FindVarParams) listOfLocalVars.getItem(j);
					if (var.typeEndIndex()==1364) {
					}
					if (var.startIndex()==-1 || var.endIndex()==-1) continue;
					if (var.typeStartIndex()==-1 || var.typeEndIndex()==-1) continue;
					if (var.typeStartIndex()<=indexInmBuffer && indexInmBuffer<=var.typeEndIndex()) {
						FindVarUseParams varUse = 
							Compiler.getVarUseWithIndex(data.mlistOfAllVarUsesHashed, data.mBuffer.getItem(indexInmBuffer).str, indexInmBuffer);
						if (varUse!=null) return varUse;
						return var;
					}
					if (var.varNameIndex()==indexInmBuffer) {		// 변수를 터치시
						return var;
					}
				}
			}
		}
		
		
		
		
		
		if (classParams.listOfFunctionParams!=null) {
			// 함수인지 확인
			ArrayListIReset listOfFuncs = classParams.listOfFunctionParams;		
			for (j=0; j<listOfFuncs.count; j++) {
				FindFunctionParams func = (FindFunctionParams) listOfFuncs.getItem(j);
				if (func.startIndex()<=indexInmBuffer && indexInmBuffer<=func.endIndex()) {
					if (func.returnTypeStartIndex()<=indexInmBuffer && indexInmBuffer<=func.returnTypeEndIndex()) {
						return func;
					}
					if (func.functionNameIndex()==indexInmBuffer) {
						return func;
					}
				}					
			}
		}
	
		
		if (this.data.mlistOfSpecialStatement!=null) {
			ArrayListIReset listOfSpecialStatements = this.data.mlistOfSpecialStatement;		
			for (j=0; j<listOfSpecialStatements.count; j++) {
				FindSpecialStatementParams specialStatement = (FindSpecialStatementParams) listOfSpecialStatements.getItem(j);
				if (specialStatement.kewordIndex()==indexInmBuffer) {
					return specialStatement;
				}
			}
		}
		
		
		return null;
	}
	
	/** 제어블록의 키워드부분을 사용자가 터치시 호출이 된다.*/
	public HighArray_CodeChar findNode_controlBlock_makeString( FindControlBlockParams controlBlock, int indexInmBuffer) {
		if (!Common_Settings.showsByteCodes()) {
			return null;
		}
		if (controlBlock!=null) {
			HighArray_CodeChar r = null;
			if (controlBlock.funcCall==null) {
				
			}
			else {
				r = new HighArray_CodeChar("", Common_Settings.textColor);
				int j;
				if (controlBlock.funcCall.expression==null) return null;
				for (j=0; j<controlBlock.funcCall.expression.postfix.length; j++) {
					CodeStringEx token = controlBlock.funcCall.expression.postfix[j];
					r = getPostfixPrint( r, token);				
				}
			}
			return r;
		}
		return null;
	}
	
	/** 함수 정의의 머릿부분을 사용자가 터치시 호출이 된다.
	 * @param coreThreadID */
	public HighArray_CodeChar findNode_func_makeString( FindFunctionParams func, int indexInmBuffer, int coreThreadID) {
		HighArray_CodeString src = this.data.mBuffer;
		if (func!=null) {
			src = func.compiler.data.mBuffer;
			
			// func.functionNameIndex()==-1인 경우는 MenuClassAndMemberList에서 상속 함수선언을 터치한 경우이다.
			if (func.functionNameIndex()==indexInmBuffer || func.functionNameIndex()==-1) {
				int k;
				String docuComment = null;
				if (func.docuComment!=null && func.docuComment.str!=null) {
					docuComment = func.docuComment.str;
				}
				
				String className = "";
				if (func.parent!=null) {
					FindClassParams classP = (FindClassParams)func.parent;
					className = classP.name + ".";
				}
				
				String funcName;
				funcName = func.name;
				String returnTypeOfFunc;
				returnTypeOfFunc = func.getReturnType( func.returnTypeStartIndex(), func.returnTypeEndIndex(), coreThreadID);
				// PathClassLoader에서 클래스의 생성자의 경우 null이다.
				if (returnTypeOfFunc==null) returnTypeOfFunc = "";
				
				String args = "";
				for (k=0; k<func.listOfFuncArgs.count; k++) {
					FindVarParams arg = (FindVarParams)func.listOfFuncArgs.getItem(k);
					String typeName = arg.getType( arg.typeStartIndex(), arg.typeEndIndex(), coreThreadID);
					if (arg.varNameIndex()!=-1) {
						args += typeName + " " + src.getItem(arg.varNameIndex()).toString();
					}
					else {
						args += typeName;
					}
					if (k!=func.listOfFuncArgs.count-1) {
						args += ", ";
					}
				}
				
				boolean isConstructor = func.isConstructor;
				
				String message = "";
				if (func.overridedFindFunctionParams!=null) {
					message = "Overrides " + func.overridedFindFunctionParams.name + "() in " + 
							((FindClassParams)func.overridedFindFunctionParams.parent).name + "\n\n";
				}
				/*if (isStatic) {
					if (isConstructor) message += "S, C : ";
					else message += "S : ";
				}
				else {
					if (isConstructor) message += "C : ";
					else message += "";
				}*/
				if (isConstructor) message += "Constructor ";
				message += func.accessModifier.toString();
								
								
				if (docuComment!=null)
					return new HighArray_CodeChar(docuComment + "\n" + message + returnTypeOfFunc + " " + className + funcName + "(" + args + ")", Common_Settings.textColor);
				else 
					return new HighArray_CodeChar(message + returnTypeOfFunc + " " + className + funcName + "(" + args + ")", Common_Settings.textColor);
			}
			// 함수선언의 리턴타입을 터치시
			else if (func.returnTypeStartIndex()<=indexInmBuffer && indexInmBuffer<=func.returnTypeEndIndex()) {
				String docuComment = null;
				HighArray_CodeChar r;
				FindClassParams typeClassParams = Loader.loadClass(this, func.returnType, coreThreadID);
				if (typeClassParams!=null && typeClassParams.docuComment!=null && typeClassParams.docuComment.str!=null) {
					docuComment = typeClassParams.docuComment.str;
				}
				if (docuComment!=null) {
					r = new HighArray_CodeChar(docuComment + "\n" + 
							func.getReturnType( func.returnTypeStartIndex(), func.returnTypeEndIndex(), coreThreadID),
							Common_Settings.textColor);
				}
				else {
					r = new HighArray_CodeChar(
							func.getReturnType( func.returnTypeStartIndex(), func.returnTypeEndIndex(), coreThreadID), 
							Common_Settings.textColor);
				}
				return r;
			}
		}
		return null;
	}
	
	
	public void changeBounds() {
		this.createMenuClassAndMemberList(true, 0);
		this.createMenuClassAndMemberListWhenInputtingDot(true, 0);
		
		if (CompilerStatic.textViewExpressionTreeAndMessage!=null) {
			CompilerStatic.textViewExpressionTreeAndMessage.setText(0, new CodeString("", Common_Settings.textColor));
			int x, y, w, h;
			int viewWidth = Control.view.getWidth(); 
			int viewHeight = Control.view.getHeight();
			w = (int) (viewWidth * 0.8f);
			h = (int) (viewHeight * 0.6f);
			x = viewWidth/2 - w/2;
			y = viewHeight/2 - h/2;
			
			Rectangle boundsOfTextView = new Rectangle(x,y,w,h);
			CompilerStatic.textViewExpressionTreeAndMessage.changeBounds(boundsOfTextView);
		}
		
		CompilerInterface.createTextViewLogBird(true);
		CompilerInterface.createTextViewConsole(true);
		CompilerInterface.createTextViewInput(true);
		CompilerInterface.createTextViewDebugView(true);
		CompilerInterface.createMenuProblemList_EditText(true);
	}
			
	/**단 하나만 생성*/
	public void createMenuClassAndMemberList(boolean changeBounds, int coreThreadID) {
		View view = Control.view;
		int viewWidth = view.getWidth();
		int viewHeight = view.getHeight();	
		
		// 영역만 잡아놓고 나중에 Button[]을 넣어준다.
		int width = (int) (viewWidth * 0.9f);
		int height = (int) (viewHeight * 0.8f);
		int x = viewWidth / 2 - width / 2;
		int y = viewHeight / 2 - height / 2;
		Rectangle boundsOfMenuClassAndMemberList = new Rectangle(x,y,width,height);
	
		if (!changeBounds) {
			if (data.menuClassAndMemberList==null) { 
				data.menuClassAndMemberList = new MenuClassAndMemberList(this, boundsOfMenuClassAndMemberList, coreThreadID);
				this.compilerStack.data.menuClassAndMemberList = data.menuClassAndMemberList;
			}
		}
		else {
			if (data.menuClassAndMemberList!=null) {
				data.menuClassAndMemberList.changeBounds(boundsOfMenuClassAndMemberList);
			}
		}
	}
	/**단 하나만 생성*/
	public void createMenuClassAndMemberListWhenInputtingDot(boolean changeBounds, int coreThreadID) {
		View view = Control.view;
		int viewWidth = view.getWidth();
		int viewHeight = view.getHeight();	
		
		// 영역만 잡아놓고 나중에 Button[]을 넣어준다.
		int width = (int) (viewWidth * 0.6f);
		int height = (int) (viewHeight * 0.6f);
		int x = viewWidth / 2 - width / 2;
		int y = viewHeight / 2 - height / 2;
		Rectangle boundsOfMenuClassAndMemberList = new Rectangle(x,y,width,height);
		
		if (!changeBounds) {
			if (data.menuClassAndMemberListWhenInputtingDot==null) {
				data.menuClassAndMemberListWhenInputtingDot = new MenuClassAndMemberListWhenInputtingDot(this, boundsOfMenuClassAndMemberList, coreThreadID);
				data.menuClassAndMemberListWhenInputtingDot.showsExtendsMember = true;
				this.compilerStack.data.menuClassAndMemberListWhenInputtingDot = data.menuClassAndMemberListWhenInputtingDot;
			}
		}
		else {
			if (data.menuClassAndMemberListWhenInputtingDot!=null) {
				data.menuClassAndMemberListWhenInputtingDot.changeBounds(boundsOfMenuClassAndMemberList);
			}
		}
	}
	
	
	/**단 하나만 생성*/
	public static void createMenuProblemList_EditText(boolean changeBounds) {
		View view = Control.view;
		int viewWidth = view.getWidth();
		int viewHeight = view.getHeight();
					
		// 영역만 잡아놓고 나중에 Button[]을 넣어준다.
		int width = (int) (viewWidth * 0.9f);
		int height = (int) (viewHeight * 0.6f);
		int x = viewWidth / 2 - width / 2;
		int y = viewHeight / 2 - height / 2;
		Rectangle boundsOfMenuProblemList = new Rectangle(x,y,width,height);	
		
		if (!changeBounds) {
			if (CompilerStatic.menuProblemList_EditText==null) {
				CompilerStatic.menuProblemList_EditText = new MenuProblemList_EditText(boundsOfMenuProblemList);
				CompilerStatic.menuProblemList_EditText.setBackColor(Color.GREEN);
			}
		}
		else {
			if (CompilerStatic.menuProblemList_EditText!=null) {
				CompilerStatic.menuProblemList_EditText.changeBounds(boundsOfMenuProblemList);
			}
		}
	}
	
	/**단 하나만 생성*/
	public static void createTextViewLogBird(boolean changeBounds) {
		int x, y, w, h;
		int viewWidth = Control.view.getWidth(); 
		int viewHeight = Control.view.getHeight();
		w = (int) (viewWidth * 0.8f);
		h = (int) (viewHeight * 0.6f);
		x = viewWidth/2 - w/2;
		y = viewHeight/2 - h/2;
		
		Rectangle boundsOfTextView = new Rectangle(x,y,w,h);
		
		if (!changeBounds) {
			if (CommonGUI.textViewLogBird==null) {
				CommonGUI.textViewLogBird = new TextView(false, false, Control.view, "LogBird", boundsOfTextView, 
						Control.view.getHeight()*0.025f, false, null, ScrollMode.Both, Common_Settings.backColor);
				CommonGUI.textViewLogBird.isReadOnly = true;
				CommonGUI.textViewLogBird.isSelecting = true;
				CompilerStatic.textViewLogBird = CommonGUI.textViewLogBird;
			}
		}
		else {
			if (CommonGUI.textViewLogBird!=null) {
				CommonGUI.textViewLogBird.changeBounds(boundsOfTextView);
			}
		}
	}
	
	/**단 하나만 생성*/
	public static void createTextViewConsole(boolean changeBounds) {
		int x, y, w, h;
		int viewWidth = Control.view.getWidth(); 
		int viewHeight = Control.view.getHeight();
		w = (int) (viewWidth * 0.8f);
		h = (int) (viewHeight * 0.6f);
		x = viewWidth/2 - w/2;
		y = viewHeight/2 - h/2;
		
		Rectangle boundsOfTextView = new Rectangle(x,y,w,h);
		
		if (!changeBounds) {
			if (CommonGUI.textViewConsole==null) {
				CommonGUI.textViewConsole = new TextView(false, false, null, "Console", boundsOfTextView, 
						Control.view.getHeight()*0.025f, false, null, ScrollMode.Both, Common_Settings.backColor);
				CommonGUI.textViewConsole.isReadOnly = true;
				CommonGUI.textViewConsole.isSelecting = true;
				//Compiler.textViewConsole = CommonGUI.textViewConsole;
			}
		}
		else {
			if (CommonGUI.textViewConsole!=null) {
				CommonGUI.textViewConsole.changeBounds(boundsOfTextView);
			}
		}
	}
	/**단 하나만 생성*/
	public static void createTextViewInput(boolean changeBounds) {
		int x, y, w, h;
		int viewWidth = Control.view.getWidth(); 
		int viewHeight = Control.view.getHeight();
		w = (int) (viewWidth * 0.8f);
		h = (int) (viewHeight * 0.6f);
		x = viewWidth/2 - w/2;
		y = viewHeight/2 - h/2;
		
		Rectangle boundsOfTextView = new Rectangle(x,y,w,h);
		
		if (!changeBounds) {
			if (CommonGUI.textViewInput==null) {
				CommonGUI.textViewInput = new InputTextView(false, false, null, "InputStream", boundsOfTextView, 
						Control.view.getHeight()*0.025f, false, null, ScrollMode.Both, Common_Settings.backColor);
				CommonGUI.textViewInput.isReadOnly = false;
				
			}
		}
		else {
			if (CommonGUI.textViewInput!=null) {
				CommonGUI.textViewInput.changeBounds(boundsOfTextView);
			}
		}
	}
	/**단 하나만 생성*/
	public static void createTextViewDebugView(boolean changeBounds) {
		int x, y, w, h;
		int viewWidth = Control.view.getWidth(); 
		int viewHeight = Control.view.getHeight();
		w = (int) (viewWidth * 0.8f);
		h = (int) (viewHeight * 0.6f);
		x = viewWidth/2 - w/2;
		y = viewHeight/2 - h/2;
		
		Rectangle boundsOfTextView = new Rectangle(x,y,w,h);
		
		if (!changeBounds) {
			if (CommonGUI.textViewDebug==null) {
				CommonGUI.textViewDebug = new DebugView(false, false, null, "DebugView", boundsOfTextView, 
						Control.view.getHeight()*0.025f, false, null, ScrollMode.Both, Common_Settings.backColor);
				CommonGUI.textViewDebug.isReadOnly = true;
				CommonGUI.textViewDebug.isSelecting = true;
			}
		}
		else {
			if (CommonGUI.textViewDebug!=null) {
				CommonGUI.textViewDebug.changeBounds(boundsOfTextView);
			}
		}
	}
	/**단 하나만 생성*/
	public static void createTextViewExpressionTree() {
		if (CompilerStatic.textViewExpressionTreeAndMessage!=null) return; 
		int x, y, w, h;
		int viewWidth = Control.view.getWidth(); 
		int viewHeight = Control.view.getHeight();
		w = (int) (viewWidth * 0.8f);
		h = (int) (viewHeight * 0.65f);
		x = viewWidth/2 - w/2;
		y = viewHeight/2 - h/2;
		
		Rectangle boundsOfTextView = new Rectangle(x,y,w,h);
		CompilerStatic.textViewExpressionTreeAndMessage = new TextView(false, false, null, "TextViewExpressionTreeAndMessage", boundsOfTextView, 
				Control.view.getHeight()*0.025f, false, null, ScrollMode.VScroll, Common_Settings.backColor);
		CompilerStatic.textViewExpressionTreeAndMessage.isReadOnly = true;
	}
	
	public void setBackColor(int color) {	
		Common_Settings.setBackColor(color);		
		
		if (data.menuClassAndMemberList!=null) {
			if (data.menuClassAndMemberList.textView!=null) {
				data.menuClassAndMemberList.textView.setBackColor(Common_Settings.backColor);
			}
		}
		
		if (data.mBuffer!=null) {		
			int i;
			CodeString codeString;
			byte type;
			for (i=0; i<data.mBuffer.count; i++) {
				codeString = data.mBuffer.getItem(i);
				type = codeString.charAt(0).type;
				if (type==0 || type==CodeStringType.Text) {
					codeString.setColor(Common_Settings.textColor);
				}
				else if (type==CodeStringType.Keyword) {
					codeString.setColor(Common_Settings.keywordColor);
				}
				else if (type==CodeStringType.MemberVarUse) {
					codeString.setColor(Common_Settings.varUseColor);
				}
				else if (type==CodeStringType.FuncUse) {
					codeString.setColor(Common_Settings.funcUseColor);
				}
				else if (type==CodeStringType.MemberVarDecl) {
					codeString.setColor(Common_Settings.memberDeclColor);
				}
				else if (type==CodeStringType.Comment) {
					codeString.setColor(Common_Settings.commentColor);
				}
				else if (type==CodeStringType.DocuComment) {
					codeString.setColor(Common_Settings.docuCommentColor);
				}
			}
		}
		
		if (CompilerStatic.textViewExpressionTreeAndMessage!=null) {
			CompilerStatic.textViewExpressionTreeAndMessage.setBackColor(Common_Settings.backColor);
		}
		
		
		
	}
	
	/** '.'을 입력하면 패키지나 클래스의 멤버들을 표시하는 창을 연다.
	 * @param coreThreadID 
	 * @param filter : "all"(not filter), "a"(chars to filter)), only lower case*/
	public void inputDot(int indexInmBufferOfDot, String filter, int coreThreadID) {
		//int index = CompilerHelper.SkipBlank(data.mBuffer, true, 0, indexInmBufferOfDot-1);
		int index = Fullname.hasAND(this, true, indexInmBufferOfDot-1, true);
		if (data.mBuffer.getItem(index).equals(".")) {
			index = CompilerHelper.SkipBlank(data.mBuffer, false, index+1, data.mBuffer.count-1);
		}
		
		FindVarUseParams varUse = Compiler.getVarUseWithIndex(data.mlistOfAllVarUsesHashed, data.mBuffer.getItem(index).str, index);
		if (varUse==null) return;
		FindClassParams classParams = null;
		FindPackageParams packageParams = null;
		String typeName = null;
		if (varUse.varDecl!=null) {
			FindVarParams var = (FindVarParams)varUse.varDecl;
			typeName = var.typeName;
			int typeDimension = Array.getArrayDimension(this, typeName);
			int varUseDimension = Array.getArrayDimension(this, varUse.name);
			if (typeDimension!=varUseDimension) { 
				// 타입이 배열일 경우, buffer.length에서 buffer의 타입
				typeName = "com.gsoft.common.Array";
			}
			else {
				// AAA[] arr; ... arr[0].func()
				// typeName is AAA
				typeName = Array.getArrayElementType(typeName);
			}
			classParams = Loader.loadClass(this, typeName, coreThreadID);
		}
		else if (varUse.funcDecl!=null) {
			FindFunctionParams func = (FindFunctionParams)varUse.funcDecl;
			typeName = func.returnType;
			int typeDimension = Array.getArrayDimension(this, typeName);
			int varUseDimension = Array.getArrayDimension(this, varUse.name);
			if (typeDimension!=varUseDimension) { 
				// 타입이 배열일 경우, func().length에서 func()의 return 타입
				typeName = "com.gsoft.common.Array";
			}
			else {
				// AAA[] func(); ... func()[0].func2()
				// typeName is AAA
				typeName = Array.getArrayElementType(typeName);
			}
			classParams = Loader.loadClass(this, typeName, coreThreadID);
		}
		else if (varUse.memberDecl!=null) {
			if (varUse.memberDecl instanceof FindClassParams) {
				FindClassParams member = (FindClassParams)varUse.memberDecl;
				typeName = member.name;
				classParams = Loader.loadClass(this, typeName, coreThreadID);
			}
			else if (varUse.memberDecl instanceof FindPackageParams) {
				packageParams = (FindPackageParams) varUse.memberDecl;
			}
		}
		if (classParams!=null) {
			this.setMembersOfMenuClassAndMembersListWhenInputtingDot(classParams, filter);
			data.menuClassAndMemberListWhenInputtingDot.open(true, CommonGUI.editText_compiler);
		}
		if (packageParams!=null) {
			this.setMembersOfMenuClassAndMembersListWhenInputtingDot(packageParams, filter, coreThreadID);
			data.menuClassAndMemberListWhenInputtingDot.open(true, CommonGUI.editText_compiler);
		}
	}
	
	/**@param filter : "all"(not filter), "a"(chars to filter), only lower case*/
	void setMembersOfMenuClassAndMembersListWhenInputtingDot(FindClassParams classParams, String filter) {
		Button[] list;
		HighArray_CodeString mBuffer = classParams.compiler.data.mBuffer;
		data.menuClassAndMemberListWhenInputtingDot.setContainerClassAndSrc(mBuffer, 
				classParams);
		list = data.menuClassAndMemberListWhenInputtingDot.getMenuListButtons(this, mBuffer, classParams, 1, filter);
		data.menuClassAndMemberListWhenInputtingDot.setButtons(list);
	}
	
	/**@param filter : "all"(not filter), "a"(chars to filter), only lower case*/
	void setMembersOfMenuClassAndMembersListWhenInputtingDot(FindPackageParams packageParams, String filter, int coreThreadID) {
		Button[] list;
		HighArray_CodeString mBuffer = packageParams.compiler.data.mBuffer;
		list = data.menuClassAndMemberListWhenInputtingDot.getMenuListButtons(this, mBuffer, packageParams, 1, filter, coreThreadID);
		data.menuClassAndMemberListWhenInputtingDot.setButtons(list);
	}
	
	
	public void start2_WhenUsingCompilerCache(String filename, int coreThreadID) {
		
		//this.PairErrorExists = false;
		
		data.filename = filename;
		setBackColor(Common_Settings.backColor);
		
		
		//CompilerInterface.createTextViewLogBird(false);
		//CompilerInterface.createTextViewConsole(false);
		//CompilerInterface.createMenuProblemList_EditText(false);
		
		
		
		//CommonGUI.textViewLogBird.initialize();
		
		
		
		createMenuClassAndMemberList(false, coreThreadID);
		this.createMenuClassAndMemberListWhenInputtingDot(false, coreThreadID);
		createTextViewExpressionTree();
		
		data.menuClassAndMemberList.setContainerClassAndSrc(data.mBuffer, null);
		Button[] list = data.menuClassAndMemberList.getMenuListButtons(data.mBuffer, data.mlistOfClass);
		
		
		data.menuClassAndMemberList.setButtons(list);
		
		//ErrorList ownErrors = errors.findErrors(filename);
		//ErrorList.showErrors(ownErrors);
			
	}
	
	/**Refer to Loader.loadClassFromSrc_onlyInterface()*/
	public void start2_WhenUsingClassCache(String filename, int coreThreadID) {
		//CompilerStatic.errors.removeErrors(filename);
		
		//Compiler.PairErrorExists = false;
		
		data.filename = filename;
		setBackColor(Common_Settings.backColor);
		
		
		//CompilerInterface.createTextViewLogBird(false);
		//CompilerInterface.createTextViewConsole(false);
		//CompilerInterface.createMenuProblemList_EditText(false);
		
				
		//CommonGUI.textViewLogBird.initialize();
		
		
		createMenuClassAndMemberList(false, coreThreadID);
		this.createMenuClassAndMemberListWhenInputtingDot(false, coreThreadID);
		createTextViewExpressionTree();
		
		
		this.loadLibraries2(this);
		
		int i;
		for (i=0; i<data.mlistOfAllDefinedClasses.count; i++) {
			FindClassParams classParams = (FindClassParams) data.mlistOfAllDefinedClasses.getItem(i);
			classParams.loadWayOfFindClassParams = LoadWayOfFindClassParams.Start2; 
		}
		this.setClassNamesAndCreateConstructors(coreThreadID);
		
		for (i=0; i<data.mlistOfClass.count; i++) {
			FindClassParams classParams = (FindClassParams) data.mlistOfClass.getItem(i);
			inputThisAndSuperToClassAndInputVarUsesToHashtable(data.mBuffer, classParams, ModeAllOrUpdate.All, 
					true, 0, data.mBuffer.count-1);
		}
		
		
		
		Language lang = data.language;		
		
		FindAllClassesAndItsMembers2_part2( 0, data.mBuffer.count-1, data.mlistOfClass, 
				lang, ModeAllOrUpdate.All, true, null, coreThreadID, true);
		
		
		
		data.menuClassAndMemberList.setContainerClassAndSrc(data.mBuffer, null);
		Button[] list = data.menuClassAndMemberList.getMenuListButtons(data.mBuffer, data.mlistOfClass);
		
		
		data.menuClassAndMemberList.setButtons(list);
		
		data.strOutput = data.strInput;
		
		
		
		CompilerCache.add(this);
	}
   
	
	public void start_HTML( int backColor, String filename, int coreThreadID) {		
		LanguageAndTextFormat languageAndTextFormat = FileHelper.getLanguageAndTextFormat(filename);
		Language lang = languageAndTextFormat.lang;
		TextFormat format = languageAndTextFormat.format;
		
		ReturnOfReadString r = IO.readString(filename);
		HighArray_char input = r.result;
		if (input==null) return;		
			
		data.language = lang;
		data.textFormat = format;	
		
		data.filename = filename;
		setBackColor(Common_Settings.backColor);
		
		compilerStack.setLanguage(lang);
			
		CompilerInterface.createTextViewLogBird(false);
		CompilerInterface.createTextViewConsole(false);
		CompilerInterface.createTextViewInput(false);
		CompilerInterface.createTextViewDebugView(false);
		CompilerInterface.createMenuProblemList_EditText(false);
		
		try {
			createMenuClassAndMemberList(false, coreThreadID);
			this.createMenuClassAndMemberListWhenInputtingDot(false, coreThreadID);
			createTextViewExpressionTree();

			data.strInput = new HighArray_CodeChar(input, Common_Settings.textColor);
			data.mBuffer = new StringTokenizer().ConvertToStringArray2(data.strInput, 1000, lang);
			Checker.changeKeywordAndConstantColorAndTextColor(this, data.mBuffer, true, 0, data.mBuffer.count-1);
			data.menuClassAndMemberList.setButtons(new Button[0]);
			data.strOutput = data.strInput;
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	/** Puts only to CompilerCache*/
	public void start_C( int backColor, String filename, int coreThreadID) {		
		LanguageAndTextFormat languageAndTextFormat = FileHelper.getLanguageAndTextFormat(filename);
		Language lang = languageAndTextFormat.lang;
		TextFormat format = languageAndTextFormat.format;
		
		ReturnOfReadString r = IO.readString(filename);
		HighArray_char input = r.result;
		if (input==null) return;
			
		data.language = lang;
		data.textFormat = format;	
		
		data.filename = filename;
		setBackColor(Common_Settings.backColor);
		
		compilerStack.setLanguage(lang);
		
		CompilerInterface.createTextViewLogBird(false);
		CompilerInterface.createTextViewConsole(false);
		CompilerInterface.createTextViewInput(false);
		CompilerInterface.createTextViewDebugView(false);
		CompilerInterface.createMenuProblemList_EditText(false);
			
		
		try {
			createMenuClassAndMemberList(false, coreThreadID);
			this.createMenuClassAndMemberListWhenInputtingDot(false, coreThreadID);
			createTextViewExpressionTree();

			data.strInput = new HighArray_CodeChar(input, Common_Settings.textColor);
			data.mBuffer = new StringTokenizer().ConvertToStringArray2(data.strInput, 5000, lang);
			Checker.changeKeywordAndConstantColorAndTextColor(this, data.mBuffer, true, 0, data.mBuffer.count-1);
			data.menuClassAndMemberList.setButtons(new Button[0]);
			data.strOutput = data.strInput;
			
			CompilerCache.add(this);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	/** Compiler의 main함수 역할을 한다.
	 * 클래스 캐시가 바뀌는 것에 주의한다.
	 * @param modeAllOrUpdate */
	public void start2(int backColor, String filename, int coreThreadID) {
		//CommonGUI.setDrawOnlyLog(true);
		
		
		LanguageAndTextFormat languageAndTextFormat = FileHelper.getLanguageAndTextFormat(filename);
		Language lang = languageAndTextFormat.lang;
		TextFormat format = languageAndTextFormat.format;
		
		ReturnOfReadString r = IO.readString(filename);
		HighArray_char input = r.result;
		if (input==null) return;
		
		setBackColor(/*Common_Settings.settings.selectedColor[0]*/Common_Settings.backColor);
		
		data.language = lang;
		data.filename = filename;
		
		data.textFormat = format;
		compilerStack.setLanguage(lang);
		
		
		CompilerInterface.createTextViewLogBird(false);
		CompilerInterface.createTextViewConsole(false);
		CompilerInterface.createTextViewInput(false);
		CompilerInterface.createTextViewDebugView(false);
		CompilerInterface.createMenuProblemList_EditText(false);
		
				
		try {
			createMenuClassAndMemberList(false, coreThreadID);
			this.createMenuClassAndMemberListWhenInputtingDot(false, coreThreadID);
			createTextViewExpressionTree();

							
			if (Common_Settings.settings.loadsClassesFrequentlyUsedAdvancely) {
				CompilerHelper.startThreadReadingJavaClassesUsingWell(coreThreadID);
			}
			
			CommonGUI.showMessage(true, "Loading class files and analyzing....");
			
			CompilerStatic.errors.removeErrors(filename);
			this.PairErrorExists = false;
			
			HighArray_CodeChar strInput = new HighArray_CodeChar(input, Common_Settings.textColor);			
			data.strInput  = strInput;
			
			StringTokenizer tokenizer = new StringTokenizer();
			HighArray_CodeString src = tokenizer.ConvertToStringArray2(data.strInput, 10000, data.language); 
			data.mBuffer = src;	
			
			data.mlistOfComments = tokenizer.mlistOfComments;
			Comment.setCompilerToAllComments(data.mlistOfComments, this);
			
			
			data.packageName = null;
			data.mlistOfClass.reset2();
			
			FindAllClassesAndItsMembers2( 0, data.mBuffer.count-1, data.mlistOfClass, 
					lang, ModeAllOrUpdate.All, true, null, coreThreadID, true);
			
			
			data.strOutput = data.strInput;
			
			
			
							
			/** listOfClass가 1보다 큰 경우(즉 파일하나에 중첩되지 않은 클래스가 여러 개 있으면, 
			 * 루트라 이름붙인다.) 루트에서는  parentClassParams=null, curClassParams=null이다. 
			 * 1인 경우는 parentClassParams=첫번째 클래스, curClassParams=첫번째클래스이다.*/
			Button[] list;
			
			data.menuClassAndMemberList.setContainerClassAndSrc(data.mBuffer, null);
			list = data.menuClassAndMemberList.getMenuListButtons(data.mBuffer, data.mlistOfClass);
			
			
			data.menuClassAndMemberList.setButtons(list);
		
			//ErrorList ownErrors = CompilerStatic.errors.findErrors(filename);
			//ErrorList.showErrors(ownErrors);
			
			CompilerCache.add(this);
			
		} catch (Exception e) {
							
			//showMessage(true, e.toString());
			//return null;
			if (Common_Settings.g_printsLog) e.printStackTrace();
			CompilerHelper.printStackTrace(CompilerStatic.textViewLogBird, e);
		}
		
		//CommonGUI.setDrawOnlyLog(false);
	}
	
	
	
	
	/** Compiler의 main함수 역할을 한다.
	 * 클래스 캐시가 바뀌는 것에 주의한다.
	 * @param coreThreadID */
	public static void start2_PathClassLoader(int backColor, String filePath, int coreThreadID) {
		//data.language.language = lang;
		
		//CompilerStatic.errors.removeErrors(filePath);
		//this.PairErrorExists = false;
				
		
		CompilerInterface.createTextViewLogBird(false);
		CompilerInterface.createTextViewConsole(false);
		CompilerInterface.createTextViewInput(false);
		CompilerInterface.createTextViewDebugView(false);
		CompilerInterface.createMenuProblemList_EditText(false);
				
		
		//CommonGUI.textViewLogBird.initialize();
		
		
		try {
			if (!Common_Settings.showsByteCodes()) {
				return;
			}
			String filename = FileHelper.getFilename(filePath);
			filename = FileHelper.getFilenameExceptExt(filename);
			
			PathClassLoader loader = new PathClassLoader(filePath, null, filename, true, coreThreadID);
			
			CommonGUI.editText_compiler.setCompiler(loader.compiler);
			loader.compiler.setBackColor(Common_Settings.backColor);
			Compiler compiler = loader.compiler;
			CompilerData data = compiler.data;
			// PathClassLoader에서 만들어진 compiler의 compiler.data.menuClassAndMemberList에 MenuClassAndMemberList이 설정된다.
			((CompilerInterface)compiler).createMenuClassAndMemberList(false, coreThreadID);
			CompilerInterface.createTextViewExpressionTree();
			data.mLoader = loader;
			
			if (loader!=null && loader.classParams!=null) {
				data.strOutput = data.mLoader.getText();
				data.mBuffer = data.mLoader.mBuffer;
				
				loader.compiler.compilerStack.core.findNewLines(0, data.mBuffer.count-1);
				
				Button[] list;
				data.menuClassAndMemberList.setContainerClassAndSrc(data.mBuffer, 
						data.mLoader.classParams);
				data.mlistOfClass.add(data.mLoader.classParams);
				list = data.menuClassAndMemberList.getMenuListButtons(data.mBuffer, data.mlistOfClass);
				data.menuClassAndMemberList.setButtons(list);					
			}
		} catch (Throwable e) {
				
			if (Common_Settings.g_printsLog) e.printStackTrace();
			CompilerHelper.printStackTrace(CompilerStatic.textViewLogBird, e);
		}
	}

	
}
