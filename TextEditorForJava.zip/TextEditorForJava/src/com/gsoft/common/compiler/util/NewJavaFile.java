package com.gsoft.common.compiler.util;

import java.io.File;

import com.gsoft.common.CommonGUI;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.FileHelper;
import com.gsoft.common.IO;
import com.gsoft.common.IO_types.TextFormat;
import com.gsoft.common.gui.Control;

public class NewJavaFile {
	
	/** packageName과 className을 가진 새로운 자바파일을 생성한다. 
	 * 기존 packageName을 갖는 output에 있는 디렉토리는 지워진다.
	 * 또한 기존  packageName과 className을 갖는 예전 자바파일은 덮어씌어진다.
	 * @param className : fullname이 아니라 short name*/
	public static String createNewJavaFile(String packageName, String className, boolean inputsMainFunc) {
		if (packageName!=null && !packageName.equals("")) {
			String slashedPackageName = packageName.replace('.', File.separatorChar);
			File packageDir = new File(Common_Settings.pathProjectSrc+File.separator+slashedPackageName);
			String filename = packageDir.getAbsolutePath()+File.separator+className+".java";
			if (!packageDir.exists()) {
				packageDir.mkdirs();
			}
			
			File outputDir = new File(Common_Settings.pathJaneSoft+File.separator+"output"+File.separator+slashedPackageName);
			if (outputDir.exists()) {
				// packageName과 같은 output 디렉토리에 있는 디렉토리를 지운다.
				FileHelper.delete(outputDir.getAbsolutePath());
			}
			
			if (new File(filename).exists()) {
				CommonGUI.loggingForMessageBox.setText(true, "Old java file is deleted and new java file is created", false);
				CommonGUI.loggingForMessageBox.setHides(false);
				Control.view.postInvalidate();
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					
					e.printStackTrace();
				}
			}
			
			String text = null;
			if (!inputsMainFunc) {
				text = 
					"package "+packageName+";\n\n"+
					"public class "+className+" {\n"+
					"}\n";
			}
			else {
				text = 
						"package "+packageName+";\n\n"+
						"public class "+className+" {\n"+
						"\tpublic static void main(String[] args) {\n"+
						"\t}\n"+
						"}\n";
			}
			IO.writeString(filename, text, TextFormat.UTF_8, false, true);
			
			/*Compiler compilerLocal = new Compiler();
			compilerLocal.start2(text, Compiler_types.Language.Java, CommonGUI_Settings.backColor, filename);
			
			
			return compilerLocal;*/
			return text;
		}
		return null;
	}
}
