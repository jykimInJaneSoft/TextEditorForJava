package com.gsoft.common.compiler.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Color;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.CommonGUI;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.FileHelper;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.gui.Control;
import com.gsoft.common.gui.LoggingScrollable;

public class Decompressor {
	static class ThreadDecompressAndroidAndProjectSrc extends Thread {
		public void run() {
			LoggingScrollable.longOperation = true;
			
			Decompressor.decompressAndroidAndProjectSrc_sub();          				            				        				
			
			LoggingScrollable.longOperation = false;
		}
	}
	
	public static void decompressAndroidAndProjectSrc_sub() {
		boolean success = true;
		
			//  /sdcard/gsoft 의 파일들이 올바르지 않으면 /sdcard/gsoft과 /sdcard/gsoft.zip을 모두 지우고
			// 새로 압축을 푼다.
			//boolean r = IO.FileHelper.testFileWork();
		//if (androidJavaLibAlreadyExists()==false) {
		
		
		// 압축이 실패할 수도 있으므로 디폴트로 바꿔놓는다.
		
			
			//CommonGUI.showMessage(true, "Deleting " + destFilename + ".. Please don't close and wait..");
			//FileHelper.delete(destFilename);
			// /sdcard/gsoft.zip
			//destFilename =  Control.pathJaneSoft + File.separator + "gsoft.zip";
			//FileHelper.delete(destFilename);
			success = decompressAndroidJavaLib();
			
			if (!success) {
				//Compiler.errors.add(new Error(compiler, 0,0,"Can't load android library."));
			}
			else {
				CommonGUI.showMessage(true, "Decompress completed.");
				//CommonGUI.loggingForMessageBox.setHides(true);
			}
		//}
		
		// 프로그램시작시에는 /sdcard/janeSoft/project/com을 지우고 다시 설치한다.
		//if (projectSrcAlreadyExists()==false) {
			
			//CommonGUI.showMessage(true, "Deleting " + destFilename + ".. Please don't close and wait..");
			//FileHelper.delete(destFilename);
			// /sdcard/janeSoft/project.zip
			//destFilename =  Control.pathJaneSoft + File.separator + "project.zip";
			//FileHelper.delete(destFilename);
			success = decompressProjectSrc();
			
			if (!success) {
				//Compiler.errors.add(new Error(compiler, 0,0,"Can't load project files."));
			}
			else {
				CommonGUI.showMessage(true, "Decompress completed.");
				CommonGUI.loggingForMessageBox.setHides(true);
			}
		//}			
	
	}
	
	/** 스레드를 사용하여 압축을 해제할지를 결정하여 압축을 해제한다.
	 * slave 로 동작할 때는 압축을 해제하지 않는다.*/
	public static void decompressAndroidAndProjectSrc() {
		/*if (Common_Settings.settings.usesChildCompilerProcess) {
			if (Control.isMasterOrSlave) {
				ThreadDecompressAndroidAndProjectSrc thread = new ThreadDecompressAndroidAndProjectSrc();
				thread.start();
			}
		}
		else {
			ThreadDecompressAndroidAndProjectSrc thread = new ThreadDecompressAndroidAndProjectSrc();
			thread.start();
		}*/
		ThreadDecompressAndroidAndProjectSrc thread = new ThreadDecompressAndroidAndProjectSrc();
		thread.start();
	}
	
	
	/** 윈도우즈의 경우 asset\lib\project.zip 파일을 c:\TextEditorForJava\janeSoft\project.zip 에 옮겨서
	 * c:\TextEditorForJava\janeSoft\project 에 압축을 해제하고 c:\TextEditorForJava\janeSoft\project.zip 은 지운다.
	 * @return 압축해제가 성공하면 true 를 리턴한다.
	 */
	public static boolean decompressProjectSrc() {
		OutputStream os = null;
		InputStream is = null;
		
		byte[] buf = new byte[1000];
		
		String srcFilename = null;
		try{
			
			
			Context context = Control.view.getContext();
			AssetManager asset = context.getAssets();
			
			// asset에 있는 "gsoft.zip" 파일을 sdcard(전체경로:/sdcard/janeSoft/project.zip)에 옮긴다.
			is = asset.open("lib"+File.separator+"project.zip");
			
			srcFilename = Common_Settings.pathJaneSoft + File.separator + "project.zip";
			File srcFile = new File(srcFilename);
			
			try {
				os = new FileOutputStream(srcFile);
				FileHelper.move(buf, is, os);
				}catch(Exception e) {
					return false;
				}
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
			CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
			return false;
		}
		finally {
			FileHelper.close(is);
			FileHelper.close(os);
		}
		
		try {
			
			String destFilename =  Common_Settings.pathJaneSoft + File.separator + "project";
			
			new File(destFilename).mkdirs();
			
			// sdcard에 옮겨진 jar파일을 압축을 푼다.
			CommonGUI.showMessage(true, "Decompressing project.zip.. Please don't close and wait..");
			boolean r = com.gsoft.common.util.Util.JarFile.decompress(srcFilename, destFilename);
			// /sdcard/janeSoft/project.zip 파일을 지운다.
			FileHelper.delete(srcFilename);
			
			if (r) {
				Common_Settings.pathProjectSrc = destFilename;
				//Control.settingsDialog.editTextDirectory.setText(0, 
				//		new CodeString(Control.pathAndroid+File.separator,Color.BLACK));
				return true;
			}
			else {
				CommonGUI.showMessage(true, "Failed decompressing project.zip....");
				Thread.sleep(4000);
				return false;
			}
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
			CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
			return false;
		}
		finally {
			FileHelper.close(is);
			FileHelper.close(os);
		}
	}
	
	/**asset에 있는 gsoft.zip을 /sdcard/janeSoft/gsoft.zip에 옮겨서 
	 * /sdcard/janeSoft/gsoft에 압축을 해제한다.
	 * 윈도우즈의 경우 asset\lib\gsoft.zip 파일을 c:\TextEditorForJava\janeSoft\gsoft.zip 에 옮겨서
	 * c:\TextEditorForJava\janeSoft\gsoft 에 압축을 해제하고 c:\TextEditorForJava\janeSoft\gsoft.zip 은 지운다.
	 * 압축이 성공적으로 풀리면 Common_Settings.settings.pathAndroid가 
	 * c:\TextEditorForJava\janeSoft\gsoft 으로 바뀌게 된다.
	 * */
	public static boolean decompressAndroidJavaLib() {
		OutputStream os = null;
		InputStream is = null;
		
		byte[] buf = new byte[1000];
		
		String srcFilename = null;
		try{
			Context context = Control.view.getContext();
			AssetManager asset = context.getAssets();
			
			// asset에 있는 "AndroidJavaLib.zip" 파일을 sdcard(전체경로:/sdcard/gsoft.zip)에 옮긴다.
			is = asset.open("lib"+File.separator+"gsoft.zip");
			
			srcFilename = Common_Settings.pathJaneSoft + File.separator + "gsoft.zip";
			File srcFile = new File(srcFilename);
			
			try {
				os = new FileOutputStream(srcFile);
				FileHelper.move(buf, is, os);
				}catch(Exception e) {
					return false;
				}
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
			CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
			return false;
		}
		finally {
			FileHelper.close(is);
			FileHelper.close(os);
		}
		
		try {
			
			String destFilename =  Common_Settings.pathAndroid;
					
			
			// sdcard에 옮겨진 jar파일을 압축을 푼다.
			CommonGUI.showMessage(true, "Decompressing AndroidJavaLib.zip.. Please don't close and wait..");
			boolean r = com.gsoft.common.util.Util.JarFile.decompress(srcFilename, destFilename);
			// 옮겨진 /sdcard/AndroidJavaLib.zip 파일은 지운다.
			FileHelper.delete(srcFilename);
			
			if (r) {
				Common_Settings.pathAndroid = destFilename;
				if (Common_Settings.settingsDialog!=null) {
					Common_Settings.settingsDialog.setEditTextDirectory(Common_Settings.pathAndroid+File.separator);
				}
				return true;
			}
			else {
				CommonGUI.showMessage(true, "Failed decompressing AndroidJavaLib.zip....");
				Thread.sleep(4000);
				return false;
			}
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
			CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
			return false;
		}
		finally {
			FileHelper.close(is);
			FileHelper.close(os);
		}
	}
	
	
	/**asset에 있는 gsoft.zip을 /sdcard/janeSoft/gsoft.zip에 옮겨서 /sdcard/janeSoft/gsoft에 압축을 해제한다.
	 * 윈도우즈의 경우 asset\lib\gsoft.zip 파일을 c:\TextEditorForJava\janeSoft\gsoft.zip 에 옮겨서
	 * c:\TextEditorForJava\janeSoft\gsoft 에 압축을 해제하고 c:\TextEditorForJava\janeSoft\gsoft.zip 은 지운다.
	 * @return 압축해제가 성공하면 true 를 리턴한다.
	 */
	public static boolean decompressGSoft() {
		OutputStream os = null;
		InputStream is = null;
		
		byte[] buf = new byte[1000];
		
		String srcFilename = null;
		try{
			Context context = Control.view.getContext();
			AssetManager asset = context.getAssets();
			
			// asset에 있는 "gsoft.zip" 파일을 sdcard(전체경로:/sdcard/gsoft.zip)에 옮긴다.
			is = asset.open("lib"+File.separator+"gsoft.zip");
			
			srcFilename = Common_Settings.pathJaneSoft + File.separator + "gsoft.zip";
			File srcFile = new File(srcFilename);
			
			try {
				os = new FileOutputStream(srcFile);
				FileHelper.move(buf, is, os);
				}catch(Exception e) {
					return false;
				}
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
			CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
			return false;
		}
		finally {
			FileHelper.close(is);
			FileHelper.close(os);
		}
		
		try {
			
			// /sdcard/janeSoft/gsoft 에 압축을 해제한다.
			String destFilename1 =  Common_Settings.pathJaneSoft + File.separator + "gsoft";
			
			//String destFilename2 =  destFilename1 + File.separator + "com" + File.separator + "gsoft";
			
						
			
			// sdcard 에 옮겨진 zip 파일을 압축을 푼다.
			CommonGUI.showMessage(true, "Decompressing gsoft.zip.. Please don't close and wait..");
			boolean r = com.gsoft.common.util.Util.JarFile.decompress(srcFilename, destFilename1);
			// /sdcard/gsoft.zip 파일을 지운다.
			FileHelper.delete(srcFilename);
			
			if (r) {
				Common_Settings.pathAndroid = destFilename1;
				if (Common_Settings.settingsDialog!=null) {
					Common_Settings.settingsDialog.editTextDirectory.setText(0, 
						new CodeString(Common_Settings.pathAndroid+File.separator,Color.BLACK));
				}
				return true;
			}
			else {
				CommonGUI.showMessage(true, "Failed decompressing gsoft.zip....");
				Thread.sleep(4000);
				return false;
			}
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
			CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
			return false;
		}
		finally {
			FileHelper.close(is);
			FileHelper.close(os);
		}
	}
	
	
	static class ThreaddecompressOtherLib extends Thread {
		String otherJarPath;
		public ThreaddecompressOtherLib(String otherJarPath) {
			
			this.otherJarPath = otherJarPath;
		}

		public void run() {
			Decompressor.decompressOtherLib_sub(otherJarPath);
		}
	}
	
	/**otherJarPath을 Control.pathOther_Lib/xxx 에 압축을 해제한다.
	 */
	public static boolean decompressOtherLib(String otherJarPath) {
		ThreaddecompressOtherLib thread = new ThreaddecompressOtherLib(otherJarPath);
		thread.start();
		return true;
	}
	
	
	
	/**otherJarPath을 Control.pathOther_Lib/xxx 에 압축을 해제한다.
	 * @return 압축해제가 성공하면 true 를 리턴한다.
	 */
	public static boolean decompressOtherLib_sub(String otherJarPath) {
		OutputStream os = null;
		InputStream is = null;
		
		
		String srcFilename = null;
		String jarFilename = FileHelper.getFilename(otherJarPath);
		String jarFilenameExceptExt = FileHelper.getFilenameExceptExt(jarFilename);
		
		srcFilename = otherJarPath;
		
		
		try {
			
			File fileOtherLib = new File(Common_Settings.pathOther_Lib);
			fileOtherLib.mkdirs();
			
			// /sdcard/janesoft/other_lib/*** 에 압축을 해제한다.
			String destFilename1 =  Common_Settings.pathOther_Lib + File.separator + jarFilenameExceptExt;
					
			
			// sdcard 에 옮겨진 zip 파일을 압축을 푼다.
			CommonGUI.showMessage(true, "Decompressing "+jarFilename+".. Please don't close and wait..");
			boolean r = com.gsoft.common.util.Util.JarFile.decompress(srcFilename, destFilename1);
			// /sdcard/gsoft.zip 파일을 지운다.
			//FileHelper.delete(srcFilename);
			
			if (r) {
				int index = Common_Settings.listOfOtherLibs.getIndex(destFilename1);
				if (index==-1) {
					Common_Settings.listOfOtherLibs.add(destFilename1);
				}
				CommonGUI.showMessage(true, "Succeeded decompressing "+jarFilename+"....");
				return true;
			}
			else {
				CommonGUI.showMessage(true, "Failed decompressing "+jarFilename+"....");
				Thread.sleep(4000);
				return false;
			}
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
			CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
			return false;
		}
		finally {
			FileHelper.close(is);
			FileHelper.close(os);
		}
	}
	
	
	
	
	//static class Thread
}
