package com.gsoft.common.compiler.util;


public class SynchronizedObjects {

	/** used in Loader.loadClass(), Builder.build(File file), ClassCache.getFindClassParams()*/
	public static Object lockForMultiThreadBuild = new Integer(1);
	public Object lock2 = new Integer(2);
}
