package com.gsoft.common.compiler.util;

import android.graphics.Canvas;
import android.graphics.Color;
import android.view.View;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.ColorEx;
import com.gsoft.common.CommonGUI;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.Events.MotionEvent;
import com.gsoft.common.FileHelper;
import com.gsoft.common.Sizing.Rectangle;
import com.gsoft.common.Sizing.Size;
import com.gsoft.common.Sizing.SizeF;
import com.gsoft.common.interfaces.OnTouchListener;
import com.gsoft.common.R.R;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.gui.Buttons.Button;
import com.gsoft.common.gui.Control;
import com.gsoft.common.gui.Dialog;
import com.gsoft.common.gui.FileDialog;
import com.gsoft.common.gui.MenuWithScrollBar;
import com.gsoft.common.gui.edittext.Edit.ScrollMode;
import com.gsoft.common.gui.edittext.EditText;

import com.gsoft.common.compiler.util.Decompressor;

/** xxx.jar파일을 등록하고 등록된 jar 파일 리스트를 볼 수 있는 대화상자*/
public class OtherLibsDialog  extends Dialog implements OnTouchListener {
	MenuWithScrollBar menuListOfLibs;
	Button buttonDeleteLib;
	EditText editTextPathInput;
	Button buttonAddlib;
	
	float scaleOfmenuListOfJarFilesX = 0.7f;
	float scaleOfmenuListOfJarFilesY = 0.3f;
	
	float scaleOfeditTextPathInputX = 0.7f;
	float scaleOfeditTextPathInputY = 0.1f;
	
	float scaleOfbuttonAddlibX = 0.15f;
	
	float scaleOfTitleBarY = 0.08f;
	
	float scaleOfOKButtonX = 0.15f;
	float scaleOfOKButtonY = 0.07f;
	
	float scaleOfGapY = (1-scaleOfTitleBarY-scaleOfmenuListOfJarFilesY-scaleOfeditTextPathInputY
			- scaleOfOKButtonY) / 4;
	
	
	public OtherLibsDialog(View owner, Rectangle bounds) {
		super(owner, bounds);
		this.bounds = bounds;
		
		this.createControls(false);
		
		Button[] libs = this.getMenuListButtons();
		this.menuListOfLibs.setButtons(libs);
	}
	
	
	
	public void changeBounds(Rectangle bounds) {
		this.bounds = bounds;
		this.createControls(true);
		//super.changeBounds(bounds);
	}
	
	void createControls(boolean changeBounds) {
		heightTitleBar = (int) (bounds.height*scaleOfTitleBarY);
		
		
		this.isTitleBarEnable = true;
		this.Text = "Other libraries-Select a jar you want";
		
		if (changeBounds) {
			super.changeBounds(bounds);
		}
		
		int gapY = (int) (bounds.height * this.scaleOfGapY);
		
		int x, y, w, h;
		int gapX = 0;
		float scaleOfGapX;
		
		int colorOfButton = ColorEx.darkerOrLighter(Color.WHITE, -100);
		
		
		scaleOfGapX = (1 - scaleOfmenuListOfJarFilesX - scaleOfbuttonAddlibX) / 3;
		gapX = (int) (bounds.width * scaleOfGapX);
		x = bounds.x + gapX;
		y = bounds.y + heightTitleBar + gapY;
		w = (int) (bounds.width * this.scaleOfmenuListOfJarFilesX);
		h = (int) (bounds.height * this.scaleOfmenuListOfJarFilesY);
		
		if (menuListOfLibs==null) {			
			Rectangle boundsOfmenuListOfJarFiles = new Rectangle(x, y, w, h);
			
			w = (int) (boundsOfmenuListOfJarFiles.width * 0.7f);
			h = (int) (bounds.height * 0.1f);
			Size buttonSize = new Size(w, h);
			menuListOfLibs = new MenuWithScrollBar(this, boundsOfmenuListOfJarFiles, 
					buttonSize, 
					ScrollMode.VScroll);
			menuListOfLibs.setBackColor(Color.YELLOW);
			menuListOfLibs.setOnTouchListener(this);				
		}
		else {
			Rectangle bounds = this.menuListOfLibs.bounds;
			bounds.x=x; bounds.y=y; bounds.width=w; bounds.height=h;
			this.menuListOfLibs.changeBounds(bounds);
		}
		
		x = menuListOfLibs.bounds.right() + gapX;
		y = bounds.y + heightTitleBar + gapY;
		w = (int) (bounds.width * this.scaleOfbuttonAddlibX);
		h = (int) (bounds.height * this.scaleOfOKButtonY);
		
		if (this.buttonDeleteLib==null) {
			Rectangle boundsOfbuttonDeleteLib = new Rectangle(x, y, w, h);
			this.buttonDeleteLib = new Button(owner, "Delete Lib", "Delete Lib", 
				colorOfButton, boundsOfbuttonDeleteLib, false, 255, true, 0.0f, null, Color.CYAN);
			buttonDeleteLib.setOnTouchListener(this);
		}
		else {
			Rectangle bounds = this.buttonDeleteLib.bounds;
			bounds.x=x; bounds.y=y; bounds.width=w; bounds.height=h;
			this.buttonDeleteLib.changeBounds(bounds);
		}
		
		
		scaleOfGapX = (1 - scaleOfeditTextPathInputX - scaleOfbuttonAddlibX) / 3;
		gapX = (int) (bounds.width * scaleOfGapX);
		x = bounds.x + gapX;
		y = menuListOfLibs.bounds.bottom() + gapY;
		w = (int) (bounds.width * this.scaleOfeditTextPathInputX);
		h = (int) (bounds.height * this.scaleOfeditTextPathInputY);
		
		if (editTextPathInput==null) {
			Rectangle boundsOfeditTextPathInput = new Rectangle(x, y, w, h);
			editTextPathInput = new EditText(false, false, this, "PathInput", boundsOfeditTextPathInput, 
					boundsOfeditTextPathInput.height*0.5f, true, 
					new CodeString("", Color.BLACK), 
					ScrollMode.Both, Color.WHITE);
			editTextPathInput.isReadOnly = true;			
		}
		else {
			Rectangle bounds = this.editTextPathInput.bounds;
			bounds.x=x; bounds.y=y; bounds.width=w; bounds.height=h;
			this.editTextPathInput.changeBounds(bounds);
		}
		
		
		
		x = editTextPathInput.bounds.right() + gapX;
		y = menuListOfLibs.bounds.bottom() + gapY;
		w = (int) (bounds.width * this.scaleOfbuttonAddlibX);
		h = (int) (bounds.height * this.scaleOfeditTextPathInputY);
		
		if (this.buttonAddlib==null) {
			Rectangle boundsOfbuttonAddlib = new Rectangle(x, y, w, h);
			this.buttonAddlib = new Button(owner, "Add lib", "Add lib", 
				colorOfButton, boundsOfbuttonAddlib, false, 255, true, 0.0f, null, Color.CYAN);
			buttonAddlib.setOnTouchListener(this);
		}
		else {
			Rectangle bounds = this.buttonAddlib.bounds;
			bounds.x=x; bounds.y=y; bounds.width=w; bounds.height=h;
			this.buttonAddlib.changeBounds(bounds);
		}
		
		scaleOfGapX = (1 - 2*scaleOfOKButtonX) / 3;
		gapX = (int) (bounds.width * scaleOfGapX);
		x = bounds.x + gapX;
		y = this.buttonAddlib.bounds.bottom() + gapY;
		w = (int) (bounds.width * scaleOfOKButtonX);
		h = (int) (bounds.height * scaleOfOKButtonY);
		
		if (this.controls==null) {
			Rectangle boundsOfButtonOK = new Rectangle(x,y,w,h);
			x = boundsOfButtonOK.right() + gapX;
			Rectangle boundsOfButtonCancel = new Rectangle(x,y,w,h);
			
			controls = new Button[2];
			controls[0] = new Button(owner, Dialog.NameButtonOk, Control.res.getString(R.string.OK), 
					colorOfButton, boundsOfButtonOK, false, 255, true, 0.0f, null, Color.CYAN);
			controls[1] = new Button(owner, Dialog.NameButtonCancel, Control.res.getString(R.string.cancel), 
					colorOfButton, boundsOfButtonCancel, false, 255, true, 0.0f, null, Color.CYAN);
			// 이벤트를 이 클래스에서 직접 처리
			controls[0].setOnTouchListener(this);
			controls[1].setOnTouchListener(this);
		}
		else {
			Rectangle bounds = this.controls[0].bounds;
			bounds.x=x; bounds.y=y; bounds.width=w; bounds.height=h;
			this.controls[0].changeBounds(bounds);
			
			x = bounds.right() + gapX;
			
			bounds = this.controls[1].bounds;
			bounds.x=x; bounds.y=y; bounds.width=w; bounds.height=h;
			this.controls[1].changeBounds(bounds);
		}
	}
	
	
	public boolean onTouch(MotionEvent event, SizeF scaleFactor) {
		boolean r;
		int i;
    	if (event.actionCode==MotionEvent.ActionDown || event.actionCode==MotionEvent.ActionDoubleClicked) {
	    	r = super.onTouch(event, scaleFactor);
	    	if (!r) return false;
	    	for (i=0; i<controls.length; i++) {
	    		r = controls[i].onTouch(event, scaleFactor);
	    		if (r) return true;
	    	}
	    	
	    	r = this.menuListOfLibs.onTouch(event, scaleFactor);
	    	if (r) return true;
	    	
	    	r = this.buttonDeleteLib.onTouch(event, scaleFactor);
	    	if (r) return true;
	    	
	    	r = this.editTextPathInput.onTouch(event, scaleFactor);
	    	if (r) return true;
	    	
	    	r = this.buttonAddlib.onTouch(event, scaleFactor);
	    	if (r) return true;
	    	
	    	
	    	return true;
    	}
    	return false;
    }
	
	public void draw(Canvas canvas)
    {
		if (hides) return;
		synchronized(this) {
			try {
		        super.draw(canvas);
		        
		        this.menuListOfLibs.draw(canvas);
		        this.buttonDeleteLib.draw(canvas);
		        this.editTextPathInput.draw(canvas);
		        this.buttonAddlib.draw(canvas);
		        
		        int i;
		        for (i=0; i<controls.length; i++) {
		    		controls[i].draw(canvas);
		        }
			}catch(Exception e) { 	}
    	}
    }
	
	public void open(boolean isOpen) {
		super.open(isOpen);
		this.editTextPathInput.setText(0, new CodeString("", Common_Settings.textColor));
	}
	
	public void onTouchEvent(Object sender, MotionEvent e) {
		
		if (sender instanceof Button) {
			Button button = (Button)sender;
			if (button.iName==controls[0].iName)	// OK
            {	
				super.OK(true);
				this.setHides(true);				
            }
            else if (button.iName==controls[1].iName)	// Cancel
            {
            	cancel();
            	this.setHides(true);
            }
            else if (button.iName==this.buttonDeleteLib.iName) {
            	Button selectedButton = this.menuListOfLibs.selectedButton;
            	String path = null;
            	if (selectedButton!=null) {
            		path = (String) selectedButton.addedInfo;
            	}
            	if (path==null) return;
            	int index = Common_Settings.listOfOtherLibs.getIndex(path);
            	try {
            		Common_Settings.listOfOtherLibs.delete(index, 1);
				} catch (Exception e1) {
					
					e1.printStackTrace();
				}
            	CompilerHelper.setJavaClassPathAndJavaLibraryPathIfNotExists();
            	
            	Button[] libs = this.getMenuListButtons();
				this.menuListOfLibs.setButtons(libs);
				
            }
            else if (button.iName==this.buttonAddlib.iName) {
            	CommonGUI.fileDialog.isFullScreen = true;
            	CommonGUI.fileDialog.canSelectFileType = false;
            	CommonGUI.fileDialog.isForViewing = true;
            	CommonGUI.fileDialog.setScaleValues();
            	CommonGUI.fileDialog.changeBounds(new Rectangle(0,0,Control.view.getWidth(),Control.view.getHeight()));
            	CommonGUI.fileDialog.createAndSetFileListButtons(CommonGUI.fileDialog.getCurDir(true), FileDialog.Category.Compression);
				//integrationKeyboard.setHides(true);
            	CommonGUI.fileDialog.open(this, "Set the path of other library");
            	CommonGUI.fileDialog.setOnTouchListener(this);
            }
		}
		else if (sender instanceof FileDialog) {
			FileDialog fileDialog = (FileDialog)sender;
			if (fileDialog.getIsOK()) {
				String path = fileDialog.mAbsFilename;
				this.editTextPathInput.setText(0, new CodeString(path,Color.BLACK));
				Decompressor.decompressOtherLib(path);
				
				try {
					Thread.sleep(3000);
				} catch (InterruptedException e1) {
					
					e1.printStackTrace();
				}
				
				CompilerHelper.setJavaClassPathAndJavaLibraryPathIfNotExists();
				
				Button[] libs = this.getMenuListButtons();
				this.menuListOfLibs.setButtons(libs);
			}
		}
	}
	
	public void setMenuListButtonsWithCommon_Settings_listOfOtherLibs() {
		Button[] libs = this.getMenuListButtons();
		this.menuListOfLibs.setButtons(libs);
	}
	
	Button[] getMenuListButtons() {
		int buttonCount = Common_Settings.listOfOtherLibs.count;
		Button[] buttons = new Button[buttonCount];
		int i;
		int color;
		for (i=0; i<buttonCount; i++) {
			String name = FileHelper.getFilename(Common_Settings.listOfOtherLibs.getItem(i));
			color = Color.BLUE;
			buttons[i] = new Button(null, "", "", Color.BLUE, 
					new Rectangle(0,0,0,0), 
					false, 255, true, 0, null, Color.CYAN);
			buttons[i].toggleable = true;
			buttons[i].name = name;
			buttons[i].bounds.x = 0;
			buttons[i].bounds.y = 0;
			buttons[i].bounds.width = this.menuListOfLibs.originButtonWidth;
			buttons[i].bounds.height = this.menuListOfLibs.originButtonHeight;
			buttons[i].changeBounds(buttons[i].bounds);
			buttons[i].setBackColor(color);
			buttons[i].addedInfo = Common_Settings.listOfOtherLibs.getItem(i);
			buttons[i].setText(buttons[i].name);
		}
		return buttons;
	}

}
