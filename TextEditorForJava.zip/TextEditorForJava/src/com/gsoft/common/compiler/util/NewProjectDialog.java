package com.gsoft.common.compiler.util;

import android.graphics.Canvas;
import android.graphics.Color;

import com.gsoft.common.gui.Dialog;
import com.gsoft.common.Code.CodeString;
import com.gsoft.common.ColorEx;
import com.gsoft.common.CommonGUI;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.Events.MotionEvent;
import com.gsoft.common.Sizing.Rectangle;
import com.gsoft.common.Sizing.SizeF;
import com.gsoft.common.interfaces.OnTouchListener;
import com.gsoft.common.R.R;
import com.gsoft.common.gui.Buttons.Button;
import com.gsoft.common.gui.Control;
import com.gsoft.common.gui.Dialog.EditableDialog;
import com.gsoft.common.gui.IntegrationKeyboard;
import com.gsoft.common.gui.Static;
import com.gsoft.common.gui.edittext.Edit.ScrollMode;
import com.gsoft.common.gui.edittext.EditText;

public class NewProjectDialog   extends EditableDialog implements OnTouchListener {
	float scaleOfGapX = 0.02f;
	
	float scaleOfTitleBar = 0.1f;
	
	float scaleOfeditTextProjectX = 0.4f;
	float scaleOfeditTextProjectY = 0.1f;
	
	float scaleOfeditTextPackageX = 0.4f;
	float scaleOfeditTextPackageY = 0.1f;
	
	float scaleOfeditTextClassX = 0.4f;
	float scaleOfeditTextClassY = 0.1f;
	
	float scaleOfbuttonMainFuncX = 0.4f;
	float scaleOfbuttonMainFuncY = 0.1f;
	
	float scaleOfOKButtonX = (1-scaleOfGapX*3) / 2;
	float scaleOfOKButtonY = 0.1f;
	
	float scaleOfGapY = (1-scaleOfTitleBar-scaleOfeditTextProjectY-scaleOfeditTextPackageY-scaleOfeditTextClassY-
			scaleOfbuttonMainFuncY-scaleOfOKButtonY) / 6;
	
	Static staticProject;
	Static staticPackage;
	Static staticClass;
	Static staticMainFunc;
	
	public EditText editTextProject;
	public EditText editTextPackage;
	public EditText editTextClass;
	public Button buttonMainFunc;

	
	
	
	public NewProjectDialog(Rectangle bounds) {
		super(Control.view, bounds);
		
		this.bounds = bounds;
		heightTitleBar = (int) (bounds.height*scaleOfTitleBar);
	
		
		this.isTitleBarEnable = true;
		//this.Text = Control.res.getString(R.string.font_size_dialog);
		this.Text = "New Project";
		
		int heightOfGap = (int)(bounds.height * scaleOfGapY);
		int widthOfGap = (int)(bounds.width * scaleOfGapX);
		int alpha = 255;
		
		int colorOfButton = ColorEx.darkerOrLighter(Color.WHITE, -100);
		
		int width = (int)(bounds.width * scaleOfeditTextProjectX);
		int height = (int)(bounds.height * scaleOfeditTextProjectY);
		int x = bounds.x + widthOfGap;
		int y = bounds.y + heightTitleBar + heightOfGap;
				
		Rectangle boundsOfStaticProject = new Rectangle(x,y,width,height);
		staticProject = new Static(owner, "Project", textColor, boundsOfStaticProject);
		
		// owner속성을 this로 해야 editText.owner 속성으로 키보드에서 EditableDialog를 최대화할 수 있다.
		x = boundsOfStaticProject.right() + widthOfGap;
		Rectangle boundsOfEditTextProject = new Rectangle(x,y,width,height);
		editTextProject = new EditText(false, false, this, "EditTextProject", boundsOfEditTextProject, boundsOfEditTextProject.height*0.6f, 
				true, new CodeString("", Color.BLACK), 
				ScrollMode.VScroll, Color.WHITE);		
		
		
		x = bounds.x + widthOfGap;
		y = boundsOfEditTextProject.bottom() + heightOfGap;
		
		Rectangle boundsOfStaticPackage = new Rectangle(x,y,width,height);
		staticPackage = new Static(owner, "Package", textColor, boundsOfStaticPackage);
		
		// owner속성을 this로 해야 editText.owner 속성으로 키보드에서 EditableDialog를 최대화할 수 있다.
		x = boundsOfStaticPackage.right() + widthOfGap;
		Rectangle boundsOfEditTextPackage = new Rectangle(x,y,width,height);
		editTextPackage = new EditText(false, false, this, "EditTextPackage", boundsOfEditTextPackage, boundsOfEditTextPackage.height*0.6f, 
				true, new CodeString("", Color.BLACK), 
				ScrollMode.VScroll, Color.WHITE);
		
		
		
		x = bounds.x + widthOfGap;
		y = boundsOfEditTextPackage.bottom() + heightOfGap;
		Rectangle boundsOfStaticClass = new Rectangle(x,y,width,height);
		staticClass = new Static(owner, "Class", textColor, boundsOfStaticClass);
		
		// owner속성을 this로 해야 editText.owner 속성으로 키보드에서 EditableDialog를 최대화할 수 있다.
		x = boundsOfStaticClass.right() + widthOfGap;
		Rectangle boundsOfEditTextClass = new Rectangle(x,y,width,height);
		editTextClass = new EditText(false, false, this, "EditTextClass", boundsOfEditTextClass, boundsOfEditTextClass.height*0.6f, 
				true, new CodeString("", Color.BLACK), 
				ScrollMode.VScroll, Color.WHITE);
		
		
		x = bounds.x + widthOfGap;
		y = boundsOfStaticClass.bottom() + heightOfGap;
		Rectangle boundsOfStaticMainFunc = new Rectangle(x,y,width,height);
		staticMainFunc = new Static(owner, "Inputs main func", textColor, boundsOfStaticMainFunc);
		
		x = boundsOfStaticMainFunc.right() + widthOfGap;
		Rectangle boundsOfButtonMainFunc = new Rectangle(x,y,width,height);
		this.buttonMainFunc = new Button(owner, "Main Func", "Disabled", 
				colorOfButton, boundsOfButtonMainFunc, false, alpha, true, 0.0f, null, Color.CYAN);
		buttonMainFunc.toggleable = true;
		buttonMainFunc.setOnTouchListener(this);
		
		
		width = (int) (bounds.width * scaleOfOKButtonX);
		height = (int) (bounds.height * scaleOfOKButtonY);
		x = bounds.x + widthOfGap;
		y = boundsOfStaticMainFunc.bottom() + heightOfGap;
		Rectangle boundsOfButtonOK = new Rectangle(x,y,width,height);
		x = boundsOfButtonOK.right() + widthOfGap;
		Rectangle boundsOfButtonCancel = new Rectangle(x,y,width,height);
		
		controls = new Button[2];
		controls[0] = new Button(owner, Dialog.NameButtonOk, Control.res.getString(R.string.OK), 
				colorOfButton, boundsOfButtonOK, false, alpha, true, 0.0f, null, Color.CYAN);
		controls[1] = new Button(owner, Dialog.NameButtonCancel, Control.res.getString(R.string.cancel), 
				colorOfButton, boundsOfButtonCancel, false, alpha, true, 0.0f, null, Color.CYAN);
		// 이벤트를 이 클래스에서 직접 처리
		controls[0].setOnTouchListener(this);
		controls[1].setOnTouchListener(this);
	}
	
	
	public void changeBounds(Rectangle bounds) {
		this.bounds = bounds;
		if (!isMaximized()) backUpBounds();
		
		int heightOfGap = (int)(bounds.height * scaleOfGapY);
		int widthOfGap = (int)(bounds.width * scaleOfGapX);
		
		int width = (int) (bounds.width * scaleOfeditTextPackageX);
		int height = (int) (bounds.height * scaleOfeditTextPackageY);
		int x = bounds.x + widthOfGap;
		int y = bounds.y + heightTitleBar + heightOfGap;
		
		Rectangle boundsOfStaticProject = staticProject.bounds;
		boundsOfStaticProject.x = x;
		boundsOfStaticProject.y = y;
		boundsOfStaticProject.width = width;
		boundsOfStaticProject.height = height;
		staticProject.changeBounds(boundsOfStaticProject);
		
		x = boundsOfStaticProject.right() + widthOfGap;
		Rectangle boundsOfEditTextProject = editTextProject.bounds;
		boundsOfEditTextProject.x = x;
		boundsOfEditTextProject.y = y;
		boundsOfEditTextProject.width = width;
		boundsOfEditTextProject.height = height;
		editTextProject.changeBounds(boundsOfEditTextProject);
		
		x = bounds.x + widthOfGap;
		y = boundsOfEditTextProject.bottom() + heightOfGap;
		Rectangle boundsOfStaticPackage = staticPackage.bounds;
		boundsOfStaticPackage.x = x;
		boundsOfStaticPackage.y = y;
		boundsOfStaticPackage.width = width;
		boundsOfStaticPackage.height = height;
		staticPackage.changeBounds(boundsOfStaticPackage);
		
		x = boundsOfStaticPackage.right() + widthOfGap;
		Rectangle boundsOfEditTextPackage = editTextPackage.bounds;
		boundsOfEditTextPackage.x = x;
		boundsOfEditTextPackage.y = y;
		boundsOfEditTextPackage.width = width;
		boundsOfEditTextPackage.height = height;
		editTextPackage.changeBounds(boundsOfEditTextPackage);
		
		x = bounds.x + widthOfGap;
		y = boundsOfEditTextPackage.bottom() + heightOfGap;
		Rectangle boundsOfStaticClass = staticClass.bounds;
		boundsOfStaticClass.x = x;
		boundsOfStaticClass.y = y;
		boundsOfStaticClass.width = width;
		boundsOfStaticClass.height = height;
		staticClass.changeBounds(boundsOfStaticClass);
		
		x = boundsOfStaticClass.right() + widthOfGap;
		Rectangle boundsOfEditTextClass = editTextClass.bounds;
		boundsOfEditTextClass.x = x;
		boundsOfEditTextClass.y = y;
		boundsOfEditTextClass.width = width;
		boundsOfEditTextClass.height = height;
		editTextClass.changeBounds(boundsOfEditTextClass);
		//editTextClass.setText(0, editTextClass.getText());
		
		
		x = bounds.x + widthOfGap;
		y = boundsOfStaticClass.bottom() + heightOfGap;
		Rectangle boundsOfStaticMainFunc = staticMainFunc.bounds;
		boundsOfStaticMainFunc.x = x;
		boundsOfStaticMainFunc.y = y;
		boundsOfStaticMainFunc.width = width;
		boundsOfStaticMainFunc.height = height;
		staticMainFunc.changeBounds(boundsOfStaticMainFunc);
		
		x = boundsOfStaticMainFunc.right() + widthOfGap;
		Rectangle boundsOfButtonMainFunc = buttonMainFunc.bounds;
		boundsOfButtonMainFunc.x = x;
		boundsOfButtonMainFunc.y = y;
		boundsOfButtonMainFunc.width = width;
		boundsOfButtonMainFunc.height = height;
		this.buttonMainFunc.changeBounds(boundsOfButtonMainFunc);
				
		
		width = (int) (bounds.width * scaleOfOKButtonX);
		height = (int) (bounds.height * scaleOfOKButtonY);
		x = bounds.x + widthOfGap;
		y = boundsOfStaticMainFunc.bottom() + heightOfGap;
		Rectangle boundsOfButtonOK = ((Button)controls[0]).bounds;
		boundsOfButtonOK.x = x;
		boundsOfButtonOK.y = y;
		boundsOfButtonOK.width = width;
		boundsOfButtonOK.height = height;
		
		x = boundsOfButtonOK.right() + widthOfGap;
		Rectangle boundsOfButtonCancel = ((Button)controls[1]).bounds;
		boundsOfButtonCancel.x = x;
		boundsOfButtonCancel.y = y;
		boundsOfButtonCancel.width = width;
		boundsOfButtonCancel.height = height;
		
		((Button)controls[0]).changeBounds(boundsOfButtonOK);		
		((Button)controls[1]).changeBounds(boundsOfButtonCancel);
	}
	
	
	 @Override
	    public boolean onTouch(MotionEvent event, SizeF scaleFactor) {
	    	boolean r;
	    	if (event.actionCode==MotionEvent.ActionDown || event.actionCode==MotionEvent.ActionDoubleClicked) {
		    	r = super.onTouch(event, scaleFactor);
		    	if (!r) return false;
		    	
		    	r = editTextProject.onTouch(event, scaleFactor);
				if (r) {
					if (Common_Settings.settings.EnablesScreenKeyboard) {
						IntegrationKeyboard keyboard = CommonGUI.keyboard;
						if (isMaximized()) {
							Rectangle newBounds = new Rectangle(/*bounds.x, bounds.y,*/0, 0, bounds.width, /*prevSize.height*/(int)(Control.view.getHeight()*0.5f));
							changeBounds(newBounds);
							setHides(false);
							changeBoundsOfKeyboard(bounds);
							keyboard.setHides(false);
						}
			    		else {
			    			changeBoundsOfKeyboard(bounds);
			    			keyboard.setHides(false);
			    		}
					}
					return true;
				}
				
		    	r = editTextPackage.onTouch(event, scaleFactor);
				if (r) {
					if (Common_Settings.settings.EnablesScreenKeyboard) {
						IntegrationKeyboard keyboard = CommonGUI.keyboard;
						if (isMaximized()) {
							Rectangle newBounds = new Rectangle(/*bounds.x, bounds.y,*/0, 0, bounds.width, /*prevSize.height*/(int)(Control.view.getHeight()*0.5f));
							changeBounds(newBounds);
							setHides(false);
							changeBoundsOfKeyboard(bounds);
							keyboard.setHides(false);
						}
			    		else {
			    			changeBoundsOfKeyboard(bounds);
			    			keyboard.setHides(false);
			    		}
					}
					return true;
				}
				
				r = editTextClass.onTouch(event, scaleFactor);
				if (r) {
					if (Common_Settings.settings.EnablesScreenKeyboard) {
						IntegrationKeyboard keyboard = CommonGUI.keyboard;
						if (isMaximized()) {
							Rectangle newBounds = new Rectangle(/*bounds.x, bounds.y,*/0,0, bounds.width, /*prevSize.height*/(int)(Control.view.getHeight()*0.5f));
							changeBounds(newBounds);
							setHides(false);
							changeBoundsOfKeyboard(bounds);
							keyboard.setHides(false);
						}
			    		else {
			    			changeBoundsOfKeyboard(bounds);
			    			keyboard.setHides(false);
			    		}
					}
					return true;
				}
				
				r = this.buttonMainFunc.onTouch(event, scaleFactor);
				if (r) return true;
					
				int i;
	    		for (i=0; i<controls.length; i++) {
	    			r = controls[i].onTouch(event, scaleFactor);
	    			if (r) return true;
	    		}
		    	return true;
	    	}
	    	else return false;
	    }   
	    
	    public void cancel() {
	    	super.cancel();
	    }
	    
	    public void draw(Canvas canvas)
	    {
			if (hides) return;
			synchronized(this) {
				super.draw(canvas);
				staticProject.draw(canvas);
		        staticPackage.draw(canvas);
		        staticClass.draw(canvas);
		        this.staticMainFunc.draw(canvas);
		        
		        editTextProject.draw(canvas);
		        editTextPackage.draw(canvas);
		        editTextClass.draw(canvas);
		        this.buttonMainFunc.draw(canvas);
		        
		        int i;
	    		for (i=0; i<controls.length; i++) {
	    			controls[i].draw(canvas);
	    		}
			}
	    }
	    
	    @Override
		public void onTouchEvent(Object sender, MotionEvent e) {
			
			
			
			if (sender instanceof Button) {
				Button button = (Button)sender;
				if (button.iName==controls[0].iName)	// OK
	            {   
					super.ok();	
					this.callTouchListener(this, null);								
	            }
	            else if (button.iName==controls[1].iName)	// Cancel
	            {
	            	cancel();
	            }			
	            else if (button.iName==this.buttonMainFunc.iName)	// Cancel
	            {
	            	if (this.buttonMainFunc.getIsSelected()) {
	            		this.buttonMainFunc.setText("Enabled");
	            	}
	            	else {
	            		this.buttonMainFunc.setText("Disabled");
	            	}
	            }
			}		
		}
			
}
