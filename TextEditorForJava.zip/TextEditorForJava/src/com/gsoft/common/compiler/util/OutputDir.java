package com.gsoft.common.compiler.util;

import java.io.File;

import com.gsoft.common.Common_Settings;
import com.gsoft.common.FileHelper;
import com.gsoft.common.compiler.Fullname;
import com.gsoft.common.util.ArrayList;

public class OutputDir {
	
	public static String toClassFileName(String javaFilePath) {
		String fullname = Fullname.toFullname(2, javaFilePath);
		String slashedFullname = fullname.replace('.', File.separatorChar);
		String r = Common_Settings.pathOutput + File.separator + slashedFullname + ".class";
		return r;
	}
	
	/**includes subclasses of javaFilePath, Returns a file name of class files. 
	 * @return : String[]*/
	public static ArrayList findClassFiles(String javaFilePath) {
		ArrayList r = new ArrayList(3);
		
		String classFileName = toClassFileName(javaFilePath);
		String fullname = Fullname.toFullname(2, javaFilePath);
		String slashedFullname = fullname.replace('.', File.separatorChar);
		
		String lastToken = null;
		int i;
		for (i=slashedFullname.length()-1; i>=0; i--) {
			char c = slashedFullname.charAt(i);
			if (c==File.separatorChar) {
				lastToken = slashedFullname.substring(i+1, slashedFullname.length());
				break;
			}
		}
		if (i==-1) {
			lastToken = slashedFullname;
		}
		
		
		String dir = FileHelper.getDirectory(classFileName);
		
		File fileOfDir = new File(dir);
		String[] listOfFiles = fileOfDir.list();
		
		for (i=0; i<listOfFiles.length; i++) {
			String filename = listOfFiles[i];
			String ext = FileHelper.getExt(filename);
			if (ext.equals(".class")) {
				int indexOfLastToken = filename.indexOf(lastToken);			
				if (indexOfLastToken==0) {
					//String classFileName = dir + File.separator + filename + ".class";
					if (lastToken.length()+6==filename.length()) {						
						r.add(filename);
					}
					else if (filename.contains(lastToken+"$")){
						r.add(filename);
					}
				}
			}
			
		}
		return r;
		
	}
	
	public static boolean exists(String classFilePath) {
		File classFile = new File(classFilePath);
		if (classFile.exists()) return true;
		return false;
	}

}
