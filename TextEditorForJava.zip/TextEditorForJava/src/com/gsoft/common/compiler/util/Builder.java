package com.gsoft.common.compiler.util;

import java.io.File;
import java.io.IOException;

import com.gsoft.common.CommonGUI;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.Events.MotionEvent;
import com.gsoft.common.FileHelper;
import com.gsoft.common.IO;
import com.gsoft.common.IO_types.ReturnOfReadString;
import com.gsoft.common.IO_types.TextFormat;
import com.gsoft.common.Sizing.Rectangle;
import com.gsoft.common.Sizing.Size;
import com.gsoft.common.interfaces.OnTouchListener;
import com.gsoft.common.compiler.ClassCache;
import com.gsoft.common.compiler.ClassCache.ReturnOfcloneClassCache;
import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.CompilerCache;
import com.gsoft.common.compiler.CompilerInterface;
import com.gsoft.common.compiler.CompilerStatic;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.InterfaceErrorResolver;
import com.gsoft.common.compiler.bytecode.ByteCodeGenerator;
import com.gsoft.common.compiler.gui.CurPathText;
import com.gsoft.common.gui.Buttons.Button;
import com.gsoft.common.gui.Control;
import com.gsoft.common.gui.LoggingScrollable;
import com.gsoft.common.gui.Menu.MenuType;
import com.gsoft.common.gui.MenuWithClosable;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.HighArray_char;
import com.gsoft.common.util.Sort;
import com.gsoft.common.util.Sort.SortItemLong;
import com.gsoft.dependent.ClassFileRunner;
import com.gsoft.dependent.ClassFileRunner.ThreadFindMainClasses;

import com.gsoft.common.compiler.util.SynchronizedObjects;

public class Builder implements OnTouchListener {
	
	static Builder builder = new Builder();
	
	static class JavaFile {
		String path;
		long lastModified;
		JavaFile(String path, long lastModified) {
			this.path = path;
			this.lastModified = lastModified;
		}
	}
	
	public static enum FileListToCompile_Mode {
		AllInProject, 
		AllInPackage,
		AllInPackage_Recursive,
		//PartOr1,
		Only1
	}
	
	static String[] namesOfBuildTypes = {
		"AllInProject", 
		"AllInPackage",
		"AllInPackage_Recursive",
		//"PartOr1",
		"Only1"
	};
	
	static MenuWithClosable menuBuildTypes;

	public static Throwable ErrorOccurred;
	public static boolean buildingCanceled;
	
	public static void openMenuBuildTypes() {
		if (menuBuildTypes!=null) {
			menuBuildTypes.open(builder, true);
		}
	}
	
	public static void createMenuBuildTypes(boolean changeBounds) {
		
		int viewWidth = Control.view.getWidth();
		int viewHeight = Control.view.getHeight();
		int x, y;
		
		float fHeightScale = 0.1f;
		if (namesOfBuildTypes.length>10) fHeightScale = 0.8f;
		else if (namesOfBuildTypes.length>5) fHeightScale = 0.6f;
		else fHeightScale = 0.3f;
		
		int width=(int) (viewWidth*0.6f);
		int height=(int) (viewHeight*fHeightScale);
		x = viewWidth/2-width/2;
		y = viewHeight/2-height/2;
		Rectangle boundsMainClasses = new Rectangle(x,y,width,height);
		if (!changeBounds) {
			if (menuBuildTypes!=null) return;
			//public MenuWithClosable(String name, Rectangle srcBounds, MenuType menuType, Object owner, 
		    //	String[] namesButtons, Size cellSpacing, boolean selectable,
		    //	OnTouchListener listener)
			menuBuildTypes = new MenuWithClosable("BuildTypes", boundsMainClasses, 
					MenuType.Vertical, builder, namesOfBuildTypes, new Size(3,3), true, builder);
			
			/*this.menuMainClasses.buttons[6].selectable = false;	// MultiSelect 메뉴는 토글로 동작한다.
			this.menuMainClasses.buttons[6].toggleable = true;
			this.menuMainClasses.buttons[6].ColorSelected = Color.YELLOW;*/
						
		}
		else {
			if (menuBuildTypes==null) return;
			menuBuildTypes.changeBounds(boundsMainClasses);
		}
		
	}
	
	/**FileListToCompile.txt 없으면 FileListToCompile.txt을 새로 만들고 
	 * packageName 안에 있는 모든 자바파일들의 리스트를 만들어 리턴하고
	 * FileListToCompile.txt이 있으면 컴파일을 해야 할 갱신된 자바 파일들의 리스트를 만들어 리턴한다.
	 * @return ArrayList : File[]*/
	static ArrayList getFileListToCompile(String packageName, FileListToCompile_Mode mode) {
		String filename = Common_Settings.pathConsoleInputAndError+File.separator+"FileListToCompile.txt";
		File fileCompile = new File(filename);
		if (!fileCompile.exists()) {
			//ArrayList r = Builder.findAllJavaFiles(packageName);			
			ArrayList r = null;
			if (mode==FileListToCompile_Mode.AllInProject) {
				//r = Builder.findAllJavaFiles(packageName);
				r = Builder.findAllJavaFilesInProject();
			}
			else if (mode==FileListToCompile_Mode.AllInPackage) {
				r = Builder.findAllJavaFilesInPackage(packageName, false);
			}
			else if (mode==FileListToCompile_Mode.AllInPackage_Recursive) {
				r = Builder.findAllJavaFilesInPackage(packageName, true);
			}
			/*else if (mode==FileListToCompile_Mode.PartOr1) {
				r = CommonGUI.editText_compiler.getCompiler().data.listOfBuild1OrPart.listOfBuild1OrPart;
			}*/
			
			new File(Common_Settings.pathConsoleInputAndError).mkdirs();
			try {
				fileCompile.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
				return null;
			}
			
			return sortByFileSize(r, false);
		}
		else {
			ArrayList fileListToCompile_old = Builder.readFromFileListToCompile();
			ArrayList allFileList = null;
			if (mode==FileListToCompile_Mode.AllInProject) {
				allFileList = Builder.findAllJavaFilesInProject();
			}
			else if (mode==FileListToCompile_Mode.AllInPackage) {
				allFileList = Builder.findAllJavaFilesInPackage(packageName, false);
			}
			else if (mode==FileListToCompile_Mode.AllInPackage_Recursive) {
				allFileList = Builder.findAllJavaFilesInPackage(packageName, true);
			}
			/*else if (mode==FileListToCompile_Mode.PartOr1) {
				allFileList = CommonGUI.editText_compiler.getCompiler().data.listOfBuild1OrPart.listOfBuild1OrPart;
			}*/
			ArrayList fileListToCompile_new = Builder.createJavaFileList(allFileList);
			ArrayList updateList = Builder.compareWith(fileListToCompile_old, fileListToCompile_new);
			
			ArrayList noneExistClassFilesList = getNoneExistClassFilesList(allFileList);
			ArrayList noneExistClassFilesList_new = new ArrayList(noneExistClassFilesList.count);
			int i, j;
			// updateList에 이미 있는지를 체크해서 중복성을 제거해서 새로운 noneExistClassFilesList_new을 만든다.
			for (i=0; i<noneExistClassFilesList.count; i++) {
				String javaFilenameWithoutClassFile = ((File)noneExistClassFilesList.getItem(i)).getAbsolutePath();
				boolean found = false;
				for (j=0; j<updateList.count; j++) {
					String javaFilenameToUpdate = ((File)updateList.getItem(j)).getAbsolutePath();
					if (javaFilenameWithoutClassFile.equals(javaFilenameToUpdate)) {
						found = true;
						break;
					}
				}
				if (!found) {
					noneExistClassFilesList_new.add(noneExistClassFilesList.getItem(i));
				}
				
			}
			for (i=0; i<noneExistClassFilesList_new.count; i++) {
				updateList.add(noneExistClassFilesList_new.getItem(i));
			}
			
			ArrayList result = new ArrayList(30);
			for (i=0; i<updateList.count; i++) {
				File file = (File) updateList.getItem(i);
				result.add(file);
			}
			InterfaceErrorResolver.findJavaFilesReferringModifiedDocumentsInProject(updateList, result, 0);
			
			return sortByFileSize(result, false);
		}
	}
	
	/**FileListToCompile.txt 없으면 FileListToCompile.txt을 새로 만들고 
	 * packageName 안에 있는 모든 자바파일들의 리스트를 만들어 리턴하고
	 * FileListToCompile.txt이 있으면 컴파일을 해야 할 갱신된 자바 파일들의 리스트를 만들어 리턴한다.
	 * getFileListToCompile(packageName)과 다른 점은 javaFileName라는 소스 파일 하나에 대해서만 
	 * 컴파일을 해야 할지를 결정한다는 것이다.
	 * @return ArrayList : File[]*/
	static ArrayList getFileListToCompile(String packageName, String javaFileName, FileListToCompile_Mode mode) {
		String filename = Common_Settings.pathConsoleInputAndError+File.separator+"FileListToCompile.txt";
		File fileCompile = new File(filename);
		if (!fileCompile.exists()) {
			//ArrayList r = Builder.findAllJavaFiles(packageName);
			ArrayList r = null;
			if (mode==FileListToCompile_Mode.AllInProject) {
				//r = Builder.findAllJavaFiles(packageName);
				r = Builder.findAllJavaFilesInProject();
			}
			else if (mode==FileListToCompile_Mode.AllInPackage) {
				r = Builder.findAllJavaFilesInPackage(packageName, false);
			}
			else if (mode==FileListToCompile_Mode.AllInPackage_Recursive) {
				r = Builder.findAllJavaFilesInPackage(packageName, true);
			}
			/*else if (mode==FileListToCompile_Mode.PartOr1) {
				r = CommonGUI.editText_compiler.getCompiler().data.listOfBuild1OrPart.listOfBuild1OrPart;
			}*/
			else if (mode==FileListToCompile_Mode.Only1) {
				r = new ArrayList(1);
				r.add(new File(javaFileName));
			}
			
			new File(Common_Settings.pathConsoleInputAndError).mkdirs();
			try {
				fileCompile.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
				return null;
			}
			//Builder.makeFileListToCompile(r);
			return sortByFileSize(r, false);
		}
		else {
			ArrayList fileListToCompile_old = Builder.readFromFileListToCompile();
			ArrayList javaFileList = null;
			if (mode==FileListToCompile_Mode.AllInProject) {
				//javaFileList = Builder.findAllJavaFiles(packageName);
				javaFileList = Builder.findAllJavaFilesInProject();
			}
			else if (mode==FileListToCompile_Mode.AllInPackage) {
				javaFileList = Builder.findAllJavaFilesInPackage(packageName, false);
			}
			else if (mode==FileListToCompile_Mode.AllInPackage_Recursive) {
				javaFileList = Builder.findAllJavaFilesInPackage(packageName, true);
			}
			/*else if (mode==FileListToCompile_Mode.PartOr1) {
				javaFileList = CommonGUI.editText_compiler.getCompiler().data.listOfBuild1OrPart.listOfBuild1OrPart;
			}*/
			else if (mode==FileListToCompile_Mode.Only1) {
				javaFileList = new ArrayList(1);
				javaFileList.add(new File(javaFileName));
			}
			ArrayList fileListToCompile_new = Builder.createJavaFileList(javaFileList);
			ArrayList updateList = Builder.compareWith(fileListToCompile_old, fileListToCompile_new);
			
			ArrayList noneExistClassFilesList = getNoneExistClassFilesList(javaFileList);
			ArrayList noneExistClassFilesList_new = new ArrayList(noneExistClassFilesList.count);
			int i, j;
			// updateList에 이미 있는지를 체크해서 중복성을 제거해서 새로운 noneExistClassFilesList_new을 만든다.
			for (i=0; i<noneExistClassFilesList.count; i++) {
				String javaFilenameWithoutClassFile = ((File)noneExistClassFilesList.getItem(i)).getAbsolutePath();
				boolean found = false;
				for (j=0; j<updateList.count; j++) {
					String javaFilenameToUpdate = ((File)updateList.getItem(j)).getAbsolutePath();
					if (javaFilenameWithoutClassFile.equals(javaFilenameToUpdate)) {
						found = true;
						break;
					}
				}
				if (!found) {
					noneExistClassFilesList_new.add(noneExistClassFilesList.getItem(i));
				}
				
			}
			for (i=0; i<noneExistClassFilesList_new.count; i++) {
				updateList.add(noneExistClassFilesList_new.getItem(i));
			}
			
			ArrayList result = new ArrayList(30);
			for (i=0; i<updateList.count; i++) {
				File file = (File) updateList.getItem(i);
				result.add(file);
			}
			InterfaceErrorResolver.findJavaFilesReferringModifiedDocumentsInProject(updateList, result, 0);
			
			return sortByFileSize(updateList, false);
		}
	}
	
	/** Sorts fileList by its size and returns file[]
	 * @param fileList : file[]
	 * @param upOrDown : up(true), down(false)*/
	static ArrayList sortByFileSize(ArrayList fileList, boolean upOrDown) {
		int i;
		ArrayList sortList = new ArrayList(fileList.count);
		for (i=0; i<fileList.count; i++) {
			File file = (File) fileList.getItem(i);
			SortItemLong sortItem = new SortItemLong(file.length(), file);
			sortList.add(sortItem);
		}
		Sort.sort_Long(sortList);
		
		ArrayList r = new ArrayList(sortList.count);
		if (upOrDown) {
			for (i=0; i<sortList.count; i++) {
				SortItemLong sortItem = (SortItemLong) sortList.getItem(i);
				r.add(sortItem.obj);
				
			}
		}
		else {
			for (i=sortList.count-1; i>=0; i--) {
				SortItemLong sortItem = (SortItemLong) sortList.getItem(i);
				r.add(sortItem.obj);				
			}
		}
		return r;
	}
	
	/** java파일은 있지만 class파일은 없는 java파일들을 찾아 File[]으로 리턴한다.
	 * @return ArrayList : File[], 자바 파일 리스트
	 * @param allJavaFileList : File[]*/
	static ArrayList getNoneExistClassFilesList(ArrayList allJavaFilesList) {
		ArrayList r = new ArrayList(5);
		r.resizeInc = 10;
		String outputDir = Common_Settings.pathOutput;
		//String packageDir = outputDir+File.separator+packageName;
		//packageDir = packageDir.replace('.', File.separatorChar);
		String projectDir = Common_Settings.pathProjectSrc;
		int i, j;
		//ArrayList listOfClassFiles = FileHelper.getFileList(packageDir, false);
		ArrayList listOfClassFiles = FileHelper.getFileList(outputDir, true);
		
		boolean[] existList = new boolean[allJavaFilesList.count];
		for (i=0; i<allJavaFilesList.count; i++) {
			File javaFile = (File) allJavaFilesList.getItem(i);
			String absJavaFilename = javaFile.getAbsolutePath();
			// .java
			String fullJavaName = null;
			if (javaFile.isDirectory()) {
				if (projectDir.length()+1<=absJavaFilename.length()-1) {
					fullJavaName = absJavaFilename.substring(projectDir.length()+1, absJavaFilename.length());
				}
			}
			else if (absJavaFilename.charAt(absJavaFilename.length()-4)=='j' && absJavaFilename.charAt(absJavaFilename.length()-3)=='a' &&
				absJavaFilename.charAt(absJavaFilename.length()-2)=='v' && absJavaFilename.charAt(absJavaFilename.length()-1)=='a') { 
				if (projectDir.length()+1<absJavaFilename.length() && absJavaFilename.length()-5>=0) {
					fullJavaName = absJavaFilename.substring(projectDir.length()+1, absJavaFilename.length()-5);
				}
			} 
			else {
				existList[i] = true;
				continue;
			}
			if (fullJavaName==null) continue;
			for (j=0; j<listOfClassFiles.count; j++) {
				File classFile = (File) listOfClassFiles.getItem(j);
				String absFilename = classFile.getAbsolutePath();
				// .class
				String fullClassName = null;
				if (classFile.isDirectory()) {
					if (outputDir.length()+1<=absFilename.length()-1) {
						fullClassName = absFilename.substring(outputDir.length()+1, absFilename.length());
					}
				}
				else if (absFilename.charAt(absFilename.length()-5)=='c' && absFilename.charAt(absFilename.length()-4)=='l' &&
					absFilename.charAt(absFilename.length()-3)=='a' && absFilename.charAt(absFilename.length()-2)=='s' &&
					absFilename.charAt(absFilename.length()-1)=='s') 
				{	
					if (outputDir.length()+1<absFilename.length() && absFilename.length()-6>=0) {
						fullClassName = absFilename.substring(outputDir.length()+1, absFilename.length()-6);
					}	
				}
				else {
					continue;
				}
				
				if (fullClassName==null) continue;
				if (fullJavaName.equals(fullClassName)) {
					existList[i] = true;
					break;
				}
			}//for (j=0; j<listOfClassFiles.count; j++) {
		}
		
		for (i=0; i<existList.length; i++) {
			if (!existList[i]) {
				// java파일은 있지만 class파일은 없는 java파일인 경우
				r.add(allJavaFilesList.getItem(i));
			}
		}
		return r;
	}
	
	/**fileListToCompile_old에 오래된 버전이 있거나 fileListToCompile_old에 없을 경우에는 file[]으로 리턴한다.*/
	static ArrayList compareWith(ArrayList fileListToCompile_old, ArrayList fileListToCompile_new) {
		int i, j;
		ArrayList r = new ArrayList(10);
		for (i=0; i<fileListToCompile_new.count; i++) {
			JavaFile javaFile_new = (JavaFile) fileListToCompile_new.getItem(i);
			String strPathNew = javaFile_new.path;
			for (j=0; j<fileListToCompile_old.count; j++) {
				JavaFile javaFile_old = (JavaFile) fileListToCompile_old.getItem(j);
				String strPathOld = javaFile_old.path;
				if (strPathNew.equals(strPathOld)) {
					if (javaFile_new.lastModified!=javaFile_old.lastModified) {
						File file = new File(javaFile_new.path);
						r.add(file);							
					}
					break;
				}
			}
			if (j==fileListToCompile_old.count) {
				File file = new File(javaFile_new.path);
				r.add(file);
			}
		}
		
		return r;
	}
	
	
	/**mPackageName에서 최상위 토큰을 찾는다. 
	      예를들어 mPackageName이 com.gsoft.common.gui에서 최상위 토큰은 com이다.
	   com안에 있는 모든 자바 파일들을 찾는다.
	   @return ArrayList : File[]*/
	public static ArrayList findAllJavaFilesInProject(/*String packageName*/) {		
		/*int indexOfDot = packageName.indexOf(".");
		String topOfPackageName = null;
		if (indexOfDot==-1) {
			topOfPackageName = packageName;
		}
		else {
			topOfPackageName = packageName.substring(0, indexOfDot);
		}
		String packageFileName = Common_Settings.pathProjectSrc+File.separator+topOfPackageName;*/
		String packageFileName = Common_Settings.pathProjectSrc;
		ArrayList fileList = FileHelper.getFileList(packageFileName, true);
		
		ArrayList newFileList = Builder.findJavaFiles(fileList);
		return newFileList;
	}
	
	/**Common_Settings.pathJaneSoft/project 안에 있는 모든 자바 파일들을 찾는다.
	 @return ArrayList : File[]*/
	static ArrayList findAllProjectJavaFiles() {	
		String packageFileName = Common_Settings.pathJaneSoft+File.separator+"project";
		ArrayList fileList = FileHelper.getFileList(packageFileName, true);
		ArrayList newFileList = Builder.findJavaFiles(fileList);
		return newFileList;
	}
	
	static ArrayList findJavaFiles(ArrayList fileList) {
		int i;
		ArrayList newFileList = new ArrayList(fileList.count);
		for (i=0; i<fileList.count; i++) {
			File file = (File) fileList.getItem(i);
			String ext = FileHelper.getExt(file.getAbsolutePath());
			if (ext.equals(".java")) {
				newFileList.add(file);
			}
		}
		return newFileList;
	}
	
	/**mPackageName에서 최상위 토큰을 찾는다. 
    예를들어 mPackageName이 com.gsoft.common.gui에서 최상위 토큰은 com이다.
	 com안에 있는 모든 자바 파일들을 찾는다.
	 @return ArrayList : File[]
	 @param isRecursive : 디렉토리내에서도 찾아야 할 경우*/
	public static ArrayList findAllJavaFilesInPackage(String packageName, boolean isRecursive) {		
		String slashedPackageName = packageName.replace('.', File.separatorChar);
		String packageFileName = Common_Settings.pathProjectSrc+File.separator+slashedPackageName;
		ArrayList fileList = FileHelper.getFileList(packageFileName, isRecursive);
		ArrayList newFileList = Builder.findJavaFiles(fileList);
		return newFileList;
	}
	
	/** setted in EditText_Compiler.saveDialog_handler()*/
	public static ArrayList modifiedCompilers = null;
	
	
	
	
	
	/**@return ArrayList : File[]*/
	/*static ArrayList find1OrPartJavaFiles() {
		ArrayList fileList = new ArrayList(CompilerStatic.listOfBuild1OrPart.count);
		int i;
		for (i=0; i<CompilerStatic.listOfBuild1OrPart.count; i++) {
			File path = (File) CompilerStatic.listOfBuild1OrPart.getItem(i);
			fileList.add(path);
		}
		return fileList;
	}*/
	
	/** allFileList에서 FileListToCompile.txt을 만든다.
	 * @param allFileList : File[]*/
	static void makeFileListToCompile(ArrayList allFileList) {
		if (allFileList==null) return;
		
		String jarDir = Common_Settings.pathConsoleInputAndError;
		File jarDirFile = new File(jarDir);
		if (!jarDirFile.exists()) {
			jarDirFile.mkdirs();
		}
		String filename = jarDir + File.separator + "FileListToCompile.txt";
		HighArray_char result = new HighArray_char(500);
		
		int i;
		for (i=0; i<allFileList.count; i++) {
			File javaFile = (File) allFileList.getItem(i);
			if (javaFile.isDirectory()) continue;
			long modifiedTime = javaFile.lastModified();
			result.add(javaFile.getAbsolutePath());
			result.add(";");
			result.add(String.valueOf(modifiedTime));
			result.add("\n");
		}
		
		HighArray_char strResult = result;
		IO.writeString(filename, strResult, TextFormat.UTF_8, false, true);
	}
	
	/** updateFileList에서 FileListToCompile.txt을 갱신한다.
	 * @param updateFileList : File[]*/
	static void updateFileListToCompile(ArrayList updateFileList) {
		String filename = Common_Settings.pathConsoleInputAndError+File.separator+"FileListToCompile.txt";
		
		ArrayList list = Builder.readFromFileListToCompile();
		HighArray_char result = new HighArray_char(500);
		
		ArrayList newUpdateFileList = new ArrayList(updateFileList.count);
		
		int i, j;
		for (j=0; j<updateFileList.count; j++) {
			File updateFile = (File) updateFileList.getItem(j);
			String updatePath = updateFile.getAbsolutePath(); 
			for (i=0; i<list.count; i++) {
				JavaFile javaFile = (JavaFile) list.getItem(i);
				String path = javaFile.path;
				if (updatePath.equals(path)) {
					javaFile.lastModified = updateFile.lastModified();
					break;
				}
			}
			if (i==list.count) {
				// 못 찾았으면
				newUpdateFileList.add(updateFile);
			}
		}
		
		for (j=0; j<newUpdateFileList.count; j++) {
			File updateFile = (File) newUpdateFileList.getItem(j);
			String updatePath = updateFile.getAbsolutePath();
			long modifiedTime = updateFile.lastModified();
			JavaFile javaFile = new JavaFile(updatePath, modifiedTime);
			list.add(javaFile);
		}
		
		for (i=0; i<list.count; i++) {
			JavaFile javaFile = (JavaFile) list.getItem(i);
			long modifiedTime = javaFile.lastModified;
			result.add(javaFile.path);
			result.add(";");
			result.add(String.valueOf(modifiedTime));
			result.add("\n");
		}
		
		HighArray_char strResult = result;
		IO.writeString(filename, strResult, TextFormat.UTF_8, false, true);
	}
	
	/** BuildAll을 할 당시의 모든 자바파일들의 lastModified을 얻고 JavaFile[]을 리턴한다.
	 * @param allFileList : File[]
	 *  @return ArrayList : JavaFile[]*/
	static ArrayList createJavaFileList(ArrayList allFileList) {
		ArrayList r = new ArrayList(20);
		int i;
		for (i=0; i<allFileList.count; i++) {
			File file = (File) allFileList.getItem(i);
			if (file.isDirectory()) continue;
			r.add(new JavaFile(file.getAbsolutePath(), file.lastModified()));
		}
		return r;
	}
	
	/** FileListToCompile.txt에서  JavaFile[]을 읽어서 리턴한다.
	 * @return ArrayList : JavaFile[]*/
	static ArrayList readFromFileListToCompile() {
		String filename = Common_Settings.pathConsoleInputAndError+File.separator+"FileListToCompile.txt";
		ReturnOfReadString input = IO.readString(filename);
		if (input==null) return new ArrayList(0);
		
		HighArray_char strInput = input.result;
		
		ArrayList r = new ArrayList(20);
		int i;
		String path = null;
		String strLastModified = null;
		int startIndex = 0;
		int endIndex = -1;
		for (i=0; i<strInput.count; i++) {
			if (i+1<strInput.count && strInput.charAt(i+1)==';') {
				endIndex = i+1;
				path = strInput.substring(startIndex, endIndex);
				startIndex = i+2;
			}
			else if (i+1<strInput.count && strInput.charAt(i+1)=='\n') {
				endIndex = i+1;
				strLastModified = strInput.substring(startIndex, endIndex);
				startIndex = i+2;
				r.add(new JavaFile(path, Long.parseLong(strLastModified)));
			}
		}
		return r;
	}
	
	/**현재 로드한 자바파일에 대해서만 클래스 파일을 만든다.
	 * @param isModefied */
	public static void build(Compiler compiler, boolean waitForBuild, FileListToCompile_Mode fileListToCompile_Mode) {
		/*if (com.gsoft.common.compiler.CompilerStatic.errors.count!=0) {
			CommonGUI.showMessage(true, "Check errors in the problems list");
			return;
		}*/
		
		ThreadBuild thread = new ThreadBuild(fileListToCompile_Mode);
		thread.start();
		
		if (waitForBuild) {
			try {
				thread.join();
			} catch (InterruptedException e) {
				
				if (Common_Settings.g_printsLog) e.printStackTrace();
			}
		}
	}
	
	
	
	
	public enum RunOrDebug {
		Run,
		Debug
	}
	
	
	/** Run, Run1, Debug*/
	public static class ThreadBuildAndRunOrDebug extends Thread {
		private Compiler compiler;
		private FileListToCompile_Mode fileListToCompile_Mode;
		private RunOrDebug runOrDebug;
		private String filePathToRun;
		ThreadBuildAndRunOrDebug(Compiler compiler, String filePathToRun, FileListToCompile_Mode fileListToCompile_Mode, RunOrDebug runOrDebug) {
			this.compiler = compiler;
			this.filePathToRun  = filePathToRun;
			this.fileListToCompile_Mode = fileListToCompile_Mode;
			this.runOrDebug = runOrDebug;
		}
		public void run() {
			Builder.buildAndRunOrDebug_sub(compiler, filePathToRun, fileListToCompile_Mode, runOrDebug);
		}
	}
	
	/** Run, Run1, Debug, entry point*/
	public static void buildAndRunOrDebug(Compiler compiler, String filePathToRun, FileListToCompile_Mode fileListToCompile_Mode, RunOrDebug runOrDebug) {
		ThreadBuildAndRunOrDebug thread = new ThreadBuildAndRunOrDebug(compiler, filePathToRun, fileListToCompile_Mode, runOrDebug);
		thread.start();
	}
	
	/** Run, Run1, Debug*/
	static void buildAndRunOrDebug_sub(Compiler compiler, String filePathToRun, FileListToCompile_Mode fileListToCompile_Mode, RunOrDebug runOrDebug) {
		
		// build이 끝날때까지 기다린다.
		Builder.build(compiler, true, fileListToCompile_Mode);
		
		
		if (com.gsoft.common.compiler.CompilerStatic.errors.count!=0) {
			CommonGUI.showMessage(true, "Check errors in the problems list");
			return;
		}
		
		//Compiler.PairErrorExists = false;
		
		// compiler.packageName에서 main함수를 포함하는 클래스들을 찾는다.
		if (filePathToRun!=null) {
			CommonGUI.fileDialog.mAbsFilename = filePathToRun;
		}
		else {
			if (fileListToCompile_Mode==FileListToCompile_Mode.AllInProject) {
				CommonGUI.fileDialog.mAbsFilename = Common_Settings.pathOutput/*+File.separator+
						compiler.data.packageName.replace('.', File.separatorChar)*/;
			}
		}
		ClassFileRunner.mAbsFilename = CommonGUI.fileDialog.mAbsFilename;
		ThreadFindMainClasses javaThread = new ThreadFindMainClasses(ClassFileRunner.mAbsFilename, runOrDebug);	
		javaThread.start();
		
	}
	
	/**PackageAndImportClassesInFile[]
	 * @param fileList */
	//static ArrayList allJavaFilesInProject;
	
	
	
	public static void build(ArrayList fileList) {
		
		// The number of ClassCache is 1.
		InterfaceErrorResolver.deleteOldClassFiles(fileList);
		
		// The number of ClassCache is numOfCores.
		runThreadBuild_PerCore(fileList);
				
		// The number of ClassCache is 1.
		CompilerCache.listOfCompilers = Builder.clonedCompilerCache;
		ClassCache.restoreClassCache(Builder.clonedClassCache);
		
		if (CompilerStatic.errors.count==0) {
			CommonGUI.editText_compiler.resetButtonProblemsAndProblemsAllColor();
		}
	
		System.gc();
		
		Builder.modifiedCompilers = null;
		
		// The number of ClassCache is 1.
		/*CompilerCache.listOfCompilers.count = 0;
		ClassCache.resetClassCache();
		
		CompilerStatic.errors.reset2();		
		
		
		// The number of ClassCache is numOfCores.
		int numOfCores = runThreadBuild_PerCore(fileList);
				
		// The number of ClassCache is 1.
		ClassCache.restoreClassCache(numOfCores);
		
		if (CompilerStatic.errors.count==0) {
			CommonGUI.editText_compiler.resetButtonProblemsAndProblemsAllColor();
		}
	
		System.gc();
		
		Builder.modifiedCompilers = null;*/
	}
	
	static ArrayList listOfhreadBuild_PerCore;
	
	public static void cancelBuild() {
		int i;
		for (i=0; i<listOfhreadBuild_PerCore.count; i++) {
			ThreadBuild_PerCore thread = (ThreadBuild_PerCore) listOfhreadBuild_PerCore.getItem(i);
			thread.cancelBuild = true;
		}
		buildingCanceled = true;
	}
	
	static int runThreadBuild_PerCore(ArrayList fileList) {
		int numOfCores = Runtime.getRuntime().availableProcessors();
		numOfCores--;
		if (numOfCores<=0) numOfCores = 1;
		
		numOfCores = 1;
		
		ClassCache.makeClassCachesForMultiCore(numOfCores);
		
		int i;
		
		
		ArrayList[] fileListForMultiCore = new ArrayList[numOfCores];
		int countOfFileListOfCoreThread = fileList.count / numOfCores + 1;
		for (i=0; i<numOfCores; i++) {
			fileListForMultiCore[i] = new ArrayList(countOfFileListOfCoreThread);
		}
		
		for (i=0; i<fileList.count; i++) {
			File file = (File) fileList.getItem(i);
			int s = i % numOfCores;			
			fileListForMultiCore[s].add(file);
		}
		
		listOfhreadBuild_PerCore = new ArrayList(numOfCores);
		for (i=0; i<numOfCores; i++) {			
			ThreadBuild_PerCore thread = new ThreadBuild_PerCore(i, fileListForMultiCore[i], numOfCores);
			listOfhreadBuild_PerCore.add(thread);
			thread.start();
		}
		for (i=0; i<numOfCores; i++) {			
			ThreadBuild_PerCore thread = (ThreadBuild_PerCore) listOfhreadBuild_PerCore.getItem(i);
			try {
				thread.join();
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
		}
		
		return numOfCores;
	}
	
	static class ThreadBuild_PerCore extends Thread {
		private ArrayList fileList;
		private int coreThreadID;
		public boolean cancelBuild = false;
		
		ThreadBuild_PerCore(int coreThreadID, ArrayList fileList, int numOfCores) {
			this.fileList = fileList;
			this.coreThreadID = coreThreadID;
		}
		public void run() {
			try {
				int i;
				for (i=0; i<fileList.count; i++) {
					if (cancelBuild) {						
						break;
					}
					File file = (File) fileList.getItem(i);
					Builder.build(file, coreThreadID);
					if (i % 2==1) {
						Builder.callGCAndWait(file);
					}
				}
			}catch(Throwable e) {
				e.printStackTrace();
				Builder.ErrorOccurred = e;
			}
		}
	}
	
	public static void callGCAndWait(File file) {
		long fileSize = file.length();
		if (fileSize>100*1000) {
			System.gc();
			try {
				Thread.sleep(1500);
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
		}
		else if (fileSize>50*1000) {
			System.gc();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
		}
		else if (fileSize>20*1000) {
			System.gc();
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
		}
		else {
			
		}
	}
	
	public static FindClassParams start2_usingCache(String filePath, String fullClassName, int coreThreadID) {
		Compiler compiler = start2_usingCache(filePath, coreThreadID);
		int i;
		for (i=0; i<compiler.data.mlistOfAllDefinedClasses.count; i++) {
			FindClassParams c = (FindClassParams) compiler.data.mlistOfAllDefinedClasses.getItem(i);
			if (c.name.equals(fullClassName))
				return c;
		}
		return null;
	}
	
	public static Compiler start2_usingCache(String filePath, int coreThreadID) {
		Compiler cachedCompiler = CompilerCache.findCompiler(filePath);
		Compiler compilerLocal = null;
		if (cachedCompiler!=null) {
			compilerLocal = cachedCompiler;
		}
		else {
			Compiler cachedCompilerInClassCache = ClassCache.findCompiler(filePath, coreThreadID);
			if (cachedCompilerInClassCache!=null) {
				compilerLocal = cachedCompilerInClassCache;
				((CompilerInterface)compilerLocal).start2_WhenUsingClassCache(filePath, coreThreadID);
			}
			else {
				compilerLocal = new CompilerInterface();
				// 클래스 캐시가 갱신된다.
				((CompilerInterface)compilerLocal).start2(
						Common_Settings.backColor, filePath, coreThreadID);
			}				
		}
		return compilerLocal;
	}
	
	public static void build(File file, int coreThreadID) {
		try {
			if (file.isDirectory()) return;
			String filePath = file.getAbsolutePath();
			String extension = FileHelper.getExt(filePath);
			if (!extension.equals(".java")) return;				
			// 디렉토리와 확장자가 .java가 아닌 파일들은 제외한다.
			
					
			Compiler compilerLocal = start2_usingCache(filePath, coreThreadID);
			
			
			
			// 에러가 없거나 있더라도 새로 만들어진 compilerLocal을 가지고 editText_compiler의 compiler를 대체한다.
			/*if (filePath.equals(CommonGUI.editText_compiler.getCompiler().data.filename)) {
				CommonGUI.editText_compiler.setCompiler(compilerLocal);
			}*/
			
			ByteCodeGenerator codeGen = null;
			if (CompilerStatic.errors.count==0 && !compilerLocal.PairErrorExists) {
				//Compiler.PairErrorExists = false;
				// 새로 만들어진 compilerLocal을 가지고 generate()를 한다.
				codeGen = new ByteCodeGenerator(compilerLocal, compilerLocal.data.mlistOfClass, coreThreadID);
				codeGen.generate(compilerLocal);
				if (CompilerStatic.errors.count==0 && !compilerLocal.PairErrorExists) {					
					ArrayList updateList = new ArrayList(1);
					updateList.add(new File(filePath));
					
					synchronized (SynchronizedObjects.lockForMultiThreadBuild) {
						Builder.updateFileListToCompile(updateList);
						CommonGUI.showMessage(true, compilerLocal.data.filename+ " is completed");
					}				
				}// if (CompilerStatic.errors.count==0) {
			}// if (CompilerStatic.errors.count==0) {
			
			if (codeGen!=null) {
				codeGen.destroy();
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	static int getLimitCountOfClassCache(int numOfCores) {
		if (numOfCores>=4) {
			return 10;
		}
		else if (numOfCores>=2) {
			return 30;
		}
		return 50;
	}
	
	/**made in ThreadBuild.run()*/
	static ArrayList clonedCompilerCache;
	/**made in ThreadBuild.run()*/
	static ReturnOfcloneClassCache clonedClassCache;
	
	//public static boolean isBuilding;
	
	public static class ThreadBuild extends Thread {
		
		
		
		//EditText_Compiler owner;
		/** 자바 파일을 로드하였을 때 compiler.packageName을 갖는다.
		 */
		//public String mPackageName;
		FileListToCompile_Mode fileListToCompile_Mode;
		public ThreadBuild(FileListToCompile_Mode fileListToCompile_Mode) {
			this.fileListToCompile_Mode = fileListToCompile_Mode;
		}
		
		/**mPackageName에 있는 모든 자바파일들에 대해 클래스 파일들을 만든다.*/
		public void run() {
			Control.view.postInvalidate();
			
			LoggingScrollable.longOperation = true;
			
			try {
				CompilerStatic.errors = CompilerStatic.errors.removeErrorsOutSideOfProject(Common_Settings.pathProjectSrc);
				
				Builder.clonedCompilerCache = CompilerCache.cloneCache();
				Builder.clonedClassCache =  ClassCache.cloneClassCache();
				
				CompilerCache.listOfCompilers.count = 0;
				ClassCache.resetClassCache();
				
				CompilerStatic.errors.reset2();
				
				
				String mPackageName = CommonGUI.editText_compiler.getCompiler().data.packageName;
				ArrayList fileList = null;
				if (fileListToCompile_Mode==FileListToCompile_Mode.Only1) {
					fileList = Builder.getFileListToCompile(mPackageName, CommonGUI.editText_compiler.getCompiler().data.filename, 
							fileListToCompile_Mode);
				}
				else {
					fileList = Builder.getFileListToCompile(mPackageName, fileListToCompile_Mode);
				}
				
				Builder.ErrorOccurred = null;
				Builder.buildingCanceled = false;
				
				Builder.build(fileList);
				
				String curFileName = CommonGUI.editText_compiler.getCompiler().data.filename;
				CurPathText.setCurPathTextPlusProjectName(curFileName);
				
				if (Builder.buildingCanceled) {
					CommonGUI.showMessage(true, "Canceled Building");
				}
				else {
					if (Builder.ErrorOccurred==null) {
						if (com.gsoft.common.compiler.CompilerStatic.errors.count==0) {
							if (fileListToCompile_Mode==FileListToCompile_Mode.AllInProject) {
								CommonGUI.showMessage(true, "BuildAll is completed");
							}
							else {
								CommonGUI.showMessage(true, "Build is completed");
							}
						}
						else {
							CommonGUI.showMessage(true, "Check errors in the problems list");
						}
					}
					else {
						CommonGUI.showMessage(true, Builder.ErrorOccurred.getMessage());
					}
				}
			}catch(Exception e) {
				e.printStackTrace();
			}
			finally {
				LoggingScrollable.longOperation = false;
			}
			
			Control.view.postInvalidate();
		}
	}

	@Override
	public void onTouchEvent(Object sender, MotionEvent e) {
		
		if (sender instanceof Button) {
			Button button = (Button) sender;
			menuBuildTypes.open(false);
			if (button.iName==menuBuildTypes.buttons[0].iName) {
				// "AllInProject", 
				Builder.build(CommonGUI.editText_compiler.getCompiler(), false, FileListToCompile_Mode.AllInProject);
			}
			else if (button.iName==menuBuildTypes.buttons[1].iName) {
				// "AllInPackage", 
				Builder.build(CommonGUI.editText_compiler.getCompiler(), false, FileListToCompile_Mode.AllInPackage);
			}
			else if (button.iName==menuBuildTypes.buttons[2].iName) {
				// "AllInPackage_Recursive", 
				Builder.build(CommonGUI.editText_compiler.getCompiler(), false, FileListToCompile_Mode.AllInPackage_Recursive);
			}
			else if (button.iName==menuBuildTypes.buttons[3].iName) {
				// "Only1", 
				Builder.build(CommonGUI.editText_compiler.getCompiler(), false, FileListToCompile_Mode.Only1);
			}			
		}// if (sender instanceof Button) {
	}
}
