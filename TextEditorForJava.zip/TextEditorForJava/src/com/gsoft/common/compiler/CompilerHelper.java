package com.gsoft.common.compiler;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import com.gsoft.common.Code.CodeChar;
import com.gsoft.common.Code.CodeString;
import com.gsoft.common.Code.CodeStringType;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.FileHelper;
import com.gsoft.common.IO;
import com.gsoft.common.IO_types.TextFormat;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.Compiler_types.FindControlBlockParams;
import com.gsoft.common.compiler.Compiler_types.FindFuncCallParam;
import com.gsoft.common.compiler.Compiler_types.FindFunctionParams;
import com.gsoft.common.compiler.Compiler_types.FindIndependentFuncCallParams;
import com.gsoft.common.compiler.Compiler_types.FindVarParams;
import com.gsoft.common.compiler.Compiler_types.FindVarUseParams;
import com.gsoft.common.compiler.Compiler_types_Base.AccessModifier;
import com.gsoft.common.compiler.Compiler_types_Base.AccessModifier.AccessPermission;
import com.gsoft.common.compiler.Compiler_types_Base.FindStatementParams;
import com.gsoft.common.compiler.Compiler_types_Special.FindSpecialBlockParams;
import com.gsoft.common.compiler.bytecode.HighArrayCharForByteCode;
import com.gsoft.common.compiler.classloader.Loader;
import com.gsoft.common.gui.Control;
import com.gsoft.common.gui.TextView;
import com.gsoft.common.util.Array;
import com.gsoft.common.util.ArrayListChar;
import com.gsoft.common.util.ArrayListCodeString;
import com.gsoft.common.util.ArrayListIReset;
import com.gsoft.common.util.ArrayListString;
import com.gsoft.common.util.HighArray;
import com.gsoft.common.util.HighArray_CodeChar;
import com.gsoft.common.util.Util.StackTracer;
import com.gsoft.common.util.hash.Hashtable2_String;

import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.HighArray_CodeString;
import com.gsoft.common.compiler.StringTokenizer;
import com.gsoft.common.compiler.Checker;
import com.gsoft.common.compiler.CompilerStatic;
import com.gsoft.common.compiler.Compiler_types_Static;
import com.gsoft.common.compiler.TemplateBase;
import com.gsoft.common.compiler.Number;

public class CompilerHelper {
	
	public static String getTypeName(Compiler compiler, FindVarUseParams varUse) {
		String typeName = null;
		CodeString varUseName = compiler.data.mBuffer.getItem(varUse.index());
		if (CompilerHelper.IsConstant(varUseName)) {
			if (varUseName.charAt(0).c=='"') {
				typeName = "java.lang.String";
			}
			else if (varUseName.charAt(0).c=='\'') {
				typeName = "char";
			}
			else {
				int numberType = Number.IsNumber2(varUseName);
				return Number.getNumberString(numberType);
			}
		}
		else {
			FindVarParams var = varUse.getOriginalVar();			
			typeName = var.typeName;
		}
		return typeName;
	}
	
	
	public static CodeString getNameOfControlBlock(Compiler compiler, FindControlBlockParams controlBlock) {
		CodeString name = null;
		if (controlBlock.nameIndex()!=-1) {
			// 일반적인 controlBlock의 nameIndex는 null이 아니다
			name = compiler.data.mBuffer.getItem(controlBlock.nameIndex());
		}
		else if (controlBlock instanceof FindSpecialBlockParams) {
			// 가짜 try-catch블록
			FindSpecialBlockParams synchronizedBlock = (FindSpecialBlockParams) controlBlock;
			if (synchronizedBlock.specialBlockType==FindSpecialBlockParams.SpecialBlockType_try) {
				name = new CodeString("try", Common_Settings.textColor);
			}
			else if (synchronizedBlock.specialBlockType==FindSpecialBlockParams.SpecialBlockType_catch) {
				name = new CodeString("catch", Common_Settings.textColor);
			}
			else if (synchronizedBlock.specialBlockType==FindSpecialBlockParams.SpecialBlockType_finally) {
				name = new CodeString("finally", Common_Settings.textColor);
			}
		}
		return name;
	}
	
	public static int Find(HighArray_CodeString src, String str, int startIndex, int endIndex)
    {
		try{
        int i;
        int resultIndex = -1;
        for (i = startIndex; i <= endIndex; i++)
        {
        	CodeString cstr = src.getItem(i);
        	if (CompilerHelper.IsComment(cstr)) continue;
            if (cstr.equals(str))
            {
                resultIndex = i;
                break;
            }
        }
        return resultIndex;
		}catch(Exception e) {
			return -1;
		}
    }
	
	/**funcCall에서 startIndex부터 검색을 시작하여 c를 찾아 c의 인덱스를 리턴한다. 
	 * @param startIndex : funcCall에서 c의 검색을 시작하는 인덱스*/
	public static int indexOf(HighArray_CodeString src, FindFuncCallParam funcCall, int startIndex, String c) {
		int i;
		for (i=startIndex; i<=funcCall.endIndex(); i++) {
			CodeString str = src.getItem(i);
			if (CompilerHelper.IsComment(str)) continue;
			if (str.equals(c)) {
				return i;
			}
		}
		return -1;
	}
	
	/**src에서 startIndex부터 검색을 시작하여 c를 찾아 c의 인덱스를 리턴한다. 
	 * @param startIndex : src에서 c의 검색을 시작하는 인덱스*/
	public static int indexOfBeforeSemicolon(HighArray_CodeString src, int startIndex, String c) {
		int i;
		for (i=startIndex; i<src.count; i++) {
			try {
			CodeString str = src.getItem(i);
			if (CompilerHelper.IsComment(str)) continue;
			if (str.equals(";")) {
				return -1;
			}
			else if (str.equals(c)) {
				return i;
			}
			}catch(Exception e) {
				if (Common_Settings.g_printsLog) e.printStackTrace();
			}
		}
		return -1;
	}
	
	/** path에 있는 '/', '\\'을 separatorChar로 바꾼다.*/
	public static ArrayListChar replaceFileSeparator(ArrayListChar path, char separatorChar) {
		int i;
		for (i=0; i<path.count; i++) {
			char c = path.getItem(i);
			if (c=='/' || c=='\\') {
				path.list[i] = separatorChar;
			}
		}
		return path;
	}
	
	
	/** blank나 comment(comment는 찾지 않음)를 skip.
     *  reverse가 false이면 startIndex()부터 endIndex()까지 인덱스를 증가시키면서 검색, 못 찾으면 endIndex()+1
	 *  reverse가 true이면 endIndex()부터 startIndex()까지 인덱스를 감소시키면서 검색, 못 찾으면 startIndex()-1*/
	public static int SkipBlank(CodeString src, boolean reverse, int startIndex, int endIndex)
    {
        int i;
        int resultIndex = -1;
        if (!reverse)
        {
            for (i = startIndex; i <= endIndex; i++)
            {
            	CodeChar c = src.charAt(i);
            	if (CompilerHelper.IsComment(c)) continue;
                if (CompilerHelper.IsBlank(c.c)) continue;
                break;
            }
            resultIndex = i;
        }
        else
        {
            for (i = endIndex; i >= startIndex; i--)
            {
            	CodeChar c = src.charAt(i);
            	if (CompilerHelper.IsComment(c)) continue;
                if (CompilerHelper.IsBlank(c.c)) continue;
                break;
            }
           
            resultIndex = i;
        }
        return resultIndex;
    }
	
	/** blank나 comment(comment는 찾지 않음)를 skip.
     *  reverse가 false이면 startIndex()부터 endIndex()까지 인덱스를 증가시키면서 검색, 못 찾으면 endIndex()+1
	 *  reverse가 true이면 endIndex()부터 startIndex()까지 인덱스를 감소시키면서 검색, 못 찾으면 startIndex()-1*/
	public static int SkipBlank(HighArray_CodeChar src, boolean reverse, int startIndex, int endIndex)
    {
        int i;
        int resultIndex = -1;
        if (!reverse)
        {
            for (i = startIndex; i <= endIndex; i++)
            {
            	CodeChar c = src.charAt(i);
            	if (CompilerHelper.IsComment(c)) continue;
                if (CompilerHelper.IsBlank(c.c)) continue;
                break;
            }
            resultIndex = i;
        }
        else
        {
            for (i = endIndex; i >= startIndex; i--)
            {
            	CodeChar c = src.charAt(i);
            	if (CompilerHelper.IsComment(c)) continue;
                if (CompilerHelper.IsBlank(c.c)) continue;
                break;
            }
           
            resultIndex = i;
        }
        return resultIndex;
    }
	
	
	/** reverse가 false이면 startIndex()부터 endIndex()까지 인덱스를 증가시키면서 검색, 못 찾으면 endIndex()+1
	 *  reverse가 true이면 endIndex()부터 startIndex()까지 인덱스를 감소시키면서 검색, 못 찾으면 startIndex()-1
	 *  @param stringStopped : 발견해서 멈추게 한 문자열*/
	int Skip(HighArray_CodeString src, boolean reverse, ArrayListCodeString listOfStopStrings, 
			int startIndex, int endIndex, CodeString stringStopped)
    {
        int i;
        int resultIndex = -1;
        if (!reverse)
        {
            for (i = startIndex; i <= endIndex; i++)
            {
            	CodeString cstr = src.getItem(i);
            	if (CompilerHelper.IsComment(cstr)) continue;
                if (Contains(cstr, listOfStopStrings))  {
                	stringStopped.str = cstr.str; 
                	break;
                }
            }
            resultIndex = i;
        }
        else
        {
            for (i = endIndex; i >= startIndex; i--)
            {
            	CodeString cstr = src.getItem(i);
            	if (CompilerHelper.IsComment(cstr)) continue;
                if (Contains(cstr, listOfStopStrings)) {
                	stringStopped.str = cstr.str;
                	break;
                }
            }
            resultIndex = i;
        }
        return resultIndex;
    }
	
	 /** blank만을 skip, 즉 \n, \b, \r등만을 스킵하고 주석은 스킵하지 않는다.
     * reverse가 false이면 startIndex()부터 endIndex()까지 인덱스를 증가시키면서 검색, 못 찾으면 endIndex()+1
	 *  reverse가 true이면 endIndex()부터 startIndex()까지 인덱스를 감소시키면서 검색, 못 찾으면 startIndex()-1*/
	static int SkipOnlyBlank(HighArray_CodeString src, boolean reverse, int startIndex, int endIndex)
    {
        int i;
        int resultIndex = -1;
        if (!reverse)
        {
            for (i = startIndex; i <= endIndex; i++)
            {
            	CodeString cstr = src.getItem(i);
                if (CompilerHelper.IsBlank(cstr)) continue;
                else break;
            }
            resultIndex = i;
        }
        else
        {
            for (i = endIndex; i >= startIndex; i--)
            {
            	CodeString cstr = src.getItem(i);
                if (CompilerHelper.IsBlank(cstr)) continue;
                else break;
            }
            resultIndex = i;
        }
        return resultIndex;
    }

	
	
	
	/** Expression를 skip.
     *  reverse가 false이면 startIndex()부터 endIndex()까지 인덱스를 증가시키면서 검색, 못 찾으면 endIndex()+1
	 *  reverse가 true이면 endIndex()부터 startIndex()까지 인덱스를 감소시키면서 검색, 못 찾으면 startIndex()-1*/
	static int SkipExpression(Compiler compiler, boolean reverse, int startIndex, int endIndex)
    {
		HighArray_CodeString src = compiler.data.mBuffer;
        int i;
        int resultIndex = -1;
        if (!reverse)
        {
            for (i = startIndex; i <= endIndex; i++)
            {
            	CodeString cstr = src.getItem(i);
            	if (CompilerHelper.IsComment(cstr)) continue;
            	else if (CompilerHelper.IsBlank(cstr)) continue;
            	else if (IsIdentifier(cstr, compiler)) continue;
            	else if (CompilerHelper.IsConstant(cstr)) continue;
            	else if (CompilerHelper.IsOperator(cstr)) continue;
            	else if (cstr.equals("(")) {
                	int rightPair;
                	rightPair = Checker.CheckParenthesis(compiler,  "(", ")", i, endIndex, false);
                	if (rightPair==-1) i = endIndex;
                	else i = rightPair;
                	continue;
                }
            	else if (cstr.equals(".")) {
            		continue;
            	}
            	else if (cstr.equals("?") || cstr.equals(":")) {
            		continue;
            	}
            	else if (CompilerHelper.IsSeparator(cstr)) {
                	break;
                }
            	else {
            		continue;
            	}
            }
            resultIndex = i;
        }
        else
        {
            for (i = endIndex; i >= startIndex; i--)
            {
            	CodeString cstr = src.getItem(i);
            	if (CompilerHelper.IsComment(cstr)) continue;
            	else if (CompilerHelper.IsBlank(cstr)) continue;
            	else if (IsIdentifier(cstr, compiler)) continue;
            	else if (CompilerHelper.IsConstant(cstr)) continue;
            	else if (CompilerHelper.IsOperator(cstr)) continue;
            	else if (cstr.equals(")")) {
                	int leftPair;
                	leftPair = Checker.CheckParenthesis(compiler,  "(", ")", startIndex, i, true);
                	if (leftPair==-1) i = startIndex;
                	else i = leftPair;
                	continue;
                }
            	else if (cstr.equals(".")) {
            		continue;
            	}
            	else if (cstr.equals("?") || cstr.equals(":")) {
            		continue;
            	}
            	else if (CompilerHelper.IsSeparator(cstr)) {
                	break;
                }
            	else {
            		continue;
            	}
            }
            resultIndex = i;
        }
        return resultIndex;
    }
	
	
	/** blank와 애노테이션과 일반주석만을 skip, 
     * reverse가 false이면 startIndex()부터 endIndex()까지 인덱스를 증가시키면서 검색, 못 찾으면 endIndex()+1
	 *  reverse가 true이면 endIndex()부터 startIndex()까지 인덱스를 감소시키면서 검색, 못 찾으면 startIndex()-1*/
	public static int SkipOnlyBlankAndAnnotationAndRegularComment(HighArray_CodeString src, boolean reverse, int startIndex, int endIndex)
    {
        int i;
        int resultIndex = -1;
        if (!reverse)
        {
            for (i = startIndex; i <= endIndex; i++)
            {
            	CodeString cstr = src.getItem(i);
                if (CompilerHelper.IsBlank(cstr)) continue;
                else if (CompilerHelper.IsAnnotation(cstr)) continue;
                else if (CompilerHelper.IsRegularComment(cstr)) continue;
                else break;
            }
            /*if (i <= endIndex+1) resultIndex = i;
            else resultIndex = endIndex();*/
            resultIndex = i;
        }
        else
        {
            for (i = endIndex; i >= startIndex; i--)
            {
            	CodeString cstr = src.getItem(i);
                if (CompilerHelper.IsBlank(cstr)) continue;
                else if (CompilerHelper.IsAnnotation(cstr)) continue;
                else if (CompilerHelper.IsRegularComment(cstr)) continue;
                else break;
            }
            /*if (i >= startIndex-1) resultIndex = i;
            else resultIndex = startIndex();*/
            resultIndex = i;
        }
        return resultIndex;
    }
    
	
	boolean Contains(CodeString target, ArrayListCodeString listOfStopStrings) {
		int i;
		for (i=0; i<listOfStopStrings.count; i++) {
			if (target.equals(listOfStopStrings.getItem(i))) {
				return true;
			}
		}		 
		return false;
	}
	
	/** 인용부호 "의 오른쪽 쌍의 인덱스를 찾는다.
	 * startIndex는 leftPair의 인덱스이다.*/
	public static int skipParenthesis(HighArrayCharForByteCode input, String leftPair, int startIndex, int endIndex) {
		if (leftPair.equals("\"")) {
			int i;
			for (i=startIndex+1; i<=endIndex; i++) {
				try {
				char c = input.getItem(i);
				if (c=='"' && input.getItem(i-1)!='\\') {
					// "\"abc\""
					return i;
				}
				if (c=='"' && input.getItem(i-1)=='\\' && input.getItem(i-2)=='\\') {
					// "\\"
					return i;
				}
				}catch(Exception e) {
					if (Common_Settings.g_printsLog) e.printStackTrace();
				}
			}
		}
		else if (leftPair.equals("\'")) {
			int i;
			for (i=startIndex+1; i<=endIndex; i++) {
				try {
				char c = input.getItem(i);
				if (c=='\'' && input.getItem(i-1)!='\\') {
					// '\''
					return i;
				}
				if (c=='\'' && input.getItem(i-1)=='\\' && input.getItem(i-2)=='\\') {
					// '\\'
					return i;
				}
				}catch(Exception e) {
					if (Common_Settings.g_printsLog) e.printStackTrace();
				}
			}
		}
		return -1;
	}
	
	/** reverse가 false이면 startIndex()부터 endIndex()까지 인덱스를 증가시키면서 검색, 못 찾으면 endIndex()+1
	 *  reverse가 true이면 endIndex()부터 startIndex()까지 인덱스를 감소시키면서 검색, 못 찾으면 startIndex()-1
	 *  주석이나 애노테이션은 skip한다.*/
	public static int Skip(HighArray_CodeString src, boolean reverse, String stopChar, int startIndex, int endIndex)
    {
        int i;
        int resultIndex = -1;
        if (!reverse)
        {
            for (i = startIndex; i <= endIndex; i++)
            {
            	CodeString cstr = src.getItem(i);
            	if (CompilerHelper.IsComment(cstr) || CompilerHelper.IsAnnotation(cstr)) continue;
                if (cstr.equals(stopChar)) break;
            }
            resultIndex = i;
        }
        else
        {
            for (i = endIndex; i >= startIndex; i--)
            {
            	CodeString cstr = src.getItem(i);
            	if (CompilerHelper.IsComment(cstr) || CompilerHelper.IsAnnotation(cstr)) continue;
                if (cstr.equals(stopChar)) break;
            }
            resultIndex = i;
        }
        return resultIndex;
    }
	
	/** reverse가 false이면 startIndex()부터 endIndex()까지 인덱스를 증가시키면서 검색, 못 찾으면 endIndex()+1
	 *  reverse가 true이면 endIndex()부터 startIndex()까지 인덱스를 감소시키면서 검색, 못 찾으면 startIndex()-1
	 *  주석이나 애노테이션은 skip한다.*/
	public static int Skip(HighArray_CodeString src, boolean reverse, String[] stopCharList, int startIndex, int endIndex)
    {
        int i, j;
        int resultIndex = -1;
        boolean found = false;
        if (!reverse)
        {
            for (i = startIndex; i <= endIndex; i++)
            {
            	CodeString cstr = src.getItem(i);
            	if (CompilerHelper.IsComment(cstr) || CompilerHelper.IsAnnotation(cstr)) continue;
            	for (j=0; j<stopCharList.length; j++) {
            		if (cstr.equals(stopCharList[j])) {
            			found = true;
            			break;
            		}
            	}
            	if (found) break;
            }
            resultIndex = i;
        }
        else
        {
            for (i = endIndex; i >= startIndex; i--)
            {
            	CodeString cstr = src.getItem(i);
            	if (CompilerHelper.IsComment(cstr) || CompilerHelper.IsAnnotation(cstr)) continue;
            	for (j=0; j<stopCharList.length; j++) {
            		if (cstr.equals(stopCharList[j])) {
            			found = true;
            			break;
            		}
            	}
            	if (found) break;
            }
            resultIndex = i;
        }
        return resultIndex;
    }
	
	 /** blank나 comment를 skip.
     *  reverse가 false이면 startIndex()부터 endIndex()까지 인덱스를 증가시키면서 검색, 
     *  blank나 comment가 아닌 인덱스를 리턴, 못 찾으면 endIndex()+1
	 *  reverse가 true이면 endIndex()부터 startIndex()까지 인덱스를 감소시키면서 검색, 
	 *  blank나 comment가 아닌 인덱스를 리턴, 못 찾으면 startIndex()-1*/
	public static int SkipBlank(HighArray_CodeString src, boolean reverse, int startIndex, int endIndex)
    {
        int i;
        int resultIndex = -1;
        if (!reverse)
        {
            for (i = startIndex; i <= endIndex; i++)
            {
            	CodeString cstr = src.getItem(i);
            	if (CompilerHelper.IsComment(cstr)) continue;
                if (CompilerHelper.IsBlank(cstr)) continue;
                break;
            }
            resultIndex = i;
        }
        else
        {
            for (i = endIndex; i >= startIndex; i--)
            {
            	try{
            	CodeString cstr = src.getItem(i);
            	if (CompilerHelper.IsComment(cstr)) continue;
                if (CompilerHelper.IsBlank(cstr)) continue;
                break;
            	}catch(Exception e) {
            	}
            }
            resultIndex = i;
        }
        return resultIndex;
    }
	
	
	
	
	
	public static CodeString findComment(CodeString input, int textColor) throws Exception
    {
        int i, j;
        char[] result = new char[input.length()];
        int[] resultColors = new int[input.length()];
        byte[] resultTypes = new byte[input.length()]; 
        int count = 0;
        
        for (i = 0; i < input.length(); )
        {
        	// "/*"
            if (input.charAt(i).c == '/' && 
            		(i + 1 < input.length() && input.charAt(i + 1).c == '*'))
            {	
            	int startOfComment = i;
            	int endOfComment = input.length()-1;
            	boolean isDocuComment = false;            	
            	                	
                for (j = i+2; j < input.length(); j++)
                {
                	if (input.charAt(j).c == '*' && 
                			(j + 1 < input.length() && input.charAt(j + 1).c == '/'))
                    {
                		endOfComment = j + 1;
                		break;
                    }
                }
                
                // "/**" 다큐먼트 주석,  /**/는 아님
                if (j<input.length() && i+2<input.length() && input.charAt(i+2).c=='*' && 
                		i+3<input.length() && input.charAt(i+3).c!='/') { 
                	isDocuComment = true;
                }
                
                int k;
                if (!isDocuComment) {
                    for (k=startOfComment; k<=endOfComment; k++) {
                    	result[count] = input.charAt(k).c;
                        resultColors[count] = Common_Settings.commentColor;
                        resultTypes[count++] = CodeStringType.Comment;
                    }
                }
                else {
                	for (k=startOfComment; k<=endOfComment; k++) {
                    	result[count] = input.charAt(k).c;
                        resultColors[count] = Common_Settings.docuCommentColor;
                        resultTypes[count++] = CodeStringType.DocuComment;
                    }
                }
                i = endOfComment + 1;
                
               
            }
        	// "//"
            else if (input.charAt(i).c == '/' && 
            		(i + 1 < input.length() && input.charAt(i + 1).c == '/'))
            {
            	for (j = i; j < input.length(); j++)
                {
                	result[count] = input.charAt(j).c;
                    resultColors[count] = Common_Settings.commentColor;
                    resultTypes[count++] = CodeStringType.Comment;
                    i = j+1;
                    
                    if (input.charAt(j).c == '\r' && 
                    		(j + 1 < input.length() && input.charAt(j + 1).c == '\n')) {
                    	// 마지막 '\n'넣기
                    	result[count] = input.charAt(j+1).c;
                        resultColors[count] = Common_Settings.commentColor;
                        resultTypes[count++] = CodeStringType.Comment;
                        i = j+2;
                        //listOfComments.add(new Point(startOfComment, endOfComment));
                    	break;
                    }
                    else if (input.charAt(j).c == '\n') { // 이미 넣었음
                    	//listOfComments.add(new Point(startOfComment, endOfComment));
                    	break;
                    }
                    
                }
            }
                        
            else	// 주석이 아닌 경우
            {
            	result[count] = input.charAt(i).c;
                resultColors[count] = textColor;
                resultTypes[count++] = CodeStringType.Text;
                i++;
            }
        }
        result = Array.Resize(result, count);
        resultColors = Array.Resize(resultColors, count);
        resultTypes = Array.Resize(resultTypes, count);
        return new CodeString(result, resultColors, resultTypes);
    }
	
	
	
	public static ArrayListCodeString findComment(ArrayListCodeString src, int textColor) throws Exception
    {
        int i, j;
        ArrayListCodeString r = new ArrayListCodeString(src.count); 
        for (i = 0; i < src.count; )
        {
        	// "/*"
            if (!CompilerHelper.IsConstant(src.getItem(i)) && src.getItem(i).equals("/") && 
            		(i + 1 < src.count && !CompilerHelper.IsConstant(src.getItem(i+1)) && src.getItem(i + 1).equals("*")))
            {	
            	int startOfComment = i;
            	int endOfComment = src.count-1;
            	boolean isDocuComment = false;            	
            	                	
                for (j = i+2; j < src.count; j++)
                {
                	if (!CompilerHelper.IsConstant(src.getItem(j)) && src.getItem(j).equals("*") && 
                			(j + 1 < src.count && !CompilerHelper.IsConstant(src.getItem(j+1)) && src.getItem(j + 1).equals("/")))
                    {
                		endOfComment = j + 1;
                		break;
                    }
                }
                
                // "/**" 다큐먼트 주석,  /**/는 아님
                if (j<src.count && i+2<src.count && !CompilerHelper.IsConstant(src.getItem(i+2)) && src.getItem(i+2).equals("*") && 
                		i+3<src.count && !CompilerHelper.IsConstant(src.getItem(i+3)) && !src.getItem(i+3).equals("/")) { 
                	isDocuComment = true;
                }
                
                int k;
                if (!isDocuComment) {
                    for (k=startOfComment; k<=endOfComment; k++) {
                    	CodeString str = src.getItem(k);
                    	str.setType(CodeStringType.Comment);
                    	str.setColor(Common_Settings.commentColor);
                    	r.add(str);
                    }
                }
                else {
                	for (k=startOfComment; k<=endOfComment; k++) {
                		CodeString str = src.getItem(k);
                    	str.setType(CodeStringType.DocuComment);
                    	str.setColor(Common_Settings.docuCommentColor);
                    	r.add(str);
                    }
                }
                i = endOfComment + 1;
                
               
            }
        	// "//"
            else if (!CompilerHelper.IsConstant(src.getItem(i)) && src.getItem(i).equals("/") && 
            		(i + 1 < src.count && !CompilerHelper.IsConstant(src.getItem(i+1)) && src.getItem(i + 1).equals("/")))
            {
            	for (j = i; j < src.count; j++)
                {
            		if (src.getItem(j).equals("파티션들중")) {
            		}
            		CodeString str = src.getItem(j);
                	str.setType(CodeStringType.Comment);
                	str.setColor(Common_Settings.commentColor);
                	r.add(str);
                    i = j+1;
                    
                    if (src.getItem(j).equals("\r") && 
                    		(j + 1 < src.count && src.getItem(j + 1).equals("\n"))) {
                    	// 마지막 '\n'넣기
                    	CodeString str2 = src.getItem(j+1);
                    	str2.setType(CodeStringType.Comment);
                    	str.setColor(Common_Settings.commentColor);
                    	r.add(str2);
                        i = j+2;
                        //listOfComments.add(new Point(startOfComment, endOfComment));
                    	break;
                    }
                    else if (src.getItem(j).equals("\n")) { // 이미 넣었음
                    	//listOfComments.add(new Point(startOfComment, endOfComment));
                    	break;
                    }
                    
                }
            }
                        
            else	// 주석이 아닌 경우
            {
            	if (CompilerHelper.IsConstant(src.getItem(i))) {
            		CodeString str = src.getItem(i);
                	str.setType(CodeStringType.Constant);
                	str.setColor(Common_Settings.keywordColor);
                	r.add(str);
	                i++;
            	}
            	else {
            		CodeString str = src.getItem(i);
                	str.setType(CodeStringType.Text);
                	str.setColor(Common_Settings.textColor);
                	r.add(str);
	                i++;
            	}
            }
        }
        return r;
    }
	
	/** 디렉토리에서 parentClassNameFull의 childClassNameShort라는 이름의 
	 * 내부(inner) 클래스가 존재하는지 확인한다.
	 * @param parentClassNameFull : java.lang.String, com.gsoft.common.gui.Control 과 같은 이름
	 * @param childClassNameShort : String, Control과 같은 짧은 이름
	 * @param usesCache : glistOfFilesInPackage에 저장된 파일리스트가 packageName에 있는 파일리스트와 동일한 것이라면
	 * usesCache이 true일때 새로 리스트를 얻는게 아니라 glistOfFilesInPackage이 캐시로서 사용되고 
	 * usesCache이 false이면 glistOfFilesInPackage을 새로 만든다.
	 * @param coreThreadID 
	 * */
	public static boolean hasInnerClass(Compiler compiler, String parentClassNameFull, String childClassNameShort, 
			boolean usesCache, int coreThreadID) {
		FindClassParams innerClass = Loader.loadClass(compiler, parentClassNameFull+"."+childClassNameShort, coreThreadID);
		if (innerClass!=null) return true;
		return false;
	}
	
	
	
	/**파일에 출력한다.*/
	public static void printStackTrace(File file, Exception e) {
		if (file==null) return;
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(file);
			BufferedOutputStream bos = new BufferedOutputStream(fos);
			CodeString stackTraceMessage = (new StackTracer(e)).getMessage();
			IO.writeString(bos, stackTraceMessage.str, TextFormat.UTF_8, false, true);
		} catch (FileNotFoundException e1) {
			
			e1.printStackTrace();
		} catch (Exception e2) {
			
		}
		finally {
			if (fos!=null)
				try {
					fos.close();
				} catch (IOException e1) {
					
					e1.printStackTrace();
				}
		}
	}
	/**LogBird에 출력한다.*/
	public static void printStackTrace(TextView tv, Throwable e) {
				
		if (tv==null) return;
		CodeString stackTraceMessage = (new StackTracer(e)).getMessage();
		
		int oldNumOfLines = tv.numOfLines-1;
		if (tv.textArray[oldNumOfLines]==null) {
			tv.textArray[oldNumOfLines] = new CodeString("", Common_Settings.textColor);
		}
		CodeString lastLine = tv.textArray[oldNumOfLines];
		CodeString updateLines = stackTraceMessage;
		updateLines = lastLine.concate(updateLines);
		
		tv.setTextMultiLine(oldNumOfLines, updateLines, 1);
		
		//tv.setText(tv.numOfLines, stackTraceMessage);
		tv.vScrollPosToLastPage();
		
	}
	
	/**LogBird에 출력한다.*/
	public static void printMessage(TextView tv, CodeString message) {
		if (tv==null) return;
		
		synchronized (tv) {
			
			int oldNumOfLines = tv.numOfLines-1;
			
			try {
				if (tv.textArray[oldNumOfLines]==null) {
					tv.textArray[oldNumOfLines] = new CodeString("", Common_Settings.textColor);
				}
				CodeString lastLine = tv.textArray[oldNumOfLines];
				CodeString updateLines = message;
				updateLines = lastLine.concate(updateLines);
				
				tv.setTextMultiLine(oldNumOfLines, updateLines, 1);
				
				tv.vScrollPosToLastPage();
				Control.view.invalidate();
			}catch (Exception e) {
				e.printStackTrace();
				
			}
		}
	}
	
	/**LogBird에 출력한다.*/
	public static void printMessage(TextView tv, String message) {
		if (tv==null) return;
		
		CodeString strMessage = new CodeString(message, Common_Settings.keywordColor);
		CompilerHelper.printMessage(tv, strMessage);
	}
	
	
	
	
	/** classParams 에 static 필드가 있으면 그것들을 초기화하기 위해 
	 * static 생성자가 존재하지 않으면
	 * static 생성자를 만든다.
	 * @param classParams
	 */
	public static void makeStaticDefaultConstructorIfStaticConstructorNotExist(Compiler compiler, FindClassParams classParams) {
		if (classParams.isEnum) return;
		
		if (!staticConstructorExists(compiler, classParams)) {
			makeStaticDefaultConstructor(compiler, classParams);
		}
	}

	
	/** 디폴트 인스턴스 생성자가 아니라 인스턴스 생성자가 없으면 디폴트 인스턴스 생성자를 만든다.*/
	public static void makeNoneStaticDefaultConstructorIfConstructorNotExist(Compiler compiler, FindClassParams classParams) {
		if (classParams.isEnum) return;
		if (!noneStaticConstructorExists(compiler, classParams)) {
			makeNoneStaticDefaultConstructor(compiler, classParams);
		}
	}
	
	/** classParams에 static 생성자가 아닌 인스턴스 생성자가 존재하는지를 확인한다.*/
	public static boolean noneStaticConstructorExists(Compiler compiler, FindClassParams classParams) {
		if (classParams.isEnum) return false;
		int i;
		String shortName = CompilerStatic.getShortName(classParams.name);
		for (i=0; i<classParams.listOfFunctionParams.count; i++) {
			FindFunctionParams func = (FindFunctionParams) classParams.listOfFunctionParams.getItem(i);
			//if (func.listOfFuncArgs.count!=0) continue;
			if (func.accessModifier!=null && func.accessModifier.isStatic) continue;
			if (func.name.equals(shortName)) return true;
		}
		return false;
	}
	
	
	
	/** classParams에 static 생성자가 존재하는지를 확인한다.*/
	public static boolean staticConstructorExists(Compiler compiler, FindClassParams classParams) {
		if (classParams.isEnum) return false;
		int i;
		String shortName = CompilerHelper.getShortName(classParams.name);
		for (i=0; i<classParams.listOfFunctionParams.count; i++) {
			FindFunctionParams func = (FindFunctionParams) classParams.listOfFunctionParams.getItem(i);
			//if (func.listOfFuncArgs.count!=0) continue;
			if (func.accessModifier!=null && !func.accessModifier.isStatic) continue;
			if (func.name.equals(shortName)) return true;
			//if (func.name.equals(staticConstructorName)) return true;
			if (func.isStaticBlock) return true; // static 생성자로 변환된다.
		}
		return false;
	}
	
	
	
	public static FindFunctionParams makeStaticDefaultConstructor(Compiler compiler, FindClassParams classParams) {
		FindFunctionParams func = new FindFunctionParams(classParams.compiler, CompilerHelper.getShortName(classParams.name));
		// func는 존재하지 않으므로 classNameIndex를 대신 넣는다.
		func.functionNameIndex = classParams.classNameIndex;
		func.accessModifier = new AccessModifier(classParams.compiler, -1, -1);
		func.accessModifier.accessPermission = AccessPermission.Public;
		func.accessModifier.isStatic = true;
		func.isConstructor = true;
		func.isConstructorThatInitializesStaticFields = true;		
		func.parent = classParams;
		//classParams.staticConstructorThatCompilerMakes = func;
		func.isFake = true;
		
		classParams.listOfFunctionParams.add(func);
		compiler.data.mlistOfAllFunctions.add(func);
		classParams.listOfConstructor.add(func);
		
		return func;
	}
	
	
	
	/** classParams에 디폴트 생성자를 만든다.*/
	public static FindFunctionParams makeNoneStaticDefaultConstructor(Compiler compiler, FindClassParams classParams) {
		//if (classParams.isEnum) return;
		
		FindFunctionParams func=null;
		String fullname = classParams.name;
		String name = CompilerStatic.getShortName(fullname);
		func = new FindFunctionParams(compiler, name);
		// func는 존재하지 않으므로 classNameIndex를 대신 넣는다.
		func.functionNameIndex = classParams.classNameIndex;
		func.returnType = fullname;
		func.parent = classParams;
		func.isConstructor = true;
		if (func.listOfFuncArgs==null) {
			func.listOfFuncArgs = new ArrayListIReset(0);
		}
		if (func.accessModifier==null){
			func.accessModifier = new AccessModifier(compiler, -1, -1);
		}
		func.accessModifier.accessPermission = AccessPermission.Public;
		func.isFake = true;
		classParams.listOfFunctionParams.add(func);
		compiler.data.mlistOfAllFunctions.add(func);
		classParams.listOfConstructor.add(func);
		return func;
	}
	
	
	
	/**classParams 에 static 필드가 있는지를 확인하여 static 생성자를 필요로하는지를 물어본다.*/
	public static boolean requiresStaticConstructor(FindClassParams classParams) {
		int i;
		for (i=0; i<classParams.listOfVariableParams.count; i++) {
			FindVarParams var = (FindVarParams) classParams.listOfVariableParams.getItem(i);
			if (var.accessModifier!=null && var.accessModifier.isStatic) return true;
		}
		return false;
	}
	
	
	
	/**public ColorDialog(View owner, Rectangle bounds) {<br>
		super(owner, bounds);<br>
	}<br>
	constructor에서 super() 또는 super(xxx) 호출이 있는지를 확인한다.
	*/
	public static boolean hasFuncCallToConstructorOfSuperClass(Compiler compiler, 
			FindFunctionParams constructor) {
		FindStatementParams statement = null;
		if (constructor.listOfStatements.count>0) {
			statement = (FindStatementParams) constructor.listOfStatements.getItem(0);
		}
		else {
			return false;
		}
		
		if (!statement.isFake) {
			int indexSuper = 
					CompilerHelper.SkipBlank(compiler.data.mBuffer, false, statement.startIndex(), compiler.data.mBuffer.count-1);
			if (!compiler.data.mBuffer.getItem(indexSuper).equals("super"))
				return false;
			FindVarUseParams varUseSuper =
					Compiler.getVarUseWithIndex(((FindClassParams)constructor.parent).listOfAllVarUsesForFuncHashed, 
							"super", indexSuper);
			try{
			if (varUseSuper!=null &&  
				varUseSuper.listOfFuncCallParams!=null && varUseSuper.listOfFuncCallParams.count>=0)
				return true;
			}catch(Exception e) {
				if (Common_Settings.g_printsLog) e.printStackTrace();
			}
		}
		else {
			// statement는 super();이다.
			if (statement instanceof FindIndependentFuncCallParams) {
				int indexSuper = 
						CompilerHelper.SkipBlank(compiler.data.mBuffer, false, statement.startIndex(), compiler.data.mBuffer.count-1);
				if (compiler.data.mBuffer.getItem(indexSuper).equals("super"))
					return true;
			}
		}
		return false;
	}
	
	/**public ColorDialog(View owner, Rectangle bounds) {<br>
		super(owner, bounds);<br>
	}<br>
	constructor에서 super() 또는 super(xxx) 호출이 있는지를 확인한다.
	@param tryBlock : constructor 내 최초의 가짜 try-block이어야 한다. 
	그렇지 않으면 Exception을 발생시킨다.
	*/
	public static boolean hasFuncCallToConstructorOfSuperClass(Compiler compiler, 
			FindControlBlockParams tryBlock) throws Exception {
		if (!(tryBlock.parent instanceof FindFunctionParams)) 
			throw new Exception("try block is not the child of constructor");
		if (tryBlock.parent instanceof FindFunctionParams) {
			FindFunctionParams func = (FindFunctionParams) tryBlock.parent;
			if (!func.isConstructor) {
				throw new Exception("try block is not the child of constructor");
			}
		}
		
		FindStatementParams statement = null;
		if (tryBlock.listOfStatements.count>0) {
			statement = (FindStatementParams) tryBlock.listOfStatements.getItem(0);
		}
		else {
			return false;
		}
		
		if (!statement.isFake) {
			int indexSuper = 
					CompilerHelper.SkipBlank(compiler.data.mBuffer, false, statement.startIndex(), compiler.data.mBuffer.count-1);
			if (!compiler.data.mBuffer.getItem(indexSuper).equals("super"))
				return false;
			//int indexInListOfVarUses = 
					//compiler.getIndexInmListOfAllVarUses2(constructor.listOfAllVarUsesForFunc, 0, indexSuper, true);
			
			FindFunctionParams parentFunc = (FindFunctionParams) tryBlock.parent;
			FindClassParams parentClass = (FindClassParams) parentFunc.parent;
			FindVarUseParams varUseSuper =
					Compiler.getVarUseWithIndex(parentClass.listOfAllVarUsesForFuncHashed, 
							"super", indexSuper);
			//FindVarUseParams varUseSuper = constructor.listOfAllVarUsesForFunc.getItem(indexInListOfVarUses);
			try{
			if (varUseSuper!=null && /*varUseSuper.name!=null && varUseSuper.name.equals("super") &&*/ 
				varUseSuper.listOfFuncCallParams!=null && varUseSuper.listOfFuncCallParams.count>=0)
				return true;
			}catch(Exception e) {
				if (Common_Settings.g_printsLog) e.printStackTrace();
			}
		}
		else {
			// statement는 super();이다.
			if (statement instanceof FindIndependentFuncCallParams)
				return true;
		}
		return false;
	}
	
	
	
	static int indexOf(String str, int startIndex, char c) {
		int i;
		for (i=startIndex; i<str.length(); i++) {
			if (str.charAt(i)==c) {
				return i;
			}
		}
		return -1;
	}
	
	/** str을 역방향으로 startIndex부터 시작하여 c를 찾아 그 인덱스를 리턴한다. str의 처음까지 검색해서 못 찾으면 -1을 리턴한다.*/
	static int indexOf(String str, int startIndex, char c, boolean reverse) {
		if (reverse) {
			int i;
			for (i=startIndex; i>=0; i--) {
				if (str.charAt(i)==c) {
					return i;
				}
			}
			return -1;
		}
		return -1;
	}
	
	
	
	
	/**@param fullClassName : java.lang.String과 같은 이름*/
	static String getPackageName(String fullClassName) {
		String pathPackage =  fullClassName.replace(".", File.separator);
		int indexSeparator=0;
		String path = pathPackage;
		String r = null;
		
		while (true) {
			indexSeparator = indexOf(pathPackage, indexSeparator+1, File.separatorChar);
			if (indexSeparator==-1) {
				break;
			}
			path = pathPackage.substring(0, indexSeparator);
			String fullPath = Common_Settings.pathAndroid + File.separator + path;
			File dirPackage = new File(fullPath);
			if (!dirPackage.exists()) {
				break;
			}
			else {
				r = path;
			}
		}
		if (r!=null) {
			r = r.replace(File.separator, ".");
		}
		return r;
	}
	
	/**System.getProperty("java.class.path") 호출로 만들어진 list에서 shortName을 가지는 
	 * 패스가 존재하는지를 확인한다.
	 * @param list
	 * @param shortName
	 * @return
	 */
	static boolean findPath(HighArray list, String shortName) {
		int i;
		for (i=0; i<list.count; i++) {
			if (list.getItem(i).equals(shortName)) {
				return true;
			}
		}
		return false;
	}
	/**C:\GSoft\TextEditorForJava\TextEditorForJava\janeSoft\gsoft 을 java.class.path에 없으면 등록한다.
	 * 여기에서 등록되는 클래스패스에서 Loader.fixFullName()의 Class.forName(fullname) 호출은 원하는 클래스를 찾을 수 있다.*/
	public static void setJavaClassPathAndJavaLibraryPathIfNotExists() {
		setJavaClassPathIfNotExists();
		setJavaLibraryPathIfNotExists();
	}
	
	/**Common_Settings.path_jni_lib*/
	private static void setJavaLibraryPathIfNotExists() {
		System.setProperty("java.library.path", Common_Settings.path_jni);
	}
	
	/**C:\GSoft\TextEditorForJava\TextEditorForJava\janeSoft\gsoft 을 java.class.path에 없으면 등록한다.
	 * 여기에서 등록되는 클래스패스에서 Loader.fixFullName()의 Class.forName(fullname) 호출은 원하는 클래스를 찾을 수 있다.*/
	static void setJavaClassPathIfNotExists() {
		String curPath = "/usr/lib/jvm/java-8-openjdk-i386/jre/lib";
		StringTokenizer tokenizer = new StringTokenizer();
		String[] separators = {"\\", "/", ":", ";"};
		HighArray list = tokenizer.ConvertToStringArray2(curPath, 100, separators);
		
		
		boolean exists = CompilerHelper.findPath(list, "gsoft");
		
		//if (!exists) {
			// C:\GSoft\TextEditorForJava\TextEditorForJava\janeSoft\gsoft 을 등록한다.
			
			String pathGSoft = null;
			pathGSoft = Common_Settings.pathAndroid;
			if (pathGSoft!=null) {
				curPath += File.pathSeparator + pathGSoft;
			}
		//}
		
		if (Common_Settings.projectName!=null) {
			curPath += File.pathSeparator + Common_Settings.pathOutput;
		}
		
		int i;
		for (i=0; i<Common_Settings.listOfOtherLibs.count; i++) {
			String filename = Common_Settings.listOfOtherLibs.getItem(i);
			String shortNameExceptExt = FileHelper.getFilename(filename);
			
			exists = CompilerHelper.findPath(list, shortNameExceptExt);
			if (!exists) {
				String pathOtherLib = filename;
				curPath += File.pathSeparator + pathOtherLib;
			}
		}
		
		System.setProperty("java.class.path", curPath);
		
		
	}
	
	/** 자주 사용하는 java 패키지의 클래스들을 모아 놓은 배열(Compiler_types.glistOfJavaClassesForThread)에
	 * 있는 클래스들을 스레드(ThreadReadingJavaClassesUsingWell)를 활용하여 loadClass()로 읽어 캐시에
	 * 등록하여 성능을 높인다.
	 * @param coreThreadID 
	 */
	public static void startThreadReadingJavaClassesUsingWell(int coreThreadID) {
		ThreadReadingJavaClassesUsingWell thread = new ThreadReadingJavaClassesUsingWell(coreThreadID);
		thread.start();
	}
	
	/** 자주 사용하는 java 패키지의 클래스들을 모아 놓은 배열(Compiler_types.glistOfJavaClassesForThread)에
	 * 있는 클래스들을 스레드(ThreadReadingJavaClassesUsingWell)를 활용하여 loadClass()로 읽어 캐시에
	 * 등록하여 성능을 높인다.
	 */
	public static class ThreadReadingJavaClassesUsingWell extends Thread {
		private int coreThreadID;
		ThreadReadingJavaClassesUsingWell(int coreThreadID) {
			this.coreThreadID = coreThreadID;
		}
		public void run() {
			int i;
			Compiler compiler = new Compiler();
			for (i=0; i<Compiler_types_Static.glistOfJavaClassesForThread.length; i++) {
				String fullName = Compiler_types_Static.glistOfJavaClassesForThread[i];
				Loader.loadClass(compiler, fullName, coreThreadID);
			}
		}
	}
	
	
	/** 변수나 메서드를 이미 상속하였으면 true, 그게 아니면 false를 리턴한다.
	 * findMembersInherited() 에서 상속을 하다보면 중복해서 상속을 할 경우도 있으므로
	 * (특히 java.lang.Object의 경우) 그것을 피하기 위해 호출한다.
	 * */
	public static 
	boolean hasInherittedMember(FindClassParams classParams, FindVarParams var, FindFunctionParams func) {
		if (var!=null) {
			boolean r = classParams.hasVarInheritted(var);
			return r;
		}
		if (func!=null) {
			boolean r = classParams.hasFuncInheritted(func);
			return r;
		}
		return false;
	}
	
	
	
	
	public static boolean exists(Hashtable2_String listOfClassesHashed, String fullClassName) {
		FindClassParams item = (FindClassParams) listOfClassesHashed.getData(fullClassName, false);
		if (item!=null) return true;
		return false;
	}
	
	
	
	
	/** fullName에 템플릿에 배열기호가 포함될경우 
	 * shortName은 템플릿, 배열기호를 포함한 마지막 '.', '/', '\\', '$' 이후 이름을 리턴한다.
	 * '.', '/', '\\', '$'  이 없으면 원래 fullName을 리턴한다.
	 * @param fullName
	 * @return
	 */
	public static String getShortName(String fullName) {
		if (fullName==null) return null;
		fullName = TemplateBase.getTemplateOriginalType(fullName);
		int i;
		for (i=fullName.length()-1; i>=0; i--) {
			if (fullName.charAt(i)=='.') break;
			else if (fullName.charAt(i)=='/') break;
			else if (fullName.charAt(i)=='\\') break;
			else if (fullName.charAt(i)=='$') break;
		}
		return fullName.substring(i+1, fullName.length());
	}
	
	/** "float", "int", "char", "short", "long", "void",  
        "byte", "double", "boolean"*/
    public static boolean IsDefaultType(String c) {
    	if (c==null) return false;
    	int i;
    	if (Compiler_types_Static.TypesOfJava==null) return false;
    	for (i=0; i<Compiler_types_Static.TypesOfJava.length; i++) {
    		if (c.equals(Compiler_types_Static.TypesOfJava[i])) return true;
    	}
    	return false;
    }
	
	/** 주석, 다큐주석, 애노테이션인지를 확인한다.*/
	public static boolean IsComment(CodeChar c) {
		if (c.type==CodeStringType.Comment ||
				c.type==CodeStringType.DocuComment ||
				c.type==CodeStringType.Annotation) return true;
		return false;
	}
	
	/** 주석, 다큐주석, 애노테이션이면 true, 그렇지않으면 false*/
	public static boolean IsComment(CodeString str) {
		try {
			CodeChar c = str.charAt(0); 
			if (c.type==CodeStringType.Comment ||
					c.type==CodeStringType.DocuComment ||
					c.type==CodeStringType.Annotation) return true;
			return false;
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
		}
		return false;
	}
	
	/** 다큐주석*/
	public static boolean IsRegularComment(CodeString str) {
		CodeChar c = str.charAt(0); 
		if (c.type==CodeStringType.Comment) return true;
		return false;
	}
	
	/** 다큐주석*/
	public static boolean IsDocuComment(CodeString str) {
		CodeChar c = str.charAt(0); 
		if (c.type==CodeStringType.DocuComment) return true;
		return false;
	}
	
	/** 애노테이션인지를 확인한다.*/
	public static boolean IsAnnotation(CodeString str) {
		CodeChar c = str.charAt(0); 
		if (c.type==CodeStringType.Annotation) return true;
		return false;
	}
	
	/** 상수(인용문, 숫자, 불리안 등)인지를 확인한다. 여기서 인용문은 "abc", 'a'를 말한다. 
	 * 숫자는 정수, 부동소수점을 말한다. 또한 null을 포함한다.*/
	public static boolean IsConstant(CodeString str) {
		if (str.equals("null")) return true;
		if (str.equals("true") || str.equals("false")) return true;
		CodeChar c = str.charAt(0); 
		if (c.type==CodeStringType.Constant) return true;
	
		if (str.equals("0xff")) {
		}
		int isNumber = Number.IsNumber2(str);
		if (isNumber!=0) {
			return true;
		}
		return false;
	}
	
	/** 상수(인용문, 숫자, 불리안 등)인지를 확인한다. 여기서 인용문은 "abc", 'a'를 말한다. 
	 * 숫자는 정수, 부동소수점을 말한다. 또한 null을 포함한다.*/
	public static boolean IsConstant(String str) {
		if (str.equals("null")) return true;
		if (str.equals("true") || str.equals("false")) return true;
		//CodeChar c = str.charAt(0); 
		//if (c.type==CodeStringType.Constant) return true;
		
		if (str.charAt(0)=='"') return true; // 문자열
		if (str.charAt(0)=='\'') return true; // 문자상수, 문자하나
	
		if (str.equals("0xff")) {
		}
		int isNumber = Number.IsNumber2(str);
		if (isNumber!=0) {
			return true;
		}
		return false;
	}
	
	
	
	/**"float", "int", "char", "short", "long", "void",  
        "byte", "double", "boolean"*/
	public static boolean IsDefaultType(CodeString c, Compiler compiler) {
    	int i;
    	if (compiler.data.Types==null) return false;
    	ArrayListString types = compiler.data.Types; 
    	for (i=0; i<types.count; i++) {
    		if (c.equals(types.getItem(i))) return true;
    	}
    	return false;
    }
    
    /** "float", "int", "char", "short", "long", "void",  
        "byte", "double", "boolean"*/
    public static boolean IsDefaultType(String c, Compiler compiler) {
    	int i;
    	if (compiler.data.Types==null) return false;
    	ArrayListString types = compiler.data.Types; 
    	for (i=0; i<types.count; i++) {
    		if (c.equals(types.getItem(i))) return true;
    	}
    	return false;
    }

	
	
	/** if id, number, return true*/
	public static boolean IsIdentifier(CodeString c, Compiler compiler) {
		
    	if (c.equals("this")) return true;
    	if (c.equals("super")) return true;
    	if (CompilerHelper.IsSeparator(c)) return false;
    	if (IsKeyword(c, compiler)) return false;
    	if (IsDefaultType(c, compiler)) return false;
        	
    	
    	/*char ch = c.toString().charAt(0);
    	if (('0'<=ch && ch<='9') || (ch=='-' || ch=='+')) return false;*/
    	return true;
    }
	
	public static boolean IsKeyword(CodeString c, Compiler compiler) {
		try{
    	int i;
    	ArrayListString keywords = compiler.data.Keywords; 
    	for (i=0; i<keywords.count; i++) {
    		if (c.equals(keywords.getItem(i))) return true;
    	}
    	return false;
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
			return false;
		}
    }

	
	public static boolean IsBlank(char c)
    {
        if (c == ' ' || c == '\t' || c == '\r' || c == '\n') return true;
        return false;
    }

	/** " ", "\t", "\r", "\n" */
    public static boolean IsBlank(CodeString c)
    {
        if (c.equals(" ") || c.equals("\t") || c.equals("\r") || c.equals("\n")) return true;
        return false;
    }
    
    /** 공백을 포함한 구분자*/
    public static boolean IsSeparator(char c)
    {    	
        if (c == '[' || c == ']' || c == '{' || c == '}' || c == '(' || c == ')' ||
            c == '=' || c == ';' || c == ':' || c == ',' || c == '.' || c == '@' ||
            c == '\\' || c == '#')
            return true;
        if (IsOperator(c)) return true;
        if (CompilerHelper.IsBlank(c)) return true;
        return false;
    }

    /** 공백을 포함한 구분자*/
    public static boolean IsSeparator(CodeString c)
    {
    	//if (IsSeparator(c.charAt(0).c)) return true;
    	if (c==null) return false;
        if (c.equals("[") || c.equals("]") || c.equals("{") || c.equals("}") || c.equals("(") || c.equals(")") ||
           c.equals("=") || c.equals(";") || c.equals(":") || c.equals(",") || c.equals(".") || c.equals("@") ||
           c.equals("\\") || c.equals("#"))
            return true;
        if (IsOperator(c)) return true;
        if (CompilerHelper.IsBlank(c)) return true;
        return false;
    }
    
    public static boolean isInteger(String typeName) {
    	if (typeName.equals("boolean") || typeName.equals("byte") || typeName.equals("char") ||
				typeName.equals("short") || typeName.equals("int"))
    		return true;
    	return false;
    }
    
    /** c == '+' || c == '-' || c == '*' || c == '/' || c == '<' || c == '>' || c == '~' ||
        c == '|' || c == '&' || c == '!' || c == '%' || c == '=' || c == '^'
            참고로 '='는 주의한다. "=="*/
    public static boolean IsOperator(char c)
    {
        if (c == '+' || c == '-' || c == '*' || c == '/' || c == '<' || c == '>' || c == '~' ||
            c == '|' || c == '&' || c == '!' || c == '%' || c == '=' || c == '^' || 
            c == '?' || c == ':') return true;
        return false;
    }
    
    /** 길이가 오직 1만 허용되는 연산자들, c.equals("~") || c.equals("!") || c.equals("^") || 
	        c.equals("?") || c.equals(":") || c.equals("instanceof")*/
    public static boolean IsOperatorLen1(CodeString c) {
    	if (c.equals("~") || c.equals("!") || c.equals("^") || 
	        c.equals("?") || c.equals(":") || c.equals("instanceof")) return true;
    	return false;
    }
    
    public static boolean IsCompositiveOperator(CodeString op1, CodeString op2, CodeString op3) {
    	if (op1.equals("<") || op2.equals("<") || op3.equals("<")) {
    		return true;
    	}
    	if (op1.equals(">") || op2.equals(">") || op3.equals(">")) {
    		return true;
    	}
    	return false;
    }
    
    public static boolean IsCompositiveOperator(CodeString op1, CodeString op2) {
    	if (op2.equals("=")) {
    		// 사칙연산
    		if (op1.equals("+") || op1.equals("-") || op1.equals("*") || op1.equals("/") ||
    			op1.equals("%") || 
    			op1.equals("|") || op1.equals("&") || op1.equals("^") || op1.equals("~")) {
        		return true;
        	}
    		// 관계연산
    		if (op1.equals("!") || op1.equals("=") || op1.equals("<") || op1.equals(">"))
    			return true;
    		return false;
    	}
    	if (op1.equals("<")) {
    		// shift연산
    		if (op2.equals("<")) return true;
    		// 관계연산
    		if (op2.equals("=")) return true;
    		return false;
    	}
    	else if (op1.equals(">")) {
    		// shift연산
    		if (op2.equals(">")) return true;
    		// 관계연산
    		if (op2.equals("=")) return true;
    		return false;
    	}
    	else if (op1.equals("&")) {
    		// 논리연산
    		if (op2.equals("&")) return true;
    		return false;
    	}
    	else if (op1.equals("|")) {
    		// 논리연산
    		if (op2.equals("|")) return true;
    		return false;
    	}
    	return false;
    }
    
    
    /** &&, ||, !*/
    public static boolean IsLogicalOperator(String str) {
    	if (str.equals("&&") || str.equals("||") || str.equals("!"))
    		return true;
    	return false;
    }
    
    /** ">", "<", "==", "!=", ">=", "<="*/
    public static boolean IsRelationOperator(String str) {
    	if (str.equals(">") || str.equals("<") || str.equals("==") || str.equals("!=") ||
    			str.equals(">=") || str.equals("<="))
    		return true;
    	return false;
    }

    /** c.equals("+") || c.equals("-") || c.equals("*") || c.equals("/") || c.equals("<") || c.equals(">") || c.equals("~") ||
        c.equals("|") || c.equals("&") || c.equals("!") || c.equals("%") || c.equals("=") || c.equals("^")
            참고로 '='는 주의한다. "=="*/
    public static boolean IsOperator(CodeString c)
    {
    	if (c==null) return false;    	
    	return IsOperator(c.str);
    }
    
    /** c.equals("+") || c.equals("-") || c.equals("*") || c.equals("/") || c.equals("<") || c.equals(">") || c.equals("~") ||
    c.equals("|") || c.equals("&") || c.equals("!") || c.equals("%") || c.equals("=") || c.equals("^")
        참고로 '='는 주의한다. "=="*/
	public static boolean IsOperator(String c)
	{
		int len = c.length();
		if (len==2) {
	    	if (IsOperator(c.charAt(0))) {
	    		if (IsOperator(c.charAt(1))) {
	    			return true; // "<=" 이런경우 "<"이 연산자이므로 true
	    		}
	    		else return false; //-1이면 연산자가 아니다.
	    	}
	    	else return false;
		}
		else if (len==3) {
	    	if (IsOperator(c.charAt(0))) {
	    		if (IsOperator(c.charAt(1))) {
	    			if (IsOperator(c.charAt(2))) {
	    				return true; // "<=" 이런경우 "<"이 연산자이므로 true
	    			}
	    			else return false;
	    		}
	    		else return false;
	    	}
	    	else return false;
		}
		else if (len==1) {
			if (IsOperator(c.charAt(0))) return true;
	        /*if (c.equals("+") || c.equals("-") || c.equals("*") || c.equals("/") || c.equals("<") || c.equals(">") || c.equals("~") ||
	            c.equals("|") || c.equals("&") || c.equals("!") || c.equals("%") || c.equals("=") || c.equals("^") || 
	            c.equals("?") || c.equals(":")) return true;*/
		}
		else {
			if (c.equals("instanceof")) return true;
			return false;
		}
		
	    return false;
	}
    
    /**c.equals("!") || c.equals("~")*/
    public static boolean IsOperatorForOne(CodeString c)
    {
        if (c.equals("!") || c.equals("~")) return true;
        return false;
    }
    
    /**c.equals("+") || c.equals("-") || c.equals("*") || c.equals("/") || 
            c.equals("|") || c.equals("&") || c.equals("%")  || c.equals("^") 
            뒤에 "="이 붙는다. 참고로 <는 "<<="을 말하고 >는 ">>="을 말하고 ^는 "^="(거듭제곱)을 말한다.
            IsLValue()를 참고한다.*/
    public static boolean IsAssignOperator(CodeString c)
    {
        if (c.equals("+") || c.equals("-") || c.equals("*") || c.equals("/") || 
            c.equals("|") || c.equals("&") || c.equals("%")  || c.equals("^")) return true;
        return false;
    }
    
    /** +=, -=, *=, /=, |=, &=, %=, ^=, <<=, >>= 을 말한다.
     * "+="는 op1이 +이고, op2는 =이 된다. op3는 null일 수 있다.*/
    public static boolean IsAssignOperator(CodeString op1, CodeString op2, CodeString op3) {
    	if (IsAssignOperator(op1) && op2.equals("=")) {
    		return true;
    	}
    	if (op1.equals("<") && op2.equals("<") && op3.equals("="))
    		return true;
    	if (op1.equals(">") && op2.equals(">") && op3.equals("="))
    		return true;
    	return false;
    }
    
    
    


	/**value의 크기와 범위에 따라 그 타입을 리턴한다.*/
	public static String getType(long value) {
		if (Byte.MIN_VALUE<=value && value<=Byte.MAX_VALUE) return "byte";
		else if (Short.MIN_VALUE<=value && value<=Short.MAX_VALUE) return "short";
		else if (Integer.MIN_VALUE<=value && value<=Integer.MAX_VALUE) return "int";
		else if (Long.MIN_VALUE<=value && value<=Long.MAX_VALUE) return "long";
		
		return "long";
	}





	/** fullname을 가진 클래스내에 String toString()함수가 존재하는지 확인한다.
	 * @param coreThreadID */
	public static boolean toStringFuncExists(Compiler compiler, String fullname, int coreThreadID) {
		if (fullname==null || fullname.equals("")) return false;
		FindClassParams c = Loader.loadClass(compiler, fullname, coreThreadID);
		if (c==null) return false;
		int i;
		for (i=0; i<c.listOfFunctionParams.count; i++) {
			FindFunctionParams func = (FindFunctionParams) c.listOfFunctionParams.getItem(i);
			if (func.name.equals("toString")) {
				if (func.returnType==null) continue;
				if (func.returnType.equals("java.lang.String")) return true;
			}
		}
		for (i=0; i<c.listOfFunctionParamsInherited.count; i++) {
			FindFunctionParams func = (FindFunctionParams) c.listOfFunctionParamsInherited.getItem(i);
			if (func.name.equals("toString")) {
				if (func.returnType==null) continue;
				if (func.returnType.equals("java.lang.String")) return true;
			}
		}
		return false;
	}


}