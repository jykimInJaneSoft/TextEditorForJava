package com.gsoft.common.compiler;

import java.io.File;

import android.graphics.Point;
import android.util.Log;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.CommonGUI;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.FileHelper;
import com.gsoft.common.compiler.Compiler_types.CategoryOfControls;
import com.gsoft.common.compiler.Compiler_types.FindAssignStatementParams;
import com.gsoft.common.compiler.Compiler_types.FindBlockParams;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.Compiler_types.FindControlBlockParams;
import com.gsoft.common.compiler.Compiler_types.FindFuncCallParam;
import com.gsoft.common.compiler.Compiler_types.FindFunctionParams;
import com.gsoft.common.compiler.Compiler_types.FindIndependentFuncCallParams;
import com.gsoft.common.compiler.Compiler_types.FindVarParams;
import com.gsoft.common.compiler.Compiler_types.FindVarUseParams;
import com.gsoft.common.compiler.Compiler_types.Language;
import com.gsoft.common.compiler.Compiler_types.LoadWayOfFindClassParams;
import com.gsoft.common.compiler.Compiler_types.ModeAllOrUpdate;
import com.gsoft.common.compiler.Compiler_types.TempLocalArrayInitializer;
import com.gsoft.common.compiler.Compiler_types_Base.AccessModifier;
import com.gsoft.common.compiler.Compiler_types_Base.AndSoOnStatement;
import com.gsoft.common.compiler.Compiler_types_Base.Block;
import com.gsoft.common.compiler.Compiler_types_Base.DocuComment;
import com.gsoft.common.compiler.Compiler_types_Base.Error;
import com.gsoft.common.compiler.Compiler_types_Base.FindPackageParams;
import com.gsoft.common.compiler.Compiler_types_Base.FindStatementParams;
import com.gsoft.common.compiler.Compiler_types_Base.ImportStatement;
import com.gsoft.common.compiler.Compiler_types_Base.OldTypeIndex;
import com.gsoft.common.compiler.Compiler_types_Base.PackageStatement;
import com.gsoft.common.compiler.Compiler_types_Base.ReturnOfFindVarDecl;
import com.gsoft.common.compiler.Compiler_types_Base.ReturnOfIsType;
import com.gsoft.common.compiler.Compiler_types_Special.FindArrayInitializerParams;
import com.gsoft.common.compiler.Compiler_types_Special.FindSmallBlockParams;
import com.gsoft.common.compiler.Compiler_types_Special.FindSpecialBlockParams;
import com.gsoft.common.compiler.Compiler_types_Special.FindSpecialStatementParams;
import com.gsoft.common.compiler.bytecode.ArrayInitializer;
import com.gsoft.common.compiler.bytecode.ByteCode_Types;
import com.gsoft.common.compiler.bytecode.Console;
import com.gsoft.common.compiler.bytecode.HighArrayCharForByteCode;
import com.gsoft.common.compiler.bytecode.LocalVar;
import com.gsoft.common.compiler.bytecode.Synchronized;
import com.gsoft.common.compiler.classloader.Loader;
import com.gsoft.common.compiler.util.Builder;
import com.gsoft.common.compiler.util.SynchronizedObjects;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListIReset;
import com.gsoft.common.util.ArrayListInt;
import com.gsoft.common.util.ArrayListString;
import com.gsoft.common.util.HighArray;
import com.gsoft.common.util.HighArray_CodeChar;
import com.gsoft.common.util.hash.Hashtable2_String;

import com.gsoft.common.compiler.CompilerData;
import com.gsoft.common.compiler.CompilerStack;
import com.gsoft.common.compiler.HighArray_CodeString;
import com.gsoft.common.compiler.CompilerStack;
import com.gsoft.common.compiler.CompilerStatic;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.Fullname;
import com.gsoft.common.compiler.Expression;
import com.gsoft.common.compiler.CodeStringEx;
import com.gsoft.common.compiler.Checker;
import com.gsoft.common.compiler.Member;
import com.gsoft.common.compiler.ClassCache;
import com.gsoft.common.compiler.TemplateBase;
import com.gsoft.common.compiler.Update;
import com.gsoft.common.compiler.TypeCast_Syntax;
import com.gsoft.common.compiler.StringTokenizer;
import com.gsoft.common.compiler.Array;
import com.gsoft.common.compiler.IndexForHighArray;
import com.gsoft.common.compiler.Number;



@SuppressWarnings("unused")
public class Compiler {
	
	
	static int StringArrayLimit = 200;



	public /*static*/ boolean PairErrorExists;
	
	
	
	HighArrayCharForByteCode mByteCodeResult = new HighArrayCharForByteCode(this, 1000);
	
	/** Compiler 문서 마다 하나씩 있다.*/
	public CompilerData data = new CompilerData();
	/** Compiler 문서 마다 하나씩 있다.*/
	public CompilerStack compilerStack = new CompilerStack(this);
	
	//public ByteCodeGenerator codeGen;

	
	
	
	public Compiler() {
		//String str = new java.lang.Character((char) 12610).toString();
		//System.out.println("c="+str);
		/*StringBuilder builder = new StringBuilder();
		builder = builder.append("abc");
		builder.append((char)123);
		System.out.println(builder.toString());*/
	}
		
	
	/** 모든 메모리 자원들을 해제한다.*/
	public void destroy() {
		/*if (this.update!=null) {
			this.update.destroy();
			this.update = null;
		}*/
		if (this.data!=null) {
			this.data.destroy();
			//this.data = null;
		}
		if (this.compilerStack!=null) {
			this.compilerStack.destroy();
			this.compilerStack = null;
		}
		
		if (this.mByteCodeResult!=null) {
			this.mByteCodeResult.destroy();
			this.mByteCodeResult = null;
		}
		/*if (this.codeGen!=null) {
			this.codeGen.destroy();
			this.codeGen = null;
		}*/
	}
	
    
	
	
	
	/** CheckParenthesis의 인덱스정보를 저장한 FindBlockParams[]에서 block의 endIndex를 찾는다.*/
	FindBlockParams findBlock(ArrayListIReset listOfBlocks, int startIndexOfBlock) {
		int i;
		for (i=0; i<listOfBlocks.count; i++) {
			FindBlockParams block = (FindBlockParams) listOfBlocks.getItem(i);
			if (block.startIndex()==startIndexOfBlock) {
				return block;
			}
		}
		return null;
	}
	
	
	
	
	/** CheckParenthesis의 인덱스정보를 저장한 FindSmallBlockParams[]에서 
	 * isReverse가 false 이면 small block의 endIndex를 찾는다. 없으면 -1을 리턴,
	 * isReverse가 true  이면 small block의 startIndex()를 찾는다. 없으면 -1을 리턴,*/
	int findEndIndexOfSmallBlock(ArrayListIReset listOfSmallBlocks, int startIndexOfSmallBlock, boolean isReverse) {
		int i;
		if (!isReverse) {
			for (i=0; i<listOfSmallBlocks.count; i++) {
				FindSmallBlockParams block = (FindSmallBlockParams) listOfSmallBlocks.getItem(i);
				if (block.startIndex()==startIndexOfSmallBlock) {
					return block.endIndex();
				}
			}
			return -1;
		}
		else {
			for (i=0; i<listOfSmallBlocks.count; i++) {
				FindSmallBlockParams block = (FindSmallBlockParams) listOfSmallBlocks.getItem(i);
				if (block.endIndex()==startIndexOfSmallBlock) {
					return block.startIndex();
				}
			}
			return -1;
		}
	}
	
	
    
 
    
    
   
	
	
	/** 클래스 하나에 있는 내부클래스들을 대상으로 하며, 클래스들이 트리구조이므로 recursive call한다.*/
	public void RegisterClasses(HighArray_CodeString src, FindClassParams findClassParams, 
			String classPath) {
		int i;
		if (findClassParams==null) return;
		
		classPath += src.getItem(findClassParams.classNameIndex()).toString();
		data.mlistOfImportedClasses.add(new String(classPath));
		
		if (findClassParams.childClasses!=null) {
			classPath += ".";
			for (i=0; i<findClassParams.childClasses.count; i++) {
				FindClassParams classParams = (FindClassParams) findClassParams.childClasses.getItem(i);
				RegisterClasses(src, classParams, classPath);
			}
		}		
	}
	
	
		
	
	/** Control.pathAndroid와 janeSoft/pathProjectSrc(janeSoft/output이 아니다)의 디렉토리구조를 
	 * FindPackageParams으로 만들어 mlistOfPackages에 등록한다.*/
	void loadLibraries2(Compiler compiler) {
		int i, k;
		// janeSoft/pathProjectSrc의 디렉토리구조를 따른다.
		
		int[] arrMode = {0, 2, 3};
		for (k=0; k<arrMode.length; k++) {
			// Control.pathAndroid와 janeSoft/pathProjectSrc에서 읽는다.
			ArrayList listOfFiles = CompilerStatic.getAbsPath_FromVariousClassPath(arrMode[k]);
			if (listOfFiles==null) continue;
			for (i=0; i<listOfFiles.count; i++) {
				File packageFile = (File) listOfFiles.getItem(i);
				if (packageFile.isDirectory()) {
					String packageName = FileHelper.getFilename(packageFile.getName());
					String parentFullName = "";
					//String[] listChildren = packageFile.list(); 
					FindPackageParams p = new FindPackageParams(compiler, packageName, parentFullName);
					data.mlistOfPackages.add(p);
				}
			}
		}
	}
	
	
	
	
	
	/** 조건문, 반복문 등 제어블록 조건 등의 소괄호 '(', ')'안에 할당문이 들어가 있는지를 확인한다.*/
	public boolean IsInParenthesisOfControlBlock(FindClassParams classParams, 
			FindAssignStatementParams assignStatement, FindVarUseParams varUse) 
	{	
		if (varUse.index()==7758) {
		}
		FindFunctionParams func = varUse.funcToDefineThisVarUse;
		if (func==null) return false;
		int i;
		if (func.startIndex()<assignStatement.startIndex() && 
				assignStatement.endIndex()<func.endIndex()) {
			ArrayListIReset listOfControlBlocks = func.listOfControlBlocks;
			if (listOfControlBlocks==null) return false;
			for (i=0; i<listOfControlBlocks.count; i++) {
				FindControlBlockParams controlBlock = (FindControlBlockParams)listOfControlBlocks.getItem(i);
				if (controlBlock.startIndex()<=assignStatement.startIndex() && 
						assignStatement.endIndex()<=controlBlock.endIndex()) {
					boolean r = this.IsInParenthesisOfControlBlock(controlBlock, assignStatement);
					if (r) return true;
				}
				if (controlBlock.indexOfLeftParenthesis()<=assignStatement.startIndex() && 
						assignStatement.endIndex()<=controlBlock.indexOfRightParenthesis())
					return true;
			}
		}
		return false;
		
	}
	
	/** 조건문, 반복문 등 제어블록 조건 등의 소괄호 '(', ')'안에 수식이 들어가 있는지를 확인한다.*/
	public boolean IsInParenthesisOfControlBlock(FindControlBlockParams controlBlock, FindAssignStatementParams assignStatement) 
	{
		if (controlBlock.listOfControlBlocks==null) return false;
		int i;
		for (i=0; i<controlBlock.listOfControlBlocks.count; i++) {
			FindControlBlockParams child = (FindControlBlockParams)controlBlock.listOfControlBlocks.getItem(i);
			if (child.startIndex()<=assignStatement.startIndex() && 
					assignStatement.endIndex()<=child.endIndex()) {
				// child 제어블록부터 호출
				boolean r = this.IsInParenthesisOfControlBlock(child, assignStatement);
				if (r) return true;
			}
			if (child.indexOfLeftParenthesis()<=assignStatement.startIndex() && 
					assignStatement.endIndex()<=child.indexOfRightParenthesis())
				return true;
		}
		return false;
		
	}
	
	
	
	
	
	
	
	
	/** 파일에서 정의한 함수들을 해당 클래스의 listOfStatements에 넣는다. 재귀적 호출
	 * @param FindClassParams classParams : 처음호출시는 최상위클래스, 재귀적호출시에는 해당클래스*/
	void inputClassesAndFunctionsToListOfStatementsOfSuitableClass_sub(HighArray_CodeString src, FindClassParams classParams, 
			FindFunctionParams statement) {
		int i;
		for (i=0; i<classParams.childClasses.count; i++) {
			FindClassParams c = (FindClassParams) classParams.childClasses.getItem(i);
			inputClassesAndFunctionsToListOfStatementsOfSuitableClass_sub(src, c, statement);
			if (statement.found) {
				return;
			}
		}
		
		if (classParams.startIndex()<statement.startIndex() && statement.endIndex()<classParams.endIndex()) {
			statement.found = true;
			classParams.listOfStatements.add(statement);
		}
	}
	
	/** 파일에서 정의한 클래스들을 해당 클래스의 listOfStatements에 넣는다. 재귀적 호출
	 * @param FindClassParams classParams : 처음호출시는 최상위클래스, 재귀적호출시에는 해당클래스*/
	void inputClassesAndFunctionsToListOfStatementsOfSuitableClass_sub(HighArray_CodeString src, FindClassParams classParams, 
			FindClassParams statement) {
		int i;
		for (i=0; i<classParams.childClasses.count; i++) {
			FindClassParams c = (FindClassParams) classParams.childClasses.getItem(i);
			inputClassesAndFunctionsToListOfStatementsOfSuitableClass_sub(src, c, statement);
			if (statement.found) {
				return;
			}
		}
		
		if (classParams.name.equals(statement.name)) return;
		else {
			if (classParams.startIndex()<statement.startIndex() && statement.endIndex()<classParams.endIndex()) {
				statement.found = true;
				classParams.listOfStatements.add(statement);
			}
		}
		
	}
	
	/** 클래스의 문장리스트를 만들때 클래스에 들어가지 못한 문장들을 파일상의 문장리스트(mlistOfFindStatementParams)에 넣는다.*/
	public void inputPackageAndImportAndSoOnToListOfStatementsOfFile(HighArray_CodeString src) {
		int i;
		for (i=0; i<data.mlistOfPackageStatements.count; i++) {
			FindStatementParams c = (FindStatementParams) data.mlistOfPackageStatements.getItem(i);
			data.mlistOfFindStatementParams.add(c);
		}
		for (i=0; i<data.mlistOfImportStatements.count; i++) {
			FindStatementParams c = (FindStatementParams) data.mlistOfImportStatements.getItem(i);
			data.mlistOfFindStatementParams.add(c);
		}
		for (i=0; i<data.mlistOfClass.count; i++) {
			FindStatementParams c = (FindStatementParams) data.mlistOfClass.getItem(i);
			data.mlistOfFindStatementParams.add(c);
		}
		for (i=0; i<data.mlistOfComments.count; i++) {
			FindStatementParams c = (FindStatementParams) data.mlistOfComments.getItem(i);
			if (!c.found) {
				data.mlistOfFindStatementParams.add(c);
			}
		}
		
		for (i=0; i<data.mlistOfAnnotations.count; i++) {
			FindStatementParams c = (FindStatementParams) data.mlistOfAnnotations.getItem(i);
			if (!c.found) {
				data.mlistOfFindStatementParams.add(c);
			}
		}
		
		ArrayListIReset result = new ArrayListIReset(data.mlistOfFindStatementParams.count);
		CompilerStatic.SortByIndex(data.mlistOfFindStatementParams, result);
		
		// 문장과 문장사이에서 나머지 문장들을 찾고 넣는다.
		data.mlistOfFindStatementParams = findAndSoOnStatements( 0, result, src.count-1);
	}
	
	
	/** 문장과 문장사이에서 나머지 문장들을 찾고 넣는다.
	 * @param input : startIndex()에 의해 미리 정렬되어 있어야 한다.
	 * @return : 이 함수의 처리 결과를 말한다.*/
	ArrayListIReset findAndSoOnStatements( int startIndex, ArrayListIReset input, int endIndex) {
		HighArray_CodeString src = this.data.mBuffer;
		if (input.count==0) {
			ArrayListIReset result = new ArrayListIReset(1);
			result.add(new AndSoOnStatement(this, startIndex, endIndex));
			return result;
		}
		int i;
		ArrayListIReset result = new ArrayListIReset(input.count*2);
		FindStatementParams s0 = (FindStatementParams) input.getItem(0);
		result.add(s0);
		if (0<s0.startIndex()) {
			result.add(new AndSoOnStatement(this, startIndex, s0.startIndex()-1)); 
		}
		for (i=0; i<input.count; i++) {
			FindStatementParams s = (FindStatementParams) input.getItem(i);
			if (s.endIndex()==1721) {
			}
			if (i>0) {				
				result.add(s);
			}
			if (i<input.count-1) { // 문장과 문장 사이
				FindStatementParams s1 = (FindStatementParams) input.getItem(i+1);
				if (s.endIndex()<s1.startIndex()) {
					result.add(new AndSoOnStatement(this, s.endIndex()+1, s1.startIndex()-1));
				}
			}
			else if (i==input.count-1) { // 마지막 문장과 src의 끝 사이
				if (s.endIndex()+1<=src.count-1) {
					result.add(new AndSoOnStatement(this, s.endIndex()+1, endIndex));
				}
			}
		}
		
		ArrayListIReset result2 = new ArrayListIReset(result.count);
		CompilerStatic.SortByIndex(result, result2);
		return result2;
	}
	
	/** 파일에서 정의한 주석과 Annotation들을 해당 클래스의 listOfStatements에 넣는다.
	 * 참고로 파일에서 정의한 클래스들과 함수들은 inputClassesAndFunctionsToListOfStatementsOfSuitableClass()에서, 
	 * 변수선언들은 FindAllClassesAndItsMembers2_sub()에서 넣는다.
	 * @param FindClassParams classParams : 최상위클래스*/
	/*public void inputCommentsAndAnnotationsToListOfStatementsOfSuitableClass(HighArray_CodeString src, FindClassParams classParams) {
		int i;
		for (i=0; i<mlistOfComments.count; i++) {
			Comment c = (Comment) mlistOfComments.getItem(i);
			c.found = false;
			this.inputStatementToSuitableBlock_caller(src, classParams, c);
		}
		
		for (i=0; i<mlistOfAnnotations.count; i++) {
			Annotation a = (Annotation) mlistOfAnnotations.getItem(i);
			a.found = false;
			this.inputStatementToSuitableBlock_caller(src, classParams, a);
		}
	}*/
	
	/** 파일에서 정의한 클래스들과 함수들을 해당 클래스의 listOfStatements에 넣는다.
	 * 참고로 주석은 inputCommentsToListOfStatementsOfSuitableClass()에서, 
	 * 변수선언들은 FindAllClassesAndItsMembers2_sub()에서 넣는다.
	 * @param FindClassParams classParams : 최상위클래스*/
	public void inputClassesAndFunctionsToListOfStatementsOfSuitableClass( FindClassParams classParams) {
		HighArray_CodeString src = this.data.mBuffer;
		int i;
		for (i=0; i<data.mlistOfAllDefinedClasses.count; i++) {
			FindClassParams c = (FindClassParams) data.mlistOfAllDefinedClasses.getItem(i);
			if (c.name.equals(classParams.name)) continue;
			c.found = false;
			inputClassesAndFunctionsToListOfStatementsOfSuitableClass_sub(src, classParams, c);
		}
		
		for (i=0; i<data.mlistOfAllFunctions.count; i++) {
			FindFunctionParams f = (FindFunctionParams) data.mlistOfAllFunctions.getItem(i);
			f.found = false;
			inputClassesAndFunctionsToListOfStatementsOfSuitableClass_sub(src, classParams, f);
		}
	}
	
	
	
	
	/** mlistOfAllArrayIntializers에서 lValue의 varUse로 해당 배열초기화문을 찾는다.*/
	FindArrayInitializerParams getFindArrayInitializerParams( FindVarUseParams varUse) {
		int i;
		for (i=0; i<data.mlistOfAllArrayIntializers.count; i++) {
			FindArrayInitializerParams arr = (FindArrayInitializerParams) data.mlistOfAllArrayIntializers.getItem(i);
			if (arr.nameIndex()==varUse.index()) return arr;
		}
		return null;
	}
	
	
	
	
	
	/** varUse들을 해당클래스의 listOfAllVarUsesForVar, listOfAllVarUsesForFunc해시테이블에 넣는다.
	 * @param endIndex 
	 * @param startIndex 
	 * @param allOrPart 
	 * @param endIndex 
	 * @param startIndex 
	 * @param allOrPart */
	public void InputVarUsesToHashtableOfClass(HighArray_CodeString src, FindClassParams classParams, 
			boolean allOrPart, int startIndex, int endIndex) {
		int i;
		int j;
		for (i=0; i<2; i++) {
			HighArray listOfAllVarUses = null;
			if (i==0) listOfAllVarUses = classParams.listOfAllVarUsesForVar;
			else listOfAllVarUses = classParams.listOfAllVarUsesForFunc;
			if (listOfAllVarUses==null) return;
			
			Hashtable2_String hashtable = null;
			int len = listOfAllVarUses.getCount();
			if (allOrPart) {
				hashtable = new Hashtable2_String(50, 20);
				for (j=0; j<len; j++) {
					FindVarUseParams varUse = (FindVarUseParams) listOfAllVarUses.getItem(j);
					if (src.getItem(varUse.index()).equals("super")) {
					}
					hashtable.input(varUse.originName, varUse);
				}
			}
			else {
				hashtable = new Hashtable2_String(25, 10);
				for (j=0; j<len; j++) {
					FindVarUseParams varUse = (FindVarUseParams) listOfAllVarUses.getItem(j);
					if (startIndex<=varUse.index() && varUse.index()<=endIndex) {
						hashtable.input(varUse.originName, varUse);
					}
				}
			}
			
			if (i==0) classParams.listOfAllVarUsesForVarHashed = hashtable;
			else classParams.listOfAllVarUsesForFuncHashed = hashtable;
		}
	}
	
	/** this, super와 varUse들을 해당클래스의 해시테이블에 넣는다.
	 * @param classParams : 처음 호출시는 최상위 클래스, 재귀적 호출시는 해당클래스
	 * @param endIndex 
	 * @param startIndex 
	 * @param allOrPart */
	public void inputThisAndSuperToClassAndInputVarUsesToHashtable(HighArray_CodeString src, 
			FindClassParams classParams, ModeAllOrUpdate modeAllOrUpdate, 
			boolean allOrPart, int startIndex, int endIndex) {
		int i;
		if (classParams==null) return;
		if (classParams.isEnum) return;
		if (classParams.isInterface) return;
		
		if (classParams.childClasses!=null) {
			if (allOrPart) {
				FindVarParams varThis = new FindVarParams(this, true, false, false, classParams);
				FindVarParams varSuper = new FindVarParams(this, false, false, true, classParams);
				AccessModifier accessModifierThis = new AccessModifier(this, -1, -1);
				AccessModifier accessModifierSuper = new AccessModifier(this, -1, -1);
				varThis.accessModifier = accessModifierThis;
				varSuper.accessModifier = accessModifierSuper;
				
				//classParams.listOfVariableParams.add(varThis); // this
				compilerStack.core.putVarToParent(varThis, classParams);
				//classParams.listOfVariableParams.add(varSuper); // super
				compilerStack.core.putVarToParent(varSuper, classParams);
				//this.mlistOfAllMemberVarDeclarations.add(varThis);
				compilerStack.core.putFindVarParams(varThis, false);
				//this.mlistOfAllMemberVarDeclarations.add(varSuper);
				compilerStack.core.putFindVarParams(varSuper, false);
			}
			InputVarUsesToHashtableOfClass(src, classParams, allOrPart, startIndex, endIndex);
			
			for (i=0; i<classParams.listOfFunctionParams.count; i++) {
				FindFunctionParams func = (FindFunctionParams) classParams.listOfFunctionParams.getItem(i);
				FindVarParams varThis2 = new FindVarParams(this, true, false, false, classParams);
				func.thisVar = varThis2;
				//func.thisVar = classParams.thisVar;
			}
			
			for (i=0; i<classParams.childClasses.count; i++) {
				FindClassParams child = (FindClassParams) classParams.childClasses.getItem(i);
				inputThisAndSuperToClassAndInputVarUsesToHashtable(src, child, modeAllOrUpdate, 
						allOrPart, startIndex, endIndex);
			}
		}
		else {
			if (allOrPart) {
				FindVarParams varThis = new FindVarParams(this, true, false, false, classParams);
				FindVarParams varSuper = new FindVarParams(this, false, false, true, classParams);
				//classParams.listOfVariableParams.add(varThis); // this
				compilerStack.core.putVarToParent(varThis, classParams);
				//classParams.listOfVariableParams.add(varSuper); // super
				compilerStack.core.putVarToParent(varSuper, classParams);
				//this.mlistOfAllMemberVarDeclarations.add(varThis);
				compilerStack.core.putFindVarParams(varThis, false);
				//this.mlistOfAllMemberVarDeclarations.add(varSuper);
				compilerStack.core.putFindVarParams(varSuper, false);
			}
			//Compiler.SortByName(src, classParams.listOfAllVarUsesForVar, classParams.listOfAllVarUsesForVarSortedByName);
			InputVarUsesToHashtableOfClass(src, classParams, allOrPart, startIndex, endIndex);
			
			for (i=0; i<classParams.listOfFunctionParams.count; i++) {
				FindFunctionParams func = (FindFunctionParams) classParams.listOfFunctionParams.getItem(i);
				FindVarParams varThis2 = new FindVarParams(this, true, false, false, classParams);
				func.thisVar = varThis2;
				//func.thisVar = classParams.thisVar;
			}
		}
		
	}
	
	boolean hasInHeritted(FindClassParams classParams, String className) {
		if (classParams.classNameToExtend.equals(className)) return true;
		if (classParams.classToExtend!=null) {
			// 상속관계에서 이미 상속을 했는지 확인한다.
			boolean r = hasInHeritted(classParams.classToExtend, className);
			return r;
		}
		return false;
	}
	
	
	
	
	/**어떤 자바파일을 로드한 상태에서 패키지이름이나 클래스이름이 바뀌면 filename을 바꿔야 한다.
	 * 기존 패키지이름이나 클래스 이름을 가진 자바 파일은 지워지고 새로운 패키지이름과 클래스이름을 갖는 자바 파일이 저장된다.
	 * @param className : 가장 바깥 클래스의 short name*/
	public boolean checkFilename(String packageName) {
		if (packageName!=null && !packageName.equals("")) {
			String slashedPackageName = packageName.replace('.', File.separatorChar);
			File packageDir = new File(Common_Settings.pathProjectSrc+File.separator+slashedPackageName);
			// 어떤 자바파일을 로드한 후에 패키지 이름을 바꾸고 구문분석을 다시 할 경우에
			String oldFilename = data.filename;
			
			if (!oldFilename.contains(Common_Settings.pathProjectSrc)) {
				data.isOutsideOfProject = true;
				return false;
			}
			
			String oldPackageName = oldFilename.substring(Common_Settings.pathProjectSrc.length()+1, oldFilename.length());
			
			StringTokenizer tokenizer = new StringTokenizer();
			String[] separators = {File.separator};
			HighArray result = tokenizer.ConvertToStringArray2(oldPackageName, 50, separators);
			
			int i;
			oldPackageName = "";
			// Test\A.java 에서 \와 A.java를 뺀다.
			for (i=0; i<result.count-2; i++) {
				oldPackageName += result.getItem(i);
			}
			oldPackageName = oldPackageName.replace(File.separatorChar, '.');
			// Test\A.java 에서 A가 된다.
			String oldClassName = FileHelper.getFilenameExceptExt((String)result.getItem(result.count-1));
			
			if (!oldPackageName.equals(packageName)) {
				// 패키지 이름이 파일이름과 다르면
				PackageStatement ps = (PackageStatement) data.mlistOfPackageStatements.getItem(0);
				CompilerStatic.errors.add(new Error(this, ps.startIndex(), ps.endIndex(), 
						"invalid package name : not equals with filename"));
				return false;
			}
			
			FindClassParams mainClass = null;
			for (int q=0; q<data.mlistOfClass.count; q++) {
				FindClassParams c = (FindClassParams) data.mlistOfClass.getItem(q);
				String className = CompilerHelper.getShortName(c.name);
				String newFilename = packageDir.getAbsolutePath()+File.separator+className+".java";
				
				ArrayList r = new ArrayList(1);
				CompilerStatic.findMainFunc(c, r);
				if (r.count>0) {
					// Finds the main class having main()
					mainClass = c;
					break;
				}
			}
			
			FindClassParams classParams = null;
			if (mainClass!=null) {
				String className = CompilerHelper.getShortName(mainClass.name);
				// className is of main class.
				// File name is the name of a class having a main()
				if (oldClassName.equals(className)) return true;
				classParams = mainClass;
			}
			else {
				for (int q=0; q<data.mlistOfClass.count; q++) {
					FindClassParams c = (FindClassParams) data.mlistOfClass.getItem(q);
					String className = CompilerHelper.getShortName(c.name);
					//String newFilename = packageDir.getAbsolutePath()+File.separator+className+".java";
				
					// main함수가 없을 경우 파일 내에 어떤 클래스도 파일이름과
				     // 같을 수 있으나 반드시 하나의 클래스는 파일이름과 같아야 한다.
					if (oldClassName.equals(className)) return true;
				}// for (int q=0; q<data.mlistOfClass.count; q++) {	
			}			
			
			
			int errorStartIndex, errorEndIndex;
			if (classParams!=null) {
				errorStartIndex = classParams.classNameIndex();
				errorEndIndex = classParams.classNameIndex();
			}
			else {
				errorStartIndex = 0;
				errorEndIndex = 0;
			}
			CompilerStatic.errors.add(new Error(this, errorStartIndex, errorEndIndex, 
					"invalid class name : not equals with filename"));
			
		}
		return false;
	}
	
	public FindStatementParams findStatement(Object node) {
		if (node instanceof FindClassParams) {
			return (FindStatementParams) node;
			
		}
		else if (node instanceof FindVarUseParams) {
			// varUse를 포함하는 최소의 문장을 찾는다.
			FindVarUseParams varUse = (FindVarUseParams) node;
			FindStatementParams statement = this.findFindStatementParams(varUse);
						
			return statement;
		}
		else if (node instanceof FindControlBlockParams) {
			return (FindStatementParams) node;
		}
		else if (node instanceof FindFunctionParams) {
			return (FindStatementParams) node;
		}
		return null;
	}
	
	
	/** varUse를 포함하는 함수 또는 클래스 내에서 varUse를 갖는 최소의 문장을 찾아 리턴한다.
	 * 클래스인 경우 멤버변수 초기화 문장을 찾는다.*/
	public FindStatementParams findFindStatementParams(FindVarUseParams varUse) {
		FindFunctionParams func = varUse.funcToDefineThisVarUse;
		FindClassParams classParams = varUse.classToDefineThisVarUse;
		int i;
		if (func!=null && (func.startIndex()<varUse.index() && varUse.index()<func.endIndex())) {
			for (i=0; i<func.listOfStatements.count; i++) {
				FindStatementParams statement = (FindStatementParams) func.listOfStatements.getItem(i);
				if (statement instanceof FindVarParams) continue;
				int startIndex = statement.startIndex();
				int endIndex = statement.endIndex();
				if (startIndex<=varUse.index() && varUse.index()<=endIndex) {
					if (statement instanceof FindControlBlockParams) {
						FindControlBlockParams controlBlock = (FindControlBlockParams) statement;
						// 제어구조의 괄호내에 있는 varUse를 클릭했을때
						if (controlBlock.indexOfLeftParenthesis()<=varUse.index() && varUse.index()<=controlBlock.indexOfRightParenthesis()) {							
							return controlBlock;
						}
						// 제어구조내에서 문장찾기
						FindStatementParams r = findFindStatementParams(varUse, controlBlock);
						return r;
					}
					else {
						return statement;
					}
				}
				
			}
		}//if (func!=null) {
		else { // 클래스에 있는 멤버변수 초기화문
			for (i=0; i<classParams.listOfStatements.count; i++) {
				FindStatementParams statement = (FindStatementParams) classParams.listOfStatements.getItem(i);
				if (statement instanceof FindVarParams) continue;
				int startIndex = statement.startIndex();
				int endIndex = statement.endIndex();
				if (startIndex<=varUse.index() && varUse.index()<=endIndex) {
					if (statement instanceof FindClassParams) {
						continue;
					}
					else if (statement instanceof FindFunctionParams) {
						continue;
					}
					else {
						// 대입문 또는 함수호출문등
						return statement;
					}
				}
				
			}
		}
		
		return null;
	}
	
	
	void FindAllClassesAndItsMembers2_sub_update(int startIndex, int endIndex, 
			ArrayListIReset result, 
			boolean allOrPart, FindFunctionParams functionForPart, int coreThreadID, boolean showsLogMessage) {
		try {
		ArrayListIReset mlistOfAllArrayIntializers = null;
		ArrayListIReset mlistOfAllAssignStatements = null;
		ArrayListIReset mlistOfAllControlBlocks = null;
		ArrayListIReset mlistOfAllDefinedClasses = null;
		ArrayListIReset mlistOfAllConstructor = null;
		ArrayListIReset mlistOfAllForLoops = null;
		ArrayListIReset mlistOfAllFunctions = null;
		HighArray mlistOfAllLocalVarDeclarations = null;
		HighArray mlistOfAllMemberVarDeclarations = null;
		ArrayListIReset mlistOfAllTemplates = null;
		ArrayListIReset mlistOfAllTypeCasts = null;
		HighArray mlistOfAllVarUses = null;
		Hashtable2_String mlistOfAllVarUsesHashed = null;
		ArrayListIReset mlistOfAnnotations = null;
		ArrayListIReset mlistOfBlocks = null;
		ArrayListIReset mlistOfFinally = null;
		ArrayListIReset mlistOfFindStatementParams = null;
		ArrayListIReset mlistOfSpecialStatement = null;
		ArrayListIReset mlistOfThreeOperandsOperation = null;
		ArrayListInt mlistOfNewLines = null;
		
		ArrayListIReset listOfConstructor = null;
		ArrayListIReset listOfControlBlocks = null;
		ArrayListIReset listOfSpecialBlocks = null;
		ArrayListIReset listOfFunctionParams = null;
		ArrayListIReset listOfStatements = null;
		ArrayListIReset listOfVariableParams = null;
		
		Hashtable2_String listOfAllVarUsesForVarHashed = null;
		Hashtable2_String listOfAllVarUsesForFuncHashed = null;
		HighArray listOfAllVarUses = null;
		HighArray listOfAllVarUsesForVar = null;
		HighArray listOfAllVarUsesForFunc = null;
		
		if (!allOrPart) {
		
			mlistOfAllArrayIntializers = data.mlistOfAllArrayIntializers;
			mlistOfAllAssignStatements = data.mlistOfAllAssignStatements;
			mlistOfAllControlBlocks = data.mlistOfAllControlBlocks;
			mlistOfAllConstructor = data.mlistOfAllConstructor;
			mlistOfAllDefinedClasses = data.mlistOfAllDefinedClasses;
			mlistOfAllForLoops = data.mlistOfAllForLoops;
			mlistOfAllFunctions = data.mlistOfAllFunctions;
			mlistOfAllLocalVarDeclarations = data.mlistOfAllLocalVarDeclarations;
			mlistOfAllMemberVarDeclarations = data.mlistOfAllMemberVarDeclarations;
			mlistOfAllTemplates = data.mlistOfAllTemplates;
			mlistOfAllTypeCasts = data.mlistOfAllTypeCasts;
			mlistOfAllVarUses = data.mlistOfAllVarUses;
			mlistOfAllVarUsesHashed = data.mlistOfAllVarUsesHashed;
			mlistOfAnnotations = data.mlistOfAnnotations;
			mlistOfBlocks = data.mlistOfBlocks;
			mlistOfFinally = data.mlistOfFinally;
			mlistOfFindStatementParams = data.mlistOfFindStatementParams;			
			mlistOfSpecialStatement = data.mlistOfSpecialStatement;
			mlistOfThreeOperandsOperation = data.mlistOfThreeOperandsOperation;
			mlistOfNewLines = data.mlistOfNewLines;
			
			FindClassParams parentClassForPart = (FindClassParams) functionForPart.parent;
			
			listOfConstructor = parentClassForPart.listOfConstructor;
			listOfControlBlocks = parentClassForPart.listOfControlBlocks;
			listOfFunctionParams = parentClassForPart.listOfFunctionParams;
			listOfSpecialBlocks = parentClassForPart.listOfSpecialBlocks;
			listOfStatements = parentClassForPart.listOfStatements;
			listOfVariableParams = parentClassForPart.listOfVariableParams;
			listOfAllVarUsesForVar = parentClassForPart.listOfAllVarUsesForVar;
			listOfAllVarUsesForFunc = parentClassForPart.listOfAllVarUsesForFunc;
			listOfAllVarUsesForVarHashed = parentClassForPart.listOfAllVarUsesForVarHashed;
			listOfAllVarUsesForFuncHashed = parentClassForPart.listOfAllVarUsesForFuncHashed;
			listOfAllVarUses = parentClassForPart.listOfAllVarUses;
			
			data.mlistOfAllArrayIntializers = new ArrayListIReset(5);
			data.mlistOfAllAssignStatements = new ArrayListIReset(5);
			data.mlistOfAllControlBlocks = new ArrayListIReset(5);
			data.mlistOfAllConstructor = new ArrayListIReset(5);
			data.mlistOfAllDefinedClasses = new ArrayListIReset(5);
			data.mlistOfAllForLoops = new ArrayListIReset(5);
			data.mlistOfAllFunctions = new ArrayListIReset(5);
			data.mlistOfAllLocalVarDeclarations = new HighArray(5);
			data.mlistOfAllMemberVarDeclarations = new HighArray(5);
			data.mlistOfAllTemplates = new ArrayListIReset(5);
			data.mlistOfAllTypeCasts = new ArrayListIReset(5);
			data.mlistOfAllVarUses = new HighArray(5);
			data.mlistOfAllVarUsesHashed = new Hashtable2_String(50, 20);
			data.mlistOfAnnotations = new ArrayListIReset(5);
			data.mlistOfBlocks = new ArrayListIReset(5);
			data.mlistOfFinally = new ArrayListIReset(5);
			data.mlistOfFindStatementParams = new ArrayListIReset(5);			
			data.mlistOfSpecialStatement = new ArrayListIReset(5);
			data.mlistOfThreeOperandsOperation = new ArrayListIReset(5);
			data.mlistOfNewLines = new ArrayListInt(5);
			
			
		
			parentClassForPart.listOfConstructor = new ArrayListIReset(5);
			parentClassForPart.listOfControlBlocks = new ArrayListIReset(5);
			parentClassForPart.listOfFunctionParams = new ArrayListIReset(5);
			parentClassForPart.listOfSpecialBlocks = new ArrayListIReset(5);
			parentClassForPart.listOfStatements = new ArrayListIReset(5);
			parentClassForPart.listOfVariableParams = new ArrayListIReset(5);
			//parentClassForPart.allocateListOfVarUses(modeAllOrUpdate);
			parentClassForPart.listOfAllVarUses = new HighArray(5);
			parentClassForPart.listOfAllVarUsesForVar = new HighArray(5);
			parentClassForPart.listOfAllVarUsesForFunc = new HighArray(5);
			//parentClassForPart.listOfAllVarUsesForVarHashed = new Hashtable2_String(50, 20);
			//parentClassForPart.listOfAllVarUsesForFuncHashed = new Hashtable2_String(50, 20);
			
		/*	functionForPart.increases_start_pc_OfLocalVarsBySwitch = false;
			functionForPart.increases_start_pc_OfLocalVarsByTry = false;
			functionForPart.isTypeNameToChange = false;
			functionForPart.listOfAllVarUses = new HighArray(30);
			functionForPart.listOfAllVarUsesForFunc = new HighArray(20);
			functionForPart.listOfAllVarUsesForVar = new HighArray(20);
			functionForPart.listOfControlBlocks = new ArrayListIReset(5);
			functionForPart.listOfFuncArgs = new ArrayListIReset(5);
			functionForPart.listOfLocalVarsForArrayInit = new ArrayListIReset(5);
			functionForPart.listOfLocalVarsForArrayInit_arrayLength = new ArrayListIReset(5);
			functionForPart.listOfSpecialBlocks = new ArrayListIReset(5);
			functionForPart.listOfStatements = new ArrayListIReset(5);
			functionForPart.listOfVariableParams = new ArrayListIReset(5);
			functionForPart.listOfVariableParamsBeforeProcessLocalVars = null;
			*/
		}
		
		compilerStack.findAnnotation(data.mBuffer, startIndex, endIndex);
		
		this.compilerStack.core.findNewLines(startIndex, endIndex);
		
		compilerStack.core.FindAllClassesAndItsMembers2_sub(startIndex, endIndex, result, ModeAllOrUpdate.Update,
				allOrPart, functionForPart, coreThreadID, showsLogMessage);
		
		if (data.language != Language.C) { // c의 경우는 this를 넣지 않는다.
			int i;
			for (i=0; i<data.mlistOfClass.count; i++) {
				FindClassParams classParams = (FindClassParams) data.mlistOfClass.getItem(i);
				inputThisAndSuperToClassAndInputVarUsesToHashtable(data.mBuffer, classParams, ModeAllOrUpdate.All, 
						allOrPart, startIndex, endIndex);
			}
		}
		
		if (!allOrPart) {
			Update.insertPart(data.mlistOfAllArrayIntializers, mlistOfAllArrayIntializers);
			Update.insertPart(data.mlistOfAllAssignStatements, mlistOfAllAssignStatements);
			Update.insertPart(data.mlistOfAllControlBlocks, mlistOfAllControlBlocks);
			Update.insertPart(data.mlistOfAllConstructor, mlistOfAllConstructor);
			Update.insertPart(data.mlistOfAllDefinedClasses, mlistOfAllDefinedClasses);
			Update.insertPart(data.mlistOfAllForLoops, mlistOfAllForLoops);
			//Update.insertPart(data.mlistOfAllFunctions, mlistOfAllFunctions);
			Update.insertPart(data.mlistOfAllLocalVarDeclarations, mlistOfAllLocalVarDeclarations);
			Update.insertPart(data.mlistOfAllMemberVarDeclarations, mlistOfAllMemberVarDeclarations);
			Update.insertPart(data.mlistOfAllTemplates, mlistOfAllTemplates);
			Update.insertPart(data.mlistOfAllTypeCasts, mlistOfAllTypeCasts);
			Update.insertPart2(data.mlistOfAllVarUses, mlistOfAllVarUses);
			Update.insertPart(data.mlistOfAllVarUsesHashed, mlistOfAllVarUsesHashed);
			Update.insertPart(data.mlistOfAnnotations, mlistOfAnnotations);
			Update.insertPart(data.mlistOfBlocks, mlistOfBlocks);
			Update.insertPart(data.mlistOfFinally, mlistOfFinally);
			Update.insertPart(data.mlistOfFindStatementParams, mlistOfFindStatementParams);			
			Update.insertPart(data.mlistOfSpecialStatement, mlistOfSpecialStatement);
			Update.insertPart(data.mlistOfThreeOperandsOperation, mlistOfThreeOperandsOperation);
			Update.insertPart(data.mlistOfNewLines, mlistOfNewLines);
			
			FindClassParams parentClassForPart = (FindClassParams) functionForPart.parent;
					
			Update.insertPart(parentClassForPart.listOfConstructor, listOfConstructor);
			Update.insertPart(parentClassForPart.listOfControlBlocks, listOfControlBlocks);
			//Update.insertPart(parentClassForPart.listOfFunctionParams, listOfFunctionParams);			
			Update.insertPart(parentClassForPart.listOfSpecialBlocks, listOfSpecialBlocks);
			Update.insertPart(parentClassForPart.listOfStatements, listOfStatements);
			Update.insertPart(parentClassForPart.listOfVariableParams, listOfVariableParams);
			Update.insertPart(parentClassForPart.listOfAllVarUsesForVarHashed, listOfAllVarUsesForVarHashed);
			Update.insertPart(parentClassForPart.listOfAllVarUsesForFuncHashed, listOfAllVarUsesForFuncHashed);
			Update.insertPart2(parentClassForPart.listOfAllVarUsesForVar, listOfAllVarUsesForVar);
			Update.insertPart2(parentClassForPart.listOfAllVarUsesForFunc, listOfAllVarUsesForFunc);
			Update.insertPart2(parentClassForPart.listOfAllVarUses, listOfAllVarUses);
			
			
			data.mlistOfAllArrayIntializers = mlistOfAllArrayIntializers;
			data.mlistOfAllAssignStatements = mlistOfAllAssignStatements;
			data.mlistOfAllControlBlocks = mlistOfAllControlBlocks;
			data.mlistOfAllConstructor = mlistOfAllConstructor;
			data.mlistOfAllDefinedClasses = mlistOfAllDefinedClasses;
			data.mlistOfAllForLoops = mlistOfAllForLoops;
			data.mlistOfAllFunctions = mlistOfAllFunctions;
			data.mlistOfAllLocalVarDeclarations = mlistOfAllLocalVarDeclarations;
			data.mlistOfAllMemberVarDeclarations = mlistOfAllMemberVarDeclarations;
			data.mlistOfAllTemplates = mlistOfAllTemplates;
			data.mlistOfAllTypeCasts = mlistOfAllTypeCasts;
			data.mlistOfAllVarUses = mlistOfAllVarUses;
			data.mlistOfAllVarUsesHashed = mlistOfAllVarUsesHashed;
			data.mlistOfAnnotations = mlistOfAnnotations;
			data.mlistOfBlocks = mlistOfBlocks;
			data.mlistOfFinally = mlistOfFinally;
			data.mlistOfFindStatementParams = mlistOfFindStatementParams;			
			data.mlistOfSpecialStatement = mlistOfSpecialStatement;
			data.mlistOfThreeOperandsOperation = mlistOfThreeOperandsOperation;
			data.mlistOfNewLines = mlistOfNewLines;
					
			parentClassForPart.listOfConstructor = listOfConstructor;
			parentClassForPart.listOfControlBlocks = listOfControlBlocks;
			parentClassForPart.listOfFunctionParams = listOfFunctionParams;			
			parentClassForPart.listOfSpecialBlocks = listOfSpecialBlocks;
			parentClassForPart.listOfStatements = listOfStatements;
			parentClassForPart.listOfVariableParams = listOfVariableParams;
			parentClassForPart.listOfAllVarUsesForVarHashed = listOfAllVarUsesForVarHashed;
			parentClassForPart.listOfAllVarUsesForFuncHashed = listOfAllVarUsesForFuncHashed;
			parentClassForPart.listOfAllVarUsesForVar = listOfAllVarUsesForVar;
			parentClassForPart.listOfAllVarUsesForFunc = listOfAllVarUsesForFunc;
			parentClassForPart.listOfAllVarUses = listOfAllVarUses;
			
			
		}
		
	}catch(Exception e) {
		if (Common_Settings.g_printsLog) e.printStackTrace();
		if (Common_Settings.g_printsLog) CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
	}
	}
	
	/** varUse를 포함하는 제어구조 내에서 varUse를 갖는 최소의 문장을 찾아 리턴한다.*/
	FindStatementParams findFindStatementParams(FindVarUseParams varUse, FindControlBlockParams controlBlock) {
		int i;
		if (controlBlock.indexOfLeftParenthesis()==31700) {
		}
		for (i=0; i<controlBlock.listOfStatements.count; i++) {
			FindStatementParams statement = (FindStatementParams) controlBlock.listOfStatements.getItem(i);
			if (statement instanceof FindVarParams) continue;
			int startIndex = statement.startIndex();
			int endIndex = statement.endIndex();
			
			if (startIndex<=varUse.index() && varUse.index()<=endIndex) {
				if (statement instanceof FindControlBlockParams) {
					FindControlBlockParams child = (FindControlBlockParams) statement;
					if (child.indexOfLeftParenthesis()<=varUse.index() && varUse.index()<=child.indexOfRightParenthesis())
						return child;
					return findFindStatementParams(varUse, child);
				}
				else {
					return statement;
				}
			}
		}
		return null;
	}
	
	/**startIndex, endIndex 모두 포함*/
	public void FindAllClassesAndItsMembers2( int startIndex, int endIndex, 
			ArrayListIReset result, Language lang, ModeAllOrUpdate modeAllOrUpdate, 
			boolean allOrPart, FindFunctionParams functionForPart, int coreThreadID, boolean showsLogMessage) {
		HighArray_CodeString src = this.data.mBuffer;
		try{
			//CommonGUI.drawOnlyLog = true;
			
			
			if (lang==Language.Java) {
				compilerStack.core.changeSourceAndInputWithConditions();
				endIndex = data.mBuffer.count-1;
				src = data.mBuffer;
				
				compilerStack.RegisterPackageName(src);
				
				this.loadLibraries2(this);
				
				compilerStack.RegisterImportedClasses(src);
				
				compilerStack.loadImportStar(coreThreadID);
				
			}
			
			
			//modeAllOrUpdate = ModeAllOrUpdate.All;
			
			try {
				
				if (showsLogMessage) {
					CommonGUI.showMessage(true, "FindAllClassesAndItsMembers2_sub()...");
				}
				
				if (allOrPart) {
					compilerStack.findAnnotation(data.mBuffer, startIndex, endIndex);
					
					this.compilerStack.core.findNewLines(startIndex, endIndex);
					
					
					compilerStack.core.FindAllClassesAndItsMembers2_sub(startIndex, endIndex, result, modeAllOrUpdate,
							allOrPart, functionForPart, coreThreadID, showsLogMessage);
					
					
					
					int i;
					for (i=0; i<data.mlistOfAllDefinedClasses.count; i++) {
						FindClassParams classParams = (FindClassParams) data.mlistOfAllDefinedClasses.getItem(i);
						classParams.loadWayOfFindClassParams = LoadWayOfFindClassParams.Start2; 
					}
					setClassNamesAndCreateConstructors(coreThreadID);
					
					/*FindClassParams classParams0 = (FindClassParams) data.mlistOfClass.getItem(0);
					if (classParams0==null) {
						return;
					}
					String shortName = CompilerHelper.getShortName(classParams0.name);*/
					boolean b = checkFilename(data.packageName);
					if (!b) return;
					
					ClassCache.setClassCache(this, modeAllOrUpdate, coreThreadID);
					
					for (i=0; i<data.mlistOfClass.count; i++) {
						FindClassParams classParams = (FindClassParams) data.mlistOfClass.getItem(i);
						inputThisAndSuperToClassAndInputVarUsesToHashtable(data.mBuffer, classParams, ModeAllOrUpdate.All, 
								allOrPart, startIndex, endIndex);
					}
				}
				else {
					FindAllClassesAndItsMembers2_sub_update(startIndex, endIndex, result, allOrPart, functionForPart, coreThreadID, showsLogMessage);
					setClassNamesAndCreateConstructors(coreThreadID);
				}
				
				
				
				
				if (FileHelper.getFilename(data.filename).equals("ConnectDialog.java")) {
				}
			}catch(Exception e) {
				if (Common_Settings.g_printsLog) e.printStackTrace();
				if (Common_Settings.g_printsLog) CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
			}
			
			
			FindAllClassesAndItsMembers2_part2( startIndex, endIndex, 
					result, lang, modeAllOrUpdate, allOrPart, functionForPart, coreThreadID, showsLogMessage);
			
			//CommonGUI.drawOnlyLog = false;
		
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
			if (Common_Settings.g_printsLog) CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
		}
		
		
		
	}
		
		
	public void FindAllClassesAndItsMembers2_part2(int startIndex, int endIndex, 
			ArrayListIReset result, Language lang, ModeAllOrUpdate modeAllOrUpdate, 
			boolean allOrPart, FindFunctionParams functionForPart, int coreThreadID, boolean showsLogMessage) {
		HighArray_CodeString src = this.data.mBuffer;
		try {
			if (showsLogMessage) {
				CommonGUI.showMessage(true, "findTypeCasts()");
			}
			
			
		TypeCast_Syntax.findTypeCasts(this, src, data.mlistOfAllVarUses, allOrPart, startIndex, endIndex, coreThreadID);
		
		
		TemplateBase.findAllVarUsingOfTemplate(this, src);
		
			
		
		
		if (showsLogMessage) {
			CommonGUI.showMessage(true, "FindClassesFromTypeDecls()");
		}
		
		// 상속을 하기전에 변수, 메서드 등의 타입을 확실히 한다. 
		// TreeNodeButton은 Button을 상속하는데 Button은 TreeNodeButton 다음에 정의되므로
		// FindMembersInherited()에서 Button을 loadClass()할때 Button은 캐시에 등록되어 있고
		// 그것의 멤버들을 상속하여 중복 변수, 중복 메서드를 체크 할때(CompilerHelper.hasInherittedMember()) 
		// FindClassesFromTypeDecls()가 FindMembersInherited() 다음에 오면 아직 타입이 정의되어
		// 있지 않으므로 NullPointerException이 발생한다.
		ArrayListString namesOfClassesFromTypeDecls = new ArrayListString(10);
		compilerStack.core.FindClassesFromTypeDecls(this, namesOfClassesFromTypeDecls, coreThreadID);
		
		Checker.checkDuplicateNames(this, coreThreadID);
		
		
		int i;
		for (i=0; i<data.mlistOfAllDefinedClasses.count; i++) {
			FindClassParams c = (FindClassParams) data.mlistOfAllDefinedClasses.getItem(i);
			if (c.template!=null) {
				TemplateBase.applyTypeNameToChangeToTemplateClass(this, c, c.name, (byte)0);
			}
		}
		
		
		if (showsLogMessage) {
			CommonGUI.showMessage(true, "FindMembersInherited()");
		}
		
		// 같은 파일에 정의된 클래스들의 이름이 fullname으로 확실하게 정한 이후에 상속한다.
		for (i=0; i<data.mlistOfAllDefinedClasses.count; i++) {
			FindClassParams classParams = (FindClassParams) data.mlistOfAllDefinedClasses.getItem(i);
			if (CompilerStatic.getShortName(classParams.name).equals("Block")) {
				int a;
				a=0;
				a++;
			}
			compilerStack.FindMembersInherited(classParams, coreThreadID);
			if (classParams.hasVarInheritted("Common_Settings.textColor")) {
			}
		}
		
				
		
		if (showsLogMessage) {
			CommonGUI.showMessage(true, "findAllVarUsingAndChangeMemberDeclColor_caller_Local()");
		}
		
		findAllLocalVarUsing_caller_Local( 
				data.mlistOfAllMemberVarDeclarations, data.mlistOfAllLocalVarDeclarations);
		
		
		
		
		if (showsLogMessage) {
			CommonGUI.showMessage(true, "findMemberUsesUsingNamespace()");
		}
		
		try {			
			Member.findMemberUsesUsingNamespace_OnlyImport(this, coreThreadID);
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
			if (Common_Settings.g_printsLog) CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
		}
		
		
		// import하지 않고 com.gsoft.common.FileHelper.getFileName()호출을 하는 경우와 같이
		// 이런 경우는 import문에서 클래스가 로드되는 것이 아니라 호출시 로드가 된다.
		try {
			int nextIndexOfLastImport = -1;
			if (data.mlistOfImportStatements.count>0) {
				nextIndexOfLastImport = ((ImportStatement)data.mlistOfImportStatements.getItem(data.mlistOfImportStatements.count-1)).endIndex();
			}
			Member.findMemberUsesUsingNamespace(this, nextIndexOfLastImport+1, endIndex, coreThreadID);
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
			if (Common_Settings.g_printsLog) CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
		}
		
		if (showsLogMessage) {
			CommonGUI.showMessage(true, "findTypeOfAssignments()");
		}
		
		findTypeOfAssignments( allOrPart, startIndex, endIndex, coreThreadID);
		
		findTypeOfSpecialStatements(this, coreThreadID);
		
		findTypeOfConditionsAndConvertConditionsToPostfix( coreThreadID);
		
	
		
		putAssignsOfClassToConstructorInAllDefinedClasses(allOrPart, functionForPart);
	
		
		//this.addTryFinallySheildToAllFunctionsWithSynchronized();
		
		String typeName = "java.lang.Throwable";
		String fieldName = ByteCode_Types.throwableVarNameForFinallyBlock;		
		
		for (i=0; i<data.mlistOfFinally.count; i++) {
			try {
			FindControlBlockParams block = (FindControlBlockParams) data.mlistOfFinally.getItem(i);
			// finally절에서 java.lang.Throwable 예외를 발생시키기 위한 지역변수를 만든다.
			Block parent = CompilerStatic.getParent(block);
			if (!(parent instanceof FindFunctionParams)) continue;
			FindFunctionParams func = (FindFunctionParams) parent;
			FindVarParams throwableLocalVar = new FindVarParams(this, typeName, fieldName);
			throwableLocalVar.isMemberOrLocal = false;
			throwableLocalVar.parent = block;
			
			throwableLocalVar.isFake = true;
			// 등록이 안되어 있으면 등록한다.
			FindVarParams var = func.getVar(fieldName);
			if (var==null) {
				func.listOfVariableParams.add(throwableLocalVar);
				throwableLocalVar.indexOfLocalVarsInFunctionBeforeProcessLocalVars = func.listOfVariableParams.count-1; 
			}
			
			}catch(Exception e) {
				if (Common_Settings.g_printsLog) e.printStackTrace();
			}
		}// for (i=0; i<data.mlistOfFinally.count; i++) {
		
		fieldName = ByteCode_Types.varNameForTempLocalArrayInitializer;
		
		for (i=0; i<data.mlistOfTempLocalArrayInitializers.count; i++) {
			TempLocalArrayInitializer tempLocalArrayInit = (TempLocalArrayInitializer) data.mlistOfTempLocalArrayInitializers.getItem(i);
			// finally절에서 java.lang.Throwable 예외를 발생시키기 위한 지역변수를 만든다.
			FindFunctionParams func = (FindFunctionParams) tempLocalArrayInit.varUseFuncCall.funcToDefineThisVarUse;
			typeName = tempLocalArrayInit.funcArg.typeName;
			FindVarParams tempLocalVar_ArrayInit = new FindVarParams(this, typeName, fieldName);
			tempLocalVar_ArrayInit.isMemberOrLocal = false;
			tempLocalVar_ArrayInit.parent = func;
			
			tempLocalVar_ArrayInit.isFake = true;
			// 등록이 안되어 있으면 등록한다.
			FindVarParams var = func.getVar(fieldName);
			if (var==null) {
				func.listOfVariableParams.add(tempLocalVar_ArrayInit);
				tempLocalVar_ArrayInit.indexOfLocalVarsInFunctionBeforeProcessLocalVars = func.listOfVariableParams.count-1; 
			}
		}
		
		addSynchronizedVarAndFinallyVarToAllFunctions();
		
		
		
		for (i=0; i<data.mlistOfAllFunctions.count; i++) {
			FindFunctionParams func = (FindFunctionParams) data.mlistOfAllFunctions.getItem(i);
			if (allOrPart || func==functionForPart) {
				if (func.name.equals("main") && func.accessModifier.isStatic) {
					Console.putTryCatchShieldForFunction(this, func);
				}
			}
		}
		
		
		
		LocalVar.processLocalVarsDefinedInBlock(this);
		
		
		
		// 함수별 지역변수들의 index를 센다.
		for (i=0; i<data.mlistOfAllFunctions.count; i++) {
			FindFunctionParams func = (FindFunctionParams) data.mlistOfAllFunctions.getItem(i);
			if (!allOrPart) {
				int a;
				a=0;
				a++;
			}
			if (allOrPart || func==functionForPart) {
				LocalVar.processLocalVars(func);
				Checker.containsLocalVarThatDoesNotInitialize(this, func, true);
			}
		}
				
		for (i=0; i<data.mlistOfAllControlBlocks.count; i++) {
			FindControlBlockParams controlBlock = (FindControlBlockParams) data.mlistOfAllControlBlocks.getItem(i);
			if (controlBlock.findBlockParams==null && controlBlock.listOfControlBlocks.count>0) {
				controlBlock.endIndexWhenNestingControlBlockWithoutMiddlePair = 
						ByteCode_Types.getEndIndexOfNestingControlBlockWithoutMiddlePair(controlBlock.nameIndex());
			}
		}
		
		Checker.checkConstructor(this);
		
		Checker.changeKeywordAndConstantColorAndTextColor(this, src, allOrPart, startIndex, endIndex);
		
		Checker.changeVarUseColor(src, data.mlistOfClass, allOrPart, startIndex, endIndex);
		
		Checker.checkControlBlocks(this, src, allOrPart, startIndex, endIndex);
		
		Checker.checkThrowReturnContinueAndBreak(this, coreThreadID);
		
		Checker.checkVarUse(this, src, allOrPart, startIndex, endIndex);
		
		Checker.checkLocalVar(this, src, data.mlistOfAllFunctions, allOrPart, functionForPart);
		
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
			if (Common_Settings.g_printsLog) CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
		}
	}
	
	void addTryFinallySheildToAllFunctionsWithSynchronized() {
		int i;
		ArrayList listOfFuncsWithSync = new ArrayList(5); 
		for (i=0; i<data.mlistOfAllFunctions.count; i++) {
			FindFunctionParams func = (FindFunctionParams) data.mlistOfAllFunctions.getItem(i);
			if (func.accessModifier.isSynchronized) {
				//Synchronized.putTryFinallyShieldForMonitorExitInFunctionWithSynchronized(this, func);
				listOfFuncsWithSync.add(func);
			}
		}
		for (i=0; i<data.mlistOfAllControlBlocks.count; i++) {
			FindControlBlockParams controlBlock = (FindControlBlockParams) data.mlistOfAllControlBlocks.getItem(i);
			if (controlBlock.getName().equals("synchronized")) {
				FindFunctionParams func = (FindFunctionParams) CompilerStatic.getParent(controlBlock);
				int j;
				boolean allreadyAdded = false;
				for (j=0; j<listOfFuncsWithSync.count; j++) {
					FindFunctionParams f = (FindFunctionParams) listOfFuncsWithSync.getItem(j);
					if (f==func) {
						allreadyAdded = true;
						break;
					}
				}
				if (!allreadyAdded) {
					listOfFuncsWithSync.add(func);
				}
			}
		}// for (i=0; i<data.mlistOfAllControlBlocks.count; i++) {
		
		for (i=0; i<listOfFuncsWithSync.count; i++) {
			FindFunctionParams f = (FindFunctionParams) listOfFuncsWithSync.getItem(i);
			Synchronized.putTryFinallyShieldForMonitorExitInFunctionWithSynchronized(this, f);
			int a;
			a=0;
			a++;
		}
	}
	
	void addSynchronizedVarAndFinallyVarToAllFunctions() {
		int i;
		String typeName = "int";
		String fieldNameOfSynchronized = "bitMaskArrForSynchronized";
		String fieldNameOfFinally = "bitMaskArrForFinally";
		
		for (i=0; i<data.mlistOfAllFunctions.count; i++) {
			FindFunctionParams func = (FindFunctionParams) data.mlistOfAllFunctions.getItem(i);
			if (func.accessModifier.isSynchronized) {
				FindVarParams synchronizedVar = new FindVarParams(this, typeName, fieldNameOfSynchronized);
				synchronizedVar.isMemberOrLocal = false;
				synchronizedVar.parent = func;					
				synchronizedVar.isFake = true;
				// 등록이 안되어 있으면 등록한다.
				FindVarParams var = func.getVar(fieldNameOfSynchronized);
				if (var==null) {
					func.listOfVariableParams.add(synchronizedVar);
					synchronizedVar.indexOfLocalVarsInFunctionBeforeProcessLocalVars = func.listOfVariableParams.count-1; 
				}
			}
		} // for (i=0; i<data.mlistOfAllFunctions.count; i++) {
		
		for (i=0; i<data.mlistOfAllControlBlocks.count; i++) {
			FindControlBlockParams controlBlock = (FindControlBlockParams) data.mlistOfAllControlBlocks.getItem(i);
			if (controlBlock instanceof FindSpecialBlockParams) {
				if (controlBlock.getName().equals("synchronized")) {
					// synchronized절에서 monitor를 위한 지역변수를 만든다.
					Block parent = CompilerStatic.getParent(controlBlock);
					FindFunctionParams func = (FindFunctionParams) parent;
					
					FindVarParams synchronizedVar = new FindVarParams(this, typeName, fieldNameOfSynchronized);
					synchronizedVar.isMemberOrLocal = false;
					synchronizedVar.parent = func;					
					synchronizedVar.isFake = true;
					// 등록이 안되어 있으면 등록한다.
					FindVarParams var = func.getVar(fieldNameOfSynchronized);
					if (var==null) {
						func.listOfVariableParams.add(synchronizedVar);
						synchronizedVar.indexOfLocalVarsInFunctionBeforeProcessLocalVars = func.listOfVariableParams.count-1; 
					}
				}
				else if (controlBlock.getName().equals("finally")) {
					// finally절에서 throwable를 위한 지역변수를 만든다.
					Block parent = CompilerStatic.getParent(controlBlock);
					FindFunctionParams func = (FindFunctionParams) parent;
					
					FindVarParams finallyVar = new FindVarParams(this, typeName, fieldNameOfFinally);
					finallyVar.isMemberOrLocal = false;
					finallyVar.parent = func;					
					finallyVar.isFake = true;
					// 등록이 안되어 있으면 등록한다.
					FindVarParams var = func.getVar(fieldNameOfFinally);
					if (var==null) {
						func.listOfVariableParams.add(finallyVar);
						finallyVar.indexOfLocalVarsInFunctionBeforeProcessLocalVars = func.listOfVariableParams.count-1; 
					}
				}
			}// if (controlBlock instanceof FindSpecialBlockParams) {
		}// for (i=0; i<data.mlistOfAllControlBlocks.count; i++) {
		
		
	}
	
	/**클래스 이름과 클래스 캐시를 설정하고 생성자들을 만든다.
	 * @param coreThreadID */ 
	public void setClassNamesAndCreateConstructors(int coreThreadID) {
		HighArray_CodeString src = this.data.mBuffer;
		int i, j;		
		try {
		// 외부라이브러리처럼 클래스의 name을 fullname으로 정해준다.
		// mlistOfAllClasses이 static이므로 mlistOfAllDefinedClasses안의 클래스들을 대상으로 한다.
		// 즉, 여러 파일을 load할 경우 src가 달라지는 문제가 발생할 수 있다.
		for (i=0; i<data.mlistOfAllDefinedClasses.count; i++) {
			FindClassParams c = (FindClassParams) data.mlistOfAllDefinedClasses.getItem(i);
			if (c.name==null) {
				String fullName;
				if (!c.isEventHandlerClass) {
					String fullNameExceptPackageName1 = Fullname.getFullNameExceptPackageName(src, c);
					String fullNameExceptPackageName2 = fullNameExceptPackageName1.substring(0, fullNameExceptPackageName1.length()-1);
					//fullName = data.packageName + "." + fullNameExceptPackageName2;
					if (data.packageName!=null) {
						fullName = data.packageName + "." + fullNameExceptPackageName2;
					}
					else {
						fullName = fullNameExceptPackageName2;
					}
				}
				else {
					fullName = Fullname.getFullNameType(this, c.startIndexOfEventHandlerName(), 
							c.endIndexOfEventHandlerName(), coreThreadID) + "_EventHandler";
				}
				c.name = fullName;
				if (c.name.equals("android.content.Context")) {
					int a;
					a=0;
					a++;	
				}
				// 인터페이스나 추상클래스이면 디폴트 생성자를 만들지 않는다. 인스턴스를 만들 수 없기 때문이다.
				if (!(c.isInterface || c.accessModifier.isAbstract)) {
					CompilerHelper.makeNoneStaticDefaultConstructorIfConstructorNotExist(this, c);
				}
				if (!(c.isInterface)) {
					// static 필드가 있으면 추상클래스도 static 생성자를 만들어야 한다.					
					if (CompilerHelper.requiresStaticConstructor(c)) {
						CompilerHelper.makeStaticDefaultConstructorIfStaticConstructorNotExist(this, c);
					}
				}
			}
			// 여기서 mlistOfAllClasses에 넣어준다. 
			// import한 기존 클래스가 아니라 새로 읽어들인 클래스로 바꿔준다.
			//synchronized (SynchronizedObjects.lockForMultiThreadBuild) {
				
			//}// synchronized (System.out) {
			
			
		}
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
			if (Common_Settings.g_printsLog) CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
		}
	}
	
	
	
	/** return문을 포함하는 synchronized가 중첩되거나 그렇지 않을 경우 synchronized의 개수를 세어 리턴한다.
	 * return문이 synchronized에 포함되지 않으면 0을 리턴한다.*/  
	int getCountOfSynchronized(FindSpecialStatementParams statement) {
		if (statement.kewordIndex()==1656) {
		}
		int count=0;
		FindStatementParams parent = statement.parent;
		while (true) {			
			if (parent==null) return count;
			if (parent instanceof FindFunctionParams) {
				FindFunctionParams func = (FindFunctionParams) parent;
				if (func.accessModifier!=null && func.accessModifier.isSynchronized) 
					count++;
				else return count;
			}
			if (parent instanceof FindClassParams) {
				return count;
			}
			if (parent instanceof FindControlBlockParams) {
				FindControlBlockParams controlBlock = (FindControlBlockParams) parent;
				// controlBlock.nameIndex()==-1일 경우 가짜 try-catch블록
				if (controlBlock.nameIndex()!=-1 &&
						data.mBuffer.getItem(controlBlock.nameIndex()).equals("synchronized"))
					count++;
			}
			parent = parent.parent;
		}
	}
	
	/** mlistOfAllDefinedClasses에서 클래스의 멤버 초기화문을 찾아서 
	 * 그 클래스의 생성자의 앞부분에 넣는다.
	 * static멤버 초기화 부분은 따로 넣는다.
	 * @param functionForPart 
	 * @param allOrPart */
	void putAssignsOfClassToConstructorInAllDefinedClasses(boolean allOrPart, FindFunctionParams functionForPart) {
		int i;
		for (i=0; i<data.mlistOfAllDefinedClasses.count; i++) {
			try {
			FindClassParams classParams = (FindClassParams) data.mlistOfAllDefinedClasses.getItem(i);
			
			ArrayListIReset listOfAssignsOfClass_instance = new ArrayListIReset(classParams.listOfStatements.count);
			listOfAssignsOfClass_instance.resizeInc = 100;
			ArrayListIReset listOfAssignsOfClass_static = new ArrayListIReset(classParams.listOfStatements.count);
			listOfAssignsOfClass_static.resizeInc = 50;
			
			ArrayListIReset listOfAssignsOfClass_instance_backup = null;
			ArrayListIReset listOfAssignsOfClass_static_backup = null;
			
			// 클래스의 초기화 문장들을 넣는다.
			for (int k=0; k<classParams.listOfStatements.count; k++) {
				FindStatementParams statement = (FindStatementParams) classParams.listOfStatements.getItem(k);
				if (statement instanceof FindVarParams) {
					FindVarParams var = (FindVarParams) statement;
					if (var.isNotInitialized()) {
						if (var.accessModifier!=null && var.accessModifier.isStatic) {
							listOfAssignsOfClass_static.add(var);
						}
						else {
							listOfAssignsOfClass_instance.add(var);
						}
					}
				}
				else if (statement instanceof FindAssignStatementParams) {
					FindAssignStatementParams assign = (FindAssignStatementParams) statement;
					FindVarParams var = assign.lValue.varDecl;
					if (var==null) continue;
					if (var.accessModifier!=null && var.accessModifier.isStatic) {
						listOfAssignsOfClass_static.add(assign);
					}
					else {
						listOfAssignsOfClass_instance.add(assign);
					}
				}
			}
			listOfAssignsOfClass_instance_backup = this.getClone(listOfAssignsOfClass_instance);
			listOfAssignsOfClass_static_backup =  this.getClone(listOfAssignsOfClass_static);
			listOfAssignsOfClass_instance_backup.resizeInc = 100;
			listOfAssignsOfClass_static_backup.resizeInc = 50;
			
			for (int m=0; m<classParams.listOfConstructor.count; m++) {
				FindFunctionParams func = (FindFunctionParams) classParams.listOfConstructor.getItem(m);
				if (func.isConstructor) {
					if (func.functionNameIndex()==1088) {
					}
					if (!func.isConstructorThatInitializesStaticFields) {
						int n = 0;
						// super()를 가장 처음에 넣는다.
						if (CompilerHelper.hasFuncCallToConstructorOfSuperClass(this, func)) {
							listOfAssignsOfClass_instance.insert(0, func.listOfStatements.getItem(0));
							n = 1;
						}
						// 생성자의 원래 문장들을 그 다음에 넣는다.
						for (; n<func.listOfStatements.count; n++) {
							FindStatementParams s = (FindStatementParams) func.listOfStatements.getItem(n);
							if (s instanceof FindIndependentFuncCallParams) {
								
							}
							listOfAssignsOfClass_instance.add(s);
						}
						func.listOfStatements = listOfAssignsOfClass_instance;
					}
					else { 
						// static constuctor
						for (int n=0; n<func.listOfStatements.count; n++) {
							listOfAssignsOfClass_static.add(func.listOfStatements.getItem(n));
						}
						func.listOfStatements = listOfAssignsOfClass_static;
					}
				}
				listOfAssignsOfClass_instance = this.getClone(listOfAssignsOfClass_instance_backup);
				listOfAssignsOfClass_static = this.getClone(listOfAssignsOfClass_static_backup);
			}//for (int m=0; m<classParams.listOfConstructor.count; m++) {
			
			}catch(Exception e) {
				if (Common_Settings.g_printsLog) e.printStackTrace();
				
			}
		}//for (i=0; i<this.mlistOfAllDefinedClasses.count; i++) {
	}
	
	ArrayListIReset getClone(ArrayListIReset arr) {
		int i;
		ArrayListIReset r = new ArrayListIReset(arr.count);
		for (i=0; i<arr.count; i++) {
			r.add(arr.getItem(i));
		}
		return r;
	}
	
	/** findTypeOfConditionsAndConvertConditionsToPostfix()에서 호출하여 for loop의 조건문의 인덱스를 리턴한다.
	 * @return : 시작인덱스는 Point.x, 끝인덱스는 Point.y*/
	Point getConditionIndicesOfForLoop( int indexOfLeftParenthesis, int indexOfRightParenthesis) {
		HighArray_CodeString src = this.data.mBuffer;
		int startIndex = -1, endIndex = -1;
		
		startIndex = CompilerHelper.Skip(src, false, ";", indexOfLeftParenthesis+1, indexOfRightParenthesis-1);
		if (startIndex==indexOfRightParenthesis) {
			CompilerStatic.errors.add(new Error(this, indexOfLeftParenthesis, indexOfRightParenthesis, "Condition of for loop not valid."));
			return null;
		}
		startIndex++;
		
		endIndex = CompilerHelper.Skip(src, false, ";", startIndex, indexOfRightParenthesis-1);
		if (endIndex==indexOfRightParenthesis) {
			CompilerStatic.errors.add(new Error(this, indexOfLeftParenthesis, indexOfRightParenthesis, "Condition of for loop not valid."));
			return null;
		}
		endIndex--;	
		
		Point r = new Point();
		r.x = startIndex;
		r.y = endIndex;
		return r;
	}
	
	
	boolean isBoolean(String typeFullName) {
		if (typeFullName==null) return false;
		if (typeFullName.length()!=7) return false;
		
		if (typeFullName.charAt(0)!='b') return false;
		if (typeFullName.charAt(1)!='o') return false;
		if (typeFullName.charAt(2)!='o') return false;
		if (typeFullName.charAt(3)!='l') return false;
		if (typeFullName.charAt(4)!='e') return false;
		if (typeFullName.charAt(5)!='a') return false;
		if (typeFullName.charAt(6)!='n') return false;
		
		return true;
	}
		
	/** if, while, for 등의 조건문을 POSTFIX로 변환하고 타입을 결정한다.
	 * @param src : src having conditions
	 * @param coreThreadID */
	void findTypeOfConditionsAndConvertConditionsToPostfix( int coreThreadID) {
		HighArray_CodeString src = this.data.mBuffer;
		int i;
		for (i=0; i<data.mlistOfAllControlBlocks.count; i++) {
			try {
			FindControlBlockParams controlBlock = 
					(FindControlBlockParams) data.mlistOfAllControlBlocks.getItem(i);
			if (controlBlock.catOfControls==null) continue;
			
			if (controlBlock.catOfControls.category==CategoryOfControls.Control_for) {
				if (controlBlock.indexOfLeftParenthesis()==1332) {
					int a;
					a=0;
					a++;
				}
				Point p = getConditionIndicesOfForLoop( controlBlock.indexOfLeftParenthesis(), controlBlock.indexOfRightParenthesis());
				if (p!=null) {
					FindFuncCallParam funcCall = new FindFuncCallParam(this, p.x, p.y);
					funcCall.typeFullName = Expression.getTypeOfExpression(this, funcCall, coreThreadID);
					controlBlock.funcCall = funcCall;
					if (funcCall.typeFullName==null || !funcCall.typeFullName.equals("boolean")) {
						CompilerStatic.errors.add(new Error(this, controlBlock.nameIndex(), controlBlock.nameIndex(), "Condition of control block must be boolean. : " + funcCall.typeFullName));
					}
				}
			}
			else if (controlBlock.catOfControls.category==CategoryOfControls.Control_switch) { // switch문의 경우
				FindFuncCallParam funcCall = new FindFuncCallParam(this, controlBlock.indexOfLeftParenthesis()+1, controlBlock.indexOfRightParenthesis()-1);
				funcCall.typeFullName = Expression.getTypeOfExpression(this, funcCall, coreThreadID);
				controlBlock.funcCall = funcCall;
				if (funcCall.typeFullName!=null && (funcCall.typeFullName.equals("int") || funcCall.typeFullName.equals("char") ||
						funcCall.typeFullName.equals("byte") || funcCall.typeFullName.equals("short") || funcCall.typeFullName.equals("long"))) {
				}
				else {
					CompilerStatic.errors.add(new Error(this, controlBlock.nameIndex(), controlBlock.nameIndex(), "Condition of control block must be int. : " + funcCall.typeFullName));
				}
			}
			else if (controlBlock.catOfControls.category==CategoryOfControls.Control_case) { // case문의 경우
				FindFuncCallParam funcCall = new FindFuncCallParam(this, controlBlock.indexOfLeftParenthesis(), controlBlock.indexOfRightParenthesis()-1);
				funcCall.typeFullName = Expression.getTypeOfExpression(this, funcCall, coreThreadID);
				controlBlock.funcCall = funcCall;
				if (funcCall.typeFullName!=null && (funcCall.typeFullName.equals("int") || funcCall.typeFullName.equals("char") ||
						funcCall.typeFullName.equals("byte") || funcCall.typeFullName.equals("short") || funcCall.typeFullName.equals("long"))) {
				}
				else {
					CodeString nameOfControl = CompilerHelper.getNameOfControlBlock(this, controlBlock);
					if (!nameOfControl.equals("default")) {
						CompilerStatic.errors.add(new Error(this, controlBlock.nameIndex(), controlBlock.nameIndex(), "Condition of control block must be int. : " + funcCall.typeFullName));
					}
				}
			}
			else if (controlBlock.catOfControls.category==CategoryOfControls.Control_else) { // else문의 경우
				
			}
			else if (controlBlock.catOfControls.category!=CategoryOfControls.Control_case) {
				if (controlBlock.nameIndex()==2245) {
				}
				FindFuncCallParam funcCall = new FindFuncCallParam(this, controlBlock.indexOfLeftParenthesis()+1, controlBlock.indexOfRightParenthesis()-1);
				funcCall.typeFullName = Expression.getTypeOfExpression(this, funcCall, coreThreadID);
				controlBlock.funcCall = funcCall;
				if (funcCall.typeFullName==null || !funcCall.typeFullName.equals("boolean")) {
					CompilerStatic.errors.add(new Error(this, controlBlock.nameIndex(), controlBlock.nameIndex(), "Condition of control block must be boolean. : " + funcCall.typeFullName));
				}
			}
			}catch (Exception e) {
				if (Common_Settings.g_printsLog) e.printStackTrace();
				if (Common_Settings.g_printsLog) CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
			}
			
		}
	}
	
	/** return expression; 과 같이 expression의 타입을 찾아서 
	 * FindSpecialStatementParams.funcCall에 넣는다.
	 * @param coreThreadID */
	void findTypeOfSpecialStatements(Compiler compiler, int coreThreadID) {
		int i;		
		for (i=0; i<data.mlistOfSpecialStatement.count; i++) {
			FindSpecialStatementParams statement = (FindSpecialStatementParams) data.mlistOfSpecialStatement.getItem(i);
			String keyword = data.mBuffer.getItem(statement.kewordIndex()).str;
			CodeStringEx typeFullName = null;
			int startIndex = -1;
			int endIndex = -1;
			if (keyword.equals("return") || keyword.equals("throw")) {
				if (statement.kewordIndex()==331) {
					int a;
					a=0;
					a++;
				}
				if (statement.funcCall==null) {
					startIndex = statement.kewordIndex()+1;
					endIndex = statement.endIndex()-1;
					if (startIndex<=endIndex) {
						FindFuncCallParam funcCall = new FindFuncCallParam(this, startIndex, endIndex);
						funcCall.typeFullName = 
								Expression.getTypeOfExpression(this, funcCall, coreThreadID);
						statement.funcCall = funcCall;
						typeFullName = funcCall.typeFullName;
					}
				}
			}//if (keyword.equals("return") || keyword.equals("throw")) {
		}
	}
	
	public void getTypeOfAssignment(FindAssignStatementParams assign, int coreThreadID) {
		HighArray_CodeString src = this.data.mBuffer;
		try {
			
		if (assign.lValue.index()==242) {
			int a;
			a=0;
			a++;
		}
		FindFuncCallParam rValue = assign.lValue.rValue;
		
		String fullNameOfLValue = null;
		FindVarParams var = assign.lValue.varDecl;
		if (var==null) {
			return;
		}
		fullNameOfLValue = var.typeName;
		rValue.funcName = fullNameOfLValue; 
		
		if (fullNameOfLValue==null)
			fullNameOfLValue = var.getType(var.typeStartIndex(), var.typeEndIndex(), coreThreadID);
		if (fullNameOfLValue==null) return;
		
		if (assign.lValue.isArrayElement) {
			// colorButtons[k] = new Button(owner);에서 lValue는 colorButtons[k]이고 
			// 이것의 타입은 Control[]이다.
			fullNameOfLValue = Array.getArrayElementType(fullNameOfLValue);
		}
		
		
		if (assign.arrayInitializer==null) {			
			try{
			/*	// rValue의 타입을 정한다.
			typeFullName = getTypeOfExpression(src, rValue);
			if (typeFullName!=null)  {
				//assign.typeFullNameOfRValue = typeFullName.str;				
				rValue.typeFullName = typeFullName;
			}
			
			int startOfFindFuncCallParam = this.SkipBlank(src, false, assign.startIndex(), src.count-1);
			int endOfFindFuncCallParam = assign.endIndex();
			if (CompilerHelper.IsSeparator(src.getItem(endOfFindFuncCallParam))) {
				endOfFindFuncCallParam = this.SkipBlank(src, true, 0, endOfFindFuncCallParam-1);
			}
			
			// 대입연산자들(=,+=,-=등)을 포함하여 타입을 정한다.
			FindFuncCallParam funcCallParam = new FindFuncCallParam(this, startOfFindFuncCallParam, endOfFindFuncCallParam);
			CodeStringEx csFullNameOfLValue = new CodeStringEx(fullNameOfLValue);
			csFullNameOfLValue.typeFullName = fullNameOfLValue;
			
			ArrayListIReset listOfTypes = new ArrayListIReset(2);				
			listOfTypes.add(csFullNameOfLValue);
			csFullNameOfLValue.operandOrOperator = csFullNameOfLValue;
			listOfTypes.add(typeFullName);
			if (typeFullName!=null) {
				typeFullName.operandOrOperator = typeFullName;
			}
			CodeStringEx csOperator = new CodeStringEx(assign.operator);
			
			CodeStringEx type = CompilerHelper.getTypeOfOperator(this, funcCallParam, listOfTypes, csOperator);
			funcCallParam.typeFullName = type;
			*/
			
			
			int startOfFindFuncCallParam = CompilerHelper.SkipBlank(src, false, assign.startIndex(), src.count-1);
			int endOfFindFuncCallParam = assign.endIndex();
			if (CompilerHelper.IsSeparator(src.getItem(endOfFindFuncCallParam))) {
				endOfFindFuncCallParam = CompilerHelper.SkipBlank(src, true, 0, endOfFindFuncCallParam-1);
			}
			
			// 대입연산자들(=,+=,-=등)을 포함하여 타입을 정한다.
			FindFuncCallParam funcCallParam = new FindFuncCallParam(this, startOfFindFuncCallParam, endOfFindFuncCallParam);
			funcCallParam.typeFullName = Expression.getTypeOfExpression(this, funcCallParam, coreThreadID);
			
			assign.funcCallParam = funcCallParam;
			
			}catch(Exception e) {
				if (Common_Settings.g_printsLog) e.printStackTrace();
				if (Common_Settings.g_printsLog) CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
				Log.e("error", "lValue name : "+assign.lValue.name);
				CompilerHelper.printMessage(CommonGUI.textViewLogBird, "lValue name : "+assign.lValue.name);
				
			}
		}
		else { // 할당문이 배열초기화문이면
			ArrayInitializer.findTypesOfExpressionsOfArrayInitializer( this, assign, coreThreadID);
		}
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
			if (Common_Settings.g_printsLog) CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
			
		}
	}
	
	/** mlistOfAllAssignStatements에 대해서 모든 할당문들의 타입을 체크한다.
	 * @param endIndex 
	 * @param startIndex 
	 * @param allOrPart 
	 * @param coreThreadID */
	void findTypeOfAssignments( boolean allOrPart, int startIndex, int endIndex, int coreThreadID) {
		HighArray_CodeString src = this.data.mBuffer;
		int i;
		if (allOrPart) {
			for (i=0; i<data.mlistOfAllAssignStatements.count; i++) {
				FindAssignStatementParams assign = 
					(FindAssignStatementParams) data.mlistOfAllAssignStatements.getItem(i);
				//CommonGUI.showMessage(true, "i="+i+" "+assign);
				if (i==10) {
					int a;
					a=0;
					a++;
				}
				getTypeOfAssignment(assign, coreThreadID);
			}
		}
		else {
			for (i=0; i<data.mlistOfAllAssignStatements.count; i++) {
				FindAssignStatementParams assign = 
					(FindAssignStatementParams) data.mlistOfAllAssignStatements.getItem(i);
				if (startIndex<=assign.startIndex() && assign.endIndex()<=endIndex) {
					//CommonGUI.showMessage(true, "i="+i+" "+assign);
					if (i==3) {
						int a;
						a=0;
						a++;
					}
					getTypeOfAssignment(assign, coreThreadID);
				}
			}
		}
	}
	
	
	
	
	
	/**클래스의 AndSoOnStatements들을 찾고 넣고 정렬한다. 
	 * 클래스내부의 자식클래스, 함수, 초기화문장들도 포함한다.
	 * @param classParams : 처음 호출시 최상위 클래스, 재귀적 호출시는 해당 클래스*/
	void findAndSoOnStatementsOfClass( FindClassParams classParams) {
		HighArray_CodeString src = this.data.mBuffer;
		int i;
		for (i=0; i<classParams.childClasses.count; i++) {
			FindClassParams child = (FindClassParams) classParams.childClasses.getItem(i);
			// 자식 클래스부터 AndSoOnStatements들을 찾고 넣고 정렬한다. 재귀적 호출
			findAndSoOnStatementsOfClass( child);
		}
		
		// 자신의 문장리스트를 AndSoOnStatements들을 찾고 넣고 정렬한다.
		
		classParams.listOfStatements = findAndSoOnStatements( classParams.findBlockParams.startIndex()+1, 
				classParams.listOfStatements, classParams.findBlockParams.endIndex()-1);
				
		for (i=0; i<classParams.listOfFunctionParams.count; i++) {
			FindFunctionParams func = (FindFunctionParams) classParams.listOfFunctionParams.getItem(i);
			findAndSoOnStatementsOfFunction( func);
		}
		
	}
	
	/** 제어블록의 AndSoOnStatements들을 찾고 넣고 정렬한다. 재귀적 호출*/
	void findAndSoOnStatementsOfControlBlock( FindControlBlockParams controlBlock) {
		HighArray_CodeString src = this.data.mBuffer;
		int i;
		for (i=0; i<controlBlock.listOfStatements.count; i++) {
			FindStatementParams s = (FindStatementParams) controlBlock.listOfStatements.getItem(i);
			if (s instanceof FindControlBlockParams) {
				FindControlBlockParams c = (FindControlBlockParams) s;
				// 자식 제어블록부터 AndSoOnStatements들을 찾고 넣고 정렬한다.
				findAndSoOnStatementsOfControlBlock( c);
			}
		}
		
		// 자신의 문장리스트를 AndSoOnStatements들을 찾고 넣고 정렬한다.
		if (!controlBlock.isBlock
				/*controlBlock.findBlockParams==null || controlBlock.findBlockParams.startIndex()==-1 || controlBlock.findBlockParams.endIndex()==-1*/) {
			if (controlBlock.catOfControls.category==CategoryOfControls.Control_if) {
			}
			// 제어블록이 단문이면
			controlBlock.listOfStatements = findAndSoOnStatements( controlBlock.indexOfRightParenthesis()+1,
					controlBlock.listOfStatements, controlBlock.endIndex()-1);
		}
		else { // 제어블록이 복문이면
			controlBlock.listOfStatements = findAndSoOnStatements( controlBlock.findBlockParams.startIndex()+1,
					controlBlock.listOfStatements, controlBlock.findBlockParams.endIndex()-1);
		}
	}
	
	/** 함수의 AndSoOnStatements들을 찾고 넣고 정렬한다. 함수내부의 제어블록도 포함한다.*/
	void findAndSoOnStatementsOfFunction( FindFunctionParams func) {
		HighArray_CodeString src = this.data.mBuffer;
		if (func.isConstructor && func.findBlockParams==null) {
			// 컴파일러가 만드는 생성자이면 리턴한다.
			return;
		}
		
		int i;		
		for (i=0; i<func.listOfStatements.count; i++) {
			FindStatementParams s = (FindStatementParams) func.listOfStatements.getItem(i);
			if (s instanceof FindControlBlockParams) {
				FindControlBlockParams c = (FindControlBlockParams) s;
				findAndSoOnStatementsOfControlBlock( c);
			}
		}
		
		// 아규먼트는 여기에서 하지 않는다.
		func.listOfStatements = findAndSoOnStatements( func.findBlockParams.startIndex()+1, 
				func.listOfStatements, func.findBlockParams.endIndex()-1);
	}
	
	
	
	
	
	
	void makeScope(FindFunctionParams func, FindVarParams var) {
		if (func.listOfControlBlocks!=null) {
			int i;
			boolean r;
			for (i=0; i<func.listOfControlBlocks.count; i++) {
				FindControlBlockParams block = (FindControlBlockParams)func.listOfControlBlocks.getItem(i);
				r = isInScope(block, var);
				if (r) return;
			}
		}
		if (func.startIndex()<var.startIndex() && var.endIndex()<func.endIndex()) {
			var.startIndexOfScope = IndexForHighArray.indexRelative(var, data.mBuffer, var.startIndex());
			var.endIndexOfScope = IndexForHighArray.indexRelative(var, data.mBuffer, func.endIndex());
		}
		
	}
	
	/** 지역변수의 scope를 결정하기 위한 recursive 호출이다.*/
	private boolean isInScope(FindControlBlockParams block, FindVarParams var) {
		if (block.listOfControlBlocks==null) return false;  // 가장 끝 제어블록의 자식 제어블록리스트는 null이다.
		int i;
		boolean r;
		// 자신부터가 아니라 자식 제어블록부터 검사한다.
		for (i=0; i<block.listOfControlBlocks.count; i++) {
			FindControlBlockParams childBlock = (FindControlBlockParams)block.listOfControlBlocks.getItem(i);
			r = isInScope(childBlock, var);
			if (r) return true; 
			// 자식 제어블록내에서 선언되었으므로 자신의 것은 아니지만 
			// scope가 결정이 되었다는 의미이다.
		}
		if (block.startIndex()<var.startIndex() && var.endIndex()<block.endIndex()) {
			var.startIndexOfScope = IndexForHighArray.indexRelative(var, data.mBuffer, var.startIndex());
			var.endIndexOfScope = IndexForHighArray.indexRelative(var, data.mBuffer, block.findBlockParams.endIndex());
			return true;
		}
		return false;
	}
	
	
	HighArray_CodeChar getFuncCallParamTypePrint( HighArray_CodeChar r, CodeStringEx typeName) {
		r = r.concate(new HighArray_CodeChar("Param Type : "+typeName.str+"  ", Common_Settings.docuCommentColor));
		/*if (typeName.typeFullNameAfterOperation==null) {
			//r = r.concate(new CodeString(":" + typeName.typeFullName + "  ", Common_Settings.textColor));
		}
		else {
			//r = r.concate(new CodeString(":" + typeName.typeFullName, Common_Settings.textColor));
			r = r.concate(new CodeString("("+typeName.typeFullNameAfterOperation+")  ", Common_Settings.textColor));
		}
		if (typeName.value!=null) {
			r = r.concate(new CodeString("(value=" + typeName.value + ")  ", Common_Settings.varUseColor));
		}*/
		//r = r.concate(new CodeString(">  ", Common_Settings.varUseColor));
		return r;
	}
	
	
	/** findNode_varUse_makeString_postfix()에서 호출한다. 포스트픽스의 해당 토큰을 출력한다.
	 * @param r : input*/
	HighArray_CodeChar getPostfixPrint( HighArray_CodeChar r, CodeStringEx token) {
		HighArray_CodeString src = this.data.mBuffer;
		if (CompilerHelper.IsOperator(token)) {
			if (!token.isPlusOrMinusForOne) {
				r = r.concate(new HighArray_CodeChar(token.str, Common_Settings.varUseColor));
				if (token.typeFullNameAfterOperation==null) {
					r = r.concate(new HighArray_CodeChar(":" + token.typeFullName + "  ", Common_Settings.textColor));
				}
				else {
					r = r.concate(new HighArray_CodeChar(":" + token.typeFullName, Common_Settings.textColor));
					r = r.concate(new HighArray_CodeChar("("+token.typeFullNameAfterOperation+")  ", Common_Settings.textColor));
				}
			}
			else {
				r = r.concate(new HighArray_CodeChar(token.str, Common_Settings.funcUseColor));
				if (token.typeFullNameAfterOperation==null) {
					r = r.concate(new HighArray_CodeChar(":" + token.typeFullName + "  ", Common_Settings.textColor));
				}
				else {
					r = r.concate(new HighArray_CodeChar(":" + token.typeFullName, Common_Settings.textColor));
					r = r.concate(new HighArray_CodeChar("("+token.typeFullNameAfterOperation+")  ", Common_Settings.textColor));
				}
			}
		}
		else {
			if (token==null) {
				r = r.concate(new HighArray_CodeChar("null  ", Common_Settings.varUseColor));
				return r;
			}
			r = r.concate(new HighArray_CodeChar(token.str, Common_Settings.varUseColor));
			if (token.typeFullNameAfterOperation==null) {
				r = r.concate(new HighArray_CodeChar(":" + token.typeFullName + "  ", Common_Settings.textColor));
			}
			else {
				r = r.concate(new HighArray_CodeChar(":" + token.typeFullName, Common_Settings.textColor));
				r = r.concate(new HighArray_CodeChar("("+token.typeFullNameAfterOperation+")  ", Common_Settings.textColor));
			}
		}
		/*if (token.value!=null) {
			r = r.concate(new HighArray_CodeChar("(value=" + token.value + ")  ", Common_Settings.varUseColor));
		}*/
		return r;
	}
	
	
	
	/** findNode_varUse_makeString_postfix에서 호출한다.
	 * 수식이 중복되어 처리될수있으므로 인덱스값을 child의 마지막 위치 다음으로 바꿔준다.*/
	public int getIndex(CodeStringEx token, FindVarUseParams child, int k) {
		boolean isFuncCallAndArrayElement = false;
		if (child.funcDecl!=null && child.isArrayElement)
			isFuncCallAndArrayElement = true;
		
		if (child.funcDecl!=null && child.listOfFuncCallParams!=null) {
			if (child.listOfFuncCallParams.count>0) {
				FindFuncCallParam funcCall = (FindFuncCallParam) 
					child.listOfFuncCallParams.getItem(child.listOfFuncCallParams.count-1);
				int endIndexOfFuncCall = funcCall.endIndex()+1;
				k = CompilerStatic.getIndexInmListOfAllVarUses2(token.listOfVarUses, k, endIndexOfFuncCall, true);
				k--;
			}
		}
		if (child.isArrayElement && child.listOfArrayElementParams!=null) {
			FindFuncCallParam funcCall = (FindFuncCallParam) 
					child.listOfArrayElementParams.getItem(child.listOfArrayElementParams.count-1);
			int endIndexOfFuncCall = funcCall.endIndex()+1;
			k = CompilerStatic.getIndexInmListOfAllVarUses2(token.listOfVarUses, k, endIndexOfFuncCall, true);
			k--;										
		}
		if (child.typeCast!=null && child.typeCast.funcCall!=null) {
			FindFuncCallParam funcCall = (FindFuncCallParam) child.typeCast.funcCall;
			int endIndexOfFuncCall = funcCall.endIndex()+1;
			k = CompilerStatic.getIndexInmListOfAllVarUses2(token.listOfVarUses, k, endIndexOfFuncCall, true);
			k--;
		}
		if (isFuncCallAndArrayElement && child.listOfFuncCallParams.count>0) k++;
		return k;
	}
	
	
	
	Error getError(int indexInmBuffer) {
		int i;
		for (i=0; i<CompilerStatic.errors.count; i++) {
			Error err = (Error) CompilerStatic.errors.getItem(i);
			if (err.startIndex()<=indexInmBuffer && indexInmBuffer<=err.endIndex()) {
				return err;
			}
		}
		return null;		
	}
	
	
	
	
	ArrayListIReset getAllVarUses(HighArray_CodeString src, ArrayListIReset listOfAllVarUses, int startIndex, int endIndex) {
		int i;
		ArrayListIReset listOfVarUses = new ArrayListIReset(10);
		listOfVarUses.resizeInc = 10;
		for (i=0; i<listOfAllVarUses.count; i++) {
			FindVarUseParams varUse = (FindVarUseParams)listOfAllVarUses.getItem(i);
			if (startIndex<=varUse.index() && varUse.index()<=endIndex) {
				listOfVarUses.add(varUse);
			}
			else if (varUse.index()>endIndex) {
				break;
			}
		}
		return listOfVarUses;
	}
	
	String getNameSpaceElement(String path, int index) {
		int i;
		int[] indicesDots = new int[20];
		int k=0;
		for (i=0; i<path.length(); i++) {
			if (path.charAt(i)=='.') {
				indicesDots[k] = i;
				k++;
			}
		}
		
		String r=null;
		if (indicesDots.length>0) {
			if (1<=index && index<k) {
				r = path.substring(indicesDots[index-1]+1, indicesDots[index]);
			}
			else if (0==index) {
				r = path.substring(0, indicesDots[0]);
			}
			else if (index==k) {
				r = path.substring(indicesDots[k-1]+1, path.length());
			}
			else return null;			
		}
		else {
			r = path;
		}
		return r;
					
	}
	
	
	
	
	/** 다른 소스파일에서 인터페이스의 풀네임타입을 얻을때 호출한다.
	 *  Character.Subset에서 Character는 java.lang.Character이므로 여기에 Subset을 연결하여
	 *  java.lang.Character.Subset을 리턴한다. static이 아닌 getTypeOfImportLibrary() 등을 사용하므로
	 *  this 파라미터를 주의한다.
	 * @param coreThreadID 
	 * @param name : Character.Subset과 같은 이름, 아니면 com.gsoft.common.Compiler와 같은 이름.
	 * @return
	 */
	String getTypeName_full(Compiler compiler, int typeStartIndex, int typeEndIndex, int coreThreadID) {
		
		return Fullname.getFullNameType(compiler, typeStartIndex, typeEndIndex, coreThreadID);
	}
	
		
	
	boolean hasConstant(FindVarUseParams varUse) {
		int i;
		for (i=0; i<varUse.listOfFuncCallParams.count; i++) {
			FindFuncCallParam funcCall = (FindFuncCallParam) varUse.listOfFuncCallParams.getItem(i);
			CodeString str = Fullname.getFullName(data.mBuffer, funcCall.startIndex(), funcCall.endIndex());
			if (Number.IsNumber2(str)!=0)
				return true;
		}
		return false;
	}
	
	/** classParams(클래스)내에 varUse란 이름을 갖는 변수 또는 함수가 있는지 검사한다.*/
	boolean hasVarOrFunc( FindClassParams classParams, String varUse, boolean isVarOrFunc) {
		HighArray_CodeString src = this.data.mBuffer;
		int i;
		if (isVarOrFunc) {
			for (i=0; i<classParams.listOfVariableParams.count; i++) {
				FindVarParams var = (FindVarParams)classParams.listOfVariableParams.getItem(i);
				if (!var.isThis && !var.isSuper) { 
					if (src.getItem(var.varNameIndex()).equals(varUse)) return true;
				}
				else {
					if (varUse.equals("this")) return true;
					if (varUse.equals("super")) return true;
					return true;
				}
			}
		}
		else {
			for (i=0; i<classParams.listOfFunctionParams.count; i++) {
				FindFunctionParams func = (FindFunctionParams)classParams.listOfFunctionParams.getItem(i);
				if (src.getItem(func.functionNameIndex()).equals(varUse)) return true;
			}
		}
		return false;
	}
	
		
		
	
	/** 해당 클래스 내에서(findMemberVarUsingOutofClass 대조)
	 *  변수선언(var)(멤버,지역)으로 해당클래스의 변수사용리스트(FindClassParams.hashtableOfAllVarUsesForVarHashedByName)에서 모두 찾는다.
	 *  
	 *  멤버변수선언과 멤버변수사용은 full name을 얻어서 비교한다.
	 *  지역변수선언은 full name이 아니므로 varName이고, 
		지역변수사용은 멤버변수와 겹칠수 있으므로 full name을 얻어서 비교한다.
		
	 * @param classParams : 해당 클래스 (변수를 선언한 클래스), inputVarToSuitableClassOrFunc에서 호출되므로.
	 * @param isLocal : true이면 멤버변수찾기(functionParams==null), false이면 로컬변수찾기(classParams==null)
	 * @param var : 변수선언 */	
	void findAllLocalVarUsing_sub( 
			FindClassParams classParams, FindFunctionParams functionParams,   
			FindVarParams var, /*ArrayListIReset listOfAllVarUses,*/ boolean isLocal, String varName) {
		HighArray_CodeString src = this.data.mBuffer;
		
		if (classParams!=null && classParams.name.equals("com.gsoft.common.gui.Button") && varName.equals("bounds")) {
		}
		if (classParams!=null && classParams.name.equals("com.gsoft.common.gui.EditText") && varName.equals("RedoBuffer")) {
		}
		if (classParams!=null && classParams.name.equals("com.gsoft.common.gui.EditText") && varName.equals("selectP2")) {
		}
		// 현재클래스는 현재 파일에 정의된 것이고 상속클래스는 현재 파일에 정의되지 않을수도 있으므로
		// 상속클래스의 필드를 찾을때는 src와 var.varNameIndex()이 불일치할 수도 있으므로 
		// var.varNameIndex()을 쓸때는 주의해야 하고 var.fieldName을 사용해야 한다.
		// varUse.index()는 상관이 없다.
		try {
			int i;
			//String varName = src.getItem(var.varNameIndex()).toString();
			
			
			//for (i=0; i<classParams.listOfAllVarUses.count; i++) {
			int len = functionParams.listOfAllVarUsesForVar.getCount();
			for (i=0; i<len; i++) {
				FindVarUseParams varUse = (FindVarUseParams)functionParams.listOfAllVarUsesForVar.getItem(i);
				int index = varUse.index();
				String varUseName = varUse.originName;
				//String varUseName = varUse.name;
				if (varUseName.equals("buffer[i]")) {
				}
				//if (block.startIndex()<index && index<block.endIndex()) { // 변수의 scope가 맞아야 한다.
				if (var.startIndexOfScope()<=index && index<=var.endIndexOfScope()) { // 변수의 scope가 맞아야 한다.
					// 지역변수선언은 full name이 아니므로 varName이고, 
					// 지역변수사용은 멤버변수와 겹칠수 있으므로 full name을 얻어서 비교한다.
					//String varUseFullName = getFullName(src, classParams, varUse, true);
					if (varName.equals(varUseName)) { // 변수선언과 이름이 같고
					//if (varName.equals(varUseFullName)) { // 변수선언과 이름이 같고
						if (varName.equals("s")) {
						}
						int dot = CompilerHelper.SkipBlank(src, true, 0, index-1);
						if (dot>=0 && src.getItem(dot).equals(".")) {
							int parent = CompilerHelper.SkipBlank(src, true, 0, dot-1);
							if (parent>=0 && src.getItem(parent).equals("this")) {									
							}
						}
						else { // .이 없어야 한다.
							//if (var.startIndex()OfScope<=varUse.index() && varUse.index()<=var.endIndex()OfScope) {
								// 지역변수의 scope검사
								varUse.isLocal = true;
								varUse.varDecl = var;
								var.addVarUseToListOfVarUses(varUse);
							//}
						}
						if (varUseName.equals("widthOfCharsInPage")) {
						}
						
					}//if (varName.equals(varUseName)) { // 변수선언과 이름이 같고
				}//if (functionParams.startIndex()<index && index<functionParams.endIndex()) {
				else if (index > functionParams.endIndex()) {
					break;
				}
			}//for (i=0; i<classParams.listOfAllVarUses.count; i++) {
		} catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
			if (Common_Settings.g_printsLog) CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
		}
	}
	
	
	
	/** 네임스페이스에서 꼭대기 변수를 찾는다.*/
	void findAllLocalVarUsing_caller_Local( 
			HighArray listOfAllMemberVarDeclarations, HighArray listOfAllLocalVarDeclarations) {
		HighArray_CodeString src = this.data.mBuffer;
		int i;
		int len = listOfAllLocalVarDeclarations.getCount();
		for (i=0; i<len; i++) {
			FindVarParams var = (FindVarParams) listOfAllLocalVarDeclarations.getItem(i);
			if (var.varNameIndex()!=-1 && src.getItem(var.varNameIndex()).equals("Common_Settings.backColor")) {
			}
			Block block = CompilerStatic.getParent((Block)var.parent);
			if (block instanceof FindFunctionParams) {
				//var.isMemberOrLocal = false; // 로컬변수
				//findAllVarUsingAndChangeMemberDeclColor(src, null, (FindFunctionParams)block, var, true);
				this.findAllLocalVarUsing_sub( null, (FindFunctionParams)block, var, true, var.fieldName);
			}
		}
	}
	
	
	/** setOnTouchListener(new View.OnTouchListener() {}); 에서 View.OnTouchListener()는 
		 * 이벤트 핸들러 클래스이므로 {의 인덱스를 리턴한다.*/
	int isEventHandlerClass(HighArray_CodeString src, FindFuncCallParam funcCall) {
		int i;
		for (i=funcCall.startIndex(); i<=funcCall.endIndex(); i++) {
			CodeString str = src.getItem(i);
			if (CompilerHelper.IsBlank(str) || CompilerHelper.IsComment(str)) continue;
			if (str.equals("{")) {
				return i;
			}
		}
		return -1;
	}
	
		
	
	
	
	/** 함수호출의 파라미터가 함수, 덧셈, 뺄셈 등 operator일 경우, full name를 포함한 
	 * 모든 경우에 파라미터의 타입을 정해준다. 파라미터가 네임스페이스가 있는 함수일 수도 있으므로 
	 * 함수호출의 매개변수당 한번씩 findMemberUsesUsingNamespace_sub 을 recursive call 한다.
	 * @param src : src having funcCall
	 * @param listOfFuncCallParams : ','로 구분된 파라미터 리스트, FindFuncCallParam[]
	 * @param indexInmListOfAllVarUses : varUse(해당함수이름)의 mListOfAllVarUses에서의 인덱스
	 */
	boolean setParamsTypeOfListOfFuncCallParams(HighArray_CodeString src, 
			ArrayListIReset listOfFuncCallParams, int coreThreadID) {
		if (listOfFuncCallParams==null) return false;
		int i;
		CodeStringEx typeName = null;
		
		for (i=0; i<listOfFuncCallParams.count; i++) {
			FindFuncCallParam funcCallParam = (FindFuncCallParam)listOfFuncCallParams.getItem(i);
			if (funcCallParam.startIndex()==269) {
			}
			if (funcCallParam.funcName.equals("FindExpression")) {
			}
			if (funcCallParam.typeFullName==null) {
				CodeString param = Fullname.getFullName(src, funcCallParam.startIndex(), funcCallParam.endIndex());
				
				typeName = Expression.getTypeOfExpression(this, funcCallParam, coreThreadID);
				// 함수인자가 숫자상수일때 "int"로 변환할지 여부를 확인한다.
				int numberType = Number.IsNumber2(param);
				if (numberType!=0) {
					if (Number.convertNumberConstantToIntegerInFunctionParameter(param, numberType)) {
						typeName.typeFullNameAfterOperation = "int";
						//typeName.typeFullName = "int";
						typeName.changeStr("int");
					}
				}
				
				if (typeName!=null && (typeName.str==null || typeName.str.equals(""))) {
					funcCallParam.typeFullName = null;
					return false;
				}
				else {
					funcCallParam.typeFullName = typeName;
				}
			}
			//if (typeName!=null) {
			if (typeName!=null && (typeName.str==null || typeName.str.equals(""))) {
				//funcCallParam.classParams = getFindClassParams(Compiler.mlistOfAllClassesHashed, Compiler.mlistOfAllClasses, typeName.str);
				funcCallParam.classParams = Loader.loadClass(this, typeName.str, coreThreadID);
			}
		}
		return true;
		
	}
	
	
	
	
	/** 자신의 class와 child class들에서 function이 이미 존재하는지 찾는다.*/
	public boolean Exists(FindClassParams findClassParams, int functionNameIndex) {
		int i;
		if (findClassParams==null) return false;
		ArrayListIReset list = findClassParams.listOfFunctionParams;
		for (i=0; i<list.count; i++) {
			FindFunctionParams fp = (FindFunctionParams) list.getItem(i);
			if (fp.functionNameIndex()==functionNameIndex) return true;
		}
		if (findClassParams.childClasses!=null) {
			for (i=0; i<findClassParams.childClasses.count; i++) {
				boolean r = Exists((FindClassParams)(findClassParams.childClasses.getItem(i)), 
						functionNameIndex);
				if (r) return true;
			}
		}
		return false;
	}
	  
    
    
    
    
    /** block을 처음으로 감싸는 클래스나 함수를 얻는다. 
	 * 예를들어 제어블럭에서 getParent를 호출하면 이 블럭을 처음으로 감싸는 함수를 얻는다.*/
	public static Block getParent(Block block) {
		return CompilerStatic.getParent(block);
	}
	
	/** mlistOfAllVarUses의 해시리스트에서 varUseName과 indexOfVarUseInMBuffer으로 해당 varUse를 검색한다.
	 * @return : varUse가 검색되지않으면 null을 리턴, 그렇지 않으면 varUse 리턴 */
	public static FindVarUseParams getVarUseWithIndex(Hashtable2_String hashListOfAllVarUses, String varUseName, int indexOfVarUseInMBuffer) {
		return CompilerStatic.getVarUseWithIndex(hashListOfAllVarUses, varUseName, indexOfVarUseInMBuffer);
	}
	
	
	/** type이 아니면 -1을 리턴, type이면 index를 리턴, 
     * array이면 역방향일 경우 배열의 시작인덱스를, 순방향일 경우 ]의 인덱스를 리턴
     * 포인터이면 역방향일 경우 타입의 시작인덱스를 리턴
     * @param template : result(out), 템플릿이 중첩될 경우 가장 바깥 템플릿, 즉 parent
     * @param index : isReverse가 true일경우 타입의 endIndex(), isReverse가 false일경우 타입의 startIndex()*/
    public ReturnOfIsType IsType(HighArray_CodeString src, boolean isReverse, int index) {
    	return compilerStack.IsType(src, isReverse, index);
    }
    
    /** mlistOfAllVarUses에서 시작인덱스(startIindexInmListOfAllVarUses)에서부터 검색을 시작하여 
	 * indexInmBuffer을 만날 때까지 mlistOfAllVarUses의 마지막 인덱스를 리턴한다. 못찾으면 -1을 리턴
	 * @param isStartOrEnd : true일때, 즉 start일때는 varUse.index()>=indexInmBuffer 조건이 최초로 성립할때이고,
	 * false일때, 즉 end일때는 varUse.index()==indexInmBuffer시는 현재varUse의 인덱스, 
	 * 그렇지않으면 이전varUse의 인덱스를 리턴한다.*/
	public static int getIndexInmListOfAllVarUses(HighArray_CodeString src, HighArray mlistOfAllVarUses, 
			int startIindexInmListOfAllVarUses, 
			int indexInmBuffer, boolean isStartOrEnd) {
		return CompilerStatic.getIndexInmListOfAllVarUses(src, mlistOfAllVarUses, startIindexInmListOfAllVarUses, indexInmBuffer, isStartOrEnd);
	}
	
	/** varUse 다음에 '=', '+=', '-=', '*=', '/=', '%=' 가 있으면 lValue라고 판단한다. 
	 * @return '='의 인덱스를 리턴, lValue가 아니면 -1을 리턴*/
	public int IsLValue(HighArray_CodeString src, FindVarUseParams varUse) {
		return compilerStack.IsLValue(src, varUse);
		
	}
	
	
	
	
	/** 변수선언 외에 변수사용도 찾는다. 
	 * 변수선언의 경우 endIndex는 세미콜론의 인덱스이다.
	 * @param findVarParams : out 
	 * @param index : if (IsIdentifier(cstr) || CompilerHelper.IsConstant(cstr) ||
        		IsDefaultType(cstr))   { // 식별자, 상수, 타입(타입캐스트)의 인덱스
	 * @param oldTypeIndex : int a, b;의 경우처럼 타입선언 b를 찾을때 이전 호출에서 ,로 끝날경우 
	 * int 타입의 인덱스
	 * @param coreThreadID 
	 * @return OldTypeIndex : int a, b;의 경우처럼 타입선언 a를 찾은후 ,로 끝나는 경우 
	 * 다음 호출을 위해서 int 타입의 인덱스를 리턴한다.*/
	public ReturnOfFindVarDecl FindVarDeclarationsAndVarUses(
			int index, OldTypeIndex oldTypeIndex, int coreThreadID)
	{
		HighArray_CodeString src = this.data.mBuffer;
		return compilerStack.FindVarDeclarationsAndVarUses(src, index, oldTypeIndex, coreThreadID);
	}
	
	public void FindFunction( FindClassParams parent, FindFunctionParams findFunctionParams, 
			int indexOfLeftParenthesis, int coreThreadID)
	{
		HighArray_CodeString src = this.data.mBuffer;
		compilerStack.FindFunction(src, parent, findFunctionParams, indexOfLeftParenthesis, coreThreadID);
	}
	
	public boolean hasAccessModifier(FindVarParams var,
			FindFunctionParams func) {
		
		return this.compilerStack.hasAccessModifier(var, func);
	}

	public DocuComment FindDocuComment( int startIndex,
			int endIndex) {
		HighArray_CodeString src = this.data.mBuffer;
		
		return this.compilerStack.FindDocuComment(src, startIndex, endIndex);
	}
	
	/** 중괄호를 사용자가 터치시 나타나는 툴팁을 위한 호출이다.*/
	public HighArray_CodeChar findParenthesis( int indexInmBuffer) {
		HighArray_CodeString src = this.data.mBuffer;
		int i;
		FindBlockParams block=null;
		for (i=0; i<data.mlistOfBlocks.count; i++) {
			block = (FindBlockParams)data.mlistOfBlocks.getItem(i);
			if (block.startIndex()==indexInmBuffer) {
				if (block.endIndex()!=-1) {
					if (block.categoryOfBlock!=null)
						return new HighArray_CodeChar(indexInmBuffer + " " + block.categoryOfBlock.toString()+" "+block.blockName + " starts", Common_Settings.textColor);
					else return new HighArray_CodeChar(indexInmBuffer + " " + "EndIndex:" + block.endIndex() + " starts", Common_Settings.textColor);
				}
				else {
					return new HighArray_CodeChar(indexInmBuffer + " " + "Not pair", Common_Settings.textColor);
				}
			}
			else if (block.endIndex()==indexInmBuffer) {
				if (block.categoryOfBlock!=null)
					return new HighArray_CodeChar(indexInmBuffer + " " + block.categoryOfBlock.toString()+" "+block.blockName + " ends", Common_Settings.textColor);
				else return new HighArray_CodeChar(indexInmBuffer + " " + "StartIndex:" + block.startIndex() + " ends", Common_Settings.textColor);
			} 
		}
		return null;
	}
	
	
	/**virtual method*/
	public void changeBounds() {
		try {
			throw new Exception("virtual method");
		} catch (Exception e) {
			
			if (Common_Settings.g_printsLog) e.printStackTrace();
		}
	}
	/**virtual method*/
	public void setBackColor(int backColor) {	
		try {
			throw new Exception("virtual method");
		} catch (Exception e) {
			
			if (Common_Settings.g_printsLog) e.printStackTrace();
		}
	}
	/**virtual method*/
	public HighArray_CodeChar findNode( int indexInmBuffer) {
		
		try {
			throw new Exception("virtual method");
		} catch (Exception e) {
			
			if (Common_Settings.g_printsLog) e.printStackTrace();
		}
		return null;
	}
		
	/**virtual method*/
	public static void createTextViewLogBird(boolean b) {
		
		try {
			throw new Exception("virtual method");
		} catch (Exception e) {
			
			if (Common_Settings.g_printsLog) e.printStackTrace();
		}
	}
		
	
	/**virtual method*/
	public FindStatementParams findLocationWhenNotPaired( ArrayListIReset listOfClasses, 
			int indexInmBuffer) {
		try {
			throw new Exception("virtual method");
		} catch (Exception e) {
			
			if (Common_Settings.g_printsLog) e.printStackTrace();
		}
		return null;
	}

	/**virtual method*/
	public FindStatementParams findLocation( ArrayListIReset mlistOfClass, int indexInmBuffer) {
		try {
			throw new Exception("virtual method");
		} catch (Exception e) {
			
			if (Common_Settings.g_printsLog) e.printStackTrace();
		}
		return null;
		
	}
	
}