package com.gsoft.common.compiler;

import java.io.File;

import com.gsoft.common.Common_Settings;
import com.gsoft.common.FileHelper;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.Compiler_types.ModeAllOrUpdate;
import com.gsoft.common.compiler.Compiler_types_Base.Error;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListIReset;
import com.gsoft.common.util.hash.Hashtable2_FindClassParams;
import com.gsoft.common.util.hash.Hashtable2_String;

import com.gsoft.common.compiler.CompilerData;
import com.gsoft.common.compiler.CompilerStatic;
import com.gsoft.common.compiler.Compiler;


public class ClassCache {
	public static class ClassCacheList extends ArrayListIReset {

		public ClassCacheList(int initMaxLength) {
			super(initMaxLength);
			
		}
		
		/**Returns a cloned ClassCacheList*/
		public Object clone() {
			ClassCacheList listCloned = new ClassCacheList(count);
			int i;
			for (i=0; i<count; i++) {
				listCloned.add(getItem(i));
			}
			return listCloned;
		}
		
		synchronized public void add(FindClassParams classParams) {
			super.add(classParams);
		}
		
		/**When deleting or renaming any files in a project, then remove classes.
		 * Refer to Builder.build(fileList)*/
		public ClassCacheList removeClassesInFileThatDoesNotExist() {
			int i;
			ClassCacheList newList = new ClassCacheList(this.count); 
			for (i=0; i<this.count; i++) {
				FindClassParams classParams = (FindClassParams) this.getItem(i);
				if (classParams==null) continue;
				String filename = classParams.compiler.data.filename;
				File file = new File(filename);
				if (file.exists()) {
					newList.add(classParams);
				}
			}
			return newList;
		}
		
		/** delete a class with filePath. Not erase class.
		 * Refer to editText_Compiler.saveDialog_handler()*/
		public void deleteClass(String filePath) {
			int i;
			for (i=0; i<this.count; i++) {
				FindClassParams classParams = (FindClassParams) this.getItem(i);
				if (classParams==null) continue;
				//if (classParams.loadWayOfFindClassParams==LoadWayOfFindClassParams.Start2) {
					String filename = classParams.compiler.data.filename;
					if (filename.equals(filePath)) {						
						this.list[i] = null;
					}
				//}
			}
		}
		
		/** delete a class with filePath. Not erase class.
		 * Refer to editText_Compiler.saveDialog_handler()*/
		public void deleteClassWithFullClassName(String fullClassName) {
			int i;
			for (i=0; i<this.count; i++) {
				FindClassParams classParams = (FindClassParams) this.getItem(i);
				if (classParams==null) continue;
				//if (classParams.loadWayOfFindClassParams==LoadWayOfFindClassParams.Start2) {
					if (classParams.name.equals(fullClassName)) {
						this.list[i] = null;
					}
				//}
			}
		}
		
		
	}// public static class ClassCacheList extends ArrayListIReset {
	
	
	/**If modeAllOrUpdate is ModeAllOrUpdate.All, calls putToClassCache(), 
	 * If modeAllOrUpdate is ModeAllOrUpdate.Update, calls updateToClassCache().
	 * @param compiler
	 * @param modeAllOrUpdate
	 * @param coreThreadID
	 */
	public static void setClassCache(Compiler compiler, ModeAllOrUpdate modeAllOrUpdate, int coreThreadID) {
		int i;
		CompilerData data = compiler.data;
		// 외부라이브러리처럼 클래스의 name을 fullname으로 정해준다.
		// mlistOfAllClasses이 static이므로 mlistOfAllDefinedClasses안의 클래스들을 대상으로 한다.
		// 즉, 여러 파일을 load할 경우 src가 달라지는 문제가 발생할 수 있다.
		for (i=0; i<data.mlistOfAllDefinedClasses.count; i++) {
			FindClassParams c = (FindClassParams) data.mlistOfAllDefinedClasses.getItem(i);
			if (modeAllOrUpdate==ModeAllOrUpdate.All) {
				ClassCache.putToClassCache(c, coreThreadID);
			}
			else { // Update
				ClassCache.updateToClassCache(c, coreThreadID);
			}
		}
	}
	
	/**If classCache don't have c,then Adds c.
	 * If classCache have c,then makes an duplicate error.*/ 
	public static void putToClassCache(FindClassParams c, int coreThreadID) {		
		int j;
		for (j=0; j<CompilerStatic.mlistOfAllClasses[coreThreadID].count; j++) {
			FindClassParams classParams = (FindClassParams) CompilerStatic.mlistOfAllClasses[coreThreadID].getItem(j);
			if (classParams==null) continue;
			
			if (classParams.name.equals(c.name)) {
				String ext1 = FileHelper.getExt(classParams.compiler.data.filename);
				String ext2 = FileHelper.getExt(c.compiler.data.filename);
				
				// Test1.java에 Test.A와 Test2.java에도 Test.A가 있으면 에러를 낸다.
				if (ext1.equals(".java") && ext2.equals(".java")) {
					CompilerStatic.errors.add(new Error(classParams.compiler, classParams.classNameIndex(), classParams.classNameIndex(), 
							"Duplicate class name"));
					CompilerStatic.errors.add(new Error(c.compiler, c.classNameIndex(), c.classNameIndex(), 
							"Duplicate class name"));
				}
				return;
			}
		}
		// 새로 추가한다.
		ClassCache.addClassToClassCache(c, coreThreadID);
	}
	
	/**If classCache have c,then replace with c. If not, then adds c.*/
	public static void updateToClassCache(FindClassParams c, int coreThreadID) {
		int j;
		for (j=0; j<CompilerStatic.mlistOfAllClasses[coreThreadID].count; j++) {
			FindClassParams classParams = (FindClassParams) CompilerStatic.mlistOfAllClasses[coreThreadID].getItem(j);
			if (classParams==null) continue;
			if (classParams.name.equals(c.name)) {
				if (classParams.compiler.data.filename.equals(c.compiler.data.filename)) {
					ClassCache.replaceClassInClassCache(j, c, coreThreadID);							
					return;
				}
			}
		}
		ClassCache.addClassToClassCache(c, coreThreadID);
	}
	
	/**makes mlistOfAllClasses and mlistOfAllClassesHashed a number of numOfCores*/
	public static void makeClassCachesForMultiCore(int numOfCores) {
		CompilerStatic.mlistOfAllClasses = new ClassCacheList[numOfCores];
		CompilerStatic.mlistOfAllClassesHashed = new Hashtable2_FindClassParams[numOfCores];
		int i;
		for (i=0; i<numOfCores; i++) {
			CompilerStatic.mlistOfAllClasses[i] = new ClassCacheList(20);
			CompilerStatic.mlistOfAllClassesHashed[i] = new Hashtable2_FindClassParams(50, 20);
		}
	}
	
	static void replaceClassInClassCache(int indexInmlistOfAllClasses, FindClassParams c, int coreThreadID) {
		CompilerStatic.mlistOfAllClasses[coreThreadID].list[indexInmlistOfAllClasses] = c;
		CompilerStatic.mlistOfAllClassesHashed[coreThreadID].replace(c.name, c);
	}
	
	static void addClassToClassCache(FindClassParams c, int coreThreadID) {
		CompilerStatic.mlistOfAllClasses[coreThreadID].add(c);
		CompilerStatic.mlistOfAllClassesHashed[coreThreadID].input(c.name, c);
	}
	
	/**Not erase classes.
	 * @param coreThreadID */
	public static void deleteClassesHavingCompiler(Compiler compiler, int coreThreadID) {
		int i;
		try {
			for (i=0; i<compiler.data.mlistOfAllDefinedClasses.count; i++) {
				FindClassParams c = (FindClassParams) compiler.data.mlistOfAllDefinedClasses.getItem(i);
				deleteClassInClassCache(c, coreThreadID);
			}
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
		}
	}
	
	/**Not erase classes.
	 * @param coreThreadID */
	public static void deleteClassInClassCache(FindClassParams c, int coreThreadID) {
		CompilerStatic.mlistOfAllClasses[coreThreadID].deleteClassWithFullClassName(c.name);
		CompilerStatic.mlistOfAllClassesHashed[coreThreadID].deleteData(c.name);
	}
	
	public static class ReturnOfcloneClassCache {
		public ClassCacheList[] clonedmlistOfAllClasses;
		public Hashtable2_FindClassParams[] clonedmlistOfAllClassesHashed;
	}
	public static ReturnOfcloneClassCache cloneClassCache() {
		ReturnOfcloneClassCache r = new ReturnOfcloneClassCache();
		r.clonedmlistOfAllClasses = new ClassCacheList[CompilerStatic.mlistOfAllClasses.length];
		r.clonedmlistOfAllClassesHashed = new Hashtable2_FindClassParams[CompilerStatic.mlistOfAllClasses.length];
		
		int i;
		for (i=0; i<CompilerStatic.mlistOfAllClasses.length; i++) {
			r.clonedmlistOfAllClasses[i] = (ClassCacheList) CompilerStatic.mlistOfAllClasses[i].clone();
			r.clonedmlistOfAllClassesHashed[i] = (Hashtable2_FindClassParams) CompilerStatic.mlistOfAllClassesHashed[i].clone();
		}
		return r;
	}
	
	
	public static void restoreClassCache(ReturnOfcloneClassCache cloned/*int numOfCores*/) {
		CompilerStatic.mlistOfAllClasses = cloned.clonedmlistOfAllClasses;
		CompilerStatic.mlistOfAllClassesHashed = cloned.clonedmlistOfAllClassesHashed;
		
		/*// Num of classCaches changes to 1
		 * if (numOfCores!=1) {
			ClassCacheList mlistOfAllClasses = new ClassCacheList(20);
			Hashtable2_FindClassParams mlistOfAllClassesHashed = new Hashtable2_FindClassParams(50, 20);
			
			int i, j;
			for (i=0; i<numOfCores; i++) {
				for (j=0; j<CompilerStatic.mlistOfAllClasses[i].count; j++) {
					FindClassParams c = (FindClassParams) CompilerStatic.mlistOfAllClasses[i].getItem(j);
					if (ClassCache.getFindClassParams(mlistOfAllClassesHashed, c.name)==null) {
						mlistOfAllClasses.add(c);
						mlistOfAllClassesHashed.input(c.name, c);
					}
				}
			}
			
			CompilerStatic.mlistOfAllClasses = new ClassCacheList[0];
			CompilerStatic.mlistOfAllClassesHashed = new Hashtable2_FindClassParams[0];
			
			CompilerStatic.mlistOfAllClasses[0] = mlistOfAllClasses;
			CompilerStatic.mlistOfAllClassesHashed[0] = mlistOfAllClassesHashed;
		}*/
	}
	
	public static void resetClassCache() {
		int i;
		for (i=0; i<CompilerStatic.mlistOfAllClasses.length; i++) {
			CompilerStatic.mlistOfAllClasses[i].reset2();
			CompilerStatic.mlistOfAllClassesHashed[i].reset();
		}
	}
	
	
	/** CommonGUI_SettingsDialog.settings.usesClassCache 이 false 이면 
	 * 클래스 캐시와 캐시에 들어있는 FindClassParams와 Compiler 등을 제거한다.
	 * @param coreThreadID */
	public static void destroyClassCache(int coreThreadID) {
		//if (!Common_Settings.settings.usesClassCache) {
			CompilerStatic.mlistOfAllClasses[coreThreadID].destroy();
			CompilerStatic.mlistOfAllClassesHashed[coreThreadID].destroy();
			System.gc();
		//}		
	}
	
	/** listOfClasses에서 name을 갖는 클래스를 검색한다.
	 * name은 fullname이든 short name이든 상관은 없으나 
	 * short name일 경우 틀린 classParams가 검색될 위험성이 있다. 
	 * 현재 short name으로 이 함수를 호출하는 경우는 
	 * 같은 파일 내에서 정의된 클래스에 대해서만 한다. */
	public static FindClassParams getFindClassParams(Hashtable2_String listOfClassesHashed, 
			ArrayListIReset listOfClasses, String name, int coreThreadID) {
		if (name==null) return null;
		if (name.contains(".")) {  // 풀네임이면
			return ClassCache.getFindClassParams(listOfClassesHashed, name);
		}
		else {  // short name			
			return null;
		}
		//return null;
	}
	
	/*public static FindClassParams getFindClassParams2(ClassCacheList mlistOfAllClasses, String filePath, int coreThreadID) {
		//synchronized (SynchronizedObjects.lockForMultiThreadBuild) {
			int i;
			for (i=0; i<mlistOfAllClasses.count; i++) {
				FindClassParams item = (FindClassParams) mlistOfAllClasses.getItem(i);
				if (item==null) continue;
				if (item.compiler!=null && item.compiler.data.filename!=null) {
					if (item.compiler.data.filename.equals(filePath)) return item;
				}
			}
		//}
		return null;
	}*/
	
	public static FindClassParams getFindClassParams(ClassCacheList listOfClasses, String fullClassName) {
		//synchronized (SynchronizedObjects.lockForMultiThreadBuild) {
			int i;
			for (i=0; i<listOfClasses.count; i++) {
				FindClassParams item = (FindClassParams) listOfClasses.getItem(i);
				if (item==null) continue;
				if (item.name!=null) {
					if (item.name.equals(fullClassName)) return item;
				}
			}
		//}
		return null;
	}
	
	/** @param fullClassNameIncludingTemplateExceptArray : 클래스가 템플릿 클래스일 경우 템플릿 타입 이름을 포함하고 배열은 포함하지 않은 클래스 풀 이름이다.*/
	public static /*synchronized*/ 
	FindClassParams getFindClassParams(Hashtable2_String listOfClassesHashed, String fullClassNameIncludingTemplateExceptArray) {
		//synchronized (SynchronizedObjects.lockForMultiThreadBuild) {
			FindClassParams item = (FindClassParams) listOfClassesHashed.getData(fullClassNameIncludingTemplateExceptArray, false);
			return item;
		//}
	}
	
	public static /*synchronized*/ 
	ArrayList getAllFindClassParams(Hashtable2_String listOfClassesHashed, String fullClassNameIncludingTemplateExceptArray) {
		//synchronized (SynchronizedObjects.lockForMultiThreadBuild) {
			return (ArrayList) listOfClassesHashed.getData(fullClassNameIncludingTemplateExceptArray, true);
		//}
	}
		
	
	/** find a compiler in class cache
	 * @param coreThreadID */
	public static Compiler findCompiler(String filePath, int coreThreadID) {
		//synchronized (SynchronizedObjects.lockForMultiThreadBuild) {
		int i;
		for (i=0; i<CompilerStatic.mlistOfAllClasses[coreThreadID].count; i++) {
			FindClassParams item = (FindClassParams) CompilerStatic.mlistOfAllClasses[coreThreadID].getItem(i);
			if (item==null) continue;
			if (item.compiler!=null && item.compiler.data.filename!=null) {
				if (item.compiler.data.filename.equals(filePath)) return item.compiler;
			}
		}
		//}
		return null;
	}
	
	
}
