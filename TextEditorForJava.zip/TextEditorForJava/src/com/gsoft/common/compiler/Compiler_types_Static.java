package com.gsoft.common.compiler;

public class Compiler_types_Static {
	static String[] KeywordsOfHtml = {
		"html", "head", "body", "title", "link",
		
		"a", "address", "applet", "area", "audio", "b", "br", 
		"caption", "div", "col", "dt", "hr", "form", "iframe",
		"img", "input", "label", "li", "menu", "meta", "object",
		"option", "p", "script", "select", "strong", "style",
		"table", "td", "textarea", "th", "tr", "u", "var", "video"
	};
	
	static String[] KeywordsOfC = {
		// Modifiers
		"ifdef", "ifndef", "endif", "typedef", "define", "include",
		
		"private", "protected", "public", 
        "const", "extern", 
          
        "class", "struct", "enum", "union", 
        "new", "this", "operator",  

        "sizeof",  // 타입 정보
        
        "NULL", "FALSE", "TRUE", 

        "switch", "break", "for", "return", "if", "do", "else",  
        "try", "case", "goto", "continue", "while", 
        "throw", "finally", "catch", "default"                                   

        

        
	};
	
	static String[] KeywordsOfCSharp = {
		// Modifiers
        "private", "protected", "public", "final", "volatile", "sealed", "internal", 
        "static", "readonly", "unsafe", "extern", "abstract", "virtual", 
        "event", "const", "override", "default",

        "null", "false", "true", 

        "switch", "break", "for", "return", "if", "do", "else", "in", 
        "try", "case", "goto", "continue", "while", 
        "throw", "finally", "catch", "foreach", "default",                                    

        "struct", "explicit", "class", "ref", "enum", "namespace", 
        "implicit", "using", "new", "delegate", "interface", 
        "base", "this", "operator", "params", "super", 

        "typeof", "sizeof", "is", "as", // 타입 정보

        "checked", "unchecked", // 오버플로 예외 컨트롤

        "out", "fixed", "lock", "stackalloc"
	};
	
	static String[] KeywordsOfJava = {   
			
			/*"float", "int", "uint", "char", "short", "long", "void", "ulong", 
            "byte", "bool", "sbyte", "decimal", "object", "ushort", "string", 
            "double", "boolean",
            
            */
		
		
        // Modifiers
        "private", "protected", "public", "final", "volatile",  
        "static", "extern", "abstract",  
        "const", "default", "native",

        "null", "false", "true", 

        "switch", "break", "for", "return", "if", "do", "else",  
        "try", "case", "goto", "continue", "while", 
        "throw", "throws", "finally", "catch", "foreach", "synchronized",                                    

        "class", "enum", "package", "import",  
        "new", "interface", "extends", "implements",
        "super", "this",  

        "typeof", "sizeof", "as", "instanceof"// 타입 정보
        
        
        
        /*"float", "int", "char", "short", "long", "void",  
        "byte", "double", "boolean"*/
        
        
	};
	
	
	static String[] AccessModifiersOfC = {		 
		"private", "protected", "public", 
        "const", "extern"
	};
	
	static String[] AccessModifiersOfCSharp = {
		"private", "protected", "public", "final", "volatile", "sealed", "internal", 
        "static", "readonly", "unsafe", "extern", "abstract", "virtual", 
        "event", "const", "override", "default"
	};
	
	static String[] AccessModifiersOfJava = {
		/*"private", "protected", "public", "final", "volatile", "sealed", "internal", 
        "static", "readonly", "unsafe", "extern", "abstract", "virtual", 
        "event", "const", "override", "default"*/
        
        "private", "protected", "public", "final", "volatile",  
        "static", "extern", "abstract",  
        "const", "default", "synchronized", "enum", "interface", 
        "native"
	};
	
	static String[] TypesOfC = {
		"float", "int", "char", "short", "long", "void",  
        "byte", "bool", "unsigned", "signed", 
        "double"
	};
	
	static String[] TypesOfCSharp = {
		"float", "int", "uint", "char", "short", "long", "void", "ulong", 
        "byte", "bool", "sbyte", "decimal", "object", "ushort", "string", 
        "double", "boolean"
	};
	
	static String[] TypesOfJava = {
		/*"float", "int", "uint", "char", "short", "long", "void", "ulong", 
        "byte", "bool", "sbyte", "decimal", "object", "ushort", "string", 
        "double", "boolean"*/
		
		"float", "int", "char", "short", "long", "void",  
        "byte", "double", "boolean"/*, "Object", "String"*/
	};
	
	
	/** 자주 사용하는 java 패키지의 클래스들을 모아 놓은 배열이다. 
	 * 여기에 있는 클래스들을 스레드를 활용하여 loadClass()로 읽어 캐시에
	 * 등록하여 성능을 높인다.
	 */
	public static String[] glistOfJavaClassesForThread = {
		// java.lang 패키지
		"java.lang.Boolean", "java.lang.Byte", "java.lang.Character", "java.lang.Class", "java.lang.Double",
		"java.lang.Error", "java.lang.Exception", "java.lang.Float", "java.lang.Integer", "java.lang.Long",
		"java.lang.Math", "java.lang.Object", "java.lang.Runtime", "java.lang.Short", "java.lang.String",
		"java.lang.StringBuffer", "java.lang.StringBuilder", "java.lang.System", "java.lang.Thread",
		"java.lang.VirtualMachineError", 
		
		// java.io 패키지
		"java.io.BufferedInputStream", "java.io.BufferedOutputStream", "java.io.BufferedReader",
		"java.io.BufferedWriter", "java.io.File", "java.io.FileInputStream", "java.io.FileOutputStream",
		"java.io.FileNotFoundException", "java.io.InputStream", "java.io.InputStreamReader",
		"java.io.IOException", "java.io.Reader", "java.io.StringReader", "java.io.StringWriter", 
		"java.io.Writer"
		
	};
}
