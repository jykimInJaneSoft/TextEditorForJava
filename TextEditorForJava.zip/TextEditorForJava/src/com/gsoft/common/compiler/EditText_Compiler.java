package com.gsoft.common.compiler;

import janesoft.common.MemoryManager;

import java.io.File;
import java.io.IOException;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Point;
import android.graphics.RectF;

import com.gsoft.common.Code.CodeChar;
import com.gsoft.common.Code.CodeString;
import com.gsoft.common.Code.CodeStringType;
import com.gsoft.common.CommonGUI;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.Events.MotionEvent;
import com.gsoft.common.FileHelper;
import com.gsoft.common.FileHelper.LanguageAndTextFormat;
import com.gsoft.common.IO;
import com.gsoft.common.IO_types.ReturnOfReadString;
import com.gsoft.common.IO_types.TextFormat;
import com.gsoft.common.Sizing.Rectangle;
import com.gsoft.common.Sizing.RectangleF;
import com.gsoft.common.Sizing.SizeF;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.Compiler_types.FindControlBlockParams;
import com.gsoft.common.compiler.Compiler_types.FindFunctionParams;
import com.gsoft.common.compiler.Compiler_types.FindVarParams;
import com.gsoft.common.compiler.Compiler_types.FindVarUseParams;
import com.gsoft.common.compiler.Compiler_types.Language;
import com.gsoft.common.compiler.Compiler_types.LoadWayOfFindClassParams;
import com.gsoft.common.compiler.Compiler_types_Base.FindPackageParams;
import com.gsoft.common.compiler.Compiler_types_Special.ErrorList;
import com.gsoft.common.compiler.bytecode.ByteCode_Types;
import com.gsoft.common.compiler.bytecode.InstructionSet;
import com.gsoft.common.compiler.debug.BreakPoint;
import com.gsoft.common.compiler.gui.CurPathText;
import com.gsoft.common.compiler.gui.MDITabList;
import com.gsoft.common.compiler.gui.MenuClassAndMemberList;
import com.gsoft.common.compiler.gui.MenuClassAndMemberListWhenInputtingDot;
import com.gsoft.common.compiler.gui.MenuProblemList;
import com.gsoft.common.compiler.gui.MenuProblemList_EditText;
import com.gsoft.common.compiler.util.Builder;
import com.gsoft.common.compiler.util.Builder.FileListToCompile_Mode;
import com.gsoft.common.compiler.util.Builder.RunOrDebug;
import com.gsoft.common.compiler.util.NewJavaClassDialog;
import com.gsoft.common.compiler.util.NewJavaFile;
import com.gsoft.common.compiler.util.NewProjectDialog;
import com.gsoft.common.gui.Buttons.Button;
import com.gsoft.common.gui.Control;
import com.gsoft.common.gui.FileDialog;
import com.gsoft.common.gui.FileDialog.Category;
import com.gsoft.common.gui.IntegrationKeyboard;
import com.gsoft.common.gui.IntegrationKeyboard.Hangul;
import com.gsoft.common.gui.IntegrationKeyboard.Mode;
import com.gsoft.common.gui.LoggingScrollable;
import com.gsoft.common.gui.SaveDialog;
import com.gsoft.common.gui.SettingsDialog;
import com.gsoft.common.gui.edittext.Edit;
import com.gsoft.common.gui.edittext.Edit.ScrollMode;
import com.gsoft.common.gui.edittext.EditText;
import com.gsoft.common.gui.edittext.FunctionOfEditText;
import com.gsoft.common.gui.edittext.UndoOfEditText;
import com.gsoft.common.util.Array;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListInt;
import com.gsoft.common.util.HighArray_CodeChar;
import com.gsoft.common.util.HighArray_char;
import com.gsoft.dependent.ClassFileRunner;

import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.CompilerInterface;
import com.gsoft.common.compiler.CompilerCache;
import com.gsoft.common.compiler.ClassCache;
import com.gsoft.common.compiler.Compiler_types;
import com.gsoft.common.compiler.CompilerStatic;
import com.gsoft.common.compiler.Member;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.Checker;
import com.gsoft.common.compiler.Update;
import com.gsoft.common.compiler.HighArray_CodeString;

public class EditText_Compiler extends EditText {
	
	private float scaleOfButtonBuildAll_Y = 0.035f;
	
	float scaleOfGapY = 0.01f;
	
	private Button buttonNewProject;
	private Button buttonOpenProject;
	private Button buttonCloseProject;	
	private Button buttonNewClass;
	
	Button buttonBuild;
	private Button buttonBuildAll;	
	Button buttonRun;
	Button buttonRun1;
	Button buttonDebug;
	Button buttonCancelBuild;
	
	
	Button buttonToggleBreakpoint;
	Button buttonRemoveAllBreakpoints;
	
	Button buttonOpenDecl;
	public Button buttonProblems;
	public Button buttonProblemsAll;
	private Button buttonInput;
	private Button buttonConsole;
	private Button buttonDebugView;
	private Button buttonUsedMemory;
	
	public Language lang_backup;
	public String filename_backup;
	public TextFormat format_backup;

	private Paint paint2 = new Paint();


	
	
	/**콘솔출력을 위한 파일을 지운다.*/
	public boolean lastOperation() {
		ClassFileRunner.lastOperation();
		
		ArrayList modifiedCompiler = CompilerCache.isProjectModified();
		if (modifiedCompiler.count!=0) {
			this.dialogState = SaveDialogState.Destroy;
			this.saveDialog.Text = "Do you want to save ";
			this.saveDialog.setText(CompilerCache.toString_isProjectModified(modifiedCompiler) + "?");
			this.saveDialog.open(this, true);
			Control.view.invalidate();
			return false;
		}
		return true;
	}
	
	
	public EditText_Compiler(boolean hasToolbarAndMenuFontSize,
			boolean isDockingOfToolbarFlexiable, Object owner, String name,
			Rectangle paramBounds, float fontSize, boolean isSingleLine,
			CodeString text, ScrollMode scrollMode, int backColor) {
		super(hasToolbarAndMenuFontSize, isDockingOfToolbarFlexiable, owner, name,
				paramBounds, fontSize, isSingleLine, text, scrollMode, backColor);
		
		CommonGUI.editText_compiler = this;
		
		this.createSaveDialog(false);
		
		createEditTextCurPath(null, true);
		CurPathText.setCurPathTextPlusProjectName("");
		
		createButtonNewProjectAndOpenProjectAndCloseProjectAndNewClass(false);
	}
	
	/**  자바를 로딩시 editText_compiler 상단에 있는 경로 바를 말한다. 
	 * 처음으로 자바 파일을 열때 경로바를 생성하고 editText의 바운드를 바꾼다.
	 * @param createOrDispose : true이면 경로바를 생성하고 false이면 제거한다.*/
	public static void createEditTextCurPath(Compiler compiler, boolean createOrDispose) {
		
		CommonGUI.editText_compiler.showsCurPath(createOrDispose);
		
		if (compiler!=null) {
			CurPathText.setCurPathTextPlusProjectName(compiler.data.filename);
		}
		else if (Common_Settings.projectName!=null) {
			CurPathText.setCurPathTextPlusProjectName(Common_Settings.projectName);
		}
	}
	
	/*public void newDocument() {
		this.compiler = null;
		this.initialize();
	}*/
	
	/** resetDocument()를 호출하여 문서가 바뀔때마다 메모리를 해제한다.*/
	public void initialize() {
		resetDocument();
		super.initialize();
		
		compiler = null;
		CurPathText.setCurPathTextPlusProjectName("");
	}
	
	
	
	public void changeBounds(Rectangle newBounds) {
		super.changeBounds(newBounds);
		if (compiler!=null) {
			compiler.changeBounds();
			
			this.createButtonNewProjectAndOpenProjectAndCloseProjectAndNewClass(true);
			this.createButtonBuildAndRunAndProblems(true);
			CompilerInterface.createMenuProblemList_EditText(true);
		}
		if (this.showsMDITabList) {
			if (mDITabList==null) {
				mDITabList = new MDITabList(boundsOfMDITabList);
			}
			else {
				mDITabList.changeBounds(boundsOfMDITabList);
			}
		}
		if (this.getShowsCurPath()) {
			if (CurPathText.editTextCurPath==null) {
				CurPathText.createEditTextCurPath(compiler, boundsOfEditTextCurPath);
			}
			else {
				CurPathText.editTextCurPath.changeBounds(boundsOfEditTextCurPath);
			}
		}
		if (this.saveDialog!=null) {
			this.createSaveDialog(true);
		}
		if (this.newProjectDialog!=null) {
			this.createNewProjectDialog(true);
		}
		if (this.newJavaClassDialog!=null) {
			this.createNewJavaClassDialog(true);
		}
		
		Builder.createMenuBuildTypes(true);
	}
	
	/** lang이 java일 때만 Build와 Run이 가능하도록 한다.*/
	boolean isBuildAndRunEnable() {
		if (this.lang==Compiler_types.Language.Java)
			return true;
		return false;
	}
	
	@Override
    public boolean onTouch(MotionEvent event, SizeF scaleFactor) {
    	boolean r=false;
    	if (event.actionCode==MotionEvent.ActionDown || event.actionCode==MotionEvent.ActionDoubleClicked) {
    		if (this.buttonNewProject!=null) {
    			r = this.buttonNewProject.onTouch(event, scaleFactor);
    			if (r) return true;
    		}
    		if (this.buttonOpenProject!=null) {
    			r = this.buttonOpenProject.onTouch(event, scaleFactor);
    			if (r) return true;
    		}
    		if (this.buttonCloseProject!=null) {
    			r = this.buttonCloseProject.onTouch(event, scaleFactor);
    			if (r) return true;
    		}
    		if (this.buttonNewClass!=null) {
    			r = this.buttonNewClass.onTouch(event, scaleFactor);
    			if (r) return true;
    		}
    		if (this.isBuildAndRunEnable()) {    			
	    		if (this.buttonBuild!=null) {
	    			r = this.buttonBuild.onTouch(event, scaleFactor);
	    			if (r) return true;
	    		}
	    		if (this.buttonBuildAll!=null) {
	    			r = this.buttonBuildAll.onTouch(event, scaleFactor);
	    			if (r) return true;
	    		}
	    		if (this.buttonRun!=null) {
	    			r = this.buttonRun.onTouch(event, scaleFactor);
	    			if (r) return true;
	    		}
	    		if (this.buttonRun1!=null) {
	    			r = this.buttonRun1.onTouch(event, scaleFactor);
	    			if (r) return true;
	    		}
	    		if (this.buttonDebug!=null) {
	    			r = this.buttonDebug.onTouch(event, scaleFactor);
	    			if (r) return true;
	    		}
	    		if (this.buttonCancelBuild!=null) {
	    			r = this.buttonCancelBuild.onTouch(event, scaleFactor);
	    			if (r) return true;
	    		}
	    		if (this.buttonToggleBreakpoint!=null) {
	    			r = this.buttonToggleBreakpoint.onTouch(event, scaleFactor);
	    			if (r) return true;
	    		}
	    		if (this.buttonRemoveAllBreakpoints!=null) {
	    			r = this.buttonRemoveAllBreakpoints.onTouch(event, scaleFactor);
	    			if (r) return true;
	    		}
	    		if (this.buttonOpenDecl!=null) {
	    			r = this.buttonOpenDecl.onTouch(event, scaleFactor);
	    			if (r) return true;
	    		}
	    		if (this.buttonProblems!=null) {
	    			r = this.buttonProblems.onTouch(event, scaleFactor);
	    			if (r) return true;
	    		}
	    		if (this.buttonProblemsAll!=null) {
	    			r = this.buttonProblemsAll.onTouch(event, scaleFactor);
	    			if (r) return true;
	    		}
	    		if (this.buttonInput!=null) {
	    			r = this.buttonInput.onTouch(event, scaleFactor);
	    			if (r) return true;
	    		}
	    		if (this.buttonConsole!=null) {
	    			r = this.buttonConsole.onTouch(event, scaleFactor);
	    			if (r) return true;
	    		}
	    		if (this.buttonDebugView!=null) {
	    			r = this.buttonDebugView.onTouch(event, scaleFactor);
	    			if (r) return true;
	    		}
	    		if (this.buttonUsedMemory!=null) {
	    			r = this.buttonUsedMemory.onTouch(event, scaleFactor);
	    			if (r) return true;
	    		}
    		}
    		
    		
	    	r = super.onTouch(event, scaleFactor);
	    	if (!r) {
	    		return false;
	    	}
	    	else {
	    		//this.setCurPathText(cursorPos.x, cursorPos.y);
	    		return true;
	    	}
    	}
    	else if (event.actionCode==MotionEvent.ActionMove || event.actionCode==MotionEvent.ActionUp) {
    		if (event.actionCode==MotionEvent.ActionUp) {
    		}
    		
			// drag시작이 scrollBar이면 scrollBar가, editText라면 editText가 핸들링
			if (Control.capturedControl==this) {// 영역검사를 하지않고 영역을 벗어나더라도 자신이 핸들링한다.
				if (event.actionCode==MotionEvent.ActionMove) {
					if (this.compiler!=null) {
						if (CompilerStatic.textViewExpressionTreeAndMessage!=null) 
							CompilerStatic.textViewExpressionTreeAndMessage.setHides(true);
		    		}
				}
				onTouchEvent(this, event);
				return true;
			}
			
						
		}
    	return false;
    }
	
	public void toolbar_Listener(Object sender, String buttonName) {
		if (buttonName.equals("S")) {	// 툴바버튼
			FunctionOfEditText.toolbar_Listener(this, sender, buttonName);
			return;
		}
		else if (buttonName.equals("M")) {
			ScrollMode scrollMode=this.scrollMode; 
			if (scrollMode==ScrollMode.VScroll) {
				scrollMode = ScrollMode.Both;
			}
			else {
				scrollMode = ScrollMode.VScroll;
			}
			this.setScrollMode(scrollMode);
			return;
		}
		else if (buttonName.equals("FN")) {
			FunctionOfEditText.toolbar_Listener(this, sender, buttonName);
		}
		else if (buttonName.equals("O")) {
			if (compiler==null && CommonGUI.textViewLogBird!=null) {
				//Control.textViewLogBird.setHides(false);
				CommonGUI.textViewLogBird.open(true);
			}
			else if (compiler!=null && compiler.data.menuClassAndMemberList!=null) {
				compiler.data.menuClassAndMemberList.open(true);
				compiler.data.menuClassAndMemberList.setOnTouchListener(this);
				//Compiler.menuProblemList_EditText.setOnTouchListener(this);
				if (CompilerStatic.menuProblemList_EditText!=null) {
					CompilerStatic.menuProblemList_EditText.setOnTouchListener(this);
				}
			}
			else if (compiler!=null && compiler.data.menuClassAndMemberList==null) {
				if (CommonGUI.textViewLogBird!=null) {
					CommonGUI.textViewLogBird.open(true);
				}
			}
		}
		else if (buttonName.equals("U")) {
			/*if (lang!=null) {
				if (isModified) {
					//String input = getText();
					boolean hasLogMessage = false;
					//if (Control.loggingForMessageBox.getHides()) {
						Control.loggingForMessageBox.setText(true, "loading...", false);
						Control.loggingForMessageBox.setHides(false);
						hasLogMessage = true;
					//}
					ThreadSetIsProgramCode thread = new ThreadSetIsProgramCode(hasLogMessage, true);
					thread.start();
				}
				else {
					//if (preProcessor!=null) {
						compiler.menuClassList.open(true);
						compiler.menuClassList.setOnTouchListener(this);
					//}
				}
			}*/
		}
		else if (buttonName.equals("R/W")) {
			if (toolbar.buttons[4].getIsSelected()) {
				this.isReadOnly = true;
			}
			else {
				this.isReadOnly = false;
			}
		}
	}
	
	/** .class 파일에서 커서 좌표의 워드를 찾는다.*/
	CodeString findWordInClassFile(int cursorPosX, int cursorPosY) {		
		CodeString line = this.textArray[cursorPosY];
		int left, right;
		int i;
		for (i=cursorPosX; i>=0; i--) {
			CodeChar c = line.charAt(i);
			if (c.c==' ' || c.c=='\b' || c.c=='\t' || c.c=='\r' || c.c=='\n') break;
		}
		//if (i<0) i = 0;
		left = i;
		
		for (i=cursorPosX; i<line.count; i++) {
			CodeChar c = line.charAt(i);
			if (c.c==' ' || c.c=='\b' || c.c=='\t' || c.c=='\r' || c.c=='\n') break;
		}
		//if (i>=line.count) i = line.count-1;
		right = i;
		
		CodeString r = null;
		if (left!=right) {
			r = line.substring(left+1, right);
			if (r.count>0 && r.charAt(r.count-1).c==';')
				r = r.substring(0, r.count-1);
		}
		return r;
	}
	
	
	
	
	
	public HighArray_CodeChar getCompileOutput() {
		if (compiler!=null) return compiler.data.strOutput;
		return null;
	}
		
	public void setBackColor(int backColor) {
		super.setBackColor(backColor);
		
		Common_Settings.setBackColor(backColor);
		
		if (compiler!=null) {
			compiler.setBackColor(backColor);
		}
				
		if (Common_Settings.CurrentSystem.equals(Common_Settings.CurrentSystemIsJava) &&
				Common_Settings.settings.isTripleBuffering)  { 
			this.drawToImage(mCanvas);
		}
	}
	
	/** Destroy CompilerCache, ClassCache and compiler. call gc <br>
	 * 프로젝트가 바뀔때마다 클래스 캐시와 compiler 가 사용하는 메모리를 해제한다.
	 * 클래스 캐시가 모두 해제될때 compiler 가 사용하는 메모리도 모두 해제된다.
	 * NewProject, OpenProject와 closeProject에서 호출된다.*/
	void destroyProject() {
		CompilerCache.destroy();
		
		//Loader.mlistOfLoadClassFromSrc_onlyInterface.destroy();
		//CompilerStatic.mlistOfLoadClassFromSrc_onlyInterface_failed.destroy();
		//PathClassLoader.listOfClassesToFailLoading.destroy();
		ClassCache.destroyClassCache(0);
		
		if (this.compiler!=null) {
			this.compiler.destroy();
			this.compiler = null;			
		}
		if (this.mDITabList!=null) {
			this.mDITabList.closeAllTabButtons();
		}
		CompilerStatic.errors.destroy();
		
		this.initialize();
		
		System.gc();
	}
	
	/** 문서가 바뀔때마다 settings.usesClassCache 가 false 이면 클래스 캐시와 compiler 가 사용하는 메모리를 해제한다.
	 * 클래스 캐시가 모두 해제될때 compiler 가 사용하는 메모리도 모두 해제된다.*/
	void resetDocument() {
		// 문서가 바뀔때마다 compiler 가 사용하는 메모리를 해제한다.
		//Common_Settings.settings.usesClassCache = true;
		
		if (!Common_Settings.settings.usesClassCache) {
			
		}
		
		BreakPoint.lineNumberShowingArrow = null;
		
	}
	
	public void setIsModified(boolean isModified) {
		super.setIsModified(isModified);
		if (compiler!=null) {
			compiler.data.isModified = isModified;
			this.mDITabList.setModifiedSymbol(this.compiler.data.filename, isModified);
		}
	}
	/*
	public void setCursorPosX(int cursorPosX) {
		super.setCursorPosX(cursorPosX);
		if (compiler!=null) {
			compiler.data.cursorPos.x = cursorPosX;
		}
	}
	
	public void setCursorPos(Point cursorPos) {
		super.setCursorPos(cursorPos);
		if (compiler!=null) {
			compiler.data.cursorPos.x = cursorPos.x;
			compiler.data.cursorPos.y = cursorPos.y;
		}
	}
	
	public void setCursorPos(int cursorPosX, int cursorPosY) {
		super.setCursorPos(cursorPosX, cursorPosY);
		if (compiler!=null) {
			compiler.data.cursorPos.x = cursorPosX;
			compiler.data.cursorPos.y = cursorPosY;
		}
	}*/
	
	String filePath_closeCompilerDocument;
	
	public void closeCompilerDocument(String filePath) {
		Compiler compilerLocal = CompilerCache.findCompiler(filePath);
		if (compilerLocal!=null && compilerLocal.data.isModified) {
			filePath_closeCompilerDocument = filePath;
			this.dialogState = SaveDialogState.CloseDocument;
			this.saveDialog.Text = "Do you want to save ";
			ArrayList list = new ArrayList(1);
			list.add(compilerLocal);
			this.saveDialog.setText(CompilerCache.toString_isProjectModified(list) + "?");
			this.saveDialog.open(this, true);
			
			//this.setIsModified(false);
		}
		else {
			this.mDITabList.closeTabButton_sub(filePath);
		}
	}
	
	/**editText_compiler의 compiler가 바뀌는데 주의한다.
	 * CompilerDocument를 load하고 setText()까지 하여 문서를 연다.
	 * 프로젝트에는 단 하나의 editText_compiler가 존재하고 열려있는 문서(editText_compiler.compiler)도 단 하나이다.
	 * 탭버튼을 누를 경우에도 이 함수를 통해서 다시 연다.*/
	public void openCompilerDocument(String filePath) {		
		Control.view.postInvalidate();
		
		LoggingScrollable.longOperation = true;
		
		saveMDIDatasToCompilerData(compiler);
		
		this.initialize();
		
				
		// Compiler in editText_compiler changes.
		boolean result = this.loadCompilerDocument(filePath);
		
		if (result) {
			//HighArray_CodeChar text = this.getCompileOutput(lang); 
			//this.setText(0, text);
			loadMDIDatasFromCompilerData(compiler);
		}
		
		LoggingScrollable.longOperation = false;
	}
	
	void saveMDIDatasToCompilerData(Compiler compiler) {
		if (compiler!=null) {
			compiler.data.isModified = this.getIsModified();
			
			compiler.data.lineNumberShowingArrow = BreakPoint.lineNumberShowingArrow;
			
			compiler.data.cursorPos.x = cursorPos.x;
			compiler.data.cursorPos.y = cursorPos.y;
			
			compiler.data.textArray = this.textArray;			
			compiler.data.vScrollPos = this.vScrollPos;			
			compiler.data.widthOfhScrollPos = this.widthOfhScrollPos;
					
			compiler.data.numOfLines = this.numOfLines;
			
			compiler.data.isSelecting = this.isSelecting;
			compiler.data.selectLenY = this.selectLenY;
			compiler.data.selectIndices = this.selectIndices;
			compiler.data.selectIndicesCount = this.selectIndicesCount;
			
			compiler.data.isFound = this.isFound;
			compiler.data.findLenY = this.findLenY;
			compiler.data.findIndices = this.findIndices;
			compiler.data.findIndicesCount = this.findIndicesCount;
			
			compiler.data.undoBuffer = this.undoBuffer;
			compiler.data.redoBuffer = this.redoBuffer;
			
			 compiler.data.isReadOnly = this.isReadOnly;
		}
	}
	
	void loadMDIDatasFromCompilerData(Compiler compiler) {
		if (compiler!=null) {
			super.setIsModified(compiler.data.isModified);			
			BreakPoint.lineNumberShowingArrow = compiler.data.lineNumberShowingArrow;
			
			cursorPos.x = compiler.data.cursorPos.x;
			cursorPos.y = compiler.data.cursorPos.y;
			
			this.textArray = compiler.data.textArray;
			this.vScrollPos = compiler.data.vScrollPos;			
			this.widthOfhScrollPos = compiler.data.widthOfhScrollPos;
			this.numOfLines = compiler.data.numOfLines;
			
			this.isSelecting = compiler.data.isSelecting;
			this.selectLenY = compiler.data.selectLenY;
			this.selectIndices = compiler.data.selectIndices;
			this.selectIndicesCount = compiler.data.selectIndicesCount;
			
			this.isFound = compiler.data.isFound;
			this.findLenY = compiler.data.findLenY;
			this.findIndices = compiler.data.findIndices;
			this.findIndicesCount = compiler.data.findIndicesCount;
							
			this.undoBuffer = compiler.data.undoBuffer;
			this.redoBuffer = compiler.data.redoBuffer;
			
			this.isReadOnly = compiler.data.isReadOnly;
			
			if (this.numOfLines!=0) {
				// When opening a document in CompilerCache or ClassCache.				
				setVScrollBar();			
				setHScrollBar();
			}
			else {
				// When opening new document
				HighArray_CodeChar text = this.getCompileOutput(); 
				this.setText(0, text);
				
				compiler.data.textArray = this.textArray;
				compiler.data.numOfLines = this.numOfLines;
			}
		}
	}
	
	/**  자바를 로딩시 editText_compiler 상단에 있는 TabList 바를 말한다. 
	 * 처음으로 자바 파일을 열때 탭바를 생성하고 editText의 바운드를 바꾼다.
	 * @param createOrDispose : true이면 경로바를 생성하고 false이면 제거한다.*/
	public void createMDITabList(boolean createOrDispose) {
		showsMDITabList(createOrDispose);
	}
		
	/** 문서가 바뀔때마다 compiler 가 사용하는 메모리를 해제한다. 
	 * Compiler.start2() 호출시 settings.usesClassCache 가 false 이면 클래스 캐시를 모두 해제한다.
	 * 클래스 캐시가 모두 해제될때 compiler 가 사용하는 메모리도 모두 해제된다.
	 * editText_compiler의 compiler가 바뀌는데 주의한다.
	 * 프로젝트에는 단 하나의 editText_compiler가 존재하고 열려있는 문서(editText_compiler.compiler)도 단 하나이다.*/
	boolean loadCompilerDocument(String filePath) {		
	
		try {
			LanguageAndTextFormat languageAndTextFormat = FileHelper.getLanguageAndTextFormat(filePath);
			//if (languageAndTextFormat==null) return false;
			
			if (languageAndTextFormat==null || languageAndTextFormat.lang==null) {
				createMDITabList(true);
				if (mDITabList!=null) {
					mDITabList.addTabButtonAndFocusTabIfNotExist(filePath);
				}
				//Compiler cachedCompiler = CompilerCache.findCompiler(filePath);
				
				//if (cachedCompiler==null) {
				
				// /mnt/sdcard/janeSoft/project/ProjectName/temp/Console 과 같은 텍스트 파일을 읽을 경우
				// 계속 내용이 바뀌게 되어 CompilerCache에 넣지 않고 필요할 때마다 파일을 읽는다.
					this.compiler = new CompilerInterface();
					String text = IO.readString(filePath).result.getItems();
					HighArray_CodeChar arr = new HighArray_CodeChar(100); 
					arr.add(new CodeString(text, this.textColor));
					this.compiler.data.filename = filePath;
					this.compiler.data.strOutput = arr;
					super.setIsModified(false);
					
					createEditTextCurPath(compiler, true);
					CurPathText.setCurPathTextPlusProjectName(filePath);
					
					//CompilerCache.add(this.compiler);
				/*}
				else {
					this.compiler = cachedCompiler;
				}*/
				
				return true;
			}
			else {			
				this.lang = languageAndTextFormat.lang;
				TextFormat format = languageAndTextFormat.format;
				
				if (lang!=null) {
					createMDITabList(true);
					if (mDITabList!=null) {
						mDITabList.addTabButtonAndFocusTabIfNotExist(filePath);
					}
					
					Compiler cachedCompiler = null;
					Compiler cachedCompilerInClassCache = null;
				
					FileDialog fileDialog = CommonGUI.fileDialog;
					fileDialog.menuTextFormat.selectAll(false);
					if (format==TextFormat.UTF_8) {
						Button button = fileDialog.menuTextFormat.findByName("UTF-8");
						button.Select(true);
					}
					else if (format==TextFormat.UTF_16) {
						Button button = fileDialog.menuTextFormat.findByName("UTF-16");
						button.Select(true);
					}
					else if (format==TextFormat.MS949_Korean) {
						Button button = fileDialog.menuTextFormat.findByName("MS-949");
						button.Select(true);
					}
					
					if (lang==Compiler_types.Language.Java) {
						this.createButtonBuildAndRunAndProblems(false);
						
						cachedCompiler = CompilerCache.findCompiler(filePath);
						
						if (cachedCompiler==null) {
							cachedCompilerInClassCache = ClassCache.findCompiler(filePath, 0);
							// 캐시에 없을 경우
							if (cachedCompilerInClassCache!=null) { 
								this.compiler = cachedCompilerInClassCache;
								((CompilerInterface)cachedCompilerInClassCache).start2_WhenUsingClassCache(filePath, 0);
							}
							else {								
								compiler = new CompilerInterface();
								// 클래스 캐시가 갱신된다.
								((CompilerInterface)compiler).start2(Common_Settings.backColor, filePath, 0);
							}
						}
						else {						
							this.compiler = cachedCompiler;
							((CompilerInterface)this.compiler).start2_WhenUsingCompilerCache(filePath, 0);
						}
						
						createEditTextCurPath(compiler, true);
						CurPathText.setCurPathTextPlusProjectName(filePath);
						
						Update.createThreadTimerAndStart();
						
						
					}// if (lang==Compiler_types.Language.Java) {
					else if (lang==Compiler_types.Language.Html) {
						this.isReadOnly = true;
						this.createButtonBuildAndRunAndProblems(false);
						
						this.compiler = new CompilerInterface();
						((CompilerInterface)this.compiler).start_HTML(backColor, filePath, 0);
					}
					else if (lang==Compiler_types.Language.Class) {
						/*cachedCompiler = CompilerCache.findCompiler(filePath);
						if (cachedCompiler!=null) {
							this.compiler = cachedCompiler;
							((CompilerInterface)this.compiler).start2_WhenUsingCompilerCache(filePath, 0);
						}
						else {
							this.isReadOnly = true;
							CompilerInterface.start2_PathClassLoader(backColor, filePath, 0);
						}*/
						this.isReadOnly = true;
						CompilerInterface.start2_PathClassLoader(backColor, filePath, 0);
					}
					else if (lang==Compiler_types.Language.C) {
						cachedCompiler = CompilerCache.findCompiler(filePath);
						if (cachedCompiler!=null) {
							this.compiler = cachedCompiler;
							//((CompilerInterface)this.compiler).start2_WhenUsingCompilerCache(filePath, 0);
						}
						else {
							this.compiler = new CompilerInterface();
							((CompilerInterface)this.compiler).start_C(backColor, filePath, 0);
						}
					}
					super.setIsModified(false);
					//System.gc();
					return true;
				}
			} // if (lang!=null) {
			return false;
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
			CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
			return false;
		}finally {
						
		}
	}
	
	/** Writes an open file*/
	public void write(TextFormat format) throws IOException {
		if (this.compiler!=null) {
			if (this.getIsModified()) {
				this.saveModifiedCompiler(compiler);
			}
		}
	}
	
	/** Writes all modified files*/
	public void writeAllFiles() throws IOException {
		ArrayList modifiedCompilerList = null;
		modifiedCompilerList = CompilerCache.isProjectModified();
		this.saveModifiedCompilerList(modifiedCompilerList);
			
	}
	
	/** Writes all files in project*/
	public void writeAllFilesInProject() throws IOException {		
		Thread_writeAllFilesInProject thread = new Thread_writeAllFilesInProject(this);
		thread.start();
	}
	
	static class Thread_writeAllFilesInProject extends Thread {
		private EditText_Compiler editText;
		Thread_writeAllFilesInProject(EditText_Compiler editText) {
			this.editText = editText;
		}
		public void run() {
			try {
				CommonGUI.showMessage(true, "Converting all files in your project...");
				Control.view.postInvalidate();
				
				editText.writeAllFilesInProject_sub();
				CommonGUI.showMessage(true, "Converting ended...");
				Control.view.postInvalidate();
			} catch (IOException e) {
				
				e.printStackTrace();
			}
		}
	}
	
	public void writeAllFilesInProject_sub() throws IOException {
		int i;
		ArrayList fileList = FileHelper.getFileList(Common_Settings.pathProject, true);
		for (i=0; i<fileList.count; i++) {
			File file = (File) fileList.getItem(i);
			CommonGUI.showMessage(true, "Converting "+file.getAbsolutePath());
			this.saveFile(file.getAbsolutePath());
		}
	}
	
	void createButtonNewProjectAndOpenProjectAndCloseProjectAndNewClass(boolean changeBounds) {
		int widthButton = this.toolbar.bounds.width;
		int heightButton = (int) (this.scaleOfButtonBuildAll_Y * Control.view.getHeight());
		Rectangle buttonBounds = null;
		
		int gapY = (int) (this.scaleOfGapY * Control.view.getHeight());
		int x = this.bounds.x-widthButton;
		int y = this.toolbar.buttons[5].bounds.bottom() + gapY;
		
		if (!changeBounds) {
			
			if (this.buttonNewProject==null) {
				buttonBounds = new Rectangle(x, y, widthButton, heightButton);
				this.buttonNewProject = new Button(this, "NewProject", "NewProject", Color.CYAN, buttonBounds, 
	            		false, 255, false, 0.0f, null, Color.LTGRAY);
				this.buttonNewProject.setOnTouchListener(this);
			}
			if (this.buttonOpenProject==null) {
				buttonBounds = new Rectangle(x, buttonNewProject.bounds.bottom(), widthButton, heightButton);
				this.buttonOpenProject = new Button(this, "OpenProject", "OpenProject", Color.CYAN, buttonBounds, 
	            		false, 255, false, 0.0f, null, Color.LTGRAY);
				this.buttonOpenProject.setOnTouchListener(this);
			}
			if (this.buttonCloseProject==null) {
				buttonBounds = new Rectangle(x, buttonOpenProject.bounds.bottom(), widthButton, heightButton);
				this.buttonCloseProject = new Button(this, "CloseProject", "CloseProject", Color.CYAN, buttonBounds, 
	            		false, 255, false, 0.0f, null, Color.LTGRAY);
				this.buttonCloseProject.setOnTouchListener(this);
			}
			if (this.buttonNewClass==null) {
				buttonBounds = new Rectangle(x, buttonCloseProject.bounds.bottom(), widthButton, heightButton);
				this.buttonNewClass = new Button(this, "NewClass", "NewClass", Color.CYAN, buttonBounds, 
	            		false, 255, false, 0.0f, null, Color.LTGRAY);
				this.buttonNewClass.setOnTouchListener(this);
			}
		}// if (!changeBounds) {
		else {
			if (this.buttonNewProject!=null) {
				buttonBounds = new Rectangle(x, y, widthButton, heightButton);
				this.buttonNewProject.changeBounds(buttonBounds);
			}
			if (this.buttonOpenProject!=null) {
				buttonBounds = new Rectangle(x, this.buttonNewProject.bounds.bottom(), widthButton, heightButton);
				this.buttonOpenProject.changeBounds(buttonBounds);
			}
			if (this.buttonCloseProject!=null) {
				buttonBounds = new Rectangle(x, this.buttonOpenProject.bounds.bottom(), widthButton, heightButton);
				this.buttonCloseProject.changeBounds(buttonBounds);
			}
			if (this.buttonNewClass!=null) {
				buttonBounds = new Rectangle(x, this.buttonCloseProject.bounds.bottom(), widthButton, heightButton);
				this.buttonNewClass.changeBounds(buttonBounds);
			}
		}
	}
	
	/** lang이 java이면 버튼 build와 run을 만들고 바운드를 바꾼다.*/
	void createButtonBuildAndRunAndProblems(boolean changeBounds) {
		if (!isBuildAndRunEnable()) return;
		
		int widthButton = this.toolbar.bounds.width;
		int heightButton = (int) (this.scaleOfButtonBuildAll_Y * Control.view.getHeight());
		Rectangle buttonBounds = null;
		
		int x = this.bounds.x-widthButton;
		//int y = this.bounds.y+this.toolbar.buttons[this.toolbar.buttons.length-1].bounds.bottom();
		int gapY = (int) (this.scaleOfGapY * Control.view.getHeight());
		
		if (!changeBounds) {
			if (this.buttonBuild==null) {
				buttonBounds = new Rectangle(x, this.buttonNewClass.bounds.bottom()+gapY, widthButton, heightButton);
				this.buttonBuild = new Button(this, "Build", "Build", Color.CYAN, buttonBounds, 
	            		false, 255, false, 0.0f, null, Color.LTGRAY);
				this.buttonBuild.setOnTouchListener(this);
			}
			if (this.buttonBuildAll==null) {
				buttonBounds = new Rectangle(x, this.buttonBuild.bounds.bottom(), widthButton, heightButton);
				this.buttonBuildAll = new Button(this, "BuildAll", "BuildAll", Color.CYAN, buttonBounds, 
	            		false, 255, false, 0.0f, null, Color.LTGRAY);
				this.buttonBuildAll.setOnTouchListener(this);
			}
			if (this.buttonRun==null) {
				buttonBounds = new Rectangle(x, this.buttonBuildAll.bounds.bottom(), widthButton, heightButton);
				this.buttonRun = new Button(this, "Run", "Run", Color.CYAN, buttonBounds, 
	            		false, 255, false, 0.0f, null, Color.LTGRAY);
				this.buttonRun.setOnTouchListener(this);
			}
			if (this.buttonRun1==null) {
				buttonBounds = new Rectangle(x, this.buttonRun.bounds.bottom(), widthButton, heightButton);
				this.buttonRun1 = new Button(this, "Run1", "Run1", Color.CYAN, buttonBounds, 
	            		false, 255, false, 0.0f, null, Color.LTGRAY);
				this.buttonRun1.setOnTouchListener(this);
			}
			if (this.buttonDebug==null) {
				buttonBounds = new Rectangle(x, this.buttonRun1.bounds.bottom(), widthButton, heightButton);
				this.buttonDebug = new Button(this, "Debug", "Debug", Color.CYAN, buttonBounds, 
	            		false, 255, false, 0.0f, null, Color.LTGRAY);
				this.buttonDebug.setOnTouchListener(this);
			}
			if (this.buttonCancelBuild==null) {
				buttonBounds = new Rectangle(x, this.buttonDebug.bounds.bottom(), widthButton, heightButton);
				this.buttonCancelBuild = new Button(this, "CancelBuild", "CancelBuild", Color.CYAN, buttonBounds, 
	            		false, 255, false, 0.0f, null, Color.LTGRAY);
				this.buttonCancelBuild.setOnTouchListener(this);
			}
			if (this.buttonToggleBreakpoint==null) {
				buttonBounds = new Rectangle(x, this.buttonCancelBuild.bounds.bottom()+gapY, widthButton, heightButton);
				this.buttonToggleBreakpoint = new Button(this, "ToggleBP", "ToggleBP", Color.CYAN, buttonBounds, 
	            		false, 255, false, 0.0f, null, Color.LTGRAY);
				this.buttonToggleBreakpoint.setOnTouchListener(this);
			}
			if (this.buttonRemoveAllBreakpoints==null) {
				buttonBounds = new Rectangle(x, this.buttonToggleBreakpoint.bounds.bottom(), widthButton, heightButton);
				this.buttonRemoveAllBreakpoints = new Button(this, "RemoveAllBPS", "RemoveAllBPS", Color.CYAN, buttonBounds, 
	            		false, 255, false, 0.0f, null, Color.LTGRAY);
				this.buttonRemoveAllBreakpoints.setOnTouchListener(this);
			}
			if (this.buttonOpenDecl==null) {
				buttonBounds = new Rectangle(x, this.buttonRemoveAllBreakpoints.bounds.bottom()+gapY, widthButton, heightButton);
				this.buttonOpenDecl = new Button(this, "OpenDecl", "OpenDecl", Color.CYAN, buttonBounds, 
	            		false, 255, false, 0.0f, null, Color.LTGRAY);
				this.buttonOpenDecl.setOnTouchListener(this);
			}
			if (this.buttonProblems==null) {
				buttonBounds = new Rectangle(x, this.buttonOpenDecl.bounds.bottom(), widthButton, heightButton);
				this.buttonProblems = new Button(this, "Problems", "Problems", Color.CYAN, buttonBounds, 
	            		false, 255, false, 0.0f, null, Color.LTGRAY);
				this.buttonProblems.setOnTouchListener(this);
			}
			if (this.buttonProblemsAll==null) {
				buttonBounds = new Rectangle(x, this.buttonProblems.bounds.bottom(), widthButton, heightButton);
				this.buttonProblemsAll = new Button(this, "ProblemsAll", "ProblemsAll", Color.CYAN, buttonBounds, 
	            		false, 255, false, 0.0f, null, Color.LTGRAY);
				this.buttonProblemsAll.setOnTouchListener(this);
			}
			if (this.buttonInput==null) {
				buttonBounds = new Rectangle(x, this.buttonProblemsAll.bounds.bottom(), widthButton, heightButton);
				this.buttonInput = new Button(this, "Input", "Input", Color.CYAN, buttonBounds, 
	            		false, 255, false, 0.0f, null, Color.LTGRAY);
				this.buttonInput.setOnTouchListener(this);
			}
			if (this.buttonConsole==null) {
				buttonBounds = new Rectangle(x, this.buttonInput.bounds.bottom(), widthButton, heightButton);
				this.buttonConsole = new Button(this, "Console", "Console", Color.CYAN, buttonBounds, 
	            		false, 255, false, 0.0f, null, Color.LTGRAY);
				this.buttonConsole.setOnTouchListener(this);
			}
			if (this.buttonDebugView==null) {
				buttonBounds = new Rectangle(x, this.buttonConsole.bounds.bottom(), widthButton, heightButton);
				this.buttonDebugView = new Button(this, "DebugView", "DebugView", Color.CYAN, buttonBounds, 
	            		false, 255, false, 0.0f, null, Color.LTGRAY);
				this.buttonDebugView.setOnTouchListener(this);
			}
			if (this.buttonUsedMemory==null) {
				buttonBounds = new Rectangle(x, this.buttonDebugView.bounds.bottom(), widthButton, heightButton);
				this.buttonUsedMemory = new Button(this, "UsedMemory", "UsedMemory", Color.CYAN, buttonBounds, 
	            		false, 255, false, 0.0f, null, Color.LTGRAY);
				this.buttonUsedMemory.setOnTouchListener(this);
			}
		}// if (!changeBounds) {
		else {
			
			if (this.buttonBuild!=null) {
				buttonBounds = new Rectangle(x, this.buttonNewClass.bounds.bottom()+gapY, widthButton, heightButton);
				this.buttonBuild.changeBounds(buttonBounds);
			}
			if (this.buttonBuildAll!=null) {
				buttonBounds = new Rectangle(x, this.buttonBuild.bounds.bottom(), widthButton, heightButton);
				this.buttonBuildAll.changeBounds(buttonBounds);
			}
			if (this.buttonRun!=null) {
				buttonBounds = new Rectangle(x, this.buttonBuildAll.bounds.bottom(), widthButton, heightButton);
				this.buttonRun.changeBounds(buttonBounds);
			}
			if (this.buttonRun1!=null) {
				buttonBounds = new Rectangle(x, this.buttonRun.bounds.bottom(), widthButton, heightButton);
				this.buttonRun1.changeBounds(buttonBounds);
			}
			if (this.buttonDebug!=null) {
				buttonBounds = new Rectangle(x, this.buttonRun1.bounds.bottom(), widthButton, heightButton);
				this.buttonDebug.changeBounds(buttonBounds);
			}
			if (this.buttonCancelBuild!=null) {
				buttonBounds = new Rectangle(x, this.buttonDebug.bounds.bottom(), widthButton, heightButton);
				this.buttonCancelBuild.changeBounds(buttonBounds);
			}
			if (this.buttonToggleBreakpoint!=null) {
				buttonBounds = new Rectangle(x, this.buttonCancelBuild.bounds.bottom()+gapY, widthButton, heightButton);
				this.buttonToggleBreakpoint.changeBounds(buttonBounds);
			}
			if (this.buttonRemoveAllBreakpoints!=null) {
				buttonBounds = new Rectangle(x, this.buttonToggleBreakpoint.bounds.bottom(), widthButton, heightButton);
				this.buttonRemoveAllBreakpoints.changeBounds(buttonBounds);
			}
			if (this.buttonOpenDecl!=null) {
				buttonBounds = new Rectangle(x, this.buttonRemoveAllBreakpoints.bounds.bottom()+gapY, widthButton, heightButton);
				this.buttonOpenDecl.changeBounds(buttonBounds);
			}
			if (this.buttonProblems!=null) {
				buttonBounds = new Rectangle(x, this.buttonOpenDecl.bounds.bottom(), widthButton, heightButton);
				this.buttonProblems.changeBounds(buttonBounds);
			}
			if (this.buttonProblemsAll!=null) {
				buttonBounds = new Rectangle(x, this.buttonProblems.bounds.bottom(), widthButton, heightButton);
				this.buttonProblemsAll.changeBounds(buttonBounds);
			}
			if (this.buttonInput!=null) {
				buttonBounds = new Rectangle(x, this.buttonProblemsAll.bounds.bottom(), widthButton, heightButton);
				this.buttonInput.changeBounds(buttonBounds);
			}
			if (this.buttonConsole!=null) {
				buttonBounds = new Rectangle(x, this.buttonInput.bounds.bottom(), widthButton, heightButton);
				this.buttonConsole.changeBounds(buttonBounds);
			}
			if (this.buttonDebugView!=null) {
				buttonBounds = new Rectangle(x, this.buttonConsole.bounds.bottom(), widthButton, heightButton);
				this.buttonDebugView.changeBounds(buttonBounds);
			}
			if (this.buttonUsedMemory!=null) {
				buttonBounds = new Rectangle(x, this.buttonDebugView.bounds.bottom(), widthButton, heightButton);
				this.buttonUsedMemory.changeBounds(buttonBounds);
			}
		}
	}
	
	
	
	
	/** EditText의 이벤트 리스너, 이후에 draw가 호출된다*/
	public void editText_Listener(Object sender, MotionEvent e) {
		try {
			FunctionOfEditText.editText_Listener(this, sender, e);
		
		if (e.actionCode==MotionEvent.ActionDown) {
			if (lang==Language.Java || lang==Language.C) {
				//
				if (compiler==null) return;				
				HighArray_CodeString mBuffer = compiler.data.mBuffer;
				indexInmBuffer = CompilerStatic.findWord(compiler, cursorPos.x,cursorPos.y);
				if (indexInmBuffer!=-1 && indexInmBuffer!=mBuffer.count) {
					CodeString str = mBuffer.getItem(indexInmBuffer);
					HighArray_CodeChar message = null;
					if (str!=null) {
						if (str.equals("{") || str.equals("}")) {
							message = compiler.findParenthesis( indexInmBuffer);
						}
						else {
							message = compiler.findNode( indexInmBuffer);
						}
						if (message!=null && message.count!=0) {														
							CompilerStatic.textViewExpressionTreeAndMessage.initCursorAndScrollPos();
							CompilerStatic.textViewExpressionTreeAndMessage.setText(0, message);
							CompilerStatic.textViewExpressionTreeAndMessage.setHides(false);							
						}
					}
				}
			}//if (lang==Language.Java || lang==Language.C) {
			else if (lang==Language.Class) {
				//CodeString word = findWordInClassFile(cursorPos.x, cursorPos.y);
				CodeString word = null;
				if (compiler==null) return;				
				HighArray_CodeString mBuffer = compiler.data.mBuffer;
				int indexInmBuffer = CompilerStatic.findWord(compiler, cursorPos.x,cursorPos.y);
				if (indexInmBuffer!=-1) {
					word = mBuffer.getItem(indexInmBuffer);
				}
				if (word!=null) {
					int i;
					boolean found = false;
					ByteCode_Types.ByteCodeInstruction instruction = null;
					for (i=0; i<InstructionSet.instructionSet.length; i++) {
						instruction = InstructionSet.instructionSet[i];
						if (instruction.mnemonic.equals(word.str)) {
							found = true;
							break;
						}
					}
					if (found) {
						CompilerStatic.textViewExpressionTreeAndMessage.initCursorAndScrollPos();
						CompilerStatic.textViewExpressionTreeAndMessage.setText(0, new CodeString(instruction.message, Common_Settings.textColor));
						CompilerStatic.textViewExpressionTreeAndMessage.setHides(false);
					}
				}
			}
		}
		}catch(Exception e1) {
			//Log.e("EditText-OnTouchEvent ActionMove", e1.toString());
			e1.printStackTrace();
			CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e1);
			//return;
		}
	}
	
	
	
	/** Debug시에 이동한 라인에 =>를 그린다.*/
	public void drawArrowOnLineNumber(Canvas canvas) {
		if (BreakPoint.lineNumberShowingArrow==null || BreakPoint.lineNumberShowingArrow.lineNumber==-1) return;
				
		paint2.setColor(Common_Settings.varUseColor);
		paint2.setStyle(Style.STROKE);
		paint2.setTextSize(fontSize);
		float x = bounds.x+2;
		float y = bounds.y + (BreakPoint.lineNumberShowingArrow.lineNumber-vScrollPos) * lineHeight;
		if (bounds.y<y && y<=bounds.y+bounds.height) {
			canvas.drawText("=>", x, y, paint2);
		}
		
	}
	
	/** Debug시에 중단점 사각형을 그린다.*/
	public void drawBreakPoints(Canvas canvas) {
		ArrayListInt listOfBreakPoints = null;
		if (compiler!=null) {
			listOfBreakPoints = compiler.data.listOfBreakPoints;
		}
		if (listOfBreakPoints==null) return;
		paint2.setColor(Edit.selectColor);
		paint2.setStyle(Style.FILL);
		RectangleF dst = new RectangleF();
		//paint.setAlpha(80);
		int i;
		float x=bounds.x+2, y, w, h=lineHeight*0.65f;
		w = h;
		for (i=0; i<listOfBreakPoints.count; i++) {
			int lineNumber = listOfBreakPoints.getItem(i);
			y = bounds.y + (lineNumber-1-vScrollPos) * lineHeight + descent*2.0f;
			dst.x = x;
			dst.y = y;
			dst.width = w;
			dst.height = h;
			if (bounds.y<=y && y<=bounds.y+bounds.height-h) {
				canvas.drawRect(dst.toRectF(), paint2);
			}
		}
	}
	
	
	
	/** 명령줄이나 step, 혹은 Open Decl버튼 클릭으로 인해서 
	 * 이동할 라인으로 커서와 vScrollPos, hScrollPos을 바꿔서
	 * 페이지를 바꾼다.
	 * @param classParams 
	 * @param showsDebugLocation 
	 * @param fullClassName 
	 */
	public void moveToLineNumber(FindClassParams classParams, int lineNumber, boolean showsDebugLocation, 
			String fullClassName, boolean waitForOpen) {
		ThreadmoveToLineNumber thread = new ThreadmoveToLineNumber(this, classParams, lineNumber, 
				showsDebugLocation, fullClassName);		
		thread.start();
		try {
			thread.join();
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
	}
	
	static class ThreadmoveToLineNumber extends Thread {
		private FindClassParams classParams;
		private int lineNumber;
		private boolean showsDebugLocation;
		private EditText_Compiler owner;
		private String fullClassName;
		public ThreadmoveToLineNumber(EditText_Compiler owner, FindClassParams classParams,
				int lineNumber, boolean showsDebugLocation, String fullClassName) {
			
			this.owner = owner;
			this.classParams = classParams;
			this.lineNumber = lineNumber;
			this.showsDebugLocation = showsDebugLocation;
			this.fullClassName = fullClassName;
		}
		public void run() {
			owner.moveToLineNumber_sub(classParams, lineNumber, showsDebugLocation, fullClassName);			
			Control.view.postInvalidate();
		}
	}
	
	/** 명령줄이나 step, 혹은 Open Decl버튼 클릭으로 인해서 
	 * 이동할 라인으로 커서와 vScrollPos, hScrollPos을 바꿔서
	 * 페이지를 바꾼다.
	 * @param classParams 
	 * @param showsDebugLocation 
	 * @param fullClassName 
	 */
	protected void moveToLineNumber_sub(FindClassParams classParams, int lineNumber, boolean showsDebugLocation, 
			String fullClassName) {
		if (classParams==null || classParams.loadWayOfFindClassParams==LoadWayOfFindClassParams.ByteCode) {
			CommonGUI.showMessage(true, "Can't open a class named "+fullClassName+". Add its source file.");
			//this.lineNumberShowingArrow = null;
			return;
		}
				
		// 다른 소스파일인 경우
		if (!this.compiler.data.filename.equals(classParams.compiler.data.filename)) {
			if (classParams.compiler.data.mBuffer==null) {
				// Step completed: "thread=main", java.lang.Thread.exit(), line=754 bci=0 을 만났을때
				// 클래스 캐시에 넣어진 java.lang.Thread 등
				CommonGUI.showMessage(true, "Can't open a class named "+fullClassName+". Add its source file.");
				//this.lineNumberShowingArrow = null;
				return;
			}
			this.openCompilerDocument(classParams.compiler.data.filename);
		}
		
		if (lineNumber-2<0) {
			CommonGUI.showMessage(true, "It is a place that does not exist. So Can't move there.");
			//this.lineNumberShowingArrow = null;
			return;
		}
		
		//CompilerInterface compiler = (CompilerInterface) CommonGUI.editText_compiler.getCompiler();
		ArrayListInt listOfNewLines = compiler.data.mlistOfNewLines;
		int i;
		int indexOfNewLine = -1;
		for (i=0; i<listOfNewLines.count; i++) {
			int index = listOfNewLines.getItem(i);
			if (i==lineNumber-2) {
				indexOfNewLine = index; 
				break;
			}
		}
		int indexOfX = CompilerHelper.SkipBlank(compiler.data.mBuffer, false, indexOfNewLine+1, compiler.data.mBuffer.count-1);
		int cursorX = indexOfX - (indexOfNewLine+1);
		
		CommonGUI.editText_compiler.moveToCursorPos(cursorX, lineNumber-1);
		if (showsDebugLocation) {
			BreakPoint.setLineNumberShowingArrow(fullClassName, lineNumber);
		}
		
		
		CurPathText.setCurPathTextPlusProjectName(CommonGUI.editText_compiler.getCompiler(), 
				cursorPos.x, cursorPos.y, 
				CommonGUI.editText_compiler.getShowsCurPath());
		Control.view.postInvalidate();
	}
	
	public synchronized void draw(Canvas canvas) {
		super.draw(canvas);
		
		drawBreakPoints(canvas);
		
		this.drawArrowOnLineNumber(canvas);
		
		RectF rectBounds = bounds.toRectF();
		paintOfBorder.setColor(Common_Settings.keywordColor);
    	canvas.drawRect(rectBounds, paintOfBorder);
    	
    	if (this.buttonNewProject!=null) {
			this.buttonNewProject.draw(canvas);
		}
    	if (this.buttonOpenProject!=null) {
			this.buttonOpenProject.draw(canvas);
		}
    	if (this.buttonCloseProject!=null) {
			this.buttonCloseProject.draw(canvas);
		}
    	if (this.buttonNewClass!=null) {
			this.buttonNewClass.draw(canvas);
		}
    	
    	if (this.lang==Compiler_types.Language.Java) {
    		
    		if (this.buttonBuild!=null) {
    			this.buttonBuild.draw(canvas);
    		}
    		if (this.buttonBuildAll!=null) {
    			this.buttonBuildAll.draw(canvas);
    		}
    		if (this.buttonRun!=null) {
    			this.buttonRun.draw(canvas);
    		}
    		if (this.buttonRun1!=null) {
    			this.buttonRun1.draw(canvas);
    		}
    		if (this.buttonDebug!=null) {
    			this.buttonDebug.draw(canvas);
    		}
    		if (this.buttonCancelBuild!=null) {
    			this.buttonCancelBuild.draw(canvas);
    		}
    		if (this.buttonToggleBreakpoint!=null) {
    			this.buttonToggleBreakpoint.draw(canvas);
    		}
    		if (this.buttonRemoveAllBreakpoints!=null) {
    			this.buttonRemoveAllBreakpoints.draw(canvas);
    		}
    		if (this.buttonOpenDecl!=null) {
    			this.buttonOpenDecl.draw(canvas);
    		}
    		if (this.buttonProblems!=null) {
    			this.buttonProblems.draw(canvas);
    		}
    		if (this.buttonProblemsAll!=null) {
    			this.buttonProblemsAll.draw(canvas);
    		}
    		if (this.buttonInput!=null) {
    			this.buttonInput.draw(canvas);
    		}
    		if (this.buttonConsole!=null) {
    			this.buttonConsole.draw(canvas);
    		}
    		if (this.buttonDebugView!=null) {
    			this.buttonDebugView.draw(canvas);
    		}
    		if (this.buttonUsedMemory!=null) {
    			this.buttonUsedMemory.draw(canvas);
    		}
    	}
	}
	
		
	/**EditText_Compiler는 단 하나의 compiler를 갖는다.
	 * MDI에서도 단 하나의 compiler를 갖는다.
	 * 프로젝트에는 단 하나의 editText_compiler가 존재하고 열려있는 문서(editText_compiler.compiler)도 단 하나이다.*/
	private Compiler compiler;
	/** 사용자가 마지막으로 클릭한 indexInmBuffer*/
	int indexInmBuffer = -1;
	/** 저장을 안했을 경우 저장을 할것인지를 묻는 대화상자*/
	public SaveDialog saveDialog;
	public SaveDialogState dialogState;
	
	NewProjectDialog newProjectDialog;
	private NewJavaClassDialog newJavaClassDialog;

	public RunOrDebug runOrDebug = RunOrDebug.Run;

	
	
	
	
	
	
	
	
	public Compiler getCompiler() {
		return this.compiler;
	}
	
	public void setCompiler(Compiler compiler) {
		this.compiler = compiler;
	}

	
	/** mBufferIndex을 만날때까지의 numOfLines를 리턴한다.*/
	public int getNumOfLinesInmBuffer(HighArray_CodeString src, int mBufferIndex) {
		int j;
		int countOfNewLineChar = 0;
		for (j=0; j<=mBufferIndex; j++) {
			CodeString str = src.getItem(j);
			if (str.equals("\n")) {
				countOfNewLineChar++;
			}
		}
		return countOfNewLineChar;
	}
	
	void update_mListOfNewLines(int cursorPosX, int cursorPosY, String charA) {
		if (charA.equals(Edit.BackspaceChar)) {
			if (this.isSelecting) {
				//super.addBackspaceChar();
				return;
			}
			if (cursorPos.x!=0) {
				compiler.data.mlistOfNewLines.list[cursorPosY]--;
			}
			else {
				
			}
		}
		else if (charA.equals(Edit.DeleteChar)) {
			
		}
		else if (charA.equals(Edit.NewLineChar)) {
			
		}
		else {
			compiler.data.mlistOfNewLines.list[cursorPosY]++;
		}
	}
	
	
	
	public void addCharReally(String charA) {
		CommonGUI.loggingForMessageBox.setHides(true);
		
		//int cursorPos_backup = cursorPos.x;
		try {			
		
			UndoOfEditText.backUpForUndo(this, charA, false);
			// redo 를 무효화한다. redoBuffer를 모두 지워야 한다. 
			// redo 를 무효로 만들지 않으면 undo-redo 시스템의 오류가 발생한다.
			redoBuffer.reset();
		
		//if (charA.equals(IntegrationKeyboard.Space)) charA = " ";
		if (textArray[cursorPos.y]==null) {
			textArray[cursorPos.y] = new CodeString("", textColor);
		}
	
		int cursorPosX = cursorPos.x;
		int cursorPosY = cursorPos.y;
		
		
		if (this.isSelecting && 
				(charA.equals(Edit.DeleteChar) || charA.equals(Edit.BackspaceChar))) {
			this.deleteSelectedText();
			if (compiler!=null) {
				this.update(cursorPosX, cursorPosY, "all", true);
			}
		}
		else {
			try {
			if (charA.equals("}")) {
				int r = this.addMiddleRightPair();
				if (r!=-1) {
					cursorPosX = r;
					//cursorPos_backup = r;
				}
			}
			
			
			
			textArray[cursorPos.y].insert(new CodeString(charA, textColor).listCodeChar, 0, cursorPosX, charA.length());
			}catch(Exception e) {
				e.printStackTrace();
			}
			
			boolean allOrPart = false;
			
			if (!charA.equals(Edit.DeleteChar) && !charA.equals(Edit.NewLineChar) &&
					!charA.equals(Edit.BackspaceChar)) {
				CodeString newText=null;				
				try {
					newText = TextArrayToText(cursorPos.y, cursorPosX, 1);
					setTextMultiLine(cursorPos.y, newText, -1);
					
					if (charA.equals("{") || charA.equals("}") || charA.equals("[") || charA.equals("]") ||
							charA.equals("(") || charA.equals(")")) {
						allOrPart = true;
					}
				}catch(Exception e) {
				}				
				
				if (keyboardMode==Mode.Hangul && hangulMode!=Hangul.Mode.None) {
					
				}
				else {
					cursorPos.x = cursorPosX + 1;
				}			
			}
			else {
				if (charA.equals(Edit.BackspaceChar)) {
					char prevChar = 0;
					if (cursorPos.x>0) {
						prevChar = this.textArray[cursorPos.y].charAt(cursorPos.x-1).c;
					}
					if (prevChar=='{' || prevChar=='}' || prevChar=='[' || prevChar==']' ||
							prevChar=='(' || prevChar==')') {
						allOrPart = true;
					}
					addBackspaceChar();
				}
				else if (charA.equals(Edit.DeleteChar)) {
					char curChar = 0;
					curChar = this.textArray[cursorPos.y].charAt(cursorPos.x).c;
					if (curChar=='{' || curChar=='}' || curChar=='[' || curChar==']' ||
							curChar=='(' || curChar==')') {
						allOrPart = true;
					}
					addDeleteChar();
				}
				else if (charA.equals(Edit.NewLineChar)) {
					addEnterChar();
				}
				else {
					CodeString newText = TextArrayToText(cursorPos.y, 0, cursorPos.y, cursorPosX);
					setText(cursorPos.y, newText);
				}
			}
			if (compiler!=null) {				
				this.update(cursorPosX, cursorPosY, charA, allOrPart);
			}
		}
		
		
				
		}catch(Exception e) {
			//Log.e("EditText-addCharReally", e.toString());
			if (Common_Settings.g_printsLog) e.printStackTrace();
			CompilerHelper.printStackTrace(textViewLogBird, e);
		}
	}
	
	
	
	
	
	/**startIndex, endIndex 모두 포함, mBuffer에서의 인덱스*/
	protected HighArray_CodeChar getText4(int startIndexInstrInput, int endIndexInstrInput) {
		
		int i;
		HighArray_CodeChar newText = new HighArray_CodeChar(100);
		int count=0;
		int xOfStartIndexOfResult = -1;
		int yOfStartIndexOfResult = -1;
		int xOfEndIndexOfResult = -1;
		int yOfEndIndexOfResult = -1;
		
		for (i=0; i<this.numOfLines; i++) {
			CodeString line = this.textArray[i];
			count += line.count;
			if (startIndexInstrInput<count) {
				int inc = count-startIndexInstrInput-1;
				yOfStartIndexOfResult = i;
				xOfStartIndexOfResult = line.count-inc-1;
				break;
			}			
		}
		count -= this.textArray[yOfStartIndexOfResult].count;
		
		for (i=yOfStartIndexOfResult; i<this.numOfLines; i++) {
			CodeString line = this.textArray[i];
			count += line.count;
			if (endIndexInstrInput<count) {
				int inc = count-endIndexInstrInput-1;
				yOfEndIndexOfResult = i;
				xOfEndIndexOfResult = line.count-inc-1;
				break;
			}			
		}
		
		int j;
		
		for (i=xOfStartIndexOfResult; i<this.textArray[yOfStartIndexOfResult].count; i++) {
			newText.add(this.textArray[yOfStartIndexOfResult].charAt(i));
		}
		for (j=yOfStartIndexOfResult+1; j<yOfEndIndexOfResult; j++) {
			for (i=0; i<this.textArray[j].count; i++) {
				newText.add(this.textArray[j].charAt(i));
			}
		}
		for (i=0; i<=xOfEndIndexOfResult; i++) {
			newText.add(this.textArray[yOfEndIndexOfResult].charAt(i));
		}
		return newText;
	}
	
	/**startIndex, endIndex 모두 포함, mBuffer에서의 인덱스*/
	protected HighArray_CodeChar getText3AndTrim(int startLineY, int endLineY) {
		
		int i;
		HighArray_CodeChar newText = new HighArray_CodeChar(100);
		for (i=startLineY; i<=endLineY; i++) {
			CodeString line = this.textArray[i];
			newText.add(line);
		} 
		return newText.trim();
	}
	
	protected void drawCommon(Canvas canvas) {
		super.drawCommon(canvas);
	}
	
	/** cursorPosX, cursorPosY에서 charA를 입력하고 
	 * 소스 파일 전체를 컴파일할 경우 allOrPart을 true를 입력하고
	 * 그렇지 않으면 false를 입력한다.
	 */
	public void update(int cursorPosX, int cursorPosY, String charA, boolean allOrPart) {
		Control.view.postInvalidate();
		if (compiler!=null && FileHelper.getExt(compiler.data.filename).equals(".java")) { 
			LoggingScrollable.longOperation = true;
			
			Update.update(charA);
			this.saveMDIDatasToCompilerData(compiler);
			
			LoggingScrollable.longOperation = false;
		}
	}
	
	
	

	public void addChar(String charA) {
		//Update.waitForUpdate();
			
		CurPathText.setCurPathTextPlusProjectName(compiler, cursorPos.x, cursorPos.y, this.getShowsCurPath());
		
		// specialKeys를 누르는 것은 제외한다.
		setIsModified(true);
		redoBuffer.reset();
		
		if (charA.equals(IntegrationKeyboard.Delete)) {	// BackSpace
			charA = Edit.DeleteChar;
			
		}	// BackSpace
		else if (charA.equals(IntegrationKeyboard.Enter)) {
			charA = Edit.NewLineChar;
		}
		else if (charA.equals(IntegrationKeyboard.BackSpace)) {
			charA = Edit.BackspaceChar;
		}
		if (isSingleLine) {
			if (charA.equals(Edit.NewLineChar)) return;
		}
		addCharReally(charA/*, isNextToCursor*/);
			
		if (this.scrollMode==ScrollMode.VScroll) {
			setVScrollPos();
			setVScrollBar();
		}
		else {
			setVScrollPos();
			setHScrollPos();
			setVScrollBar();
			setHScrollBar();
		}
	}
	
	@Override
	public void replaceChar(String charA) {
		//Update.waitForUpdate();
		
		super.replaceChar(charA);
	}
	
	/**lineNumber의 들여쓰기 공간 크기를 리턴한다.*/
	int getSpaceSize(int lineNumber) {
		int i;
		CodeString curLine = this.textArray[lineNumber];
		for (i=0; i<curLine.count; i++) {
			CodeChar c = curLine.charAt(i);
			if (c.c==' ' || c.c=='\t') continue;
			else {
				return i;
			}
		}
		return -1;
	}
	
	
	/**'}'을 입력할때 들여쓰기(-Edit.SpaceSize)를 한다. 
	 * '}'이 들어가야할 위치를 리턴한다.*/
	public int addMiddleRightPair() {
		if (this.lang!=Language.Java) return -1;
		
		/*while (true) {
			boolean haveToSleep = false;
			synchronized (Update.listOfQueueItems) {
				if (Update.listOfQueueItems.count>0) {
					haveToSleep = true;
				}
				else {
					break;
				}
			}
			if (haveToSleep) {
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					
					e.printStackTrace();
				}
			}
		}*/
		synchronized (Update.listOfQueueItems) {
			if (Update.listOfQueueItems.count>0) {
				Update.updateAllRightNow( 0);
			}
		}
		
		boolean minus4 = false;
		int cursorPosY = cursorPos.y;
		CodeString curLine = this.textArray[cursorPosY];
		int prevIndex = CompilerHelper.SkipBlank(curLine, true, 0, cursorPos.x-1);
		// 현재줄이 모두 공백일 경우
		if (prevIndex==-1 && 
				this.textArray[cursorPosY-1].count>0 && 
				this.textArray[cursorPosY-1].charAt(this.textArray[cursorPosY-1].count-1).c=='\n') {
			minus4 = true;
		}
		if (minus4) {
			CodeChar[] spaces = null;
			int indexOfRightPair = CompilerStatic.findWord(compiler, cursorPos.x, cursorPos.y);
			int indexOfLeftPair = 
					Checker.CheckParenthesisAddingFirstPair(compiler, compiler.data.mBuffer, "{", "}", 0, indexOfRightPair, true);
			if (indexOfLeftPair!=-1) {
				int lineNumberOfLeftPair = CompilerStatic.getCursorPosYInSrc(compiler, indexOfLeftPair);
				int spaceSize = this.getSpaceSize(lineNumberOfLeftPair);
				
				int arrSize = spaceSize;
				/*if (curLine.charAt(curLine.count-1).c=='\n') {
					arrSize++;
				}*/
				spaces = new CodeChar[arrSize];
				Array.Copy(this.textArray[lineNumberOfLeftPair].listCodeChar, 0, spaces, 0, spaceSize);
				/*if (curLine.charAt(curLine.count-1).c=='\n') {
					spaces[spaces.length-1] = new CodeChar('\n', Common_Settings.textColor, CodeStringType.Text);
				}*/
				//this.textArray[cursorPosY] = new CodeString(spaces, spaces.length);
				this.textArray[cursorPosY].insert(spaces, 0, 0, spaces.length);
				cursorPos.x = spaceSize;
				return cursorPos.x;
			}
			
		}
		return -1;
	}
	
	
	/** 들여쓰기를 위한 것이다.*/
	@Override
	public void addEnterChar() {
		int cursorPosY = cursorPos.y;
		int cursorPosX = cursorPos.x;
		int prevIndex = CompilerHelper.SkipBlank(this.textArray[cursorPosY], true, 0, cursorPos.x-1);
		// 다음줄이 모두 공백일 경우
		if (prevIndex==-1) {
			prevIndex = cursorPos.x-1;
		}
	
		
		super.addEnterChar();
		
		if (prevIndex<0) {
			return;
		}
		
		
		if (this.compiler!=null) {
			int i;
			CodeString curLine = this.textArray[cursorPosY];
			CodeString nextLine = null;
			if (cursorPosY+1<this.numOfLines) {
				nextLine = textArray[cursorPosY+1];
				boolean inputsSpace = false;
				i = this.getSpaceSize(cursorPosY);
				if (i!=-1) inputsSpace = true;
				
				if (inputsSpace) {
					int pos=0;
					CodeChar[] spaces = null;
					// 엔터키 이전의 문자가 다음과 같으면
					if (/*prevChar==';' || prevChar=='}' || prevChar==' ' || prevChar=='\t'*/ 
							!this.inputsInnerSpace(cursorPosY, cursorPosX)) {
						// 현재 라인과 같은 여백을 갖는다.
						spaces = curLine.listCodeChar;
						pos = i;
					}					
					else { // '{', ')' 등
						// 현재 라인이 갖는 여백에 +4를 갖는다.
						spaces = new CodeChar[i+/*Edit.SpaceSize*/1];
						Array.Copy(curLine.listCodeChar, 0, spaces, 0, i);
						int j;
						for (j=0; j</*Edit.SpaceSize*/1; j++) {
							spaces[i+j] = new CodeChar(/*' '*/'\t', Common_Settings.textColor, CodeStringType.Text); 
						}
						pos = spaces.length;
					}
					nextLine.insert(spaces, 0, 0, pos);
					cursorPos.x = pos;
					cursorPos.y = cursorPosY+1;
					
					//this.update(cursorPos.x, cursorPos.y, Edit.NewLineChar, false);
					//Update.update2RightNow(this);
				}
				
			}
		}
	}
	
	/**들여쓰기를 할 것인가를 결정한다.	 * 
	 * @param curCursorPosY : 엔터를 입력하기 전 좌표
	 * @param curCursorPosX : 엔터를 입력하기 전 좌표
	 * @return false(들여쓰기 X), true(들여쓰기 O)*/
	boolean inputsInnerSpace(int curCursorPosY, int curCursorPosX) {
		int i;
		for (i=curCursorPosX-1; i>=0; i--) {
			char c = this.textArray[curCursorPosY].charAt(i).c;
			if (CompilerHelper.IsBlank(c)) continue;
			else break;
		}
		// 현재 라인이 전부 공백인 경우 들여쓰기 X
		if (i==-1) return false;
		
		for (i=curCursorPosX-1; i>=0; i--) {
			char c = this.textArray[curCursorPosY].charAt(i).c;
			if (CompilerHelper.IsBlank(c)) continue;
			if (c==';' || c=='}') {
				return false;
			}
			if (c=='{' || c=='(' || c==',' )  {
				return true;
			}
		}
		
		for (i=curCursorPosX-1; i>=0; i--) {
			char c = this.textArray[curCursorPosY].charAt(i).c;
			if (i>0 && this.textArray[curCursorPosY].charAt(i-1).c=='/') {
				if (c=='/') return false; // //
				else if (c=='*') return false; // /*
			}
			else if (i>0 && this.textArray[curCursorPosY].charAt(i-1).c=='*') {
				if (c=='/') return false; // */
			}
		}
		// 들여쓰기가 기본이다.
		return true;
	}
	
	/** '.'을 입력하면 패키지나 클래스의 멤버들을 표시하는 창을 연다.
	 * @param compiler : changed compiler 
	 * @param filter : "all"(not filter), "a"(chars to filter), only lower case*/
	void inputDot(Compiler compiler, String filter) {
		HighArray_CodeString mBuffer = compiler.data.mBuffer;
		int indexInmBuffer = CompilerStatic.findWord(compiler, cursorPos.x-1, cursorPos.y);
		if (indexInmBuffer!=-1 && indexInmBuffer!=mBuffer.count) {
			((CompilerInterface)compiler).inputDot(indexInmBuffer, filter, 0);
		}
	}
	
	void createSaveDialog(boolean changeBounds) {
		int w = (int) (Control.view.getWidth()*0.6f);
		int h = (int) (Control.view.getHeight()*0.35f);
		int x = Control.view.getWidth()/2 - w/2;
		int y = Control.view.getHeight()/2 - h/2;
		Rectangle bounds = new Rectangle(x, y, w, h);
		if (!changeBounds) {
			if (saveDialog==null) {
				saveDialog = new SaveDialog(Control.view, bounds);
				saveDialog.setText("Do you want to save?");
			}
		}
		else {
			saveDialog.changeBounds(bounds);
		}
	}
	
	void createNewProjectDialog(boolean changeBounds) {
		int w = (int) (Control.view.getWidth()*0.7f);
		int h = (int) (Control.view.getHeight()*0.6f);
		int x = Control.view.getWidth()/2 - w/2;
		int y = 0;
		Rectangle bounds = new Rectangle(x, y, w, h);
		if (!changeBounds) {
			if (this.newProjectDialog==null) {
				newProjectDialog = new NewProjectDialog(bounds);
				newProjectDialog.setOnTouchListener(this);
			}
		}
		else {
			newProjectDialog.changeBounds(bounds);
		}
	}
	
	void createNewJavaClassDialog(boolean changeBounds) {
		int w = (int) (Control.view.getWidth()*0.7f);
		int h = (int) (Control.view.getHeight()*0.55f);
		int x = Control.view.getWidth()/2 - w/2;
		int y = 0;
		Rectangle bounds = new Rectangle(x, y, w, h);
		if (!changeBounds) {
			if (this.newJavaClassDialog==null) {
				newJavaClassDialog = new NewJavaClassDialog(bounds);
				newJavaClassDialog.setOnTouchListener(this);
			}
		}
		else {
			newJavaClassDialog.changeBounds(bounds);
		}
	}
	
	
	
	public static enum SaveDialogState {
		NewProject, OpenProject, CloseProject, CloseDocument, 
		Build, BuildAll, Run, Run1, Debug, 
		Destroy
	}
	
	/** when clicking open project*/
	void fileDialog_handler(Object sender) {
		FileDialog dialog = (FileDialog) sender;
		if (dialog.getIsOK()) {
			createEditTextCurPath(null, true);
			
			this.destroyProject();
			
			String curDir = dialog.getCurDir(true);			
			Common_Settings.set_pathProject(curDir.substring(0, curDir.length()-1));
			Common_Settings.setProjectPath(Common_Settings.get_pathProject());
			
			Common_Settings.settings = SettingsDialog.restoreProjectSettings(Common_Settings.get_pathProject());
			Common_Settings.settingsDialog.setEditTextDirectory(Common_Settings.pathAndroid);
			Common_Settings.settingsDialog.otherLibsDialog.setMenuListButtonsWithCommon_Settings_listOfOtherLibs();
			
			CurPathText.setCurPathTextPlusProjectName("");
			
			CompilerHelper.setJavaClassPathIfNotExists();
			
			this.initialize();
		}
	}
	
	/**Debug*/
	void buttonDebug_handler() {
		ArrayList modifiedCompiler = CompilerCache.isProjectModified();
		if (modifiedCompiler.count!=0) {
			this.dialogState = SaveDialogState.Debug;
			this.saveDialog.Text = "Do you want to save ";
			this.saveDialog.setText(CompilerCache.toString_isProjectModified(modifiedCompiler) + "?");
			this.saveDialog.open(this, true);
		}
		else {
			if (compiler!=null) {
				if (this.runOrDebug==RunOrDebug.Run) {
					resetInputConsoleDebugAndError();
					
					CommonGUI.loggingForMessageBox.setText(true, "Building any java files in "+compiler.data.packageName+"...", false);
					CommonGUI.loggingForMessageBox.setHides(false);
					Control.view.invalidate();
					
					Builder.buildAndRunOrDebug(compiler, compiler.data.filename, FileListToCompile_Mode.AllInProject, RunOrDebug.Debug);
					
					this.runOrDebug = RunOrDebug.Debug;
					
					this.buttonNewProject.setText("To Java");
					this.buttonOpenProject.setText("Resume");
					this.buttonCloseProject.setText("Threads");
					this.buttonNewClass.setText("Where");
					
					this.buttonBuild.setText("Step into");
					this.buttonBuildAll.setText("Step over");
					this.buttonRun.setText("Step return");
					this.buttonRun1.setText("Locals");
					//this.buttonDebug.setText("Run");
					
					//this.listOfBreakPoints.reset2();
					BreakPoint.lineNumberShowingArrow = null;
					
					ClassFileRunner.resetDebugCommand();
					
					String allBreakpointsStr = BreakPoint.getAllBreakpoints(true);
					ClassFileRunner.addToDebugCommand(allBreakpointsStr);
					
					String runCommand = "run\r\n";
					ClassFileRunner.addToDebugCommand(runCommand);
				} //if (this.runOrDebug==RunOrDebug.Run) {				
			}// if (compiler!=null) {
		}
	}
	
	
	
	
	
	
	
	void buttonToggleBreakpoint_handler() {
		BreakPoint.toggleBreakPoint(compiler, cursorPos);
	}
	
	void buttonRemoveAllBreakpoints_handler() {
		String listOfClears = BreakPoint.removeAllBreakpoints(this.runOrDebug);
		if (listOfClears!=null) {
			// in debug mode
			ClassFileRunner.replaceDebugCommand(listOfClears);
		}
	}
	
	void buttonOpenDecl_handler() {
		int indexInmBuffer = CompilerStatic.findWord(compiler, cursorPos.x, cursorPos.y);
		Object node = 
				((CompilerInterface)compiler).findNode_sub2( compiler.data.mlistOfClass, indexInmBuffer);
		if (node instanceof FindClassParams) {
			
		}// if (node instanceof FindVarParams) {
		
		else if (node instanceof FindVarUseParams) {
			FindVarUseParams varUse = (FindVarUseParams) node;
			if (varUse.varDecl!=null) {
				FindVarParams var = varUse.varDecl;
				FindClassParams parentClass = null;
				if (var.isMemberOrLocal) {
					parentClass = (FindClassParams) var.parent;
				}
				else {
					// 지역변수인 경우
					parentClass = (FindClassParams) (var.parent.parent);
				}
				String ext = FileHelper.getExt(parentClass.compiler.data.filename);
				FindClassParams classInSrc = null;
				FindVarParams varInSrc = null;
				int lineNumber = -1;
				if (ext.equals(".java")) {
					classInSrc = parentClass;
					varInSrc = var;
				}
				else {
					String slashedFullname = parentClass.name.replace('.', File.separatorChar);
					File srcFile = CompilerStatic.getAbsPath_FromVariousClassPath(2, slashedFullname);
					if (srcFile!=null) {
						classInSrc = Builder.start2_usingCache(srcFile.getAbsolutePath(), parentClass.name, 0);
						varInSrc = Member.getMemberVarInSrc(varUse.classToDefineThisVarUse.compiler, varUse.classToDefineThisVarUse.compiler.data.mBuffer, classInSrc, varUse, 0);
					}
				}
				if (varInSrc!=null) {
					lineNumber = CompilerStatic.getCursorPosYInSrc(classInSrc.compiler, varInSrc.startIndex())+1;	
				}
				
				this.moveToLineNumber(classInSrc, lineNumber, false, parentClass.name, false);
			}
			else if (varUse.funcDecl!=null) {
				FindFunctionParams func = varUse.funcDecl;
				FindClassParams parentClass = (FindClassParams) func.parent;
				String ext = FileHelper.getExt(parentClass.compiler.data.filename);
				FindClassParams classInSrc = null;
				FindFunctionParams funcInSrc = null;
				int lineNumber = -1;
				if (ext.equals(".java")) {
					classInSrc = parentClass;
					funcInSrc = func;
				}
				else {
					String slashedFullname = parentClass.name.replace('.', File.separatorChar);
					File srcFile = CompilerStatic.getAbsPath_FromVariousClassPath(2, slashedFullname);
					if (srcFile!=null) {
						classInSrc = Builder.start2_usingCache(srcFile.getAbsolutePath(), parentClass.name, 0);
						funcInSrc = Member.getFunctionInSrc(varUse.classToDefineThisVarUse.compiler, classInSrc, varUse, 0);
					}
				}
				if (funcInSrc!=null) {
					lineNumber = CompilerStatic.getCursorPosYInSrc(classInSrc.compiler, funcInSrc.startIndex())+1;
				}
				this.moveToLineNumber(classInSrc, lineNumber, false, parentClass.name, false);
							
			}
			else if (varUse.memberDecl!=null) {
				if (varUse.memberDecl instanceof FindClassParams) {
					FindClassParams classParams = (FindClassParams) varUse.memberDecl;
					
					String ext = FileHelper.getExt(classParams.compiler.data.filename);
					FindClassParams classInSrc = null;
					int lineNumber = -1;
					if (ext.equals(".java")) {
						classInSrc = classParams;
					}
					else {
						String slashedFullname = classParams.name.replace('.', File.separatorChar);
						File srcFile = CompilerStatic.getAbsPath_FromVariousClassPath(2, slashedFullname);
						if (srcFile!=null) {
							classInSrc = Builder.start2_usingCache(srcFile.getAbsolutePath(), classParams.name, 0);
						}
					}
					if (classInSrc!=null) {
						lineNumber = CompilerStatic.getCursorPosYInSrc(classInSrc.compiler, classInSrc.startIndex())+1;
					}
					this.moveToLineNumber(classInSrc, lineNumber, false, classParams.name, false);
				}
				
			}
		
		}//else if (node instanceof FindVarUseParams) {
		else if (node instanceof FindVarParams) {
		}// if (node instanceof FindVarParams) {
		
		else if (node instanceof FindFunctionParams) {
		
		}//else if (node instanceof FindFunctionParams) {
		else if (node instanceof FindControlBlockParams) {
			
		}
	}
	
	/**CloseProject/Threads*/
	void buttonCloseProject_handler() {
		ArrayList modifiedCompiler = CompilerCache.isProjectModified();
		if (modifiedCompiler.count!=0) {
			this.dialogState = SaveDialogState.CloseProject;
			this.saveDialog.Text = "Do you want to save ";
			this.saveDialog.setText(CompilerCache.toString_isProjectModified(modifiedCompiler) + "?");
			this.saveDialog.open(this, true);
		}
		else {
			if (this.runOrDebug==RunOrDebug.Run) {
				this.destroyProject();
				
				Common_Settings.set_pathProject(null);				
				Common_Settings.setProjectPath(Common_Settings.get_pathProject());
				Common_Settings.listOfOtherLibs.reset2();
				Common_Settings.settingsDialog.otherLibsDialog.setMenuListButtonsWithCommon_Settings_listOfOtherLibs();
				//Common_Settings.settingsDialog.backupProjectSettings();
				
				CurPathText.setCurPathTextPlusProjectName("");
				
				CompilerHelper.setJavaClassPathIfNotExists();
				
				this.initialize();
			}
			else {
				ClassFileRunner.replaceDebugCommand("threads" + "\r\n");
			}
		}
	}
	
	/**OpenProject/Resume*/
	void buttonOpenProject_handler() {
		ArrayList modifiedCompiler = CompilerCache.isProjectModified();
		if (modifiedCompiler.count!=0) {
			this.dialogState = SaveDialogState.OpenProject;
			this.saveDialog.Text = "Do you want to save ";
			this.saveDialog.setText(CompilerCache.toString_isProjectModified(modifiedCompiler) + "?");
			this.saveDialog.open(this, true);
		}
		else {
			if (this.runOrDebug==RunOrDebug.Run) {
				FileDialog fileDialog = CommonGUI.fileDialog;
				fileDialog.isFullScreen = true;
				fileDialog.canSelectFileType = false;
				fileDialog.isForViewing = true;
				fileDialog.isOpenFileDialog = false;
				fileDialog.setScaleValues();
				fileDialog.changeBounds(new Rectangle(0,0,Control.view.getWidth(),Control.view.getHeight()));
				
				String curDir = null;
				if (Common_Settings.pathProject==null) {
					curDir = Common_Settings.pathJaneSoft + File.separator + "project";
				}
				else {
					curDir = FileHelper.getDirectory(Common_Settings.pathProject);
				}
				fileDialog.createAndSetFileListButtons(curDir, FileDialog.Category.Text);
				fileDialog.setIsForReadingOrSaving(1);
				fileDialog.open(this, "Load Project - Select a directory");
			}
			else {
				BreakPoint.clearBreakPointsForStepOver();
				ClassFileRunner.addToDebugCommand("resume\r\n");
				BreakPoint.resetAllLineNumbersShowingArrow();
			}
		}
	}
	
	public void toJava() {
		this.buttonNewProject.setText("NewProject");
		this.buttonOpenProject.setText("OpenProject");
		this.buttonCloseProject.setText("CloseProject");
		this.buttonNewClass.setText("NewClass");
		
		this.buttonBuild.setText("Build");
		this.buttonBuildAll.setText("BuildAll");
		this.buttonRun.setText("Run");
		this.buttonRun1.setText("Run1");
		this.buttonDebug.setText("Debug");
		
		this.runOrDebug = RunOrDebug.Run;
		
		ClassFileRunner.killOldThread();
		
		BreakPoint.lineNumberShowingArrow = null;
		//this.listOfBreakPoints.reset2();
		
		BreakPoint.resetAllLineNumbersShowingArrow();
		
		BreakPoint.listOfoldBreakPointForStepOver.reset();
	}
	
	/**NewProject/To Java*/
	void buttonNewProject_handler() {
		if (this.runOrDebug==RunOrDebug.Run) {
			ArrayList modifiedCompiler = CompilerCache.isProjectModified();
			if (modifiedCompiler.count!=0) {
				this.dialogState = SaveDialogState.NewProject;
				this.saveDialog.Text = "Do you want to save ";
				this.saveDialog.setText(CompilerCache.toString_isProjectModified(modifiedCompiler) + "?");
				this.saveDialog.open(this, true);
			}
			else {
				if (this.newProjectDialog==null) {
					this.createNewProjectDialog(false);
				}
				this.newProjectDialog.open(true);
			}
		}
		else {
			this.toJava();
		}
	}
	
	void newProjectDialog_handler(Object sender) {
		NewProjectDialog dialog = (NewProjectDialog) sender;
		if (dialog.getIsOK()) {
			this.destroyProject();
			
			CommonGUI.editText_compiler.initialize();
			
			String projectName = dialog.editTextProject.getText2();
			
			String projectDir = null;
			if (Common_Settings.pathProject==null) {
				projectDir = Common_Settings.pathJaneSoft + File.separator + "project";
			}
			else {
				projectDir = FileHelper.getDirectory(Common_Settings.pathProject);
			}
			String projectPath = projectDir + File.separator + projectName;
			File fileProjectPath = new File(projectPath);
			fileProjectPath.mkdirs();
			
			File fileProjectSrcPath = new File(projectPath+File.separator+"src");
			fileProjectSrcPath.mkdirs();
			
			File fileProjectOutputPath = new File(projectPath+File.separator+"output");
			fileProjectOutputPath.mkdirs();
			
			File fileProjectDocPath = new File(projectPath+File.separator+"doc");
			fileProjectDocPath.mkdirs();
			
			Common_Settings.setProjectPath(projectPath);
			
			CompilerHelper.setJavaClassPathIfNotExists();
			
			String packageName = dialog.editTextPackage.getText2();
			String className = dialog.editTextClass.getText2();
			boolean inputsMainFunc = dialog.buttonMainFunc.getIsSelected();
			NewJavaFile.createNewJavaFile(packageName, className, inputsMainFunc);
			String filePath = Common_Settings.pathProjectSrc+File.separator+packageName.replace('.', File.separatorChar)+
					File.separator+className+".java";
						
			this.loadCompilerDocument(filePath);
			this.setText(0, compiler.data.mBuffer.toHighArray_CodeChar());
			
			Common_Settings.listOfOtherLibs.reset2();
			Common_Settings.settingsDialog.otherLibsDialog.setMenuListButtonsWithCommon_Settings_listOfOtherLibs();
			Common_Settings.settingsDialog.backupProjectSettings();
			
			CommonGUI.loggingForMessageBox.setText(true, 
					"Succeeded creating "+packageName+"."+className, false);
			CommonGUI.loggingForMessageBox.setHides(false);
		}
	}
	
	/**NewClass/Where*/
	void buttonNewClass_handler() {
		if (this.runOrDebug==RunOrDebug.Run) {
			if (this.newJavaClassDialog==null) {
				this.createNewJavaClassDialog(false);
			}
			this.newJavaClassDialog.open(true);
		}
		else {
			ClassFileRunner.replaceDebugCommand("where" + "\r\n");
		}
	}
	
	/**Build/Step Into*/
	void buttonBuild_handler() {
		if (this.runOrDebug==RunOrDebug.Run) {
			ArrayList modifiedCompiler = CompilerCache.isProjectModified();
			if (modifiedCompiler.count!=0) {
				this.dialogState = SaveDialogState.Build;
				this.saveDialog.Text = "Do you want to save ";
				this.saveDialog.setText(CompilerCache.toString_isProjectModified(modifiedCompiler) + "?");
				this.saveDialog.open(this, true);
			}
			else {
				// 현재 로드한 자바파일에 대해서만 클래스 파일을 만든다.
				if (compiler!=null) {
					//Builder.build(compiler, false, FileListToCompile_Mode.Only1);
					Builder.createMenuBuildTypes(false);
					Builder.openMenuBuildTypes();
				}
			}
		}
		else {
			// step into
			BreakPoint.clearBreakPointsForStepOver();
			ClassFileRunner.addToDebugCommand("step\r\n");
		}
	}
	
	
	
	/**BuildAll/Step Over*/
	void buttonBuildAll_handler() {
		if (this.runOrDebug==RunOrDebug.Run) {
			ArrayList modifiedCompiler = CompilerCache.isProjectModified();
			if (modifiedCompiler.count!=0) {
				this.dialogState = SaveDialogState.BuildAll;
				this.saveDialog.Text = "Do you want to save ";
				this.saveDialog.setText(CompilerCache.toString_isProjectModified(modifiedCompiler) + "?");
				this.saveDialog.open(this, true);
			}
			else {
				// mPackageName에 있는 모든 자바파일들에 대해 클래스 파일들을 만든다.
				if (compiler!=null) {
					CommonGUI.loggingForMessageBox.setText(true, "Building all java files in "+compiler.data.packageName+"...", false);
					CommonGUI.loggingForMessageBox.setHides(false);
					Control.view.invalidate();
					
					Builder.build(compiler, false, FileListToCompile_Mode.AllInProject);
				}
			}
		}
		else {
			// step over
			CommonGUI.textViewDebug.stepOver(compiler);	
			
		}
	}
	
	/**Run/Step Return*/
	void buttonRun_handler() {
		if (this.runOrDebug==RunOrDebug.Run) {
			ArrayList modifiedCompiler = CompilerCache.isProjectModified();
			if (modifiedCompiler.count!=0) {
				this.dialogState = SaveDialogState.Run;
				this.saveDialog.Text = "Do you want to save ";
				this.saveDialog.setText(CompilerCache.toString_isProjectModified(modifiedCompiler) + "?");
				this.saveDialog.open(this, true);
			}
			else {
				if (compiler!=null) {
					resetInputConsoleDebugAndError();
					
					CommonGUI.loggingForMessageBox.setText(true, "Building all java files in "+compiler.data.packageName+"...", false);
					CommonGUI.loggingForMessageBox.setHides(false);
					Control.view.invalidate();
					
					Builder.buildAndRunOrDebug(compiler, null, FileListToCompile_Mode.AllInProject, RunOrDebug.Run);
					
					this.runOrDebug = RunOrDebug.Run;
				}
			}
		}
		else {
			// step return
			BreakPoint.clearBreakPointsForStepOver();
			ClassFileRunner.addToDebugCommand("step up\r\n");
		}
	}
	
	/** Initializes CommonGUI.textViewInput, CommonGUI.textViewConsole, CommonGUI.textViewDebug
	 * and deletes Console, Debug, ErrorFile_Console, ErrorFile_Debug
	 */
	void resetInputConsoleDebugAndError() {
		try {
			CommonGUI.textViewInput.initialize();
			CommonGUI.textViewConsole.initialize();
			CommonGUI.textViewDebug.initialize();
			File inputFile = new File(Common_Settings.pathInput);
			inputFile.delete();
			File consoleFile = new File(Common_Settings.pathConsoleInputAndError+File.separator+"Console");
			consoleFile.delete();
			File debugFile = new File(Common_Settings.pathConsoleInputAndError+File.separator+"Debug");
			debugFile.delete();
			File ErrorFile_ConsoleFile = new File(Common_Settings.pathConsoleInputAndError+File.separator+"ErrorFile_Console");
			ErrorFile_ConsoleFile.delete();
			File ErrorFile_DebugFile = new File(Common_Settings.pathConsoleInputAndError+File.separator+"ErrorFile_Debug");
			ErrorFile_DebugFile.delete();
		}catch(Exception e) {
			
		}
	}
	
	/**Run1/locals*/
	void buttonRun1_handler() {
		if (this.runOrDebug==RunOrDebug.Run) {
			ArrayList modifiedCompiler = CompilerCache.isProjectModified();
			if (modifiedCompiler.count!=0) {
				this.dialogState = SaveDialogState.Run1;
				this.saveDialog.Text = "Do you want to save ";
				this.saveDialog.setText(CompilerCache.toString_isProjectModified(modifiedCompiler) + "?");
				this.saveDialog.open(this, true);
			}
			else {
				if (compiler!=null) {
					resetInputConsoleDebugAndError();
					
					CommonGUI.loggingForMessageBox.setText(true, "Building all java files in "+compiler.data.packageName+"...", false);
					CommonGUI.loggingForMessageBox.setHides(false);
					Control.view.invalidate();
					
					Builder.buildAndRunOrDebug(compiler, compiler.data.filename, /*FileListToCompile_Mode.PartOr1*/FileListToCompile_Mode.AllInProject, RunOrDebug.Run);
					
					this.runOrDebug = RunOrDebug.Run;
				}
			}
		}
		else {
			// locals
			ClassFileRunner.replaceDebugCommand("locals\r\n");
		}
	}
	
	public void newDocument_handler(Object sender) {
		if (this.compiler==null) {
			CommonGUI.editText_compiler.initialize();
			return;
		}
		
		String packageDir = FileHelper.getDirectory(this.compiler.data.filename);
		CommonGUI.editText_compiler.initialize();		
		
		String filePath = null;
		java.util.Random rd = new java.util.Random(); 
		while (true) {
			String filename = "" + rd.nextInt(1000);
			filePath = packageDir + File.separator + filename+".txt";			
			if (!new File(filePath).exists()) break;
		}
		try {
			new File(filePath).createNewFile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		this.loadCompilerDocument(filePath);
		//this.setText(0, compiler.data.mBuffer.toHighArray_CodeChar());
		
		CommonGUI.loggingForMessageBox.setText(true, 
				"Succeeded creating "+filePath, false);
		CommonGUI.loggingForMessageBox.setHides(false);
	}
	
	void newJavaClassDialog_handler(Object sender) {
		NewJavaClassDialog dialog = (NewJavaClassDialog) sender;
		if (dialog.getIsOK()) {
			CommonGUI.editText_compiler.initialize();
			
			String packageName = dialog.editTextPackage.getText2();
			String className = dialog.editTextClass.getText2();
			boolean inputsMainFunc = dialog.buttonMainFunc.getIsSelected();
			NewJavaFile.createNewJavaFile(packageName, className, inputsMainFunc);
			String filePath = Common_Settings.pathProjectSrc+File.separator+packageName.replace('.', File.separatorChar)+
					File.separator+className+".java";
			
			this.loadCompilerDocument(filePath);
			this.setText(0, compiler.data.mBuffer.toHighArray_CodeChar());
			
			CommonGUI.loggingForMessageBox.setText(true, 
					"Succeeded creating "+packageName+"."+className, false);
			CommonGUI.loggingForMessageBox.setHides(false);
		}
	}
	
	
	
	void saveModifiedCompiler(Compiler compilerLocal) {
		// 바뀐 내용을 저장한다.
		HighArray_char content = null;
		if (this.compiler==compilerLocal) {
			content = getText4();
		}
		else {
			content = compilerLocal.data.getText2();
		}
		try {
			
			IO.writeString_CRLF(compilerLocal.data.filename, content, TextFormat.UTF_8, false, 
					CommonGUI.fileDialog.originalOrCRLFOrLF, true);
		}catch(Exception e2) {
			// compiler.filename이 잘못되었을 경우
		}
		
		compilerLocal.data.isModified = false;
		if (this.compiler==compilerLocal) {
			setIsModified(false);
		}
		CommonGUI.editText_compiler.mDITabList.setModifiedSymbol(compilerLocal.data.filename, compilerLocal.data.isModified);
	}
	
	void saveFile(String filePath) {
		Compiler compilerLocal = CompilerCache.findCompiler(filePath);
		if (compilerLocal!=null) {
			this.saveModifiedCompiler(compilerLocal);
			return;
		}
		Category category = FileHelper.getFileCategory(filePath);
		if (category==null) return;
		String ext = FileHelper.getExt(filePath);
		if (ext.equals("")) return;
		
		if (ext!=null && category==Category.Text) {
			if (ext.equals(".class") || ext.equals(".o") || ext.equals(".so") || ext.equals(".obj") || ext.equals(".exe")) return;
			
			// 바뀐 내용을 저장한다.
			ReturnOfReadString content = IO.readString(filePath);
			try {
				IO.writeString_CRLF(filePath, content.result, TextFormat.UTF_8, false, CommonGUI.fileDialog.originalOrCRLFOrLF, true);
			}catch(Exception e2) {
				// compiler.filename이 잘못되었을 경우
			}
		}
		
	}
	
	/*static class Thread_saveModifiedCompilerList extends Thread {
		private EditText_Compiler editText;
		private ArrayList modifiedCompilerList;
		Thread_saveModifiedCompilerList(EditText_Compiler editText, ArrayList modifiedCompilerList) {
			this.editText = editText;
			this.modifiedCompilerList = modifiedCompilerList;
		}
		public void run() {
			editText.saveModifiedCompilerList_sub(modifiedCompilerList);
			Control.view.postInvalidate();
		}
	}
	
	void saveModifiedCompilerList(ArrayList modifiedCompilerList) {
		Thread_saveModifiedCompilerList thread = new Thread_saveModifiedCompilerList(this, modifiedCompilerList);
		thread.start();
	}*/
	
	void saveModifiedCompilerList(ArrayList modifiedCompilerList) {
		int i;
		for (i=0; i<modifiedCompilerList.count; i++) {
			Compiler compilerLocal = (Compiler) modifiedCompilerList.getItem(i);
			saveModifiedCompiler(compilerLocal);
		}
	}
		
	
	void saveDialog_handler(Object sender) {
		SaveDialog dialog = (SaveDialog) sender;
		ArrayList modifiedCompilerList = null;
		if (dialogState!=SaveDialogState.CloseDocument) {
			modifiedCompilerList = CompilerCache.isProjectModified();
		}
		else {
			Compiler modifiedCompiler = CompilerCache.findCompiler(filePath_closeCompilerDocument);
			modifiedCompilerList = new ArrayList(1);
			modifiedCompilerList.add(modifiedCompiler);
		}
		Builder.modifiedCompilers = (ArrayList) modifiedCompilerList.clone();
		
		
		if (dialog.getIsOK()) {	// OK
			if (modifiedCompilerList.count!=0) {
				this.saveModifiedCompilerList(modifiedCompilerList);
			}
		}//if (dialog.getIsOK()) {
		else {
			// OK without saving
			if (dialogState==SaveDialogState.NewProject || dialogState==SaveDialogState.OpenProject ||
					dialogState==SaveDialogState.CloseProject || dialogState==SaveDialogState.CloseDocument || 
					dialogState==SaveDialogState.Destroy) {
				// don't save. Erase classes in cache.
				if (modifiedCompilerList.count!=0) {
					int i, j;
					for (i=0; i<modifiedCompilerList.count; i++) {
						Compiler compilerLocal = (Compiler) modifiedCompilerList.getItem(i);
						CompilerCache.deleteCompiler(compilerLocal.data.filename);				
						for (j=0; j<compilerLocal.data.mlistOfAllDefinedClasses.count; j++) {
							FindClassParams c = (FindClassParams) compilerLocal.data.mlistOfAllDefinedClasses.getItem(j);
							ClassCache.deleteClassInClassCache(c, 0);
						}
						compilerLocal.data.isModified = false;
						CommonGUI.editText_compiler.mDITabList.setModifiedSymbol(compilerLocal.data.filename, compilerLocal.data.isModified);
						if (this.compiler==compilerLocal) {
							setIsModified(false);
						}
					}
				}
			}
			else {
				// When build, run, debug, save modified files.
				this.saveModifiedCompilerList(modifiedCompilerList);
			}
		}
		
		// OK, OK without saving
		if (dialogState==SaveDialogState.NewProject) {
			this.buttonNewProject_handler();
		}
		else if (dialogState==SaveDialogState.OpenProject) {
			this.buttonOpenProject_handler();
		}
		else if (dialogState==SaveDialogState.CloseProject) {
			this.buttonCloseProject_handler();
		}
		else if (dialogState==SaveDialogState.CloseDocument) {
			this.mDITabList.closeTabButton_sub(this.filePath_closeCompilerDocument);
		}
		else if (dialogState==SaveDialogState.Destroy) {			
			Control.exit(false);
		}
		
		else if (dialogState==SaveDialogState.Build) {				
			this.buttonBuild_handler();
		}
		else if (dialogState==SaveDialogState.BuildAll) {				
			this.buttonBuildAll_handler();
		}				
		else if (dialogState==SaveDialogState.Run) {
			this.buttonRun_handler();
		}
		else if (dialogState==SaveDialogState.Run1) {
			this.buttonRun1_handler();
		}
		else if (dialogState==SaveDialogState.Debug) {
			this.buttonDebug_handler();
		}
		
	}
	
	
	void selectWord() {
		int indexInmBuffer = CompilerStatic.findWord(compiler, cursorPos.x, cursorPos.y);
		Point startP1 = CompilerStatic.getCursorPosInSrc(compiler, indexInmBuffer);
		Point endP1 = new Point(startP1.x+compiler.data.mBuffer.getItem(indexInmBuffer).count-1, startP1.y);
		FunctionOfEditText.makeSelectIndices(this, true, startP1, endP1);
		this.isSelecting = true;
	}
		
	public void onTouchEvent(Object sender, MotionEvent e) {
		if ((sender instanceof IntegrationKeyboard) && compiler!=null && 
				compiler.data.menuClassAndMemberListWhenInputtingDot!=null && !compiler.data.menuClassAndMemberListWhenInputtingDot.getHides()) {
			IntegrationKeyboard keyboard = (IntegrationKeyboard) sender;
			String key = keyboard.key;
			if (compiler.data.menuClassAndMemberListWhenInputtingDot.filter.equals("all")) {
				compiler.data.menuClassAndMemberListWhenInputtingDot.filter = key;
			}
			else {
				compiler.data.menuClassAndMemberListWhenInputtingDot.filter += key;
			}
			compiler.data.menuClassAndMemberListWhenInputtingDot.filter = compiler.data.menuClassAndMemberListWhenInputtingDot.filter.toLowerCase();
			this.inputDot(compiler, compiler.data.menuClassAndMemberListWhenInputtingDot.filter);
			return;
		}
		super.onTouchEvent(sender, e);
		if (sender==this) {
			// 에디터 영역내를 클릭시에만
			//this.selectWord();
			
			CurPathText.setCurPathTextPlusProjectName(compiler, cursorPos.x, cursorPos.y, this.getShowsCurPath());
		}
		
		if (sender instanceof Button) {
			Button button = (Button)sender;
			if (this.buttonNewProject!=null && button.iName==this.buttonNewProject.iName) {
				buttonNewProject_handler();
			}
			else if (this.buttonOpenProject!=null && button.iName==this.buttonOpenProject.iName) {
				buttonOpenProject_handler();
			}
			else if (this.buttonCloseProject!=null && button.iName==this.buttonCloseProject.iName) {
				buttonCloseProject_handler();
			}
			else if (this.buttonNewClass!=null && button.iName==this.buttonNewClass.iName) {
				this.buttonNewClass_handler();
			}
			if (this.isBuildAndRunEnable()) {				
				if (this.buttonBuild!=null && button.iName==this.buttonBuild.iName) {
					this.buttonBuild_handler();
				}
				else if (this.buttonBuildAll!=null && button.iName==this.buttonBuildAll.iName) {
					this.buttonBuildAll_handler();
				}
				else if (this.buttonRun!=null && button.iName==this.buttonRun.iName) {
					this.buttonRun_handler();
				}
				else if (this.buttonRun1!=null && button.iName==this.buttonRun1.iName) {					
					this.buttonRun1_handler();
				}
				else if (this.buttonDebug!=null && button.iName==this.buttonDebug.iName) {					
					buttonDebug_handler();
				}
				else if (this.buttonCancelBuild!=null && button.iName==this.buttonCancelBuild.iName) {					
					buttonCancelBuild_handler();
				}
				else if (this.buttonToggleBreakpoint!=null && button.iName==this.buttonToggleBreakpoint.iName) {					
					buttonToggleBreakpoint_handler();
				}
				else if (this.buttonRemoveAllBreakpoints!=null && button.iName==this.buttonRemoveAllBreakpoints.iName) {					
					buttonRemoveAllBreakpoints_handler();
				}
				else if (this.buttonOpenDecl!=null && button.iName==this.buttonOpenDecl.iName) {
					buttonOpenDecl_handler();
				}
				else if (this.buttonProblems!=null && button.iName==this.buttonProblems.iName) {
					ErrorList ownErrors = CompilerStatic.errors.findErrors(compiler.data.filename);
					ErrorList.showErrors(ownErrors);
					CompilerStatic.menuProblemList_EditText.open(true, this);
				}
				else if (this.buttonProblemsAll!=null && button.iName==this.buttonProblemsAll.iName) {
					ErrorList.showErrors(CompilerStatic.errors);
					CompilerStatic.menuProblemList_EditText.open(true, this);
				}
				else if (this.buttonInput!=null && button.iName==this.buttonInput.iName) {
					CommonGUI.textViewInput.open(true);
				}
				else if (this.buttonConsole!=null && button.iName==this.buttonConsole.iName) {	
					CommonGUI.textViewConsole.open(true);
				}
				else if (this.buttonDebugView!=null && button.iName==this.buttonDebugView.iName) {	
					CommonGUI.textViewDebug.open(true);
				}
			}//if (this.isBuildAndRunEnable()) {
			
			if (this.buttonUsedMemory!=null && button.iName==this.buttonUsedMemory.iName) {
				String text = null;
				text = String.valueOf(MemoryManager.sumMemory());
				CommonGUI.loggingForMessageBox.setText(true, text, false);
				CommonGUI.loggingForMessageBox.setHides(false);
			}
			return;
		} // if (sender instanceof Button) {
		else if (sender instanceof SaveDialog) {
			saveDialog_handler(sender);
		}//else if (sender instanceof SaveDialog) {
		else if (sender instanceof FileDialog) {
			fileDialog_handler(sender);
		}
		else if (sender instanceof NewProjectDialog) {
			this.newProjectDialog_handler(sender);
		}
		else if (sender instanceof NewJavaClassDialog) {
			this.newJavaClassDialog_handler(sender);
		}//else if (sender instanceof NewJavaClassDialog) {
		else if (sender instanceof MenuClassAndMemberListWhenInputtingDot) {
			menuClassAndMemberListWhenInputtingDot_handler(sender);
		}
		
		if (e==null) {
			// Compiler의 MenuProblemList_EditText의 오류EditText을 터치시 호출
			if (sender instanceof MenuProblemList_EditText) {
				MenuProblemList_EditText list = (MenuProblemList_EditText)sender;
				int countOfNewLineChars = list.countOfNewLineChars;
				list.open(false);
				
				this.moveToCursorPos(list.countOfCol, countOfNewLineChars);
				
				CurPathText.setCurPathTextPlusProjectName(compiler, cursorPos.x, cursorPos.y, this.getShowsCurPath());
				
				if (scrollMode==ScrollMode.Both) {
					com.gsoft.common.compiler.Compiler_types_Base.Error selectedError = list.selectedError;
					CommonGUI.loggingForMessageBox.setText(true, selectedError.msg, false);
					CommonGUI.loggingForMessageBox.open(true);
				}
				
			}
			else if (sender instanceof MenuClassAndMemberList) {
				MenuClassAndMemberList classList = (MenuClassAndMemberList)sender;
				Point cursorPosToMove = classList.cursorPosToMove;
				classList.open(false);
				
				this.moveToCursorPos(cursorPosToMove.x, cursorPosToMove.y);
				
				CurPathText.setCurPathTextPlusProjectName(compiler, cursorPos.x, cursorPos.y, this.getShowsCurPath());
				
				if (scrollMode==ScrollMode.Both) {
					widthOfhScrollPos = 0;
					setHScrollPos();
					setHScrollBar();
				}
				
			}
			// Compiler의 MenuProblemList의 오류버튼을 터치시 호출
			else if (sender instanceof MenuProblemList) {
				MenuProblemList list = (MenuProblemList)sender;
				int countOfNewLineChars = list.countOfNewLineChars;
				list.open(false);
			
				this.moveToCursorPosY(countOfNewLineChars);
				
				CurPathText.setCurPathTextPlusProjectName(compiler, cursorPos.x, cursorPos.y, this.getShowsCurPath());
				
				if (scrollMode==ScrollMode.Both) {
					widthOfhScrollPos = 0;
					setHScrollPos();
					setHScrollBar();
				}
			}
			
			if (Common_Settings.CurrentSystem.equals(Common_Settings.CurrentSystemIsJava) &&
					Common_Settings.settings.isTripleBuffering)  {
				this.drawToImage(mCanvas);
			}
		}
	}
	
	private void buttonCancelBuild_handler() {
		
		Builder.cancelBuild();
	}
	
	public void resetButtonProblemsAndProblemsAllColor() {
		CommonGUI.editText_compiler.buttonProblems.setBackColor(Color.CYAN);
		CommonGUI.editText_compiler.buttonProblemsAll.setBackColor(Color.CYAN);
	}


	void menuClassAndMemberListWhenInputtingDot_handler(Object sender) {
		MenuClassAndMemberListWhenInputtingDot menu = (MenuClassAndMemberListWhenInputtingDot) sender;
		menu.open(false);
		
		Button selectedItem = menu.selectedItem;
		Object addedInfo = selectedItem.addedInfo;
		CodeString curLine = this.textArray[cursorPos.y];
		CodeString name = null;
		Point cursorPos_backup = cursorPos;
		if (addedInfo==null) {
			name = new CodeString(selectedItem.text, Common_Settings.textColor);
			curLine.insert(name.listCodeChar, 0, cursorPos.x, name.count);
			
			cursorPos.x += name.count;
		}
		else {
			if (addedInfo instanceof FindVarParams) {
				FindVarParams var = (FindVarParams) addedInfo; 
				name = new CodeString(var.fieldName, Common_Settings.textColor);
				curLine.insert(name.listCodeChar, 0, cursorPos.x, name.count);
				
				cursorPos.x += name.count;
			}
			else if (addedInfo instanceof FindFunctionParams) {
				FindFunctionParams func = (FindFunctionParams) addedInfo; 
				name = new CodeString(func.name+"()", Common_Settings.textColor);
				curLine.insert(name.listCodeChar, 0, cursorPos.x, name.count);
				
				cursorPos.x += name.count;
			}
			else if (addedInfo instanceof FindClassParams) {
				FindClassParams c = (FindClassParams) addedInfo;
				name = new CodeString(CompilerHelper.getShortName(c.name), Common_Settings.textColor);
				curLine.insert(name.listCodeChar, 0, cursorPos.x, name.count);
				
				cursorPos.x += name.count;
			}
			else if (addedInfo instanceof FindPackageParams) {
				FindPackageParams c = (FindPackageParams) addedInfo;
				name = new CodeString(c.packageName, Common_Settings.textColor);
				curLine.insert(name.listCodeChar, 0, cursorPos.x, name.count);
				
				cursorPos.x += name.count;
			}
		}
		if (compiler!=null) {				
			this.update(cursorPos_backup.x+1, cursorPos_backup.y, name.str, false);
		}
	}
	
}