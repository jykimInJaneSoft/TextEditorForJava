package com.gsoft.common.compiler;

import com.gsoft.common.CommonGUI;
import com.gsoft.common.FileHelper;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.util.ArrayList;

import com.gsoft.common.compiler.Compiler;

/** compiler document cache*/
public class CompilerCache {
	/** compiler document list*/
	public static ArrayList listOfCompilers = new ArrayList(10);
	
	public static ArrayList cloneCache() {
		ArrayList listOfCompilersCloned = new ArrayList(listOfCompilers.count);
		int i;
		for (i=0; i<listOfCompilers.count; i++) {
			listOfCompilersCloned.add(listOfCompilers.getItem(i));
		}
		return listOfCompilersCloned;
	}
	
	/** find a compiler with filename*/
	public static Compiler findCompiler(String filename) {
		int i;
		for (i=0; i<listOfCompilers.count; i++) {
			Compiler c = (Compiler) listOfCompilers.getItem(i);
			if (c==null) continue;
			if (c.data.filename.equals(filename)) {
				return c;
			}
		}
		return null;
	}
	
	/** delete a compiler with filename. Not erase compiler.
	 * Refer to editText_Compiler.saveDialog_handler()*/
	public static void deleteCompiler(String filename) {
		int i;
		for (i=0; i<listOfCompilers.count; i++) {
			Compiler c = (Compiler) listOfCompilers.getItem(i);
			if (c==null) continue;
			if (c.data.filename.equals(filename)) {
				listOfCompilers.list[i] = null;
			}
		}
	}
	
	/** find a compiler with fullClassName*/
	public static Compiler findCompilerWithfullClassName(String fullClassName) {
		int i, j;
		for (i=0; i<listOfCompilers.count; i++) {
			Compiler c = (Compiler) listOfCompilers.getItem(i);
			if (c==null) continue;
			for (j=0; j<c.data.mlistOfAllDefinedClasses.count; j++) {
				FindClassParams classParams = (FindClassParams) c.data.mlistOfAllDefinedClasses.getItem(j);
				if (classParams.name.equals(fullClassName)) {
					return c;
				}
			}
		}
		return null;
	}
	
	/** add to cache with compiler. 
	 * CompilerCache에 이미 있으면 update(compiler)를 하고 그렇지않으면 추가한다.*/
	public static void add(Compiler compiler) {
		Compiler r = findCompiler(compiler.data.filename);
		if (r!=null) {
			update(r);
		}
		else {
			listOfCompilers.add(compiler);
		}
	}
	
	/**cache update with compiler*/
	public static void update(Compiler compiler) {
		int i;
		for (i=0; i<listOfCompilers.count; i++) {
			Compiler c = (Compiler) listOfCompilers.getItem(i);
			if (c==null) continue;
			if (c.data.filename.equals(compiler.data.filename)) {
				listOfCompilers.list[i] = compiler;
				return;
			}
		}
	}
	
	public static void destroy() {
		int i;
		for (i=0; i<listOfCompilers.count; i++) {
			Compiler c = (Compiler) listOfCompilers.getItem(i);
			if (c==null) continue;
			c.destroy();			
			listOfCompilers.list[i] = null;
		}
		listOfCompilers.count = 0;
			
	}
	
	
	
	public static ArrayList resetModifiedSymbols() {
		//if (!Common_Settings.settings.usesClassCache) return null;
		int i;
		ArrayList r = new ArrayList(5);
		for (i=0; i<CompilerCache.listOfCompilers.count; i++) {
			Compiler compilerLocal = (Compiler) CompilerCache.listOfCompilers.getItem(i);
			if (compilerLocal==null) continue;
			CommonGUI.editText_compiler.mDITabList.setModifiedSymbol(compilerLocal.data.filename, compilerLocal.data.isModified);
		}
		return r;
	}
	
	/**Returns modified Compiler[] in CompilerCache.listOfCompilers
	 * @return Compiler[]*/
	public static ArrayList isProjectModified() {
		//if (!Common_Settings.settings.usesClassCache) return null;
		int i;
		ArrayList r = new ArrayList(5);
		for (i=0; i<CompilerCache.listOfCompilers.count; i++) {
			Compiler compilerLocal = (Compiler) CompilerCache.listOfCompilers.getItem(i);
			if (compilerLocal==null) continue;
			if (compilerLocal.data.isModified) {
				r.add(compilerLocal);
			}
		}
		return r;
	}
	
	public static String toString_isProjectModified(ArrayList resultOfIsProjectModified) {
		int i;
		String r = "";
		if (resultOfIsProjectModified.count>0) {
			Compiler compilerLocal = (Compiler) resultOfIsProjectModified.getItem(0);
			String filename = FileHelper.getFilename(compilerLocal.data.filename);
			r += filename;
		}
		
		for (i=1; i<resultOfIsProjectModified.count; i++) {
			Compiler compilerLocal = (Compiler) resultOfIsProjectModified.getItem(i);
			String filename = FileHelper.getFilename(compilerLocal.data.filename);
			r += ", "+filename;
		}
		return r;
	}
}
