package com.gsoft.common.compiler.bytecode;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.CompilerData;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.CompilerStatic;
import com.gsoft.common.compiler.Compiler_types.CategoryOfControls;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.Compiler_types.FindControlBlockParams;
import com.gsoft.common.compiler.Compiler_types.FindFunctionParams;
import com.gsoft.common.compiler.Compiler_types.FindVarParams;
import com.gsoft.common.compiler.Compiler_types.FindVarUseParams;
import com.gsoft.common.compiler.Compiler_types_Base.Block;
import com.gsoft.common.compiler.Compiler_types_Base.FindStatementParams;
import com.gsoft.common.compiler.Compiler_types_Special.FindSpecialBlockParams;
import com.gsoft.common.util.Array;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListIReset;
import com.gsoft.common.util.HighArray;

import com.gsoft.common.compiler.bytecode.StackMapTable_Helper;
import com.gsoft.common.compiler.bytecode.ControlBlock;
import com.gsoft.common.compiler.bytecode.ByteCodeGeneratorForClass;
import com.gsoft.common.compiler.bytecode.HighArrayCharForByteCode;
import com.gsoft.common.compiler.bytecode.Specials;
import com.gsoft.common.compiler.bytecode.ByteCode_Types;
import com.gsoft.common.compiler.bytecode.ByteCode_Helper;
import com.gsoft.common.compiler.bytecode.TypeCast;

public class LocalVar {
	
	/** 타입이름이 같은 재사용할 수 있는 변수를 스코프를 고려해서 찾고 indexOfLocalVariableTable을 센다.
	 *  func가 static이 아닌 경우 this포인터는 0번을 차지한다.
		 * indexOfLocalVariableTable는 함수별로 사용되는 LocalVariableTable에서의 특정 로컬 변수의 인덱스, 
		 * aload, iload 등은 1을 더하고 lload, lstore, dload, dstore는 2를 더한다.
		 * Compiler.FindAllClassesAndItsMembers2() 끝부분에서 호출되어 
		 * 일괄적으로 정해지고(FindVarParams.indexOfLocalVariableTable) 
		 * 바이트코드 생성시에 aload, iload, lload, lstore 등에서 로컬변수의 인덱스가 필요할 때
		 * FindVarParams.indexOfLocalVariableTable에서 얻어진다.*/
	public static void processLocalVars(FindFunctionParams func) {
		int i;
		int len = func.listOfVariableParams.count;
		boolean isStatic = func.accessModifier.isStatic;
		int indexOfLocalVariableTable = 0;
		
		if (isStatic) {
			
		}
		else { // this가 추가되기 때문에 1을 더해준다. this는 0 index를 차지한다.
			indexOfLocalVariableTable++;
		}
		
		func.listOfVariableParamsBeforeProcessLocalVars = func.listOfVariableParams;
		ArrayListIReset newlistOfVariableParams = new ArrayListIReset(func.listOfVariableParams.count);
		
		
		for (i=0; i<len; i++) {
			FindVarParams v = (FindVarParams) func.listOfVariableParamsBeforeProcessLocalVars.getItem(i);
			v.indexOfLocalVarsInFunctionBeforeProcessLocalVars = i;
			
			boolean found = false;
			
			
			FindVarParams sharedVar = findReusableLocalVar_processLocalVars(func, newlistOfVariableParams, v);
			if (sharedVar!=null) found = true;
			
			// 공유변수가 아니면 newlistOfVariableParams에 추가한다.
			if (!found) {
				newlistOfVariableParams.add(v);
				v.usedInProcessLocalVars = false;
				v.indexOfLocalVariableTable = indexOfLocalVariableTable;
				if (v.typeName==null) {
				}
				if (v.typeName.equals("long") || v.typeName.equals("double")) {
					indexOfLocalVariableTable += 2;
				}
				else {
					indexOfLocalVariableTable++;
				}
			}		
			
		}//for (i=0; i<len; i++) {
		
		func.listOfVariableParams = newlistOfVariableParams;
		// 불필요한 지역변수들은 제거되었으므로 indexOfLocalVarsInFunction을 다시 센다.
	
		
		// 불필요한 지역변수들은 제거되었으므로 indexOfLocalVariableTable을 다시 센다.
		for (i=0; i<func.listOfVariableParamsBeforeProcessLocalVars.count; i++) {
			FindVarParams v = (FindVarParams) func.listOfVariableParamsBeforeProcessLocalVars.getItem(i);
			if (v.sharedVar!=null) {
				v.indexOfLocalVariableTable = v.sharedVar.indexOfLocalVariableTable;
			}
		}
		
		// 불필요한 지역변수들은 제거되었으므로 indexOfLocalVariableTable을 다시 센다.
		for (i=0; i<func.listOfVariableParamsBeforeProcessLocalVars.count; i++) {
			FindVarParams v = (FindVarParams) func.listOfVariableParamsBeforeProcessLocalVars.getItem(i);
			if (v.sharedVar!=null) {
				changeAllLocalVarUses_processLocalVars(func, v);
			}
		}
	}
	
	/** localVar에 연결된 모든 varUse들의 varDecl과 varDeclBeforeProcessLocalVars을 
	 * 공유변수와 원래변수로 바꾼다. processLocalVars()에서 호출한다.
	 * @param func
	 * @param localVar
	 */
	public static void changeAllLocalVarUses_processLocalVars(FindFunctionParams func, FindVarParams localVar) {
		int i;
		HighArray listOfVarUses = localVar.getListOfVarUses();
		for (i=0; i<listOfVarUses.count; i++) {
			FindVarUseParams varUse = (FindVarUseParams) listOfVarUses.getItem(i);
			varUse.varDeclBeforeProcessLocalVars = varUse.varDecl;
			varUse.varDecl = localVar.sharedVar;
		}
	}
	
	
	/** func의 지역변수 리스트에서 var의 공유변수를 찾는다. 
	 * 그리고 공유변수를 찾기 전에 var의 스코프 이전에 끝나는 변수들의 usedInProcessLocalVars과 sharedBy를 해제한다.
	 * var가 v를 공유하면 v의 usedInProcessLocalVars을 true, sharedBy는 var로 설정한다.
	 *  타입이름이 같은 재사용할 수 있는 변수를 스코프를 고려해서 찾는다.<br>
			 func() {<br>
			     block1 {<br>
						int a;<br>
			     }<br>
				   block2 {<br>
						int b;<br>
			     }<br>
			 }<br>
			 b는 a를 공유한다.<br>
			 <br>
			  예제(example) <br> 
			 for (int i=0; i<arr.length; i++) {<br>
				   int j = 0;<br>
				   System.out.println("A.arr["+i+"]:"+arr[i+j]);<br>
			 }<br>
<br>
			 for (i=0; i<color1.length; i++) {<br>
				 int n = 0, k=120;<br>
				 System.out.println("A.color1["+i+"]:"+color1[i]);<br>
			 }<br>
			 여기에서 n은 j를 공유하고 k는 n이 j를 이미 공유하고 있기 때문에 continue한 후 
			 새로운 기억장소를 할당받아야 한다.
					 
    */
	public static FindVarParams findReusableLocalVar_processLocalVars(FindFunctionParams func, ArrayListIReset newlistOfVariableParams, FindVarParams var) {
		int i;
		if (var.varNameIndex()==982) {
		}
		if (var.indexOfLocalVarsInFunctionBeforeProcessLocalVars==12) {
		}
		// var의 공유변수를 찾을때 var 이전의 스코프가 끝난 변수들에 대해서 사용중이 아니라고 표시한다.
		for (i=0; i<func.listOfVariableParamsBeforeProcessLocalVars.count; i++) {
			FindVarParams v = (FindVarParams) func.listOfVariableParamsBeforeProcessLocalVars.getItem(i);
			if (v==var) break; // 현재 var까지
			if (v.endIndexOfScope()<var.startIndexOfScope()) {
				if (v.sharedBy==null) {
					// v를 공유하는 변수가 없으면
					v.usedInProcessLocalVars = false;
				}
				else {
					// v를 공유하는 변수가 있으면 그 변수의 스코프가 var 이전에 끝날때 해제한다.
					if (v.sharedBy.endIndexOfScope()<var.startIndexOfScope()) {
						v.usedInProcessLocalVars = false;
						v.sharedBy = null;
					}
				}
				if (v.sharedVar!=null) {
					// v가 어떤 변수를 공유하고 있으면
					if (v.sharedVar.sharedBy==null) {
						v.sharedVar.usedInProcessLocalVars = false;
						v.sharedVar.sharedBy = null;
					}
					else {
						// v를 공유하는 변수가 있으면 그 변수의 스코프가 var 이전에 끝날때 해제한다.
						if (v.sharedVar.sharedBy.endIndexOfScope()<var.startIndexOfScope()) {
							v.sharedVar.usedInProcessLocalVars = false;
							v.sharedVar.sharedBy = null;
						}
					}
				}
			}
		}
		
		for (i=0; i<newlistOfVariableParams.count; i++) {
			FindVarParams v = (FindVarParams) newlistOfVariableParams.getItem(i);
			if (v.endIndexOfScope()>=var.startIndexOfScope()) continue;
			else {
				// v가 사용중이 아니고 타입이 같으면 var는 v를 공유한다.
				if (!v.usedInProcessLocalVars) {
					if (var.typeName.equals(v.typeName)) {
						// v는 중복되는 변수, vAdded는 v와 공유하는 변수, v는 vAdded를 공유한다.
						var.sharedVar = v;
						v.usedInProcessLocalVars = true;
						v.sharedBy = var;
						return v;
					}					
				}
			}
		}
		return null;
	}
	
	/**최상위 if, else if 블록을 찾는다.*/
	static FindControlBlockParams getOuterIFBlockWithOtherBlock(Compiler compiler, Block parent) {
		while (true) {
			if (parent==null) return null;
			if (parent instanceof FindControlBlockParams) {
				FindControlBlockParams c = (FindControlBlockParams) parent;
				if (!c.isFake) {
					if (c.getName().equals("if") || c.getName().equals("else if")) {
						//return c;
						if (StackMapTable_Helper.containsOtherControlBlock(c)!=null) {
							FindControlBlockParams r = getOuterIFBlockWithOtherBlock(compiler, c.parent);
							if (r==null) {
								return c;
							}
						}
					}
						
				}
			}
			if (parent.parent instanceof FindFunctionParams) return null;
			if (parent.parent!=null) parent = parent.parent;
			else return null;
		}
	}
	
	/**if, else if의 직접적인 자식 블록 뿐만아니라 내부 블록도 포함한다.*/
	static FindControlBlockParams isVarDefinedInIFBlock(Compiler compiler, FindVarParams var) {
		Block parent = var.parent;
		while (true) {
			if (parent==null) return null;
			if (parent instanceof FindControlBlockParams) {
				FindControlBlockParams c = (FindControlBlockParams) parent;
				if (!c.isFake) {
					if (c.getName().equals("if") || c.getName().equals("else if"))
						return c;
				}
			}
			if (parent.parent instanceof FindFunctionParams) return null;
			if (parent.parent!=null) parent = parent.parent;
			else return null;
		}
	}
	
	/** 최상위 try, catch, finally, synchronized, function 가 아닌 블록을 찾는다.
	 * try, catch, finally, synchronized의 경우에는 null을 리턴한다.*/
	static FindControlBlockParams getOuterBlock(Compiler compiler, Block parent) {
		while (true) {
			if (parent==null) return null;
			if (parent instanceof FindControlBlockParams) {
				FindControlBlockParams c = (FindControlBlockParams) parent;				
				//if (!c.isFake) {
					//if (c.catOfControls!=null) {
						FindControlBlockParams r = getOuterBlock(compiler, c.parent);
						if (r==null) {
							return c;
						}
					//}
				//}
			}
			if (parent.parent instanceof FindFunctionParams) return null;
			if (parent.parent!=null) parent = parent.parent;
			else return null;
		}
	}
	
	/**자바 파일에 정의된 지역변수들에 대해서 블록안에 정의된 모든 지역변수들을 찾는다.
	 * try, catch, finally, synchronized는 제외한다.
	 * @param compiler
	 * @return
	 */
	static ArrayList getLocalVarsDefinedInBlock(Compiler compiler) {
		int i, j;
		CompilerData data = compiler.data;
		ArrayList r = new ArrayList(10); 
		for (i=0; i<data.mlistOfAllFunctions.count; i++) {
			FindFunctionParams func = (FindFunctionParams) data.mlistOfAllFunctions.getItem(i);
			for (j=0; j<func.listOfVariableParams.count; j++) {
				FindVarParams localVar = (FindVarParams) func.listOfVariableParams.getItem(j);
				if (func.isFuncArg(localVar)) continue;
				r.add(localVar);
			}
		}
		return r;
	}
	
	static ArrayList getLocalVarsDefinedInBlock_backup(Compiler compiler) {
		int i, j;
		CompilerData data = compiler.data;
		ArrayList r = new ArrayList(10); 
		for (i=0; i<data.mlistOfAllFunctions.count; i++) {
			FindFunctionParams func = (FindFunctionParams) data.mlistOfAllFunctions.getItem(i);
			for (j=0; j<func.listOfVariableParams.count; j++) {
				FindVarParams localVar = (FindVarParams) func.listOfVariableParams.getItem(j);
				
				if (LocalVar.getOuterBlock(compiler, localVar.parent)!=null) {				
					r.add(localVar);
				}
			}
		}
		return r;
	}
	
	/** Block 안에서 정의된 모든 지역변수들을 원래 블록에서 빼서 최상위 블록에 넣는다.
	 * 그리고 스코프는 원래의 블록을 유지한다.*/
	public static void processLocalVarsDefinedInBlock(Compiler compiler) {
		ArrayList listOfLocalVars = getLocalVarsDefinedInBlock(compiler);
		int i, j;
		// 원래 블록에서 뺀다.
		for (i=0; i<listOfLocalVars.count; i++) {
			FindVarParams var = (FindVarParams) listOfLocalVars.getItem(i);
		
			Block block = var.parent;
			for (j=0; j<block.listOfVariableParams.count; j++) {
				if (block instanceof FindFunctionParams) continue;
				if (block.listOfVariableParams.getItem(j)==var) {
					block.listOfVariableParams.list = Array.Delete(block.listOfVariableParams.list, j, 1);
					block.listOfVariableParams.count--;
					break;
				}
			}
			for (j=0; j<block.listOfStatements.count; j++) {
				if (block.listOfStatements.getItem(j)==var) {
					block.listOfStatements.list = Array.Delete(block.listOfStatements.list, j, 1);
					block.listOfStatements.count--;
					break;
				}
			}
		} // for i
		
		// 새로운 최상위 블록에 넣는다.
		for (i=0; i<listOfLocalVars.count; i++) {
			FindVarParams var = (FindVarParams) listOfLocalVars.getItem(i);
					
			// var의 parent를 block의 parent로 바꾸고 scope는 원래의 블록을 유지한다.
			FindFunctionParams func = (FindFunctionParams) CompilerStatic.getParent(var.parent);
			var.blockBeforeMovingFromBlock = var.parent;			
			var.parent = func;
			var.blockAfterMovingFromBlock = func;
			if (var.parent instanceof FindControlBlockParams) {
				FindControlBlockParams controlBlock = (FindControlBlockParams) var.parent;
				var.startIndexOfScope = controlBlock.nameIndex;
				var.endIndexOfScope = controlBlock.endIndex;
			}
			var.movedFromBlock = true;
						
			/*
			Block blockAfterMovingFromBlock = var.blockAfterMovingFromBlock;
						
			ArrayListIReset listOfStatements = blockAfterMovingFromBlock.listOfStatements;
			for (j=0; j<listOfStatements.count; j++) {
				FindStatementParams statement = (FindStatementParams) listOfStatements.getItem(j);
				if (!(statement instanceof FindVarParams)) {
					listOfStatements.insert(j, var);
					break;
				}
			}
			if (listOfStatements.count==0) {
				listOfStatements.add(var);
			}*/
			func.listOfLocalVarsToInitialize.add(var);
		} // for i
	}
	
	/** Block 안에서 정의된 모든 지역변수들을 원래 블록에서 빼서 최상위 블록에 넣는다.
	 * 그리고 스코프는 원래의 블록을 유지한다.*/
	public static void processLocalVarsDefinedInBlock_backup(Compiler compiler) {
		ArrayList listOfLocalVars = getLocalVarsDefinedInBlock(compiler);
		int i, j;
		// 원래 블록에서 뺀다.
		for (i=0; i<listOfLocalVars.count; i++) {
			FindVarParams var = (FindVarParams) listOfLocalVars.getItem(i);
			
			Block block = var.parent;
			for (j=0; j<block.listOfVariableParams.count; j++) {
				if (block.listOfVariableParams.getItem(j)==var) {
					block.listOfVariableParams.list = Array.Delete(block.listOfVariableParams.list, j, 1);
					block.listOfVariableParams.count--;
					break;
				}
			}
			for (j=0; j<block.listOfStatements.count; j++) {
				if (block.listOfStatements.getItem(j)==var) {
					block.listOfStatements.list = Array.Delete(block.listOfStatements.list, j, 1);
					block.listOfStatements.count--;
					break;
				}
			}
		} // for i
		
		// 새로운 최상위 블록에 넣는다.
		for (i=0; i<listOfLocalVars.count; i++) {
			FindVarParams var = (FindVarParams) listOfLocalVars.getItem(i);
			
			FindControlBlockParams controlBlock = (FindControlBlockParams) var.parent;
			// var의 parent를 block의 parent로 바꾸고 scope는 원래의 블록을 유지한다.
			FindControlBlockParams block = LocalVar.getOuterBlock(compiler, controlBlock);
			if (block.getName().equals("else if") || block.getName().equals("else")) {
				block = ControlBlock.getIFBlock(compiler, block);
			}
			else if (block.getName().equals("catch") || block.getName().equals("finally")) {
				block = Specials.getTryBlockOfCatchOrFinally(compiler, block.parent, block.indexInListOfControlBlocksOfParent);
			}
			
			var.blockBeforeMovingFromBlock = var.parent;			
			var.parent = block.parent;
			var.blockAfterMovingFromBlock = block.parent;
			var.startIndexOfScope = controlBlock.nameIndex;
			var.endIndexOfScope = controlBlock.endIndex;
			var.movedFromBlock = true;
			
		
			
			Block blockAfterMovingFromBlock = var.blockAfterMovingFromBlock;
		
			
			ArrayListIReset listOfStatements = blockAfterMovingFromBlock.listOfStatements;
			for (j=0; j<listOfStatements.count; j++) {
				FindStatementParams statement = (FindStatementParams) listOfStatements.getItem(j);
				if (!(statement instanceof FindVarParams)) {
					listOfStatements.insert(j, var);
					break;
				}
			}
		} // for i
	}
	
	/** 최상위 for 루프를 찾는다.*/
	static FindControlBlockParams getOuterForLoopWithOtherBlock(Compiler compiler, Block parent) {
		while (true) {
			if (parent==null) return null;
			if (parent instanceof FindControlBlockParams) {
				FindControlBlockParams c = (FindControlBlockParams) parent;
				if (!c.isFake) {
					if (c.getName().equals("for")) {
						//return c;
						if (StackMapTable_Helper.containsOtherControlBlock(c)!=null) {
							FindControlBlockParams r = getOuterForLoopWithOtherBlock(compiler, c.parent);
							if (r==null) {
								return c;
							}
						}
					}
						
				}
			}
			if (parent.parent instanceof FindFunctionParams) return null;
			if (parent.parent!=null) parent = parent.parent;
			else return null;
		}
	}
	
	
	/**for의 직접적인 자식 블록 뿐만아니라 내부 블록도 포함한다.*/
	static FindControlBlockParams isVarDefinedInForLoop(Compiler compiler, FindVarParams var) {
		Block parent = var.parent;
		while (true) {
			if (parent==null) return null;
			if (parent instanceof FindControlBlockParams) {
				FindControlBlockParams c = (FindControlBlockParams) parent;
				if (!c.isFake) {
					if (c.getName().equals("for"))
						return c;
				}
			}
			if (parent.parent instanceof FindFunctionParams) return null;
			if (parent.parent!=null) parent = parent.parent;
			else return null;
		}
	}
	
	static ArrayList getLocalVarsDefinedInForLoopWithOtherBlock(Compiler compiler) {
		int i, j;
		CompilerData data = compiler.data;
		ArrayList r = new ArrayList(10); 
		for (i=0; i<data.mlistOfAllFunctions.count; i++) {
			FindFunctionParams func = (FindFunctionParams) data.mlistOfAllFunctions.getItem(i);
			for (j=0; j<func.listOfVariableParams.count; j++) {
				FindVarParams localVar = (FindVarParams) func.listOfVariableParams.getItem(j);
				if (LocalVar.getOuterForLoopWithOtherBlock(compiler, localVar.parent)!=null) {
				//if (StackMapTable_Helper.containsOtherControlBlock(block))
					r.add(localVar);
				}
			}
		}
		return r;
	}
	/*
	public static void processLocalVarsDefinedInForLoopWithOtherBlock(Compiler compiler) {
		ArrayList listOfLocalVars = getLocalVarsDefinedInForLoopWithOtherBlock(compiler);
		int i, j;
		for (i=0; i<listOfLocalVars.count; i++) {
			FindVarParams var = (FindVarParams) listOfLocalVars.getItem(i);
			if (var.varNameIndex()==286) {
				int a;
				a=0;
				a++;
			}
			Block block = var.parent;
			for (j=0; j<block.listOfVariableParams.count; j++) {
				if (block.listOfVariableParams.getItem(j)==var) {
					block.listOfVariableParams.list = Array.Delete(block.listOfVariableParams.list, j, 1);
					block.listOfVariableParams.count--;
					break;
				}
			}
			for (j=0; j<block.listOfStatements.count; j++) {
				if (block.listOfStatements.getItem(j)==var) {
					//block.listOfVariableParams.list[j] = null;
					block.listOfStatements.list = Array.Delete(block.listOfStatements.list, j, 1);
					block.listOfStatements.count--;
					break;
				}
			}
		}
		
		for (i=0; i<listOfLocalVars.count; i++) {
			FindVarParams var = (FindVarParams) listOfLocalVars.getItem(i);
			if (var.varNameIndex()==255) {
				int a;
				a=0;
				a++;
			}
			FindControlBlockParams controlBlock = (FindControlBlockParams) var.parent;
			// var의 parent를 forLoop의 parent로 바꾸고 scope는 원래의 블록을 유지한다.
			FindControlBlockParams forLoop = LocalVar.getOuterForLoopWithOtherBlock(compiler, controlBlock);
			var.blockBeforeMovingFromForLoop = var.parent;			
			var.parent = forLoop.parent;
			var.blockAfterMovingFromForLoop = forLoop.parent;
			var.startIndexOfScope = controlBlock.nameIndex;
			var.endIndexOfScope = controlBlock.endIndex;
			var.movedFromForLoop = true;
			
			if (controlBlock.nameIndex()==487) {
				int a;
				a=0;
				a++;
			}
			
			Block blockAfterMovingFromForLoop = var.blockAfterMovingFromForLoop;
			if (!(blockAfterMovingFromForLoop instanceof FindFunctionParams)) { 
				ArrayListIReset listOfVars = blockAfterMovingFromForLoop.listOfVariableParams;
				for (j=0; j<listOfVars.count; j++) {
					FindVarParams v = (FindVarParams) listOfVars.getItem(j);
					if (v.startIndex()>var.startIndex()) {
						listOfVars.insert(j, var);
						break;
					}
				}
			}
			
			ArrayListIReset listOfStatements = blockAfterMovingFromForLoop.listOfStatements;
			for (j=0; j<listOfStatements.count; j++) {
				if (listOfStatements.getItem(j)==forLoop) {
					listOfStatements.insert(j, var);
					break;
				}
			}
		}
	}*/
	
	
	static ArrayList getLocalVarsDefinedInIFBlockWithOtherBlock(Compiler compiler) {
		int i, j;
		CompilerData data = compiler.data;
		ArrayList r = new ArrayList(10); 
		for (i=0; i<data.mlistOfAllFunctions.count; i++) {
			FindFunctionParams func = (FindFunctionParams) data.mlistOfAllFunctions.getItem(i);
			for (j=0; j<func.listOfVariableParams.count; j++) {				
				FindVarParams localVar = (FindVarParams) func.listOfVariableParams.getItem(j);
				if (LocalVar.getOuterIFBlockWithOtherBlock(compiler, localVar.parent)!=null) {
					r.add(localVar);
				}
			}
		}
		return r;
	}
	/*
	public static void processLocalVarsDefinedInIFBlockWithOtherBlock(Compiler compiler) {
		ArrayList listOfLocalVars = getLocalVarsDefinedInIFBlockWithOtherBlock(compiler);
		int i, j;
		for (i=0; i<listOfLocalVars.count; i++) {
			FindVarParams var = (FindVarParams) listOfLocalVars.getItem(i);
			if (var.varNameIndex()==286) {
				int a;
				a=0;
				a++;
			}
			Block block = var.parent;
			for (j=0; j<block.listOfVariableParams.count; j++) {
				if (block.listOfVariableParams.getItem(j)==var) {
					block.listOfVariableParams.list = Array.Delete(block.listOfVariableParams.list, j, 1);
					block.listOfVariableParams.count--;
					break;
				}
			}
			for (j=0; j<block.listOfStatements.count; j++) {
				if (block.listOfStatements.getItem(j)==var) {
					//block.listOfVariableParams.list[j] = null;
					block.listOfStatements.list = Array.Delete(block.listOfStatements.list, j, 1);
					block.listOfStatements.count--;
					break;
				}
			}
		}
		
		for (i=0; i<listOfLocalVars.count; i++) {
			FindVarParams var = (FindVarParams) listOfLocalVars.getItem(i);
			if (var.varNameIndex()==4432) {
				int a;
				a=0;
				a++;
			}
			FindControlBlockParams controlBlock = (FindControlBlockParams) var.parent;
			// var의 parent를 ifBlock의 parent로 바꾸고 scope는 원래의 블록을 유지한다.
			FindControlBlockParams ifBlock = LocalVar.getOuterIFBlockWithOtherBlock(compiler, controlBlock);
			
			if (!controlBlock.getName().equals("if")) {
				ifBlock = ControlBlock.getIFBlock(compiler, ifBlock);
			}
			var.blockBeforeMovingFromIFBlock = var.parent;			
			var.parent = ifBlock.parent;
			var.blockAfterMovingFromIFBlock = ifBlock.parent;
			var.startIndexOfScope = controlBlock.nameIndex;
			var.endIndexOfScope = controlBlock.endIndex;
			var.movedFromIFBlock = true;
			
			if (controlBlock.nameIndex()==487) {
				int a;
				a=0;
				a++;
			}
			
			Block blockAfterMovingFromIFBlock = var.blockAfterMovingFromIFBlock;
			if (!(blockAfterMovingFromIFBlock instanceof FindFunctionParams)) { 
				ArrayListIReset listOfVars = blockAfterMovingFromIFBlock.listOfVariableParams;
				for (j=0; j<listOfVars.count; j++) {
					FindVarParams v = (FindVarParams) listOfVars.getItem(j);
					if (v.startIndex()>var.startIndex()) {
						listOfVars.insert(j, var);
						break;
					}
				}
				if (listOfVars.count==0) {
					listOfVars.add(var);
				}
			}
			
			ArrayListIReset listOfStatements = blockAfterMovingFromIFBlock.listOfStatements;
			for (j=0; j<listOfStatements.count; j++) {
				if (listOfStatements.getItem(j)==ifBlock) {
					listOfStatements.insert(j, var);
					break;
				}
			}
		}
	}*/
	
	
	/*
	static ArrayList getLocalVarsDefinedAfterContinue(Compiler compiler) {
		int i, j;
		CompilerData data = compiler.data;
		ArrayList r = new ArrayList(10); 
		for (i=0; i<data.mlistOfAllFunctions.count; i++) {
			FindFunctionParams func = (FindFunctionParams) data.mlistOfAllFunctions.getItem(i);
			for (j=0; j<func.listOfVariableParams.count; j++) {
				FindVarParams localVar = (FindVarParams) func.listOfVariableParams.getItem(j);
				if (localVar.parent instanceof FindControlBlockParams) {
					FindControlBlockParams controlBlock = (FindControlBlockParams) localVar.parent;
					if (controlBlock.getName().equals("for")) {
						if (StackMapTable_Helper.hasContinueBeforeVarDecl(compiler, controlBlock, localVar)) {
							r.add(localVar);
						}
					}
				}
			}
		}
		return r;
	}
	
	
	public static void processLocalVarsDefinedAfterContinue(Compiler compiler) {
		ArrayList listOfLocalVars = getLocalVarsDefinedAfterContinue(compiler);
		int i, j;
		for (i=0; i<listOfLocalVars.count; i++) {
			FindVarParams var = (FindVarParams) listOfLocalVars.getItem(i);
			if (var.varNameIndex()==286) {
				int a;
				a=0;
				a++;
			}
			Block block = var.parent;
			for (j=0; j<block.listOfVariableParams.count; j++) {
				if (block.listOfVariableParams.getItem(j)==var) {
					//block.listOfVariableParams.list[j] = null;
					block.listOfVariableParams.list = Array.Delete(block.listOfVariableParams.list, j, 1);
					block.listOfVariableParams.count--;
					break;
				}
			}
			for (j=0; j<block.listOfStatements.count; j++) {
				if (block.listOfStatements.getItem(j)==var) {
					//block.listOfVariableParams.list[j] = null;
					block.listOfStatements.list = Array.Delete(block.listOfStatements.list, j, 1);
					block.listOfStatements.count--;
					break;
				}
			}
		}
		
		for (i=0; i<listOfLocalVars.count; i++) {
			FindVarParams var = (FindVarParams) listOfLocalVars.getItem(i);
			FindControlBlockParams controlBlock = (FindControlBlockParams) var.parent;
			var.blockBeforeMovingFromContinue = var.parent;			
			var.parent = controlBlock.parent;
			var.blockAfterMovingFromContinue = var.parent;
			var.startIndexOfScope = controlBlock.nameIndex;
			var.endIndexOfScope = controlBlock.parent.endIndex;
			var.movedFromContinue = true;
			
			Block blockAfterMovingFromContinue = var.blockAfterMovingFromContinue;
			blockAfterMovingFromContinue.listOfVariableParams.add(var);
			
			for (j=0; j<blockAfterMovingFromContinue.listOfStatements.count; j++) {
				if (blockAfterMovingFromContinue.listOfStatements.getItem(j)==controlBlock) {
					blockAfterMovingFromContinue.listOfStatements.insert(j, var);
					break;
				}
			}
		}
	}*/
	
	/**switch 안에서 선언된 모든 지역변수들을 찾는다.
	 * @controlBlock : switch 블록*/
	public static ArrayList getLocalVarsDefinedInSwitch(Compiler compiler, FindControlBlockParams controlBlock) {
		int i;
		ArrayList r = new ArrayList(10);
		FindFunctionParams func = (FindFunctionParams) Compiler.getParent(controlBlock);
		ArrayListIReset listOfVars = func.listOfVariableParams;
		if (listOfVars==null) return r;
		
		for (i=0; i<listOfVars.count; i++) {
			FindVarParams var = (FindVarParams) listOfVars.getItem(i);
			if (!var.isFake) {
				if (controlBlock.startIndex()<var.startIndex() && var.endIndex()<controlBlock.endIndex()) {
					r.add(var);
				}
			}
		}
		return r;
	}
	
	/**processLocalVars() 호출 이전에 switch 안에서 선언된 지역변수들을 switch 밖으로 빼낸다.
	 * @controlBlock : switch 블록*/
	/*public static void processLocalVarsDefinedInSwitch(Compiler compiler, FindControlBlockParams controlBlock) {
		ArrayList listOfLocalVars = getLocalVarsDefinedInSwitch(compiler, controlBlock);
		int i, j;
		for (i=0; i<listOfLocalVars.count; i++) {
			FindVarParams var = (FindVarParams) listOfLocalVars.getItem(i);
			var.blockBeforeMovingFromSwitch = var.parent;			
			var.parent = controlBlock.parent;
			var.blockAfterMovingFromSwitch = var.parent;
			var.startIndexOfScope = controlBlock.nameIndex;
			var.endIndexOfScope = controlBlock.parent.endIndex;
			var.movedFromSwitch = true;
			
			
			Block blockAfterMovingFromSwitch = var.blockAfterMovingFromSwitch;
			if (!(blockAfterMovingFromSwitch instanceof FindFunctionParams)) { 
				ArrayListIReset listOfVars = blockAfterMovingFromSwitch.listOfVariableParams;
				for (j=0; j<listOfVars.count; j++) {
					FindVarParams v = (FindVarParams) listOfVars.getItem(j);
					if (v.startIndex()>var.startIndex()) {
						listOfVars.insert(j, var);
						break;
					}
				}
			}
			
			ArrayListIReset listOfStatements = blockAfterMovingFromSwitch.listOfStatements;
			for (j=0; j<listOfStatements.count; j++) {
				if (listOfStatements.getItem(j)==controlBlock) {
					listOfStatements.insert(j, var);
					break;
				}
			}		
		}
	}*/
	
	
	/** localVar가 switch 안에서 선언된 변수이면 swtich를 리턴한다.*/
	public static FindControlBlockParams isLocalVarInSwitch(Compiler compiler, FindVarParams localVar) {
				
		Block parent = localVar.parent;
		while (true) {			
			if (parent instanceof FindControlBlockParams) {
				FindControlBlockParams control =  (FindControlBlockParams) parent;
				CodeString name = null;
				if (control.nameIndex()!=-1) {
					name = compiler.data.mBuffer.getItem(control.nameIndex());
					if (name.equals("switch")) return control;
				}
			}
			try {
			parent = parent.parent;
			}catch(Exception e) {
				if (Common_Settings.g_printsLog) e.printStackTrace();
			}
			if (parent==null) return null;
			if (parent instanceof FindFunctionParams) return null;
			if (parent instanceof FindClassParams) return null;			
		}
	}
	
	/** func에서 var라는 지역변수의 인덱스를 찾아서 리턴한다.
	 * func가 static이 아닌 경우 this포인터는 0번을 차지한다.
	 * 함수별로 사용되는 LocalVariableTable에서의 특정 로컬 변수의 인덱스, 
	 * aload, iload 등은 1을 더하고 lload, lstore, dload, dstore는 2를 더한다.
	 * FindFunctionParams.getLocalVarTableIndexInFunction()을 참조한다.*/
	public static int getLocalVarTableIndex(ByteCodeGeneratorForClass generator, FindFunctionParams func, FindVarParams var) {
		
		return var.indexOfLocalVariableTable;
	}
	
	
	public static void printLocalVar_sub(ByteCodeGeneratorForClass generator, FindVarUseParams varUse, HighArrayCharForByteCode result, boolean loadOrStore, String srcIndex, int coreThreadID) {
		try {
			
			String typeName = varUse.varDecl.typeName;
			
					
			int index = getLocalVarTableIndex(generator, varUse.funcToDefineThisVarUse, varUse.varDecl);
			FindVarParams varBeforeProcessLocalVars = varUse.varDeclBeforeProcessLocalVars; 
			
			// 중복변수일 경우 중복처리하기 전 변수(원래변수)의 indexOfLocalVarsInFunctionBeforeProcessLocalVars을,
			// 중복변수가 아니면 그 변수의 indexOfLocalVarsInFunctionBeforeProcessLocalVars을 구한다.
			String strindexOfLocalVarsInFunctionBeforeProcessLocalVars = 
					varBeforeProcessLocalVars!=null ?
							", "+varBeforeProcessLocalVars.indexOfLocalVarsInFunctionBeforeProcessLocalVars :
						", "+varUse.varDecl.indexOfLocalVarsInFunctionBeforeProcessLocalVars;
						
			if (varBeforeProcessLocalVars!=null) {
				strindexOfLocalVarsInFunctionBeforeProcessLocalVars += ", "+varBeforeProcessLocalVars.getVarStr(coreThreadID);
			}
			else {
				strindexOfLocalVarsInFunctionBeforeProcessLocalVars += ", "+varUse.varDecl.getVarStr(coreThreadID);
			}
			
			
			
			if (loadOrStore) {
				if (typeName.equals("boolean") || typeName.equals("byte") || 
						typeName.equals("char") || typeName.equals("short") ||
						typeName.equals("int")) {
					// iload0-iload3 까지 밖에 없지만 임시로 iload_index를 붙여 놓고 
					// HighArrayCharForByteCode.createConstantTableIndex()에서
					// iload0-iload3 까지는 그대로 놔두고 iload index 으로 분리한다.
					result.add("iload_"+index + " // local "+varUse.varDecl.getVarStr(coreThreadID)+strindexOfLocalVarsInFunctionBeforeProcessLocalVars+srcIndex+"\n");
				}
				else if (typeName.equals("long")) {
					// 위에 있는 iload와 동일한 방식으로 인덱스를 분리한다.
					result.add("lload_"+index + " // local "+varUse.varDecl.getVarStr(coreThreadID)+strindexOfLocalVarsInFunctionBeforeProcessLocalVars+srcIndex+"\n");
				}
				else if (typeName.equals("float")) {
					// 위에 있는 iload와 동일한 방식으로 인덱스를 분리한다.
					result.add("fload_"+index + " // local "+varUse.varDecl.getVarStr(coreThreadID)+strindexOfLocalVarsInFunctionBeforeProcessLocalVars+srcIndex+"\n");
				}
				else if (typeName.equals("double")) {
					// 위에 있는 iload와 동일한 방식으로 인덱스를 분리한다.
					result.add("dload_"+index + " // local "+varUse.varDecl.getVarStr(coreThreadID)+strindexOfLocalVarsInFunctionBeforeProcessLocalVars+srcIndex+"\n");
				}
				else { // 오브젝트 지역변수
					// 위에 있는 iload와 동일한 방식으로 인덱스를 분리한다.
					result.add("aload_"+index + " // local "+varUse.varDecl.getVarStr(coreThreadID)+strindexOfLocalVarsInFunctionBeforeProcessLocalVars+srcIndex+"\n");
				}
			}
			else {
				try {
				if (typeName.equals("boolean") || typeName.equals("byte") || 
						typeName.equals("char") || typeName.equals("short") ||
						typeName.equals("int")) {
					// 위에 있는 iload와 동일한 방식으로 인덱스를 분리한다.
					result.add("istore_"+index + " // local "+varUse.varDecl.getVarStr(coreThreadID)+strindexOfLocalVarsInFunctionBeforeProcessLocalVars+srcIndex+"\n");
				}
				else if (typeName.equals("long")) {
					// 위에 있는 iload와 동일한 방식으로 인덱스를 분리한다.
					result.add("lstore_"+index + " // local "+varUse.varDecl.getVarStr(coreThreadID)+strindexOfLocalVarsInFunctionBeforeProcessLocalVars+srcIndex+"\n");
				}
				else if (typeName.equals("float")) {
					// 위에 있는 iload와 동일한 방식으로 인덱스를 분리한다.
					result.add("fstore_"+index + " // local "+varUse.varDecl.getVarStr(coreThreadID)+strindexOfLocalVarsInFunctionBeforeProcessLocalVars+srcIndex+"\n");
				}
				else if (typeName.equals("double")) {
					// 위에 있는 iload와 동일한 방식으로 인덱스를 분리한다.
					result.add("dstore_"+index + " // local "+varUse.varDecl.getVarStr(coreThreadID)+strindexOfLocalVarsInFunctionBeforeProcessLocalVars+srcIndex+"\n");
				}
				else { // 오브젝트 지역변수
					// 위에 있는 iload와 동일한 방식으로 인덱스를 분리한다.
					result.add("astore_"+index + " // local "+varUse.varDecl.getVarStr(coreThreadID)+strindexOfLocalVarsInFunctionBeforeProcessLocalVars+srcIndex+"\n");
				}
				}catch(Exception e) {
					if (Common_Settings.g_printsLog) e.printStackTrace();
				}
			}
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
		}
	}
	
	/**Calls this func in generator.traverseFuncCall_ArrayInitializer(...)*/
	public static void printLocalVar_sub_tempLocalVarForArrayInitiaizer(ByteCodeGeneratorForClass generator, 
			FindVarParams varDecl, HighArrayCharForByteCode result, boolean loadOrStore, String srcIndex, int coreThreadID) {
		try {
			
			String typeName = varDecl.typeName;
			
			
					
			int index = getLocalVarTableIndex(generator, (FindFunctionParams)varDecl.parent, varDecl);
			
			// 중복변수일 경우 중복처리하기 전 변수(원래변수)의 indexOfLocalVarsInFunctionBeforeProcessLocalVars을,
			// 중복변수가 아니면 그 변수의 indexOfLocalVarsInFunctionBeforeProcessLocalVars을 구한다.
			String strindexOfLocalVarsInFunctionBeforeProcessLocalVars = 
						", "+varDecl.indexOfLocalVarsInFunctionBeforeProcessLocalVars;
						
			strindexOfLocalVarsInFunctionBeforeProcessLocalVars += ", "+varDecl.getVarStr(coreThreadID);
			
			if (loadOrStore) {
				if (typeName.equals("boolean") || typeName.equals("byte") || 
						typeName.equals("char") || typeName.equals("short") ||
						typeName.equals("int")) {
					// iload0-iload3 까지 밖에 없지만 임시로 iload_index를 붙여 놓고 
					// HighArrayCharForByteCode.createConstantTableIndex()에서
					// iload0-iload3 까지는 그대로 놔두고 iload index 으로 분리한다.
					result.add("iload_"+index + " // local "+varDecl.getVarStr(coreThreadID)+strindexOfLocalVarsInFunctionBeforeProcessLocalVars+srcIndex+"\n");
				}
				else if (typeName.equals("long")) {
					// 위에 있는 iload와 동일한 방식으로 인덱스를 분리한다.
					result.add("lload_"+index + " // local "+varDecl.getVarStr(coreThreadID)+strindexOfLocalVarsInFunctionBeforeProcessLocalVars+srcIndex+"\n");
				}
				else if (typeName.equals("float")) {
					// 위에 있는 iload와 동일한 방식으로 인덱스를 분리한다.
					result.add("fload_"+index + " // local "+varDecl.getVarStr(coreThreadID)+strindexOfLocalVarsInFunctionBeforeProcessLocalVars+srcIndex+"\n");
				}
				else if (typeName.equals("double")) {
					// 위에 있는 iload와 동일한 방식으로 인덱스를 분리한다.
					result.add("dload_"+index + " // local "+varDecl.getVarStr(coreThreadID)+strindexOfLocalVarsInFunctionBeforeProcessLocalVars+srcIndex+"\n");
				}
				else { // 오브젝트 지역변수
					// 위에 있는 iload와 동일한 방식으로 인덱스를 분리한다.
					result.add("aload_"+index + " // local "+varDecl.getVarStr(coreThreadID)+strindexOfLocalVarsInFunctionBeforeProcessLocalVars+srcIndex+"\n");
				}
			}
			else {
				try {
				if (typeName.equals("boolean") || typeName.equals("byte") || 
						typeName.equals("char") || typeName.equals("short") ||
						typeName.equals("int")) {
					// 위에 있는 iload와 동일한 방식으로 인덱스를 분리한다.
					result.add("istore_"+index + " // local "+varDecl.getVarStr(coreThreadID)+strindexOfLocalVarsInFunctionBeforeProcessLocalVars+srcIndex+"\n");
				}
				else if (typeName.equals("long")) {
					// 위에 있는 iload와 동일한 방식으로 인덱스를 분리한다.
					result.add("lstore_"+index + " // local "+varDecl.getVarStr(coreThreadID)+strindexOfLocalVarsInFunctionBeforeProcessLocalVars+srcIndex+"\n");
				}
				else if (typeName.equals("float")) {
					// 위에 있는 iload와 동일한 방식으로 인덱스를 분리한다.
					result.add("fstore_"+index + " // local "+varDecl.getVarStr(coreThreadID)+strindexOfLocalVarsInFunctionBeforeProcessLocalVars+srcIndex+"\n");
				}
				else if (typeName.equals("double")) {
					// 위에 있는 iload와 동일한 방식으로 인덱스를 분리한다.
					result.add("dstore_"+index + " // local "+varDecl.getVarStr(coreThreadID)+strindexOfLocalVarsInFunctionBeforeProcessLocalVars+srcIndex+"\n");
				}
				else { // 오브젝트 지역변수
					// 위에 있는 iload와 동일한 방식으로 인덱스를 분리한다.
					result.add("astore_"+index + " // local "+varDecl.getVarStr(coreThreadID)+strindexOfLocalVarsInFunctionBeforeProcessLocalVars+srcIndex+"\n");
				}
				}catch(Exception e) {
					if (Common_Settings.g_printsLog) e.printStackTrace();
				}
			}
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
		}
	}
	
	/**iload0-iload3 까지 밖에 없지만 임시로 iload_index를 붙여 놓고 
	HighArrayCharForByteCode.createConstantTableIndex()에서
	iload0-iload3 까지는 그대로 놔두고 iload index 으로 분리한다.
	lload, fload 등도 동일하다. 
	 * @param loadOrStore : true일 경우 load, false일 경우 store
	 * @param coreThreadID */
	public static void printLocalVar(ByteCodeGeneratorForClass generator, FindVarUseParams varUse, HighArrayCharForByteCode result, boolean loadOrStore, int coreThreadID) {
		if (varUse.varDecl==null) return;
		// int a = (int)f + 2; 에서 타입 캐스트 int 가 varUse일 경우
		if (CompilerHelper.IsDefaultType(varUse.name)) return;
		
		
		String strmBufferIndex = null;
		if (!varUse.isFake) {
			strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, varUse.index());
		}
		else {
			// 초기화하지 않은 지역변수인 경우
			FindVarParams var = varUse.varDecl;
			if (var.fieldName.equals(ByteCode_Types.throwableVarNameForFinallyBlock)) {
				// finally의 throwable 예외 던지기
				FindSpecialBlockParams special = (FindSpecialBlockParams) var.blockBeforeMovingFromBlock;
				strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, special.endIndex());
			}
			else {
				strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, var.varNameIndex());
			}
		}
		
		printLocalVar_sub(generator, varUse, result, loadOrStore, strmBufferIndex, coreThreadID);
		
	}
	
	/**iload0-iload3 까지 밖에 없지만 임시로 iload_index를 붙여 놓고 
	HighArrayCharForByteCode.createConstantTableIndex()에서
	iload0-iload3 까지는 그대로 놔두고 iload index 으로 분리한다.
	lload, fload 등도 동일하다. 
	 * @param loadOrStore : true일 경우 load, false일 경우 store
	 * @param coreThreadID */
	public static void printLocalVar_initializeLocalVar(ByteCodeGeneratorForClass generator, FindVarUseParams varUse, HighArrayCharForByteCode result, boolean loadOrStore, int coreThreadID) {
		if (varUse.varDecl==null) return;
		// int a = (int)f + 2; 에서 타입 캐스트 int 가 varUse일 경우
		if (CompilerHelper.IsDefaultType(varUse.name)) return;
		
		
		String strmBufferIndex = null;
		strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, varUse.funcToDefineThisVarUse.functionNameIndex());
		
		printLocalVar_sub(generator, varUse, result, loadOrStore, strmBufferIndex, coreThreadID);
		
	}
	
	/** 함수에서 this와 함수 파라미터 지역변수의 Code[]에서의 start_pc, end_pc라는 라이프 타임을 얻기위해 출력한다.
	 * HighArrayCharForByteCode.createConstantTableIndex()를 참조한다.*/
	public static void printsLocalVarStart(ByteCodeGeneratorForClass generator, FindFunctionParams func, HighArrayCharForByteCode result) {
		int i;
		if (!func.accessModifier.isStatic) {
			FindVarParams varThis = func.thisVar;
			result.add("// localVarStart this "+varThis+"\n");
		}
		// 함수 블록에서 선언되는 아규먼트 이외의 지역변수들은 선언될 때 localVarStart를 출력한다. printFindStatementParams()를 참고한다. 
		for (i=0; i<func.listOfFuncArgs.count; i++) {
			FindVarParams var = (FindVarParams)func.listOfFuncArgs.getItem(i);
			result.add("// localVarStart "+var.indexOfLocalVarsInFunctionBeforeProcessLocalVars/*var.indexOfLocalVariableTable*/+" "+var+"\n");
		}
	}
	
	/** block이 끝날때 block에서 선언된 지역변수들의 스코프를 출력한다.
	 * 함수에서 지역변수의 Code[]에서의 start_pc, end_pc라는 라이프 타임을 얻기위해 출력한다.
	 * HighArrayCharForByteCode.createConstantTableIndex()를 참조한다.*/
	public static void printsLocalVarEnd(ByteCodeGeneratorForClass generator, Block block, HighArrayCharForByteCode result) {
			
		int i;
		if (block instanceof FindFunctionParams) {
			FindFunctionParams func = (FindFunctionParams) block;
			if (!func.accessModifier.isStatic) {
				FindVarParams varThis = func.thisVar;
				result.add("// localVarEnd this "+varThis+"\n");
			}
			
			// 함수블록이 끝나면 함수블록에서 선언된 모든 지역변수들을 해제한다.
			for (i=0; i<func.listOfVariableParams.count; i++) {
				FindVarParams var = (FindVarParams)func.listOfVariableParams.getItem(i);
				if (/*!var.movedFromForLoop && !var.movedFromIFBlock*//* && !var.movedFromSwitch*/!var.movedFromBlock) {
					if (var.parent instanceof FindFunctionParams) {
						result.add("// localVarEnd "+var.indexOfLocalVarsInFunctionBeforeProcessLocalVars+" "+var+"\n");
					}
				}
			}
		}
		else if (block instanceof FindControlBlockParams) {
			
			
			// 제어블록이 끝나면 제어블록에서 선언된 모든 지역변수들을 해제한다.
			/*for (i=0; i<controlBlock.listOfVariableParams.count; i++) {
				FindVarParams var = (FindVarParams)controlBlock.listOfVariableParams.getItem(i);
				if (var.movedFromSwitch && var.blockBeforeMovingFromSwitch==controlBlock) continue;
				result.add("// localVarEnd "+var.indexOfLocalVarsInFunctionBeforeProcessLocalVars+" "+var+"\n");		
			}*/
			FindFunctionParams func = (FindFunctionParams) Compiler.getParent(block);
			for (i=0; i<func.listOfVariableParams.count; i++) {
				FindVarParams var = (FindVarParams)func.listOfVariableParams.getItem(i);				
				
				if (var.movedFromBlock) {
					if (var.blockBeforeMovingFromBlock==block) {
						result.add("// localVarEnd "+var.indexOfLocalVarsInFunctionBeforeProcessLocalVars+" "+var+"\n");
					}
				}
				else {
					if (var.parent==block) {
						result.add("// localVarEnd "+var.indexOfLocalVarsInFunctionBeforeProcessLocalVars+" "+var+"\n");
					}
				}
			}
		}
		
		
		
	}
	
	/** block에서 정의된 for루프의 괄호안에서 초기화문장을 찾아서 localVarEnd를 출력한다.*/
	public static void printVarsDefinedInForLoopParentheis_printsLocalVarEnd(ByteCodeGeneratorForClass generator, Block block, HighArrayCharForByteCode result) {
		int i;
		Compiler compiler = generator.compiler;
		for (i=0; i<block.listOfStatements.count; i++) {
			FindStatementParams statement = (FindStatementParams) block.listOfStatements.getItem(i);
			if (statement instanceof FindControlBlockParams) {
				FindControlBlockParams controlBlock = (FindControlBlockParams) statement;
				if (controlBlock.catOfControls!=null)	{					
					// for루프의 경우에는 괄호안 초기화 문장도 세야 한다. 
					if (controlBlock.catOfControls.category==CategoryOfControls.Control_for) {
						int indexOfSemicolon1 = controlBlock.funcCall.startIndex();
						indexOfSemicolon1 = 
								CompilerHelper.SkipBlank(compiler.data.mBuffer, true, 0, indexOfSemicolon1-1);
						int j;
						for (j=0; j<controlBlock.listOfStatementsInParenthesis.count; j++) {
							FindStatementParams statementVar = 
									(FindStatementParams) controlBlock.listOfStatementsInParenthesis.getItem(j);
							if (statementVar instanceof FindVarParams) {
								FindVarParams var = (FindVarParams) statementVar;
								if (controlBlock.indexOfLeftParenthesis()<=var.startIndex() && 
										var.endIndex()<=indexOfSemicolon1) {
									result.add("// localVarEnd "+var.indexOfLocalVarsInFunctionBeforeProcessLocalVars+" "+var+"\n");
								}
							}
						}
					}
				}
			}
		}
	}
	
	
	
	/**var가 초기화되지 않은 변수일 경우 자동 초기화를 해준다.
	 * @param coreThreadID */
	public static void initializeLocalVar(ByteCodeGeneratorForClass generator, FindVarParams var, HighArrayCharForByteCode result, int coreThreadID) {
		
		FindFunctionParams funcToDefineThisVarUse = (FindFunctionParams) Compiler.getParent(var.parent);
		if (CompilerHelper.IsDefaultType(var.typeName)) {
			generator.printSmallIntegerNumber(0, result, funcToDefineThisVarUse.functionNameIndex());
			TypeCast.printTypeCast(generator, "int", var.typeName, result, funcToDefineThisVarUse.functionNameIndex(), coreThreadID);
		}
		else {
			String strmBufferIndex = null;
			if (!var.isFake) {
				strmBufferIndex = ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(generator.compiler, funcToDefineThisVarUse.functionNameIndex());
			}
			else {
				if (var.fieldName.equals(ByteCode_Types.throwableVarNameForFinallyBlock)) {
					// finally의 throwable 예외 던지기
					strmBufferIndex = ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(generator.compiler, funcToDefineThisVarUse.functionNameIndex());
				}
				else {
					strmBufferIndex = ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(generator.compiler, funcToDefineThisVarUse.functionNameIndex());
				}
			}
			result.add("aconst_null // "+strmBufferIndex+"\n");
		}
		FindVarUseParams lValue = new FindVarUseParams(null);
		lValue.name = var.fieldName;
		lValue.originName = var.fieldName;
		lValue.index = var.varNameIndex;
		lValue.isFake = true;
		lValue.varDecl = var;
		if (var.sharedVar!=null) {
			// var가 공유변수일 경우
			lValue.varDeclBeforeProcessLocalVars = var;
			lValue.varDecl = var.sharedVar;
		}
		lValue.funcToDefineThisVarUse = funcToDefineThisVarUse;
		printLocalVar_initializeLocalVar(generator, lValue, result, false, coreThreadID);
	}
}
