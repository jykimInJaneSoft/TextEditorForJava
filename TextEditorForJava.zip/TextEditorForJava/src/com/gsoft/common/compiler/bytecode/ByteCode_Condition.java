package com.gsoft.common.compiler.bytecode;

import com.gsoft.common.Code.CodeChar;
import com.gsoft.common.Code.CodeString;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.compiler.CodeStringEx;
import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.Compiler_types.FindControlBlockParams;
import com.gsoft.common.compiler.Compiler_types.FindFuncCallParam;
import com.gsoft.common.compiler.Compiler_types.FindVarUseParams;
import com.gsoft.common.compiler.Expression;
import com.gsoft.common.compiler.Fullname;
import com.gsoft.common.compiler.HighArray_CodeString;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.Util;

import com.gsoft.common.compiler.bytecode.ByteCodeGeneratorForClass;
import com.gsoft.common.compiler.bytecode.HighArrayCharForByteCode;
import com.gsoft.common.compiler.bytecode.ByteCode_Helper;
import com.gsoft.common.compiler.bytecode.TypeCast;

@SuppressWarnings("unused")
public class ByteCode_Condition {
	/** true && false 에서 true*/
	static final byte And_Left = 1;
	/** true && false 에서 false*/
	static final byte And_Right = 2;
	/** true || false 에서 true*/
	static final byte Or_Left = 3;
	/** true || false 에서 false*/
	static final byte Or_Right = 4;
	static final byte Not_Left = 5;
	static final byte Not_Right = 6;
	
	
	static class AffectedBy {
		CodeStringEx operator;
		byte howToLink;
		
		AffectedBy(CodeStringEx operator, byte howToLink) {
			this.operator = operator;
			this.howToLink = howToLink;
		}
		
		public String toString() {
			switch (howToLink) {
			case 1: return "And_Left";
			case 2: return "And_Right";
			case 3: return "Or_Left";
			case 4: return "Or_Right";
			case 5: return "Not_Left";
			}
			return "";
		}
	}
	
	
	/** parent가 &&일 경우 왼쪽이면 And_Left, 오른쪽이면 And_Right,
	 * parent가 ||일 경우 왼쪽이면 Or_Left, 오른쪽이면 Or_Right,
	 * parent가 !일 경우 왼쪽이면 Not_Left, 오른쪽이면 Not_Right,
	 * @param token
	 * @return : AffectedBy[]
	 */
	public static ArrayList getListOfParentsOfOperators(CodeStringEx token) {
		CodeStringEx parent = token;
		ArrayList r = new ArrayList(5); 
		while(true) {			
			if (parent==null) {
				return r;
			}
			if (parent.affectedBy==null) {
				return r;
			}
			if (parent.affectedBy.equals("&&")) {
				if (parent.affectedBy_left!=null) {
					r.add(new AffectedBy(parent.affectedBy,(byte)And_Left));
				}
				else if (parent.affectedBy_right!=null) {
					r.add(new AffectedBy(parent.affectedBy,(byte)And_Right));
				}
			}
			else if (parent.affectedBy.equals("||")) {
				if (parent.affectedBy_left!=null) {
					r.add(new AffectedBy(parent.affectedBy,(byte)Or_Left));
				}
				else if (parent.affectedBy_right!=null) {
					r.add(new AffectedBy(parent.affectedBy,(byte)Or_Right));
				}
			}
			else if (parent.affectedBy.equals("!")) {
				if (parent.affectedBy_left!=null) {
					r.add(new AffectedBy(parent.affectedBy,(byte)Not_Left));
				}
				else if (parent.affectedBy_right!=null) {
					r.add(new AffectedBy(parent.affectedBy,(byte)Not_Right));
				}
			}
			parent = parent.affectedBy;
		}
	}
	
	
	public static CodeStringEx findTokenAfterOperator(CodeStringEx[] postfix, CodeStringEx operator) {
		int i;
		for (i=0; i<postfix.length; i++) {
			CodeStringEx token = postfix[i];
			if (token.indicesInSrc.list[0]>operator.indicesInSrc.list[0]) {
				return token;
			}
		}
		return null;
	}
	
	public static int hasNOT(ArrayList parents, int startIndex) {
		int i;
		for (i=startIndex; i<parents.count; i++) {
			AffectedBy affectedBy = (AffectedBy) parents.list[i];
			if (affectedBy.howToLink==Not_Left) {
				return i;
			}
		}
		return -1;
	}
	
	public static int getCountOfNOT(ArrayList parents, int startIndex) {
		int count=0;
		int i;
		for (i=startIndex; i<parents.count; i++) {
			AffectedBy affectedBy = (AffectedBy) parents.list[i];
			if (affectedBy.howToLink==Not_Left) {
				count++;
			}
			//else return count;
		}
		return count;
	}
	
	public static int getCountOfNOTBeforeOR(ArrayList parents, int startIndex, OR or) {
		int count=0;
		int i;
		for (i=startIndex; i<parents.count; i++) {
			if (i==or.index) return count;
			AffectedBy affectedBy = (AffectedBy) parents.list[i];			
			if (affectedBy.howToLink==Not_Left) {
				count++;
			}
			//else return count;
		}
		return count;
	}
	
	public static int getCountOfNOTBeforeAND(ArrayList parents, int startIndex, AND and) {
		int count=0;
		int i;
		for (i=startIndex; i<parents.count; i++) {
			if (i==and.index) return count;
			AffectedBy affectedBy = (AffectedBy) parents.list[i];			
			if (affectedBy.howToLink==Not_Left) {
				count++;
			}
			//else return count;
		}
		return count;
	}
	
	
	static class OR {
		int index;
		AffectedBy or;
		OR(int index, AffectedBy or) {
			this.index = index;
			this.or = or;
		}
	}
	
	static class AND {
		int index;
		AffectedBy and;
		AND(int index, AffectedBy and) {
			this.index = index;
			this.and = and;
		}
	}
	
	
	/** 어떤 토큰의 오퍼레이터 parents 리스트에서 startIndex 이후의 '||'를 왼쪽으로 연결하는
	 * 첫번째 '||'를 찾아서 그것의 다음에 있는 토큰을 리턴한다.
	 * @param parents : if (true && false && true || true)에서 첫번째 true의 parents리스트는
	 * &&, &&, ||가 된다.<br>
	 *  if (true && false || true && true)에서 첫번째 true의 parents리스트는 
	 *  &&, ||가 된다.
	 * 
	 * @param startIndex : if (true &&(0) false ||(1) true)에서 괄호안의 인덱스이다. 
	 * @param postfix : 조건문의 포스트픽스 수식
	 * @return
	 */
	public static OR hasOR(ArrayList parents, int startIndex, CodeStringEx[] postfix) {
		int i;
		for (i=startIndex; i<parents.count; i++) {
			AffectedBy affectedBy = (AffectedBy) parents.list[i];
			
			/*if (affectedBy.operator.operatorAfterNOTOperation==null) {
				if (affectedBy.operator.equals("||") && affectedBy.howToLink==Or_Left) {
					OR r = new OR(i, affectedBy);
					return r;
				}
			}
			else {
				if (affectedBy.operator.operatorAfterNOTOperation.equals("||") && 
						(affectedBy.howToLink==Or_Left || affectedBy.howToLink==And_Left)) {
					// And_Left는 실제로는 Or_Left이다. callBoolean(CodeStringEx)에서 printNOT(CodeStringEx)에서
					// NOT처리시 &&가 ||로 바뀐 것이다.
					OR r = new OR(i, affectedBy);
					return r;
				}
			}*/
			if (affectedBy.operator.equals("||") && affectedBy.howToLink==Or_Left) {
				OR r = new OR(i, affectedBy);
				return r;
			}
		}
		return null;
	}
	
	public static OR hasOR_Both(ArrayList parents, int startIndex, CodeStringEx[] postfix) {
		int i;
		for (i=startIndex; i<parents.count; i++) {
			AffectedBy affectedBy = (AffectedBy) parents.list[i];
			
			/*if (affectedBy.operator.operatorAfterNOTOperation==null) {
				if (affectedBy.operator.equals("||")) {
					OR r = new OR(i, affectedBy);
					return r;
				}
			}
			else {
				if (affectedBy.operator.operatorAfterNOTOperation.equals("||")) {
					OR r = new OR(i, affectedBy);
					return r;
				}
			}*/
			if (affectedBy.operator.equals("||")) {
				OR r = new OR(i, affectedBy);
				return r;
			}
		}
		return null;
	}
	
	/** 어떤 토큰의 오퍼레이터 parents 리스트에서 startIndex 이후의 '&&'를 왼쪽으로 연결하는
	 * 첫번째 '&&'를 찾아서 그것의 다음에 있는 토큰을 리턴한다.
	 * @param parents : if (true && false && true || true)에서 첫번째 true의 parents리스트는
	 * &&, &&, ||가 된다.<br>
	 *  if (true && false || true && true)에서 첫번째 true의 parents리스트는 
	 *  &&, ||가 된다.
	 * 
	 * @param startIndex : if (true &&(0) false ||(1) true)에서 괄호안의 인덱스이다. 
	 * @param postfix : 조건문의 포스트픽스 수식
	 * @return
	 */
	public static AND hasAND(ArrayList parents, int startIndex, CodeStringEx[] postfix) {
		try {
		int i;
		for (i=startIndex; i<parents.count; i++) {
			AffectedBy affectedBy = (AffectedBy) parents.list[i];
			
			/*if (affectedBy.operator.operatorAfterNOTOperation==null) {
				if (affectedBy.operator.equals("&&") && affectedBy.howToLink==And_Left) {
					AND r = new AND(i, affectedBy);
					return r;
				}
			}
			else {
				if (affectedBy.operator.operatorAfterNOTOperation.equals("&&") && 
						(affectedBy.howToLink==And_Left || affectedBy.howToLink==Or_Left)) {
					// Or_Left는 실제로는 And_Left이다. callBoolean(CodeStringEx)에서 printNOT(CodeStringEx)에서
					// NOT처리시 ||가 &&로 바뀐 것이다.
					AND r = new AND(i, affectedBy);
					return r;
				}
			}*/
			if (affectedBy.operator.equals("&&") && affectedBy.howToLink==And_Left) {
				AND r = new AND(i, affectedBy);
				return r;
			}
		}
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
		}
		return null;
	}
	
	public static AND hasAND_Both(ArrayList parents, int startIndex, CodeStringEx[] postfix) {
		int i;
		for (i=startIndex; i<parents.count; i++) {
			AffectedBy affectedBy = (AffectedBy) parents.list[i];
			
			/*if (affectedBy.operator.operatorAfterNOTOperation==null) {
				if (affectedBy.operator.equals("&&")) {
					AND r = new AND(i, affectedBy);
					return r;
				}
			}
			else {
				if (affectedBy.operator.operatorAfterNOTOperation.equals("&&")) {
					AND r = new AND(i, affectedBy);
					return r;
				}
			}*/
			if (affectedBy.operator.equals("&&")) {
				AND r = new AND(i, affectedBy);
				return r;
			}
		}
		return null;
	}
	
	
	
	
	
			
	/**            or
	 *      and          or
	 *   or   and     and   H  
	 * A  B   C or    F G
	 *         D  E 
	 *         
	 *  (A or B) and C and (D or E)  or  F and G or H
	 *  <br>
	 *  first에서 Or_Left, Or_Right 2개의 경우의 수
		second에서 And_Left, And_Right, Or_Left, Or_Right 4개의 경우의 수
		따라서 논리연산자가 2개 이상 있을 때 8개의 경우의 수가 있다.
	 * @param token : 관계 연산자
	 * @param curType
	 * @param result
	 */
	
	
	
	/**            or
	 *      and          or
	 *   or   and     and   H  
	 * A  B   C or    F G
	 *         D  E 
	 *         
	 *  (A or B) and C and (D or E)  or  F and G or H
	 *  <br>
	 *  first에서 And_Left, And_Right 2개의 경우의 수
		second에서 And_Left, And_Right, Or_Left, Or_Right 4개의 경우의 수
		따라서 논리연산자가 2개 이상 있을 때 8개의 경우의 수가 있다.
	 * @param token : 관계 연산자
	 * @param curType
	 * @param result
	 */
	
	
	
	
	/** A && B에서 A를 처리한 후 호출, Short cut이 아니므로 주의한다.
	 * 바로 다음에 나오면서 왼쪽으로 연결하는 &&, ||을 구해서 mCountOfNOT과 mRelationOperator_AffectedByRight을 설정해서
	 * 다음 print_And_Left()나 print_Or_Left()에서 처리한다.  
	 * @param operator : &&를 오른쪽으로 연결할때 &&
	 * @param funcCall : 3항연산자에서 조건식 부분을 말한다. 3항 연산일 경우 null이 아니고, controlBlock은 null이 된다.
	 * @param coreThreadID */
	public static void print_And_Right(ByteCodeGeneratorForClass generator, FindControlBlockParams controlBlock, CodeStringEx operator, HighArrayCharForByteCode result, CodeStringEx[] postfix,
			FindFuncCallParam funcCall, int coreThreadID) {
		Compiler compiler = generator.compiler;
		if (operator.indicesInSrc.list[0]==386) {
		}
		
		String strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, operator.indicesInSrc.getItem(0));
		
		ArrayList parents = getListOfParentsOfOperators(operator);
		
		// 바로 다음에 나오는 AND, OR를 왼쪽으로 연결하는 연산자를 얻는다.
		OR or = hasOR(parents, 0, postfix);
		AND and = hasAND(parents, 0, postfix);
		
				
		String strIndex = "";
		if (or==null && and==null) {
			// if ( !false &&(0) true ) 첫번째 true
			strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)0, funcCall);
			//result.add("ifgt "+"// "+strIndex+"run"+"\n");
			// 관계식을 만족하면 run으로 간다.
			CodeStringEx leaf = getLeafToken(operator.affectsRight);
			strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, leaf.indicesInSrc.getItem(0));
			
			// !(!(b<1 && c<1 && b>0) &&(여기에서 leaf는 null이다) !(b>0 && c<1))
			if (leaf==null) return;
			if (CompilerHelper.IsLogicalOperator(leaf.str)) return;
			if (isRelationOperatorOrInstanceof(leaf)/*CompilerHelper.IsRelationOperator(leaf.str)*/) {
				printRelationOperatorOrInstanceof(generator, controlBlock, leaf, result, postfix, "or", funcCall, coreThreadID);
				result.add("// "+strIndex+"run"+strmBufferIndex+"\n");
			}
			else {
				// boolean 변수, boolean 상수
				printBooleanInCondition(generator, controlBlock, leaf, result, postfix, "or");
				result.add("// "+strIndex+"run"+strmBufferIndex+"\n");
			}
			return;
		}// if (parents==null || parents.count==0) {
		
		
		if (mLeaf_AffectedByRight!=null) return;
		
		/*int indexOfNot = hasNOT(parents, 0);
		CodeStringEx not = null;
		if (indexOfNot>=0) {
			not = ((AffectedBy)parents.getItem(indexOfNot)).operator;
		}*/
		
		// 다음에 오는(왼쪽으로 연결하는) &&, ||를 구해서 그 연산자 전에 오는 !의 개수를 구한다.
		// 그리고 print_And_Left()나 print_And_Right()에서 구해진 값으로 ifle, ifgt등을 출력한다.
		if (or!=null && and==null){
			mCountOfNOT = getCountOfNOTBeforeOR(parents, 0, or);
		}		
		else if (or==null && and!=null) {
			mCountOfNOT = getCountOfNOTBeforeAND(parents, 0, and);
		}
		else if (or!=null && and!=null) {
			if (or.index<=and.index) {
				mCountOfNOT = getCountOfNOTBeforeOR(parents, 0, or);
			}
			else {
				mCountOfNOT = getCountOfNOTBeforeAND(parents, 0, and);
			}
		}
		
		mLeaf_AffectedByRight = getLeafToken(operator.affectsRight);
		
		
	}
	
	
	
	/** print_XXX_Right()에서 &&, ||를 오른쪽으로 연결하는 관계연산자 혹은 boolean 변수, 상수*/
	static CodeStringEx mLeaf_AffectedByRight = null;
	
	/** print_XXX_Right()에서 다음에 오는(왼쪽으로 연결하는) &&, ||를 구해서 그 연산자 전에 오는 !의 개수를 구하고
	 * print_XXX_Left()에서 대신 처리한다. 
	 * &&, || 다음부터 그 다음에 오는(왼쪽으로 연결하는) &&, || 전의 !의 개수*/
	static int mCountOfNOT = 0;
	
	/** NOT을 만날때 print_And_Left(), print_Or_Left()에서 설정을 하면 
	 * print_And_Right(), print_Or_Right()에서 출력을 한다.*/  
	//CodeStringEx mRelationOperator_AffectedByLeft = null;
	
	
	
	
	/** A && B에서 A를 처리한 후 호출
	 * @param operator : &&를 왼쪽으로 연결할때 &&
	 * @param funcCall : 3항연산자에서 조건식 부분을 말한다. 3항연산자에서 조건식 부분을 말한다. 3항 연산일 경우 null이 아니고, controlBlock은 null이 된다.
	 * @param coreThreadID */
	public static void print_And_Left(ByteCodeGeneratorForClass generator, FindControlBlockParams controlBlock, CodeStringEx operator, HighArrayCharForByteCode result, CodeStringEx[] postfix,
			FindFuncCallParam funcCall, int coreThreadID) {
		Compiler compiler = generator.compiler;
		if (operator.indicesInSrc.list[0]==1786) {
		}
		String strIndex = "";
		ArrayList parents = getListOfParentsOfOperators(operator);
		OR or = hasOR(parents, 0, postfix);
	
		String strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, operator.indicesInSrc.getItem(0));
	
		
		if (or==null) {
			strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)1, funcCall);
			// if ((false &&(0) true))에서 첫번째 false				
			//result.add("ifle "+"// "+strIndex+"exit_of_condition"+"\n");
			// 관계식을 만족하지 않으면 조건문 전체를 벗어나야 한다.
			if (mLeaf_AffectedByRight!=null) {
				// print_XXX_Right()에서 넘어오는 조건식을 대신 처리할 때 
				// if (!(3)(!(1)(false &&(0) false) ||(2) true))에서 두번째 false
				// print_And_Right()에서는 or가 null일 경우 && 전 not의 개수를 설정한다.
				if (isRelationOperatorOrInstanceof(mLeaf_AffectedByRight)/*CompilerHelper.IsRelationOperator(mLeaf_AffectedByRight.str)*/) {
					printRelationOperatorOrInstanceof(generator, controlBlock, mLeaf_AffectedByRight, result, postfix, "and", funcCall, coreThreadID);
					result.add("// "+strIndex+"exit_of_condition"+strmBufferIndex+"\n");
					mLeaf_AffectedByRight = null;
				}
				else {
					printBooleanInCondition(generator, controlBlock, mLeaf_AffectedByRight, result, postfix, "and");
					result.add("// "+strIndex+"exit_of_condition"+strmBufferIndex+"\n");
					mLeaf_AffectedByRight = null;
				}
			}
			else {
				CodeStringEx leaf = getLeafToken(operator.affectsLeft);
				if (leaf==null) {
				}
				if (isRelationOperatorOrInstanceof(leaf)/*CompilerHelper.IsRelationOperator(leaf.str)*/) {
					printRelationOperatorOrInstanceof(generator, controlBlock, leaf, result, postfix, "and", funcCall, coreThreadID);
					result.add("// "+strIndex+"exit_of_condition"+strmBufferIndex+"\n");
				}
				else {
					// boolean 변수, boolean 상수
					printBooleanInCondition(generator, controlBlock, leaf, result, postfix, "and");
					result.add("// "+strIndex+"exit_of_condition"+strmBufferIndex+"\n");
				}
			}
			return;
		}//if (or==null) {
		else if (or.or.howToLink==Or_Left){
			// And_Left는 실제로는 Or_Left이다. callBoolean(CodeStringEx)에서 printNOT(CodeStringEx)에서
			// NOT처리시 &&가 ||로 바뀐 것이다.
			// if (!(1)(!(false &&(0) true)) ||(2) false)에서 첫번째 false
			CodeStringEx nextToken = findTokenAfterOperator(postfix, or.or.operator);
			String index = "("+nextToken.indicesInSrc.list[0]+"), ";
			// newLineChar가 없는 원래 관계식의 역으로 된 if**을 출력한다.
			// 관계식이 성립하지 않으면 or로 점프한다.				
			if (mLeaf_AffectedByRight!=null) {
				// print_XXX_Right()에서 넘어오는 조건식을 대신 처리할 때 
				if (isRelationOperatorOrInstanceof(mLeaf_AffectedByRight)/*CompilerHelper.IsRelationOperator(mLeaf_AffectedByRight.str)*/) {
					printRelationOperatorOrInstanceof(generator, controlBlock, mLeaf_AffectedByRight, result, postfix, "and", funcCall, coreThreadID);
					result.add("// "+index+"go to or"+", "+nextToken+strmBufferIndex+"\n"); // put false
					mLeaf_AffectedByRight = null;
				}
				else {
					printBooleanInCondition(generator, controlBlock, mLeaf_AffectedByRight, result, postfix, "and");
					result.add("// "+index+"go to or"+", "+nextToken+strmBufferIndex+"\n"); // put false
					mLeaf_AffectedByRight = null;
				}
			}
			else {
				CodeStringEx leaf = getLeafToken(operator.affectsLeft);
				if (isRelationOperatorOrInstanceof(leaf)/*CompilerHelper.IsRelationOperator(leaf.str)*/) {
					printRelationOperatorOrInstanceof(generator, controlBlock, leaf, result, postfix, "and", funcCall, coreThreadID);
					result.add("// "+index+"go to or"+", "+nextToken+strmBufferIndex+"\n"); // put false
				}
				else {
					// boolean 변수, boolean 상수
					printBooleanInCondition(generator, controlBlock, leaf, result, postfix, "and");
					result.add("// "+index+"go to or"+", "+nextToken+strmBufferIndex+"\n"); // put false
				}
			} 
			//result.add("ifle "+"// "+index+"go to or"+", "+nextToken+"\n"); // put false				
			nextToken.printsORComment = true;
			nextToken.trueOrFalse = false;
			operator.tokenAfterOR = nextToken;
		} // else if (or.or.howToLink==Or_Left){
		
		//String index = "("+operator.indicesInSrc.list[0]+"), ";
		//result.add("// "+index+"and"+"\n");
	}
	
	/**            or
	 *      and          or
	 *   or   and     and   H  
	 * A  B   C or    F G
	 *         D  E 
	 *         
	 *  (A or B) and C and (D or E)  or  F and G or H
	 *  <br>
	 *  first에서 Or_Left, Or_Right 2개의 경우의 수
		second에서 And_Left, And_Right, Or_Left, Or_Right 4개의 경우의 수
		따라서 논리연산자가 2개 이상 있을 때 8개의 경우의 수가 있다.
	 * @param token : 관계 연산자
	 * @param curType
	 * @param result
	 */
	
	
	
	/**            or
	 *      and          or
	 *   or   and     and   H  
	 * A  B   C or    F G
	 *         D  E 
	 *         
	 *  (A or B) and C and (D or E)  or  F and G or H
	 *  <br>
	 *  first에서 And_Left, And_Right 2개의 경우의 수
		second에서 And_Left, And_Right, Or_Left, Or_Right 4개의 경우의 수
		따라서 논리연산자가 2개 이상 있을 때 8개의 경우의 수가 있다.
	 * @param token : 관계 연산자
	 * @param curType
	 * @param result
	 * @param funcCall : 3항연산자에서 조건식 부분을 말한다. 3항 연산일 경우 null이 아니고, controlBlock은 null이 된다.
	 * @param coreThreadID 
	 */
	public static void printAND(ByteCodeGeneratorForClass generator, FindControlBlockParams controlBlock, CodeStringEx operator, HighArrayCharForByteCode result, CodeStringEx[] postfix, 
			FindFuncCallParam funcCall, int coreThreadID) {
		if (operator.indicesInSrc.list[0]==249) {
		}
		// 왼쪽 오퍼랜드부터 호출
		callBoolean(generator, controlBlock, operator.affectsLeft, result, postfix, funcCall, coreThreadID);
		
		print_And_Left(generator, controlBlock, operator, result, postfix, funcCall, coreThreadID);
		
		// 오른쪽 오퍼랜드
		callBoolean(generator, controlBlock, operator.affectsRight, result, postfix, funcCall, coreThreadID);
		
		print_And_Right(generator, controlBlock, operator, result, postfix, funcCall, coreThreadID);
		//result.add("iand"+"\n");
	}
	
	
	
	/**        !
	 *         !  
	 *         >  
	 *    
	 ** @param operator : leaf토큰을 찾아야 할 토큰 
	 * @return : 관계연산자, boolean변수, boolean 상수
	 */
	public static CodeStringEx getLeafToken(CodeStringEx operator) {
		if (CompilerHelper.IsRelationOperator(operator.str))
			return operator;
		else if (operator.equals("true") || operator.equals("false"))
			return operator;
		
		else if (operator.equals("!")) {
			if (operator.affectsLeft!=null) {				
				// NOT, 관계연산자, Boolean
				return getLeafToken(operator.affectsLeft);
			}
		}
		else {
			return operator;
		}
		
		return null;
	}
	
	/** A || B에서 A를 처리한 후 호출
	 * @param operator : ||를 왼쪽으로 연결할때 ||
	 * @param funcCall : 3항연산자에서 조건식 부분을 말한다. 3항 연산일 경우 null이 아니고, controlBlock은 null이 된다.
	 * @param coreThreadID */
	public static void print_Or_Left(ByteCodeGeneratorForClass generator, FindControlBlockParams controlBlock, CodeStringEx operator, HighArrayCharForByteCode result, CodeStringEx[] postfix,
			FindFuncCallParam funcCall, int coreThreadID) {
		Compiler compiler = generator.compiler;
		if (operator.indicesInSrc.getItem(0)==6656) {
		}
		String strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, operator.indicesInSrc.getItem(0));
		
		String strIndex = "";
		ArrayList parents = getListOfParentsOfOperators(operator);
		AND and = hasAND(parents, 0, postfix);
		//hasNOT(parents, 0);
		if (and==null) {
			strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)0, funcCall);
			//result.add("ifgt "+"// "+strIndex+"run"+"\n");
			// 관계식을 만족하면 run으로 간다.
			if (mLeaf_AffectedByRight!=null) {
				// print_XXX_Right()에서 넘어오는 조건식을 대신 처리할 때 
				if (isRelationOperatorOrInstanceof(mLeaf_AffectedByRight)/*CompilerHelper.IsRelationOperator(mLeaf_AffectedByRight.str)*/) {
					printRelationOperatorOrInstanceof(generator, controlBlock, mLeaf_AffectedByRight, result, postfix, "or", funcCall, coreThreadID);
					result.add("// "+strIndex+"run"+strmBufferIndex+"\n");
					mLeaf_AffectedByRight = null;
				}
				else {
					printBooleanInCondition(generator, controlBlock, mLeaf_AffectedByRight, result, postfix, "or");
					result.add("// "+strIndex+"run"+strmBufferIndex+"\n");
					mLeaf_AffectedByRight = null;
				}
			}
			else {
				CodeStringEx leaf = getLeafToken(operator.affectsLeft);
				if (isRelationOperatorOrInstanceof(leaf)/*CompilerHelper.IsRelationOperator(leaf.str)*/) {
					printRelationOperatorOrInstanceof(generator, controlBlock, leaf, result, postfix, "or", funcCall, coreThreadID);
					result.add("// "+strIndex+"run"+strmBufferIndex+"\n");
				}
				else {
					printBooleanInCondition(generator, controlBlock, leaf, result, postfix, "or");
					result.add("// "+strIndex+"run"+strmBufferIndex+"\n");
				}
			}
			
		}
		else if (and.and.howToLink==And_Left){
			// Or_Left는 실제로는 And_Left이다. callBoolean(CodeStringEx)에서 printNOT(CodeStringEx)에서
			// NOT처리시 ||가 &&로 바뀐 것이다.
			CodeStringEx nextToken = findTokenAfterOperator(postfix, and.and.operator);
			String index = "("+nextToken.indicesInSrc.list[0]+"), ";
			// if ( (true ||(0) false) &&(1) false )
			//result.add("ifgt "+"// "+index+"go to and"+", "+nextToken+"\n"); // put true
			// 관계식을 만족하면 and으로 간다.
			if (mLeaf_AffectedByRight!=null) {
				// print_XXX_Right()에서 넘어오는 조건식을 대신 처리할 때 
				if (isRelationOperatorOrInstanceof(mLeaf_AffectedByRight)/*CompilerHelper.IsRelationOperator(mLeaf_AffectedByRight.str)*/) {
					printRelationOperatorOrInstanceof(generator, controlBlock, mLeaf_AffectedByRight, result, postfix, "or", funcCall, coreThreadID);
					result.add("// "+index+"go to and"+", "+nextToken+strmBufferIndex+"\n"); // put true
					mLeaf_AffectedByRight = null;
				}
				else {
					printBooleanInCondition(generator, controlBlock, mLeaf_AffectedByRight, result, postfix, "or");
					result.add("// "+index+"go to and"+", "+nextToken+strmBufferIndex+"\n"); // put true
					mLeaf_AffectedByRight = null;
				}
			}
			else {
				CodeStringEx leaf = getLeafToken(operator.affectsLeft);
				if (isRelationOperatorOrInstanceof(leaf)/*CompilerHelper.IsRelationOperator(leaf.str)*/) {
					printRelationOperatorOrInstanceof(generator, controlBlock, operator.affectsLeft, result, postfix, "or", funcCall, coreThreadID);
					result.add("// "+index+"go to and"+", "+nextToken+strmBufferIndex+"\n"); // put true
				}
				else {
					// boolean 변수, boolean 상수
					printBooleanInCondition(generator, controlBlock, leaf, result, postfix, "or");
					result.add("// "+index+"go to and"+", "+nextToken+strmBufferIndex+"\n"); // put true
				}
			} 				
			nextToken.printsANDComment = true;
			nextToken.trueOrFalse = true;
			operator.tokenAfterAND = nextToken;
		}
		//String index = "("+operator.indicesInSrc.list[0]+"), ";
		//result.add("// "+index+"or"+"\n");
	}
	
	
	
	/** A || B에서 A를 처리한 후 호출, Short cut이 아니므로 주의한다.
	 * 바로 다음에 나오면서 왼쪽으로 연결하는 &&, ||을 구해서 mCountOfNOT과 mRelationOperator_AffectedByRight을 설정해서
	 * 다음 print_And_Left()나 print_Or_Left()에서 처리한다.
	 * @param operator : ||를 오른쪽으로 연결할때 ||
	 * @param funcCall : 3항연산자에서 조건식 부분을 말한다. 3항 연산일 경우 null이 아니고, controlBlock은 null이 된다.
	 * @param coreThreadID */
	public static void print_Or_Right(ByteCodeGeneratorForClass generator, FindControlBlockParams controlBlock, CodeStringEx operator, HighArrayCharForByteCode result, CodeStringEx[] postfix,
			FindFuncCallParam funcCall, int coreThreadID) {
		Compiler compiler = generator.compiler;
		if (operator.indicesInSrc.list[0]==266) {
			int a;
			a=0;
			a++;
		}
		String strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, operator.indicesInSrc.getItem(0));
		
		ArrayList parents = getListOfParentsOfOperators(operator);
		
		// 바로 다음에 나오는 AND, OR를 왼쪽으로 연결하는 연산자를 얻는다.
		OR or = hasOR(parents, 0, postfix);
		AND and = hasAND(parents, 0, postfix);
		
		String strIndex = "";
		if (or==null && and==null) {
			// if ( !false ||(0) true ) 첫번째 true
			strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)0, funcCall);
			//result.add("ifgt "+"// "+strIndex+"run"+"\n");
			// 관계식을 만족하면 run으로 간다.
			CodeStringEx leaf = getLeafToken(operator.affectsRight);
			strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, leaf.indicesInSrc.getItem(0));
			
			// !(!(b<1 && c<1 && b>0) &&(여기에서 leaf는 null이다) !(b>0 && c<1))
			if (leaf==null) return;
			if (CompilerHelper.IsLogicalOperator(leaf.str)) return;
			if (isRelationOperatorOrInstanceof(leaf)/*CompilerHelper.IsRelationOperator(leaf.str)*/) {
				printRelationOperatorOrInstanceof(generator, controlBlock, leaf, result, postfix, "or", funcCall, coreThreadID);
				result.add("// "+strIndex+"run"+strmBufferIndex+"\n");
			}
			else {
				// boolean 변수, boolean 상수
				printBooleanInCondition(generator, controlBlock, leaf, result, postfix, "or");
				result.add("// "+strIndex+"run"+strmBufferIndex+"\n");
			}
		}
		
		if (mLeaf_AffectedByRight!=null) return;
		
		// 다음에 오는(왼쪽으로 연결하는) &&, ||를 구해서 그 연산자 전에 오는 !의 개수를 구한다.
		// 그리고 print_And_Left()나 print_And_Right()에서 구해진 값으로 ifle, ifgt등을 출력한다. 
		if (and!=null && or==null){
			mCountOfNOT = getCountOfNOTBeforeAND(parents, 0, and);			
		}		
		else if (and==null && or!=null) {
			mCountOfNOT = getCountOfNOTBeforeOR(parents, 0, or);
		}
		else if (and!=null && or!=null) {
			if (and.index<=or.index) {
				mCountOfNOT = getCountOfNOTBeforeAND(parents, 0, and);
			}
			else {
				mCountOfNOT = getCountOfNOTBeforeOR(parents, 0, or);
			}
		}
		
		mLeaf_AffectedByRight = getLeafToken(operator.affectsRight);
	}
	
	/**@param funcCall : 3항연산자에서 조건식 부분을 말한다. 3항 연산일 경우 null이 아니고, controlBlock은 null이 된다.
	 * @param coreThreadID */
	public static void printOR(ByteCodeGeneratorForClass generator, FindControlBlockParams controlBlock, CodeStringEx operator, HighArrayCharForByteCode result, CodeStringEx[] postfix,
			FindFuncCallParam funcCall, int coreThreadID) {
		if (operator.indicesInSrc.list[0]==2044) {
		}
		// 왼쪽 오퍼랜드부터 호출
		callBoolean(generator, controlBlock, operator.affectsLeft, result, postfix, funcCall, coreThreadID);
		
		print_Or_Left(generator, controlBlock, operator, result, postfix, funcCall, coreThreadID);
		
		// 오른쪽 오퍼랜드
		callBoolean(generator, controlBlock, operator.affectsRight, result, postfix, funcCall, coreThreadID);
		
		print_Or_Right(generator, controlBlock, operator, result, postfix, funcCall, coreThreadID);
		//result.add("ior"+"\n");
	}
	
	
	/**@param funcCall : 3항연산자에서 조건식 부분을 말한다. 3항 연산일 경우 null이 아니고, controlBlock은 null이 된다.
	 * @param coreThreadID */
	public static void printNOT(ByteCodeGeneratorForClass generator, FindControlBlockParams controlBlock, CodeStringEx operator, HighArrayCharForByteCode result, CodeStringEx[] postfix,
			FindFuncCallParam funcCall, int coreThreadID) {
		if (operator.indicesInSrc.list[0]==2047) {
		}
		// 왼쪽 오퍼랜드부터 호출
		callBoolean(generator, controlBlock, operator.affectsLeft, result, postfix, funcCall, coreThreadID);
		
		/*if (operator.printsNOTComment) {
			justBeforeNot(operator, result);
		}
		
		if (operator.printsNOTComment) {
			// 해당 // not, 분기될 경우 스택에 넣을 false, true순으로 값이 정의되어 있다.
			String index = "("+operator.indicesInSrc.list[0]+"), ";
			result.add("// "+index+"not"+"\n");
			result.add("iconst_0"+"\n");	// false
			result.add("goto "+"// "+2+", ixor"+"\n"); // ixor로 점프
			result.add("iconst_1"+"\n");	// true
		}
		
		result.add("ixor 1"+"\n");*/
	}
	
	
	/** 논리연산자, 관계연산자를 제외한 모든 연산자
	 * @param funcCall : 3항연산자에서 조건식 부분을 말한다. 3항 연산일 경우 null이 아니고, controlBlock은 null이 된다.
	 * @param coreThreadID */
	public static void printOperatorInCondition(ByteCodeGeneratorForClass generator, FindControlBlockParams controlBlock, CodeStringEx token, HighArrayCharForByteCode result, CodeStringEx[] postfix,
			FindFuncCallParam funcCall, int coreThreadID) {
		if (token.indicesInSrc.list[0]==1348) {
			int a;
			a=0;
			a++;
		}
		if (token.affectsLeft!=null) {
			callBoolean(generator, controlBlock, token.affectsLeft, result, postfix, funcCall, coreThreadID);
		}
		if (!token.equals("instanceof")) { 
			// token이 instanceof일 경우 affectsRight를 대상으로 callBoolean()을 호출하지 않는다.
			if (token.affectsRight!=null) {
				callBoolean(generator, controlBlock, token.affectsRight, result, postfix, funcCall, coreThreadID);
			}
		}
		
		generator.printOperator(token, result, coreThreadID);
	}
	
	/** token이 true, false 혹은 boolean 변수일때만 출력한다.*/
	public static void printBooleanInCondition(ByteCodeGeneratorForClass generator, FindControlBlockParams controlBlock, 
			CodeStringEx token, HighArrayCharForByteCode result, CodeStringEx[] postfix, String command) {
		if (token.indicesInSrc.list[0]==2696) {
		}
		if (CompilerHelper.IsOperator(token))
			return;
		ArrayList parents = getListOfParentsOfOperators(token);
		
		// 바로 다음에 나오는 AND, OR를 왼쪽(오른쪽)으로 연결하는 연산자를 얻는다.
		/*OR or = hasOR_Both(parents, 0, postfix);
		AND and = hasAND_Both(parents, 0, postfix);
		
		// 위에서 구한 AND, OR 전까지의 NOT의 개수를 구한다.
		int countOfNOT = 0;
		if (or!=null && and==null){
			countOfNOT = getCountOfNOTBeforeOR(parents, 0, or);
		}		
		else if (or==null && and!=null) {
			countOfNOT = getCountOfNOTBeforeAND(parents, 0, and);
		}
		else if (or!=null && and!=null) {
			if (or.index<=and.index) {
				countOfNOT = getCountOfNOTBeforeOR(parents, 0, or);
			}
			else {
				countOfNOT = getCountOfNOTBeforeAND(parents, 0, and);
			}
		}*/
				
		
		int countOfNOT = getCountOfNOT(parents, 0);
		
		if (command.equals("or")) {
			if (countOfNOT % 2==0) {
				result.add("ifgt ");
			}
			else {
				result.add("ifle ");
			}
		}
		else if (command.equals("and")) {
			if (countOfNOT % 2==0) {
				result.add("ifle ");
			}
			else {
				result.add("ifgt ");
			}
		}
	}
	
	/**@param token : 관계연산자
	 * @param funcCall : 3항연산자에서 조건식 부분을 말한다. 3항 연산일 경우 null이 아니고, controlBlock은 null이 된다.
	 * @param coreThreadID */
	public static void printRelationOperatorOrInstanceof(ByteCodeGeneratorForClass generator, FindControlBlockParams controlBlock, CodeStringEx token, HighArrayCharForByteCode result, CodeStringEx[] postfix, String command,
			FindFuncCallParam funcCall, int coreThreadID) {
		Compiler compiler = generator.compiler;
		if (token.indicesInSrc.getItem(0)==2674) {
			int a;
			a=0;
			a++;
		}
		if (token.affectsLeft==null || token.affectsLeft.typeFullName==null) return;
		if (token.affectsRight==null || token.affectsRight.typeFullName==null) return;
		
		int startIndexOfRelation = Fullname.getFullNameIndex(compiler, true, token.affectsLeft.indicesInSrc.getItem(0), false);
		int endIndexOfRelation = Fullname.getFullNameIndex(compiler, false, token.affectsRight.indicesInSrc.getItem(0), false);
		FindFuncCallParam relationFuncCall = new FindFuncCallParam(compiler, startIndexOfRelation, endIndexOfRelation);
		
		printIncMode0(generator, relationFuncCall, result, coreThreadID);
		
		if (!token.affectsLeft.typeFullName.equals("null")) {
			callBoolean(generator, controlBlock, token.affectsLeft, result, postfix, funcCall, coreThreadID);
		}
		if (!token.affectsRight.typeFullName.equals("null")) {
			callBoolean(generator, controlBlock, token.affectsRight, result, postfix, funcCall, coreThreadID);
		}
		// 스택에 관계식의 결과값을 넣어준다.
		//String typeFullName = token.affectsLeft.typeFullNameAfterOperation==null ? 
		//		token.affectsLeft.typeFullName : token.affectsLeft.typeFullNameAfterOperation;
		String typeFullName = token.affectsLeft.getTypeFullNameOrTypeFullNameAfterOperation();
		
		String strmBufferIndex = ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(generator.compiler, token.indicesInSrc.getItem(0));
		
		if (typeFullName.equals("boolean")) {
			result.add("isub // "+strmBufferIndex+"\n");
		}
		else if (typeFullName.equals("byte") || typeFullName.equals("char") ||
				typeFullName.equals("short") || typeFullName.equals("int")) {
			result.add("isub // "+strmBufferIndex+"\n");
		}
		else if (typeFullName.equals("long")) {
			//result.add("lsub"+"\n");
			result.add("lcmp // "+strmBufferIndex+"\n");
		}
		else if (typeFullName.equals("float")) {
			//result.add("fsub"+"\n");
			result.add("fcmpg // "+strmBufferIndex+"\n");
		}
		else if (typeFullName.equals("double")) {
			//result.add("dsub"+"\n");
			result.add("dcmpg // "+strmBufferIndex+"\n");
		}
		else {
			//result.add("isub // "+strmBufferIndex+"\n");
		}
		
		
		printIncMode1(generator, relationFuncCall, result, coreThreadID);
		//printIncMode1(generator, controlBlock.funcCall, result);
		
		ArrayList parents = getListOfParentsOfOperators(token);
		
		
		strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, token.indicesInSrc.getItem(0));
		
		int countOfNOT = getCountOfNOT(parents, 0);
		
		String strIndex = null;
		if (token.equals(">")) {
			/*result.add("ifgt "+"// iconst_1"+"\n");
			result.add("iconst_0"+"\n");
			result.add("goto "+"// 2"+"\n");
			result.add("iconst_1"+"\n");*/
			
			// while (a>5)
			if (command.equals("null")) {
				strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)0, funcCall);
				//result.add("ifgt "+"// "+strIndex+"run"+"\n");
				if (countOfNOT % 2==0) {
					result.add("ifgt "+"// "+strIndex+"run"+strmBufferIndex+"\n");
				}
				else {
					result.add("ifle "+"// "+strIndex+"run"+strmBufferIndex+"\n");
				}
			}
			else if (command.equals("and")) { 
				//strIndex = getStringOfmBufferIndex(controlBlock, (byte)0);
				//result.add("ifgt "+"// "+strIndex+"run"+"\n");
				if (countOfNOT % 2==0) {
					result.add("ifle ");
				}
				else {
					result.add("ifgt ");
				}
			} 
			else if (command.equals("or")) {
				//result.add("ifgt ");
				if (countOfNOT % 2==0) {
					result.add("ifgt ");
				}
				else {
					result.add("ifle ");
				}
			}
		}// if (token.equals(">")) {
		else if (token.equals("<")) {
			/*result.add("iflt "+"// iconst_1"+"\n");
			result.add("iconst_0"+"\n");
			result.add("goto "+"// 2"+"\n");
			result.add("iconst_1"+"\n");*/
			
			// while
			if (command.equals("null")) {
				strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)0, funcCall);
				//result.add("iflt "+"// "+strIndex+"run"+"\n");
				if (countOfNOT % 2==0) {
					result.add("iflt "+"// "+strIndex+"run"+strmBufferIndex+"\n");
				}
				else {
					result.add("ifge "+"// "+strIndex+"run"+strmBufferIndex+"\n");
				}
			}
			else if (command.equals("and")) {
				//result.add("ifge ");
				if (countOfNOT % 2==0) {
					result.add("ifge ");
				}
				else {
					result.add("iflt ");
				}
			}
			else if (command.equals("or")) {
				//result.add("iflt ");
				if (countOfNOT % 2==0) {
					result.add("iflt ");
				}
				else {
					result.add("ifge ");
				}
			}
		}
		else if (token.equals(">=")) {
			/*result.add("ifge "+"// iconst_1"+"\n");
			result.add("iconst_0"+"\n");
			result.add("goto "+"// 2"+"\n");
			result.add("iconst_1"+"\n");*/
			
			// while
			if (command.equals("null")) {
				strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)0, funcCall);
				//result.add("ifge "+"// "+strIndex+"run"+"\n");
				if (countOfNOT % 2==0) {
					result.add("ifge "+"// "+strIndex+"run"+strmBufferIndex+"\n");
				}
				else {
					result.add("iflt "+"// "+strIndex+"run"+strmBufferIndex+"\n");
				}
			}
			else if (command.equals("and")) {
				//result.add("iflt ");
				if (countOfNOT % 2==0) {
					result.add("iflt ");
				}
				else {
					result.add("ifge ");
				}
			}
			else if (command.equals("or")) {
				//result.add("ifge ");
				if (countOfNOT % 2==0) {
					result.add("ifge ");
				}
				else {
					result.add("iflt ");
				}
			}
		}
		else if (token.equals("<=")) {
			/*result.add("ifle "+"// iconst_1"+"\n");
			result.add("iconst_0"+"\n");
			result.add("goto "+"// 2"+"\n");
			result.add("iconst_1"+"\n");*/
			
			// while
			if (command.equals("null")) {
				strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)0, funcCall);
				if (countOfNOT % 2==0) {
					result.add("ifle "+"// "+strIndex+"run"+strmBufferIndex+"\n");
				}
				else {
					result.add("ifgt "+"// "+strIndex+"run"+strmBufferIndex+"\n");
				}
			}
			else if (command.equals("and")) {
				if (countOfNOT % 2==0) {
					result.add("ifgt ");
				}
				else {
					result.add("ifle ");
				}
			}
			else if (command.equals("or")) {
				if (countOfNOT % 2==0) {
					result.add("ifle ");
				}
				else {
					result.add("ifgt ");
				}
			}
		}
		else if (token.equals("==")) {
			/*result.add("ifeq "+"// iconst_1"+"\n");
			result.add("iconst_0"+"\n");
			result.add("goto "+"// 2"+"\n");
			result.add("iconst_1"+"\n");*/
			
		    if (CompilerHelper.IsDefaultType(typeFullName)) {
				if (command.equals("null")) {
					strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)0, funcCall);
					if (countOfNOT % 2==0) {
						result.add("ifeq "+"// "+strIndex+"run"+strmBufferIndex+"\n");
					}
					else {
						result.add("ifne "+"// "+strIndex+"run"+strmBufferIndex+"\n");
					}
				}
				else if (command.equals("and")) {
					if (countOfNOT % 2==0) {
						result.add("ifne ");
					}
					else {
						result.add("ifeq ");
					}
				}
				else if (command.equals("or")) {
					if (countOfNOT % 2==0) {
						result.add("ifeq ");
					}
					else {
						result.add("ifne ");
					}
				}
		    }
		    else {
		    	// object type
		    	//String typeFullNameRight = token.affectsRight.typeFullNameAfterOperation==null ? 
		    	//		token.affectsRight.typeFullName : token.affectsRight.typeFullNameAfterOperation;
		    	String typeFullNameRight = token.affectsRight.getTypeFullNameOrTypeFullNameAfterOperation();
		    	// if (obj==null)
		    	if (typeFullName.equals("null") || typeFullNameRight.equals("null")) {
		    		if (command.equals("null")) {
						strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)0, funcCall);
						if (countOfNOT % 2==0) {
							result.add("ifnull "+"// "+strIndex+"run"+strmBufferIndex+"\n");
						}
						else {
							result.add("ifnonnull "+"// "+strIndex+"run"+strmBufferIndex+"\n");
						}
					}
					else if (command.equals("and")) {
						if (countOfNOT % 2==0) {
							result.add("ifnonnull ");
						}
						else {
							result.add("ifnull ");
						}
					}
					else if (command.equals("or")) {
						if (countOfNOT % 2==0) {
							result.add("ifnull ");
						}
						else {
							result.add("ifnonnull ");
						}
					}
		    	}
		    	else {
		    		// if (obj1==obj2)
		    		if (command.equals("null")) {
						strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)0, funcCall);
						if (countOfNOT % 2==0) {
							result.add("if_acmpeq "+"// "+strIndex+"run"+strmBufferIndex+"\n");
						}
						else {
							result.add("if_acmpne "+"// "+strIndex+"run"+strmBufferIndex+"\n");
						}
					}
					else if (command.equals("and")) {
						if (countOfNOT % 2==0) {
							result.add("if_acmpne ");
						}
						else {
							result.add("if_acmpeq ");
						}
					}
					else if (command.equals("or")) {
						if (countOfNOT % 2==0) {
							result.add("if_acmpeq ");
						}
						else {
							result.add("if_acmpne ");
						}
					}
		    	}
		    }
		} // else if (token.equals("==")) {
		else if (token.equals("!=")) {
			/*result.add("ifne "+"// iconst_1"+"\n");
			result.add("iconst_0"+"\n");
			result.add("goto "+"// 2"+"\n");
			result.add("iconst_1"+"\n");*/
		
			if (CompilerHelper.IsDefaultType(typeFullName)) {
				if (command.equals("null")) {
					strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)0, funcCall);
					if (countOfNOT % 2==0) {
						result.add("ifne "+"// "+strIndex+"run"+strmBufferIndex+"\n");
					}
					else {
						result.add("ifeq "+"// "+strIndex+"run"+strmBufferIndex+"\n");
					}
				}
				else if (command.equals("and")) {
					if (countOfNOT % 2==0) {
						result.add("ifeq ");
					}
					else {
						result.add("ifne ");
					}
				}
				else if (command.equals("or")) {
					if (countOfNOT % 2==0) {
						result.add("ifne ");
					}
					else {
						result.add("ifeq ");
					}
				}
			}
			else {
				//String typeFullNameRight = token.affectsRight.typeFullNameAfterOperation==null ? 
		    	//		token.affectsRight.typeFullName : token.affectsRight.typeFullNameAfterOperation;
				String typeFullNameRight = token.affectsRight.getTypeFullNameOrTypeFullNameAfterOperation();
				// if (obj!=null)
		    	if (typeFullName.equals("null") || typeFullNameRight.equals("null")) {
		    		if (command.equals("null")) {
						strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)0, funcCall);
						if (countOfNOT % 2==0) {
							result.add("ifnonnull "+"// "+strIndex+"run"+strmBufferIndex+"\n");
						}
						else {
							result.add("ifnull "+"// "+strIndex+"run"+strmBufferIndex+"\n");
						}
					}
					else if (command.equals("and")) {
						if (countOfNOT % 2==0) {
							result.add("ifnull ");
						}
						else {
							result.add("ifnonnull ");
						}
					}
					else if (command.equals("or")) {
						if (countOfNOT % 2==0) {
							result.add("ifnonnull ");
						}
						else {
							result.add("ifnull ");
						}
					}
		    	}
		    	else {
		    		// if (obj1!=obj2)
		    		if (command.equals("null")) {
						strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)0, funcCall);
						if (countOfNOT % 2==0) {
							result.add("if_acmpne "+"// "+strIndex+"run"+strmBufferIndex+"\n");
						}
						else {
							result.add("if_acmpeq "+"// "+strIndex+"run"+strmBufferIndex+"\n");
						}
					}
					else if (command.equals("and")) {
						if (countOfNOT % 2==0) {
							result.add("if_acmpeq ");
						}
						else {
							result.add("if_acmpne ");
						}
					}
					else if (command.equals("or")) {
						if (countOfNOT % 2==0) {
							result.add("if_acmpne ");
						}
						else {
							result.add("if_acmpeq ");
						}
					}
		    	}
			}
		} // else if (token.equals("!=")) {
		else if (token.equals("instanceof")) {
			// if (obj instanceof Object)
			generator.printOperator(token, result, coreThreadID);
			if (command.equals("null")) {
				strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)0, funcCall);
				//result.add("ifgt "+"// "+strIndex+"run"+"\n");
				if (countOfNOT % 2==0) {
					result.add("ifgt "+"// "+strIndex+"run"+strmBufferIndex+"\n");
				}
				else {
					result.add("ifle "+"// "+strIndex+"run"+strmBufferIndex+"\n");
				}
			}
			else if (command.equals("and")) { 
				//strIndex = getStringOfmBufferIndex(controlBlock, (byte)0);
				//result.add("ifgt "+"// "+strIndex+"run"+"\n");
				if (countOfNOT % 2==0) {
					result.add("ifle ");
				}
				else {
					result.add("ifgt ");
				}
			} 
			else if (command.equals("or")) {
				//result.add("ifgt ");
				if (countOfNOT % 2==0) {
					result.add("ifgt ");
				}
				else {
					result.add("ifle ");
				}
			}
		}// if (token.equals(">")) {
	}
	
	
	
	public static CodeStringEx cloneReverse(CodeStringEx operator) {
		CodeStringEx r = null;
		if (operator.equals("&&")) {
			r = new CodeStringEx("||");
		}
		else if (operator.equals("||")) {
			r = new CodeStringEx("&&");
		}
		r.affectedBy = operator.affectedBy;
		r.affectedBy_left = operator.affectedBy_left;
		r.affectedBy_right = operator.affectedBy_right;
		r.affectsLeft = operator.affectsLeft;
		r.affectsRight = operator.affectsRight;
		r.indicesInSrc = operator.indicesInSrc;
		return r;
	}
	
	
	
	/**@param funcCall : 3항연산자에서 조건식 부분을 말한다. 3항 연산일 경우 null이 아니고, controlBlock은 null이 된다.
	 * @param coreThreadID */
	public static void callBoolean(ByteCodeGeneratorForClass generator, FindControlBlockParams controlBlock, CodeStringEx token, HighArrayCharForByteCode result, CodeStringEx[] postfix, 
			FindFuncCallParam funcCall, int coreThreadID) {
		Compiler compiler = generator.compiler;
		if (token==null) return;
		if (token==null || token.indicesInSrc==null) {
		}
		if (token!=null && token.indicesInSrc!=null && token.indicesInSrc.list[0]==1810) {
		}
		if (token.equals("||")) {			
			printOR(generator, controlBlock, token, result, postfix, funcCall, coreThreadID);
		}
		else if (token.equals("&&")) {			
			printAND(generator, controlBlock, token, result, postfix, funcCall, coreThreadID);
		}
		else if (token.equals("!")) {
			printNOT(generator, controlBlock, token, result, postfix, funcCall, coreThreadID);
		}
		else {
			if (isRelationOperatorOrInstanceof(token)/*CompilerHelper.IsRelationOperator(token.str)*/) {
				//printRelationOperatorOrInstanceof(generator, controlBlock, token, result, postfix, "null", null);
				return;
			}
			else if (CompilerHelper.IsOperator(token.str)) {
				printOperatorInCondition(generator, controlBlock, token, result, postfix, funcCall, coreThreadID);
				// if (i+2.0f>3.0f) 에서 '+'의 타입캐스트를 처리한다.
				if (!TypeCast.abortsTypeFullNameAfterOperation(token)) {
					TypeCast.printTypeCast(generator,  token.typeFullName, 
						token.typeFullNameAfterOperation, result, token.indicesInSrc.getItem(0), coreThreadID);
				}
			}
			else { // 상수나 변수일 경우
				if (token.printsORComment) {
					String index = "("+token.indicesInSrc.list[0]+"), ";
					result.add("// "+index+"or"+"\n");
				}
				if (token.printsANDComment) {
					String index = "("+token.indicesInSrc.list[0]+"), ";
					result.add("// "+index+"and"+"\n");
				}
				
				if (token.indicesInSrc.getItem(0)==82) {
					int a;
					a=0;
					a++;
				}
				
				int startIndex = Compiler.getIndexInmListOfAllVarUses(
						compiler.data.mBuffer, compiler.data.mlistOfAllVarUses, 0, 
						token.indicesInSrc.getItem(0)-1, true);
				int endIndex = Compiler.getIndexInmListOfAllVarUses(
						compiler.data.mBuffer, compiler.data.mlistOfAllVarUses, startIndex, 
						token.indicesInSrc.getItem(token.indicesInSrc.count-1)+1, false);
				generator.traverse(startIndex, endIndex, result);
				
				if (token.equals("true")) {
				}
				else if (token.equals("false")) {
				}
				else if (CompilerHelper.IsConstant(token)) {
					
				}				
				else { // 변수
					
				}
				// if (i+2<f) 에서 '+'의 typeFullNameAfterOperation는 float가 된다. 
				// 따라서 iadd를 출력한 후에 i2f를 출력한다.
				
				if (!TypeCast.abortsTypeFullNameAfterOperation(token)) {
					TypeCast.printTypeCast(generator,  token.typeFullName, 
						token.typeFullNameAfterOperation, result, token.indicesInSrc.getItem(0), coreThreadID);
				}
			}//상수나 변수일 경우
		}
	}
	
	/** postfix로 src를 바꾼다.*/
	public static void changeSource(HighArray_CodeString src, CodeStringEx[] postfix) {
		int i, j;
		for (i=0; i<postfix.length; i++) {
			CodeStringEx token = postfix[i];
			if (i==20) {
			}
			if (token.equals("&&") || token.equals("||")) {
				for (j=0; j<token.indicesInSrc.count; j++) {
					int index = token.indicesInSrc.getItem(j);
					CodeChar c = token.charAt(j);
					CodeString str = src.getItem(index);
					str.changeStr(String.valueOf(c.c));
				}
			}
		}
	}
	
	
	public static CodeStringEx[] clonePostfix(CodeStringEx[] postfix) {
		CodeStringEx[] r = new CodeStringEx[postfix.length];
		int i;
		for (i=0; i<r.length; i++) {
			r[i] = (CodeStringEx) postfix[i].clone();
		}
		return r;
	}
	
	public static CodeStringEx[] reversePostfix(CodeStringEx[] postfix) {
		int i;
		for (i=0; i<postfix.length; i++) {
			CodeStringEx token = postfix[i];
			if (token.indicesInSrc.list[0]==2338) {
			}
			if (token.equals("&&")) {
				ArrayList parents = getListOfParentsOfOperators(token);			
				int countOfNOT = getCountOfNOT(parents, 0);
				if (countOfNOT % 2!=0) {
					//token.setStrAndTypeFullName("||", token.typeFullName);
					token.changeStr("||");
				}
			}
			else if (token.equals("||")) {
				ArrayList parents = getListOfParentsOfOperators(token);			
				int countOfNOT = getCountOfNOT(parents, 0);
				if (countOfNOT % 2!=0) {
					//token.setStrAndTypeFullName("&&", token.typeFullName);
					token.changeStr("&&");
				}
			}
		}
		return postfix;
	}
	
	public static boolean isRelationOperatorOrInstanceof(CodeStringEx operator) {
		if (CompilerHelper.IsRelationOperator(operator.str))
			return true;
		if (operator.equals("instanceof"))
			return true;
		return false;
	}
	
	/**++iarr[++j] 를 출력한다.
	 * @param coreThreadID */
	static void printIncMode0(ByteCodeGeneratorForClass generator, FindFuncCallParam condition, HighArrayCharForByteCode result, int coreThreadID) {
		Compiler compiler = generator.compiler;
		
		int startIndex = Compiler.getIndexInmListOfAllVarUses(
				compiler.data.mBuffer, compiler.data.mlistOfAllVarUses, 0, condition.startIndex(), true);
		int endIndex = Compiler.getIndexInmListOfAllVarUses(
				compiler.data.mBuffer, compiler.data.mlistOfAllVarUses, 0, condition.endIndex(), false);
		
		int i;
		// ++iarr[++j] 를 해결한다.
		for (i=startIndex; i<=endIndex; i++) {
			FindVarUseParams varUse = (FindVarUseParams) compiler.data.mlistOfAllVarUses.getItem(i);
			if (varUse.inc!=null) {
				generator.printVarUseIncludingInc(varUse, result, 0, coreThreadID);
				i = generator.jump(varUse, i);
			}
		}	
	}
	
	/**iarr[j++]++ 를 출력한다.
	 * @param coreThreadID */
	static void printIncMode1(ByteCodeGeneratorForClass generator, FindFuncCallParam condition, HighArrayCharForByteCode result, int coreThreadID) {
		Compiler compiler = generator.compiler;
		
		int startIndex = Compiler.getIndexInmListOfAllVarUses(
				compiler.data.mBuffer, compiler.data.mlistOfAllVarUses, 0, condition.startIndex(), true);
		int endIndex = Compiler.getIndexInmListOfAllVarUses(
				compiler.data.mBuffer, compiler.data.mlistOfAllVarUses, 0, condition.endIndex(), false);
		
		int i;
		// iarr[j++]++ 를 해결한다.
		for (i=startIndex; i<=endIndex; i++) {
			FindVarUseParams varUse = (FindVarUseParams) compiler.data.mlistOfAllVarUses.getItem(i);
			if (varUse.inc!=null) {
				generator.printVarUseIncludingInc(varUse, result, 1, coreThreadID);
				i = generator.jump(varUse, i);
			}
		}
	}
	
	
	
	
	/** 제어블록에 있는 조건식의 바이트코드를 출력한다.
	 * @param funcCall : 3항연산자에서 조건식 부분을 말한다. 3항 연산일 경우 null이 아니고, controlBlock은 null이 된다.
	 * @param coreThreadID */
	public static void printCondition(ByteCodeGeneratorForClass generator, FindControlBlockParams controlBlock, HighArrayCharForByteCode result, FindFuncCallParam funcCall, int coreThreadID) {
		Compiler compiler = generator.compiler;
		//FindFuncCallParam funcCall = controlBlock.funcCall;		
		
		if (controlBlock!=null && controlBlock.nameIndex()==75) {
			int a;
			a=0;
			a++;
		}
		
		//printIncMode0(generator, controlBlock.funcCall, result);
		
		mLeaf_AffectedByRight = null;
		
		if (funcCall==null) {
			// 일반 제어블록의 조건식일 경우
			funcCall = controlBlock.funcCall;
			if (funcCall==null) return;
		}
		
		funcCall.typeFullName = null;
		funcCall.expression = null;
		// 소스를 바꾸고 NOT이 적용된 포스트픽스를 다시 만든다.
		funcCall.typeFullName = Expression.getTypeOfExpression(compiler, funcCall, coreThreadID);
		
		
		if (funcCall.expression==null) return;
		if (funcCall.expression.postfix==null) return;
		
		CodeStringEx[] postfix = funcCall.expression.postfix;
		
		// postfix가 callBoolean(lastToken, postfix)에서 바뀌기 전에 백업한다.
		CodeStringEx[] backup_postfix = clonePostfix(postfix);
		
		CodeStringEx lastToken = postfix[postfix.length-1];
		
		if (lastToken.indicesInSrc.getItem(0)==2326) {
		}
		
		// NOT을 적용해서 &&, ||를 반대로 바꾼다.
		//callBoolean(lastToken, postfix);
		reversePostfix(postfix);
		
		
		
		funcCall.typeFullName = null;
		funcCall.expression = null;
		// 소스를 바꾸고 NOT이 적용된 포스트픽스를 다시 만든다.
		changeSource(compiler.data.mBuffer, postfix);
		Expression.getTypeOfExpression(compiler, funcCall, coreThreadID);
		
		
		result.addString(Util.getGapOfLineOffset() + " // ");
		int i;
		for (i=0; i<postfix.length; i++) {
			result.addString(postfix[i].str+" ");
		}
		result.addString("\n");
		
		
		// NOT이 적용된 postfix
		postfix = funcCall.expression.postfix;
		
		lastToken = postfix[postfix.length-1];
		
		
		if (!hasAndOrOr(postfix)) {
			if (postfix.length==1) {
				// boolean 변수 또는 상수
				// lastToken을 스택에 올린다.
				callBoolean(generator, controlBlock, lastToken, result, postfix, funcCall, coreThreadID);
				String strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)0, funcCall);
				String strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, postfix[0].indicesInSrc.getItem(0));
				result.add("ifgt "+"// "+strIndex+"run"+strmBufferIndex+"\n");
			}
			else {
				// i<2, !(i<2) 등, 수식과 관계연산자와 not으로만 이루어진 조건식
				CodeStringEx leafToken = getLeafToken(lastToken);
				if (isRelationOperatorOrInstanceof(leafToken)/*CompilerHelper.IsRelationOperator(leafToken.str)*/) {
					// if (a>5)
					try {
					printRelationOperatorOrInstanceof(generator, controlBlock, leafToken, result, postfix, "null", funcCall, coreThreadID);
					}catch(Exception e) {
						if (Common_Settings.g_printsLog) e.printStackTrace();
					}
				}
				else {
					// boolean 변수, boolean 상수
					callBoolean(generator, controlBlock, leafToken, result, postfix, null, coreThreadID);
					String strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)0, funcCall);
					String strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, leafToken.indicesInSrc.getItem(0));
					printBooleanInCondition(generator, controlBlock, leafToken, result, postfix, "or");
					result.add("// "+strIndex+"run"+strmBufferIndex+"\n");
				}
			}
		}
		else {
			// "&&", "||" 포함 조건식
			callBoolean(generator, controlBlock, lastToken, result, postfix, funcCall, coreThreadID);
			
		}
		
		// 원래의 소스로 다시 바꾼다.
		changeSource(compiler.data.mBuffer, backup_postfix);
		funcCall.expression.postfix = backup_postfix;
		
		//String strIndex = getStringOfmBufferIndex(controlBlock, (byte)0);
		//result.add("ifgt "+"// "+strIndex+"run"+"\n");
	}

	/**postfix에 "&&", "||"가 있는지 없는지를 확인한다.*/
	static boolean hasAndOrOr(CodeStringEx[] postfix) {
		int i;
		for (i=0; i<postfix.length; i++) {
			if (postfix[i].equals("&&") || postfix[i].equals("||"))
				return true;
		}
		return false;
	}
}