package com.gsoft.common.compiler.bytecode;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.CompilerStatic;
import com.gsoft.common.compiler.Compiler_types.CategoryOfControls;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.Compiler_types.FindControlBlockParams;
import com.gsoft.common.compiler.Compiler_types.FindFunctionParams;
import com.gsoft.common.compiler.Compiler_types.FindVarParams;
import com.gsoft.common.compiler.Compiler_types.FindVarUseParams;
import com.gsoft.common.compiler.Compiler_types_Base.Block;
import com.gsoft.common.compiler.Compiler_types_Base.FindStatementParams;
import com.gsoft.common.compiler.Compiler_types_Special.FindSpecialBlockParams;
import com.gsoft.common.compiler.Compiler_types_Special.FindSpecialStatementParams;
import com.gsoft.common.compiler.bytecode.ByteCodeGeneratorForClass.ReturnOfGetCountOfSynchronizedAndFinallyJustBeforeCatch;
import com.gsoft.common.compiler.bytecode.ThrowStack.ThrowStartEnd;
import com.gsoft.common.compiler.classloader.Loader;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListInt;
import com.gsoft.common.util.Sort;

import com.gsoft.common.compiler.bytecode.Synchronized;
import com.gsoft.common.compiler.bytecode.HighArrayCharForByteCode;
import com.gsoft.common.compiler.bytecode.ByteCodeGeneratorForClass;
import com.gsoft.common.compiler.bytecode.ControlBlock;
import com.gsoft.common.compiler.bytecode.ByteCode_Helper;
import com.gsoft.common.compiler.bytecode.ByteCode_Types;
import com.gsoft.common.compiler.bytecode.LocalVar;
import com.gsoft.common.compiler.bytecode.TypeDescriptor;
import com.gsoft.common.compiler.bytecode.Console;
import com.gsoft.common.compiler.bytecode.TypeCast;

/** try, catch, finally, throw, return, synchronized*/
public class Specials {
	

	/**throw(return)를 하기전에 모니터를 몇 번 해제해야 하고 finally를 몇 번 실행해야 하는지 확인하고 순서대로 출력한다.
	 * throw문일 경우 catch가 되거나 finally를 만날때까지의 모니터만 해제한다.
	 * return문일 경우 catch에 상관없이 모니터를 해제하고 finally를 순서대로 출력한다.
	 * 
	 * throwOrReturn을 true로 설정하면 return문은 throw문 처럼 finally를 만나면 가상머신에게
	   finally 처리를 맡긴다. 
	   throwOrReturn을 false로 설정하면 throw문과 다르게 synchronized(모니터해제), 
	   finally를 순서대로 출력한다.
	 * @param typeNameOfException : statement가 return문일 경우 null이다.
	 * @param coreThreadID */
	public static boolean checkSynchronizedAndFinally(ByteCodeGeneratorForClass generator, FindSpecialStatementParams statement, 
			String typeNameOfException, HighArrayCharForByteCode result, int coreThreadID) {
		Compiler compiler = generator.compiler;
		// throw문일 경우 true, return문일 경우 false
		// throwOrReturn을 true로 설정하면 return문은 throw문 처럼 finally를 만나면 가상머신에게
		// finally 처리를 맡긴다. 
		// throwOrReturn을 false로 설정하면 throw문과 다르게 synchronized(모니터해제), 
		// finally를 순서대로 출력한다.
		// continue, break문도 throwOrReturn을 false값으로 한다.
		
		
		
		boolean bResult = false;
		
		int countOfSynchronized = 0;
		ReturnOfGetCountOfSynchronizedAndFinallyJustBeforeCatch r = 
				getCountOfSynchronizedAndFinallyJustBeforeCatch(generator, statement, typeNameOfException);
		
		countOfSynchronized = r.countOfSynchronized;
		int loopCountOfFinally;
		ArrayListInt listOfLoopCountsOfSynchronized_backup = r.listOfLoopCountsOfSynchronized;
	
		
		int k, j;
		// synchronized(모니터해제)와 finally를 merge한다.
		if (r.listOfLoopCountsOfFinally.count>0) {
			listOfLoopCountsOfSynchronized_backup = (ArrayListInt)r.listOfLoopCountsOfSynchronized.clone();
					
			// newArr에 synchronized리스트와 finally리스트를 넣는다.
			int[] newArr = new int[r.listOfLoopCountsOfSynchronized.count+r.listOfLoopCountsOfFinally.count];
			for (k=0; k<r.listOfLoopCountsOfSynchronized.count; k++) {
				newArr[k] = r.listOfLoopCountsOfSynchronized.getItem(k);
			}
			int curCount = r.listOfLoopCountsOfSynchronized.count;
			for (k=0; k<r.listOfLoopCountsOfFinally.count; k++) {
				newArr[curCount+k] = r.listOfLoopCountsOfFinally.getItem(k);
			}
			// 넣어진 synchronized리스트와 finally리스트를 sort한다.
			Sort.sort(newArr);
			
			// finally리스트가 없고 synchronized리스트만 있더라도 동작한다.
			// synchronized리스트가 없고 finally리스트만 있더라도 동작한다.
			r.listOfLoopCountsOfSynchronized.list = newArr;
			r.listOfLoopCountsOfSynchronized.count = newArr.length;
			countOfSynchronized = r.listOfLoopCountsOfSynchronized.count;
			
		}//if (r.listOfLoopCountsOfFinally.count>0) {
		
		
		// merge한 synchronized(모니터해제)와 finally를 순서대로 출력한다.
		for (k=0; k<countOfSynchronized; k++) {
			int loopCountOfSynchronized = r.listOfLoopCountsOfSynchronized.getItem(k);
			
			loopCountOfFinally = -1;
			FindControlBlockParams finallyBlock = null;
			for (j=0; j<r.listOfLoopCountsOfFinally.count; j++) {
				loopCountOfFinally = r.listOfLoopCountsOfFinally.getItem(j);
				if (loopCountOfSynchronized==loopCountOfFinally) {
					finallyBlock = (FindControlBlockParams) r.listOfFinallyBlocks.getItem(j);
					break;
				}
			}			
			
			// loopCountOfFinally가 -1이면 위 루프에서 매핑이 안 되었으므로 
			// synchronized이다.
			
			if (loopCountOfSynchronized==loopCountOfFinally) { // finally이면
				//if (!throwOrReturn) {
					// 리턴문일 경우 catch를 신경 쓸 필요가 없이 function을 만날 때까지 
					// synchronized와 finally의 개수를 확인한다.
					// return문이면 return을 하기 전에 먼저 finally를 출력한다.
					result.add("// finally starts\n");
					ControlBlock.printControlBlockBody(generator, finallyBlock, result, coreThreadID);
					result.add("// finally ends\n");
				
				//Specials.printFinally_NotHandler(generator, finallyBlock, result, true);
					
					// finally블록에 throw, return문등을 포함하면
					/*if (containsThrowOrReturnOrBreakOrContinue(generator, finallyBlock, finallyBlock)) {
						bResult = true;
						break;
						//return true;
					}*/
					
					// finally가 중첩되어 있을 경우 그 finally를 다시 출력해야 한다.
				/*}
				else {
					// throw문일 경우 finally를 만나면 break한다.
					// throw문일 경우 catch가 되거나 finally를 만날때까지의 모니터만 해제한다.
					break;
				}*/
			}
			else {
				// 모니터를 해제한다.
				FindSpecialBlockParams synchronizedBlock = null;
				if (r.listOfLoopCountsOfFinally.count==0) {
					synchronizedBlock = (FindSpecialBlockParams) r.listOfSynchronizedBlocks.getItem(k);
				}
				else {
					for (j=0; j<listOfLoopCountsOfSynchronized_backup.count; j++) {
						int loopCountOfSynchronized_backup = listOfLoopCountsOfSynchronized_backup.getItem(j);
						if (loopCountOfSynchronized==loopCountOfSynchronized_backup) {
							synchronizedBlock = (FindSpecialBlockParams) r.listOfSynchronizedBlocks.getItem(j);
							break;
						}
					}
				}
				
				if (synchronizedBlock==null) {
					FindFunctionParams func = (FindFunctionParams) Compiler.getParent(statement.parent);
					if (func.accessModifier!=null && func.accessModifier.isSynchronized) {
						Synchronized.printSynchronizedObjectOfFunction(generator, func, result, coreThreadID);
						
						// throw(return)되기 전에 모니터를 해제한다.
						String srcIndex = ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(generator.compiler, func.functionNameIndex());
						result.add("monitorexit // "+srcIndex+"\n");
						//Synchronized.print_setBooleanValueToBitMaskArr(generator, func, result, false);
					}
				}
				else {
					// synchronized 괄호 안에 있는 잠금 오브젝트
					int startIndex = Compiler.getIndexInmListOfAllVarUses(
							compiler.data.mBuffer, compiler.data.mlistOfAllVarUses, 0, 
							synchronizedBlock.indexOfLeftParenthesis(), true);
					int endIndex = Compiler.getIndexInmListOfAllVarUses(
							compiler.data.mBuffer, compiler.data.mlistOfAllVarUses, startIndex, 
							synchronizedBlock.indexOfRightParenthesis(), false);
					generator.traverse(startIndex, endIndex, result);
					
					// throw(return)되기 전에 모니터를 해제한다.
					String srcIndex = ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(generator.compiler, synchronizedBlock.nameIndex());
					result.add("monitorexit // "+srcIndex+"\n");
					//Synchronized.print_setBooleanValueToBitMaskArr(generator, synchronizedBlock, result, false);
				}
			}
		}//for (k=0; k<countOfSynchronized; k++) {
		
		return bResult;
	}
	
	
		
		
		
		/**parent인 try블록에 연결된 fially블록을 얻는다. 
		 * @param parentBlock : try block의 parent블록
		 * @param indexInlistOfControlBlocksOfParent : parent블록 내의 listOfControlBlocks내에서 
		 * 		try 블록의 인덱스*/
		public static FindControlBlockParams getFinallyBlockOfTry(ByteCodeGeneratorForClass generator, Block parentBlock, int indexInlistOfControlBlocksOfParent) {
			Compiler compiler = generator.compiler;
			int i;
			int len = parentBlock.listOfControlBlocks.count;
			// try-catch-finally의 끝을 찾는다.
			for (i=indexInlistOfControlBlocksOfParent+1; i<len; i++) {
				FindControlBlockParams control = (FindControlBlockParams) parentBlock.listOfControlBlocks.getItem(i);
				CodeString name = CompilerHelper.getNameOfControlBlock(compiler, control);
				if (name.equals("catch")) {
				}
				else if (name.equals("finally")) {
					return control;
				}
				else { // catch, finally를 제외한 controlBlock이 나오면 
					return null;
				}
			}//for (i=indexInParent+1; i<len; i++) {
			return null;
		}
		
		
		
		
		
		public static void printTry(ByteCodeGeneratorForClass generator, FindControlBlockParams controlBlock, HighArrayCharForByteCode result, int coreThreadID) {
			Compiler compiler = generator.compiler;
			
			try {
				FindFunctionParams func = (FindFunctionParams) CompilerStatic.getParent(controlBlock);
				
			String index = null;
			index = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)9, null);
			result.add("// "+index+"try starts"+"\n");
			
			
			
			//result.add("nop // "+strmBufferIndexWithoutCommaAndBlank+"\n");
			
			FindSpecialBlockParams special = (FindSpecialBlockParams) controlBlock;
			if (special.anotherName!=null && special.anotherName.equals(ByteCode_Types.TryFinallyShieldForFuncWithSync)) {
				if (func.accessModifier!=null && func.accessModifier.isSynchronized) {
					result.add("// synchronized starts"+"\n");
					
					Synchronized.printSynchronizedObjectOfFunction(generator, func, result, coreThreadID);
					
					result.add("monitorenter // "+ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(generator.compiler, func.findBlockParams.startIndex())+"\n");
					//Synchronized.print_setBooleanValueToBitMaskArr(generator, func, result, true);
				}
			}
			
			String strIndex = "";		
			
			ControlBlock.printControlBlockBody(generator, controlBlock, result, coreThreadID);
			
			
			if (special.anotherName!=null && special.anotherName.equals(ByteCode_Types.TryFinallyShieldForFuncWithSync)) {
				if (func.accessModifier!=null && func.accessModifier.isSynchronized) {
					// 잠기워진 오브젝트
					Synchronized.printSynchronizedObjectOfFunction(generator, func, result, coreThreadID);
					
					result.add("monitorexit // "+ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(generator.compiler, func.findBlockParams.endIndex())+"\n");
					
					//Synchronized.print_setBooleanValueToBitMaskArr(generator, func, result, false);
					result.add("// synchronized ends"+"\n");
				}
			}
			
			/*result.add("nop // "+"\n");
			result.add("// BeforeGoTo\n");
			result.add("nop // "+"\n");*/
						
			int indexInlistOfControlBlocksOfParent = controlBlock.indexInListOfControlBlocksOfParent;
			FindControlBlockParams lastBlock = 
					getLastBlockOfTry_Catch_Finally(generator, controlBlock.parent, indexInlistOfControlBlocksOfParent);
			
			String strmBufferIndex = null;
			if (!controlBlock.isFake) {
				strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, controlBlock.endIndex());
			}
			else {
				strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, func.endIndex());
			}
			
			// 예외는 발생하지 않았다.
			CodeString name = CompilerHelper.getNameOfControlBlock(compiler, lastBlock);
			if (name.equals("finally")) {
				// 다음에 finally가 있을 경우, finally의 코드들을 실행한다.
				//   try {
				//      j=2;
				//      System.out.println("j : "+j);
				//      return;
				//   }
				//   finally {
				//	   j=3;
				//     System.out.println("j : "+j);
				//	 }
				// 이런 경우 try내에 return문이 있으므로 finally를 여기에서는 출력을 하지 않고 
				// 위에 있는 printControlBlockBody()의 printReturn()에서 출력한다.
				/*if (!containsThrowOrReturnOrBreakOrContinue(generator, controlBlock, controlBlock) &&
						!containsThrowOrReturnOrBreakOrContinue(generator, lastBlock, lastBlock)) {	
					result.add("// finally starts\n");
					ControlBlock.printControlBlockBody(generator, lastBlock, result);
					result.add("// finally ends\n");
				}*/
				if (!containsThrowOrReturnOrBreakOrContinue(generator, controlBlock, controlBlock)) {	
					strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, lastBlock, (byte)6, null);
					result.add("goto_w "+"// "+strIndex+"go to finally"+strmBufferIndex+"\n");
				}
				// 바깥 문장 리스트에 throw, return문을 포함하면 goto를 출력하지 않는다.
				// finally의 바깥 문장 리스트에 throw, return문을 포함하면 goto를 출력하지 않는다.
				//if (!containsThrowOrReturnOrBreakOrContinue(generator, controlBlock, controlBlock)/* &&
				//		!containsThrowOrReturnOrBreakOrContinue(generator, lastBlock, lastBlock)*/) {	
				//	strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, lastBlock, (byte)7, null);
				//	result.add("goto_w "+"// "+strIndex+"go to exit of try-catch-finally"+strmBufferIndex+"\n");
				//	controlBlock.tryCatchFinallyHasGoTo = true;
				//}*/
			}
			else {
				// 다음에 finally가 없이 catch만 있을 경우
				// 바깥 문장 리스트에 throw, return문을 포함하면 goto를 출력하지 않는다.
				if (!containsThrowOrReturnOrBreakOrContinue(generator, controlBlock, controlBlock)) {
					strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, lastBlock, (byte)7, null);
					result.add("goto_w "+"// "+strIndex+"go to exit of try-catch-finally"+strmBufferIndex+"\n");
					controlBlock.tryCatchFinallyHasGoTo = true;
				}
			}		
			
			LocalVar.printsLocalVarEnd(generator, controlBlock, result);
			
			index = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)2, null);
			result.add("// "+index+"exit of try"+"\n");
			
			}catch(Exception e) {
				if (Common_Settings.g_printsLog) e.printStackTrace();
			}
		}
		
		/** try-catch-finally의 끝은 catch이거나 finally가 된다.
		 * 발생한 예외를 catch의 괄호안에 있는 예외선언에 저장한다.
		 * try-catch-finally의 끝이면 exit of try-catch-finally을 출력한다.
		 * @param coreThreadID */
		public static void printCatch(ByteCodeGeneratorForClass generator, FindControlBlockParams controlBlock, HighArrayCharForByteCode result, int coreThreadID) {
			Compiler compiler = generator.compiler;
			
			FindControlBlockParams tryBlock = getTryBlockOfCatchOrFinally(generator, controlBlock.parent, 
					controlBlock.indexInListOfControlBlocksOfParent);
			String index = ", T// "+ByteCode_Helper.getStringOfmBufferIndex(compiler, tryBlock, (byte)9, null);
			String index2 = ", T// "+ByteCode_Helper.getStringOfmBufferIndex(compiler, tryBlock, (byte)2, null);
			//String index2 = ", T// "+ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)9, null);
			
			FindVarParams exceptionVar = 
					(FindVarParams) controlBlock.listOfStatementsInParenthesis.getItem(0);
			FindClassParams classParams = 
					Loader.loadClass(compiler, exceptionVar.typeName, coreThreadID);
			String descriptor = TypeDescriptor.getDescriptorExceptLAndSemicolon(classParams, coreThreadID);
			
			String strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)9, null);
					
			result.add("// "+strIndex+"catch starts"+index+index2+" // "+descriptor+"\n");
			
			
			FindFunctionParams func = (FindFunctionParams) CompilerStatic.getParent(controlBlock);
			
			
			
			//result.add("nop // "+strmBufferIndexWithoutCommaAndBlank+"\n");
			
			//String strIndex = "";
			
			FindVarParams var = 
					(FindVarParams) controlBlock.listOfStatementsInParenthesis.getItem(0);
			
			FindVarParams varBeforeProcessLocalVars = var; 
			
			
			
			if (var.sharedVar!=null) {
				// 지역변수가 스코프는 허용되나 중복변수일 경우 원래의 공유변수를 가져온다.
				var = var.sharedVar;
			}
			
			
			
			int localVarTableIndex = LocalVar.getLocalVarTableIndex(generator, func, var);
			
			// 중복변수일 경우 중복처리하기 전 변수의 indexOfLocalVarsInFunctionBeforeProcessLocalVars을,
			// 중복변수가 아니면 그 변수의 indexOfLocalVarsInFunctionBeforeProcessLocalVars을 구한다.
			String strindexOfLocalVarsInFunctionBeforeProcessLocalVars = 
					varBeforeProcessLocalVars.sharedVar!=null ?
						", "+varBeforeProcessLocalVars.indexOfLocalVarsInFunctionBeforeProcessLocalVars : 
							", "+var.indexOfLocalVarsInFunctionBeforeProcessLocalVars;
			
			String strmBufferIndex = null;
			if (!controlBlock.isFake) {
				strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, controlBlock.nameIndex());
			}
			else {
				strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, func.endIndex());
			}
			
			// 발생한 예외를 catch의 괄호안에 있는 예외선언에 저장한다.
			result.add("astore_"+localVarTableIndex+ " // local "+var.getVarStr(coreThreadID)+strindexOfLocalVarsInFunctionBeforeProcessLocalVars+strmBufferIndex+"\n");
			
			if (!controlBlock.isFake) {
				ControlBlock.printControlBlockBody(generator, controlBlock, result, coreThreadID);
			}
			else {
				Console.callsPrintStackTraceInFakeCatchBlock(generator, 
						(FindSpecialBlockParams)controlBlock, result, coreThreadID);
			}
			
			
			
			int indexInlistOfControlBlocksOfParent = controlBlock.indexInListOfControlBlocksOfParent;
			FindControlBlockParams lastBlock = 
					getLastBlockOfTry_Catch_Finally(generator, controlBlock.parent, indexInlistOfControlBlocksOfParent);
			
			CodeString name = CompilerHelper.getNameOfControlBlock(compiler, lastBlock);
			
			if (lastBlock==controlBlock) {
				LocalVar.printsLocalVarEnd(generator, controlBlock, result);
				
				// 다음에 catch, finally가 없는 경우, 즉 현재 catch로 끝날 경우
				//index = "("+controlBlock.findBlockParams.endIndex()+"), ";
				index = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)2, null);
				result.add("// "+index+"exit of catch"+"\n");
				strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, lastBlock, (byte)7, null);
				result.add("// "+strIndex+"exit of try-catch-finally"+"\n");
			}
			else {
				/*result.add("nop // "+"\n");
				result.add("// BeforeGoTo\n");
				result.add("nop // "+"\n");*/
				
				if (name.equals("finally")) { 
					// 다음에 finally가 있을 경우, finally의 코드들을 실행한다.
					//   catch(Exception e) {
					//       j=2;
				    //      System.out.println("j : "+j);
				    //      return;
					//   }
					//   finally {
					//	   j=3;
				    //     System.out.println("j : "+j);
				    //	 }
					// 이런 경우 catch내에 return문이 있으므로 finally를 여기에서는 출력을 하지 않고 
					// 위에 있는 printControlBlockBody()의 printReturn()에서 출력한다.
					/*if (!containsThrowOrReturnOrBreakOrContinue(generator, controlBlock, controlBlock) && 
							!containsThrowOrReturnOrBreakOrContinue(generator, lastBlock, lastBlock)) {	
						result.add("// finally starts\n");
						ControlBlock.printControlBlockBody(generator, lastBlock, result);
						result.add("// finally ends\n");
					}*/
					if (!containsThrowOrReturnOrBreakOrContinue(generator, controlBlock, controlBlock)/* &&
							!containsThrowOrReturnOrBreakOrContinue(generator, lastBlock, lastBlock)*/) {	
						strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, lastBlock, (byte)6, null);
						result.add("goto_w "+"// "+strIndex+"go to finally"+strmBufferIndex+"\n");
					}
					// 바깥 문장 리스트에 throw문을 포함하면 goto를 출력하지 않는다.
					// finally의 바깥 문장 리스트에 throw, return문을 포함하면 goto를 출력하지 않는다.
					/*if (!containsThrowOrReturnOrBreakOrContinue(generator, controlBlock, controlBlock) && 
							!containsThrowOrReturnOrBreakOrContinue(generator, lastBlock, lastBlock)) {	
						strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, lastBlock, (byte)7, null);
						strmBufferIndex = ByteCode_Helper.getSourceLineNumber(controlBlock.endIndex());
						result.add("goto_w "+"// "+strIndex+"go to exit of try-catch-finally"+strmBufferIndex+"\n");
						controlBlock.tryCatchFinallyHasGoTo = true;
					}*/
				}
				else {
					// 다음에 finally가 없이 catch만 있을 경우
					// 바깥 문장 리스트에 throw문을 포함하면 goto를 출력하지 않는다.
					if (!containsThrowOrReturnOrBreakOrContinue(generator, controlBlock, controlBlock)) {
						strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, lastBlock, (byte)7, null);
						strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, controlBlock.endIndex());
						result.add("goto_w "+"// "+strIndex+"go to exit of try-catch-finally"+strmBufferIndex+"\n");
						controlBlock.tryCatchFinallyHasGoTo = true;
					}
				}			
			
				LocalVar.printsLocalVarEnd(generator, controlBlock, result);
				
				index = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)2, null);
				result.add("// "+index+"exit of catch"+"\n");
			}
		}
		
		/** try-catch-finally의 끝은 catch이거나 finally가 된다.
		 * try-catch-finally의 끝이면 exit of try-catch-finally을 출력한다.
		 * @param coreThreadID 
		 * @param printsExitOfTry_Catch_Finally : 
		 * throw문이나 return문을 만났을때 finally절로 이동을 한후 예외를 throw하거나 리턴을 해야하므로 
		 * 이 때는 exit of try-catch-finally을 출력하지 않는다.*/
		public static void printFinally_NotHandler(ByteCodeGeneratorForClass generator, FindControlBlockParams controlBlock, /*boolean printsExitOfTry_Catch_Finally,*/ 
				HighArrayCharForByteCode result, int coreThreadID) {
			Compiler compiler = generator.compiler;
			
			///////////// 예외가 발생했을때 실행되는 finally ///////////////////
			
			
		
			String strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)6, null);
			result.add("// "+strIndex+"finally starts"+"\n");
			
			
			if (!controlBlock.isFake) {
				ControlBlock.printControlBlockBody(generator, controlBlock, result, coreThreadID);
			}
			else {
				// Refer to Synchronized.putTryFinallyShieldForMonitorExitInFunctionWithSynchronized()
				FindFunctionParams func = (FindFunctionParams) CompilerStatic.getParent(controlBlock);
				Synchronized.printMonitorExitInEndOfFunc(generator, func, result, coreThreadID);
			}
			
			
			LocalVar.printsLocalVarEnd(generator, controlBlock, result);
			
			
			strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)8, null);
			result.add("// "+strIndex+"finally ends"+"\n");
			
			
			///////////// 예외가 발생하지 않았을때 실행되는 finally ///////////////////
			
		
			
			//if (printsExitOfTry_Catch_Finally) {
				
			//}
			
			
		}
		
		
		public static void printFinally_handler(ByteCodeGeneratorForClass generator, FindControlBlockParams controlBlock,  
				HighArrayCharForByteCode result, int coreThreadID) {
			Compiler compiler = generator.compiler;
			
			///////////// 예외가 발생했을때 실행되는 finally ///////////////////
			
			FindControlBlockParams tryBlock = getTryBlockOfCatchOrFinally(generator, controlBlock.parent, 
					controlBlock.indexInListOfControlBlocksOfParent);
			FindControlBlockParams[] catchBlocks = Specials.getCatchBlocksOfTry(generator, tryBlock.parent, tryBlock.indexInListOfControlBlocksOfParent);
			FindControlBlockParams lastCatchBlock = tryBlock;
			if (catchBlocks!=null && catchBlocks.length>0) {
				lastCatchBlock = catchBlocks[catchBlocks.length-1];
			}
			//String index = ", T// ("+tryBlock.nameIndex()+")";
			// try블록의 끝 또는 catch블록이 있을 경우 마지막 catch블록의 끝
			//String index2 = ", T// ("+lastCatchBlock.findBlockParams.endIndex()+")";
			
			String index = ", T// "+ByteCode_Helper.getStringOfmBufferIndex(compiler, tryBlock, (byte)9, null);
			String index2 = ", T// "+ByteCode_Helper.getStringOfmBufferIndex(compiler, lastCatchBlock, (byte)2, null);
			
			
			String strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)9, null);
			result.add("// "+strIndex+"finally (handler) starts"+index+index2+"\n");
			
			FindFunctionParams func = (FindFunctionParams) Compiler.getParent(controlBlock);
			
			// FindAllClassesAndItsMembers2()의 뒷부분에서 finally의 listOfStatementsInParenthesis에
			// Throwable변수를 저장한다.
			FindVarParams var = func.getVar(ByteCode_Types.throwableVarNameForFinallyBlock);
			FindVarParams varBeforeProcessLocalVars = var;
			if (var.sharedVar!=null) {
				var = var.sharedVar;
			}
			
			int localVarTableIndex = LocalVar.getLocalVarTableIndex(generator, func, var);
			
			
			// 중복변수일 경우 중복처리하기 전 변수의 indexOfLocalVarsInFunctionBeforeProcessLocalVars을,
			// 중복변수가 아니면 그 변수의 indexOfLocalVarsInFunctionBeforeProcessLocalVars을 구한다.
			String strindexOfLocalVarsInFunctionBeforeProcessLocalVars = 
						", "+varBeforeProcessLocalVars.indexOfLocalVarsInFunctionBeforeProcessLocalVars;
			
			strindexOfLocalVarsInFunctionBeforeProcessLocalVars = 
					strindexOfLocalVarsInFunctionBeforeProcessLocalVars+", "+varBeforeProcessLocalVars.getVarStr(coreThreadID);
			
			String strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, controlBlock.nameIndex());
						
			// 발생한 예외를 finally 예외선언 java.lang.Throwable 지역변수에 저장한다.
			result.add("astore_"+localVarTableIndex+ " // local "+var.getVarStr(coreThreadID)+strindexOfLocalVarsInFunctionBeforeProcessLocalVars+strmBufferIndex+"\n");
			
			
			//this.printControlBlockBody(controlBlock, result)
			// 제어블록내에 있는 문장들을 수행한다.
			int i;
			for (i=0; i<controlBlock.listOfStatements.count; i++) {
				FindStatementParams statement = (FindStatementParams) controlBlock.listOfStatements.getItem(i);
				// 현재 문장이 throw, return문이면 뒤에서 예외를 throw하기 때문에 출력하지 않는다.
				//if (this.isThrowOrReturn(statement)) {				
				//	break;
				//}
				// printFinally()는 발생한 예외를 throw를 해야 하므로 java.lang.Throwable를 throw를 하기 전에 
				// throw나 return문을 출력하지 못하도록 강제해야 한다.
				generator.printFindStatementParams(statement, result, coreThreadID);
				
			}
			
			// 발생한 예외를 throw하여 전파한다.
			FindSpecialStatementParams special = new FindSpecialStatementParams(compiler, -1, -1, -1);
			special.isFake = true;
			special.parent = controlBlock;
			printThrow(generator, special, result, coreThreadID);
			
			LocalVar.printsLocalVarEnd(generator, controlBlock, result);
			
			strIndex = "("+(controlBlock.endIndex()-1)+"), ";
			//strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)8, null);
			result.add("// "+strIndex+"exit of finally (handler)"+"\n");
		}
		
		/** try-catch-finally의 끝은 catch이거나 finally가 된다.
		 * try-catch-finally의 끝이면 exit of try-catch-finally을 출력한다.
		 * @param coreThreadID 
		 * @param printsExitOfTry_Catch_Finally : 
		 * throw문이나 return문을 만났을때 finally절로 이동을 한후 예외를 throw하거나 리턴을 해야하므로 
		 * 이 때는 exit of try-catch-finally을 출력하지 않는다.*/
		public static void printFinally(ByteCodeGeneratorForClass generator, FindControlBlockParams controlBlock,  
				HighArrayCharForByteCode result, int coreThreadID) {
			
			//printFinally_handler(generator, controlBlock, result);
			
			///////////// 예외가 발생하지 않았을때 실행되는 finally ///////////////////
			
		
			
			Compiler compiler = generator.compiler;
			
			///////////// 예외가 발생했을때 실행되는 finally ///////////////////
			
			FindControlBlockParams tryBlock = getTryBlockOfCatchOrFinally(generator, controlBlock.parent, 
					controlBlock.indexInListOfControlBlocksOfParent);
			FindControlBlockParams[] catchBlocks = Specials.getCatchBlocksOfTry(generator, tryBlock.parent, tryBlock.indexInListOfControlBlocksOfParent);
			FindControlBlockParams lastCatchBlock = tryBlock;
			if (catchBlocks!=null && catchBlocks.length>0) {
				lastCatchBlock = catchBlocks[catchBlocks.length-1];
			}
			//String index = ", T// ("+tryBlock.nameIndex()+")";
			// try블록의 끝 또는 catch블록이 있을 경우 마지막 catch블록의 끝
			//String index2 = ", T// ("+lastCatchBlock.findBlockParams.endIndex()+")";
			
			String index = ", T// "+ByteCode_Helper.getStringOfmBufferIndex(compiler, tryBlock, (byte)9, null);
			String index2 = ", T// "+ByteCode_Helper.getStringOfmBufferIndex(compiler, lastCatchBlock/*tryBlock*/, (byte)2, null);
			
			// '{''s index in finally {
			String strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)0, null);
			if (controlBlock.isFake) {
				strIndex = "("+ByteCode_Types.startIndexOfFakeFinallyHandlerInFuncWithSync+"), ";
			}
			result.add("// "+strIndex+"finally (handler) starts"+index+index2+"\n");
			
			FindFunctionParams func = (FindFunctionParams) Compiler.getParent(controlBlock);
			
			// FindAllClassesAndItsMembers2()의 뒷부분에서 finally의 listOfStatementsInParenthesis에
						// Throwable변수를 저장한다.
			FindVarParams var = func.getVar(ByteCode_Types.throwableVarNameForFinallyBlock);
			FindVarParams varBeforeProcessLocalVars = var;
			if (var.sharedVar!=null) {
				var = var.sharedVar;
			}
			
			int localVarTableIndex = LocalVar.getLocalVarTableIndex(generator, func, var);
			
			
			// 중복변수일 경우 중복처리하기 전 변수의 indexOfLocalVarsInFunctionBeforeProcessLocalVars을,
			// 중복변수가 아니면 그 변수의 indexOfLocalVarsInFunctionBeforeProcessLocalVars을 구한다.
			String strindexOfLocalVarsInFunctionBeforeProcessLocalVars = 
						", "+varBeforeProcessLocalVars.indexOfLocalVarsInFunctionBeforeProcessLocalVars;
			
			strindexOfLocalVarsInFunctionBeforeProcessLocalVars = 
					strindexOfLocalVarsInFunctionBeforeProcessLocalVars+", "+varBeforeProcessLocalVars.getVarStr(coreThreadID);
			
			String strmBufferIndex = null;
			if (controlBlock.isFake) {
				strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, controlBlock.nameIndex());
			}
			else {
				strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, func.endIndex());
			}
						
			// 발생한 예외를 finally 예외선언 java.lang.Throwable 지역변수에 저장한다.
			result.add("astore_"+localVarTableIndex+ " // local "+var.getVarStr(coreThreadID)+strindexOfLocalVarsInFunctionBeforeProcessLocalVars+strmBufferIndex+"\n");
			
			
			Specials.print_setBooleanValueToBitMaskArr(generator, controlBlock, result, true, coreThreadID);
			
			//strIndex = "("+(controlBlock.endIndex()-1)+"), ";
			strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)2, null);
			result.add("// "+strIndex+"exit of finally (handler)"+"\n");
			
			Specials.printFinally_NotHandler(generator, controlBlock, result, coreThreadID);
			
			if (!containsThrowOrReturnOrBreakOrContinue(generator, controlBlock, controlBlock)) {
				Specials.printThrowInEndOfFinally(generator, controlBlock, result, coreThreadID);
			}
			
			strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)7, null);
			result.add("// "+strIndex+"exit of try-catch-finally"+"\n");
		}
		
		
		
		static ArrayListInt listOfFinallyIndices = null;
		static ArrayList listOfFinallyBlocks = null;
		
		static int getSerialNumberInBitMaskArr(FindFunctionParams func, int mBufferIndexOfFinallyKeyword) {
			if (listOfFinallyIndices==null) {
				listOfFinallyIndices = new ArrayListInt(2);
				listOfFinallyBlocks = new ArrayList(2);
				
				findFinallyBlocks(func, listOfFinallyIndices, listOfFinallyBlocks);		
			}// if (listOfFinallyIndices==null) {
			
			int count = 0;
			int i;
			for (i=0; i<listOfFinallyIndices.count; i++) {
				int indexName = listOfFinallyIndices.getItem(i);
				if (indexName==mBufferIndexOfFinallyKeyword) return count;
				count++;
			}
			return -1;
		}
		
		static void findFinallyBlocks(FindFunctionParams func, ArrayListInt listOfFinallyIndices, ArrayList listOfFinallyBlocks) {
			int i;
			for (i=0; i<func.listOfControlBlocks.count; i++) {
				FindControlBlockParams block = (FindControlBlockParams) func.listOfControlBlocks.getItem(i);
				if (block.getName().equals("finally")) {
					FindSpecialBlockParams special = (FindSpecialBlockParams) block;
					if (!block.isFake) {
						listOfFinallyIndices.add(special.nameIndex());
					}
					else {
						int fakeIndex = ByteCode_Types.getFakeTryCatchFinallyIndex(special, 0);
						listOfFinallyIndices.add(fakeIndex);
					}
					listOfFinallyBlocks.add(special);
				}
				findFinallyBlocks_sub(block, listOfFinallyIndices, listOfFinallyBlocks);
			}	
		}
		
		static void findFinallyBlocks_sub(FindControlBlockParams parentBlock, ArrayListInt listOfFinallyIndices, ArrayList listOfFinallyBlocks) {
			int i;
			for (i=0; i<parentBlock.listOfControlBlocks.count; i++) {
				FindControlBlockParams block = (FindControlBlockParams) parentBlock.listOfControlBlocks.getItem(i);
				if (block.getName().equals("finally")) {
					FindSpecialBlockParams special = (FindSpecialBlockParams) block;
					listOfFinallyIndices.add(special.nameIndex());
					listOfFinallyBlocks.add(special);
				}
				findFinallyBlocks_sub(block, listOfFinallyIndices, listOfFinallyBlocks);
			}
		}
		
		public static void printThrowInEndOfFinally(ByteCodeGeneratorForClass generator, FindControlBlockParams controlBlock, 
				HighArrayCharForByteCode result, int coreThreadID) {
			
			String strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, controlBlock.startIndex());
			Compiler compiler = generator.compiler;
			
			print_getBooleanValueFromBitMaskArr(generator, controlBlock, result, coreThreadID);
			
			int mBufferIndexOfFinally = -1;
			FindFunctionParams func = null;
			if (!controlBlock.isFake) {
				mBufferIndexOfFinally = controlBlock.nameIndex();
			}
			else {
				mBufferIndexOfFinally = ByteCode_Types.getFakeTryCatchFinallyIndex((FindSpecialBlockParams)controlBlock, 0);
			}
			func = (FindFunctionParams) Compiler.getParent(controlBlock);
		
			int sn = getSerialNumberInBitMaskArr(func, mBufferIndexOfFinally);
			
			// All finallys has a different strIndex, label and offset.
			
			String strIndex = "("+(3000000+sn)+"), ";
			result.add("ifle // "+strIndex+"go to exit of fake if"+strmBufferIndex+"\n"); // 
			
			String strIndex2 = "("+(3000000+100+sn)+"), ";
			result.add("// "+strIndex2+"exit_of_condition of "+"fake if"+"\n");
			
			// 발생한 예외를 throw하여 전파한다.
			FindSpecialStatementParams special = new FindSpecialStatementParams(compiler, -1, -1, -1);
			special.isFake = true;
			special.parent = controlBlock;
			printThrow(generator, special, result, coreThreadID);
			
			result.add("// "+strIndex+"exit of fake if"+"\n");
		}
		
		public static void print_setBooleanValueToBitMaskArr(ByteCodeGeneratorForClass generator, 
				FindControlBlockParams controlBlock, HighArrayCharForByteCode result, boolean booleanValue, int coreThreadID) {
			int mBufferIndexOfFinally = -1;
			FindFunctionParams func = null;
			if (!controlBlock.isFake) {
				mBufferIndexOfFinally = controlBlock.nameIndex();
			}
			else {
				mBufferIndexOfFinally = ByteCode_Types.getFakeTryCatchFinallyIndex((FindSpecialBlockParams)controlBlock, 0);
			}
			func = (FindFunctionParams) Compiler.getParent(controlBlock);
			
			// loads parameters of setBooleanValueFromBitMaskArrFunc()
			
			// prints serialNumberInBitMaskArr
			int sn = getSerialNumberInBitMaskArr(func, mBufferIndexOfFinally);
			if (!controlBlock.isFake) {
				generator.printSmallIntegerNumber(sn, result, mBufferIndexOfFinally);
			}
			else {
				generator.printSmallIntegerNumber(sn, result, func.endIndex());
			}
			
			FindVarParams var = func.getVar("bitMaskArrForFinally");
			
			int localTableIndex = var.indexOfLocalVariableTable;
			
			FindVarParams varBeforeProcessLocalVars = var;
			if (var.sharedVar!=null) {
				var = var.sharedVar;
			}
					
			// 중복변수일 경우 중복처리하기 전 변수의 indexOfLocalVarsInFunctionBeforeProcessLocalVars을,
			// 중복변수가 아니면 그 변수의 indexOfLocalVarsInFunctionBeforeProcessLocalVars을 구한다.
			String strindexOfLocalVarsInFunctionBeforeProcessLocalVars = 
						", "+varBeforeProcessLocalVars.indexOfLocalVarsInFunctionBeforeProcessLocalVars;
			
			strindexOfLocalVarsInFunctionBeforeProcessLocalVars = 
					strindexOfLocalVarsInFunctionBeforeProcessLocalVars+", "+varBeforeProcessLocalVars.getVarStr(coreThreadID);
			
			String strmBufferIndex = null;
			String strmBufferIndexWithoutCommaAndBlank = null;
			if (!controlBlock.isFake) {
				strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, controlBlock.nameIndex());
				strmBufferIndexWithoutCommaAndBlank = ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(generator.compiler, controlBlock.nameIndex());
			}
			else {
				strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, func.endIndex());
				strmBufferIndexWithoutCommaAndBlank = ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(generator.compiler, func.endIndex());
			}
			
			// prints bitMaskArr
			result.add("iload_"+localTableIndex + " // local "+var.getVarStr(coreThreadID)+strindexOfLocalVarsInFunctionBeforeProcessLocalVars+strmBufferIndex+"\n");
			
			int booleanValueInt = 0;
			if (booleanValue) booleanValueInt = 1;
			// prints booleanValue
			int srcIndex = -1;
			if (!controlBlock.isFake) {
				srcIndex = mBufferIndexOfFinally;
			}
			else {
				srcIndex = func.endIndex();
			}
			generator.printSmallIntegerNumber(booleanValueInt, result, srcIndex);
			result.add("i2z // "+strmBufferIndexWithoutCommaAndBlank+"\n");
			
			FindFunctionParams setBooleanValueToBitMaskArrFunc = 
					Synchronized.setBooleanValueToBitMaskArr(generator, srcIndex, coreThreadID);
			
			// calls setBooleanValueToBitMaskArrFunc()
			generator.physical.makeCONSTANT_Method_infoAndPutItIntolistOfConstantTable(setBooleanValueToBitMaskArrFunc, coreThreadID);
			result.add("invokestatic // "+setBooleanValueToBitMaskArrFunc.getMethodInfoStr(coreThreadID)+
					strmBufferIndex+"\n");
			
			// set bitMaskArr with return value 
			result.add("istore_"+localTableIndex + " // local "+var.getVarStr(coreThreadID)+strindexOfLocalVarsInFunctionBeforeProcessLocalVars+strmBufferIndex+"\n");
		}
		
		public static void print_getBooleanValueFromBitMaskArr(ByteCodeGeneratorForClass generator, 
				FindControlBlockParams controlBlock, HighArrayCharForByteCode result, int coreThreadID) {
			int mBufferIndexOfFinally = -1;
			FindFunctionParams func = null;
			if (!controlBlock.isFake) {
				mBufferIndexOfFinally = controlBlock.nameIndex();
			}
			else {
				mBufferIndexOfFinally = ByteCode_Types.getFakeTryCatchFinallyIndex((FindSpecialBlockParams)controlBlock, 0);
			}
			func = (FindFunctionParams) Compiler.getParent(controlBlock);
			
			// loads parameters of getBooleanValueFromBitMaskArrFunc()
			
			// prints serialNumberInBitMaskArr
			int sn = getSerialNumberInBitMaskArr(func, mBufferIndexOfFinally);
			if (!controlBlock.isFake) {
				generator.printSmallIntegerNumber(sn, result, mBufferIndexOfFinally);
			}
			else {
				generator.printSmallIntegerNumber(sn, result, func.endIndex());
			}
			
			FindVarParams var = func.getVar("bitMaskArrForFinally");
			int localTableIndex = var.indexOfLocalVariableTable;
			
			FindVarParams varBeforeProcessLocalVars = var;
			if (var.sharedVar!=null) {
				var = var.sharedVar;
			}
					
			// 중복변수일 경우 중복처리하기 전 변수의 indexOfLocalVarsInFunctionBeforeProcessLocalVars을,
			// 중복변수가 아니면 그 변수의 indexOfLocalVarsInFunctionBeforeProcessLocalVars을 구한다.
			String strindexOfLocalVarsInFunctionBeforeProcessLocalVars = 
						", "+varBeforeProcessLocalVars.indexOfLocalVarsInFunctionBeforeProcessLocalVars;
			
			strindexOfLocalVarsInFunctionBeforeProcessLocalVars = 
					strindexOfLocalVarsInFunctionBeforeProcessLocalVars+", "+varBeforeProcessLocalVars.getVarStr(coreThreadID);
			
			String strmBufferIndex = null;
			int srcIndex = -1;
			if (!controlBlock.isFake) {
				srcIndex = controlBlock.nameIndex();
			}
			else {
				srcIndex = func.endIndex();
			}
			strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, srcIndex);
			
			// prints bitMaskArr
			result.add("iload_"+localTableIndex + " // local "+var.getVarStr(coreThreadID)+strindexOfLocalVarsInFunctionBeforeProcessLocalVars+strmBufferIndex+"\n");
			
			FindFunctionParams getBooleanValueFromBitMaskArrFunc = Synchronized.getBooleanValueFromBitMaskArrFunc(generator, srcIndex, coreThreadID);
			
			// calls getBooleanValueFromBitMaskArrFunc()
			generator.physical.makeCONSTANT_Method_infoAndPutItIntolistOfConstantTable(getBooleanValueFromBitMaskArrFunc, coreThreadID);
			result.add("invokestatic // "+getBooleanValueFromBitMaskArrFunc.getMethodInfoStr(coreThreadID)+
					strmBufferIndex+"\n");
		}
		
		/** 전체 try_catch_finally를 한번에 출력한다.
		 * @param coreThreadID */
		public static void printTry_catch_finally(ByteCodeGeneratorForClass generator, FindControlBlockParams tryBlock, HighArrayCharForByteCode result, int coreThreadID) {
			Compiler compiler = generator.compiler;
			
			Block parentBlock = tryBlock.parent;
			int i;
			int indexEnd = parentBlock.listOfControlBlocks.count-1;
			for (i=tryBlock.indexInListOfControlBlocksOfParent+1; i<parentBlock.listOfControlBlocks.count; i++) {
				FindControlBlockParams controlBlock = (FindControlBlockParams) parentBlock.listOfControlBlocks.getItem(i);
				
				// 다음 controlBlock이 없는 try, catch문이거나 
				if ( controlBlock.catOfControls!=null) {
					indexEnd = i-1;
					break;
				}
				CodeString keyword = CompilerHelper.getNameOfControlBlock(compiler, controlBlock);
				
				// 다음 controlBlock이 catch나 finally가 아니면
				if (!(keyword.equals("catch") || keyword.equals("finally"))) {
					indexEnd = i-1;
					break;
				}
				else {
					FindSpecialBlockParams catchOrFinally = (FindSpecialBlockParams) controlBlock;
					catchOrFinally.tryBlockConnected = (FindSpecialBlockParams) tryBlock;				
				}
			}		
			
			for (i=tryBlock.indexInListOfControlBlocksOfParent; i<=indexEnd; i++) {
				FindControlBlockParams controlBlock = (FindControlBlockParams) parentBlock.listOfControlBlocks.getItem(i);
				
				CodeString keyword = CompilerHelper.getNameOfControlBlock(compiler, controlBlock);
				
				if (keyword.equals("try")) {
					//String strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)9, null);
					//result.add("// "+strIndex+"BlockStart\n");
					printTry(generator, controlBlock, result, coreThreadID);
				}
				else if (keyword.equals("catch")) {
					printCatch(generator, controlBlock, result, coreThreadID);
				}
				else if (keyword.equals("finally")) {
					printFinally(generator, controlBlock, result, coreThreadID);
				}
			}
		}
		
		
		
		
		public static void printReturn(ByteCodeGeneratorForClass generator, FindSpecialStatementParams statement, HighArrayCharForByteCode result, int coreThreadID) {
			
			// return; 에서와 같이 값을 리턴하지 않는 경우 statement.funcCall은 null이므로
			// 이 경우에는 return만 출력한다.
			// 리턴할 값을 스택에 넣는다.
			// return문에 수식이 있을 경우 수식을 출력한다.
						
			checkSynchronizedAndFinally(generator, statement, null, result, coreThreadID);
			
			
			FindFunctionParams func = (FindFunctionParams) CompilerStatic.getParent(statement.parent);
			//Synchronized.printMonitorExitInEndOfFunc(generator, func, result);
			
			// return; 에서와 같이 값을 리턴하지 않는 경우 statement.funcCall은 null이므로
			// 이 경우에는 return만 출력한다.
			// 리턴할 값을 스택에 넣는다.
			// return문에 수식이 있을 경우 수식을 출력한다.
			if (statement.funcCall!=null && statement.funcCall.typeFullName!=null) {
				generator.traverseChild(statement.funcCall, result, coreThreadID);
				String typeNameOfFuncCall = statement.funcCall.typeFullName.str;
				
				TypeCast.printTypeCast(generator,  typeNameOfFuncCall, func.returnType, 
						result, statement.funcCall.startIndex(), coreThreadID);
			}
			
			String strmBufferIndex = ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(generator.compiler, statement.kewordIndex());
			
			// statement.funcCall.typeFullName이 null이거나 ""이거나 "void"이면 return으로 한다.			
			if (statement.funcCall!=null && statement.funcCall.typeFullName!=null) {
				String typeName = func.returnType;
				if (typeName.equals("boolean") ||
					typeName.equals("byte") || typeName.equals("char") || typeName.equals("short") ||
					typeName.equals("int")) {
					result.add("ireturn // "+strmBufferIndex+"\n");
				}
				else if (typeName.equals("long")) {
					result.add("lreturn // "+strmBufferIndex+"\n");
				}
				else if (typeName.equals("float")) {
					result.add("freturn // "+strmBufferIndex+"\n");
				}
				else if (typeName.equals("double")) {
					result.add("dreturn // "+strmBufferIndex+"\n");
				}
				else if (typeName.equals("void") || typeName.equals("")) { // void형
					result.add("return // "+strmBufferIndex+"\n");
				}
				else {
					result.add("areturn // "+strmBufferIndex+"\n");
				}
			}
			else { // void 형
				result.add("return // "+strmBufferIndex+"\n");
			}
			
			// return을 출력할 때 stack map entry를 끝낸다.
			result.add("// exit of return\n");
		}
		
		
		
		public static void printThrow(ByteCodeGeneratorForClass generator, FindSpecialStatementParams statement, HighArrayCharForByteCode result, int coreThreadID) {
						
			
			String strIndex = null;
			if (!statement.isFake) {
				strIndex = "("+statement.kewordIndex()+"), ";
			}
			else {
				FindSpecialBlockParams finallyBlock = (FindSpecialBlockParams) statement.parent;
				
				int mBufferIndexOfFinally = -1;
				FindFunctionParams func = null;
				if (!finallyBlock.isFake) {
					mBufferIndexOfFinally = finallyBlock.nameIndex();
				}
				else {
					mBufferIndexOfFinally = ByteCode_Types.getFakeTryCatchFinallyIndex(finallyBlock, 0);
				}
				func = (FindFunctionParams) Compiler.getParent(finallyBlock);
			
				int sn = getSerialNumberInBitMaskArr(func, mBufferIndexOfFinally);
				strIndex = "("+(3000000+200+sn)+"), ";
			}
			result.add("// "+strIndex+"throw starts"+"\n");
			
			ThrowStartEnd throwStartEnd = new ThrowStartEnd(statement.kewordIndex());
			
			ThrowStartEnd parentThrow = (ThrowStartEnd) generator.compiler.data.throwStack.Get();
			if (parentThrow!=null) {
				parentThrow.listOfChild.add(throwStartEnd);
				throwStartEnd.parentThrow = parentThrow; 
			}
			else {
				generator.compiler.data.listOfThrowStartEnd.add(throwStartEnd);
			}
			generator.compiler.data.throwStack.Push(throwStartEnd);
			
			String typeNameOfException = null;
			if (statement.funcCall==null && statement.isFake) { // finally블록의 가짜 throw문
				typeNameOfException = "java.lang.Throwable";
			}
			else {
				if (statement.funcCall.typeFullName==null) return;
				typeNameOfException = statement.funcCall.typeFullName.str;
			}
			
			throwStartEnd.setExceptionTypeName(typeNameOfException);
			
			// 던질 예외를 스택에 넣는다.
			if (statement.funcCall!=null) {
				generator.traverseChild(statement.funcCall, result, coreThreadID);
			}
			
			String strmBufferIndex = ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(generator.compiler, statement.kewordIndex());
			
			//checkSynchronizedAndFinally(generator, statement, typeNameOfException, result);
			
			if (statement.kewordIndex()!=-1) {
				// athrow throws an error or exception 
				// (notice that the rest of the stack is cleared, leaving only a reference to the Throwable)			
				result.add("athrow // "+strmBufferIndex+"\n");
				/*if (catchBlock!=null) {
					printCatch(catchBlock, result);
				}*/
			}
			else {
				// 가짜 throw문일 경우
				FindFunctionParams func = (FindFunctionParams) Compiler.getParent(statement.parent);
				FindVarParams exception = func.getVar(ByteCode_Types.throwableVarNameForFinallyBlock);
				FindVarUseParams varUseException = new FindVarUseParams(statement.parent.endIndex);
				varUseException.varDecl = exception;
				varUseException.funcToDefineThisVarUse = func;
				LocalVar.printLocalVar(generator, varUseException, result, true, coreThreadID);
				strmBufferIndex = ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(generator.compiler, statement.parent.endIndex());
				result.add("athrow // "+strmBufferIndex+"\n");
				
			}
			
			result.add("// "+strIndex+"throw ends"+"\n");
			
			generator.compiler.data.throwStack.Pop();
		}
	   
		/** block을 처음으로 감싸는 try 블록을 얻는다. 
		 * 예를들어 throw e;에서 getParentTryBlock를 호출하면 
		 * 이 블럭을 처음으로 감싸는 try블록를 얻는다.*/
		public static Block getParentTryBlock(ByteCodeGeneratorForClass generator, Block block) {
			Compiler compiler = generator.compiler;
			while (true) {
				if (block instanceof FindControlBlockParams) {
					FindControlBlockParams control = (FindControlBlockParams) block;
					if (control.catOfControls==null) {
						CodeString name = CompilerHelper.getNameOfControlBlock(compiler, control);
						if (name.equals("try"))
							return control;
					}
				}
				if (block!=null) {
					block = block.parent;
				}
				else {
					return null;
				}
			}
		}
		
		
		
		
		/**throw가 던지는 예외가 catch되기 전에( throw가 던지는 예외타입이 catch블록 리스트에 있을 때)
		   synchronized의 개수를 세어 오브젝트 잠금을 몇 번 해제를 해야 하는지를 얻는다.
			found는 catch블록을 만나서 던진 예외가 catch되면 true가 된다.<br>
			
			 catch-synchronized-synchronized-throw e 스택 상에서 
			 catch를 만나기 전에 synchronized가 두번 있으므로 결과는 2가 된다.<br>
			
			 synchronized-synchronized-catch-throw e 스택 상에서 
			 synchronized를 만나기 전에 catch가 되므로 결과는 0가 된다. 
			 이 때는 모니터를 해제할 필요가 없다.
			 
			 또한 catch 되기 전에 finally절이 있는지를 확인하여 스택상에서의 위치를 저장한다.
			 
			 synchronized-catch-finally-throw e 스택 상에서 
			 synchronized를 만나기 전에 catch가 되므로 결과는 synchronized의 개수는 0이 되고
			 finally의 개수는 1이 된다.
			 
			 synchronized-catch-synchronized-finally-finally-throw e 스택 상에서 
			 synchronized의 개수는 1이 되고 finally의 개수는 2가 된다.
			 
			 리턴문일 경우 catch를 신경 쓸 필요가 없이 function을 만날 때까지 
			 synchronized와 finally의 개수를 확인한다.
			 
			 synchronized-catch-finally-return 스택 상에서 
			 결과는 synchronized의 개수는 1이 되고 finally의 개수는 1이 된다.
			 
			 synchronized-catch-synchronized-finally-finally-return 스택 상에서 
			 synchronized의 개수는 2이 되고 finally의 개수는 2가 된다.
			 
			 continue, break문일 경우 return문과 유사한 방식으로 catch를 신경 쓸 필요가 없이
			   반복루프까지의 synchronized, finally를 센다.
		 * @param typeNameOfExceptionOfThrow 
			 */
		public static ReturnOfGetCountOfSynchronizedAndFinallyJustBeforeCatch 
		getCountOfSynchronizedAndFinallyJustBeforeCatch(ByteCodeGeneratorForClass generator, FindSpecialStatementParams statement, String typeNameOfExceptionOfThrow) {
		Compiler compiler = generator.compiler;
		
		if (statement.kewordIndex()==667) {
		}
		
		// throw문일 경우 true, return문일 경우 false
		boolean throwOrReturn = false;
		String nameOfStatement = null;
		if (statement.kewordIndex()!=-1) {
			nameOfStatement = compiler.data.mBuffer.getItem(statement.kewordIndex()).str;
		}
		else if (statement.isFake) {
			nameOfStatement = "throw";
		}
		if (nameOfStatement.equals("throw")) {
			throwOrReturn = true;
		}
		
		// throw가 던지는 예외가 catch되기 전에 
		// synchronized의 개수를 세어 오브젝트 잠금을 몇 번 해제를 해야 하는지를 얻는다.
		// found는 catch블록을 만나서 던진 예외가 catch되면 true가 된다.
		
		// catch-synchronized-synchronized-throw e 스택 상에서 
		// catch를 만나기 전에 synchronized가 두번 있으므로 결과는 2가 된다.
		
		// synchronized-synchronized-catch-throw e 스택 상에서 
		// synchronized를 만나기 전에 catch가 되므로 결과는 0가 된다. 
		// 이 때는 모니터를 해제할 필요가 없다.
		Block block = statement.parent;
		// synchronized의 개수
		int count = 0;
		// synchronized의 스택에서의 위치를 알 수 있는 loopCount들의 리스트
		ArrayListInt listOfLoopCountsOfSynchronized = new ArrayListInt(3);
		
		// 스택에서의 nested 관계를 알 수 있다.
		int loopCount = 0;		
		ArrayList listOfFinallyBlocks = new ArrayList(3);
		// finally의 스택에서의 위치를 알 수 있는 loopCount들의 리스트
		ArrayListInt listOfLoopCountsOfFinally = new ArrayListInt(3);
		
		ArrayList listOfSynchronizedBlocks = new ArrayList(3);
		
		// throw가 catch되는 블록
		FindControlBlockParams catchBlockCatchingThrow = null;
		
		String keyword = null;
		if (statement.kewordIndex()!=-1) {
			keyword = compiler.data.mBuffer.getItem(statement.kewordIndex()).str;
		}
		
		while (true) {
			FindControlBlockParams tryBlock = null;
			FindControlBlockParams[] listOfCatchBlocks = null;
			
			if (block==null) break;
			else if (block instanceof FindControlBlockParams) {
				FindControlBlockParams control = (FindControlBlockParams) block;
				if (control.catOfControls==null) {
					CodeString name = CompilerHelper.getNameOfControlBlock(compiler, control);
					if (name.equals("try")) {
						tryBlock = control;
					}
					else if (name.equals("synchronized")) {
						// throw가 던지는 예외가 catch되기 전에 
						// synchronized의 개수를 세어 오브젝트 잠금을 몇 번 해제를 해야 하는지를 얻는다.
						count++;
						listOfLoopCountsOfSynchronized.add(loopCount);
						listOfSynchronizedBlocks.add(control);
					}
					else if (name.equals("catch")) {
						tryBlock = 
								getTryBlockOfCatchOrFinally(generator, control.parent, control.indexInListOfControlBlocksOfParent);
					}
					else {						
						block = block.parent;
						continue;
					}
				}
				else { // for, if 등
					if (control.catOfControls.category==CategoryOfControls.Control_for || 
							control.catOfControls.category==CategoryOfControls.Control_while ||
							control.catOfControls.category==CategoryOfControls.Control_dowhile) {
						if (keyword!=null && (keyword.equals("continue") || keyword.equals("break"))) {
						    // continue, break문일 경우 반복루프까지의 synchronized, finally를 센다.
							break;
						}
					}
					block = block.parent;
					continue;
				}
			}//else if (block instanceof FindControlBlockParams) {
			else if (block instanceof FindFunctionParams) {
				FindFunctionParams func = (FindFunctionParams) block;
				if (func.accessModifier!=null && func.accessModifier.isSynchronized) {
					// throw가 던지는 예외가 catch되기 전에 
					// synchronized의 개수를 세어 오브젝트 잠금을 몇 번 해제를 해야 하는지를 얻는다.
					count++;
					listOfLoopCountsOfSynchronized.add(loopCount);
				}
				// func를 만나면 루프를 종료한다.
				break;
			}
			else {
				block = block.parent;
				continue;
			}
			
			if (tryBlock!=null && block==tryBlock) {				
				if (throwOrReturn) {
					// throw문일때만 루프종료
					listOfCatchBlocks = 
							getCatchBlocksOfTry(generator, tryBlock.parent, tryBlock.indexInListOfControlBlocksOfParent);
					int i;
					// catchedThrow는 throw가 던지는 예외타입이 
					// catch블록 리스트에 있을 때 true가 된다.
					// throw문일때만 루프종료
					if (listOfCatchBlocks!=null) {
						for (i=0; i<listOfCatchBlocks.length; i++) {
							FindControlBlockParams cb = listOfCatchBlocks[i];
							FindVarParams var = (FindVarParams) cb.listOfStatementsInParenthesis.getItem(0);
							if (var.typeName.equals(typeNameOfExceptionOfThrow)) {
								//catchedThrow = true;
								catchBlockCatchingThrow = cb;
								break;
							}
						}
						// throw문일때만 루프종료
						if (catchBlockCatchingThrow!=null) {				
							break; // while루프를 빠져나간다.
						}//if (catchedThrow) {
					}//if (listOfCatchBlocks!=null) {
				}//if (throwOrReturn) {
			}//if (tryBlock!=null) {
			if (tryBlock!=null) {
				FindControlBlockParams finallyBlockLocal = 
						getFinallyBlockOfTry(generator, tryBlock.parent, tryBlock.indexInListOfControlBlocksOfParent);
				if (finallyBlockLocal!=null) {
					// finally가 발견되었으므로 스택위치를 저장한다.
					listOfFinallyBlocks.add(finallyBlockLocal);
					listOfLoopCountsOfFinally.add(loopCount);
				}
			}
			
			
			if (block!=null) {
				block = block.parent;
			}
			
			// 스택에서의 nested 루프 카운트를 증가시킨다.
			loopCount++;
		}//while (true) {
		
		int loopCountOfCatch = -1;
		if (catchBlockCatchingThrow!=null) {
			// throw문일때만
			loopCountOfCatch = loopCount;
		}
		
		
		ReturnOfGetCountOfSynchronizedAndFinallyJustBeforeCatch r = new ReturnOfGetCountOfSynchronizedAndFinallyJustBeforeCatch();
		r.countOfSynchronized = count;
		r.listOfLoopCountsOfSynchronized = listOfLoopCountsOfSynchronized;
		r.listOfFinallyBlocks = listOfFinallyBlocks;
		r.listOfLoopCountsOfFinally = listOfLoopCountsOfFinally;
		r.loopCountOfCatch = loopCountOfCatch;
		r.catchBlock = catchBlockCatchingThrow;
		r.listOfSynchronizedBlocks = listOfSynchronizedBlocks; 
		return r;
	}
		
		
		/** return문을 포함하는 synchronized가 중첩되거나 그렇지 않을 경우 synchronized의 개수를 세어 리턴한다.
		 * return문이 synchronized에 포함되지 않으면 0을 리턴한다.*/  
		public static int getCountOfSynchronized(ByteCodeGeneratorForClass generator, FindSpecialStatementParams statement) {
			Compiler compiler = generator.compiler;
			
			if (statement.kewordIndex()==1656) {
			}
			int count=0;
			FindStatementParams parent = statement.parent;
			while (true) {			
				if (parent==null) return count;
				if (parent instanceof FindFunctionParams) {
					FindFunctionParams func = (FindFunctionParams) parent;
					if (func.accessModifier!=null && func.accessModifier.isSynchronized) 
						count++;
					else return count;
				}
				if (parent instanceof FindClassParams) {
					return count;
				}
				if (parent instanceof FindControlBlockParams) {
					FindControlBlockParams controlBlock = (FindControlBlockParams) parent;
					// controlBlock.nameIndex()==-1일 경우 가짜 try-catch블록
					if (controlBlock.nameIndex()!=-1 &&
							compiler.data.mBuffer.getItem(controlBlock.nameIndex()).equals("synchronized"))
						count++;
				}
				parent = parent.parent;
			}
		}
		
		
		/** controlBlock의 listOfStatements에서 가장 바깥 문장들중(if, for등에 포함된 throw문은 아님)에 
		 * throw문, return문이 포함되어 있으면 true를 리턴하고, 그렇지 않으면 false를 리턴한다.
		 * try, if, for등에서 throw, return문이 있을 경우 goto 출력을 생략하기 위해 호출한다.<br>
		 * synchronized { return;} 혹은 finally { return;}와 같이
		 *  반드시 실행되는 블록 내부에 throw, return문등이 있는 경우에도 true가 된다.<br>
		 * throw문의 경우  throw문이 있더라도 parent블록 내부에서 던지는 예외가 catch가 되면 false를 리턴하고 
		 * 그렇지 않으면 true를 리턴한다.
		 * @param controlBlock :
		 * @param parentBlock : controlBlock은 parentBlock내부에서 재귀적 호출되는 블록이고, 
		 * parentBlock은 throw, return 문등이 있는지를 확인하는 최상위블록이다. 
		 * @return
		 */
		/*public static boolean containsThrowOrReturnOrBreakOrContinue_IfElseIf_Else(ByteCodeGeneratorForClass generator, FindControlBlockParams controlBlock, Block parentBlock) {
			String blockName = controlBlock.getName();
			if (blockName.equals("if")) {
				int indexInListOfControlBlocksOfParent = block.indexInListOfControlBlocksOfParent;
				for (int k=indexInListOfControlBlocksOfParent; k<block.listOfControlBlocks.count; k++) {
					FindControlBlockParams ifElseIfElse = (FindControlBlockParams) block.listOfControlBlocks.getItem(k);
					if (ifElseIfElse.getName().equals("else") && ControlBlock.if_elseEnds(ifElseIfElse)) {
						return true;
					}
				}
			}
		}*/
		
		
		/** controlBlock의 listOfStatements에서 가장 바깥 문장들중(if, for등에 포함된 throw문은 아님)에 
		 * throw문, return문이 포함되어 있으면 true를 리턴하고, 그렇지 않으면 false를 리턴한다.
		 * try, if, for등에서 throw, return문이 있을 경우 goto 출력을 생략하기 위해 호출한다.<br>
		 * synchronized { return;} 혹은 finally { return;}와 같이
		 *  반드시 실행되는 블록 내부에 throw, return문등이 있는 경우에도 true가 된다.<br>
		 * throw문의 경우  throw문이 있더라도 parent블록 내부에서 던지는 예외가 catch가 되면 false를 리턴하고 
		 * 그렇지 않으면 true를 리턴한다.
		 * @param controlBlock :
		 * @param parentBlock : controlBlock은 parentBlock내부에서 재귀적 호출되는 블록이고, 
		 * parentBlock은 throw, return 문등이 있는지를 확인하는 최상위블록이다. 
		 * @return
		 */
		public static boolean containsThrowOrReturnOrBreakOrContinue(ByteCodeGeneratorForClass generator, FindControlBlockParams controlBlock, Block parentBlock) {
			Compiler compiler = generator.compiler;
			int i;
			for (i=0; i<controlBlock.listOfStatements.count; i++) {
				FindStatementParams statement = (FindStatementParams) controlBlock.listOfStatements.getItem(i);
				if (statement instanceof FindControlBlockParams) {
					FindControlBlockParams block = (FindControlBlockParams) statement;
					if (block.catOfControls!=null) continue;
					String blockName = block.getName();					
					if (blockName.equals("try") || blockName.equals("catch")) continue;
					if (containsThrowOrReturnOrBreakOrContinue(generator, block, parentBlock)) {
						return true;
					}
					//else return false;
					else continue;
				}
				else if (statement instanceof FindSpecialStatementParams) {
					FindSpecialStatementParams special = (FindSpecialStatementParams) statement;
					String keyword = compiler.data.mBuffer.getItem(special.kewordIndex()).str; 
					if (keyword.equals("throw")) {
						String typeNameOfException = null;
						if (special.funcCall==null && statement.isFake) { // finally블록의 가짜 throw문
							typeNameOfException = "java.lang.Throwable";
						}
						else {
							if (special.funcCall.typeFullName==null) {
								return false;
							}
							typeNameOfException = special.funcCall.typeFullName.str;
						}
						ReturnOfGetCountOfSynchronizedAndFinallyJustBeforeCatch r = 
								getCountOfSynchronizedAndFinallyJustBeforeCatch(generator, special, typeNameOfException);
						if (r.catchBlock!=null) {
							if (parentBlock.startIndex()<=r.catchBlock.startIndex() && 
									r.catchBlock.endIndex()<=parentBlock.endIndex()) {
								// throw문이 있더라도 parent블록 내부에서 catch가 되므로 false를 리턴한다.
								return false;
							}
						}
						// parent블록 내부에서 catch가 되지 않으면 true를 리턴한다.
						return true;
					}
					else if (keyword.equals("return")	 || 
							keyword.equals("continue")  || keyword.equals("break")) {
						return true;
					}
				}
			}
			return false;
		}
		
		/** throw문이나 return문이면 true를 리턴하고, 그렇지 않으면 false를 리턴한다.
		 * throw문, return문 다음에 문장이 있을 경우 에러를 출력한다.
		 * synchronized { return;} 혹은 finally { return;}와 같은 경우에도 true가 된다. 
		 */
		public static boolean isThrowOrReturnOrBreakOrContinue(ByteCodeGeneratorForClass generator, FindStatementParams statement) {
			Compiler compiler = generator.compiler;
			
			if (statement instanceof FindSpecialStatementParams) {
				FindSpecialStatementParams special = (FindSpecialStatementParams) statement;
				String keyword = compiler.data.mBuffer.getItem(special.kewordIndex()).str; 
				if (keyword.equals("throw") || keyword.equals("return")	|| 
						keyword.equals("break") || keyword.equals("continue")) {
					return true;
				}
			}
			else if (statement instanceof FindControlBlockParams) {
				FindControlBlockParams block = (FindControlBlockParams) statement;
				if (block.catOfControls!=null) return false;
				String blockName = CompilerHelper.getNameOfControlBlock(compiler, block).str;
				// try { 
				//    return;
				// }catch() {
				// } 와 같은 경우에는 제외한다.
				if (blockName.equals("try")) return false;
				// catch() {
				//    return;
				// } 와 같은 경우에는 제외한다.
				if (blockName.equals("catch")) return false;
				int i;
				// finally, sychronized
				for (i=0; i<block.listOfStatements.count; i++) {
					FindStatementParams s = (FindStatementParams) block.listOfStatements.getItem(i);
					if (isThrowOrReturnOrBreakOrContinue(generator, s)) return true;
				}
			}
			return false;
		}
		
		
		/** try-catch-finally에서 마지막 블록을 리턴한다.   
		 * @param parentBlock : try블록의 parent블록
		 * @param indexInlistOfControlBlocksOfParent : parent블록 내의 listOfControlBlocks내에서 
		 * 		try 블록의 인덱스
		 */
		public static FindControlBlockParams getLastBlockOfTry_Catch_Finally(ByteCodeGeneratorForClass generator, Block parentBlock, int indexInlistOfControlBlocksOfParent) {
			Compiler compiler = generator.compiler;
			int i;
			//boolean catchExists=false, finallyExists=false;
			int len = parentBlock.listOfControlBlocks.count;
			// try-catch-finally의 끝을 찾는다.
			FindControlBlockParams lastBlock = 
					(FindControlBlockParams) parentBlock.listOfControlBlocks.getItem(indexInlistOfControlBlocksOfParent);
			for (i=indexInlistOfControlBlocksOfParent+1; i<len; i++) {
				FindControlBlockParams control = (FindControlBlockParams) parentBlock.listOfControlBlocks.getItem(i);
				CodeString name = CompilerHelper.getNameOfControlBlock(compiler, control);
				
				if (name.equals("catch")) {
					//catchExists = true;
					lastBlock = control;
				}
				else if (name.equals("finally")) {
					//finallyExists = true;
					//break;
					lastBlock = control;
				}
				else { // catch, finally를 제외한 try, if 등 controlBlock이 나오면 
					lastBlock = (FindControlBlockParams) parentBlock.listOfControlBlocks.getItem(i-1);
					break;
				}
			}//for (i=indexInParent+1; i<len; i++) {
			/*if (catchExists==false && finallyExists==false) return null;
			else if (catchExists==true && finallyExists==false) return 1;
			else if (catchExists==false && finallyExists==true) return 2;
			else return 3;*/
			return lastBlock;
		}
		
		
		
		/** catch나 finall블록의 try블록을 리턴한다.
		 *  @param parentBlock : catch, finally 블록의 parent블록*/
		public static FindControlBlockParams getTryBlockOfCatchOrFinally(ByteCodeGeneratorForClass generator, Block parentBlock, int indexInlistOfControlBlocksOfParent) {
			return getTryBlockOfCatchOrFinally(generator.compiler, parentBlock, indexInlistOfControlBlocksOfParent);
		}
		
		/** catch나 finall블록의 try블록을 리턴한다.
		 *  @param parentBlock : catch, finally 블록의 parent블록*/
		public static FindControlBlockParams getTryBlockOfCatchOrFinally(Compiler compiler, Block parentBlock, int indexInlistOfControlBlocksOfParent) {
			int i;
			for (i=indexInlistOfControlBlocksOfParent-1; i>=0; i--) {
				FindControlBlockParams control = (FindControlBlockParams) parentBlock.listOfControlBlocks.getItem(i);
				CodeString name = CompilerHelper.getNameOfControlBlock(compiler, control);
				
				if (name.equals("try")) {
					return control;
				}
			}//for (i=indexInParent+1; i<len; i++) {
		
			return null;
		}
		
		
		public static boolean isLastStatementReturn(Compiler compiler, FindFunctionParams func) {
			if (func.listOfStatements.count==0) return false;
			/*FindStatementParams firstStatement = 
					(FindStatementParams) func.listOfStatements.getItem(0);
			if (firstStatement instanceof FindSpecialBlockParams) {
				FindSpecialBlockParams special = (FindSpecialBlockParams) firstStatement;
				if (special.isFake) {
					if (special.anotherName.equals(ByteCode_Types.TryFinallyShieldForFuncWithSync)) {
						
					}
				}
			}*/
			FindStatementParams lastStatement = 
					(FindStatementParams) func.listOfStatements.getItem(func.listOfStatements.count-1); 
			if (!(lastStatement instanceof FindSpecialStatementParams)) return false;
			else {
				FindSpecialStatementParams specialStatement = (FindSpecialStatementParams) lastStatement;
				if (!compiler.data.mBuffer.getItem(specialStatement.kewordIndex()).equals("return")) {
					return false;
				}
				return true;
			}
		}
		
		
		/**parent인 try블록에 연결된 catch블록들을 얻는다. 
		 * @param parentBlock : try block의 parent블록
		 * @param indexInlistOfControlBlocksOfParent : parent블록 내의 listOfControlBlocks내에서 
		 * 		try 블록의 인덱스*/
		public static FindControlBlockParams[] getCatchBlocksOfTry(ByteCodeGeneratorForClass generator, Block parentBlock, int indexInlistOfControlBlocksOfParent) {
			Compiler compiler = generator.compiler;
			int i;
			ArrayList r = new ArrayList(5);
			int len = parentBlock.listOfControlBlocks.count;
			// try-catch-finally의 끝을 찾는다.
			for (i=indexInlistOfControlBlocksOfParent+1; i<len; i++) {
				FindControlBlockParams control = (FindControlBlockParams) parentBlock.listOfControlBlocks.getItem(i);
				CodeString name = CompilerHelper.getNameOfControlBlock(compiler, control);
				if (name.equals("catch")) {
					r.add(control);
				}
				else if (name.equals("finally")) {
					break;
				}
				else { // catch, finally를 제외한 controlBlock이 나오면 
					break;
				}
			}//for (i=indexInParent+1; i<len; i++) {
			FindControlBlockParams[] result = new FindControlBlockParams[r.count];
			for (i=0; i<r.count; i++) {
				result[i] = (FindControlBlockParams) r.getItem(i);
			}
			return result;
		}
	   
}
