package com.gsoft.common.compiler.bytecode;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import com.gsoft.common.Common_Settings;
import com.gsoft.common.IO;
import com.gsoft.common.interfaces.IReset;
import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.CompilerStatic;
import com.gsoft.common.compiler.Compiler_types.FindFunctionParams;
import com.gsoft.common.compiler.Compiler_types.FindVarParams;
import com.gsoft.common.compiler.Compiler_types_Base.AccessModifier;
import com.gsoft.common.compiler.bytecode.ByteCode_Types.ClassFieldMethod;
import com.gsoft.common.compiler.bytecode.ByteCode_Types.Exceptions_attribute;
import com.gsoft.common.compiler.bytecode.ByteCode_Types.HashItemOfConstantTable;
import com.gsoft.common.compiler.bytecode.ByteCode_Types.InnerClasses_attribute;
import com.gsoft.common.compiler.bytecode.ByteCode_Types.LineNumberTable_attribute;
import com.gsoft.common.compiler.bytecode.ByteCode_Types.LocalVariableTable_Entry;
import com.gsoft.common.compiler.bytecode.ByteCode_Types.LocalVariableTable_attribute;
import com.gsoft.common.compiler.bytecode.ByteCode_Types.SourceFile_attribute;
import com.gsoft.common.compiler.classloader.ClassLoader;
import com.gsoft.common.compiler.classloader.PathClassLoader;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListIReset;
import com.gsoft.common.util.ArrayListString;

import com.gsoft.common.compiler.bytecode.StackMapTable_attribute;
import com.gsoft.common.compiler.bytecode.Code_attribute;
import com.gsoft.common.compiler.bytecode.ByteCodeGeneratorForClass;
import com.gsoft.common.compiler.bytecode.ByteCode_Types;
import com.gsoft.common.compiler.bytecode.TypeDescriptor;

@SuppressWarnings("unused")
public class ByteCode_Types_Info {
	public static class Attribute_Info implements IReset {
		public int readBytesLen;
		
		/** attribute_name_index와 attribute_length는 모든 속성의 공통적인 속성이다.*/
		int attribute_name_index;	
		/** attribute_name_index와 attribute_length는 모든 속성의 공통적인 속성이다.*/
		int attribute_length;
		String attribute_name;
		byte[] info; // attribute_length
		
		/** SourceFile Attribute 일 경우 0이 아니다.*/
		int sourcefile_index;
		/** SourceFile Attribute 일 경우 null 이 아니다.*/
		String sourcefile_name;
	
		
		/** Code Attribute 일 경우 null 이 아니다.*/
		public Code_attribute codeAttribute;
		/** LineNumberTable Attribute 일 경우 null 이 아니다.*/
		LineNumberTable_attribute lineNumberTableAttribute;
		/** LocalVariableTable Attribute 일 경우 null 이 아니다.*/
		LocalVariableTable_attribute localVarTableAttribute;
		/** StackMapTable Attribute 일 경우 null 이 아니다.*/
		StackMapTable_attribute stackMapTableAttribute;
		
		/** Method_info의 attribute, 
		 * Attribute 가 Exceptions Attribute 일 경우 null 이 아니다.*/
		Exceptions_attribute exceptionsAttribute;
		 /** Attribute 가 InnerClasses Attribute 일 경우 null 이 아니다.*/
		public InnerClasses_attribute innerClassesAttribute;
		SourceFile_attribute sourceFileAttribute;
		
		/**attribute_name_index, attribute_length 6바이트을 포함한 
		 * LocalVariableTable_attribute, StackMapTable_attribute 등을 쓴다.
		 * @param coreThreadID */
		static void write(OutputStream output, ByteCodeGeneratorForClass generator, Object attribute, boolean isLittleEndian, int coreThreadID) {
			
			if (attribute instanceof LocalVariableTable_attribute) {
				LocalVariableTable_attribute localVariableTable_attribute = (LocalVariableTable_attribute) attribute;
				
				// attribute_name_index 쓰기, u2
				HashItemOfConstantTable hashItem = 
						(HashItemOfConstantTable) generator.physical.listOfConstantTableUtf8Hashed.getData("LocalVariableTable");
				IO.writeShort(output, (short)hashItem.index, isLittleEndian);
				
				
				// attribute_length 쓰기, u4
				// attribute_name_index, attribute_length 6바이트를 제외한 
				// LocalVariableTable attribute의 길이 = LocalVariableTable length(u2) + local_variable_table_length * 10
				int attribute_length = localVariableTable_attribute.getAttributeLength();
				IO.writeInt(output, attribute_length, isLittleEndian);
				
				localVariableTable_attribute.write(output, coreThreadID);
			}
			else if (attribute instanceof StackMapTable_attribute) {
				StackMapTable_attribute stackMapTable_attribute = (StackMapTable_attribute) attribute;
				
				// attribute_name_index 쓰기
				HashItemOfConstantTable hashItem = 
						(HashItemOfConstantTable) generator.physical.listOfConstantTableUtf8Hashed.getData("StackMapTable");
				IO.writeShort(output, (short)hashItem.index, isLittleEndian);
				
				// attribute_length 쓰기
				int attribute_length = stackMapTable_attribute.getAttributeLength();
				IO.writeInt(output, attribute_length, isLittleEndian);
				
				stackMapTable_attribute.write(output, isLittleEndian);
			}
			else if (attribute instanceof LineNumberTable_attribute) {
				LineNumberTable_attribute lineNumberTable_attribute = (LineNumberTable_attribute) attribute;
				
				// attribute_name_index 쓰기, u2
				HashItemOfConstantTable hashItem = 
						(HashItemOfConstantTable) generator.physical.listOfConstantTableUtf8Hashed.getData("LineNumberTable");
				IO.writeShort(output, (short)hashItem.index, isLittleEndian);
				
				
				// attribute_length 쓰기, u4
				// attribute_name_index, attribute_length 6바이트를 제외한 
				// LineNumberTable attribute의 길이 = LineNumberTable length(u2) + line_number_table_length * 4
				int attribute_length = lineNumberTable_attribute.getAttributeLength();
				IO.writeInt(output, attribute_length, isLittleEndian);
				
				lineNumberTable_attribute.write(output);
			}
			else if (attribute instanceof InnerClasses_attribute) {
				InnerClasses_attribute innerClasses_attribute = (InnerClasses_attribute) attribute;
				
				// attribute_name_index 쓰기
				HashItemOfConstantTable hashItem = 
						(HashItemOfConstantTable) generator.physical.listOfConstantTableUtf8Hashed.getData("InnerClasses");
				IO.writeShort(output, (short)hashItem.index, isLittleEndian);
				
				// attribute_length 쓰기
				int attribute_length = innerClasses_attribute.getAttributeLength();
				IO.writeInt(output, attribute_length, isLittleEndian);
				
				innerClasses_attribute.write(output);
			}
			else if (attribute instanceof SourceFile_attribute) {
				SourceFile_attribute sourceFile_attribute = (SourceFile_attribute) attribute;
				
				// attribute_name_index 쓰기
				HashItemOfConstantTable hashItem = 
						(HashItemOfConstantTable) generator.physical.listOfConstantTableUtf8Hashed.getData("SourceFile");
				IO.writeShort(output, (short)hashItem.index, isLittleEndian);
				
				// attribute_length 쓰기
				int attribute_length = sourceFile_attribute.getAttributeLength();
				IO.writeInt(output, attribute_length, isLittleEndian);
				
				sourceFile_attribute.write(output);
			}
		}
		
		public static Attribute_Info read(PathClassLoader owner, InputStream is, ArrayList constantTable
				, boolean IsLittleEndian) throws IOException {
			Attribute_Info r = new Attribute_Info();
			r.attribute_name_index = IO.readUnsignedShort(is, IsLittleEndian);
			r.readBytesLen += 2;
			
			r.attribute_name = ((CONSTANT_Utf8_info) constantTable.getItem(r.attribute_name_index)).str;
			
			if (r.attribute_name.equals("SourceFile")) {
				r.attribute_length = IO.readInt(is, IsLittleEndian);
				r.readBytesLen += 4;
				
				if (!owner.readsCode) {
					is.skip(r.attribute_length);
				}
				else {		
					r.sourcefile_index = IO.readUnsignedShort(is, IsLittleEndian);
					r.readBytesLen += 2;
					r.sourcefile_name = ((CONSTANT_Utf8_info) constantTable.getItem(r.sourcefile_index)).str;
				}
			}
			else if (r.attribute_name.equals("Exceptions")) {
				r.attribute_length = IO.readInt(is, IsLittleEndian);
				r.readBytesLen += 4;
				if (!owner.readsCode) {
					is.skip(r.attribute_length);
				}
				else {		
					r.exceptionsAttribute = Exceptions_attribute.read(is, IsLittleEndian);
					r.readBytesLen += r.exceptionsAttribute.readBytesLen;
					
					r.exceptionsAttribute.attribute_name_index = r.attribute_name_index;
					r.exceptionsAttribute.attribute_length = r.attribute_length;
				}
			}
			else if (r.attribute_name.equals("InnerClasses")) {
				r.attribute_length = IO.readInt(is, IsLittleEndian);
				r.readBytesLen += 4;
				if (!owner.readsCode) {
					is.skip(r.attribute_length);
				}
				else {
					r.innerClassesAttribute =
							InnerClasses_attribute.toInnerClasses_attribute(is, constantTable, IsLittleEndian);
					r.readBytesLen += r.innerClassesAttribute.readBytesLen;
				}
				
			}
			else if (r.attribute_name.equals("SourceFile")) {
				r.attribute_length = IO.readInt(is, IsLittleEndian);
				r.readBytesLen += 4;
				if (!owner.readsCode) {
					is.skip(r.attribute_length);
				}
				else {
					r.sourceFileAttribute =
							SourceFile_attribute.toSourceFile_attribute(is, constantTable, IsLittleEndian);
					r.readBytesLen += r.sourceFileAttribute.readBytesLen;
				}
				
			}
			// Code_Attribute는 Method_Info의 속성이다.
			else if (r.attribute_name.equals("Code")) {
				r.attribute_length = IO.readInt(is, IsLittleEndian); // ColorDialog의 ColorDialog()은 1169
				r.readBytesLen += 4;
				
				//r.info = new byte[r.attribute_length];
				//is.read(r.info);
				if (!owner.readsCode) {
					is.skip(r.attribute_length);
				}
				else {				
					// r.attribute_length 만큼 읽어들인다.
					int a;
					a=0;
					a++;
					r.codeAttribute = Code_attribute.toCode_attribute(owner, is, 
							constantTable, IsLittleEndian);
					r.readBytesLen += r.codeAttribute.readBytesLen;
					
					r.codeAttribute.attribute_name_index = r.attribute_name_index;
					r.codeAttribute.attribute_length = r.attribute_length;
				}
			}
			
			// LineNumberTable, LocalVariableTable, StackMapTable 은 
			// Code_Attribute의 속성이다.
			else if (r.attribute_name.equals("StackMapTable")) {
				r.attribute_length = IO.readInt(is, IsLittleEndian);
				r.readBytesLen += 4;
				
				if (!owner.readsCode) {
					is.skip(r.attribute_length);
				}
				else {	
					// SimpleTest1의 test()의 info : [0, 1, -3, 0, 6, 1, 1]
					// r.attribute_length 만큼 읽어들인다.
					//r.info = new byte[r.attribute_length];
					//is.read(r.info);
					
					r.stackMapTableAttribute = StackMapTable_attribute.toStackMapTable_attribute(owner, is, 
							constantTable, IsLittleEndian);
					r.readBytesLen += r.stackMapTableAttribute.readBytesLen;
					
					r.stackMapTableAttribute.attribute_name_index = r.attribute_name_index;
					r.stackMapTableAttribute.attribute_length = r.attribute_length;
				}
			}
			else if (r.attribute_name.equals("LineNumberTable")) {
				r.attribute_length = IO.readInt(is, IsLittleEndian);
				r.readBytesLen += 4;
				
				if (!owner.readsCode) {
					is.skip(r.attribute_length);
				}
				else {				
					// r.attribute_length 만큼 읽어들인다.
					r.lineNumberTableAttribute = LineNumberTable_attribute.toLineNumberTable_attribute(
							is, constantTable, IsLittleEndian);
					r.readBytesLen += r.lineNumberTableAttribute.readBytesLen;
					
					r.lineNumberTableAttribute.attribute_name_index = r.attribute_name_index;
					r.lineNumberTableAttribute.attribute_length = r.attribute_length;
				}
			}
			else if (r.attribute_name.equals("LocalVariableTable")) {
				r.attribute_length = IO.readInt(is, IsLittleEndian); // 180, 182
				r.readBytesLen += 4;
				
				if (!owner.readsCode) {
					is.skip(r.attribute_length);
				}
				else {				
					// r.attribute_length 만큼 읽어들인다.
					r.localVarTableAttribute = LocalVariableTable_attribute.toLocalVariableTable_attribute(
							is, constantTable, IsLittleEndian);
					r.readBytesLen += r.localVarTableAttribute.readBytesLen;
					
					r.localVarTableAttribute.attribute_name_index = r.attribute_name_index;
					r.localVarTableAttribute.attribute_length = r.attribute_length;
				}
			}
			else {
				// 나머지 attribute들은 skip
				r.attribute_length = IO.readInt(is, IsLittleEndian);
				r.readBytesLen += 4;
				
				is.skip(r.attribute_length);
				/*if (owner.readsCode==false) {
					is.skip(r.attribute_length);
				}
				else {		
					r.info = new byte[r.attribute_length];
					is.read(r.info);
				}*/
			}
			return r;
			
		}

		@Override
		public void destroy() {
			
			/*if (this.classes!=null) {
				int i;
				for (i=0; i<this.classes.length; i++) {
					this.classes[i].destroy();
					this.classes[i] = null;
				}
				this.classes = null;
			}*/
			if (this.info!=null) {
				this.info = null;
			}
			this.attribute_name = null;
			if (codeAttribute!=null) {
				codeAttribute.destroy();
				codeAttribute = null;
			}
			if (lineNumberTableAttribute!=null) {
				lineNumberTableAttribute.destroy();
				lineNumberTableAttribute = null;
			}
			if (localVarTableAttribute!=null) {
				localVarTableAttribute.destroy();
				localVarTableAttribute = null;
			}
			if (exceptionsAttribute!=null) {
				exceptionsAttribute.destroy();
				exceptionsAttribute = null;
			}
			if (stackMapTableAttribute!=null) {
				stackMapTableAttribute.destroy();
				stackMapTableAttribute = null;
			}
		}
	}
	
	/** 내부클래스를 표현하는 클래스, 
	 * InnerClasses Attribute를 갖을 경우 내부클래스 하나를 표현하기 위해 사용한다.
	 * Attribute_Info의 read()의 InnerClasses부분을 참조한다.*/
	public static class Class_Info implements IReset {
		/** 0이 아니라면 constant pool 내 이 인덱스의 엔트리는 CONSTANT_Class_info이고,
		 * 0이면 내부클래스가 아니다.	 */
		int inner_class_info_index;
		public String innerClassName;
		/** 0이 아니라면 constant pool 내 이 인덱스의 엔트리는 CONSTANT_Class_info이고,
		 * 0이면 외부클래스가 없다.	 */
		int outer_class_info_index;
		String outerClassName;
		/** innerClassName의 짧은 이름을 갖는 CONSTANT_Utf8_info 를 가리키는 인덱스*/
		int inner_name_index;
		/** innerClassName 의 short 이름*/
		String simpleInnerName;
		short inner_class_access_flags;
		AccessModifier accessModifier;
		@Override
		public void destroy() {
			
			innerClassName = null;
			outerClassName = null;
			simpleInnerName = null;
			if (accessModifier!=null) {
				accessModifier.destroy();
				accessModifier = null;
			}
		}
		public void write(OutputStream os) {
			
			/*
			 * InnerClasses_attribute {<br>
				u2 attribute_name_index;<br>
				u4 attribute_length;<br>
				u2 number_of_classes;	<br>		
				{ <br>
				u2 inner_class_info_index;<br>
				u2 outer_class_info_index;<br>
				u2 inner_name_index;<br>
				u2 inner_class_access_flags;<br>
				} classes[number_of_classes];<br>
			  }<br>*/
			IO.writeShort(os, (short)this.inner_class_info_index, false);
			IO.writeShort(os, (short)this.outer_class_info_index, false);
			IO.writeShort(os, (short)this.inner_name_index, false);
			IO.writeShort(os, (short)this.inner_class_access_flags, false);
		}
		
		static int getAttributeLength() {
			return 2*4;
		}
	}
	
	
	
	public static class CONSTANT_String_info { 
		/**8*/
		byte tag; 
		int string_index; // CONSTANT_Utf8_info의 constantTable 내 인덱스
		ArrayList constantPool;
		/**tag:8*/
		public CONSTANT_String_info(byte tag, int string_index, ArrayList constantPool) {
			this.tag = tag;
			this.string_index = string_index;
			this.constantPool = constantPool;
		}
		public String toString() {
			/*if (constantPool!=null) {
				String str = ((CONSTANT_Utf8_info) constantPool.getItem(string_index)).str;
				return str;
			}
			else return str;*/
			return ""+this.string_index;
		}
	}
	
	public static class CONSTANT_Class_info {
		/**7*/
		byte tag;
		public int name_index; // CONSTANT_Utf8_info의 constantTable 내 인덱스
		ArrayList constantPool;
		/** .으로 구분되는 일반적인 full name*/
		String className;
		/**Lcom/gsoft/common/gui/ColorDialog;*/
		String classNameDescriptor;
		Compiler compiler;
		
		/** 클래스파일을 로드할 때 사용*/
		public CONSTANT_Class_info(byte tag, int name_index, ArrayList constantPool) {
			this.tag = tag;
			this.name_index = name_index;
			this.constantPool = constantPool;
		}
		/** 바이트코드를 생성할 때 필요하다.*/
		CONSTANT_Class_info(String classNameDescriptor, Compiler compiler) {
			this.classNameDescriptor = classNameDescriptor;
			this.compiler = compiler;
		}
		public String toString() {
			if (constantPool!=null) {
				classNameDescriptor = ((CONSTANT_Utf8_info) constantPool.getItem(name_index)).str;
				return classNameDescriptor;
			}
			else return classNameDescriptor;
		}
	}
	
	public static class CONSTANT_Long_info { 
		/**5*/
		byte tag; 
		long l;
		
		/** 바이트코드를 생성할 때 필요*/
		CONSTANT_Long_info(long l) {
			this.l = l;
		}
		
		public CONSTANT_Long_info(byte tag, long l) {
			this.tag = tag;
			this.l = l;
		}
		public String toString() {
			return String.valueOf(l);
		}
	}
	
	public static class CONSTANT_Double_info { 
		/**6*/
		byte tag; 
		double d;
		
		/** 바이트코드를 생성할 때 필요*/
		CONSTANT_Double_info(double d) {
			this.d = d;
		}
		
		public CONSTANT_Double_info(byte tag, double d) {
			this.tag = tag;
			this.d = d;
		}
		public String toString() {
			return String.valueOf(d);
		}
	}
	
	public static class CONSTANT_Float_info { 
		/**4*/
		byte tag; 
		float f; //IEEE 754 floating point single format
		
		/** 바이트코드를 생성할 때 필요*/
		CONSTANT_Float_info(float f) {
			this.f = f;
		}
		
		public CONSTANT_Float_info(byte tag, float f) {
			this.tag = tag;
			this.f = f;
		}
		public String toString() {
			return String.valueOf(f);
		}
	}
	
	public static class CONSTANT_Integer_info {
		/**3*/
		byte tag; 
		int integer; // big-endian (high byte first) order
		
		/** 바이트코드를 생성할 때 필요*/
		CONSTANT_Integer_info(int integer) {
			this.integer = integer;
		}
		
		public CONSTANT_Integer_info(byte tag, int integer) {
			this.tag = tag;
			this.integer = integer;
		}
		public String toString() {
			return String.valueOf(integer);
		}
	}
	
	public static class CONSTANT_Utf8_info { 
		/** tag는 1이다*/
		byte tag; 
		int length; // 바이트수
		public String str; //utf-8,  not null-terminated
		
		public CONSTANT_Utf8_info(byte tag, int length, String str) {
			this.tag = tag;
			this.length = length;
			this.str = str;
		}
		public String toString() {
			return str;
		}
	}
	
	
	/**The class_index item of a CONSTANT_Methodref_info
	structure must be a class type, not an interface type. The
	class_index item of a CONSTANT_InterfaceMethodref_info
	structure must be an interface type. The class_index item of a
	CONSTANT_Fieldref_info structure may be either a class type
	or an interface type.*/
	public static class CONSTANT_Field_info implements IReset {
		/**9*/
		public byte tag;
		/** class를 가리킬 수도 있고 interface를 가리킬수도 있다.*/
		int classRef;
		int nameAndTypeDescRef;
		/** type descriptor 형식으로 출력*/
		String parent;
		/** android.view.View*/
		String parentClassName;
		String name;
		String typeDesc;
		String nameAndTypeDesc;
		ArrayList constantPool;
		PathClassLoader loader;
		public CONSTANT_Field_info(int classRef, int nameAndTypeDescRef, 
				ArrayList constantPool, PathClassLoader loader) {
			this.classRef = classRef;
			this.nameAndTypeDescRef = nameAndTypeDescRef;
			this.constantPool = constantPool;
			this.loader = loader;
		}
		
		public void setName(String name) {
			this.name = name;
		}
		
		/** 바이트코드를 생성할 때 필요하다.
		 * @param parent : type descriptor 형식으로 출력*/
		CONSTANT_Field_info(String parent, String name, String typeDesc, Compiler compiler) {
			this.parent = parent;
			this.name = name;
			this.typeDesc = typeDesc;
		}
		
		/** 바이트코드를 생성할 때 필요하다.
		 * @param parent : type descriptor 형식으로 출력*/
		CONSTANT_Field_info(String parent, String nameAndTypeDesc, Compiler compiler) {
			this.parent = parent;
			this.nameAndTypeDesc = nameAndTypeDesc;
		}
		
		@Override
		public void destroy() {
			
			this.parent = null;
			this.name = null;
			this.typeDesc = null;
		}
		
		
		/** 바이트코드를 생성할 때 호출한다.*/
		String getFieldInfoStr() {
			if (this.nameAndTypeDesc==null) {
				return parent + "::" + typeDesc + " " + name;
			}
			else {
				return parent + "::" + nameAndTypeDesc;
			}
		}
		
		public String toString() {
			if (constantPool!=null) {
				CONSTANT_NameAndTypeDesc_info ntd = (CONSTANT_NameAndTypeDesc_info) constantPool.getItem(nameAndTypeDescRef);
				//ntd.toString();
				this.name = ((CONSTANT_Utf8_info) constantPool.getItem(ntd.nameRef)).str;
				this.typeDesc = ((CONSTANT_Utf8_info) constantPool.getItem(ntd.typeDescRef)).str;
				int parentNameIndex = ((CONSTANT_Class_info)constantPool.getItem(classRef)).name_index;
				try {
				this.parent = ((CONSTANT_Utf8_info)constantPool.getItem(parentNameIndex)).str;
				}catch(Exception e) {
					if (Common_Settings.g_printsLog) e.printStackTrace();
				}
				
				Field_Info field_Info = new Field_Info();
				field_Info.name = name;
				field_Info.descriptor = typeDesc;
				FindVarParams var = Field_Info.toFindVarParams(loader.compiler, field_Info, null, false);
				
				//var.fieldName = parent + "." + var.fieldName;
				return parent + "::" + var.toString();
			}
			else {
				/*Field_Info field_Info = new Field_Info();
				field_Info.name = name;
				field_Info.descriptor = typeDesc;
				FindVarParams var = Field_Info.toFindVarParams(compiler, field_Info, null, false);
				*/
				//var.fieldName = parent + "." + var.fieldName;
				return this.getFieldInfoStr();
			}
		}
	}
	
	/**The class_index item of a CONSTANT_Methodref_info
		structure must be a class type, not an interface type. The
		class_index item of a CONSTANT_InterfaceMethodref_info
		structure must be an interface type. The class_index item of a
		CONSTANT_Fieldref_info structure may be either a class type
		or an interface type.*/
	public static class CONSTANT_Method_info implements IReset {
		/**10*/
		public byte tag;
		/** interface를 가리키는게 아니라 class를 가리켜야 한다.*/
		int classRef; // CONSTANT_Class_info 을 가리키는 constant table 내 인덱스
		int nameAndTypeDescRef;
		/** type descriptor 형식으로 출력*/
		String parent;
		/** android.view.View*/
		String parentClassName;
		String name;
		String typeDesc;
		String nameAndTypeDesc;
		ArrayList constantPool;
		PathClassLoader loader;
		Compiler compiler;
		
		public CONSTANT_Method_info(int classRef, int nameAndTypeDescRef, ArrayList constantPool, PathClassLoader loader) {
			this.classRef = classRef;
			this.nameAndTypeDescRef = nameAndTypeDescRef;
			this.constantPool = constantPool;
			this.loader = loader;
			
		}

		/** 바이트코드를 생성할 때 필요하다.
		 * The class_index item of a CONSTANT_Methodref_info
			structure must be a class type, not an interface type. The
			class_index item of a CONSTANT_InterfaceMethodref_info
			structure must be an interface type. The class_index item of a
			CONSTANT_Fieldref_info structure may be either a class type
			or an interface type. 
		 * @param parentClassName : type descriptor 형식으로 출력
		 * @param funcName
		 * @param typeDescriptor
		 * @param compiler
		 */
		public CONSTANT_Method_info(String parentClassName, String funcName,
				String typeDescriptor, Compiler compiler) {
			
			this.parent = parentClassName;
			this.name = funcName;
			this.typeDesc = typeDescriptor;
			this.compiler = compiler;
		}
		
		/** 바이트코드를 생성할 때 필요하다.*/
		public CONSTANT_Method_info(String parentClassName, String nameAndTypeDesc, Compiler compiler) {
			
			this.parent = parentClassName;
			this.nameAndTypeDesc = nameAndTypeDesc;
			this.compiler = compiler;
		}

		@Override
		public void destroy() {
			
			this.parent = null;
			this.name = null;
			this.typeDesc = null;
		}
		
		
		/** 바이트코드를 생성할 때 호출한다.*/
		String getMethodInfoStr() {
			if (this.nameAndTypeDesc==null) {
				return parent + "::" + typeDesc + " " + name;
			}
			else {
				return parent + "::" + nameAndTypeDesc;
			}
		}
		
		public String toString() {
			if (constantPool!=null) {
				CONSTANT_NameAndTypeDesc_info ntd = (CONSTANT_NameAndTypeDesc_info) constantPool.getItem(nameAndTypeDescRef);
				//ntd.toString();
				this.name = ((CONSTANT_Utf8_info) constantPool.getItem(ntd.nameRef)).str;
				this.typeDesc = ((CONSTANT_Utf8_info) constantPool.getItem(ntd.typeDescRef)).str;
				int parentNameIndex = ((CONSTANT_Class_info)constantPool.getItem(classRef)).name_index;
				this.parent = ((CONSTANT_Utf8_info)constantPool.getItem(parentNameIndex)).str;
				
				Method_Info method_Info = new Method_Info();
				method_Info.name = name;
				method_Info.descriptor = typeDesc;
				
				FindFunctionParams func = Method_Info.toFindFunctionParams(loader.compiler, loader, 
						method_Info, loader.typeNameInTemplatePair, true, parent, false);
				
				//func.name = parent + "." + func.name;
				return parent + "::" + func.toString();
			}
			else {
				/*Method_Info method_Info = new Method_Info();
				method_Info.name = name;
				method_Info.descriptor = typeDesc;
				
				String typeNameInTemplatePair = null;
				
				FindFunctionParams func = Method_Info.toFindFunctionParams(compiler, loader, 
						method_Info, typeNameInTemplatePair, true, parent, false);*/
				
				//func.name = parent + "." + func.name;
				
				return this.getMethodInfoStr();
			}
		}
		
		
	}
	
	
	/**The class_index item of a CONSTANT_Methodref_info
	structure must be a class type, not an interface type. The
	class_index item of a CONSTANT_InterfaceMethodref_info
	structure must be an interface type. The class_index item of a
	CONSTANT_Fieldref_info structure may be either a class type
	or an interface type.*/
	public static class CONSTANT_InterfaceMethod_info implements IReset {
		/**11*/
		public byte tag;
		/** class를 가리키는게 아니라 interface를 가리켜야 한다.*/
		int classRef;
		int nameAndTypeDescRef;
		/** type descriptor 형식으로 출력, class가 아니라 interface*/
		String parent;
		String name;
		String typeDesc;
		String nameAndTypeDesc;
		ArrayList constantPool;
		PathClassLoader loader;
		Compiler compiler;
		
		public CONSTANT_InterfaceMethod_info(PathClassLoader loader, ArrayList constantPool, int classRef, int nameAndTypeDescRef) {
			this.classRef = classRef;
			this.nameAndTypeDescRef = nameAndTypeDescRef;
			this.constantPool = constantPool;
			this.loader = loader;
		}
		
		/** 바이트코드를 생성할 때 필요하다.
		 * The class_index item of a CONSTANT_Methodref_info
			structure must be a class type, not an interface type. The
			class_index item of a CONSTANT_InterfaceMethodref_info
			structure must be an interface type. The class_index item of a
			CONSTANT_Fieldref_info structure may be either a class type
			or an interface type. 
		 * @param parentClassName : type descriptor 형식으로 출력
		 * @param funcName
		 * @param typeDescriptor
		 * @param compiler
		 */
		public CONSTANT_InterfaceMethod_info(String parentClassName, String funcName,
				String typeDescriptor, Compiler compiler) {
			
			this.parent = parentClassName;
			this.name = funcName;
			this.typeDesc = typeDescriptor;
			this.compiler = compiler;
		}
		
		/** 바이트코드를 생성할 때 필요하다.*/
		public CONSTANT_InterfaceMethod_info(String parentClassName, String nameAndTypeDesc, Compiler compiler) {
			
			this.parent = parentClassName;
			this.nameAndTypeDesc = nameAndTypeDesc;
			this.compiler = compiler;
		}

		@Override
		public void destroy() {
			
			this.parent = null;
			this.name = null;
			this.typeDesc = null;
		}
				
		/** 바이트코드를 생성할 때 호출한다.*/
		String getMethodInfoStr() {
			if (this.nameAndTypeDesc==null) {
				return parent + "::" + typeDesc + " " + name;
			}
			else {
				return parent + "::" + nameAndTypeDesc;
			}
		}
		
		public String toString() {
			if (constantPool!=null) {
				CONSTANT_NameAndTypeDesc_info ntd = (CONSTANT_NameAndTypeDesc_info) constantPool.getItem(nameAndTypeDescRef);
				//ntd.toString();
				this.name = ((CONSTANT_Utf8_info) constantPool.getItem(ntd.nameRef)).str;
				this.typeDesc = ((CONSTANT_Utf8_info) constantPool.getItem(ntd.typeDescRef)).str;
				int parentNameIndex = ((CONSTANT_Class_info)constantPool.getItem(classRef)).name_index;
				this.parent = ((CONSTANT_Utf8_info)constantPool.getItem(parentNameIndex)).str;
				
				Method_Info method_Info = new Method_Info();
				method_Info.name = name;
				method_Info.descriptor = typeDesc;
				
				FindFunctionParams func = Method_Info.toFindFunctionParams(loader.compiler, loader, 
						method_Info, loader.typeNameInTemplatePair, true, parent, false);
				
				//func.name = parent + "." + func.name;
				return parent + "::" + func.toString();
			}
			else {
				/*Method_Info method_Info = new Method_Info();
				method_Info.name = name;
				method_Info.descriptor = typeDesc;
				
				String typeNameInTemplatePair = null;
				
				FindFunctionParams func = Method_Info.toFindFunctionParams(compiler, loader, 
						method_Info, typeNameInTemplatePair, true, parent, false);
				*/
				//func.name = parent + "." + func.name;
				
				return this.getMethodInfoStr();
			}
		}
	}
	
	public static class CONSTANT_NameAndTypeDesc_info {
		/**12*/
		byte tag;
		int nameRef;
		int typeDescRef;
		ArrayList constantPool;
		String name;
		String typeDesc;
		
		public CONSTANT_NameAndTypeDesc_info(int nameRef, int typeDescRef, ArrayList constantPool) {
			this.nameRef = nameRef;
			this.typeDescRef = typeDescRef;
			this.constantPool = constantPool;
			
		}
		
		CONSTANT_NameAndTypeDesc_info(String name, String typeDesc) {
			this.name = name;
			this.typeDesc = typeDesc;
		}
		
		/** name과 typeDesc가 정해진다.*/
		public String toString() {
			if (constantPool!=null) {
				this.name = ((CONSTANT_Utf8_info) constantPool.getItem(nameRef)).str;
				this.typeDesc = ((CONSTANT_Utf8_info) constantPool.getItem(typeDescRef)).str;
				// return name + ":" + typeDesc;
				return typeDesc + " " + name;
			}
			else {
				return typeDesc + " " + name;
			}
		}
	}
	
	
	/**Flag Name 		Value Interpretation 
	 * ACC_PUBLIC 		0x0001 Declared public; may be accessed from outside its package. 
	 * ACC_PRIVATE 		0x0002 Declared private; usable only within the defining class. 
	 * ACC_PROTECTED 	0x0004 Declared protected; may be accessed within subclasses. 
	 * ACC_STATIC 		0x0008 Declared static. 
	 * ACC_FINAL	 	0x0010 Declared final; no further assignment after initialization. 
	 * ACC_VOLATILE 	0x0040 Declared volatile; cannot be cached. 
	 * ACC_TRANSIENT 	0x0080 Declaredtransient; not written or read by a persistent object manager. 
	 * ACC_SYNTHETIC 	0x1000 Declared synthetic; Not present in the source code. 
	 * ACC_ENUM 		0x4000 Declared as an element of an enum.*/
	public static class Field_Info implements IReset {
		short access_flags;
		/** 필드 이름을 표현하는 CONSTANT_Utf8_info 의 constant table 내 인덱스*/
		int name_index;
		/** 필드 디스크립터를 표현하는 CONSTANT_Utf8_info 의 constant table 내 인덱스*/
		int descriptor_index;
		int attributes_count;
		Attribute_Info[] attributes;
		
		String name;
		String descriptor;
		AccessModifier accessModifier;
		
		/**
		 * field_info { <br>
			u2 access_flags; <br>
			u2 name_index; <br>
			u2 descriptor_index; <br>
			u2 attributes_count; <br>
			attribute_info attributes[attributes_count]; <br>
		  } <br>
		 * @param output
		 * @param generator
		 * @param IsLittleEndian
		 * @param var
		 */
		static void write(OutputStream output, ByteCodeGeneratorForClass generator, boolean IsLittleEndian, FindVarParams var, int coreThreadID) {
			short accessFlags = ByteCode_Types.accessModifierToShort(var.accessModifier, ClassFieldMethod.Field);
			IO.writeShort(output, accessFlags, IsLittleEndian); // u2
			
			HashItemOfConstantTable hashItem = 
					(HashItemOfConstantTable) generator.physical.listOfConstantTableUtf8Hashed.getData(var.fieldName);
			int nameRef = hashItem.index; // u2
			if (var.fieldName.equals("menuType")) {
				nameRef = 6;
			}
			IO.writeShort(output, (short)nameRef, false);
			
			String typeDesc = TypeDescriptor.getDescriptor(var, coreThreadID);
			hashItem = 
					(HashItemOfConstantTable) generator.physical.listOfConstantTableUtf8Hashed.getData(typeDesc);
			int descRef = hashItem.index; // u2
			if (var.fieldName.equals("menuType")) {
				descRef = 5;
			}
			IO.writeShort(output, (short)descRef, false);
			
			// attributes_count, u2
			IO.writeShort(output, (short)0, IsLittleEndian);
		}
		
		public static Field_Info read(PathClassLoader owner, InputStream is, ArrayList constantTable, boolean IsLittleEndian) throws IOException, Exception {
			try {
			Field_Info r = new Field_Info();
			r.access_flags = IO.readShort(is, IsLittleEndian);
			r.accessModifier = ByteCode_Types.toAccessModifier(r.access_flags, ClassFieldMethod.Field);
			r.name_index = IO.readUnsignedShort(is, IsLittleEndian);
			
			
			r.name = ((CONSTANT_Utf8_info) constantTable.getItem(r.name_index)).str;
			
			r.descriptor_index = IO.readUnsignedShort(is, IsLittleEndian);
			r.descriptor = ((CONSTANT_Utf8_info) constantTable.getItem(r.descriptor_index)).str;
			
			r.attributes_count = IO.readUnsignedShort(is, IsLittleEndian);
			r.attributes = new Attribute_Info[r.attributes_count];
			int i;
			for (i=0; i<r.attributes_count; i++) {
				r.attributes[i] = Attribute_Info.read(owner, is, constantTable, IsLittleEndian);
			}
			
			return r;
			}catch(Exception e) {
				if (Common_Settings.g_printsLog) e.printStackTrace();				
				throw e;
			}
			
		}
		
		/** indexC 는 c의 fieldDescriptor상에서의 인덱스를 말한다.*/
		private static String getType(String fieldDescriptor, char c, int indexC, boolean setsSeparatorToDot) {
			String typeName=null;
			if (c=='B') typeName = "byte";				
			else if (c=='C') typeName = "char";
			else if (c=='D') typeName = "double";
			else if (c=='F') typeName = "float";
			else if (c=='I') typeName = "int";
			else if (c=='J') typeName = "long";
			else if (c=='S') typeName = "short";
			else if (c=='Z') typeName = "boolean";
			else if (c=='L') {
				typeName = fieldDescriptor.substring(indexC+1, fieldDescriptor.length()-1);
				if (setsSeparatorToDot) {
					typeName = typeName.replace('/', '.');
					typeName = typeName.replace('$', '.');
				}
			}
			else {
				typeName = fieldDescriptor.substring(indexC, fieldDescriptor.length());
				if (setsSeparatorToDot) {
					typeName = typeName.replace('/', '.');
					typeName = typeName.replace('$', '.');
				}
			}
			return typeName;
		}
		
		public static String getType(Field_Info field, boolean setsSeparatorToDot) {
			String typeName=null;
			if (field.descriptor!=null) {
				char c = field.descriptor.charAt(0);				
				if (c=='[') { // array
					int i;
					int dimension=1;
					for (i=1; i<field.descriptor.length(); i++) {
						c = field.descriptor.charAt(i);
						if (c=='[') {
							dimension++;
						}
						else break;
					}
					int j;
					String arrDimension = "";
					for (j=0; j<dimension; j++) {
						arrDimension = arrDimension + "[]";
					}
					// array의 원소 타입
					char t = field.descriptor.charAt(i);
					String elementType = getType(field.descriptor, t, i, setsSeparatorToDot);
					typeName = elementType + arrDimension;
					
				}
				else {
					typeName = getType(field.descriptor, c, 0, setsSeparatorToDot);
				}
			}
			return typeName;
		}
		
		public static String getType(String descriptor, boolean setsSeparatorToDot) {
			String typeName=null;
			if (descriptor!=null) {
				char c = descriptor.charAt(0);				
				if (c=='[') { // array
					int i;
					int dimension=1;
					for (i=1; i<descriptor.length(); i++) {
						c = descriptor.charAt(i);
						if (c=='[') {
							dimension++;
						}
						else break;
					}
					int j;
					String arrDimension = "";
					for (j=0; j<dimension; j++) {
						arrDimension = arrDimension + "[]";
					}
					// array의 원소 타입
					char t = descriptor.charAt(i);
					String elementType = getType(descriptor, t, i, setsSeparatorToDot);
					typeName = elementType + arrDimension;
					
				}
				else {
					typeName = getType(descriptor, c, 0, setsSeparatorToDot);
				}
			}
			return typeName;
		}
		
		/** @param typeNameInTemplatePair : 클래스가 템플릿 클래스일 경우 <>안에 있는 바꿔야 할 풀 타입 이름이다.
		 * @param setsSeparatorToDot : path separator 나 '$'등 디렉토리 관련정보를 '.'으로 바꾸려면 true,
		 * 그렇지 않으면 false*/
		public static FindVarParams toFindVarParams(Compiler compiler, Field_Info field, String typeNameInTemplatePair,
				boolean setsSeparatorToDot) {
			FindVarParams var=null;
			//var = FindVarParams(field.name)
			String typeName = field.descriptor;
			String fieldName;
			fieldName = field.name;
			if (fieldName.equals("out")) {
				int a;
				a=0;
				a++;
			}
			typeName = getType(field, setsSeparatorToDot);
			var = new FindVarParams(compiler, typeName, fieldName);
			if (typeNameInTemplatePair!=null) {
				//T data 에서 T는 바이트코드에서 java.lang.Object이다.
				// java.lang.Object을 typeNameInTemplatePair으로 바꾼다.
				if (var.typeName.equals("java.lang.Object")) {
					var.typeName = typeNameInTemplatePair;
				}
			}
			var.accessModifier = field.accessModifier;
			var.isMemberOrLocal = true;
			return var;
		}

		@Override
		public void destroy() {
			
			if (this.accessModifier!=null) {
				this.accessModifier.destroy();
				this.accessModifier = null;
			}
			if (this.attributes!=null) {
				int i;
				for (i=0; i<this.attributes_count; i++) {
					this.attributes[i].destroy();
					this.attributes[i] = null;
				}
			}
			this.name = null;
			this.descriptor = null;
		}
	}
	
	/**Flag Name Value Interpretation
	ACC_PUBLIC 0x0001 Declared public ; may be accessed	from outside its package.
	ACC_PRIVATE 0x0002 Declared private ; accessible only within the defining class.
	ACC_PROTECTED 0x0004 Declared protected ; may be accessed within subclasses.
	ACC_STATIC 0x0008 Declared static .
	ACC_FINAL 0x0010 Declared final ; must not be over-ridden.
	ACC_SYNCHRONIZED 0x0020 Declared synchronized ; invocation is wrapped in a monitor lock.
	ACC_BRIDGE 0x0040 A bridge method, generated by the	compiler.
	ACC_VARARGS 0x0080 Declared with variable number of	arguments.
	ACC_NATIVE 0x0100 Declared native ; implemented in a language other than Java.
	ACC_ABSTRACT 0x0400 Declared abstract ; no implementa-tion is provided.
	ACC_STRICT 0x0800 Declared strictfp ; floating-point mode is FP-strict
	ACC_SYNTHETIC 0x1000 Declared synthetic ; Not present in the source code.*/
	public static class Method_Info implements IReset {
		short access_flags;
		/** 메서드 이름을 표현하는 CONSTANT_Utf8_info 의 constant table 내 인덱스*/
		int name_index;
		/** 메서드 디스크립터를 표현하는 CONSTANT_Utf8_info 의 constant table 내 인덱스*/
		int descriptor_index;
		public int attributes_count;
		/** code, exception attribute 등*/
		public Attribute_Info[] attributes;
		
		public String name;
		String descriptor;
		AccessModifier accessModifier;
		
		/**
		 * method_info { <br>
			u2 access_flags; <br>
			u2 name_index; <br>
			u2 descriptor_index; <br>
			u2 attributes_count; <br>
			attribute_info attributes[attributes_count]; <br>
		  } <br>
		 * @param output
		 * @param generator
		 * @param isLittleEndian
		 * @param func
		 * @param indexOfFunc : PathClassWriter.printMethods()에서 method의 인덱스
		 * @param compiler
		 */
		public static void write(OutputStream output,
				ByteCodeGeneratorForClass generator, boolean isLittleEndian,
				FindFunctionParams func, int indexOfFunc, Compiler compiler, Code_attribute codeAttribute, int coreThreadID) {
			
			// u2
			short accessFlags = ByteCode_Types.accessModifierToShort(func.accessModifier, ClassFieldMethod.Method);
			IO.writeShort(output, accessFlags, isLittleEndian);
			
			String funcName = func.name;
			if (func.isConstructor) {
				if (func.isConstructorThatInitializesStaticFields) {
					funcName = "<clinit>";
				}
				else funcName = "<init>";
			}
			if (func.isConstructor) {
				int a;
				a=0;
				a++;
			}
			if (funcName.equals("substring")) {
				int a;
				a=0;
				a++;
			}
			ArrayList constantTable = generator.physical.listOfConstantTable;
			HashItemOfConstantTable hashItem = 
					(HashItemOfConstantTable) generator.physical.listOfConstantTableUtf8Hashed.getData(funcName);
			int nameRef = 0;
			try {
			nameRef = hashItem.index; // u2
			}catch(Exception e) {
				if (Common_Settings.g_printsLog) e.printStackTrace();
			}
			IO.writeShort(output, (short)nameRef, false);
			
			String typeDesc = TypeDescriptor.getDescriptor(func, coreThreadID);
			hashItem = 
					(HashItemOfConstantTable) generator.physical.listOfConstantTableUtf8Hashed.getData(typeDesc);
			int descRef = hashItem.index; // u2
			IO.writeShort(output, (short)descRef, false);
			
			// attributes_count, Code attribute, u2
			int attributes_count = 1;
			if (func.accessModifier.isAbstract || func.accessModifier.isNative) {
				attributes_count = 0;
				IO.writeShort(output, (short)attributes_count, isLittleEndian);
				return;
			}
			
			IO.writeShort(output, (short)attributes_count, isLittleEndian);
			
			// Code attribute 쓰기
			
			//codeAttribute = new Code_attribute(generator, func, indexOfFunc, compiler);
			
			// attribute_name_index 쓰기, u2
			hashItem = 
					(HashItemOfConstantTable) generator.physical.listOfConstantTableUtf8Hashed.getData("Code");
			IO.writeShort(output, (short)hashItem.index, false);
			
			// attribute_length 쓰기, u4, 1169
			int attribute_length = codeAttribute.getAttributeLength();
			IO.writeInt(output, attribute_length, false);
			
			if (func.functionNameIndex()==4198) {
				int a;
				a=0;
				a++;
			}
			
			try {
				codeAttribute.write(output, false, coreThreadID);
			} catch (IOException e) {
				
				if (Common_Settings.g_printsLog) e.printStackTrace();
			}
		}
		
		public static Method_Info read(PathClassLoader owner, InputStream is, ArrayList constantTable, boolean IsLittleEndian) throws IOException, Exception {
			try {
			Method_Info r = new Method_Info();
			r.access_flags = IO.readShort(is, IsLittleEndian);
			r.accessModifier = ByteCode_Types.toAccessModifier(r.access_flags, ClassFieldMethod.Method);
			r.name_index = IO.readUnsignedShort(is, IsLittleEndian);
			try {
			r.name = ((CONSTANT_Utf8_info) constantTable.getItem(r.name_index)).str;
			}catch(Exception e) {
				//if (Common_Settings.g_printsLog) e.printStackTrace();
				throw e;
			}
			
			
			if (r.name.equals("<clinit>") || r.name.equals("<init>")) {
			}
			
			r.descriptor_index = IO.readUnsignedShort(is, IsLittleEndian);
			// ProcessBuilder의 command()함수의 디스크립터는 다음과 같다.
			// ()Ljava/util/List;
			// ([Ljava/lang/String;)Ljava/lang/ProcessBuilder;
			// (Ljava/util/List;)Ljava/lang/ProcessBuilder;
			
			r.descriptor = ((CONSTANT_Utf8_info) constantTable.getItem(r.descriptor_index)).str;
			
			
			r.attributes_count = IO.readUnsignedShort(is, IsLittleEndian);
			r.attributes = new Attribute_Info[r.attributes_count];
			int i;
			for (i=0; i<r.attributes_count; i++) {
				r.attributes[i] = Attribute_Info.read(owner, is, constantTable, IsLittleEndian);
			}
			return r;
			
			}catch(Exception e) {
				//if (Common_Settings.g_printsLog) e.printStackTrace();
				throw e;
			}
			
		}
		
		@Override
		public void destroy() {
			
			if (this.accessModifier!=null) {
				this.accessModifier.destroy();
				this.accessModifier = null;
			}
			if (this.attributes!=null) {
				int i;
				for (i=0; i<this.attributes_count; i++) {
					this.attributes[i].destroy();
					this.attributes[i] = null;
				}
			}
			this.name = null;
			this.descriptor = null;
		}
		
		
		
		private static String getType(String descriptor, char c, int index, int arrayDimension,
				boolean setsSeparatorToDot) {
			String typeName=null;
			if (c=='V') typeName = "void";
			else if (c=='B') typeName = "byte";				
			else if (c=='C') typeName = "char";
			else if (c=='D') typeName = "double";
			else if (c=='F') typeName = "float";
			else if (c=='I') typeName = "int";
			else if (c=='J') typeName = "long";
			else if (c=='S') typeName = "short";
			else if (c=='Z') typeName = "boolean";
			else if (c=='L') {
				int i;
				for (i=index+1; i<descriptor.length(); i++) {
					if (descriptor.charAt(i)==';') break;
				}
				
				typeName = descriptor.substring(index+1, i);
				if (setsSeparatorToDot) {
					typeName = typeName.replace('/', '.');
					typeName = typeName.replace('$', '.');
				}
			}
			int i;
			for (i=0; i<arrayDimension; i++) {
				typeName = typeName + "[]";
			}
			return typeName;
		}
		
		static int getSemicolonIndex(String descriptor, int startIndex) {
			int i;
			int count = descriptor.length();
			for (i=startIndex; i<count; i++) {
				char c = descriptor.charAt(i);
				if (c==';') return i;
			}
			return -1;
		}
		
		
		
		static String[] getTypes(Method_Info method, boolean setsSeparatorToDot) {
			ArrayListString list = new ArrayListString(10); 
			String[] r = null;
			if (method.name.equals("getItems")) {
			}
			// (파라미터디스크립터*)리턴디스크립터
			if (method.descriptor!=null) {
				int i;
				String descriptor = method.descriptor;
				int dimensionArray = 0;
				// 파라미터 타입들
				int len = descriptor.length();
				for (i=0; i<len; i++) {
					char c = descriptor.charAt(i);
					if (c=='(') continue;
					else if (c==')') {
						i++;
						break;
					}
					else if (c=='[') {
						dimensionArray++;
					}
					else if (c=='V' || c=='B' || c=='C' || c=='D' || c=='F' || c=='I' || c=='J' || c=='S' || c=='Z') {						
						String type = getType(descriptor, c, i, dimensionArray, setsSeparatorToDot);
						list.add(type);
						dimensionArray = 0;
					}
					else if (c=='L') {						
						String type = getType(descriptor, c, i, dimensionArray, setsSeparatorToDot);
						list.add(type);
						//i += type.length();
						i = getSemicolonIndex(descriptor, i);
						dimensionArray = 0;
					}
				}
				// 리턴 타입들
				for (;i<descriptor.length(); i++) {
					char c = descriptor.charAt(i);
					if (c=='[') {
						dimensionArray++;
					}
					else if (c=='V' || c=='B' || c=='C' || c=='D' || c=='F' || c=='I' || c=='J' || c=='S' || c=='Z') {						
						String type = getType(descriptor, c, i, dimensionArray, setsSeparatorToDot);
						list.add(type);
						dimensionArray = 0;
					}
					else if (c=='L') {						
						String type = getType(descriptor, c, i, dimensionArray, setsSeparatorToDot);
						list.add(type);
						//i += type.length();
						i = getSemicolonIndex(descriptor, i);
						dimensionArray = 0;
					}
				}
				
				r = list.getItems();
			}
			return r;
		}
		
		
		static String[] getTypes(String descriptor, boolean setsSeparatorToDot) {
			ArrayListString list = new ArrayListString(10); 
			String[] r = null;
			// (파라미터디스크립터*)리턴디스크립터
			if (descriptor!=null) {
				int i;
				//String descriptor = method.descriptor;
				int dimensionArray = 0;
				// 파라미터 타입들
				int len = descriptor.length();
				for (i=0; i<len; i++) {
					char c = descriptor.charAt(i);
					if (c=='(') continue;
					else if (c==')') {
						i++;
						break;
					}
					else if (c=='[') {
						dimensionArray++;
					}
					else if (c=='V' || c=='B' || c=='C' || c=='D' || c=='F' || c=='I' || c=='J' || c=='S' || c=='Z') {						
						String type = getType(descriptor, c, i, dimensionArray, setsSeparatorToDot);
						list.add(type);
						dimensionArray = 0;
					}
					else if (c=='L') {						
						String type = getType(descriptor, c, i, dimensionArray, setsSeparatorToDot);
						list.add(type);
						//i += type.length();
						i = getSemicolonIndex(descriptor, i);
						dimensionArray = 0;
					}
				}
				// 리턴 타입들
				for (;i<descriptor.length(); i++) {
					char c = descriptor.charAt(i);
					if (c=='[') {
						dimensionArray++;
					}
					else if (c=='V' || c=='B' || c=='C' || c=='D' || c=='F' || c=='I' || c=='J' || c=='S' || c=='Z') {						
						String type = getType(descriptor, c, i, dimensionArray, setsSeparatorToDot);
						list.add(type);
						dimensionArray = 0;
					}
					else if (c=='L') {						
						String type = getType(descriptor, c, i, dimensionArray, setsSeparatorToDot);
						list.add(type);
						//i += type.length();
						i = getSemicolonIndex(descriptor, i);
						dimensionArray = 0;
					}
				}
				
				r = list.getItems();
			}
			return r;
		}
		
		public static LocalVariableTable_attribute findLocalVariableTable_attribute(Method_Info method_info) {
			int i, j;
			if (method_info.attributes==null) return null;
			for (i=0; i<method_info.attributes.length; i++) {
				Attribute_Info attribute_info = method_info.attributes[i];
				if (attribute_info.attribute_name.equals("Code")) {
					Code_attribute codeAttribute = attribute_info.codeAttribute;
					if (codeAttribute==null || codeAttribute.attributes==null) return null;
					for (j=0; j<codeAttribute.attributes.length; j++) {
						Attribute_Info attribute_info2 = codeAttribute.attributes[j];
						if (attribute_info2.attribute_name.equals("LocalVariableTable")) {
							return attribute_info2.localVarTableAttribute;
						}
					}
				}
			}
			return null;
		}
		
		
		/** @param typeNameInTemplatePair : 클래스가 템플릿 클래스일 경우 <>안에 있는 바꿔야 할 풀 타입 이름이다.
		 * @param changesInitToConstructorName : init 메서드 이름을 클래스 이름으로 바꾸는지 여부
		 * @param setsSeparatorToDot : path separator 나 '$'등 디렉토리 관련정보를 '.'으로 바꾸려면 true,
		 * 그렇지 않으면 false*/
		public static FindFunctionParams toFindFunctionParams(Compiler compiler, ClassLoader loader, 
				Method_Info method, String typeNameInTemplatePair, 
				boolean changesInitToConstructorName, String parent, boolean setsSeparatorToDot) {
			FindFunctionParams func=null;
			//var = FindVarParams(field.name)
			String[] listOfTypes;
			String methodName;
			methodName = method.name;
			
			if (method.name.equals("test")) {
			}
			
			listOfTypes = getTypes(method, setsSeparatorToDot);
			func = new FindFunctionParams(compiler, methodName);
			func.returnType = listOfTypes[listOfTypes.length-1];
			func.method_Info = method;
			
			
			if (method.name.equals("<init>") || method.name.equals("<clinit>")) {
				if (changesInitToConstructorName) {					
					method.name = CompilerStatic.getShortName(parent);
					if (method.name.charAt(method.name.length()-1)==';') {
						// parent가 Ljava/lang/Object;인 경우
						// 마지막 ;을 제거한다.
						method.name = method.name.substring(0, method.name.length()-1);
					}
				}
				func.name = method.name;
				if (func.name.equals("Control")) {
				}
				// stack = new Stack<Block>();에서 Stack<Block>의 fullNameIncludingTemplateExceptArray는
				// com.gsoft.common.Util.Stack<com.gsoft.common.Compiler_types.Block>이다.
				if (loader==null) {// 바이트코드를 만들때
					func.returnType = parent + "." + func.name;
				}
				else {  // 바이트코드를 읽을때
					func.returnType = loader.fullNameIncludingTemplateExceptArray;
				}
				func.isConstructor = true;
				if (method.accessModifier!=null && method.accessModifier.isStatic) {
					func.isConstructorThatInitializesStaticFields = true;
				}
			}
			
			if (typeNameInTemplatePair!=null) {
				//T Get()에서 T는 바이트코드에서 java.lang.Object이다.
				// java.lang.Object을 typeNameInTemplatePair으로 바꾼다.
				if (func.returnType.equals("java.lang.Object")) {
					func.returnType = typeNameInTemplatePair;
				}
			}
			
			LocalVariableTable_attribute localVariableTable_attribute = Method_Info.findLocalVariableTable_attribute(method);
			int i;
			func.listOfFuncArgs = new ArrayListIReset(5);
			for (i=0; i<listOfTypes.length-1; i++) {
				String typeName = listOfTypes[i];
				String argName = null;
				// Gets argName of func from local_variable_table
				if (localVariableTable_attribute!=null) {
					try {
					if (!method.accessModifier.isStatic) {
						//if (i+1<localVariableTable_attribute.local_variable_table.length) {
							argName = localVariableTable_attribute.local_variable_table[i+1].name;
						//}
					}
					else {
						argName = localVariableTable_attribute.local_variable_table[i].name;
					}
					}catch(Exception e) {
						//e.printStackTrace();
						//throw e;
					}
				}
				else {
					int a;
					a=0;
					a++;
				}
				FindVarParams param = new FindVarParams(compiler, typeName, argName);
				//void Push(T data)에서 T는 바이트코드에서 java.lang.Object이다.
				// java.lang.Object을 typeNameInTemplatePair으로 바꾼다.
				if (typeNameInTemplatePair!=null) {
					if (param.typeName.equals("java.lang.Object")) {
						param.typeName = typeNameInTemplatePair;
					}
				}
				func.listOfFuncArgs.add(param);
			}
			func.accessModifier = method.accessModifier;
			return func;
		}

		
	}
	
	
	public static class Verification_Type_info {
		/** 0이면 ITEM_Top, 1이면 ITEM_Integer, 2이면 ITEM_Float,
		 * 3이면 ITEM_Double, 4이면 ITEM_Long, 5이면 ITEM_Null,
		 * 6이면 ITEM_UninitializedThis, 7이면 ITEM_Object, 
		 * 8이면 ITEM_Uninitialized, u1 */
		short tagShort;
		int cpool_index; // ITEM_Object이면 의미가 있다.
		int offset;	// ITEM_Uninitialized이면 의미가 있다.
		public static ArrayList constantTable;
		public int readBytesLen;
		
		public static Verification_Type_info read(InputStream is,
				ArrayList constantTable, boolean isLittleEndian) {			
			Verification_Type_info r = new Verification_Type_info();
			byte tag = IO.readByte(is); 
			r.readBytesLen += 1;
			
			byte[] arr = {tag, 0};
			r.tagShort = IO.toShort(arr, true);
			if (r.tagShort==7) { // ITEM_Object
				r.cpool_index = IO.readUnsignedShort(is, isLittleEndian);
				r.readBytesLen += 2;
			}
			else if (r.tagShort==8) { // ITEM_Uninitialized
				r.offset = IO.readUnsignedShort(is, isLittleEndian);
				r.readBytesLen += 2;
			}
			else { // 더이상 작업할 필요가 없다.
				
			}
			return r;
		}
		
		Verification_Type_info() {
			
		}
		
		Verification_Type_info(int type) {
			tagShort = (short) type;
		}
		
		public String toString() {
			try {
			switch (tagShort) {
			case 0: return "Top_variable_info";
			case 1: return "Integer_variable_info";
			case 2: return "Float_variable_info";
			case 3: return "Double_variable_info";
			case 4: return "Long_variable_info ";
			case 5: return "Null_variable_info";
			case 6: return "UninitializedThis_variable_info";
			case 7: {
				if (constantTable!=null) { // 바이트코드를 읽을 때
					CONSTANT_Class_info classInfo = (CONSTANT_Class_info)constantTable.getItem(cpool_index);
					String typeDesc = ((CONSTANT_Utf8_info)constantTable.getItem(classInfo.name_index)).str;
					return "Object_variable_info-"+typeDesc; // cpool_index
				}
				else { // 바이트코드를 쓸 때
					return "Object_variable_info"; // cpool_index
				}
			}
			case 8: return "Uninitialized_variable_info"; // offset
			}
			return "";
			}catch(Exception e) {
				if (Common_Settings.g_printsLog) e.printStackTrace();
				return null;
			}
		}

		public void write(OutputStream os, boolean isLittleEndian) {
			
			IO.writeByte(os, (byte)tagShort);
			switch (tagShort) {
			case 0: return; // "Top_variable_info";
			case 1: return; // "Integer_variable_info";
			case 2: return; // "Float_variable_info";
			case 3: return; // "Double_variable_info";
			case 4: return; // "Long_variable_info ";
			case 5: return; // "Null_variable_info";
			case 6: return; //  "UninitializedThis_variable_info";
			case 7: IO.writeShort(os, (short)cpool_index, isLittleEndian); return; // "Object_variable_info"; // cpool_index
			case 8: IO.writeShort(os, (short)offset, isLittleEndian); return; // "Uninitialized_variable_info"; // offset
			}
		}

		public int getAttributeLength() {
			
			int r = 1; // tagShort
			switch (tagShort) {
			case 0: return r; // "Top_variable_info";
			case 1: return r; // "Integer_variable_info";
			case 2: return r; // "Float_variable_info";
			case 3: return r; // "Double_variable_info";
			case 4: return r; // "Long_variable_info ";
			case 5: return r; // "Null_variable_info";
			case 6: return r; //  "UninitializedThis_variable_info";
			case 7: return r+=2; // "Object_variable_info"; // cpool_index
			case 8: return r+=2; // "Uninitialized_variable_info"; // offset
			}
			return r;
		}
		
	}
	
}
