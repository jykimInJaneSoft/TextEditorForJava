package com.gsoft.common.compiler.bytecode;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.IO;
import com.gsoft.common.interfaces.IReset;
import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.Compiler_types.FindFunctionParams;
import com.gsoft.common.compiler.Compiler_types.FindVarParams;
import com.gsoft.common.compiler.bytecode.ByteCode_Types.ByteCodeInstruction;
import com.gsoft.common.compiler.bytecode.ByteCode_Types.Exception_Entry;
import com.gsoft.common.compiler.bytecode.ByteCode_Types.LineNumberTable_attribute;
import com.gsoft.common.compiler.bytecode.ByteCode_Types.LineNumber_Entry;
import com.gsoft.common.compiler.bytecode.ByteCode_Types.LocalVariableTable_Entry;
import com.gsoft.common.compiler.bytecode.ByteCode_Types.LocalVariableTable_attribute;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.Attribute_Info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_Class_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_Double_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_Field_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_Float_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_Integer_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_InterfaceMethod_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_Long_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_Method_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_String_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_Utf8_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.Field_Info;
import com.gsoft.common.compiler.classloader.PathClassLoader;
import com.gsoft.common.util.Array;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListInt;
import com.gsoft.common.util.HighArray_CodeChar;
import com.gsoft.common.util.HighArray_byte;
import com.gsoft.common.util.Util;

import com.gsoft.common.compiler.bytecode.StackMapTable_attribute;
import com.gsoft.common.compiler.bytecode.ByteCodeGeneratorForClass;
import com.gsoft.common.compiler.bytecode.HighArrayCharForByteCode;
import com.gsoft.common.compiler.bytecode.ByteCode_Types;

/** Attribute_Info의 한 종류(attribute_name이 Code 이면), 
 * Method_Info일 경우 attribute 이다.*/
public class Code_attribute implements IReset {
	//private static short LocalVariableTable_length;
	/** attribute_name_index, attribute_length 이 처음 6바이트를 제외해야 한다.
	 *  Attribute_Info에서 이미 읽었다.*/
	int attribute_name_index;
	/** attribute_name_index, attribute_length 이 처음 6바이트를 제외해야 한다.
	 *  Attribute_Info에서 이미 읽었다.*/
	int attribute_length; 
	/**  operand stack 의 최대깊이*/
	int max_stack;
	/** 지역변수 array 에서 메서드 아큐먼트를 포함한 지역변수의 개수,
	 * long, double 의 경우 최대 가능한 인덱스는 max_locals-2가 되고,
	 * 다른 타입은 max_locals-1이 된다.*/
	int max_locals;
	int code_length; 
	/** 실제 code*/
	byte[] code;//code_length
	/** 예외 테이블의 엔트리 개수*/
	int exception_table_length;
	Exception_Entry[] exception_table;//exception_table_length
	int attributes_count;
	/** LineNumberTable ,LocalVariableTable,
	 * attributes which contain debugging information,
	as well as the StackMapTable attribute 등을 포함한다. */
	Attribute_Info[] attributes;//attributes_count,
	PathClassLoader pathClassLoader;
	
	/** getLineNumberTableEntry()에서 설정되고, 캐시된다.*/
	LineNumberTable_attribute lineNumberTable = null;
	/** getLineNumberTableEntry()에서 사용되고 캐시된다. lineNumberTable의 검색 시작 인덱스*/
	int indexOfStartOfLineNumberTable;
	
	/** getLocalVariableTableEntry()에서 설정되고, 캐시된다.*/
	LocalVariableTable_attribute localVariableTable = null;
	
	StackMapTable_attribute stackMapTable = null;
	private ByteCodeGeneratorForClass generator;
	private int indexOfFunc;
	/** tableswitch의 디폴트 어드레스와 오프셋들을 little endian으로 읽으면 true, 그렇지 않으면 false,
	 * 초기값은 false이다.*/
	private static boolean mIsLittleEndianOfSwitch = false;
	
	
	int readBytesLen;
	
	/** func에 있는 로컬변수들을 static에 따라 long, double의 경우 2를 나머지 타입들은 1을
	 * 부여해서 max_locals를 리턴한다.
	 * @param func
	 * @return
	 */
	public static int getMaxLocals(FindFunctionParams func) {
		int max_locals = 0;
		int i;
		for (i=0; i<func.listOfVariableParams.count; i++) {
			FindVarParams var = (FindVarParams) func.listOfVariableParams.getItem(i);
			if (var.typeName.equals("long") || var.typeName.equals("double"))
				max_locals += 2;
			else max_locals++;
		}
		if (func.accessModifier.isStatic) {
		}
		else {
			max_locals++;// this가 포함되기 때문에 1을 더해준다.
		}
		return max_locals;
	}
	
	Code_attribute(ByteCodeGeneratorForClass generator, FindFunctionParams func, int indexOfFunc, Compiler compiler, int coreThreadID) {
		this.generator = generator;
		this.indexOfFunc = indexOfFunc;
		
		// colorButtons[k] = new Button(owner, namesOfColorButtons[k], namesOfColorButtons[k], 
		// colors[k], boundsOfColorButtons, true, alpha, true, 0.0f, null, this.backColor);
		// 여기에서 max_stack은 Button[], int, uninitialized 551(new), uninitialized 551(dup), 
		// view(owner), String(namesOfColorButtons[k]), String(namesOfColorButtons[k]), 
		// int(colors[k]), Rectangle(boundsOfColorButtons), integer(true), integer(alpha) 등이다.
		this.max_stack = 30; // u2
		
		this.max_locals = (short) getMaxLocals(func); // u2
					
		// code_length 쓰기, u4
		
		// exception_table_length 쓰기, u2
		exception_table_length = (short) this.generator.physical.arrResult[this.indexOfFunc].exception_table.count;
	
	
		
		////////////////// LocalVariableTable attribute 쓰기 시작 ////////////////////
		/*
		LocalVariableTable_attribute {
			u2 attribute_name_index;
			u4 attribute_length;
			u2 local_variable_table_length;
			{   u2 start_pc;
				u2 length;
				u2 name_index;
				u2 descriptor_index;
				u2 index;
			} local_variable_table[local_variable_table_length];
		}
		*/
		
		// 함수가 static이냐에 따라서 this를 추가또는 제외한다.
		this.localVariableTable = new LocalVariableTable_attribute(func, generator, indexOfFunc);
		
		
		this.stackMapTable = new StackMapTable_attribute(func, generator, indexOfFunc, compiler, coreThreadID);
		
		this.lineNumberTable = new LineNumberTable_attribute(func, generator, indexOfFunc);
	}
	
	public Code_attribute() {
		
	}

	/**  attribute_name_index, attribute_length 6바이트를 제외한 Code_attribute의 길이<br>
	 * max_stack부터 code attribute가 가지는 LocalVariableTable, StackMapTable attribute를 포함한 바이트 길이<br>
	 * Code_attribute { <br>
		u2 attribute_name_index; <br>
		u4 attribute_length; <br>
		u2 max_stack; <br>
		u2 max_locals; <br>
		u4 code_length; <br>
		u1 code[code_length]; <br>
		u2 exception_table_length; <br>
		{   u2 start_pc; <br>
			u2 end_pc; <br>
			u2 handler_pc; <br>
			u2 catch_type; <br>
		} exception_table[exception_table_length]; <br>
		u2 attributes_count; <br>
		attribute_info attributes[attributes_count]; <br>
	}*/
	public int getAttributeLength() {
		ByteCodeGeneratorForClass generator = this.generator;
		int indexOfFunc = this.indexOfFunc;
		
		HighArray_byte codeArr = generator.physical.arrResult3[indexOfFunc];
		
		HighArrayCharForByteCode byteCodes = generator.physical.arrResult[indexOfFunc];
		// exception_table_length 쓰기
		short entry_count = (short) byteCodes.exception_table.count;			
		int lengthOfExceptionTableInByte = entry_count * Exception_Entry.getAttributeLength();
		
		
		int attributeLengthOfStackMapTable = 0;
		/* StackMapTable attribute의 처음 6바이트와 
		 * StackMapTable의 엔트리 개수와 
		 * StackMapTable의 실제 바이트 길이*/ 
		// 함수에 controlBlock이 없으면 StackMapEntry를 만들지 않는다.
		if (this.stackMapTable.number_of_entries>0) {
			attributeLengthOfStackMapTable = 6+this.stackMapTable.getAttributeLength();
		}
		
		
		// Code_Attribute의 처음 6바이트를 제외해서 Code_Attribute의 attribut_length를 구한다.
		return   /*max_stack+max_locals*/
				2 + 2 +
				/*code_length와 실제 code[]의 길이*/
				4 + codeArr.getCount()+ 
				/* exception_table_length(exception_table의 엔트리개수)와 
				 * exception_table의 바이트길이*/
				2 + lengthOfExceptionTableInByte + 
				/* attributes_count*/					
				2 +
				/* LocalVariableTable attribute의 처음 6바이트와 
				 * LocalVariableTable의 엔트리 개수와 
				 * LocalVariableTable의 실제 바이트 길이*/ 
				(6+this.localVariableTable.getAttributeLength()) +
				
				attributeLengthOfStackMapTable + 
				
				(6+this.lineNumberTable.getAttributeLength()); 
	}
	
	/**
	 * Code_attribute { <br>
		u2 attribute_name_index; <br>
		u4 attribute_length; <br>
		u2 max_stack; <br>
		u2 max_locals; <br>
		u4 code_length; <br>
		u1 code[code_length]; <br>
		u2 exception_table_length; <br>
		{   u2 start_pc; <br>
			u2 end_pc; <br>
			u2 handler_pc; <br>
			u2 catch_type; <br>
		} exception_table[exception_table_length]; <br>
		u2 attributes_count; <br>
		attribute_info attributes[attributes_count]; <br>
	}
	 * @param coreThreadID */
	public void write(OutputStream output,  
			boolean isLittleEndian, int coreThreadID) throws IOException {
		HighArray_byte codeArr = this.generator.physical.arrResult3[this.indexOfFunc]; /*Common.codeArr;*/
		HighArrayCharForByteCode byteCodes = this.generator.physical.arrResult[this.indexOfFunc]; /*Common.byteCodes;*/
		ByteCodeGeneratorForClass generator = this.generator;
		
		// u2
		IO.writeShort(output, (short)max_stack, isLittleEndian);
		
		// u2
		IO.writeShort(output, (short)max_locals, isLittleEndian);
					
		// code_length 쓰기, u4
		IO.writeInt(output, codeArr.getCount(), isLittleEndian);
		
		// code 쓰기, code_length길이만큼 
		output.write(codeArr.getItems(), 0, codeArr.count);
		
		
		// exception_table_length 쓰기, u2		
		IO.writeShort(output, (short)this.exception_table_length, isLittleEndian);
		
		// Exception_Entry[] 쓰기, exception_table_length*Exception_Entry.getAttributeLength()
		int i;
		for (i=0; i<exception_table_length; i++) {
			Exception_Entry entry = (Exception_Entry) byteCodes.exception_table.getItem(i);
			Exception_Entry.write(output, entry, isLittleEndian);
		}			
		
		
		
		// attributes_count 쓰기, 일단 1개만(LocalVariableTable, LineNumberTable, StackMapTable), u2
		short attributes_count = 1;
		// 함수에 controlBlock이 없으면 StackMapEntry를 만들지 않는다.
		if (stackMapTable.number_of_entries>0) {
			attributes_count = 2;
		}
		// LineNumberTable을 추가한다.
		attributes_count++;
		IO.writeShort(output, attributes_count, isLittleEndian);
		
		
		////////////////// LocalVariableTable attribute 쓰기 시작 ////////////////////
		/*
		LocalVariableTable_attribute {
			u2 attribute_name_index;
			u4 attribute_length;
			u2 local_variable_table_length;
			{   u2 start_pc;
				u2 length;
				u2 name_index;
				u2 descriptor_index;
				u2 index;
			} local_variable_table[local_variable_table_length];
		}
		*/
		
		Attribute_Info.write(output, generator, localVariableTable, false, coreThreadID);
		
		// 함수에 controlBlock이 없으면 StackMapEntry를 만들지 않는다.
		if (stackMapTable.number_of_entries>0) {
			Attribute_Info.write(output, generator, stackMapTable, false, coreThreadID);
		}
		
		Attribute_Info.write(output, generator, this.lineNumberTable, false, coreThreadID);
		
	}
	
	
	/** Attribute_info 의 attribute_length 만큼 읽어들인다.*/
	public static Code_attribute toCode_attribute(PathClassLoader owner, InputStream is, 
			ArrayList constantTable, boolean IsLittleEndian) throws IOException {
		Code_attribute r = new Code_attribute();
		r.pathClassLoader = owner;
		//r.attribute_name_index = IO.readUnsignedShort(is);
		//r.attribute_length = IO.readInt(is);
		
		// int test(int arg1, int arg2) {
		//		int r = arg1 + arg2;
		// 		return r;
		// }
		// 위 함수의 경우 다음 속성들의 값은 속성 위 주석값과 같다.
	
		// 3
		r.max_stack = IO.readUnsignedShort(is, IsLittleEndian);
		// 1
		r.max_locals = IO.readUnsignedShort(is, IsLittleEndian);
		// 10
		r.code_length = IO.readInt(is, IsLittleEndian);
		
		r.readBytesLen += 8;
		
		
		
		//static int test(int arg1, int arg2) { // implicit frame
		//	int r = arg1 + arg2;
		//	return r;
		//}
		// 이 소스코드의 바이트 코드는 다음과 같다.
		
		// [26(1a:iload_0), 27(1b:iload_1), 96(60:iadd), 61(3d:lstore_2), 28(1c:iload_2), -84(ac:ireturn)]
		//String opcode1 = IO.toHexa((byte)26);
		//String opcode3 = IO.toHexa((byte)96);
		//String opcode4 = IO.toHexa((byte)61);
		//String opcode5 = IO.toHexa((byte)28);
		//String opcode6 = IO.toHexa((byte)-84);
		
		
		
		//static int test2(int arg1, int arg2) { 
		//	int r = arg1.intValue() + arg2;
		//	return r;
		//}
		
		//[42(2a:aload_0), -74(b6:invokevirtual), 0(b6의 인덱스), 22(b6의 인덱스), 27(1b:iload_1), 96(60:iadd), 61(3d:lstore_2), 28(1c:iload_2), -84(ac:ireturn)]
		/*String opcode1 = IO.toHexa((byte)42);
		String opcode3 = IO.toHexa((byte)-74);
		Method method = (Method) constantTable.getItem((0<<8)+22);
		Object className = constantTable.getItem(method.classRef);
		NameAndTypeDesc nameAndTypeDescRef = (NameAndTypeDesc) constantTable.getItem(method.nameAndTypeDescRef);
		String methodName = ((CONSTANT_Utf8_info) constantTable.getItem(nameAndTypeDescRef.nameRef)).str;
		String typeDesc = ((CONSTANT_Utf8_info) constantTable.getItem(nameAndTypeDescRef.typeDesc)).str;*/
		
		
		r.code = new byte[r.code_length];
		is.read(r.code);
		
		r.readBytesLen += r.code_length;
		
		// 0
		r.exception_table_length = IO.readUnsignedShort(is, IsLittleEndian);
		
		r.readBytesLen += 2;
		
		r.exception_table = new Exception_Entry[r.exception_table_length];
		int i;
		for (i=0; i<r.exception_table_length; i++) {
			r.exception_table[i] = Exception_Entry.read(is, IsLittleEndian);
			r.readBytesLen += r.exception_table[i].readBytesLen;
		}
		
		// 2
		r.attributes_count = IO.readUnsignedShort(is, IsLittleEndian);
		
		r.readBytesLen += 2;
		
		// LineNumberTable, LocalVariableTable, StackMapTable`
		r.attributes = new Attribute_Info[r.attributes_count];
		for (i=0; i<r.attributes_count; i++) {
			r.attributes[i] = Attribute_Info.read(owner, is, constantTable, IsLittleEndian);
			r.readBytesLen += r.attributes[i].readBytesLen;
		}
		
		return r;
		
	}
	
	/** instruction 의 인덱스, 즉 otherByte로 LocalVariableTable_Entry를 얻는다.*/
	LocalVariableTable_Entry getLocalVariableTableEntry(int indexOfLocalVarInStackFrame) {
		if (this.attributes==null) return null;
		int i;
		
		if (localVariableTable==null) {
			for (i=0; i<this.attributes_count; i++) {
				Attribute_Info info = this.attributes[i];
				if (info.attribute_name.equals("LocalVariableTable")) {
					localVariableTable = info.localVarTableAttribute;
					break;
				}
			}
		}
		if (localVariableTable!=null) {				
			//if (indexOfLocalVarInStackFrame<localVariableTable.local_variable_table_length) {
				for (i=0; i<localVariableTable.local_variable_table_length; i++) {
					LocalVariableTable_Entry entry = localVariableTable.local_variable_table[i];
					if (entry.index==indexOfLocalVarInStackFrame) {
						return entry;
					}
				}
			/*}
			else 
				return null;*/
		}
		return null;
	}
	
	/** code array의 인덱스로 Exception_Entry(예외핸들러)를 찾는다.
	 * @param type : 0-start_pc, 1-end_pc, 2-handler_pc*/
	Exception_Entry[] getExceptionEntry(int indexInCodeArray, int type) {
		if (exception_table!=null) {
			int j;
			ArrayList r = new ArrayList(5);
			if (type==0) {
				for (j=0; j<exception_table.length; j++) {
					Exception_Entry entry = exception_table[j];
					if (entry.start_pc==indexInCodeArray) {
						r.add(entry);
					}
				}
			}//if (type==0) {
			else if (type==1) {
				for (j=0; j<exception_table.length; j++) {
					Exception_Entry entry = exception_table[j];
					if (entry.end_pc==indexInCodeArray) {
						r.add(entry);
					}
				}
			}//if (type==1) {
			else if (type==2) {
				for (j=0; j<exception_table.length; j++) {
					Exception_Entry entry = exception_table[j];
					if (entry.handler_pc==indexInCodeArray) {
						r.add(entry);
					}
				}
			}//if (type==2) {
			Exception_Entry[] result = new Exception_Entry[r.count]; 
			int i;
			for (i=0; i<r.count; i++) {
				result[i] = (Exception_Entry) r.getItem(i);
			}
			return result;
		}//if (exception_table!=null) {
		return null;
	}
	
	LineNumber_Entry getLineNumberEntry(int indexInCodeArray) {
		if (this.attributes==null) return null;
		int i;
		
		if (this.lineNumberTable==null) {
			for (i=0; i<this.attributes_count; i++) {
				Attribute_Info info = this.attributes[i];
				if (info.attribute_name.equals("LineNumberTable")) {
					lineNumberTable = info.lineNumberTableAttribute;
					break;
				}
			}
		}
		if (lineNumberTable!=null) {
			int j;
			j = this.indexOfStartOfLineNumberTable;
			for (; j<lineNumberTable.line_number_table_length; j++) {
				LineNumber_Entry entry = lineNumberTable.line_number_table[j];
				LineNumber_Entry nextEntry = null;
				if (j<lineNumberTable.line_number_table_length-1)
					nextEntry = lineNumberTable.line_number_table[j+1];
				if (nextEntry==null && entry.start_pc<=indexInCodeArray) {
					indexOfStartOfLineNumberTable = j;
					return entry;
				}
				if (entry.start_pc<=indexInCodeArray && 
						(nextEntry!=null && indexInCodeArray<nextEntry.start_pc)) {
					indexOfStartOfLineNumberTable = j;
					return entry;
				}
			}
			indexOfStartOfLineNumberTable = j;
		}
		return null;
	}
	
	/** instruction 인덱스의 지역변수 정보나 참조 이름, 분기주소 등의 메시지를 가져온다.*/
	CodeString getMessageOfIndices(ByteCodeInstruction instruction, ArrayList constantPool, 
			boolean IsLittleEndian)  throws Exception {
		
		CodeString r= new CodeString("", Common_Settings.varUseColor);
		
		switch (instruction.opcodeHexa) {
		case 0x19 : {//aload의 지역변수정보
			short otherByte = (short) instruction.indices.getItem(0);
			r = getMessageOfIndices_sub_LocalVar(otherByte);
		break;      }
		case 0x2a : {//aload_0의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar(0);				
		break;      }
		case 0x2b : {//aload_1의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar(1);
		break;      }
		case 0x2c : {//aload_2의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar(2);
		break;      }
		case 0x2d : {//aload_3의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar(3);				
		break;      }
		case 0xbd : {//anewarray 의 타입정보
			r = getMessageOfIndices_sub_ClassType_Field_Method(instruction, constantPool, 
					CONSTANT_Info_Type.Class, IsLittleEndian);
		break;      }
		
		case 0x3a : {//astore의 지역변수정보
			short otherByte = (short) instruction.indices.getItem(0);
			r = getMessageOfIndices_sub_LocalVar(otherByte);		
		break;      }
		case 0x4b : {//astore_0의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar(0);				
		break;      }
		case 0x4c : {//astore_1의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar(1);				
		break;      }
		case 0x4d : {//astore_2의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar(2);				
		break;      }
		case 0x4e : {//astore_3의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar(3);				
		break;      }
		
		case 0x10 : {//bipush의 상수 정보
			r = new CodeString(" (", Common_Settings.varUseColor);
			short otherByte = (short) instruction.indices.getItem(0);
			r = r.concate(new CodeString(" "+otherByte, Common_Settings.varUseColor));
			r = r.concate(new CodeString(" )", Common_Settings.varUseColor));				
		break;      }
		
		case 0xc0 : {//checkcast의 타입캐스트 정보
			r = getMessageOfIndices_sub_ClassType_Field_Method(instruction, constantPool, 
					CONSTANT_Info_Type.Class, IsLittleEndian);
		break;      }
		
		case 0x18 : {//dload의 지역변수정보
			short otherByte = (short) instruction.indices.getItem(0);
			r = getMessageOfIndices_sub_LocalVar(otherByte);		
		break;      }
		case 0x26 : {//dload_0의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar(0);				
		break;      }
		case 0x27 : {//dload_1의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar(1);				
		break;      }
		case 0x28 : {//dload_2의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar(2);				
		break;      }
		case 0x29 : {//dload_3의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar(3);				
		break;      }
		
		case 0x39 : {//dstore의 지역변수정보
			short otherByte = (short) instruction.indices.getItem(0);
			r = getMessageOfIndices_sub_LocalVar(otherByte);		
		break;      }
		case 0x47 : {//dstore_0의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar(0);				
		break;      }
		case 0x48 : {//dstore_1의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar(1);				
		break;      }
		case 0x49 : {//dstore_2의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar(2);				
		break;      }
		case 0x4a : {//dstore_3의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar(3);				
		break;      }
		
		
		case 0x17 : {//fload의 지역변수정보
			short otherByte = (short) instruction.indices.getItem(0);
			r = getMessageOfIndices_sub_LocalVar(otherByte);		
		break;      }
		case 0x22 : {//fload_0의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar(0);				
		break;      }
		case 0x23 : {//fload_1의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar(1);				
		break;      }
		case 0x24 : {//fload_2의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar(2);				
		break;      }
		case 0x25 : {//fload_3의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar(3);				
		break;      }
		
		case 0x38 : {//fstore의 지역변수정보
			short otherByte = (short) instruction.indices.getItem(0);
			r = getMessageOfIndices_sub_LocalVar(otherByte);		
		break;      }
		case 0x43 : {//fstore_0의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar(0);				
		break;      }
		case 0x44 : {//fstore_1의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar(1);				
		break;      }
		case 0x45 : {//fstore_2의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar(2);				
		break;      }
		case 0x46 : {//fstore_3의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar(3);				
		break;      }
		
		// getfield 부터
		case 0xb4 : {//getfield 의 필드 정보
			r = getMessageOfIndices_sub_ClassType_Field_Method(instruction, constantPool, 
					CONSTANT_Info_Type.Field, IsLittleEndian);
		break;      }
		case 0xb2 : {//getstatic 의 필드 정보
			r = getMessageOfIndices_sub_ClassType_Field_Method(instruction, constantPool, 
					CONSTANT_Info_Type.Field, IsLittleEndian);
		break;      }
		case 0xa7 : {//goto 의 분기 오프셋 정보
			r = getMessageOfIndices_sub_BranchOffset(instruction, false, IsLittleEndian);
		break;      }
		case 0xc8 : {//goto_w 의 분기 오프셋 정보
			r = getMessageOfIndices_sub_BranchOffset(instruction, true, IsLittleEndian);
		break;      }
		
		case 0xa5 : {//if_acmpeq 의 분기 오프셋 정보
			r = getMessageOfIndices_sub_BranchOffset(instruction, false, IsLittleEndian);
		break;      }
		case 0xa6 : {//if_acmpne 의 분기 오프셋 정보
			r = getMessageOfIndices_sub_BranchOffset(instruction, false, IsLittleEndian);
		break;      }
		case 0x9f : {//if_icmpeq 의 분기 오프셋 정보
			r = getMessageOfIndices_sub_BranchOffset(instruction, false, IsLittleEndian);
		break;      }
		case 0xa2 : {//if_icmpge 의 분기 오프셋 정보
			r = getMessageOfIndices_sub_BranchOffset(instruction, false, IsLittleEndian);
		break;      }
		case 0xa3 : {//if_icmpgt 의 분기 오프셋 정보
			r = getMessageOfIndices_sub_BranchOffset(instruction, false, IsLittleEndian);
		break;      }
		case 0xa4 : {//if_icmple 의 분기 오프셋 정보
			r = getMessageOfIndices_sub_BranchOffset(instruction, false, IsLittleEndian);
		break;      }
		case 0xa1 : {//if_icmplt 의 분기 오프셋 정보
			r = getMessageOfIndices_sub_BranchOffset(instruction, false, IsLittleEndian);
		break;      }
		case 0xa0 : {//if_icmpne 의 분기 오프셋 정보
			r = getMessageOfIndices_sub_BranchOffset(instruction, false, IsLittleEndian);
		break;      }
		// 0과 비교
		case 0x99 : {//ifeq 의 분기 오프셋 정보
			r = getMessageOfIndices_sub_BranchOffset(instruction, false, IsLittleEndian);
		break;      }
		case 0x9c : {//ifge 의 분기 오프셋 정보
			r = getMessageOfIndices_sub_BranchOffset(instruction, false, IsLittleEndian);
		break;      }
		case 0x9d : {//ifgt 의 분기 오프셋 정보
			r = getMessageOfIndices_sub_BranchOffset(instruction, false, IsLittleEndian);
		break;      }
		case 0x9e : {//ifle 의 분기 오프셋 정보
			r = getMessageOfIndices_sub_BranchOffset(instruction, false, IsLittleEndian);
		break;      }
		case 0x9b : {//iflt 의 분기 오프셋 정보
			r = getMessageOfIndices_sub_BranchOffset(instruction, false, IsLittleEndian);
		break;      }
		case 0x9a : {//ifne 의 분기 오프셋 정보
			r = getMessageOfIndices_sub_BranchOffset(instruction, false, IsLittleEndian);
		break;      }
		case 0xc7 : {//ifnonnull 의 분기 오프셋 정보
			r = getMessageOfIndices_sub_BranchOffset(instruction, false, IsLittleEndian);
		break;      }
		case 0xc6 : {//ifnull 의 분기 오프셋 정보
			r = getMessageOfIndices_sub_BranchOffset(instruction, false, IsLittleEndian);
		break;      }
		
		case 0x84 : {//iinc 의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar((short) instruction.indices.getItem(0));				
		break;      }
		
		case 0x15 : {//iload 의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar((short) instruction.indices.getItem(0));				
		break;      }
		case 0x1a : {//iload_0의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar(0);				
		break;      }
		case 0x1b : {//iload_1의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar(1);				
		break;      }
		case 0x1c : {//iload_2의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar(2);				
		break;      }
		case 0x1d : {//iload_3의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar(3);				
		break;      }
		
		case 0xc1 : {//instanceof 의 클래스 타입 정보
			r = getMessageOfIndices_sub_ClassType_Field_Method(instruction, constantPool, 
					CONSTANT_Info_Type.Class, IsLittleEndian);
		break;      }
		case 0xba : {//invokedynamic 의 메서드 정보
			r = getMessageOfIndices_sub_ClassType_Field_Method(instruction, constantPool, 
					CONSTANT_Info_Type.Method, IsLittleEndian);
		break;      }
		case 0xb9 : {//invokeinterface 의 메서드 정보
			r = getMessageOfIndices_sub_ClassType_Field_Method(instruction, constantPool, 
					CONSTANT_Info_Type.InterfaceMethod, IsLittleEndian);
		break;      }
		case 0xb7 : {//invokespecial 의 메서드 정보
			r = getMessageOfIndices_sub_ClassType_Field_Method(instruction, constantPool, 
					CONSTANT_Info_Type.Method, IsLittleEndian);
		break;      }
		case 0xb8 : {//invokestatic 의 메서드 정보
			r = getMessageOfIndices_sub_ClassType_Field_Method(instruction, constantPool, 
					CONSTANT_Info_Type.Method, IsLittleEndian);
		break;      }
		case 0xb6 : {//invokevirtual 의 메서드 정보
			r = getMessageOfIndices_sub_ClassType_Field_Method(instruction, constantPool, 
					CONSTANT_Info_Type.Method, IsLittleEndian);
		break;      }
		
		case 0x36 : {//lstore 의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar((short) instruction.indices.getItem(0));			
		break;      }
		case 0x3b : {//lstore_0의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar(0);				
		break;      }
		case 0x3c : {//lstore_1의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar(1);				
		break;      }
		case 0x3d : {//lstore_2의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar(2);				
		break;      }
		case 0x3e : {//lstore_3의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar(3);				
		break;      }
		
		case 0xa8 : {//jsr(jump to subroutine) 의 분기 오프셋 정보
			r = getMessageOfIndices_sub_BranchOffset(instruction, false, IsLittleEndian);
		break;      }
		case 0xc9 : {//jsr_w(jump to subroutine) 의 분기 오프셋 정보
			r = getMessageOfIndices_sub_BranchOffset(instruction, true, IsLittleEndian);
		break;      }
		
		
		case 0x12 : {//ldc 의 constant pool 상수 정보
			r = this.getMessageOfIndices_sub_Constant(instruction, constantPool, false, IsLittleEndian);
		break;      }
		case 0x13 : {//ldc_w 의 constant pool 상수 정보
			r = this.getMessageOfIndices_sub_Constant(instruction, constantPool, true, IsLittleEndian);
		break;      }
		case 0x14 : {//ldc2_w 의 constant pool 상수 정보
			r = this.getMessageOfIndices_sub_Constant(instruction, constantPool, true, IsLittleEndian);
		break;      }
		
		case 0x16 : {//lstore 의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar((short) instruction.indices.getItem(0));				
		break;      }
		case 0x1e : {//lstore_0의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar(0);				
		break;      }
		case 0x1f : {//lstore_1의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar(1);				
		break;      }
		case 0x20 : {//lstore_2의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar(2);				
		break;      }
		case 0x21 : {//lstore_3의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar(3);				
		break;      }
		
		// lookupswitch 부터
		case 0xab : {//loopupswitch 의 key 와 분기오프셋 정보
			r = getMessageOfIndices_sub_KeysAndBranchOffset(instruction);				
		break;      }
		
		case 0x37 : {//lstore 의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar((short) instruction.indices.getItem(0));				
		break;      }
		case 0x3f : {//lstore_0의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar(0);				
		break;      }
		case 0x40 : {//lstore_1의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar(1);				
		break;      }
		case 0x41 : {//lstore_2의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar(2);				
		break;      }
		case 0x42 : {//lstore_3의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar(3);				
		break;      }
		
		case 0xc5 : {//multianewarray 의 지역변수정보
			r = getMessageOfIndices_sub_ClassType_Field_Method(instruction, constantPool, 
					CONSTANT_Info_Type.Class, IsLittleEndian);				
		break;      }
		
		case 0xbb : {//new 의 지역변수정보
			r = getMessageOfIndices_sub_ClassType_Field_Method(instruction, constantPool, 
					CONSTANT_Info_Type.Class, IsLittleEndian);
		break;      }
		case 0xbc : {//newarray 의 지역변수정보
			r = getMessageOfIndices_sub_PrimitiveType(instruction, constantPool);
		break;      }
		
		case 0xb5 : {//putfield 의 지역변수정보
			r = getMessageOfIndices_sub_ClassType_Field_Method(instruction, constantPool, 
					CONSTANT_Info_Type.Field, IsLittleEndian);
		break;      }
		case 0xb3 : {//putstatic 의 지역변수정보
			r = getMessageOfIndices_sub_ClassType_Field_Method(instruction, constantPool, 
					CONSTANT_Info_Type.Field, IsLittleEndian);
		break;      }
		case 0xa9 : {//ret 의 지역변수정보
			r = getMessageOfIndices_sub_LocalVar(instruction.indices.getItem(0));
		break;      }
		
		case 0x11 : {//sipush 의 상수 정보
			r = this.getMessageOfIndices_sub_push(instruction, false, IsLittleEndian);
		break;      }
		
		case 0xaa : {//tableswitch 의 키와 분기 주소 정보
			r = this.getMessageOfIndices_sub_KeysAndBranchOffset_Extended(instruction, IsLittleEndian);
		break;      }
		
		case 0xc4 : {//wide 의 분기 주소 정보
			r = getMessageOfIndices_sub_wide(instruction, IsLittleEndian);
		break;      }
		}
		
		return r;
	}
	
	/** tableswitch */
	CodeString getMessageOfIndices_sub_KeysAndBranchOffset_Extended (
			ByteCodeInstruction instruction, boolean IsLittleEndian)  throws Exception {
		
		ArrayListInt indices = instruction.indices;
		int i;
		String message = "";
		String messageOfPrefix = "";
		// 0-3 바이트는 padding 바이트
		// key
		// key의 개수는 다음과 같다.
		int numOfPrefixes = 3;
		int limitOfPrefixes = instruction.countOfPadding + numOfPrefixes;
		
		i = instruction.countOfPadding;
		int defaultOffset = (int) indices.getItem(i);
		messageOfPrefix += " Default Offset : " + defaultOffset;
		
		i++;
		int lowInt = (int) indices.getItem(i);
		int low = lowInt;
		messageOfPrefix += " Low : " + lowInt;
		
		i++;
		int highInt = (int) indices.getItem(i);
		messageOfPrefix += " High : " + highInt;
		
				
		String branchOffset = " Offset :";
		int limitOfOffsets = instruction.indices.count;
		int k;
		for (i=limitOfPrefixes, k=low; i<limitOfOffsets; i++, k++) {
			branchOffset += "(";
			branchOffset += k + ", ";
			int offset = (int) indices.getItem(i);
			branchOffset += offset;
			branchOffset += ")  ";
		}
		
		message = messageOfPrefix + branchOffset;
		
		CodeString r = new CodeString(" (", Common_Settings.varUseColor);
		r = r.concate(new CodeString(" " +message, Common_Settings.varUseColor));
		r = r.concate(new CodeString(" )", Common_Settings.varUseColor));
		return r;
	}
	
	/** lookupswitch */
	CodeString getMessageOfIndices_sub_KeysAndBranchOffset (ByteCodeInstruction instruction)  throws Exception {
		
		ArrayListInt indices = instruction.indices;
		int i;
		String message = "";
		String messageOfDefaultOffsetAndCountOfItems = "";
		// 0-3 바이트는 padding 바이트
		
		int defaultOffset = (int) indices.getItem(instruction.countOfPadding);
		messageOfDefaultOffsetAndCountOfItems += "Default Offset : " + defaultOffset + "  ";
		
		int indexOfCountOfItems = instruction.countOfPadding+1;
		int countOfItems = (int) indices.getItem(indexOfCountOfItems);
		messageOfDefaultOffsetAndCountOfItems += "count of items : " + countOfItems + "  ";
		
		int indexOfKeysAndOffsets = indexOfCountOfItems+1;
		String branchOffset = ", Keys and Offsets : ";
		int limitOfLoop = indices.count;
		
		for (i=indexOfKeysAndOffsets; i<limitOfLoop; i+=2) {
			branchOffset += "(";
			int key = (int) indices.getItem(i);
			branchOffset += key;
			
			/*if (i==limitOfLoop-1) {
				// lookupswitch의 마지막 오프셋은 패딩바이트와 lookupswitch의 다음 명령어로 나뉘어진다.
				break;
			}*/
			int offset = (int) indices.getItem(i+1);
			branchOffset += ", " + offset;
			branchOffset += ") ";
		}
		
		message = messageOfDefaultOffsetAndCountOfItems + branchOffset;
		
		CodeString r = new CodeString(" (", Common_Settings.varUseColor);
		r = r.concate(new CodeString(" " +message, Common_Settings.varUseColor));
		r = r.concate(new CodeString(" )", Common_Settings.varUseColor));
		return r;
	}
	
	/** lookupswitch */
	CodeString getMessageOfIndices_sub_KeysAndBranchOffset_backup(ByteCodeInstruction instruction)  throws Exception {
		
		ArrayListInt indices = instruction.indices;
		int i;
		String message = "";
		String messageOfDefaultOffsetAndCountOfItems = "";
		// 0-3 바이트는 padding 바이트
		
		int defaultOffset = (int) indices.getItem(instruction.countOfPadding);
		messageOfDefaultOffsetAndCountOfItems += "Default Offset : " + defaultOffset + "  ";
		
		int indexOfCountOfItems = instruction.countOfPadding+1;
		int countOfItems = (int) indices.getItem(indexOfCountOfItems);
		messageOfDefaultOffsetAndCountOfItems += "count of items : " + countOfItems + "  ";
		
		int indexOfKeysAndOffsets = indexOfCountOfItems+1;
		String branchOffset = ", Keys and Offsets : ";
		int limitOfLoop = indices.count;
		
		for (i=indexOfKeysAndOffsets; i<limitOfLoop; i+=2) {
			branchOffset += "(";
			int key = (int) indices.getItem(i);
			branchOffset += key;
			
			if (i==limitOfLoop-1) {
				// lookupswitch의 마지막 오프셋은 패딩바이트와 lookupswitch의 다음 명령어로 나뉘어진다.
				break;
			}
			int offset = (int) indices.getItem(i+1);
			branchOffset += ", " + offset;
			branchOffset += ") ";
		}
		
		message = messageOfDefaultOffsetAndCountOfItems + branchOffset;
		
		CodeString r = new CodeString(" (", Common_Settings.varUseColor);
		r = r.concate(new CodeString(" " +message, Common_Settings.varUseColor));
		r = r.concate(new CodeString(" )", Common_Settings.varUseColor));
		return r;
	}
	
	
	
	/** s1은 첫번째 바이트(msb), s2는 두번째 바이트 이고 리턴값은 (첫번째바이트 << 8) + 두번째바이트*/
	int toUnsignedShort(short s1, short s2, boolean IsLittleEndian) {
		byte[] buf = new byte[2];
		IO.toBytes(s1, true, IO.arrByte_Len2);
		buf[0] = IO.arrByte_Len2[0]; // msb
		IO.toBytes(s2, true, IO.arrByte_Len2); 
		buf[1] = IO.arrByte_Len2[0]; // lsb
		
		//index = IO.r.toShort(buf, IsLittleEndian);
		return IO.toUnsignedShort(buf, false);
	}
	
	/** s1은 첫번째 바이트(msb), s2는 두번째 바이트 이고 리턴값은 (첫번째바이트 << 8) + 두번째바이트*/
	short toShort(short s1, short s2, boolean IsLittleEndian) {
		byte[] buf = new byte[2];
		IO.toBytes(s1, true, IO.arrByte_Len2);
		buf[0] = IO.arrByte_Len2[0]; // msb
		IO.toBytes(s2, true, IO.arrByte_Len2);
		buf[1] = IO.arrByte_Len2[0]; // lsb
		
		//index = IO.r.toShort(buf, IsLittleEndian);
		return IO.toShort(buf, false);
	}
	
	/** s1은 첫번째 바이트(msb), s2는 두번째 바이트, s3은 세번째 바이트, s4는 네번째 바이트 이고 
	 * 리턴값은 (첫번째바이트 << 24) + (두번째바이트 << 16) + (세번째바이트 << 8) + (네번째바이트 << 0)*/
	int toInt(short s1, short s2, short s3, short s4, boolean IsLittleEndian) 
			 throws Exception {
		try {
			/*byte[] buf = {(byte) (s4 & 0xff), (byte) (s3 & 0xff), 
					(byte) (s2 & 0xff), (byte) (s1 & 0xff)};
			return IO.toInt(buf, true);*/
			
			byte[] buf = {(byte) (s1 & 0xff), (byte) (s2 & 0xff), (byte) (s3 & 0xff), (byte) (s4 & 0xff)};
			return IO.toInt(buf, false);
		}catch(Exception e) {
			throw e;
		}finally {
			//IO.IsLittleEndian = endianBackup;
		}
	}
	
	
	/** isWide가 false 이면 (첫번째바이트 << 8) + 두번째바이트*/
	CodeString getMessageOfIndices_sub_BranchOffset (
			ByteCodeInstruction instruction, boolean isWide, boolean IsLittleEndian)
					 throws Exception {
		
		int index;
		if (!isWide) {
			ArrayListInt indices = instruction.indices;
			index = toShort((short)indices.getItem(0), (short)indices.getItem(1), true);
			
		}
		else {
			ArrayListInt indices = instruction.indices;
			index = toInt((short)indices.getItem(0), (short)indices.getItem(1), 
					(short)indices.getItem(2), (short)indices.getItem(3), true);
			
			byte[] buf = new byte[4];
			IO.toBytes((short)indices.getItem(0), true, IO.arrByte_Len2);
			buf[0] = IO.arrByte_Len2[0]; // msb
			IO.toBytes((short)indices.getItem(1), true, IO.arrByte_Len2);
			buf[1] = IO.arrByte_Len2[0];
			//buf[1] = IO.toBytes((short)indices.getItem(1), true)[0];
			IO.toBytes((short)indices.getItem(2), true, IO.arrByte_Len2);
			buf[2] = IO.arrByte_Len2[0];
			//buf[2] = IO.toBytes((short)indices.getItem(2), true)[0];
			IO.toBytes((short)indices.getItem(3), true, IO.arrByte_Len2);
			buf[3] = IO.arrByte_Len2[0];
			//buf[3] = IO.toBytes((short)indices.getItem(3), true)[0];
			
			index = IO.toInt(buf, false);
			
		}
		
		String branchOffset = String.valueOf(index);
		
		CodeString r = new CodeString(" (", Common_Settings.varUseColor);
		r = r.concate(new CodeString(" " +branchOffset, Common_Settings.varUseColor));
		r = r.concate(new CodeString(" )", Common_Settings.varUseColor));
		return r;
	}
	
	/** isWide가 false 이면 (첫번째바이트 << 8) + 두번째바이트*/
	CodeString getMessageOfIndices_sub_push (
			ByteCodeInstruction instruction, boolean isWide, boolean IsLittleEndian)
					 throws Exception {
		
		int index;
		if (!isWide) {
			ArrayListInt indices = instruction.indices;
			index = toUnsignedShort((short)indices.getItem(0), (short)indices.getItem(1), true);
			
		}
		else {
			ArrayListInt indices = instruction.indices;
			index = toInt((short)indices.getItem(0), (short)indices.getItem(1), 
					(short)indices.getItem(2), (short)indices.getItem(3), true);
			
			byte[] buf = new byte[4];
			IO.toBytes((short)indices.getItem(0), true, IO.arrByte_Len2);
			buf[0] = IO.arrByte_Len2[0]; // msb
			//buf[0] = IO.toBytes((short)indices.getItem(0), true)[0]; // msb
			IO.toBytes((short)indices.getItem(1), true, IO.arrByte_Len2);
			buf[1] = IO.arrByte_Len2[0];
			//buf[1] = IO.toBytes((short)indices.getItem(1), true)[0];
			IO.toBytes((short)indices.getItem(2), true, IO.arrByte_Len2);
			buf[2] = IO.arrByte_Len2[0];
			//buf[2] = IO.toBytes((short)indices.getItem(2), true)[0];
			IO.toBytes((short)indices.getItem(3), true, IO.arrByte_Len2);
			buf[3] = IO.arrByte_Len2[0];
			//buf[3] = IO.toBytes((short)indices.getItem(3), true)[0];
			
			index = IO.toInt(buf, false);
			
		}
		
		String value = String.valueOf(index);
		
		CodeString r = new CodeString(" (", Common_Settings.varUseColor);
		r = r.concate(new CodeString(" " +value, Common_Settings.varUseColor));
		r = r.concate(new CodeString(" )", Common_Settings.varUseColor));
		return r;
	}
	
	/** isWide가 false 이면 (첫번째바이트 << 8) + 두번째바이트*/
	CodeString getMessageOfIndices_sub_wide (ByteCodeInstruction instruction, boolean IsLittleEndian) 
			 throws Exception {
		
		int index;
		int count;
		
		ArrayListInt indices = instruction.indices;
		short opcode = (short)indices.getItem(0);
		ByteCodeInstruction instructionInHash = 
				(ByteCodeInstruction) ByteCode_Types.hashTableInstructionSet.getData(opcode);
		String mnemonic = " " + instructionInHash.mnemonic;
		String message = mnemonic;
	
		
		if (indices.count==3) {
			index = toUnsignedShort((short)indices.getItem(1), (short)indices.getItem(2), true);
			message += " " + index;
		}
		else if (indices.count==5) {
			index = toUnsignedShort((short)indices.getItem(1), (short)indices.getItem(2), true);
			count = toUnsignedShort((short)indices.getItem(3), (short)indices.getItem(4), true);
			message += " " + index + " " + count;
		}
		
		CodeString r = new CodeString(" (", Common_Settings.varUseColor);
		r = r.concate(new CodeString(" " +message, Common_Settings.varUseColor));
		r = r.concate(new CodeString(" )", Common_Settings.varUseColor));
		return r;
	}
	
	/** 인덱스로 constant pool 을 검색한다.*/
	CodeString getMessageOfIndices_sub_Constant (ByteCodeInstruction instruction, 
			ArrayList constantPool, boolean isWide, boolean IsLittleEndian) 
					 throws Exception {
		ArrayListInt indices = instruction.indices;
		int index;
		
		if (isWide) {
			index = toUnsignedShort((short)indices.getItem(0), (short)indices.getItem(1), true);
		}
		else {
			IO.toBytes((short)indices.getItem(0), true, IO.arrByte_Len2);
			byte b = IO.arrByte_Len2[0];
			index = (int)(0 & 0xff00) | (b & 0xff);
		}
		
		if (index==34) {
		}
		String message = "";
		Object item = constantPool.getItem(index);
		if (item instanceof CONSTANT_String_info) {
			int stringIndex = ((CONSTANT_String_info)item).string_index;
			message = ((CONSTANT_Utf8_info) constantPool.getItem(stringIndex)).str;
		}
		else if (item instanceof CONSTANT_Integer_info) {
			int value = ((CONSTANT_Integer_info)item).integer;
			//byte[] buf = IO.toBytes(value, false);
			IO.toBytes(value, false, IO.arrByte_Len4);
			byte[] buf = IO.arrByte_Len4;
			value = IO.toInt(buf, false);
			message = String.valueOf(value);
		}
		else if (item instanceof CONSTANT_Float_info) {
			float value = ((CONSTANT_Float_info)item).f;
			message = String.valueOf(value);
		}
		else if (item instanceof CONSTANT_Long_info) {
			long value = ((CONSTANT_Long_info)item).l;
			message = String.valueOf(value);
		}
		else if (item instanceof CONSTANT_Double_info) {
			double value = ((CONSTANT_Double_info)item).d;
			message = String.valueOf(value);
		}
		
					
		CodeString r = new CodeString(" (", Common_Settings.varUseColor);
		r = r.concate(new CodeString(" " +message, Common_Settings.varUseColor));
		r = r.concate(new CodeString(" )", Common_Settings.varUseColor));
		return r;
	}
	
	
	enum CONSTANT_Info_Type {
		Class,
		Field,
		Method,
		InterfaceMethod
	}
	
	
	int getAType(String typeDesc) {
		if (typeDesc.equals("Z")) return 4; // boolean
		else if (typeDesc.equals("C")) return 5;
		else if (typeDesc.equals("F")) return 6;
		else if (typeDesc.equals("D")) return 7;
		else if (typeDesc.equals("B")) return 8;
		else if (typeDesc.equals("S")) return 9;
		else if (typeDesc.equals("I")) return 10;
		else if (typeDesc.equals("J")) return 11; // long
		return -1;
	}
	
	/**newarray는 primitive type의 배열을 생성하므로 constant table에 넣지 않는다.<br>
	 * The atype operand of each newarray instruction must take one of the values
	   T_BOOLEAN (4), T_CHAR (5), T_FLOAT (6), T_DOUBLE (7), T_BYTE (8), T_SHORT
	   (9), T_INT (10), or T_LONG (11)*/
	CodeString getMessageOfIndices_sub_PrimitiveType(ByteCodeInstruction instruction, ArrayList constantPool) {
		
		ArrayListInt indices = instruction.indices;
		short s1 = (short) indices.getItem(0);
		String message = null;
		switch (s1) {
		case 4: message = "boolean"; break;
		case 5: message = "char"; break;
		case 6: message = "float"; break;
		case 7: message = "double"; break;
		case 8: message = "byte"; break;
		case 9: message = "short"; break;
		case 10: message = "int"; break;			
		case 11: message = "long"; break;
		}
		if (message!=null) {
			CodeString r = new CodeString(" (", Common_Settings.varUseColor);
			r = r.concate(new CodeString(" " +message, Common_Settings.varUseColor));
			r = r.concate(new CodeString(" )", Common_Settings.varUseColor));
			return r;
		}
		return null;
	}
	
	/** anewarray, checkcast 등 에서 타입을 필요로할때나 필드, 메서드 레퍼런스를 얻을때 호출*/
	CodeString getMessageOfIndices_sub_ClassType_Field_Method (ByteCodeInstruction instruction, 
			ArrayList constantPool, CONSTANT_Info_Type infoType, boolean IsLittleEndian) 
					 throws Exception {
		/*ArrayList indices = instruction.indices;
		short s1 = (short) indices.getItem(0);
		short s2 = (short) indices.getItem(1);
		//short index = (short) (( (s1 & 0xff) << 8 ) | (s2 & 0xff));
		byte[] buf = {(byte) (s2 & 0xff), (byte) (s1 & 0xff)};
		short index = IO.toShort(buf);*/
		ArrayListInt indices = instruction.indices;
					
		int index = toUnsignedShort((short)indices.getItem(0), (short)indices.getItem(1), false);
		
		String message = "";
		try {
		if (infoType==CONSTANT_Info_Type.Class) {
			CONSTANT_Class_info classInfo = (CONSTANT_Class_info) constantPool.getItem(index);
			message = ((CONSTANT_Utf8_info) constantPool.getItem(classInfo.name_index)).str;
			//message = CompilerHelper.setPathSeparatorToDot(message);
		}
		else if (infoType==CONSTANT_Info_Type.Field) {
			CONSTANT_Field_info fieldInfo = 
					(CONSTANT_Field_info) constantPool.getItem(index);
			//message = fieldInfo.toString();
			message = fieldInfo.parent + "::" + fieldInfo.typeDesc + " " + fieldInfo.name;
		}
		else if (infoType==CONSTANT_Info_Type.Method) {
			CONSTANT_Method_info method = (CONSTANT_Method_info) constantPool.getItem(index);
			message = method.parent + "::" + method.typeDesc + " " + method.name;
			//message = method.toString();
		}
		else if (infoType==CONSTANT_Info_Type.InterfaceMethod) {
			CONSTANT_InterfaceMethod_info method = (CONSTANT_InterfaceMethod_info) constantPool.getItem(index);
			message = method.parent + "::" + method.typeDesc + " " + method.name;
			//message = method.toString();
		}
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
			return null;
		}
		CodeString r = new CodeString(" (", Common_Settings.varUseColor);
		r = r.concate(new CodeString(" " +message, Common_Settings.varUseColor));
		r = r.concate(new CodeString(" )", Common_Settings.varUseColor));
		return r;
	}
	
	CodeString getMessageOfIndices_sub_LocalVar(int indexOfLocalVarInStackFrame) {
		CodeString r = new CodeString(" (", Common_Settings.varUseColor);
		LocalVariableTable_Entry localVar = 
				getLocalVariableTableEntry(indexOfLocalVarInStackFrame);
		if (localVar==null) { // error
			return null;
		}
		
		Field_Info field_Info = new Field_Info();
		field_Info.name = localVar.name;
		field_Info.descriptor = localVar.descriptor;
		FindVarParams var = Field_Info.toFindVarParams(pathClassLoader.compiler, field_Info, null, false);
		var.fieldName = var.fieldName;
		//String message = var.toString();
		
		String message = localVar.descriptor + " " + localVar.name;
		
		r = r.concate(new CodeString(" " +message, Common_Settings.varUseColor));
		r = r.concate(new CodeString(" )", Common_Settings.varUseColor));
		return r;
	}
	
	
	/**디폴트 어드레스와 count가 빅엔디언으로 저장되기 때문에 정확한 패딩바이트 수를 계산해야 한다.
	 * @param i : tableswitch, lookupswitch의 code에서의 인덱스*/
	static int getCountOfPadding_tableswitch(int i, byte[] code) {
		// 패딩을 0이 아닐때까지 읽는다.
		int indexPadding;
		int limit = i+4;
		for (indexPadding=i+1; indexPadding<limit; indexPadding++) {
			if (code[indexPadding]!=0) break;
		}
		
		short countOfPadding = (short) ((indexPadding-1)-(i+1)+1);
		
		byte[] buffer = new byte[4];
		
		int c;
		boolean isReverse = false;
		for (c=0; c<=countOfPadding; c++) {			
			int countOfLabels=0;
			int indexOfDefaultOffset = indexPadding - c;
			Array.copy(code, indexOfDefaultOffset, buffer, 0, buffer.length);
			
			
			int indexOfLow = indexOfDefaultOffset + 4;
			Array.copy(code, indexOfLow, buffer, 0, buffer.length);
			int low = getValueFromBuffer4(buffer, mIsLittleEndianOfSwitch, isReverse);				
			
			int indexOfHigh = indexOfLow + 4;
			Array.copy(code, indexOfHigh, buffer, 0, buffer.length);
			int high = getValueFromBuffer4(buffer, mIsLittleEndianOfSwitch, isReverse);				
							
			countOfLabels = high-low+1;
		
			if (countOfLabels<0 || countOfLabels>500) {
				continue;
			}
			int[] arrLabel = new int[countOfLabels];
	
			
			int m;
			int indexOfOffset = indexOfHigh + 4;
			
			try {
				for (m=0; m<countOfLabels; m++, indexOfOffset+=4) {
					Array.copy(code, indexOfOffset, buffer, 0, buffer.length);
					//int offset = IO.toInt(buffer, mIsLittleEndianOfSwitch);
					int offset = getValueFromBuffer4(buffer, mIsLittleEndianOfSwitch, isReverse);
					arrLabel[m] = offset;
				}
			}catch (Exception e) {
				continue;
			}
			
			
			// defaultAddress + low + high + countOfLabels
			short numOfOtherBytes = (short) (countOfPadding-c+4*(1+2+countOfLabels));
			
			// i는 현재 오프셋이고 1은 tableswitch의 바이트수
			if ((i+1+numOfOtherBytes) % 4!=0) {
				continue;
			}
			return countOfPadding-c;
		}// for (c=0; c<=countOfPadding; c++) {
		return countOfPadding;
	}
	
	
	/**"lookupswitch" (4개이상), "tableswitch" (4개이상), "wide" (3개나 5개) 은 
	 * 가변 인덱스를 갖는다. Code_attribute의 toCodeString()에서 인덱스 개수가 결정된다.<br>
	 * 
	 * tableswitch<br>
	   4+: [0-3 bytes padding],<br> 
	   case의 조건들 : defaultbyte1, defaultbyte2, defaultbyte3, defaultbyte4,<br> 
	   jump offsets : lowbyte1, lowbyte2, lowbyte3, lowbyte4, highbyte1, highbyte2, highbyte3, highbyte4,<br> 
		...<br>
			
		switch (i) {<br>
		      case 0:  return  0;<br>
		      case 1:  return  1;<br>
		      case 2:  return  2;<br>
		      default: return -1;<br>
		}<br>
			<br>
	
		Type Description <br>
		u1   tableswitch opcode = 0xAA (170)<br> 
		-    0-3 bytes of padding ... <br>
		s4   default_offset <br>
		s4   <low> <br>
		s4   <low> + N - 1<br> 
		s4   offset_1 <br>
		s4   offset_2 <br>
		... <br>
		... <br>
		s4   offset_N <br> 
	 * @throws Exception <br>
		* */
	static int processTableSwitch(int i, byte[] code, ByteCodeInstruction instruction) throws Exception {
		int indexInstruction = i;
					
		short countOfPadding = (short) getCountOfPadding_tableswitch(i, code);
		
		instruction.countOfPadding = countOfPadding;
		int k;
		for (k=0; k<countOfPadding; k++) {
			instruction.indices.add(0);
		}
		
		// i+1은 패딩바이트의 시작인덱스
		int indexOfDefaultOffset = (i+1) + countOfPadding;
		
		
		// defaultOffset 부터 low, high, offset들은 모두 little endian으로 읽어야 한다.
		// makeCodePerInstruction()에서 바이트를 쓰므로 참조한다.
		
		// defaultOffset이 256을 초과할 경우
		// 예를들어 316이면 316=256+60=256+32+28=256+32+16+8+4=0000 0001 0011 1100
		byte[] buffer = new byte[4];
		boolean isReverse = false;
		
		int countOfLabels=0;
		Array.copy(code, indexOfDefaultOffset, buffer, 0, buffer.length);
		//int defaultOffset = IO.toInt(buffer, mIsLittleEndianOfSwitch);
		int defaultOffset = getValueFromBuffer4(buffer, mIsLittleEndianOfSwitch, isReverse);				
		
		int indexOfLow = indexOfDefaultOffset + 4;
		Array.copy(code, indexOfLow, buffer, 0, buffer.length);
		//int low = IO.toInt(buffer, mIsLittleEndianOfSwitch);
		int low = getValueFromBuffer4(buffer, mIsLittleEndianOfSwitch, isReverse);				
		
		int indexOfHigh = indexOfLow + 4;
		Array.copy(code, indexOfHigh, buffer, 0, buffer.length);
		//int high = IO.toInt(buffer, mIsLittleEndianOfSwitch);
		int high = getValueFromBuffer4(buffer, mIsLittleEndianOfSwitch, isReverse);				
		
		// 마지막 offset을 제외한다. 마지막 오프셋은 tableswitch다음 명령어와 추가되는 패딩 바이트들로 나뉜다.
		countOfLabels = high-low+1;
		
		int[] arrLabel = new int[countOfLabels];
		
		instruction.indices.add(defaultOffset);
		instruction.indices.add(low);
		instruction.indices.add(high);
		
		int m;
		int indexOfOffset = indexOfHigh + 4;
		
		for (m=0; m<countOfLabels; m++, indexOfOffset+=4) {
			Array.copy(code, indexOfOffset, buffer, 0, buffer.length);
			//int offset = IO.toInt(buffer, mIsLittleEndianOfSwitch);
			int offset = getValueFromBuffer4(buffer, mIsLittleEndianOfSwitch, isReverse);
			arrLabel[m] = offset;
			instruction.indices.add(arrLabel[m]);
		}
		
		
		// indexPadding은 다음 명령어의 시작인덱스이거나 배열의 끝
		// defaultAddress + low + high + countOfLabels
		instruction.numOfOtherBytes = (short) (countOfPadding+4*(1+2+countOfLabels));
		if (instruction.numOfOtherBytes<0) {
			throw new Exception("can't read "+instruction);
		}
		
		i = indexInstruction;
		return i;
	}
	
	
	
	
	/**c가 0일 때는 원래대로 buffer에서 읽고, 1일때는 buffer 인덱스 0과 1번재 바이트들을 바꿔서 읽는다.*/
	static int getValueFromBuffer4(byte[] buffer, boolean isLittleEndian, boolean isReverse) {
		/*if (isReverse==false) {
			return IO.toInt(buffer, isLittleEndian);
		}
		else {
			if (isLittleEndian) {		
				int four =  (int)(((int)buffer[3])<<24 & 0xff000000);
				int three = (int)(((int)buffer[2])<<16 & 0x00ff0000);
				int one =   (int)(((int)buffer[0])<<8  & 0x0000ff00);
				int two =   (int)(((int)buffer[1])     & 0x000000ff);
				// one과 two의 위치를 바꾼다.
				int r = (int) (four | three | one | two );
				return r;
			}
		}
		return -1;*/
		
		return IO.toInt(buffer, isLittleEndian);
	}
	
	/**디폴트 어드레스와 count가 빅엔디언으로 저장되기 때문에 정확한 패딩바이트 수를 계산해야 한다.
	 * @param i : tableswitch, lookupswitch의 code에서의 인덱스*/
	static int getCountOfPadding_lookup(int i, byte[] code) {
		// 패딩을 0이 아닐때까지 읽는다.
		int indexPadding;
		int limit = i+4;
		for (indexPadding=i+1; indexPadding<limit; indexPadding++) {
			if (code[indexPadding]!=0) break;
		}
		
		short countOfPadding = (short) ((indexPadding-1)-(i+1)+1);
		
		byte[] buffer = new byte[4];
		int countOfItems = 0;
		
		int c;
		boolean isReverse = false;
		for (c=0; c<=countOfPadding; c++) {
			
			// i+1은 패딩바이트의 시작인덱스
			int indexOfDefaultOffset = indexPadding - c;
			Array.copy(code, indexOfDefaultOffset, buffer, 0, buffer.length);
			//int defaultOffset = i + IO.toInt(buffer, mIsLittleEndianOfSwitch);
			int defaultOffset = getValueFromBuffer4(buffer, mIsLittleEndianOfSwitch, isReverse);
			
			if (defaultOffset<0 || defaultOffset>40000) {
				// 패딩바이트수가 잘못되어 읽는데 실패했다.
				continue;
			}				
			
			int indexOfCountOfItems = indexOfDefaultOffset + 4;
			Array.copy(code, indexOfCountOfItems, buffer, 0, buffer.length);
			//int countOfItems = IO.toInt(buffer, mIsLittleEndianOfSwitch);
			countOfItems = getValueFromBuffer4(buffer, mIsLittleEndianOfSwitch, isReverse);
			
			
			if (countOfItems<0 || countOfItems>500) {
				// 패딩바이트수가 잘못되어 읽는데 실패했다.
				continue;
			}
			
			int[] arrKeys = new int[countOfItems];
			int[] arrLabel = new int[countOfItems];
			
			int m;
			int indexOfKeys = indexOfCountOfItems + 4;
			try {
				for (m=0; m<countOfItems; m++, indexOfKeys+=8) {
					Array.copy(code, indexOfKeys, buffer, 0, buffer.length);
					//int key = IO.toInt(buffer, mIsLittleEndianOfSwitch);
					int key = getValueFromBuffer4(buffer, mIsLittleEndianOfSwitch, isReverse);
					arrKeys[m] = key;
					
					int indexOfOffset = indexOfKeys + 4;
					Array.copy(code, indexOfOffset, buffer, 0, buffer.length);
					//int offset = IO.toInt(buffer, mIsLittleEndianOfSwitch);
					int offset = getValueFromBuffer4(buffer, mIsLittleEndianOfSwitch, isReverse);
					arrLabel[m] = offset;
				}
			}catch(Exception e) {
				continue;
			}
			
			
			// defaultAddress + countOfItems + countOfItems*(key+offset)
			short numOfOtherBytes = (short) (countOfPadding-c+4*(1+1)+4*2*countOfItems);
			
			// i는 현재 오프셋이고 1은 lookupswitch의 바이트수
			if ((i+1+numOfOtherBytes) % 4 != 0) {
				// 패딩바이트수가 잘못되어 읽는데 실패했다.
				continue;
			}
			else {
				return countOfPadding-c;
			}
		}
		return countOfPadding;
	}
	
	
	static int processLookupSwitch(int i, byte[] code, ByteCodeInstruction instruction) throws Exception {
		int indexInstruction = i;
		
		int indexPadding;
		// 패딩을 0이 아닐때까지 읽는다.
		/*int limit = i+4;
		for (indexPadding=i+1; indexPadding<limit; indexPadding++) {
			if (code[indexPadding]!=0) break;
		}
		
		short countOfPadding = (short) ((indexPadding-1)-(i+1)+1);*/
		
		short countOfPadding = (short) getCountOfPadding_lookup(i, code);
		
		instruction.countOfPadding = countOfPadding;
		int k;
		for (k=0; k<countOfPadding; k++) {
			instruction.indices.add(0);
		}
		
		indexPadding = (i+1) + countOfPadding;
		
		
		byte[] buffer = new byte[4];
		boolean isReverse = false;
		int countOfItems = 0;
		
		// i+1은 패딩바이트의 시작인덱스
		int indexOfDefaultOffset = indexPadding;
		Array.copy(code, indexOfDefaultOffset, buffer, 0, buffer.length);
		//int defaultOffset = i + IO.toInt(buffer, mIsLittleEndianOfSwitch);
		int defaultOffset = getValueFromBuffer4(buffer, mIsLittleEndianOfSwitch, isReverse);
		
		
		int indexOfCountOfItems = indexOfDefaultOffset + 4;
		Array.copy(code, indexOfCountOfItems, buffer, 0, buffer.length);
		//int countOfItems = IO.toInt(buffer, mIsLittleEndianOfSwitch);
		countOfItems = getValueFromBuffer4(buffer, mIsLittleEndianOfSwitch, isReverse);
	
		
		instruction.indices.add(defaultOffset);
		instruction.indices.add(countOfItems);
		
		int[] arrKeys = new int[countOfItems];
		int[] arrLabel = new int[countOfItems];
		
		int m;
		int indexOfKeys = indexOfCountOfItems + 4;
		for (m=0; m<countOfItems; m++, indexOfKeys+=8) {
			Array.copy(code, indexOfKeys, buffer, 0, buffer.length);
			//int key = IO.toInt(buffer, mIsLittleEndianOfSwitch);
			int key = getValueFromBuffer4(buffer, mIsLittleEndianOfSwitch, isReverse);
			arrKeys[m] = key;
			instruction.indices.add(arrKeys[m]);
			
			int indexOfOffset = indexOfKeys + 4;
			Array.copy(code, indexOfOffset, buffer, 0, buffer.length);
			//int offset = IO.toInt(buffer, mIsLittleEndianOfSwitch);
			int offset = getValueFromBuffer4(buffer, mIsLittleEndianOfSwitch, isReverse);
			arrLabel[m] = offset;
			instruction.indices.add(arrLabel[m]);
			
		}
		
		
		// defaultAddress + countOfItems + countOfItems*(key+offset)
		instruction.numOfOtherBytes = (short) (countOfPadding+4*(1+1)+4*2*countOfItems);
		if (instruction.numOfOtherBytes<0) {
			throw new Exception("can't read "+instruction);
		}
		
		i = indexInstruction;
		return i;
	}
	
	
	
	
	static int processVariableInstruction(int i, byte[] code, ByteCodeInstruction instruction) throws Exception {
		if (instruction.mnemonic.equals("tableswitch")) {
			return processTableSwitch(i, code, instruction);
		}
		else if (instruction.mnemonic.equals("lookupswitch")) {
			return processLookupSwitch(i, code, instruction);
		}
		else {
			
		}
		return i;
	}
	
	/** 바이트코드를 읽을 경우 화면에 보여주기위해 Object.toString()을 override 한다.
	 * code 배열의 opcode와 인덱스들을 스트링으로 보여준다.*/
	public HighArray_CodeChar toCodeString(ArrayList constantPool, boolean IsLittleEndian) 
			 throws Exception {
		HighArray_CodeChar r = new HighArray_CodeChar(500);
		//boolean endianBackup = IO.IsLittleEndian;
		int i, j;
		int len = code.length;
		boolean printsMessage = true;
				
		for (i=0; i<this.attributes_count; i++) {
			Attribute_Info attribute = this.attributes[i];
			if (attribute.attribute_name.equals("StackMapTable")) {
				String message = "// " + attribute.stackMapTableAttribute.toString() + "\n";
				r.add(new CodeString(message, Common_Settings.commentColor));
			}
			else if (attribute.attribute_name.equals("LocalVariableTable")) {
				String message = "// " + attribute.localVarTableAttribute.toString() + "\n";
				r.add(new CodeString(message, Common_Settings.commentColor));
			}
		}
		
		//boolean foundSwitch = false;
		for (i=0; i<len; i++) {
			//CompilerHelper.showMessage(true, "Code i : " + i);
			
			
			byte opcodeByte = code[i];
			byte[] arr = {opcodeByte, 0};
			// unsigned byte
			short key = IO.toShort(arr, true);
			ByteCodeInstruction instructionInHash = 
				(ByteCodeInstruction) ByteCode_Types.hashTableInstructionSet.getData(key);
			ByteCodeInstruction instruction = new ByteCodeInstruction(instructionInHash);
			if (instruction.mnemonic.equals("if_icmpne")) {
			}
			
			
			if (instruction.hasVariableIndices() ) {
				
				
				i = processVariableInstruction(i, code, instruction);
				if (i<0) {
					//return r.toCodeString();
					return r;
				}
				
			}//if (instruction.hasVariableIndices() ) {
			else { // 인덱스 개수가 고정개이거나 0개인 경우
				// tableswitch의 다음 명령어 1개 또는 2개가 아닌 경우
				int k;
				// j 는 현재 opcode 의 다음 opcode 의 인덱스이거나 배열의 끝+1
				j = (i+1) + instruction.getLenOfIndices();
				
				for (k=i+1; k<j; k++) {
					byte b = code[k];
					byte[] arr4 = {b, 0};
					// unsigned byte
					short otherByte2 = IO.toShort(arr4, true);
					//IO.IsLittleEndian = backupEndian;
					if (instruction.mnemonic.equals("goto")) {
					}
					instruction.indices.add(otherByte2);
				}
			}//else { // 인덱스 개수가 고정개이거나 0개인 경우
			
			if (instruction.mnemonic.equals("newarray")) {
			}
			
			// 먼저 instruction의 인덱스에 대한 정보를 확인하여
			// 에러가 있을 경우 instruction에 에러가 있다고 전해준다. 
			// Compiler.keywordColor로 instruction의 색깔을 바꾼다.
			// (instruction.toCodeString()을 참조)
			CodeString message = null;
			if (printsMessage) {
				// tableswitch의 다음 명령어 1개 또는 2개가 아닌 경우
				message = this.getMessageOfIndices(instruction, constantPool, IsLittleEndian);
				if (message==null) {
					//instruction.hasError = true;
					//message = new CodeString("Error instruction", Common_Settings.textColor);
					throw new Exception("invalid instruction : "+instruction.toString());
				}
				else {
					instruction.hasError = false;
				}
				
				if (this.exception_table!=null && exception_table.length>0) {
					CodeString exceptionMessage = printExceptionEntry(i, constantPool);
					message = message.concate(exceptionMessage);
				}//if (this.exception_table!=null) {
			}
			
			
			
			// 여기에서 i 는 instruction 의 opcode 의 오프셋
			r.add(new CodeString(Util.getLineOffset(i) + " ", Common_Settings.textColor));
			r.add(instruction.toCodeString());
			r.add(new CodeString("; ", Common_Settings.textColor));
							
			
			r.add(new CodeString(" [", Common_Settings.textColor));
			LineNumber_Entry entry = this.getLineNumberEntry(i);
			try {
				if (entry!=null) {
					r.add(new CodeString(entry.line_number+"", Common_Settings.keywordColor));
				}
			}catch(Exception e) {
				if (Common_Settings.g_printsLog) e.printStackTrace();
			}
			r.add(new CodeString("] //", Common_Settings.textColor));
			
			if (r.count==960) {
			}
			
			
			if (printsMessage && message!=null) {
				r.add(message);
			}
			
			
			r.add(new CodeString("\n", Common_Settings.textColor));
			
			i += instruction.getLenOfIndices();
			
			
			//IO.IsLittleEndian = endianBackup;
			
			
		}//for (i=0; i<code.length; i++) {
		//return r.toCodeString();
		return r;
	}
	
	
	
	CodeString printExceptionEntry(int indexOfCodeArray, ArrayList constantPool) {
		int p;
		CodeString message = new CodeString("", Common_Settings.varUseColor); 
		for (p=0; p<=2; p++) {
			Exception_Entry[] entries = this.getExceptionEntry(indexOfCodeArray, p);
			if (entries!=null && entries.length>0) {
				int m;
				for (m=0; m<entries.length; m++) {
					Exception_Entry entry = entries[m];
					CodeString catchType = null;
					CONSTANT_Class_info classInfo = null;
					if (entry.catch_type==0) {
						classInfo = null;
					}
					else {
						classInfo = (CONSTANT_Class_info) constantPool.getItem(entry.catch_type);
					}
					if (classInfo==null) catchType = new CodeString("finally-handler:", Common_Settings.varUseColor);
					else catchType = new CodeString(classInfo.toString()+"-handler:", Common_Settings.varUseColor);
					catchType = catchType.concate(new CodeString(String.valueOf(entry.handler_pc)+", ",Common_Settings.varUseColor));
					
					if (p==0) { // start_pc, nested 될 수 있다. end_pc보다 항상 작다
						CodeString startOfTry = new CodeString(" Try starts and exception type is ", Common_Settings.varUseColor);
						startOfTry = startOfTry.concate(catchType);
						message = message.concate(startOfTry);
					}
					else if (p==1) { // end_pc, nested 될 수 있다. start_pc보다 항상 크다
						CodeString endOfTry = new CodeString(" Try ends in prev instruction and exception type is ", Common_Settings.varUseColor);
						endOfTry = endOfTry.concate(catchType);
						message = message.concate(endOfTry);
					}
					else if (p==2) { // handler_pc
						CodeString startOfExceptionHandler = new CodeString(" Start Of exception handler ", Common_Settings.varUseColor);
						startOfExceptionHandler = startOfExceptionHandler.concate(catchType);
						message = message.concate(startOfExceptionHandler);
					}								
				}//for (m=0; m<entries.length; m++) {
				return message; // start_pc는 end_pc보다 항상 작으므로 그대로 리턴한다.  
			}//if (entries!=null && entries.length>0) {
		}//for (p=0; p<=2; p++) {
		return message;
	}
	
	

	@Override
	public void destroy() {
		
		if (this.attributes!=null) {
			int i;
			for (i=0; i<this.attributes_count; i++) {
				this.attributes[i].destroy();
				this.attributes[i] = null;
			}
			this.attributes = null;
		}
		if (this.exception_table!=null) {
			int i;
			for (i=0; i<this.exception_table_length; i++) {
				this.exception_table[i].destroy();
				this.exception_table[i] = null;
			}
			this.exception_table = null;
		}
		this.code = null;
	}
}//Code_attribute