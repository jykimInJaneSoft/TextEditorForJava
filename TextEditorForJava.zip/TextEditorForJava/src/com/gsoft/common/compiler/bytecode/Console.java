package com.gsoft.common.compiler.bytecode;

import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.CompilerStatic;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.Compiler_types.FindFunctionParams;
import com.gsoft.common.compiler.Compiler_types.FindVarParams;
import com.gsoft.common.compiler.Compiler_types.FindVarUseParams;
import com.gsoft.common.compiler.Compiler_types_Base.Block;
import com.gsoft.common.compiler.Compiler_types_Base.FindStatementParams;
import com.gsoft.common.compiler.Compiler_types_Special.FindSpecialBlockParams;
import com.gsoft.common.compiler.Compiler_types_Special.FindThreeOperandsOperation;
import com.gsoft.common.compiler.classloader.Loader;
import com.gsoft.common.util.ArrayListIReset;

import com.gsoft.common.compiler.bytecode.ByteCodeGeneratorForClass;
import com.gsoft.common.compiler.bytecode.HighArrayCharForByteCode;
import com.gsoft.common.compiler.bytecode.ByteCode_Physical;
import com.gsoft.common.compiler.bytecode.ByteCode_Types;
import com.gsoft.common.compiler.bytecode.LocalVar;

public class Console {
	
	
	
	public static void callsPrintStackTraceInFakeCatchBlock(ByteCodeGeneratorForClass generator, 
			FindSpecialBlockParams catchBlock, 
			HighArrayCharForByteCode result, int coreThreadID) {
		Compiler compiler = generator.compiler;
		
		FindVarUseParams varUseException = new FindVarUseParams(null);
		varUseException.isFake = false;
		varUseException.varDecl = (FindVarParams) catchBlock.listOfStatementsInParenthesis.getItem(0);
		varUseException.originName = varUseException.varDecl.fieldName;
		varUseException.name = varUseException.originName;
		varUseException.funcToDefineThisVarUse = (FindFunctionParams) catchBlock.parent;
		varUseException.index = varUseException.funcToDefineThisVarUse.endIndex;
		
		
		LocalVar.printLocalVar(generator, varUseException, result, true, coreThreadID);
		
		
		FindVarUseParams varUseFunc = new FindVarUseParams(null);
		varUseFunc.isFake = false;
		varUseFunc.parent = varUseException;
		varUseFunc.index = varUseException.funcToDefineThisVarUse.endIndex;
		
		FindClassParams classParamsOfThrowable = Loader.loadClass(compiler, "java.lang.Throwable", coreThreadID);
		int k;
		FindFunctionParams printStackTraceFunc = null;
		for (k=0; k<classParamsOfThrowable.listOfFunctionParams.count; k++) {
			FindFunctionParams f = (FindFunctionParams) classParamsOfThrowable.listOfFunctionParams.getItem(k);
			if (f.name.equals("printStackTrace")) {
				if (f.listOfFuncArgs.count==0) {
					printStackTraceFunc = f;
					break;
				}
			}
		}
				
		varUseFunc.funcDecl = printStackTraceFunc;
		
		generator.traverseFuncCall(compiler.data.mBuffer, varUseFunc, result, coreThreadID);
		
	}
	
	
	/** main() 메서드 안에서 가짜 try-catch블록을 만든다. 
	 * 발생할 지 모르는 예외를 잡아서 콘솔에 발생한 예외에 대한 메시지를 출력하기 위한 것이다.
	가짜 try-catch블록이란 try-catch가 없는 메서드내에서 예외를 호출함수로 던져주거나 
	try-catch가 없는 synchronized블록에서 예외가 발생할 경우 모니터를 해제하기 위한 것이다.
	현재는 try-catch가 있더라도 가짜 try-catch블록을 만든다.
	(그래도 문제가 안되기 때문에)
	이 경우 Try와 Catch블록은 FindControlBlockParams.nameIndex==null이 되고 
	 * throw문은 FindSpecialStatementParams.kewordIndex==null이 된다.
	 * 이 메서드의 내용을 참조한다.*/
	public static void putTryCatchShieldForFunction(Compiler compiler, FindFunctionParams func) {
		
		ArrayListIReset originalControlBlocks = func.listOfControlBlocks;
		ArrayListIReset originalSpecialBlocks = func.listOfSpecialBlocks;
		ArrayListIReset originalStatements = func.listOfStatements;
		
		FindSpecialBlockParams tryBlock = new FindSpecialBlockParams(compiler, 
				FindSpecialBlockParams.SpecialBlockType_try, 
				func.startIndex()+1, func.endIndex()-1);
		tryBlock.parent = func;
		tryBlock.isFake = true;
		tryBlock.anotherName = ByteCode_Types.TryCatchShieldForConsole;
		compiler.data.mlistOfAllControlBlocks.add(tryBlock);
		
		int i;
		for (i=0; i<originalControlBlocks.count; i++) {
			FindStatementParams statement = (FindStatementParams) originalControlBlocks.getItem(i);
			statement.parent = tryBlock;
			tryBlock.listOfControlBlocks.add(statement);
		}
		originalControlBlocks.count = 0;
		
		for (i=0; i<originalSpecialBlocks.count; i++) {
			FindStatementParams statement = (FindStatementParams) originalSpecialBlocks.getItem(i);
			statement.parent = tryBlock;
			tryBlock.listOfSpecialBlocks.add(statement);
		}
		originalSpecialBlocks.count = 0;
		
		for (i=0; i<originalStatements.count; i++) {
			FindStatementParams statement = (FindStatementParams) originalStatements.getItem(i);
			statement.parent = tryBlock;
			tryBlock.listOfStatements.add(originalStatements.getItem(i));
			if (statement instanceof FindVarParams) {
				tryBlock.listOfVariableParams.add(statement);
			}
		}
		originalStatements.count = 0;
		
		
		for (i=0; i<compiler.data.mlistOfThreeOperandsOperation.count; i++) {
			FindThreeOperandsOperation three = (FindThreeOperandsOperation) compiler.data.mlistOfThreeOperandsOperation.getItem(i);
			if (three.parent==func) {
				three.parent = tryBlock;
			}
			//tryBlock.listOfStatements.add(originalStatements.getItem(i));
		}
		
		
		
		FindSpecialBlockParams catchBlock = new FindSpecialBlockParams(compiler, 
				FindSpecialBlockParams.SpecialBlockType_catch, 
				func.startIndex()+1, func.endIndex()-1);
		catchBlock.parent = func;
		catchBlock.isFake = true;
		catchBlock.tryBlockConnected = tryBlock;
		catchBlock.anotherName = ByteCode_Types.TryCatchShieldForConsole;
		compiler.data.mlistOfAllControlBlocks.add(catchBlock);
		
		FindVarParams var = new FindVarParams(compiler, -1, -1);
		var.typeName = "java.lang.Exception";
		var.fieldName = "e";
		var.isMemberOrLocal = false;
		var.isFake = true;
		var.parent = catchBlock;
		catchBlock.listOfStatementsInParenthesis.add(var);
		catchBlock.listOfVariableParams.add(var);
		
		// catchBlock에 발생한 예외를 출력하는 문장을 넣어야 한다.
		
		
		/*FindSpecialStatementParams throwStatement = new FindSpecialStatementParams(compiler, 
				catchBlock.startIndex()+1, catchBlock.endIndex()-1, -1);
		throwStatement.parent = catchBlock;
		throwStatement.isFake = true;
		catchBlock.listOfStatements.add(throwStatement);*/
		
		Block function = CompilerStatic.getParent(catchBlock);
		function.listOfVariableParams.add(var);
		
		
		tryBlock.indexInListOfControlBlocksOfParent = 0;
		func.listOfControlBlocks.add(tryBlock);
		func.listOfStatements.add(tryBlock);
		
		catchBlock.indexInListOfControlBlocksOfParent = 1;
		func.listOfControlBlocks.add(catchBlock);
		func.listOfStatements.add(catchBlock);
		
		 
	}
	
	
	/** @param mode : 인자없음(1), boolean(2), char(3), char[](4), double(5), float(6), 
	 * int(7), long(8), Object(9), String(10)*/
	public static FindFunctionParams getValueOfFuncFromStringClass(FindClassParams stringClass, int mode) {
		String argTypeName = null;
		switch(mode) {
		case 0: return null;
		case 1: return null;
		case 2: argTypeName = "boolean"; break;
		case 3: argTypeName = "char"; break;
		case 4: argTypeName = "boolean"; break;
		case 5: argTypeName = "double"; break;
		case 6: argTypeName = "float"; break;
		case 7: argTypeName = "int"; break;
		case 8: argTypeName = "long"; break;
		case 9: argTypeName = "Object"; break;
		case 10: argTypeName = "String"; break;
		default: return null;		
		}
		
		int i;
		for (i=0; i<stringClass.listOfFunctionParams.count; i++) {
			FindFunctionParams func = (FindFunctionParams) stringClass.listOfFunctionParams.getItem(i);
			if (func.name.equals("valueOf")) {
				FindVarParams arg = (FindVarParams) func.listOfFuncArgs.getItem(0);
				if (arg.typeName.equals(argTypeName)) {
					return func;
				}
			}
		}
		return null;
	}
	
	/**System.out.println()과 같이 PrintStream에 출력할 때 출력시간을 println(), print()의 파라미터의 뒷부분에 추가해준다.*/
	/*public static void printSystemTimeForConsole(ByteCodeGeneratorForClass generator, FindVarUseParams varUse, HighArrayCharForByteCode result) {
		Compiler compiler = generator.compiler;
		ByteCode_Physical physical = generator.physical;
		int mode = 0;		
		if (varUse.funcDecl.listOfFuncArgs.count>0) {
			FindVarParams arg = (FindVarParams) varUse.funcDecl.listOfFuncArgs.getItem(0);					
			if (arg.typeName.equals("boolean")) {
				mode = 2;
			}
			else if (arg.typeName.equals("char")) {
				mode = 3;
			}
			else if (arg.typeName.equals("char[]")) {
				mode = 4;
			}
			else if (arg.typeName.equals("double")) {
				mode = 5;
			}
			else if (arg.typeName.equals("float")) {
				mode = 6;
			}
			else if (arg.typeName.equals("int")) {
				mode = 7;
			}
			else if (arg.typeName.equals("long")) {
				mode = 8;
			}
			else if (arg.typeName.equals("java.lang.Object")) {
				mode = 9;
			}
			else if (arg.typeName.equals("java.lang.String")) {
				mode = 10;
			}
		}
		else {
			mode = 1;
		}
		printSystemTimeForConsole_sub(generator, result, mode);
		
		FindFunctionParams funcPrint = null;
		FindClassParams classPrintStream = Loader.loadClass(compiler, "java.io.PrintStream");
		int i;
		for (i=0; i<classPrintStream.listOfFunctionParams.count; i++) {
			FindFunctionParams func = (FindFunctionParams) classPrintStream.listOfFunctionParams.getItem(i);
			if (func.name.equals(varUse.name) && func.listOfFuncArgs.count==1) {
				FindVarParams arg = (FindVarParams) func.listOfFuncArgs.getItem(0);
				if (arg.typeName.equals("java.lang.String")) {
					funcPrint = func;
					break;
				}
			}
		}
		
		physical.makeCONSTANT_Method_infoAndPutItIntolistOfConstantTable(funcPrint);
		result.add("invokevirtual // "+funcPrint.getMethodInfoStr()+"\n");
	}*/
	
	/**System.out.println()과 같이 PrintStream에 출력할 때 출력시간을 println(), print()의 파라미터의 뒷부분에 추가해준다.
	 * @param mode : 해당없음(0), 인자없음(1), boolean(2), char(3), char[](4), double(5), float(6), 
	 * int(7), long(8), Object(9), String(10)
	 * @param coreThreadID 
	 * @param compiler */
	public static void printSystemTimeForConsole_sub(ByteCodeGeneratorForClass generator, HighArrayCharForByteCode result, int mode, int srcIndex, int coreThreadID) {
		Compiler compiler = generator.compiler;
		ByteCode_Physical physical = generator.physical;
		
		FindClassParams classString = Loader.loadClass(compiler, "java.lang.String", coreThreadID);
		int i;
		String emptyString = "";
		FindFunctionParams funcValueOf = null;
		
		switch (mode) {
		case 0: break;
		case 1: {
			// CONSTANT_String_info
			// ldc_w의 스트링 상수는 해시테이블에는 "이 없는 스트링이 넣어지고,
			// HighArrayCharForByteCode에는 "이 있는 스트링이 출력된다.			
			physical.makeCONSTANT_String_infoAndPutItIntolistOfConstantTable(emptyString);
			result.add("ldc_w // "+emptyString+"\n");
			break;
		}
		// println(boolean)등에서 boolean 등을 스트링으로 바꿔준다.
		case 2:case 3:case 5:
		case 6:case 7:case 8: 
		case 9: {
			funcValueOf = getValueOfFuncFromStringClass(classString, mode);
			physical.makeCONSTANT_Method_infoAndPutItIntolistOfConstantTable(funcValueOf, coreThreadID);
			result.add("invokestatic // "+funcValueOf.getMethodInfoStr(coreThreadID)+"\n");
			break;
		}
		case 10: break;
		case 4:break;
		default: return;
		}
		
		
		String strTime_head = "\\Time=";
		physical.makeCONSTANT_String_infoAndPutItIntolistOfConstantTable(strTime_head);
		result.add("ldc_w // "+strTime_head+"\n");
		
		// "이전 스트링\Time="이 된다.
		concate(generator, classString, result, srcIndex, coreThreadID);
		
		
		// String.valueOf(long)
		FindFunctionParams funcValueOf_long = getValueOfFuncFromStringClass(classString, 8);
		physical.makeCONSTANT_Method_infoAndPutItIntolistOfConstantTable(funcValueOf_long, coreThreadID);
				
		
		// System.nanoTime()
		FindFunctionParams funcNanoTime = null;
		FindClassParams classSystem = Loader.loadClass(compiler, "java.lang.System", coreThreadID);
		for (i=0; i<classSystem.listOfFunctionParams.count; i++) {
			FindFunctionParams func = (FindFunctionParams) classSystem.listOfFunctionParams.getItem(i);
			if (func.name.equals("nanoTime")) {
				funcNanoTime = func;
				break;
			}
		}
		physical.makeCONSTANT_Method_infoAndPutItIntolistOfConstantTable(funcNanoTime, coreThreadID);
		
		result.add("invokestatic // "+funcNanoTime.getMethodInfoStr(coreThreadID)+"\n");
		
		// String.valueOf(System.nanoTime)
		result.add("invokestatic // "+funcValueOf_long.getMethodInfoStr(coreThreadID)+"\n");
		
		
		// "이전 스트링\Time=XXXXXXXXX"이 된다.
		concate(generator, classString, result, srcIndex, coreThreadID);
		
		String strTime_tail = "\\";
		physical.makeCONSTANT_String_infoAndPutItIntolistOfConstantTable(strTime_tail);
		result.add("ldc_w // "+strTime_tail+"\n");
		
		// "이전 스트링\Time=XXXXXXXXX\"이 된다.
		concate(generator, classString, result, srcIndex, coreThreadID);
	}
	
	/** 오퍼랜드 스택에 StringRef(오브젝트), String(파라미터)이 있을 경우 String.concat()를 호출하는 invokevirtual을 출력한다.
	 * @param coreThreadID */
	static void concate(ByteCodeGeneratorForClass generator, FindClassParams classString, HighArrayCharForByteCode result, int srcIndex, int coreThreadID) {
		//Compiler compiler = generator.compiler;
		ByteCode_Physical physical = generator.physical;
		
		
		FindFunctionParams funcConcate = null;
		int i, j;
		for (j=0; j<2; j++) {
			ArrayListIReset list = null;
			if (j==0) list = classString.listOfFunctionParams;
			else list = classString.listOfFunctionParamsInherited;
			
			for (i=0; i<list.count; i++) {
				FindFunctionParams func = (FindFunctionParams) list.getItem(i);
				if (func.name.equals("concat") && func.listOfFuncArgs.count==1) {
					FindVarParams arg = (FindVarParams) func.listOfFuncArgs.getItem(0);
					if (arg.typeName.equals("java.lang.String")) {
						funcConcate = func;
						break;
					}
				}
			}
			if (funcConcate!=null) break;
		}
		physical.makeCONSTANT_Method_infoAndPutItIntolistOfConstantTable(funcConcate, coreThreadID);
		
		// 이전 파라미터가 스트링인 경우 String.concat(String.valueOf(System.nanoTime))
		result.add("invokevirtual // "+funcConcate.getMethodInfoStr(coreThreadID)+"\n");
	}
	
	
	/** e.printStackTrace()를 e.printStackTrace(System.out)으로 바꿔서 ErrorStream에 출력하던 것을
	 * System.out에 출력해서 에러가 발생할 경우 콘솔 출력이 정상적으로 이루어지도록 한다.
	 * @param generator
	 * @param varUse : printStackTrace
	 * @param result
	 * @param coreThreadID 
	 */
	public static void addsSystemOutToPrintStackTrace(ByteCodeGeneratorForClass generator, 
			FindVarUseParams varUse, HighArrayCharForByteCode result, int coreThreadID) {
		Compiler compiler = generator.compiler;
		ByteCode_Physical physical = generator.physical;
		
		FindClassParams classParamsOfVarUse = Loader.loadClass(compiler, varUse.parent.varDecl.typeName, coreThreadID);
		FindClassParams classParamsOfThrowable = Loader.loadClass(compiler, "java.lang.Throwable", coreThreadID);
		if (classParamsOfVarUse!=null && FindClassParams.isARelation(compiler, classParamsOfThrowable, classParamsOfVarUse, coreThreadID)) {
			FindFunctionParams func = varUse.funcDecl;
			if (func.name.equals("printStackTrace") && func.listOfFuncArgs.count==0) {
				FindVarParams var = new FindVarParams(compiler, -1, -1);
				var.isFake = true;
				var.fieldName = "out";
				var.typeName = "java.io.PrintStream";
				var.parent = Loader.loadClass(compiler, "java.lang.System", coreThreadID);
				var.isMemberOrLocal = true;
				physical.makeCONSTANT_Field_infoAndPutItIntolistOfConstantTable(var, coreThreadID);
				
				result.add("getstatic // "+var.getFieldInfoStr(coreThreadID)+"\n");
				
				int k;
				FindFunctionParams printStackTraceWithPrintStream = null;
				for (k=0; k<classParamsOfThrowable.listOfFunctionParams.count; k++) {
					FindFunctionParams f = (FindFunctionParams) classParamsOfThrowable.listOfFunctionParams.getItem(k);
					if (f.name.equals("printStackTrace")) {
						if (f.listOfFuncArgs.count==1) {
							FindVarParams arg = (FindVarParams) f.listOfFuncArgs.getItem(0);
							if (arg.typeName.equals("java.io.PrintStream")) {
								printStackTraceWithPrintStream = f;
								break;
							}
						}
					}
				}
				
				physical.makeCONSTANT_Method_infoAndPutItIntolistOfConstantTable(printStackTraceWithPrintStream, coreThreadID);
				result.add("invokevirtual // "+printStackTraceWithPrintStream.getMethodInfoStr(coreThreadID)+"\n");
				
				return;
			}
		}
	}
}

	


