package com.gsoft.common.compiler.bytecode;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.CommonGUI;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.compiler.Array;
import com.gsoft.common.compiler.Checker;
import com.gsoft.common.compiler.CodeStringEx;
import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.CompilerStatic;
import com.gsoft.common.compiler.Compiler_types.CategoryOfControls;
import com.gsoft.common.compiler.Compiler_types.FindAssignStatementParams;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.Compiler_types.FindControlBlockParams;
import com.gsoft.common.compiler.Compiler_types.FindFuncCallParam;
import com.gsoft.common.compiler.Compiler_types.FindFunctionParams;
import com.gsoft.common.compiler.Compiler_types.FindIndependentFuncCallParams;
import com.gsoft.common.compiler.Compiler_types.FindVarParams;
import com.gsoft.common.compiler.Compiler_types.FindVarUseParams;
import com.gsoft.common.compiler.Compiler_types_Base.AccessModifier.AccessPermission;
import com.gsoft.common.compiler.Compiler_types_Base.Error;
import com.gsoft.common.compiler.Compiler_types_Base.FindStatementParams;
import com.gsoft.common.compiler.Compiler_types_Special.FindIncrementStatementParams;
import com.gsoft.common.compiler.Compiler_types_Special.FindSpecialBlockParams;
import com.gsoft.common.compiler.Compiler_types_Special.FindSpecialStatementParams;
import com.gsoft.common.compiler.Fullname;
import com.gsoft.common.compiler.HighArray_CodeString;
import com.gsoft.common.compiler.Member;
import com.gsoft.common.compiler.Number;
import com.gsoft.common.compiler.TypeCast_Syntax;
import com.gsoft.common.compiler.bytecode.ByteCode_Types.ByteCodeInstruction;
import com.gsoft.common.compiler.bytecode.ByteCode_Types.HashItemOfConstantTable;
import com.gsoft.common.compiler.bytecode.ThreeOperandsOperation.StartEnd;
import com.gsoft.common.compiler.classloader.Loader;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListChar;
import com.gsoft.common.util.ArrayListIReset;
import com.gsoft.common.util.ArrayListInt;
import com.gsoft.common.util.HighArray_char;
import com.gsoft.common.util.hash.Hashtable2_String;

import com.gsoft.common.compiler.bytecode.ByteCode_Physical;
import com.gsoft.common.compiler.bytecode.HighArrayCharForByteCode;
import com.gsoft.common.compiler.bytecode.TypeCast;
import com.gsoft.common.compiler.bytecode.InstructionSet;
import com.gsoft.common.compiler.bytecode.TypeDescriptor;
import com.gsoft.common.compiler.bytecode.ByteCode_Helper;
import com.gsoft.common.compiler.bytecode.ByteCode_Types;
import com.gsoft.common.compiler.bytecode.LocalVar;
import com.gsoft.common.compiler.bytecode.Synchronized;
import com.gsoft.common.compiler.bytecode.Specials;
import com.gsoft.common.compiler.bytecode.ControlBlock;
import com.gsoft.common.compiler.bytecode.ThreeOperandsOperation;
import com.gsoft.common.compiler.bytecode.EqualOperator;
import com.gsoft.common.compiler.bytecode.Console;
import com.gsoft.common.compiler.bytecode.Enum;

@SuppressWarnings("unused")
public class ByteCodeGeneratorForClass implements Runnable {
	
	/** compiler printing byte codes*/
	Compiler compiler;
	
	/** 바이트코드를 출력할 클래스*/
	FindClassParams classParams;
	
	
	
	/** synchronized에서 return문에서 값을 리턴할때와 배열초기화에서
	 * 인덱스를 사용할때 지역변수를 사용할 지를 결정한다. 디폴트로 false이다.
	 * true로 하면 바이트코드 생성시에 LocalVariableTable Entry의 인덱스를 결정할 수 없다.
	 */
	//boolean usesLocalVarForSynchronizedOrArrayInitializer;	
	
	
	static Hashtable2_String hashTableInstructionSet;
	
	/** 해시테이블을 생성해서 instructionSet 을 테이블에 넣는다. 한번만 초기화 가능*/
	static {
		if (hashTableInstructionSet==null) {
			hashTableInstructionSet = new Hashtable2_String(50, 5);
			int i;
			for (i=0; i<InstructionSet.instructionSet.length; i++) {
				ByteCodeInstruction instruction = InstructionSet.instructionSet[i];
				hashTableInstructionSet.input(instruction.mnemonic, instruction);
			}
		}
	}
	
	

	public ByteCode_Physical physical;

	
	
	/** 사용자가 소스에서 어떤 노드를 클릭할 때마다 새로운 constant table(listOfConstantTable)이 만들어진다.*/
	public void resetHashTablesAndConstantTable(Object node) {
		physical.resetHashTablesAndConstantTable(node);
	}
	
	public void destroy() {
		/*if (this.classParams!=null) {
			this.classParams.destroy();
			this.classParams = null;
		}*/
		physical.destroy();
	}
	
		
	
	
	
	/** @param mlistOfClass : 가장 바깥(inner 가 아닌) 클래스의 리스트*/
	ByteCodeGeneratorForClass(Compiler compiler, FindClassParams classParams, int coreThreadID) {
		this.compiler = compiler;
		this.classParams = classParams;
		this.physical = new ByteCode_Physical(this);
		this.coreThreadID = coreThreadID;
	}
	
	
	
	
	
	/** this.func() 혹은 func() 과 같은 멤버함수 호출일 경우
		invokespecial, invokevirtual 를 하기 전에 먼저 this 를 load 한다.
		static 함수 호출 일경우 invokestatic 을, 
		인스턴스 변수 호출일 경우 invokespecial, invokevirtual을 한다.
	 * @param coreThreadID */
	void printFuncCall(FindVarUseParams varUse, HighArrayCharForByteCode result, int coreThreadID) {
		boolean isStatic = false;
		if (varUse.funcDecl.accessModifier!=null && varUse.funcDecl.accessModifier.isStatic)
			isStatic = true;
		if (varUse.originName.equals("callTouchListener")) {
		}
		if (isStatic) {			
			physical.makeCONSTANT_Method_infoAndPutItIntolistOfConstantTable(varUse, coreThreadID);
			result.add("invokestatic // "+varUse.funcDecl.getMethodInfoStr(coreThreadID)+ByteCode_Helper.getSourceLineNumber(compiler, varUse.index())+"\n");
		}
		else { // invokespecial, invokevirtual
			boolean invokespecial = false;
			// 인스턴스 초기화 메서드를 호출하는 경우
			if (varUse.funcDecl.isConstructor) invokespecial = true;
			// private메서드를 호출하는 경우
			if (varUse.funcDecl.accessModifier!=null && 
				varUse.funcDecl.accessModifier.accessPermission==AccessPermission.Private) 
				invokespecial = true;
			// superclass의 메서드를 호출하는 경우에는  invokespecial이다.
			try {
				if (varUse.name.equals("super") || (varUse.parent!=null && varUse.parent.name.equals("super"))) {
					invokespecial = true;
				}
			}
			catch(Exception e) {
				if (Common_Settings.g_printsLog) e.printStackTrace();
			}
			/*FindClassParams classInvokingFunc = varUse.classToDefineThisVarUse;
			FindClassParams classDefiningFunc = (FindClassParams) varUse.funcDecl.parent;
			if (FindClassParams.isARelation(compiler, classDefiningFunc, classInvokingFunc) &&
					!classInvokingFunc.name.equals(classDefiningFunc.name))
				invokespecial = true;
			*/
			if (invokespecial) {
				physical.makeCONSTANT_Method_infoAndPutItIntolistOfConstantTable(varUse, coreThreadID);
				result.add("invokespecial // "+varUse.funcDecl.getMethodInfoStr(coreThreadID)+ByteCode_Helper.getSourceLineNumber(compiler, varUse.index())+"\n");
				
				// GarbageCollector가 가능하면 newObject()를 호출하여 MemoryManager에 등록한다.
				//FindClassParams classInvokingFunc = varUse.classToDefineThisVarUse;
				//FindClassParams classDefiningFunc = (FindClassParams) varUse.funcDecl.parent;
				
				boolean callsNewObject = true;
				if (varUse.funcDecl.accessModifier!=null && 
						varUse.funcDecl.accessModifier.accessPermission==AccessPermission.Private) 
					callsNewObject = false;
				/*if (FindClassParams.isARelation(compiler, classDefiningFunc, classInvokingFunc) &&
						!classInvokingFunc.name.equals(classDefiningFunc.name))
					callsNewObject = false;
				*/
				if (varUse.name.equals("super") || (varUse.parent!=null && varUse.parent.name.equals("super"))) {
					callsNewObject = false;
				}
				if (callsNewObject) {
					// // superclass의 메서드를 호출하는 경우에는 newObject()를 호출하지 않는다.
					if (Common_Settings.enablesGarbageCollector) {
						result.add("dup // "+ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(compiler, varUse.index())+"\n");
						print_newObject(varUse, result, coreThreadID);
					}
				}
				return;
			}
			
			boolean invokeinterface = false;
			FindClassParams parent = (FindClassParams) varUse.funcDecl.parent;
			if (parent.isInterface) {
				invokeinterface = true;
			}
			
			if (invokeinterface) {
				physical.makeCONSTANT_InterfaceMethod_infoAndPutItIntolistOfConstantTable(varUse, coreThreadID);
				int countOfArgs = varUse.funcDecl.listOfFuncArgs.count;
				if (!varUse.funcDecl.accessModifier.isStatic) {
					countOfArgs++;
				}
				result.add("invokeinterface // "+varUse.funcDecl.getMethodInfoStr(coreThreadID)+", "+countOfArgs+", 0"+ByteCode_Helper.getSourceLineNumber(compiler, varUse.index())+"\n");
				return;
			}
			
			// system time을 덧붙여서 출력해준다.
			/*if (varUse.name.contains("print")) {
				if (varUse.parent.name.equals("out") && varUse.parent.varDecl!=null && 
						varUse.parent.varDecl.typeName.equals("java.io.PrintStream")) {
					Console.printSystemTimeForConsole(this, varUse, result);
					return;
				}
			}// if (varUse.name.contains("print")) {
			*/
			physical.makeCONSTANT_Method_infoAndPutItIntolistOfConstantTable(varUse, coreThreadID);
			result.add("invokevirtual // "+varUse.funcDecl.getMethodInfoStr(coreThreadID)+ByteCode_Helper.getSourceLineNumber(compiler, varUse.index())+"\n");
		}
		
		
	}
	
	
	
	
	
	/** 작은 정수값이 아닌 constant table 에 들어가는 
	 * 더 큰 정수, 실수, 스트링 상수, 문자상수를 출력한다.*/
	void printConstant(FindVarUseParams varUse, HighArrayCharForByteCode result) {
		//if (varUse.constant_info==null) return;
		
		if (varUse.index()==945) {
			int a;
			a=0;
			a++;
		}
				
		// String, int or float : ldc_w
		// double or long : ldc2_w
		if (varUse.name.charAt(0)=='"') {//ldc_w
			// CONSTANT_String_info
			// ldc_w의 스트링 상수는 해시테이블에는 "이 없는 스트링이 넣어지고,
			// HighArrayCharForByteCode에는 "이 있는 스트링이 출력된다.
			// In System.out.println("abc
			//		def");  abc'\n'def  ---> abc'\''n'def
			varUse.name = ByteCode_Helper.convertNewLineCharTo2Chars(varUse.name);
			varUse.originName = varUse.name;
			
			physical.makeCONSTANT_String_infoAndPutItIntolistOfConstantTable(varUse);
			result.add("ldc_w // "+varUse.name+ByteCode_Helper.getSourceLineNumber(compiler, varUse.index())+"\n");
		}
		else if (varUse.name.charAt(0)=='\'') {
			// 문자형 정수 상수
			int unicode = (int)varUse.name.charAt(1);
			if (varUse.name.charAt(1)=='\\') {
				unicode = varUse.name.charAt(2);				
			}
			physical.makeCONSTANT_Number_infoAndPutItIntolistOfConstantTable(unicode);
			result.add("ldc_w // "+unicode+ByteCode_Helper.getSourceLineNumber(compiler, varUse.index())+"\n");			
		}
		else if (Number.IsNumber2(varUse.name)==3) {//ldc_w
			//CONSTANT_Integer_info
			physical.makeCONSTANT_Number_infoAndPutItIntolistOfConstantTable(varUse, 3);
			result.add("ldc_w // "+/*i*/ByteCode_Helper.removeLastCharOfNumber(varUse.name)+ByteCode_Helper.getSourceLineNumber(compiler, varUse.index())+"\n");
		}
		else if (Number.IsNumber2(varUse.name)==5) {//ldc_w
			//CONSTANT_Float_info
			physical.makeCONSTANT_Number_infoAndPutItIntolistOfConstantTable(varUse, 5);
			result.add("ldc_w // "+/*f*/ByteCode_Helper.removeLastCharOfNumber(varUse.name)+ByteCode_Helper.getSourceLineNumber(compiler, varUse.index())+"\n");
		}
		else if (Number.IsNumber2(varUse.name)==6) {//ldc2_w
			//CONSTANT_Double_info
			physical.makeCONSTANT_Number_infoAndPutItIntolistOfConstantTable(varUse, 6);
			result.add("ldc2_w // "+/*d*/ByteCode_Helper.removeLastCharOfNumber(varUse.name)+ByteCode_Helper.getSourceLineNumber(compiler, varUse.index())+"\n");
		}
		else if (Number.IsNumber2(varUse.name)==4) {//ldc2_w
			//CONSTANT_Long_info
			physical.makeCONSTANT_Number_infoAndPutItIntolistOfConstantTable(varUse, 4);
			result.add("ldc2_w // "+/*l*/ByteCode_Helper.removeLastCharOfNumber(varUse.name)+ByteCode_Helper.getSourceLineNumber(compiler, varUse.index())+"\n");
		}
	}
	
	
	/** 다차원배열을 포함한 배열오브젝트 생성시 호출
	 * @param coreThreadID */
	void printNewArray(FindVarUseParams varUse, HighArrayCharForByteCode result, int coreThreadID) {
		int dimension = Array.getArrayDimension(compiler, varUse.name);
		if (dimension>1) {
			String descriptor = null;
			if (CompilerHelper.IsDefaultType(varUse.originName)) {
				descriptor = TypeDescriptor.getDescriptorExceptLAndSemicolon(varUse.originName, coreThreadID);
			}
			else {
				descriptor = TypeDescriptor.getDescriptorExceptLAndSemicolon((FindClassParams)varUse.memberDecl, coreThreadID);
			}
			
			int i;
			String strDimension = "";
			for (i=0; i<dimension; i++) {
				strDimension += "[";
			}
			descriptor = strDimension + descriptor; 
			
			/*if (physical.listOfConstantTableHashed.getData(descriptor)==null) {
				physical.listOfConstantTableHashed.input(descriptor, new HashItemOfConstantTable(descriptor, 6, varUse.index()));
			}*/
			physical.makeCONSTANT_Class_infoAndPutItIntolistOfConstantTable_ExceptLAndSemicolon(descriptor);
			
			
			
			if (CompilerHelper.IsDefaultType(varUse.originName)) {
				result.add("multianewarray // "+descriptor+", "+dimension+ByteCode_Helper.getSourceLineNumber(compiler, varUse.index())+"\n");
			}
			else if (varUse.varDecl!=null) {
				//typeName = ((FindClassParams)varUse.varDecl.parent).name;
				//String typeDesc = TypeDescriptor.getDescriptor((FindClassParams)varUse.varDecl.parent);
				result.add("multianewarray // "+descriptor+", "+dimension+ByteCode_Helper.getSourceLineNumber(compiler, varUse.index())+"\n");
			}
			else if (varUse.memberDecl!=null) {
				result.add("multianewarray // "+descriptor+", "+dimension+ByteCode_Helper.getSourceLineNumber(compiler, varUse.index())+"\n");
			}
			
			
		}
		else {
			String typeName = null;
			if (CompilerHelper.IsDefaultType(varUse.originName)) {
				// newarray는 primitive type의 배열을 생성하므로 constant table에 넣지 않는다.
				// The atype operand of each newarray instruction must take one of the values
				// T_BOOLEAN (4), T_CHAR (5), T_FLOAT (6), T_DOUBLE (7), T_BYTE (8), T_SHORT
				// (9), T_INT (10), or T_LONG (11).
				typeName = varUse.originName;
				String typeDesc = TypeDescriptor.getDescriptor(typeName, coreThreadID);
				result.add("newarray // "+typeDesc+", "+ByteCode_Helper.getAType(typeDesc)+ByteCode_Helper.getSourceLineNumber(compiler, varUse.index())+"\n");
			}
			else if (varUse.varDecl!=null) {
				typeName = ((FindClassParams)varUse.varDecl.parent).name;
				String typeDesc = TypeDescriptor.getDescriptorExceptLAndSemicolon((FindClassParams)varUse.varDecl.parent, coreThreadID);
				physical.makeCONSTANT_Class_infoAndPutItIntolistOfConstantTable_ExceptLAndSemicolon(typeDesc);				
				
				result.add("anewarray // "+typeDesc+ByteCode_Helper.getSourceLineNumber(compiler, varUse.index())+"\n");
			}
			else if (varUse.memberDecl!=null) {
				typeName = ((FindClassParams)varUse.memberDecl).name;
				String typeDesc = TypeDescriptor.getDescriptorExceptLAndSemicolon((FindClassParams)varUse.memberDecl, coreThreadID);
				
				physical.makeCONSTANT_Class_infoAndPutItIntolistOfConstantTable_ExceptLAndSemicolon(typeDesc);
				
				
				result.add("anewarray // "+typeDesc+ByteCode_Helper.getSourceLineNumber(compiler, varUse.index())+"\n");
			}
		}
		
		if (Common_Settings.enablesGarbageCollector) {
			//if (MemoryManager.listOfNewCalls!=null) {
				result.add("dup // "+ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(compiler, varUse.index())+"\n");
				print_newObject(varUse, result, coreThreadID);
			//}
		}
	}
	
	
	
	/** 다차원배열을 포함한 배열오브젝트 생성시 호출*/
	/*void printNewArray_FirstProcess(FindVarUseParams varUse, HighArrayCharForByteCode result) {		
		
		int dimension = Array.getArrayDimension(compiler, varUse.name);
		String elementTypeName = null;
		if (CompilerHelper.IsDefaultType(varUse.originName)) {
			elementTypeName = varUse.originName;
		}
		else {
			elementTypeName = ((FindClassParams)varUse.memberDecl).name;
		}
		elementTypeName = "\""+ elementTypeName+ "\"";
		
		this.physical.makeCONSTANT_String_infoAndPutItIntolistOfConstantTable(elementTypeName);
		
		
		if (CompilerHelper.IsDefaultType(varUse.originName)) {
			result.add("ldc_w // "+elementTypeName+ByteCode_Helper.getSourceLineNumber(compiler, varUse.index())+"\n");
		}
		else if (varUse.varDecl!=null) {
			//typeName = ((FindClassParams)varUse.varDecl.parent).name;
			//String typeDesc = TypeDescriptor.getDescriptor((FindClassParams)varUse.varDecl.parent);
			result.add("ldc_w // "+elementTypeName+ByteCode_Helper.getSourceLineNumber(compiler, varUse.index())+"\n");
		}
		else if (varUse.memberDecl!=null) {
			result.add("ldc_w // "+elementTypeName+ByteCode_Helper.getSourceLineNumber(compiler, varUse.index())+"\n");
		}
		
		
	}*/
	
	/** 다차원배열을 포함한 배열오브젝트 생성시 호출
	 * @param coreThreadID */
	/*void printNewArray_SecondProcess(FindVarUseParams varUse, HighArrayCharForByteCode result) {	
		if (Common_Settings.enablesGarbageCollector) {
			//result.add("dup // "+ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(compiler, varUse.index())+"\n");
			print_newArrayObject(varUse, result);
			int dimension = Array.getArrayDimension(compiler, varUse.name);
			String curType = varUse.originName;
			int i;
			for (i=0; i<dimension; i++) {
				curType += "[]";
			}
			TypeCast.printTypeCast_sub_sub_objectType(this, "java.lang.Object", curType, result, varUse.index());
		}
	}
	
	void print_newArrayObject(FindVarUseParams varUseTypeName, HighArrayCharForByteCode result) {
		FindVarUseParams varUseFunc = new FindVarUseParams(null);
		varUseFunc.isFake = false;
		varUseFunc.index = varUseTypeName.index;
		varUseFunc.originName = "newArrayObject";
		varUseFunc.name = varUseFunc.originName;
		
		int dimension = Array.getArrayDimension(compiler, varUseTypeName.name);
		
		FindClassParams classParamsOfMemoryManager = Loader.loadClass(compiler, "com.gsoft.common.MemoryManager");
		int k;
		FindFunctionParams newObjectFunc = null;
		for (k=0; k<classParamsOfMemoryManager.listOfFunctionParams.count; k++) {
			FindFunctionParams f = (FindFunctionParams) classParamsOfMemoryManager.listOfFunctionParams.getItem(k);
			if (f.name.equals("newArrayObject")) {
				if (f.listOfFuncArgs.count==dimension+1) {
					newObjectFunc = f;
					break;
				}
			}
		}
				
		varUseFunc.funcDecl = newObjectFunc;
		varUseFunc.listOfFuncCallParams = new ArrayListIReset(0);
		
		this.traverseFuncCall(compiler.data.mBuffer, varUseFunc, result);
	}*/
	
	void print_newObject(FindVarUseParams varUseTypeName, HighArrayCharForByteCode result, int coreThreadID) {
		FindVarUseParams varUseFunc = new FindVarUseParams(null);
		varUseFunc.isFake = false;
		varUseFunc.index = varUseTypeName.index;
		varUseFunc.originName = "newObject";
		varUseFunc.name = varUseFunc.originName;
		
		FindClassParams classParamsOfMemoryManager = Loader.loadClass(compiler, "com.gsoft.common.MemoryManager", coreThreadID);
		int k;
		FindFunctionParams newObjectFunc = null;
		for (k=0; k<classParamsOfMemoryManager.listOfFunctionParams.count; k++) {
			FindFunctionParams f = (FindFunctionParams) classParamsOfMemoryManager.listOfFunctionParams.getItem(k);
			if (f.name.equals("newObject")) {
				if (f.listOfFuncArgs.count==1) {
					newObjectFunc = f;
					break;
				}
			}
		}
				
		varUseFunc.funcDecl = newObjectFunc;
		varUseFunc.listOfFuncCallParams = new ArrayListIReset(0);
		
		this.traverseFuncCall(compiler.data.mBuffer, varUseFunc, result, coreThreadID);
	}
	
	
	
	
	
	/** num에 따라 작은 정수(byte, short)의 숫자 타입별로 num을 출력한다.*/
	void printSmallIntegerNumber(int num, HighArrayCharForByteCode result, int mBufferIndex) {
		String strmBufferIndex = ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(compiler, mBufferIndex);
		
		int numberType = Number.IsNumber2(String.valueOf(num));
		switch (num) {
		case 0:	result.add("iconst_0 // "+strmBufferIndex+"\n"); return;
		case 1:	result.add("iconst_1 // "+strmBufferIndex+"\n"); return;
		case 2:	result.add("iconst_2 // "+strmBufferIndex+"\n"); return;
		case 3:	result.add("iconst_3 // "+strmBufferIndex+"\n"); return;
		case 4:	result.add("iconst_4 // "+strmBufferIndex+"\n"); return;
		case 5:	result.add("iconst_5 // "+strmBufferIndex+"\n"); return;
		}
		
		if (numberType==7) {
			result.add("bipush "+num+" // "+strmBufferIndex+"\n");
		}
		else if (numberType==1 || numberType==2) {
			result.add("sipush "+num+" // "+strmBufferIndex+"\n");
		}
	}
	
	
	
	
	
	/** a = i[0][0]; 에서 varUse는 i 이다. 
	 * 여기에서 마지막 첨자가 아닐 경우에는 aaload 를 출력하고 
	 * 마지막 첨자를 처리할 경우에는 iaload, caload 등을 배열원소 타입 별로 출력한다.*/
	void printArrayElement(FindVarUseParams varUse, HighArrayCharForByteCode result, 
			int curDimension, int dimensionOfArray, boolean loadsOrStores) {
		String strmBufferIndex = ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(compiler, varUse.index());
		
		if (loadsOrStores) {
			if (varUse.isArrayElement) {
				if (varUse.varDecl==null && varUse.funcDecl==null) return;
				// int[] func() {}   int i = func()[3]; 여기에서 varUse는 func이다.
				// 즉 varUse는 변수도 될 수 있고 리턴타입이 있는 함수호출도 될 수 있다.
				String typeName = varUse.varDecl!=null ? varUse.varDecl.typeName : varUse.funcDecl.returnType;
				if (typeName==null) return;
				String elementTypeName = Array.getArrayElementType(typeName);
				if (curDimension<dimensionOfArray-1) { 
					// a = i[0][1]; 에서 i[0]는 0번째 행을 말한다.
					result.add("aaload // "+strmBufferIndex+"\n");
				}
				else {
					if (elementTypeName.equals("byte") || elementTypeName.equals("boolean")) {
						result.add("baload // "+strmBufferIndex+"\n");
					}
					else if (elementTypeName.equals("char")) {
						result.add("caload // "+strmBufferIndex+"\n");
					}
					else if (elementTypeName.equals("short")) {
						result.add("saload // "+strmBufferIndex+"\n");
					}
					else if (elementTypeName.equals("int")) {
						result.add("iaload // "+strmBufferIndex+"\n");
					}
					else if (elementTypeName.equals("long")) {
						result.add("laload // "+strmBufferIndex+"\n");
					}
					else if (elementTypeName.equals("float")) {
						result.add("faload // "+strmBufferIndex+"\n");
					}
					else if (elementTypeName.equals("double")) {
						result.add("daload // "+strmBufferIndex+"\n");
					}
					else {
						result.add("aaload // "+strmBufferIndex+"\n");
					}
				}// else
				/*if (varUse.fullnameTypeCast!=null) {
					try {
					printTypeCast(varUse, elementTypeName, varUse.fullnameTypeCast, result);
					}catch(Exception e) {
						int a;
						a=0;
						a++;
					}
				}*/
			}//if (varUse.isArrayElement) {
		}//if (loadsOrStores==true)
		else {
			if (varUse.isArrayElement) {
				if (varUse.varDecl==null || varUse.varDecl.typeName==null) return;
				// store시에 func의 returnType의 배열원소에 값이 저장될 수 없다.
				String elementTypeName = Array.getArrayElementType(varUse.varDecl.typeName);
				if (curDimension<dimensionOfArray-1) { 
					// i[0][1] = a; 에서 i[0]는 0번째 행을 말한다.
					result.add("aastore // "+strmBufferIndex+"\n");
				}
				else {
					if (elementTypeName.equals("byte") || elementTypeName.equals("boolean")) {
						result.add("bastore // "+strmBufferIndex+"\n");
					}
					else if (elementTypeName.equals("char")) {
						result.add("castore // "+strmBufferIndex+"\n");
					}
					else if (elementTypeName.equals("short")) {
						result.add("sastore // "+strmBufferIndex+"\n");
					}
					else if (elementTypeName.equals("int")) {
						result.add("iastore // "+strmBufferIndex+"\n");
					}
					else if (elementTypeName.equals("long")) {
						result.add("lastore // "+strmBufferIndex+"\n");
					}
					else if (elementTypeName.equals("float")) {
						result.add("fastore // "+strmBufferIndex+"\n");
					}
					else if (elementTypeName.equals("double")) {
						result.add("dastore // "+strmBufferIndex+"\n");
					}
					else {
						result.add("aastore // "+strmBufferIndex+"\n");
					}
				}// else
				//varUse.hasPrintedCode = true;
			}//if (varUse.isArrayElement) {
		}
	}
	
	/**var가 초기화되지 않은 변수일 경우 자동 초기화를 해준다.
	 * @param coreThreadID */
	public void initializeMemberVar(FindVarParams var, HighArrayCharForByteCode result, int coreThreadID) {
		if (var.varNameIndex()==175) {
			int a;
			a=0;
			a++;
		}
		
		FindVarUseParams lValue = new FindVarUseParams(null);
		lValue.name = var.fieldName;
		lValue.originName = var.fieldName;
		lValue.index = var.varNameIndex;
		lValue.isFake = true;
		lValue.varDecl = var;
		lValue.classToDefineThisVarUse = (FindClassParams) var.parent;
		
		String strmBufferIndex = ByteCode_Helper.getSourceLineNumber(compiler, var.varNameIndex());
		
		if (!var.accessModifier.isStatic) {
			FindClassParams parentClass = (FindClassParams)lValue.classToDefineThisVarUse;
			String thisStr = TypeDescriptor.getDescriptorOfThis(parentClass, coreThreadID);
			result.add("aload_0 // local "+thisStr+strmBufferIndex+"\n");
		}
		
		if (CompilerHelper.IsDefaultType(var.typeName)) {
			this.printSmallIntegerNumber(0, result, var.varNameIndex());
			TypeCast.printTypeCast(this, "int", var.typeName, result, var.varNameIndex(), coreThreadID);
		}
		else {
			strmBufferIndex = ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(compiler, var.varNameIndex());
			result.add("aconst_null // "+strmBufferIndex+"\n");
		}
		
		
		printMemberVarUse(lValue, result, false, coreThreadID);
	}
	
	
	
	/**object 가 this 이고 getfield 일 경우 this 를 load 한다. 예를들어 aload this; getfield memberVar;  
	 * @param loadOrStore : true일 경우 getfield, getstatic, false일 경우 putstatic, putfield
	 * @param coreThreadID */
	void printMemberVarUse(FindVarUseParams varUse, HighArrayCharForByteCode result, boolean loadOrStore, int coreThreadID) {
		if (varUse.index()==376) {
		}
		String strmBufferIndex = ByteCode_Helper.getSourceLineNumber(compiler, varUse.index());
		String strmBufferIndexWithoutCommaAndBlank = ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(compiler, varUse.index());
		
		boolean isStatic = false;
		if (varUse.varDecl==null) return;
		if (varUse.index()==571) {
		}
		if (varUse.varDecl.accessModifier!=null && varUse.varDecl.accessModifier.isStatic)
			isStatic = true;
		
		physical.makeCONSTANT_Field_infoAndPutItIntolistOfConstantTable(varUse, coreThreadID);
		
		if (loadOrStore) { // getfield, getstatic
			if (isStatic) {
				result.add("getstatic // "+varUse.varDecl.getFieldInfoStr(coreThreadID)+strmBufferIndex+"\n");
			}
			else {
				// this.varName 혹은 varName 과 같은 멤버변수일 경우
				// getfield 를 하기 전에 먼저 this 를 load 한다.
				if (varUse.parent==null && varUse.isUsingThisOrSuper) {					
					FindClassParams parentClass = (FindClassParams)varUse.classToDefineThisVarUse;
					String thisStr = TypeDescriptor.getDescriptorOfThis(parentClass, coreThreadID);
					result.add("aload_0 // local "+thisStr+strmBufferIndex+"\n");
				}
				if (varUse.name.equals("length") && 
					((FindClassParams)varUse.varDecl.parent).name.equals(ByteCode_Types.ArrayFullClassName)) {
					// arr.length의 경우 length는 ByteCode_Types.ArrayFullClassName에 정의되어 있다.					
					result.add("arraylength // "+strmBufferIndexWithoutCommaAndBlank+"\n");
				}
				else {
					// 일반적인 경우
					result.add("getfield // "+varUse.varDecl.getFieldInfoStr(coreThreadID)+strmBufferIndex+"\n");
				}
			}
		}//if (loadOrStore) { // getfield, getstatic
		else {
			if (isStatic) {
				result.add("putstatic // "+varUse.varDecl.getFieldInfoStr(coreThreadID)+strmBufferIndex+"\n");
			}
			else {
				result.add("putfield // "+varUse.varDecl.getFieldInfoStr(coreThreadID)+strmBufferIndex+"\n");
			}
		}
	}
	
	/** 작은 정수 상수 bipush, sipush 를 말한다.
	 * 문자형 정수 상수, short범위를 넘지 않는 문자 상수는 bipush, sipush로 넣는다. 
	  short범위를 넘는 문자상수는 makeCONSTANT_Number_infoAndPutItIntolistOfConstantTable(unicode_value)로 넣는다.*/
	void printSmallIntegerConstant(FindVarUseParams varUse, HighArrayCharForByteCode result) {
		String strmBufferIndex = ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(compiler, varUse.index());
		
		String constant = varUse.originName;
		if (constant.equals("true")) {
			result.add("bipush "+"1 // "+strmBufferIndex+"\n");
			return;
		}
		else if (constant.equals("false")) {
			result.add("bipush "+"0 // "+strmBufferIndex+"\n");
			return;
		}
		
		/*int iConstant = Integer.parseInt(constant);
		switch(iConstant) {
		case -1:	result.add("iconst_m1\n");		return;
		case 0:		result.add("iconst_0\n");		return;
		case 1:		result.add("iconst_1\n");		return;
		case 2:		result.add("iconst_2\n");		return;
		case 3:		result.add("iconst_3\n");		return;
		case 4:		result.add("iconst_4\n");		return;
		case 5:		result.add("iconst_5\n");		return;
		}*/
		
		if (constant.equals("-1")) {
			result.add("iconst_m1 // "+strmBufferIndex+"\n");
			return;
		}
		else if (constant.equals("0")) {
			result.add("iconst_0 // "+strmBufferIndex+"\n");
			return;
		}
		else if (constant.equals("1")) {
			result.add("iconst_1 // "+strmBufferIndex+"\n");
			return;
		}
		else if (constant.equals("2")) {
			result.add("iconst_2 // "+strmBufferIndex+"\n");
			return;
		}
		else if (constant.equals("3")) {
			result.add("iconst_3 // "+strmBufferIndex+"\n");
			return;
		}
		else if (constant.equals("4")) {
			result.add("iconst_4 // "+strmBufferIndex+"\n");
			return;
		}
		else if (constant.equals("5")) {
			result.add("iconst_5 // "+strmBufferIndex+"\n");
			return;
		}
		
		if (constant.charAt(0)=='\'') {
			// 문자형 정수 상수, short범위를 넘지 않는 문자 상수는 bipush, sipush로 넣는다. 
			// short범위를 넘는 문자상수는 makeCONSTANT_Number_infoAndPutItIntolistOfConstantTable(unicode_value)로 넣는다.
			int unicode = (int)varUse.name.charAt(1);
			if (unicode=='\\') {
				// '\'', '\\'
				unicode = (int)varUse.name.charAt(2);
				char c2 = varUse.name.charAt(2);
				if (c2=='n') {
					unicode = '\n';
				}
				else if (c2=='r') {
					unicode = '\r';
				}
				else if (c2=='t') {
					unicode = '\t';
				}
				else if (c2=='b') {
					unicode = '\b';
				}
			}
			constant = String.valueOf(unicode);
		}
		
		int numberType = Number.IsNumber2(constant);
		if (numberType==7) { //byte
			result.add("bipush "+constant+" // "+strmBufferIndex+"\n");
		}
		else if (numberType==1 || numberType==2) {//char, short
			result.add("sipush "+constant+" // "+strmBufferIndex+"\n");
		}		
	}
	
	
	
	
	
	
	
	/** +, -, *, /, mod 등의 산술연산자
	 * @param coreThreadID */
	void printOperator(CodeStringEx operator, HighArrayCharForByteCode result, int coreThreadID) {
		String strmBufferIndex = null;
		if (operator.indicesInSrc==null) {
			int a;
			a=0;
			a++;
		}
		strmBufferIndex = ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(compiler, operator.indicesInSrc.getItem(0));
		if ((operator.equals("+") || operator.equals("-")) && operator.isPlusOrMinusForOne) {
			if (operator.equals("-")) {
				// x가 정수형일 경우 -x = ~x + 1 이다.
				if (operator.typeFullName!=null) {
					if (operator.typeFullName.equals("byte") || operator.typeFullName.equals("char") ||
						operator.typeFullName.equals("short") || operator.typeFullName.equals("int")) {
						result.add("ineg // "+strmBufferIndex+"\n");
						//result.add("iconst_1 // "+strmBufferIndex+"\n");
						//result.add("iadd // "+strmBufferIndex+"\n");
					}
					else if (operator.typeFullName.equals("long")) {
						result.add("lneg // "+strmBufferIndex+"\n");
						//result.add("lconst_1 // "+strmBufferIndex+"\n");
						//result.add("ladd // "+strmBufferIndex+"\n");
					}
					else if (operator.typeFullName.equals("float")) {
						// postfix에서는 -0.4f의 경우 0.4f, - 이렇게 구성이 된다.
						result.add("iconst_m1 // "+strmBufferIndex+"\n");
						result.add("i2f // "+strmBufferIndex+"\n");
						result.add("fmul // "+strmBufferIndex+"\n");
					}
					else if (operator.typeFullName.equals("double")) {
						result.add("iconst_m1 // "+strmBufferIndex+"\n");
						result.add("i2d // "+strmBufferIndex+"\n");
						result.add("dmul // "+strmBufferIndex+"\n");
					}
				}
			}
		}//if ((operator.equals("+") || operator.equals("-")) && operator.isPlusOrMinusForOne) {
		else if ((operator.equals("+") || operator.equals("-") || 
				operator.equals("*") || operator.equals("/") || operator.equals("%")) 
				&& !operator.isPlusOrMinusForOne) { //이항산술연산자		
			if (operator.equals("+")) {
				if (operator.typeFullName!=null) {
					if (operator.typeFullName.equals("byte") || operator.typeFullName.equals("char") ||
						operator.typeFullName.equals("short") || operator.typeFullName.equals("int")) {
						result.add("iadd // "+strmBufferIndex+"\n");
					}
					else if (operator.typeFullName.equals("long")) {
						result.add("ladd // "+strmBufferIndex+"\n");
					}
					else if (operator.typeFullName.equals("float")) {
						result.add("fadd // "+strmBufferIndex+"\n");
					}
					else if (operator.typeFullName.equals("double")) {
						result.add("dadd // "+strmBufferIndex+"\n");
					}
					else if (operator.typeFullName.equals("java.lang.String")) {
					}//else if (operator.typeFullName.equals("java.lang.String")) {
				}
			}//else if (operator.equals("+")) {
			else if (operator.equals("-")) {
				if (operator.typeFullName!=null) {
					if (operator.typeFullName.equals("byte") || operator.typeFullName.equals("char") ||
						operator.typeFullName.equals("short") || operator.typeFullName.equals("int")) {
						result.add("isub // "+strmBufferIndex+"\n");
					}
					else if (operator.typeFullName.equals("long")) {
						result.add("lsub // "+strmBufferIndex+"\n");
					}
					else if (operator.typeFullName.equals("float")) {
						result.add("fsub // "+strmBufferIndex+"\n");
					}
					else if (operator.typeFullName.equals("double")) {
						result.add("dsub // "+strmBufferIndex+"\n");
					}
				}
			}
			else if (operator.equals("*")) {
				if (operator.typeFullName!=null) {
					if (operator.typeFullName.equals("byte") || operator.typeFullName.equals("char") ||
						operator.typeFullName.equals("short") || operator.typeFullName.equals("int")) {
						result.add("imul // "+strmBufferIndex+"\n");
					}
					else if (operator.typeFullName.equals("long")) {
						result.add("lmul // "+strmBufferIndex+"\n");
					}
					else if (operator.typeFullName.equals("float")) {
						result.add("fmul // "+strmBufferIndex+"\n");
					}
					else if (operator.typeFullName.equals("double")) {
						result.add("dmul // "+strmBufferIndex+"\n");
					}
				}
			}
			else if (operator.equals("/")) {
				if (operator.typeFullName!=null) {
					if (operator.typeFullName.equals("byte") || operator.typeFullName.equals("char") ||
						operator.typeFullName.equals("short") || operator.typeFullName.equals("int")) {
						result.add("idiv // "+strmBufferIndex+"\n");
					}
					else if (operator.typeFullName.equals("long")) {
						result.add("ldiv // "+strmBufferIndex+"\n");
					}
					else if (operator.typeFullName.equals("float")) {
						result.add("fdiv // "+strmBufferIndex+"\n");
					}
					else if (operator.typeFullName.equals("double")) {
						result.add("ddiv // "+strmBufferIndex+"\n");
					}
				}
			}
			else if (operator.equals("%")) {
				if (operator.typeFullName!=null) {
					if (operator.typeFullName.equals("byte") || operator.typeFullName.equals("char") ||
						operator.typeFullName.equals("short") || operator.typeFullName.equals("int")) {
						result.add("irem // "+strmBufferIndex+"\n");
					}
					else if (operator.typeFullName.equals("long")) {
						result.add("lrem // "+strmBufferIndex+"\n");
					}
					else if (operator.typeFullName.equals("float")) {
						result.add("frem // "+strmBufferIndex+"\n");
					}
					else if (operator.typeFullName.equals("double")) {
						result.add("drem // "+strmBufferIndex+"\n");
					}
				}
			}
		}//이항산술연산자
		
		else if (operator.equals("<<") || operator.equals(">>") || operator.equals(">>>") ) {
			if (operator.equals("<<")) {
				if (operator.typeFullName!=null) {
					if (operator.typeFullName.equals("byte") || operator.typeFullName.equals("char") ||
						operator.typeFullName.equals("short") || operator.typeFullName.equals("int")) {
						result.add("ishl // "+strmBufferIndex+"\n");
					}
					else if (operator.typeFullName.equals("long")) {
						result.add("lshl // "+strmBufferIndex+"\n");
					}
				}
			}
			else if (operator.equals(">>")) {
				if (operator.typeFullName!=null) {
					if (operator.typeFullName.equals("byte") || operator.typeFullName.equals("char") ||
						operator.typeFullName.equals("short") || operator.typeFullName.equals("int")) {
						result.add("ishr // "+strmBufferIndex+"\n");
					}
					else if (operator.typeFullName.equals("long")) {
						result.add("lshr // "+strmBufferIndex+"\n");
					}
				}
			}
			else if (operator.equals(">>>")) {
				if (operator.typeFullName!=null) {
					if (operator.typeFullName.equals("byte") || operator.typeFullName.equals("char") ||
						operator.typeFullName.equals("short") || operator.typeFullName.equals("int")) {
						result.add("iushr // "+strmBufferIndex+"\n");
					}
					else if (operator.typeFullName.equals("long")) {
						result.add("lushr // "+strmBufferIndex+"\n");
					}
				}
			}
		}// 시프트 연산자
		
		else if (operator.equals("&") || operator.equals("|") || operator.equals("^") ||
				operator.equals("~") ) {
			if (operator.equals("&")) {
				if (operator.typeFullName!=null) {
					if (operator.typeFullName.equals("byte") || operator.typeFullName.equals("char") ||
						operator.typeFullName.equals("short") || operator.typeFullName.equals("int")) {
						result.add("iand // "+strmBufferIndex+"\n");
					}
					else if (operator.typeFullName.equals("long")) {
						result.add("land // "+strmBufferIndex+"\n");
					}
				}
			}
			else if (operator.equals("|")) {
				if (operator.typeFullName!=null) {
					if (operator.typeFullName.equals("byte") || operator.typeFullName.equals("char") ||
						operator.typeFullName.equals("short") || operator.typeFullName.equals("int")) {
						result.add("ior // "+strmBufferIndex+"\n");
					}
					else if (operator.typeFullName.equals("long")) {
						result.add("lor // "+strmBufferIndex+"\n");
					}
				}
			}
			else if (operator.equals("^")) {
				if (operator.typeFullName!=null) {
					if (operator.typeFullName.equals("byte") || operator.typeFullName.equals("char") ||
						operator.typeFullName.equals("short") || operator.typeFullName.equals("int")) {
						result.add("ixor // "+strmBufferIndex+"\n");
					}
					else if (operator.typeFullName.equals("long")) {
						result.add("lxor // "+strmBufferIndex+"\n");
					}
				}
			}
			else if (operator.equals("~")) {
				if (operator.typeFullName!=null) {
					if (operator.typeFullName.equals("byte") || operator.typeFullName.equals("char") ||
						operator.typeFullName.equals("short") || operator.typeFullName.equals("int")) {
						result.add("ineg // "+strmBufferIndex+"\n");
					}
					else if (operator.typeFullName.equals("long")) {
						result.add("lneg // "+strmBufferIndex+"\n");
					}
					else if (operator.typeFullName.equals("float")) {
						result.add("fneg // "+strmBufferIndex+"\n");
					}
					else if (operator.typeFullName.equals("double")) {
						result.add("dneg // "+strmBufferIndex+"\n");
					}
				}
			}
		}// 비트 논리 연산
		
		
		else if (operator.equals("instanceof")) {
			if (operator.affectsRight==null) return;
			FindVarUseParams varUse = (FindVarUseParams) operator.affectsRight.listOfVarUses.
					getItem(operator.affectsRight.listOfVarUses.count-1);
			/*String typeDesc = TypeDescriptor.getDescriptor((FindClassParams)varUse.memberDecl);
			if (physical.listOfConstantTableHashed.getData(typeDesc)==null) {
				physical.listOfConstantTableHashed.input(typeDesc, new HashItemOfConstantTable(typeDesc, 6, varUse.index()));
			}*/
			FindClassParams classParams = (FindClassParams)varUse.memberDecl;
			String typeDesc = TypeDescriptor.getDescriptorExceptLAndSemicolon(classParams, coreThreadID);
			physical.makeCONSTANT_Class_infoAndPutItIntolistOfConstantTable_ExceptLAndSemicolon(typeDesc);
			result.add("instanceof // "+ typeDesc+", "+strmBufferIndex + "\n");
		}
		else if (operator.equals("!")) {
			if (operator.typeFullName.equals("boolean")) {
				result.add("iconst_1 // "+strmBufferIndex+"\n");
				result.add("ixor // "+strmBufferIndex+"\n");
			}
			else {
				// error
				//CompilerStatic.errors.add(new Error(compiler, operator.indicesInSrc.getItem(0), operator.indicesInSrc.getItem(0), "))
			}
		}
		/*if (operator.typeFullNameAfterOperation!=null) {
			if (!TypeCast.abortsTypeFullNameAfterOperation(operator)) {
				TypeCast.printTypeCast_sub(this, null, operator.typeFullName, 
						operator.typeFullNameAfterOperation, result, operator.indicesInSrc.getItem(0));
			}
		}*/
	}
	
	/** printOperator()의 '+'스트링 연결연산자의 오퍼랜드 타입에 따라 그 결과를 출력한다.
	 * @param operator : operator의 타입(opeator.typeFullName)은 java.lang.String이다.*/
	/*void printConcat(CodeStringEx operator, HighArrayCharForByteCode result) {
			
		FindClassParams stringClass = Loader.loadClass(compiler, "java.lang.String");
		
		String classDescriptor = TypeDescriptor.getDescriptor(stringClass);
		
		FindFunctionParams concatFunc = ByteCode_Helper.getConcatFunctionInStringClass(stringClass);
		String nameAndTypeDesc = concatFunc.getFunctionStr();
		String methodInfoStr = classDescriptor + "::" + nameAndTypeDesc;
		
		int srcIndex = operator.indicesInSrc.getItem(0);
		
		if (physical.listOfConstantTableHashed.getData(methodInfoStr)==null) { // CONSTANT_Method_info
			physical.listOfConstantTableHashed.input(methodInfoStr, new HashItemOfConstantTable(methodInfoStr, 8, srcIndex));
		}
		if (physical.listOfConstantTableHashed.getData(classDescriptor)==null) { // CONSTANT_Class_info
			physical.listOfConstantTableHashed.input(classDescriptor, new HashItemOfConstantTable(classDescriptor, 6, srcIndex));
		}
		if (physical.listOfConstantTableHashed.getData(nameAndTypeDesc)==null) { // nameAndTypeDesc
			physical.listOfConstantTableHashed.input(nameAndTypeDesc, new HashItemOfConstantTable(nameAndTypeDesc, 9, srcIndex));
		}
		
		// 두번째 오퍼랜드가 String클래스이거나 그것의 서브클래스일 경우
		// String str = str1+str2;
		// String str = str1+obj; obj는 toString()을 갖고있는 클래스이다.
		// 두번째 오퍼랜드가 toString()을 갖고 있는 클래스일 경우
		// 두번째 오퍼랜드의 toString() 메서드를 호출하고 String의 concat()를 호출한다.
					
		result.add("invokevirtual // "+methodInfoStr+"\n");
	}
	*/
	
	
	
	
	/** 사용자가 함수호출, lValue, 배열원소 등의 varUse를 클릭했을때 
	 * varUse 앞에 있는 일련의 object 들을 출력하기 위해 호출한다. 
	 * @param varUse
	 * @param result
	 * @param isForShowingOrNot : 이 함수는 보여주기 용이 아니더라도 호출이 되기 때문에 
	 * 실제로 컴파일을 할때는 false로 해서 호출해야 한다. 
	 * 그렇지 않으면 varUse 앞에 있는 일련의 object들이 중복되어서 출력된다.
	 * @param coreThreadID 
	 * 
	 */
	void findParentAndPrintThem(FindVarUseParams varUse, HighArrayCharForByteCode result, boolean isForShowingOrNot, int coreThreadID) {
		if (!isForShowingOrNot) return;
		//if (varUse.parent!=null && varUse.parent.hasPrintedCode) return;
		
		if (varUse.parent==null && varUse.isUsingThisOrSuper) {
			FindClassParams parentClass = (FindClassParams)varUse.classToDefineThisVarUse;
			String strmBufferIndex = ByteCode_Helper.getSourceLineNumber(compiler, varUse.index());
			String thisStr = TypeDescriptor.getDescriptorOfThis(parentClass, coreThreadID);
			result.add("aload_0 // local "+thisStr+strmBufferIndex+"\n");
			return;
		}
		// object1.object2.object3.var = i + 2; 이와 같은 경우에
		// object1.object2.object3 들을 object1을 스택에 놓고 getfield 를 해야 한다.
		
		// varUse 의 parent가 null이 될때까지 parent를 찾는다.
		// object1 을 찾는다.
		FindVarUseParams parent = varUse;
		while (true) {
			if (parent.parent==null) break;
			parent = parent.parent;				
		}
		
		// object1.object2.object3 들을 object1을 스택에 놓고 getfield 를 해야 한다.
		// var 는 LValue의 마지막 부분에서 putfield 를 통해 rValue 값을 넣는다.
		FindVarUseParams childLValue = parent;
		while (true) {
			if (childLValue.child==null) break;
			// object.var = i+2; 에서 childLValue 는 object 이다.
			this.traverseExpressionTree(compiler.data.mBuffer, childLValue, result);
			childLValue = childLValue.child;				
		}
	}
	
	FindStatementParams findFindStatementParamsInmlistOfControlBlocks(int indexInmBuffer) {
		int j;
		FindControlBlockParams controlBlock = null;
		for (j=0; j<compiler.data.mlistOfAllControlBlocks.count; j++) {
			controlBlock = (FindControlBlockParams) compiler.data.mlistOfAllControlBlocks.getItem(j);
			if (controlBlock.nameIndex()==indexInmBuffer) return controlBlock;
		}
		return null;
	}
	
	
	
	
	
	/**phyical.processEnumClass()의 wrapper <br> 
	 * classParams이 enum class일 경우 this와 super 필드를 넣고 static과 none-static 생성자가 없으면 그것들을 추가하고
	 * 필드들을 static으로 만든다.
	 * @param classParams : enum
	 */
	void processEnumClass(FindClassParams classParams) {
		Enum.processEnumClass(this, classParams);
	}
	
	
	
	
	
	
	
	/**사용자가 클릭한 클래스, findNode_sub_sub()에서 스레드를 생성하여 호출*/
	FindClassParams input;
	/**printClass()의 바이트코드 결과, findNode_sub_sub()에 리턴된다.*/
	String output;

	
	int coreThreadID;
	
	
	public void run() {
		HighArray_char output = this.printClass(compiler, input, true, coreThreadID);
		CompilerStatic.textViewExpressionTreeAndMessage.initCursorAndScrollPos();
		CompilerStatic.textViewExpressionTreeAndMessage.setText(0, new CodeString(output.getItems(), Common_Settings.textColor));
		CompilerStatic.textViewExpressionTreeAndMessage.setHides(false);
		
		// Compiling YYY 메시지를 닫는다.
		CommonGUI.loggingForMessageBox.setHides(true);
		//Control.view.postInvalidate();		
	}
	
	/**phyical.printClass()의 wrapper <br>
	 * classParams 하나에 대해 클래스파일을 만들고 showsResult 플래그에 의해 화면에 바이트코드를 출력할 지 안할지를 결정한다. 
	 * @param compiler 
	 * @param classParams : 출력할 클래스
	 * @param showsResult : 바이트코드 결과를 화면에 보여주면 true, 아니면 false
	 * @param coreThreadID 
	 * @return
	 */
	HighArray_char printClass(Compiler compiler, FindClassParams classParams, boolean showsResult, int coreThreadID) {		
		this.compiler = compiler;
		return physical.printClass(compiler, classParams, showsResult, coreThreadID);
	}
	
	
	
	void printFunction(FindFunctionParams func, HighArrayCharForByteCode result, int coreThreadID) {
		int i;
		
		// StackMapTable의 엔트리를 출력하기 위해 제어블록이 시작할 때 BlockStart를 출력한다.
		// 그리고 // (mBufferIndex), exit Of Control Block을 활용하여 스택 맵 프레임의 끝을 알 수 있다.
	
		String strIndex = "";
		
		LocalVar.printsLocalVarStart(this, func, result);
		
		
		this.printLocalVarsToIntialize(func, result);
	
		
		if (func.accessModifier!=null && func.accessModifier.isSynchronized) {
			result.add("// synchronized starts"+"\n");
			
			Synchronized.printSynchronizedObjectOfFunction(this, func, result, coreThreadID);
			
			result.add("monitorenter // "+ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(compiler, func.findBlockParams.startIndex())+"\n");
			//Synchronized.print_setBooleanValueToBitMaskArr(this, func, result, true);
		}
		
		
		
		// 현재 함수가 생성자일 경우
		// super()호출이 없으면 super()를 출력한다.
		FindFunctionParams constructor = func;
		if (constructor.isFake) {
			int a;
			a=0;
			a++;
		}
		if (constructor.isConstructor && !constructor.isConstructorThatInitializesStaticFields &&
				!CompilerHelper.hasFuncCallToConstructorOfSuperClass(compiler, constructor)) {
			// 일반 컨스트럭터인데 super(...)을 하지 않은 경우
			// 컴파일러는 super(....)을 넣지 않는다. super()만 넣는다.
			// super()을 출력해야 한다. super가 없으므로 생성자의 functionNameIndex을 대신 넣는다.
			// static 생성자에서는 super()를 출력하지 않는다.
			FindVarUseParams varUseSuper = new FindVarUseParams(constructor.functionNameIndex);
			varUseSuper.name = "super";
			varUseSuper.originName = "super";
			
			varUseSuper.isFake = true;
			FindClassParams parentClass = (FindClassParams) constructor.parent;
			varUseSuper.classToDefineThisVarUse = parentClass;
			varUseSuper.funcToDefineThisVarUse = constructor;			
			
			if (parentClass.isEnum) {
				Enum.printEnumConstructorCall(this, varUseSuper, result, coreThreadID);
			}
			else {
				varUseSuper.listOfFuncCallParams = new ArrayListIReset(1);
				
				varUseSuper.funcDecl = Member.getFunction(compiler, parentClass, varUseSuper, coreThreadID);
				
				if (varUseSuper.funcDecl!=null) {
					physical.makeCONSTANT_Method_infoAndPutItIntolistOfConstantTable(varUseSuper, coreThreadID);						
					this.traverseFuncCall(compiler.data.mBuffer, varUseSuper, result, coreThreadID);
				}
				/*else {
					FindClassParams superClass = parentClass.classToExtend;
					CompilerStatic.errors.add(new Error(superClass.compiler, superClass.classNameIndex(), superClass.classNameIndex(), 
						"Default constructor not exists"));
				}*/
			}
		} // super call
				
		boolean isEnumClass = false;
		FindClassParams parent = null;
		
		if (func.parent instanceof FindClassParams) {
			parent = (FindClassParams) func.parent;
			isEnumClass = parent.isEnum;
		}
		
		
		
		if (isEnumClass && func.isConstructorThatInitializesStaticFields) {
			Enum.printEnumStaticConstructor(this, parent, result, coreThreadID);
		}
		else {
			if (func.listOfVariableParams.count==func.listOfFuncArgs.count) {
				if (func.listOfStatements.count>0) {
					FindStatementParams statement = (FindStatementParams) func.listOfStatements.getItem(0);
					if (statement instanceof FindControlBlockParams) {
						FindControlBlockParams controlBlock = (FindControlBlockParams) statement;
						String controlName = controlBlock.getName();
						if (controlName.equals("for") || controlName.equals("while")) {
							/**
							public static Block getParent(Block block) {
								while (true) {
									if (block instanceof FindFunctionParams) return block;
									if (block instanceof FindClassParams) return block;
									if (block!=null) {
										block = block.parent;
									}
									else {
										return null;
									}
								}
							}
							This must make a stack frame in offset 0.
							So print "nop".
							*/							
							result.add("nop // "+ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(compiler, controlBlock.nameIndex())+"\n");
						}
					}
				}
			}
			for (i=0; i<func.listOfStatements.count; i++) {
				FindStatementParams statement = (FindStatementParams) func.listOfStatements.getItem(i);
				//CommonGUI.showMessage(true, "i="+i+" in "+func);
				
				this.printFindStatementParams(statement, result, coreThreadID);
				// 현재 문장이 throw문이면 뒷 문장들을 출력하지 않는다.
				if (Specials.isThrowOrReturnOrBreakOrContinue(this, statement)) {
					if (i+1<func.listOfStatements.count) {
						FindStatementParams nextStatement = (FindStatementParams) func.listOfStatements.getItem(i+1);
						FindStatementParams lastStatement = (FindStatementParams) func.listOfStatements.getItem(func.listOfStatements.count-1);
						CompilerStatic.errors.add(
							new Error(
									compiler, nextStatement.startIndex(), lastStatement.endIndex(), 
									"Remove statements after throw, return, break or continue."));
					}
					break;
				}
			}
		}
		
		
		
		if (Specials.isLastStatementReturn(this.compiler, func)) {
			// func에서 리턴문으로 끝날 경우 리턴문 앞에서 LocalVarEnd를 출력한다. printReturn()을 참조한다.
			// StackMapTable의 엔트리를 출력하기 위해 제어블록이 시작할 때 BlockStart를 출력한다.
			// 그리고 // (mBufferIndex), exit Of Control Block을 활용하여 스택 맵 프레임의 끝을 알 수 있다.
			LocalVar.printsLocalVarEnd(this, func, result);
			
			if (func.accessModifier!=null && func.accessModifier.isSynchronized) {
				result.add("// synchronized ends"+"\n");
			}
			
			//Synchronized.printMonitorExitInEndOfFunc(this, func, result);
			strIndex = "("+func.findBlockParams.endIndex()+"), ";
			result.add("// "+strIndex+"exit of function\n");
		}
		else {
			// 리턴문이 없이 함수가 끝나는 경우, 예를들어 void 리턴타입 함수
			if (func.accessModifier!=null && func.accessModifier.isSynchronized) {
				// 잠기워진 오브젝트
				Synchronized.printSynchronizedObjectOfFunction(this, func, result, coreThreadID);
				
				result.add("monitorexit // "+ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(compiler, func.findBlockParams.endIndex())+"\n");
				
				//Synchronized.print_setBooleanValueToBitMaskArr(this, func, result, false);
				//Synchronized.printMonitorExitInEndOfFunc(this, func, result);
			}
			
			boolean printedReturn = false;
			if (func.isConstructor || func.returnType==null || func.returnType.equals("") || func.returnType.equals("void")) {
				if (func.findBlockParams!=null) {
					result.add("return // "+ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(compiler, func.findBlockParams.endIndex())+"\n");
				}
				else {
					result.add("return // "+ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(compiler, ((FindClassParams)func.parent).classNameIndex())+"\n");
				}
				printedReturn = true;
			}		
			/*if (!printedReturn && func.isConstructor) {
				if (func.findBlockParams!=null) {
					result.add("return // "+ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(compiler, func.findBlockParams.endIndex())+"\n");
				}
				else {
					result.add("return // "+ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(compiler, ((FindClassParams)func.parent).classNameIndex())+"\n");
				}
				printedReturn = true;
			}*/
			
			if (!printedReturn) {
				returnAutoly(func, result);
			}
			
			// 리턴문이 없으므로 return문을 출력하고 그 뒤에서 LocalVarEnd와 exit of function을 출력한다.
			LocalVar.printsLocalVarEnd(this, func, result);
			
			if (func.accessModifier!=null && func.accessModifier.isSynchronized) {
				result.add("// synchronized ends"+"\n");
			}
			
			// StackMapTable의 엔트리를 출력하기 위해 제어블록이 시작할 때 BlockStart를 출력한다.
			// 그리고 // (mBufferIndex), exit Of Control Block을 활용하여 스택 맵 프레임의 끝을 알 수 있다.
			if (func.findBlockParams!=null) {				
				strIndex = "("+func.findBlockParams.endIndex()+"), ";				
				result.add("// "+strIndex+"exit of function\n");
			}
			else {
				result.add("// "+"exit of function\n");
			}
		}
		
		
		
	}
	
	/** func가 리턴타입은 있고 마지막에서 return문을 가지고 있지 않은 경우에 
	 * return문을 자동으로 출력해준다. 정수형 리턴타입은 0을 오브젝트형은 null을 리턴한다.
	 * @param func
	 * @param result
	 */
	void returnAutoly(FindFunctionParams func, HighArrayCharForByteCode result) {
		String sourceIndex = null;
		if (func.findBlockParams!=null) {
			sourceIndex = ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(compiler, func.findBlockParams.endIndex());
			
		}
		else {
			sourceIndex = ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(compiler, ((FindClassParams)func.parent).classNameIndex());
		}
		if (CompilerHelper.IsDefaultType(func.returnType)) {
			result.add("iconst_0 // "+sourceIndex+"\n");
		}
		else {
			result.add("aconst_null // "+sourceIndex+"\n");
		}
		if (CompilerHelper.IsDefaultType(func.returnType)) {
			if (func.returnType.equals("long")) {
				result.add("i2l // "+sourceIndex+"\n");
				result.add("lreturn // "+sourceIndex+"\n");
			}
			else if (func.returnType.equals("float")) {
				result.add("i2f // "+sourceIndex+"\n");
				result.add("freturn // "+sourceIndex+"\n");
			}
			else if (func.returnType.equals("double")) {
				result.add("i2d // "+sourceIndex+"\n");
				result.add("dreturn // "+sourceIndex+"\n");
			}
			else {
				result.add("ireturn // "+sourceIndex+"\n");
			}
		}
		else {
			result.add("areturn // "+sourceIndex+"\n");
		}
	}
	
	/** initializes local vars moved from block. Refer to LocalVar.processLocalVarsDefinedInBlock()*/
	void printLocalVarsToIntialize(FindFunctionParams func, HighArrayCharForByteCode result) {
		int i;
		for (i=0; i<func.listOfLocalVarsToInitialize.count; i++) {
			FindVarParams localVar = (FindVarParams) func.listOfLocalVarsToInitialize.getItem(i);
			LocalVar.initializeLocalVar(this, localVar, result, coreThreadID);
		}
	}
	
	
	/** statement의 바이트코드를 출력한다.
	 * @param statement : FindAssignStatementParams, FindIndependentFuncCallParams 등의 최소의 문장이다.
	 * try 등을 포함한 제어구조(if, else)가 아니다.
	 * @param coreThreadID 
	 * @param doNotPrintThrowOrReturn : 블록이나 문장 내에서 throw나 return문을 출력하지 못하도록 강제한다. 
	 * printFinally()는 발생한 예외를 throw를 해야 하므로 java.lang.Throwable를 throw를 하기 전에 
	 * throw나 return문을 출력하지 못하도록 강제해야 한다.*/
	void printFindStatementParams(FindStatementParams statement, HighArrayCharForByteCode result, int coreThreadID) {
		try {
		if (statement==null) return;
		
		if (statement.includesInc) {
			// 증감문을 포함하는 문장이면
			this.printStatementIncludingInc(statement, result, coreThreadID);
			return;
		}
		
		if (statement instanceof FindVarParams) {			
			FindVarParams var = (FindVarParams)statement;
			//if (var.isNotInitialized) {
			// int a;와 같은 경우 자동초기화 해준다.
			if (var.varNameIndex()==1970) {
				int a;
				a=0;
				a++;
			}
			if (var.isFake) {
				int a;
				a=0;
				a++;
			}
			if (var.isNotInitialized()/* || var.movedFromBlock*/) {
				/*if (!var.isMemberOrLocal) {
					LocalVar.initializeLocalVar(this, var, result);
				}
				else {
					this.initializeMemberVar(var, result);
				}*/
				if (var.isMemberOrLocal) {
					this.initializeMemberVar(var, result, coreThreadID);
				}
			}
			//result.add("// localVarStart "+/*var.indexOfLocalVarsInFunction*/var.indexOfLocalVariableTable+" "+var+"\n");
		}
		else if (statement instanceof FindFunctionParams) {
			// printClass()에서 function 단위로 바이트코드가 출력되기 때문에 
			// 여기에서 result.add("// BlockStart\n");을 출력할 필요가 없다.
			// result.add("// BlockStart\n");
			FindFunctionParams func = (FindFunctionParams) statement;
			this.printFunction(func, result, coreThreadID);
		}
		else if (statement instanceof FindControlBlockParams) {
			// StackMapTable의 엔트리를 출력하기 위해 제어블록이 시작할 때 BlockStart를 출력한다.
			// 그리고 // (mBufferIndex), exit Of Control Block을 활용하여 스택 맵 프레임의 끝을 알 수 있다.
			
			// BlockStart
			// 461        astore 12          // local Lcom/gsoft/common/gui/Buttons$ButtonGroup; group
	        // localVarStart 12 int i
	        // localVarStart 13 int j
	        // localVarStart 14 int k 
	        // BlockStart
			// 464        bipush            0
			
			
			
			FindControlBlockParams controlBlock = (FindControlBlockParams) statement;
			if (controlBlock.catOfControls!=null) {
				if (controlBlock.catOfControls.category==CategoryOfControls.Control_if) {
					ControlBlock.printIf_ElseIf_Else(this, controlBlock, result, coreThreadID);
				}
				else if (controlBlock.catOfControls.category==CategoryOfControls.Control_elseif) {
					// if문을 처음 만날때 연결된 elseif나 else도 모두 출력한다.
					return;
				}
				else if (controlBlock.catOfControls.category==CategoryOfControls.Control_else) {
					// if문을 처음 만날때 연결된 elseif나 else도 모두 출력한다.
					return;
				}
				else if (controlBlock.catOfControls.category==CategoryOfControls.Control_for) {
					//result.add("// BlockStart\n");
					ControlBlock.printFor(this, controlBlock, result, coreThreadID);
				}
				else if (controlBlock.catOfControls.category==CategoryOfControls.Control_while) {
					//result.add("// BlockStart\n");
					ControlBlock.printWhile(this, controlBlock, result, coreThreadID);
				}
				else if (controlBlock.catOfControls.category==CategoryOfControls.Control_dowhile) {
					//result.add("// BlockStart\n");
					ControlBlock.printDoWhile(this, controlBlock, result, coreThreadID);
				}
				else if (controlBlock.catOfControls.category==CategoryOfControls.Control_switch) {
					//result.add("// BlockStart\n");
					ControlBlock.printSwitch(this, controlBlock, result, coreThreadID);
				}
				/*else if (controlBlock.catOfControls.category==CategoryOfControls.Control_case) {
					this.printCase(controlBlock, result);
				}*/
			}//if (controlBlock.catOfControls!=null) {
			else {
				// try, catch 등
				CodeString keyword = CompilerHelper.getNameOfControlBlock(compiler, controlBlock);
				if (keyword.equals("try")) {
					// this.printTry(controlBlock, result);
					// try문을 처음 만날때 연결된 catch나 finally도 모두 출력한다.
					Specials.printTry_catch_finally(this, controlBlock, result, coreThreadID);
				}
				else if (keyword.equals("catch")) {
					//this.printCatch(controlBlock, result);
					// try문을 처음 만날때 연결된 catch나 finally도 모두 출력한다.
					return;
				}
				else if (keyword.equals("finally")) {
					//this.printFinally(controlBlock, result);
					// try문을 처음 만날때 연결된 catch나 finally도 모두 출력한다.
					return;
				}
				else if (keyword.equals("synchronized")) {
					Synchronized.printSynchronized(this, controlBlock, result, coreThreadID);
				}
			}// try, catch 등
		}//if (statement instanceof FindControlBlockParams) {
		else if (statement instanceof FindSpecialStatementParams) {
			FindSpecialStatementParams specialStatement = (FindSpecialStatementParams) statement;
			CodeString keyword = null;
			if (specialStatement.kewordIndex()!=-1) {
				keyword = compiler.data.mBuffer.getItem(specialStatement.kewordIndex());
			}
			else { // 가짜 try-catch블록의 가짜 throw문
				keyword = new CodeString("throw", Common_Settings.textColor);
			}
			if (keyword.equals("throw")) {
				Specials.printThrow(this, specialStatement, result, coreThreadID);
			}
			else if (keyword.equals("return")) {
				Specials.printReturn(this, specialStatement, result, coreThreadID);
			}
			else {
				
				if (specialStatement.funcCall!=null) {
					this.traverseChild(specialStatement.funcCall, result, coreThreadID);
				}
				ControlBlock.printSpecialStatement(this, specialStatement, result, coreThreadID);
			}
		}
		else if (statement instanceof FindIncrementStatementParams) {
			
			FindIncrementStatementParams inc = (FindIncrementStatementParams) statement;
			FindVarUseParams lValue = inc.lValue;
			String typeName = null;
			
			if (lValue==null) {
			}
			if (lValue.index()==19264) {
			}
			
			typeName = lValue.varDecl.typeName;
					
			if (typeName.equals("int") && lValue.isLocal) {
				// 증감문장이 로컬변수이고 타입이 int일 때만 iinc를 사용한다.
				printIncrementStatement(inc, result, coreThreadID);
				
			}
			else {
				// 증감문이 멤버변수를 증감시키거나 정수형이 아닌 실수형 등일 경우
				FindAssignStatementParams assign = inc.toFindAssignStatementParams();
				
				Compiler compilerBackup = this.compiler;
				this.compiler = assign.rValue.compiler;
				
				this.printFindStatementParams(assign, result, coreThreadID);
				
				this.compiler = compilerBackup;
				//printIncrementStatement(inc, result);
			}
			
		}//else if (statement instanceof FindIncrementStatementParams) {
		else if (statement instanceof FindSpecialStatementParams) {
			
		}//else if (statement instanceof FindSpecialStatementParams) {
		else { // 대입문, 함수호출문 등
			if (statement instanceof FindVarParams) return;
			
			if (statement.startIndex()<92 && 92<statement.endIndex()) {
			}
			
			if (statement.isFake) {
				int a;
				a=0;
				a++;
			}
			
			
			int startIndex = Compiler.getIndexInmListOfAllVarUses(
					compiler.data.mBuffer, compiler.data.mlistOfAllVarUses, 0, statement.startIndex(), true);
			int endIndex = Compiler.getIndexInmListOfAllVarUses(
					compiler.data.mBuffer, compiler.data.mlistOfAllVarUses, startIndex, statement.endIndex(), false);
			traverse(startIndex, endIndex, result);
			
						
			if (statement instanceof FindIndependentFuncCallParams) {
				FindIndependentFuncCallParams IndependentFuncCall = (FindIndependentFuncCallParams) statement;
				int startIndexOfFuncCall = Fullname.getFullNameIndex(compiler, true, IndependentFuncCall.startIndex(), true);
				int newIndex = CompilerHelper.SkipBlank(compiler.data.mBuffer, true, 0, startIndexOfFuncCall-1);
				
				int indexOfFuncCall = Fullname.getFullNameIndex(compiler, false, IndependentFuncCall.startIndex(), true);
				FindVarUseParams varUseFuncCall = 
						CompilerStatic.getVarUseWithIndex(compiler.data.mlistOfAllVarUsesHashed, 
								compiler.data.mBuffer.getItem(indexOfFuncCall).str, indexOfFuncCall);
				if (varUseFuncCall!=null && varUseFuncCall.funcDecl!=null) {
					String returnType = varUseFuncCall.funcDecl.returnType;
					// new RFrame(width,height);
					// 0 new 2     // Test5/Excersize$RFrame, [11]
					// 3 dup       // [11]
					// 4 iload_1       // local I width, 1, I width, [11]
					// 5 iload_2       // local I height, 2, I height, [11]
					// 6 invokespecial 1     // Test5/Excersize$RFrame::(II)V <init>, [11]
					// 9 pop       // [11]
					
					//public ViewEx(Context context) {
					//	super(context);  Don't pop

					if ((varUseFuncCall.funcDecl.isConstructor && compiler.data.mBuffer.getItem(newIndex).equals("new")) ||
							(!varUseFuncCall.funcDecl.isConstructor && returnType!=null && !returnType.equals("void"))) {
						// 스택에서 리턴값을 빼 줘야 한다.						
						String strmBufferIndex = ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(compiler, varUseFuncCall.index());
						if (!(returnType.equals("double") || returnType.equals("long"))) {
							result.add("pop // "+strmBufferIndex+"\n");
						}
						else {
							result.add("pop2 // "+strmBufferIndex+"\n");
						}
					}					
						
				}// if (varUseFuncCall!=null && varUseFuncCall.funcDecl!=null) {
				
			}// if (statement instanceof FindIndependentFuncCallParams) {
		}
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
		}
	}
	
	/**new ProcessBuilder("java", "-jar", "***.jar")와 같은 함수인 경우
		System.out.printf("%d %f", 1, 0.5f)와 같은 함수인 경우 */
	/*void print_printf_ProcessBuilder(FindStatementParams statement, HighArrayCharForByteCode result, int coreThreadID) {
		if (statement instanceof FindIndependentFuncCallParams) {
			FindIndependentFuncCallParams IndependentFuncCall = (FindIndependentFuncCallParams) statement;
			// Finds printf in System.out.printf(...)
			int indexOfFuncCall = Fullname.getFullNameIndex(compiler, false, IndependentFuncCall.startIndex(), true);
			FindVarUseParams varUseFuncCall = 
					CompilerStatic.getVarUseWithIndex(compiler.data.mlistOfAllVarUsesHashed, 
							compiler.data.mBuffer.getItem(indexOfFuncCall).str, indexOfFuncCall);
			if (varUseFuncCall!=null && varUseFuncCall.funcDecl!=null) {
				int argIndexOfArray = Member.funcArgIsArrayAndFuncCallParamsIsElementTypeList(compiler, 
						varUseFuncCall, varUseFuncCall.funcDecl, coreThreadID);
				
				if (argIndexOfArray!=-1) {	
					// new ProcessBuilder("java", "-jar", "***.jar")와 같은 함수인 경우
					// System.out.printf("%d %f", 1, 0.5f)와 같은 함수인 경우
					this.traverseFuncCall_ArrayInitializer(compiler.data.mBuffer, varUseFuncCall, argIndexOfArray, result);
				}
			}
		}
	}*/
	
	
	
	/** f(++iarr[++j]); 이와 같은 증감문들을 해결한다.
	 * @param coreThreadID */
	void printVarUseIncludingInc(FindVarUseParams varUse, HighArrayCharForByteCode result, int typeOfInc, int coreThreadID) {
		if (varUse.index()==326) {
		}
		
		int startIndexInmBuffer=-1;
		int endIndexInmBuffer=-1;
		boolean checksChildInc = true;
		
		if (varUse.isArrayElement) {
			ArrayListIReset arr = varUse.listOfArrayElementParams;
			if (arr.count>0) {
				FindFuncCallParam funcCallStart = (FindFuncCallParam) arr.getItem(0);
				startIndexInmBuffer = funcCallStart.startIndex();
				FindFuncCallParam funcCallEnd = (FindFuncCallParam) arr.getItem(arr.count-1);
				endIndexInmBuffer = funcCallEnd.endIndex();
			}
		}
		if (!varUse.isForVarOrForFunc) {
			ArrayListIReset arr = varUse.listOfFuncCallParams;
			if (arr.count>0) {
				FindFuncCallParam funcCallStart = (FindFuncCallParam) arr.getItem(0);
				startIndexInmBuffer = funcCallStart.startIndex();
				FindFuncCallParam funcCallEnd = (FindFuncCallParam) arr.getItem(arr.count-1);
				endIndexInmBuffer = funcCallEnd.endIndex();
			}
		}
		
		if (startIndexInmBuffer<0) {
			checksChildInc = false;
		}
		
		if (endIndexInmBuffer<0) {
			checksChildInc = false;
		}
		
		if (checksChildInc) {
			int startIndex = Compiler.getIndexInmListOfAllVarUses(
					compiler.data.mBuffer, compiler.data.mlistOfAllVarUses, 0, startIndexInmBuffer, true);
			int endIndex = Compiler.getIndexInmListOfAllVarUses(
					compiler.data.mBuffer, compiler.data.mlistOfAllVarUses, 0, endIndexInmBuffer, false);
			
			int i;
			for (i=startIndex; i<=endIndex; i++) {
				FindVarUseParams v = (FindVarUseParams) compiler.data.mlistOfAllVarUses.getItem(i);
				if (v.inc!=null) {
					// 자식 inc부터 출력
					printVarUseIncludingInc(v, result, typeOfInc, coreThreadID);
				}
			}
		}
		
		// 현재 varUse의 증감문을 출력한다.
		if (typeOfInc==0 || typeOfInc==2) {
			if (varUse.inc.type==0 || varUse.inc.type==2) {
				this.printFindStatementParams(varUse.inc, result, coreThreadID);
			}
		}
		else if (typeOfInc==1 || typeOfInc==3) {
			if (varUse.inc.type==1 || varUse.inc.type==3) {
				this.printFindStatementParams(varUse.inc, result, coreThreadID);
			}
		}
	}
	
	/** f(++iarr[++j]); 이와 같은 증감문들을 해결한다.
	 * @param coreThreadID */
	void printStatementIncludingInc(FindStatementParams statement, HighArrayCharForByteCode result, int coreThreadID) {
		if (statement.startIndex()>=387 && statement.startIndex()<389) {
		}
		
		int startIndex = Compiler.getIndexInmListOfAllVarUses(
				compiler.data.mBuffer, compiler.data.mlistOfAllVarUses, 0, statement.startIndex(), true);
		int endIndex = Compiler.getIndexInmListOfAllVarUses(
				compiler.data.mBuffer, compiler.data.mlistOfAllVarUses, 0, statement.endIndex(), false);
		
		int i;
		// ++iarr[++j] 를 해결한다.
		for (i=startIndex; i<=endIndex; i++) {
			FindVarUseParams varUse = (FindVarUseParams) compiler.data.mlistOfAllVarUses.getItem(i);
			if (varUse.inc!=null) {
				printVarUseIncludingInc(varUse, result, 0, coreThreadID);
				i = this.jump(varUse, i);
			}
		}
		
		// f(++iarr[++j]); 문장을 출력한다.
		statement.includesInc = false;
		this.printFindStatementParams(statement, result, coreThreadID);
		statement.includesInc = true;
		
		// iarr[j++]++ 를 해결한다.
		for (i=startIndex; i<=endIndex; i++) {
			FindVarUseParams varUse = (FindVarUseParams) compiler.data.mlistOfAllVarUses.getItem(i);
			if (varUse.inc!=null) {
				printVarUseIncludingInc(varUse, result, 1, coreThreadID);
				i = this.jump(varUse, i);
			}
		}
	}
	
	
	/** 사용자가 조건문(if문을 제외한 else if에 대해서만 호출한다.)안의 varUse를 클릭했을때 
	 * statement의 바이트코드를 출력한다.
	 * 보여주기용이므로 printFindStatementParams()와 구별한다. 실제로 컴파일을 할 때는
	 * printFindStatementParams()을 써야 한다.
	 * @param statement : FindAssignStatementParams, FindIndependentFuncCallParams 등의 최소의 문장이다.
	 * try 등을 포함한 제어구조(if, else)가 아니다.
	 * @param coreThreadID */
	void printFindStatementParams_findNode(FindStatementParams statement, HighArrayCharForByteCode result, int coreThreadID) {
		if (statement==null) return;
		
		if (statement.includesInc) {
			printFindStatementParams(statement, result, coreThreadID);
			return;
		}
		
		String strIndex = "";
		
		//HighArrayCharForByteCode result = null;
		if (statement instanceof FindControlBlockParams) {
			FindControlBlockParams controlBlock = (FindControlBlockParams) statement;
			
			if (controlBlock.catOfControls==null) {
				// try, catch, synchronized 등
				FindSpecialBlockParams special = (FindSpecialBlockParams) controlBlock;
				String keyword = special.getName();
				if (keyword.equals("try")) {
					//this.printTry(controlBlock, result);
					this.printFindStatementParams(controlBlock, result, coreThreadID);
				}
				else if (keyword.equals("catch")) {
					Specials.printCatch(this, controlBlock, result, coreThreadID);
				}
				else if (keyword.equals("finally")) {
					Specials.printFinally(this, controlBlock, result, coreThreadID);
				}
				else { // synchronized 등
					this.printFindStatementParams(controlBlock, result, coreThreadID);
				}
			}//if (controlBlock.catOfControls==null) {
			else {
				if (controlBlock.catOfControls.category==CategoryOfControls.Control_if) {
					//result = new HighArrayCharForByteCode(100);
					//result.resizeInc = 300;				
					ControlBlock.printIfControlBlock(this, controlBlock, result, coreThreadID);				
					if (ControlBlock.if_elseEnds(controlBlock)) {
						// if문의 끝나는 영역
						strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)2, null);
						result.add("// "+strIndex+"exit"+" of "+controlBlock+"\n");
						strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)3, null);
						result.add("// "+strIndex+"exit of if-elseif-else"+"\n");
					}
					else { // if-elseif-else에서 if나 else if구조가 끝났을 때
						//strIndex = this.ByteCode_Helper.getStringOfmBufferIndex(controlBlock, (byte)3);
						//result.add("goto_w "+"// "+strIndex+"exit of if-elseif-else"+"\n");						
						// if문의 끝나는 영역
						strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)2, null);
						result.add("// "+strIndex+"exit"+" of "+controlBlock+"\n");
					}
				}
				else if (controlBlock.catOfControls.category==CategoryOfControls.Control_elseif) {
					//result = new HighArrayCharForByteCode(100);
					//result.resizeInc = 300;
					ControlBlock.printIfControlBlock(this, controlBlock, result, coreThreadID);
					if (ControlBlock.if_elseEnds(controlBlock)) {
						// else if문의 끝나는 영역
						strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)2, null);
						result.add("// "+strIndex+"exit"+" of "+controlBlock+"\n");
						strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)3, null);
						result.add("// "+strIndex+"exit of if-elseif-else"+"\n");					
					}
					else {// if-elseif-else에서 if나 else if구조가 끝났을 때
						//strIndex = this.ByteCode_Helper.getStringOfmBufferIndex(controlBlock, (byte)3);
						//result.add("goto_w "+"// "+strIndex+"exit of if-elseif-else"+"\n");
						// else if문의 끝나는 영역
						strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)2, null);
						result.add("// "+strIndex+"exit"+" of "+controlBlock+"\n");
					}
				}
				else if (controlBlock.catOfControls.category==CategoryOfControls.Control_else) {
					//result = new HighArrayCharForByteCode(100);
					//result.resizeInc = 300;
					ControlBlock.printElseControlBlock(this, controlBlock, result, coreThreadID);
					if (ControlBlock.if_elseEnds(controlBlock)) {
						strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)3, null);
						result.add("// "+strIndex+"exit of if-elseif-else"+"\n");					
					}
					else {// if-elseif-else에서 if나 else if구조가 끝났을 때
						//strIndex = this.ByteCode_Helper.getStringOfmBufferIndex(controlBlock, (byte)3);
						//result.add("goto_w "+"// "+strIndex+"exit of if-elseif-else"+"\n");
					}
				}
				else { // if, else if, else 등을 제외한 제어구조, for, while 등
					printFindStatementParams(statement, result, coreThreadID);
				}
			}// controlBlock.catOfControls!=null
		}//if (statement instanceof FindControlBlockParams) {
		else if (statement instanceof FindSpecialStatementParams) {
			printFindStatementParams(statement, result, coreThreadID);
		}
		else {
			printFindStatementParams(statement, result, coreThreadID);
		}
	}
	
	/**@param startIndex : mlistOfAllVarUses에서의 시작 인덱스
	 * @param endIndex : mlistOfAllVarUses에서의 끝 인덱스*/
	void traverse(int startIndex, int endIndex, HighArrayCharForByteCode result) {
		int i;
		for (i=startIndex; i<=endIndex; i++) {
			FindVarUseParams varUse = (FindVarUseParams) compiler.data.mlistOfAllVarUses.getItem(i);
			if (varUse.index()==551) {
				int a;
				a=0;
				a++;
			}
			if (varUse.rValue!=null) { // lValue
				this.traverseExpressionTree(compiler.data.mBuffer, varUse, result);
				i = jump(varUse, i);
			}
			else if (varUse.funcDecl!=null) {
				this.traverseExpressionTree(compiler.data.mBuffer, varUse, result);
				i = jump(varUse, i);
			}
			else if (varUse.isArrayElement) {
				this.traverseExpressionTree(compiler.data.mBuffer, varUse, result);
				i = jump(varUse, i);
			}
			else if (varUse.typeCast!=null && varUse.typeCast.affectsExpression) {
				this.traverseExpressionTree(compiler.data.mBuffer, varUse, result);
				i = jump(varUse, i);
			}
			else {
				this.traverseExpressionTree(compiler.data.mBuffer, varUse, result);
			}
		}
	}
	
	
	
	
	
	
	
	
	
	/** 증감문이 지역변수이고 타입이 int일때만 iinc를 출력하고, 
	 * 배열이나 멤버변수 혹은 정수형이 아닌 실수형일 경우에는 
	 * 타입에 따라 1을 로드하고 add를 출력한다.
	 * @param coreThreadID */
	void printIncrementStatement(FindIncrementStatementParams statement, HighArrayCharForByteCode result, int coreThreadID) {
		FindVarUseParams lValue = statement.lValue;
		String typeName = lValue.varDecl.typeName;
		
		if (lValue.index()==1096) {
		}
				
		/*if (lValue.varDecl.sharedVar!=null) {
			lValue.varDeclBeforeProcessLocalVars = lValue.varDecl; 
			lValue.varDecl = lValue.varDecl.sharedVar;
		}*/
		int index = LocalVar.getLocalVarTableIndex(this, lValue.funcToDefineThisVarUse, lValue.varDecl);
		if (typeName.equals("int") && lValue.isLocal) {
			// 지역변수이고 타입이 int일 때만
			if (statement.type==0 || statement.type==1) {
				result.add("iinc "+index+" 1 // local "+lValue.varDecl.getVarStr(coreThreadID)+ByteCode_Helper.getSourceLineNumber(compiler, lValue.index())+"\n");
			}
			else {
				result.add("iinc "+index+" -1 // local "+lValue.varDecl.getVarStr(coreThreadID)+ByteCode_Helper.getSourceLineNumber(compiler, lValue.index())+"\n");
			}
		}
		else {
			typeName = Array.getArrayElementType(typeName);
			
			if (statement.type==0 || statement.type==1) {
				if (typeName.equals("int")) {
					result.add("iconst_1 // "+ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(compiler, lValue.index())+"\n");
					result.add("iadd // "+ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(compiler, lValue.index())+"\n");
					result.add("istore_"+index+" // local "+lValue.varDecl.getVarStr(coreThreadID)+ByteCode_Helper.getSourceLineNumber(compiler, lValue.index())+"\n");
				}
				else if (typeName.equals("long")) {
					result.add("lconst 1 // "+ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(compiler, lValue.index())+"\n");
					result.add("ladd // "+ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(compiler, lValue.index())+"\n");
					result.add("lstore_"+index+" // local "+lValue.varDecl.getVarStr(coreThreadID)+ByteCode_Helper.getSourceLineNumber(compiler, lValue.index())+"\n");
				}
				else if (typeName.equals("float")) {
					result.add("fconst 1 // "+ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(compiler, lValue.index())+"\n");
					result.add("fadd // "+ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(compiler, lValue.index())+"\n");
					result.add("fstore_"+index+" // local "+lValue.varDecl.getVarStr(coreThreadID)+ByteCode_Helper.getSourceLineNumber(compiler, lValue.index())+"\n");
				}
				else if (typeName.equals("double")) {
					result.add("dconst 1 // "+ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(compiler, lValue.index())+"\n");
					result.add("dadd // "+ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(compiler, lValue.index())+"\n");
					result.add("dstore_"+index+" // local "+lValue.varDecl.getVarStr(coreThreadID)+ByteCode_Helper.getSourceLineNumber(compiler, lValue.index())+"\n");
				}
			}
		}
	}
	
	
	
	
	static class ReturnOfGetCountOfSynchronizedAndFinallyJustBeforeCatch {
		
		/**throw가 던지는 예외가 catch되기 전에(혹은 return되기 전에)
		 synchronized의 개수를 세어 오브젝트 잠금을 몇 번 해제를 해야 하는지를 얻는다.*/
		int countOfSynchronized = 0;
		/**synchronized의 스택에서의 위치를 알 수 있는 loopCount들의 리스트*/
		ArrayListInt listOfLoopCountsOfSynchronized = null;
		
		ArrayList listOfSynchronizedBlocks = null;
		
		/**throw문이 실행될 때(혹은 return되기 전에) 먼저 실행되어야 할 finally절, 
		 * FindControlBlockParams[]*/
		ArrayList listOfFinallyBlocks = null;
		//int loopCountOfFinally = -1;
		/**listOfFinallyBlocks에 들어있는 finally블록들의 스택에서의 위치 리스트*/
		ArrayListInt listOfLoopCountsOfFinally = null;
		
		/**throw문일 경우 throw가 catch되는 블록, catch가 안되면 null이다.
		 * return문일 경우 null이다.*/
		FindControlBlockParams catchBlock = null;
		/**throw문이 catch될 경우 스택상에서의 catch의 위치, 
		 * loopCountOfCatch가 -1이면 catch가 되지 않는다는 것이거나 
		 * return문에서와 같이 catch가 의미가 없다는 것이다.
		 * throw문에서는 반드시 어디에서 던져진 예외가 catch되는지를 알기 위해서 catch가 체크된다.
		 * getCountOfSynchronizedAndFinallyJustBeforeCatch()을 참조한다.
		 * throw문과 return문을 구별한다.*/
		int loopCountOfCatch = -1;
	}
	
	
	
	
	
	
	
	/** varUse가 lValue, 함수호출, 배열원소, 아니면 수식 타입캐스트이면 그 다음으로 점프하는 
	 * compiler.mlistOfAllVarUses 상의 인덱스를 리턴한다.
	 * @param varUse
	 * @param indexInmlistOfAllVarUses
	 * @return
	 */
	int jump(FindVarUseParams varUse, int indexInmlistOfAllVarUses) {
		if (varUse.rValue!=null) {
			int endIndex = Compiler.getIndexInmListOfAllVarUses(
					compiler.data.mBuffer, compiler.data.mlistOfAllVarUses, indexInmlistOfAllVarUses, varUse.rValue.endIndex(), false);
			return endIndex;
		}
		if (varUse.funcDecl!=null) {
			int leftParenthesis = 
					CompilerHelper.SkipBlank(compiler.data.mBuffer, false, varUse.index()+1, compiler.data.mBuffer.count-1);
			int rightParenthesis =
					Checker.CheckParenthesis(compiler, "(", ")", leftParenthesis, compiler.data.mBuffer.count-1, false);
			
			int endIndex = -1;
			if (!varUse.isArrayElement) {
				endIndex = Compiler.getIndexInmListOfAllVarUses(
					compiler.data.mBuffer, compiler.data.mlistOfAllVarUses, indexInmlistOfAllVarUses, rightParenthesis, false);
			}
			else {
				// if (settings.getSelectedColor()[1]==0) {
				// func()[0].intValue(); varUse is func
				//int endOfFullnameIndex = Fullname.getFullNameIndex(compiler, false, varUse.index(), false);
				int endIndexInmBuffer = Fullname.hasAND(compiler, false, varUse.index(), false);
				endIndex = Compiler.getIndexInmListOfAllVarUses(
						compiler.data.mBuffer, compiler.data.mlistOfAllVarUses, indexInmlistOfAllVarUses, endIndexInmBuffer, false);
			}
			return endIndex;			
		}
		if (varUse.isArrayElement) {
			int dimension = Array.getArrayDimension(compiler, varUse.name);
			int k;
			int leftParenthesis=-1;
			int rightParenthesis=-1;
			int mBufferIndex = varUse.index()+1;
			for (k=0; k<dimension; k++) {
				leftParenthesis = 
						CompilerHelper.SkipBlank(compiler.data.mBuffer, false, mBufferIndex, compiler.data.mBuffer.count-1);
				rightParenthesis =
						Checker.CheckParenthesis(compiler,  "[", "]", leftParenthesis, compiler.data.mBuffer.count-1, false);
				mBufferIndex = rightParenthesis+1;
			}
			
			int endIndex = Compiler.getIndexInmListOfAllVarUses(
					compiler.data.mBuffer, compiler.data.mlistOfAllVarUses, indexInmlistOfAllVarUses, rightParenthesis, false);
			return endIndex;			
		}
		if (varUse.typeCast!=null/* && varUse.typeCast.affectsExpression*/) {
			TypeCast_Syntax typeCast = varUse.typeCast;			
			//return typeCast.endIndexToAffect_mlistOfAllVarUses;
			
			// 타입캐스트되는 varUser가 함수호출, lValue, 배열원소일 경우 이미 수식을 출력했으므로
			// 다시 점프한다.
			FindVarUseParams varUseTypeCasted = 
					(FindVarUseParams) compiler.data.mlistOfAllVarUses.getItem(typeCast.endIndexToAffect_mlistOfAllVarUses);
			int r = this.jump(varUseTypeCasted, typeCast.endIndexToAffect_mlistOfAllVarUses);
			return r;
		}
		return indexInmlistOfAllVarUses;
	}
	
	
	
	
	
	
	
	/** token이 '+'의 첫번째 오퍼랜드이고 타입이 java.lang.String이거나 서브클래스이고 스트링 상수이면
	 * java.lang.String오브젝트를 생성하고 
	 * token이 '+'의 두번째 오퍼랜드이고 타입이 java.lang.String이거나 서브클래스이고 스트링 상수이면
	 * 마찬가지로 java.lang.String오브젝트를 생성하고 
	 * token이 '+'의 두번째 오퍼랜드이고 타입이 디폴트타입이면 그 타입에 따라 value 클래스를 생성한다.
	 * @param coreThreadID */
	void printFirstProcessInConcatOperator(CodeStringEx token, HighArrayCharForByteCode result, int coreThreadID) {
		int srcIndex = token.indicesInSrc.getItem(0);
		String strmBufferIndex = ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(compiler, srcIndex);
		
		// str+1+str2
		//        +
		//	  +		str2
		// str  1
		// 에서 토큰이 str일 경우에만 호출이 되도록 한다.
		FindClassParams classStringBuilder = Loader.loadClass(compiler, "java.lang.StringBuilder", coreThreadID);
		ArrayListChar message = new ArrayListChar(30);
		message.add("new // ");
		message.add(TypeDescriptor.getDescriptorExceptLAndSemicolon(classStringBuilder, coreThreadID)+
				ByteCode_Helper.getSourceLineNumber(compiler, srcIndex));
		message.add("\n");
		result.add(new String(message.getItems()));
		result.add("dup // "+strmBufferIndex+"\n");
		
		// java.lang.StringBuilder의 인자가 없는 <init>()를 호출한다.
		FindFunctionParams constructorOfStringBuilder = 
				ByteCode_Helper.getConstructorOfStringBuilder(compiler, null, srcIndex, coreThreadID);
		physical.makeCONSTANT_Method_infoAndPutItIntolistOfConstantTable(constructorOfStringBuilder, coreThreadID);						
		
		result.add("invokespecial // "+constructorOfStringBuilder.getMethodInfoStr(coreThreadID)+
				ByteCode_Helper.getSourceLineNumber(compiler, srcIndex)+"\n");
	}
	
	/**Calls constructor of classValueObject. For example, Integer(int), Float(float)*/
	void printNewValueObject_firstPassing(String fullnameOfValueObject, HighArrayCharForByteCode result, int coreThreadID, int mBufferIndexOfSrc) {
		if (CompilerHelper.IsDefaultType(fullnameOfValueObject)) {
			if (fullnameOfValueObject.equals("int")) fullnameOfValueObject = "java.lang.Integer";
			else if (fullnameOfValueObject.equals("byte")) fullnameOfValueObject = "java.lang.Byte";
			else if (fullnameOfValueObject.equals("short")) fullnameOfValueObject = "java.lang.Short";
			else if (fullnameOfValueObject.equals("char")) fullnameOfValueObject = "java.lang.Character";
			else if (fullnameOfValueObject.equals("float")) fullnameOfValueObject = "java.lang.Float";
			else if (fullnameOfValueObject.equals("long")) fullnameOfValueObject = "java.lang.Long";
			else if (fullnameOfValueObject.equals("double")) fullnameOfValueObject = "java.lang.Double";
		}
		FindClassParams classValueObject = Loader.loadClass(compiler, fullnameOfValueObject, coreThreadID);
		String srcIndex = ByteCode_Helper.getSourceLineNumber(compiler, mBufferIndexOfSrc);
		String srcIndexWithoutCommaAndBlank = ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(compiler, mBufferIndexOfSrc);
		ArrayListChar message = new ArrayListChar(30);
		message.add("new // ");
		message.add(TypeDescriptor.getDescriptorExceptLAndSemicolon(classValueObject, coreThreadID)+srcIndex);
		message.add("\n");
		result.add(new String(message.getItems()));
		result.add("dup // "+srcIndexWithoutCommaAndBlank+"\n");
	}
	
	/**Calls constructor of classValueObject. For example, Integer(int), Float(float)*/
	void printNewValueObject_secondPassing(String fullnameOfValueObject, HighArrayCharForByteCode result, int coreThreadID, int mBufferIndexOfSrc) {
		if (CompilerHelper.IsDefaultType(fullnameOfValueObject)) {
			if (fullnameOfValueObject.equals("int")) fullnameOfValueObject = "java.lang.Integer";
			else if (fullnameOfValueObject.equals("byte")) fullnameOfValueObject = "java.lang.Byte";
			else if (fullnameOfValueObject.equals("short")) fullnameOfValueObject = "java.lang.Short";
			else if (fullnameOfValueObject.equals("char")) fullnameOfValueObject = "java.lang.Character";
			else if (fullnameOfValueObject.equals("float")) fullnameOfValueObject = "java.lang.Float";
			else if (fullnameOfValueObject.equals("long")) fullnameOfValueObject = "java.lang.Long";
			else if (fullnameOfValueObject.equals("double")) fullnameOfValueObject = "java.lang.Double";
		}
		FindClassParams classValueObject = Loader.loadClass(compiler, fullnameOfValueObject, coreThreadID);
		String srcIndex = ByteCode_Helper.getSourceLineNumber(compiler, mBufferIndexOfSrc);
		String srcIndexWithoutCommaAndBlank = ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(compiler, mBufferIndexOfSrc);
		
		
		// java.lang.StringBuilder의 인자가 없는 <init>()를 호출한다.
		FindFunctionParams constructorOfValueObject = ByteCode_Helper.getConstructorOfValueObject(compiler, classValueObject, mBufferIndexOfSrc, coreThreadID);
		physical.makeCONSTANT_Method_infoAndPutItIntolistOfConstantTable(constructorOfValueObject, coreThreadID);						
		
		result.add("invokespecial // "+constructorOfValueObject.getMethodInfoStr(coreThreadID)+srcIndex+"\n");
	}
	
	
	/** token이 '+'의 첫번째 오퍼랜드이고 타입이 java.lang.String이거나 서브클래스이고 스트링 상수이면
	 * java.lang.String오브젝트를 생성하고 
	 * token이 '+'의 두번째 오퍼랜드이고 타입이 java.lang.String이거나 서브클래스이고 스트링 상수이면
	 * 마찬가지로 java.lang.String오브젝트를 생성하고 
	 * token이 '+'의 두번째 오퍼랜드이고 타입이 디폴트타입이면 그 타입에 따라 value 클래스를 생성한다.*/
	/*ReturnOfprintFirstProcessInConcatOperator printFirstProcessInConcatOperator(CodeStringEx token, HighArrayCharForByteCode result) {
		FindClassParams valueClass = null;
		FindFunctionParams constructorOfValueClass = null;
		if (token.affectedBy!=null && token.affectedBy.equals("+")) {
			if (token.affectedBy_left!=null) {
				if (CompilerHelper.IsDefaultType(token.typeFullName)) {
					// token이 int, char와 같은 디폴트타입이고 '+'의 두번째 오퍼랜드이면
					// String str = 256+"abc"; 에서 varUse는 256이다.
					// String str = 256+str1; 에서 varUse는 256이다.
					CodeStringEx secondOperand = token.affectedBy.affectsRight;
					if (secondOperand.typeFullName.equals("java.lang.String")) {
						// 첫번째 오퍼랜드가 String클래스이면
						if (token.typeFullName.equals("byte") || token.typeFullName.equals("char") ||
							token.typeFullName.equals("short") || token.typeFullName.equals("int")) {
							valueClass = Loader.loadClass(compiler, "java.lang.Integer");
							constructorOfValueClass = ByteCode_Helper.getConstructor(valueClass, 3);
						}
						else if (token.typeFullName.equals("float")) {
							valueClass = Loader.loadClass(compiler, "java.lang.Float");
							constructorOfValueClass = ByteCode_Helper.getConstructor(valueClass, 5);
						}
						else if (token.typeFullName.equals("double")) {
							valueClass = Loader.loadClass(compiler, "java.lang.Double");
							constructorOfValueClass = ByteCode_Helper.getConstructor(valueClass, 6);
						}
						else if (token.typeFullName.equals("long")) {
							valueClass = Loader.loadClass(compiler, "java.lang.Long");
							constructorOfValueClass = ByteCode_Helper.getConstructor(valueClass, 4);
						}
						else if (token.typeFullName.equals("boolean")) {
							valueClass = Loader.loadClass(compiler, "java.lang.Boolean");
							constructorOfValueClass = ByteCode_Helper.getConstructor(valueClass, 8);
						}
						
						physical.makeCONSTANT_Method_infoAndPutItIntolistOfConstantTable(constructorOfValueClass);
						
						ArrayListChar message = new ArrayListChar(30);
						message.add("new // ");
						try {
						message.add(TypeDescriptor.getDescriptor(valueClass));
						}catch(Exception e) {
							if (Common_Settings.g_printsLog) e.printStackTrace();
							int a;
							a=0;
							a++;
						}
						message.add("\n");
						result.add(new String(message.getItems()));
						result.add("dup"+"\n");
					}//if (secondOperand.equals("java.lang.String")) {
				}//if (CompilerHelper.IsDefaultType(token.typeFullName)) {
				else  {
					// valueClass가 아닌 일반 오브젝트인 경우에는 생성자를 호출하지않고 toString()만 호출한다.
					valueClass = Loader.loadClass(compiler, token.typeFullName);
					//constructorOfValueClass = this.getConstructor(valueClass, 8)
				}
			}//if (token.affectedBy_left!=null) {
			else if (token.affectedBy_right!=null) {
				if (CompilerHelper.IsDefaultType(token.typeFullName)) {
					// token이 int, char와 같은 디폴트타입이고 '+'의 두번째 오퍼랜드이면
					// String str = "abc"+256; 에서 varUse는 256이다.
					// String str = str1 +256; 에서 varUse는 256이다.
					CodeStringEx firstOperand = token.affectedBy.affectsLeft;
					if (firstOperand.typeFullName.equals("java.lang.String")) {
						// 첫번째 오퍼랜드가 String클래스이면
						if (token.typeFullName.equals("byte") || 
							token.typeFullName.equals("short") || token.typeFullName.equals("int")) {
							valueClass = Loader.loadClass(compiler, "java.lang.Integer");
							constructorOfValueClass = ByteCode_Helper.getConstructor(valueClass, 3);
						}
						else if (token.typeFullName.equals("char")) {
							valueClass = Loader.loadClass(compiler, "java.lang.Character");
							constructorOfValueClass = ByteCode_Helper.getConstructor(valueClass, 1);
						}
						else if (token.typeFullName.equals("float")) {
							valueClass = Loader.loadClass(compiler, "java.lang.Float");
							constructorOfValueClass = ByteCode_Helper.getConstructor(valueClass, 5);
						}
						else if (token.typeFullName.equals("double")) {
							valueClass = Loader.loadClass(compiler, "java.lang.Double");
							constructorOfValueClass = ByteCode_Helper.getConstructor(valueClass, 6);
						}
						else if (token.typeFullName.equals("long")) {
							valueClass = Loader.loadClass(compiler, "java.lang.Long");
							constructorOfValueClass = ByteCode_Helper.getConstructor(valueClass, 4);
						}
						else if (token.typeFullName.equals("boolean")) {
							valueClass = Loader.loadClass(compiler, "java.lang.Boolean");
							constructorOfValueClass = ByteCode_Helper.getConstructor(valueClass, 8);
						}
						
						physical.makeCONSTANT_Method_infoAndPutItIntolistOfConstantTable(constructorOfValueClass);
						
						ArrayListChar message = new ArrayListChar(30);
						message.add("new // ");
						try {
						message.add(TypeDescriptor.getDescriptor(valueClass));
						}catch(Exception e) {
							if (Common_Settings.g_printsLog) e.printStackTrace();
							int a;
							a=0;
							a++;
						}
						message.add("\n");
						result.add(new String(message.getItems()));
						result.add("dup"+"\n");
					}//if (firstOperand.equals("java.lang.String")) {
				}//else if (CompilerHelper.IsDefaultType(token.typeFullName)) {
				else  {
					// valueClass가 아닌 일반 오브젝트인 경우에는 생성자를 호출하지않고 toString()만 호출한다.
					valueClass = Loader.loadClass(compiler, token.typeFullName);
					//constructorOfValueClass = this.getConstructor(valueClass, 8)
				}
			}//else if (token.affectedBy_right!=null) {
		}//if (token.affectedBy!=null && token.affectedBy.equals("+")) {
		return new ReturnOfprintFirstProcessInConcatOperator(valueClass, constructorOfValueClass);
	}*/
	
	/** token이 '+'의 첫번째 오퍼랜드이고 타입이 java.lang.String이거나 서브클래스이고 스트링 상수이면
	 * 스택에 올려진 상수로부터 java.lang.String오브젝트를 생성하고 
	 * token이 '+'의 두번째 오퍼랜드이고 타입이 java.lang.String이거나 서브클래스이고 스트링 상수이면
	 * 마찬가지로 스택에 올려진 상수로부터 java.lang.String오브젝트를 생성하고 
	 * token이 '+'의 두번째 오퍼랜드이고 타입이 디폴트타입이면 그 타입에 따라 
	 * 스택에 올려진 값(상수 또는 변수)으로부터 value 클래스를 생성한다.
	 * @param coreThreadID */
	void printSecondProcessInConcatOperator(CodeStringEx token,
			HighArrayCharForByteCode result, int coreThreadID) {
		// ValueClass가 아닌 일반적인 오브젝트인 경우에는 toString()만 호출한다.
		if (CompilerHelper.IsOperator(token)) {
			if (token.str.equals("+")) {
				// "abc"+1 에서 '+'는 그대로 리턴한다.
				// 스트링 연결연산자로 쓰인 '+'는 그대로 리턴한다.
				if (token.affectsLeft!=null && token.affectsLeft.typeFullName.equals("java.lang.String")) 
					return;
				if (token.affectsRight!=null && token.affectsRight.typeFullName.equals("java.lang.String")) 
					return;				
			}
		}
				 
		if ( token.affectedBy!=null && token.affectedBy.equals("+") && 
				token.affectedBy.typeFullName!=null && token.affectedBy.typeFullName.equals("java.lang.String")
				/*token.affectedBy.getTypeFullNameOrTypeFullNameAfterOperation()!=null &&
				token.affectedBy.getTypeFullNameOrTypeFullNameAfterOperation().equals("java.lang.String")*/ ) {
			int srcIndex = token.indicesInSrc.getItem(0);
			if (token.affectedBy_left!=null) {
				// "abc"+1 에서 "abc"
				// java.lang.StringBuilder의 append()를 호출한다.
				FindFunctionParams appendOfStringBuilder = 
						ByteCode_Helper.getAppendOfStringBuilder(compiler, token.typeFullName, srcIndex, coreThreadID);
				physical.makeCONSTANT_Method_infoAndPutItIntolistOfConstantTable(appendOfStringBuilder, coreThreadID);				
				
				result.add("invokevirtual // "+appendOfStringBuilder.getMethodInfoStr(coreThreadID)+ByteCode_Helper.getSourceLineNumber(compiler, srcIndex)+"\n");
			}
			else if (token.affectedBy_right!=null) {
				// "abc"+1 에서 1
				// java.lang.StringBuilder의 append()를 호출한다.				
				FindFunctionParams appendOfStringBuilder = 
						ByteCode_Helper.getAppendOfStringBuilder(compiler, token.typeFullName, srcIndex, coreThreadID);
				physical.makeCONSTANT_Method_infoAndPutItIntolistOfConstantTable(appendOfStringBuilder, coreThreadID);				
				
				result.add("invokevirtual // "+appendOfStringBuilder.getMethodInfoStr(coreThreadID)+ByteCode_Helper.getSourceLineNumber(compiler, srcIndex)+"\n");
			}
			
			// 스트링 연결 리스트에서 마지막 토큰일 경우
			if ((token.affectedBy_right!=null && token.affectedBy_right.affectedBy==null)) {
				// java.lang.StringBuilder의 toString()를 호출한다.
				FindFunctionParams toStringOfStringBuilder = ByteCode_Helper.getToStringOfStringBuilder(compiler, srcIndex, coreThreadID);
				physical.makeCONSTANT_Method_infoAndPutItIntolistOfConstantTable(toStringOfStringBuilder, coreThreadID);				
				
				result.add("invokevirtual // "+toStringOfStringBuilder.getMethodInfoStr(coreThreadID)+ByteCode_Helper.getSourceLineNumber(compiler, srcIndex)+"\n");
			}
			
		}
		
		
		
		
		
	}
	
	/*void printSecondProcessInConcatOperator(CodeStringEx token, 
			FindFunctionParams constructorOfValueClass,
			FindClassParams classHavingToStringFunc,
			HighArrayCharForByteCode result) {
		// ValueClass가 아닌 일반적인 오브젝트인 경우에는 toString()만 호출한다.
		//if (constructorOfValueClass==null) return;
		
		if (token.affectedBy!=null && token.affectedBy.equals("+")) {
			if (token.affectedBy_left!=null) {
				// 토큰이 첫번째 피연산자인 경우
				if (CompilerHelper.IsDefaultType(token.typeFullName)) {
					// token이 int, char와 같은 디폴트타입이고 '+'의 두번째 오퍼랜드이면
					// String str = 256+"abc"; 에서 varUse는 256이다.
					// String str = 256+str1; 에서 varUse는 256이다.						
					CodeStringEx secondOperand = token.affectedBy.affectsRight;
					if (secondOperand.typeFullName.equals("java.lang.String")) {
						physical.makeCONSTANT_Method_infoAndPutItIntolistOfConstantTable(constructorOfValueClass);						
						
						// 첫번째 오퍼랜드가 String클래스이거나 그것의 서브클래스일 경우에만
						// Integer 클래스의 Integer(int i) 생성자를 호출한다.
						// Float 클래스의 Float(float f) 생성자를 호출한다. 기타 등등
						result.add("invokespecial // "+constructorOfValueClass.getMethodInfoStr()+"\n");
						// 여기에서 스택에는 초기화된 Value클래스의 오브젝트가 들어있게 된다.
												
						FindFunctionParams toStringFunc = ByteCode_Helper.getToStringFunction(classHavingToStringFunc);
						
						physical.makeCONSTANT_Method_infoAndPutItIntolistOfConstantTable(toStringFunc);
						
						result.add("invokevirtual // "+toStringFunc.getMethodInfoStr()+"\n");
					}
				}
				else if (token.typeFullName.equals("java.lang.String")==false) {
					// token이 Object에서 상속받을 경우
					// obj+"abc"
					CodeStringEx secondOperand = token.affectedBy.affectsRight;
					if (secondOperand.typeFullName.equals("java.lang.String")) {
						
						FindFunctionParams toStringFunc = ByteCode_Helper.getToStringFunction(classHavingToStringFunc);
						
						physical.makeCONSTANT_Method_infoAndPutItIntolistOfConstantTable(toStringFunc);
						
						result.add("invokevirtual // "+toStringFunc.getMethodInfoStr()+"\n");
					}					
				}
			}//if (token.affectedBy_left!=null) {
			else if (token.affectedBy_right!=null) { 
				// 토큰이 두번째 피연산자인 경우
				if (CompilerHelper.IsDefaultType(token.typeFullName)) {
					// token이 int, char와 같은 디폴트타입이고 '+'의 두번째 오퍼랜드이면
					// String str = "abc"+256; 에서 varUse는 256이다.
					// String str = str1 +256; 에서 varUse는 256이다.						
					CodeStringEx firstOperand = token.affectedBy.affectsLeft;
					if (firstOperand.typeFullName.equals("java.lang.String")) {
						physical.makeCONSTANT_Method_infoAndPutItIntolistOfConstantTable(constructorOfValueClass);
						
						// 첫번째 오퍼랜드가 String클래스이거나 그것의 서브클래스일 경우에만
						// Integer 클래스의 Integer(int i) 생성자를 호출한다.
						// Float 클래스의 Float(float f) 생성자를 호출한다. 
						// Character 클래스의 Character(char c) 생성자를 호출한다.
						// 기타 등등
						result.add("invokespecial // "+constructorOfValueClass.getMethodInfoStr()+"\n");
						// 여기에서 스택에는 초기화된 Value클래스의 오브젝트가 들어있게 된다.
						
						FindFunctionParams toStringFunc = ByteCode_Helper.getToStringFunction(classHavingToStringFunc);
						
						physical.makeCONSTANT_Method_infoAndPutItIntolistOfConstantTable(toStringFunc);
						
						result.add("invokevirtual // "+toStringFunc.getMethodInfoStr()+"\n");
					}
				}
				else if (token.typeFullName.equals("java.lang.String")==false) {
					// token이 Object에서 상속받을 경우
					// "abc"+obj
					CodeStringEx firstOperand = token.affectedBy.affectsLeft;
					if (firstOperand.typeFullName.equals("java.lang.String")) {
						
						FindFunctionParams toStringFunc = ByteCode_Helper.getToStringFunction(classHavingToStringFunc);
						
						physical.makeCONSTANT_Method_infoAndPutItIntolistOfConstantTable(toStringFunc);
						
						result.add("invokevirtual // "+toStringFunc.getMethodInfoStr()+"\n");
					}					
				}
			}//else if (token.affectedBy_right!=null) {
			// 여기에서 스택에는 초기화된 String오브젝트와 Value클래스의 오브젝트가 들어있게 된다.
		}//if (token.affectedBy!=null && token.affectedBy.equals("+")) {
	}*/
	
	
	/** lValue의 디폴트 초기화 코드를 출력한다. 
	 * 예를 들어 int i = 1>0 ? 3 : 2;에서 i는 삼항연산으로 초기화되어 
	 * Compiler.containsLocalVarThatDoesNotInitialize()에서 초기화에러를 발생시키지 않지만
	 * 스택맵에서 에러를 발생시켜 디폴트 초기화 코드를 넣어줘야 한다.<br>
	 * int i;<br>
	 * if () {<br>
	 * 	i=0;<br>
	 * }<br>
	 * else {<br>
	 *  i=1;<br>
	 * }<br>
	 * 이런 경우에는 초기화 에러를 발생시킨다.*/
	void printInitializeStatement(FindVarUseParams lValue, HighArrayCharForByteCode result) {
		FindVarParams var = lValue.getOriginalVar();
		FindAssignStatementParams assign = var.assignStatementThatInitializeLocalVarFirst;
		if (var.isMemberOrLocal) return;
		if (assign!=null) {
			if (assign.endIndex()<lValue.index()) {
				// 이미 초기화되었으므로 디폴트 초기화 코드를 넣지 않고 리턴한다.
				return;
			}
		}
		if (var.typeName.equals("byte") || var.typeName.equals("short") || 
				var.typeName.equals("char") || var.typeName.equals("int")) {
			result.add("bipush 0 // "+ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(compiler, lValue.index())+"\n");
		}
		else if (var.typeName.equals("long")) {
			// ldc2_w 을 이용해서 초기화를 해야 하므로 미리 0을 constant table에 등록을 해야 한다.		
		}
		else if (var.typeName.equals("float")) {
			// ldc_w
		}
		else if (var.typeName.equals("double")) {
			// ldc2_w
		}
		else {
			// object
			result.add("aconst_null // "+ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(compiler, lValue.index())+"\n");
		}
		ThreeOperandsOperation.printLValue_ThreeOperandsOperation(this, lValue, result, false, coreThreadID);
	}
	
	
	
	
	void traverseChild(FindFuncCallParam funcCall, HighArrayCharForByteCode result, FindVarUseParams varUseFor1StackItem, int coreThreadID) {
		if (varUseFor1StackItem==null) {
			this.traverseChild(funcCall, result, coreThreadID);
		}
		else {
			if (funcCall.expression.postfix==null) return;
			
			int indexOfQuestion = CompilerHelper.indexOfBeforeSemicolon(compiler.data.mBuffer, funcCall.startIndex(), "?");
			if (indexOfQuestion!=-1) {
				ThreeOperandsOperation.traverseThreeOperandsOperation(this, funcCall, result, varUseFor1StackItem, coreThreadID);
				return;
			}
			else {
				this.traverseChild(funcCall, result, coreThreadID);
			}
		}
	}
	
	/** 삼항연산자에서, 수식에 있는 오퍼랜드에 대해서 재귀적 호출을 한다. 묵시적 타입캐스트도 해결한다.
	 * @param coreThreadID */
	void traverseChild(FindFuncCallParam funcCall, HighArrayCharForByteCode result, String oldType, String curType, int coreThreadID) {
		traverseChild(funcCall, result, coreThreadID);
		if (!TypeCast.abortsTypeFullNameAfterOperation(oldType, curType)) {
			TypeCast.printTypeCast(this, oldType, 
					curType, result, funcCall.startIndex(), coreThreadID);
		}
	}
	
	/** 수식에 있는 오퍼랜드에 대해서 재귀적 호출을 한다. 묵시적 타입캐스트도 해결한다.
	 * @param coreThreadID */
	void traverseChild(FindFuncCallParam funcCall, HighArrayCharForByteCode result, int coreThreadID) {
		int j, k;
		HighArray_CodeString src = compiler.data.mBuffer;
		
		if (funcCall.expression.postfix==null) return;
		
		int indexOfQuestion = CompilerHelper.indexOf(compiler.data.mBuffer, funcCall, funcCall.startIndex(), "?");
		int startIndexOfThree=-1, endIndexOfThree=-1;
		StartEnd startEndOfThree = null;
		
		if (indexOfQuestion!=-1) {
			startEndOfThree = ThreeOperandsOperation.getStartEndOfThreeOperands(compiler, funcCall);
			if (startEndOfThree!=null) {
				startIndexOfThree = startEndOfThree.startIndex;
				endIndexOfThree = startEndOfThree.endIndex;
			}
		}
		if (funcCall.startIndex()==166) {
			int a;
			a=0;
			a++;
		}
		
		for (j=0; j<funcCall.expression.postfix.length; j++) {
			CodeStringEx token = funcCall.expression.postfix[j]; // 오퍼랜드
			if (token==null) continue;
			if (token.indicesInSrc.getItem(0)==288) {
				int a;
				a=0;
				a++;
			}
			//valueClass = null;
			//constructorOfValueClass = null;
			
			
			if (startIndexOfThree!=-1 && 
					startIndexOfThree<=token.indicesInSrc.getItem(0) && token.indicesInSrc.getItem(0)<=endIndexOfThree) {
				CodeStringEx colon = ThreeOperandsOperation.getColon(compiler, funcCall);
				//if (colon.affectedBy!=null) {
				if (colon.affectedBy_right!=null) {
					FindVarUseParams varUseOf1StackItem = 
							ThreeOperandsOperation.getVarUseWith1StackItem(this, colon, startEndOfThree);
					ThreeOperandsOperation.traverseThreeOperandsOperation(this, funcCall, result, varUseOf1StackItem, coreThreadID);
				}
				else {
					ThreeOperandsOperation.traverseThreeOperandsOperation(this, funcCall, result, null, coreThreadID);
				}
				int m;
				// 3항연산자 이후로 점프한다.
				for (m=0; m<funcCall.expression.postfix.length; m++) {
					CodeStringEx lastTokenOfThree = funcCall.expression.postfix[m];
					if (lastTokenOfThree.equals(":")) {
						if (lastTokenOfThree.affectedBy!=null) {
							//j = m+1;
							j = m;
						}
						else {
							j = m;
						}
						break;
					}
				}
				if (m<funcCall.expression.postfix.length) {
					continue;
				}
			}
			
			// 수식에 있는 스트링 연결연산자를 처리한다.
			
			if (j==0 && funcCall.typeFullName!=null && funcCall.typeFullName.equals("java.lang.String")) {
				int m;
				for (m=0; m<funcCall.expression.postfix.length; m++) {
					CodeStringEx token2 = funcCall.expression.postfix[m];
					if (token2.str.equals("+") && token2.getTypeFullNameOrTypeFullNameAfterOperation().equals("java.lang.String")) {
						// System.out.print((i+1) +"횟수"+">>");  에서 i를 만났을때 token.affectedBy는 "+"이고 typeFullName은 int이고
			            // typeFullNameAfterOperation은 java.lang.String이다.
						this.printFirstProcessInConcatOperator(token, result, coreThreadID);
						break;
					}
				}
			}
			
			
			for (k=0; k<token.listOfVarUses.count; k++) {
				// 오퍼랜드 하나에 있는 varUse들에 대해서 재귀적 호출을 한다.
				FindVarUseParams child = null;
				child = (FindVarUseParams) token.listOfVarUses.getItem(k);
				if (child!=null) {
					traverseExpressionTree(src, child, result);
					k = ByteCode_Helper.getIndex(compiler, token, child, k);
				}//if (child!=null) {
			}//for (k=0; k<token.listOfVarUses.count; k++) {
			
			// 수식 안에 또다른 대입연산자를 포함할 경우를 처리한다.			
			int index = EqualOperator.loadLValueInNestedEqualOperator(this, src, funcCall, token, result);
			if (index!=-1) j = index;
			
			if (CompilerHelper.IsOperator(token)) {
				// System.out.print((i+1) +"횟수"+">>"); (i+1)의 +를 만났을때 iadd를 출력한다.
				this.printOperator(token, result, coreThreadID);
			}
			
			// 수식에 있는 스트링 연결연산자를 처리한다.
			if ( token.affectedBy!=null && token.affectedBy.equals("+") && 
					token.affectedBy.typeFullName!=null && token.affectedBy.typeFullName.equals("java.lang.String") ) {
				// System.out.print((i+1) +"횟수"+">>");  에서 i를 만났을때 token.affectedBy는 "+"이고 typeFullName은 int이고
	            // typeFullNameAfterOperation은 java.lang.String이다. 
				// StringBuilder.append(i)가 호출되어서는 안된다.
				printSecondProcessInConcatOperator(token, result, coreThreadID);
			}
			
			if (token.indicesInSrc.getItem(0)==285) {
				int a;
				a=0;
				a++;				
			}
			
			
			
			// 1.5f + ((false) ? 1 : 1+2) 에서 ':'의  typeFullName은 byte이고 typeFullNameAfterOperation은 float이다.
			// ':'은 operator이므로 i2f는 출력되지 않는다.
			//  i2f 출력은 이 함수의 윗부분 ThreeOperandsOperation.traverseThreeOperandsOperation()에서 
			// ':'전후 수식에 대해서 각자 출력을 한다.
			//if (!token.equals(":")) {
			if ( !(token.affectedBy!=null && token.affectedBy.equals("+") && 
					/*token.affectedBy.typeFullName!=null && token.affectedBy.typeFullName.equals("java.lang.String")*/
					token.affectedBy.getTypeFullNameOrTypeFullNameAfterOperation()!=null &&
					token.affectedBy.getTypeFullNameOrTypeFullNameAfterOperation().equals("java.lang.String")) ) {
				if (!token.equals(":")) {
					if (token.typeFullNameAfterOperation!=null) {
						if (!TypeCast.abortsTypeFullNameAfterOperation(token)) {
							TypeCast.printTypeCast(this,  token.typeFullName, 
									token.typeFullNameAfterOperation, result, token.indicesInSrc.getItem(0), coreThreadID);
						}
					}
				}
			}
		}//for (j=0; j<funcCall.expression.postfix.length; j++) {
		
		if (funcCall.typeFullNameAfterFuncCall!=null) {
			TypeCast.printTypeCast(this, funcCall.typeFullName.str, 
					funcCall.typeFullNameAfterFuncCall, result, funcCall.startIndex(), coreThreadID);
		}
	}
	
	
	
	
	void traverseArrayElement(HighArray_CodeString src, FindVarUseParams varUse, int indexInmBuffer, HighArrayCharForByteCode result, int coreThreadID) {
		if (varUse.index()==239) {
			int a;
			a=0;
			a++;
		}
		// varUse가 배열원소이면서 동시에 배열이 object 의 멤버이거나 아니면 지역변수 일 경우
		// arrayref를 먼저 출력하고 다음에 첨자를 출력한다.
		if (/*varUse.constant_info!=null*/varUse.varDecl!=null && varUse.varDecl.isMemberOrLocal) { 
			this.printMemberVarUse(varUse, result, true, coreThreadID);
		}
		else { // 작은 정수나 로컬 변수 등
			// 로컬(지역)변수
			LocalVar.printLocalVar(this, varUse, result, true, coreThreadID);
		}		
		
		//int dimension = Array.getArrayDimension(compiler, varUse.name);
		int dimension = -1;
		if (varUse.varDecl!=null) {
			dimension = Array.getArrayDimension(compiler, varUse.varDecl.typeName);
		}
		else if (varUse.funcDecl!=null) {
			dimension = Array.getArrayDimension(compiler, varUse.funcDecl.returnType);
		}
		else {
			dimension = Array.getArrayDimension(compiler, varUse.name);
		}
		
		if (varUse.listOfArrayElementParams==null) return;
		
				
		int i;
		
		// 첨자 출력
		for (i=0; i<varUse.listOfArrayElementParams.count; i++) {
			FindFuncCallParam funcCallParam = 
					(FindFuncCallParam) varUse.listOfArrayElementParams.getItem(i);
							
			if (funcCallParam.expression!=null) {
				if (funcCallParam.expression.postfix!=null) {					
					
					// 1 2 +
					// 수식트리에서 자식노드들을 방문하기위해 재귀적호출
					traverseChild(funcCallParam, result, coreThreadID);
					
				}//if (funcCallParam.expression.postfix!=null) {
				
			} //if (funcCallParam.expression!=null) {
			if (i!=varUse.listOfArrayElementParams.count-1) {
				// Prints aaload in array[j][i]
				// 2 aload_1       // local [[I array, 1, [[I array, [18]
				// 3 iload_3       // local I j, 3, I j, [18]
				// 4 aaload       // [18]

				// 마지막 첨자 처리가 아니면 aaload 를 출력한다.
				if (!(CompilerHelper.IsDefaultType(varUse.originName) ||
						varUse.memberDecl!=null)) {
					// 배열원소가 타입이 아니면, 즉 배열오브젝트 생성이 아니면
					printArrayElement(varUse, result, i, dimension, true);
				}
			}
		} //for (i=0; i<varUse.listOfFuncCallParams.count; i++) {
		// 배열원소 varUse 출력
		// 마지막 첨자일 경우에는 iaload, caload 등 배열원소타입대로 출력한다.
		if (varUse.index()==1082) {
		}
	
		
		// classA.arr[0] = 1; 이런 경우에는 arr[0]의 rValue가 null이 아니므로 출력을 하지않고
		// traverseLValue()에서 출력한다.
		if (varUse.prints_xaload) {
			if (varUse.isArrayElement) {
				if (varUse.rValue==null) {//load
					if (varUse.varDecl!=null && varUse.varDecl.typeName!=null) {
						// Prints iaload in array[j][i]
						// 2 aload_1       // local [[I array, 1, [[I array, [18]
						// 3 iload_3       // local I j, 3, I j, [18]
						// 4 aaload       // [18]
						// 5 iload_2       // local I i, 2, I i, [18]
						// 6 iaload       // [18]
						
						// Prints aaload in array[j].length
						// 0 aload_1       // local [[I array, 1, [[I array, [16]
						// 1 iload_3       // local I j, 3, I j, [16]
						// 2 aaload       // [16]
						printArrayElement(varUse, result, i-1, dimension, true);
					}
					else {
						if (CompilerHelper.IsDefaultType(varUse.originName) ||
								varUse.memberDecl!=null) {
							// int[] arr = new int[10];과 같은 배열오브젝트 생성
							printNewArray(varUse, result, coreThreadID);
						}
						else if (varUse.funcDecl!=null) {
							// 배열원소인 동시에 함수호출인 경우
							// int[] func() {}  int i = func()[3]; 여기에서 varUse는 func이다.
							printArrayElement(varUse, result, i-1, dimension, true);
						}
					}
				}
			}//if (varUse.isArrayElement) {
		}
		
		if (varUse.index()==2213) {
		}
		if (varUse.fullnameTypeCast!=null) {
			String oldType = varUse.getCurType();
			if (Array.getArrayDimension(this.compiler, oldType)!=0) {
				oldType = Array.getArrayElementType(oldType);
			}
			TypeCast.printTypeCast(this, oldType, varUse.fullnameTypeCast, result, varUse.index(), coreThreadID);
		}
		
	}
	
	
	
	void traverseFuncCall(HighArray_CodeString src, FindVarUseParams varUse, HighArrayCharForByteCode result, int coreThreadID) {
		if (varUse.index()==13321) {
			int a;
			a=0;
			a++;
		}
		if (varUse.funcDecl==null) return;
		
		String strmBufferIndex = ByteCode_Helper.getSourceLineNumber(compiler, varUse.index());
		String strmBufferIndexWithoutCommaAndBlank = ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(compiler, varUse.index());
		
		// this가 앞에 붙으면 이 함수의 가장 밑에서 처리한다.
		// this.func() 혹은 func() 과 같은 멤버함수 호출일 경우
		// invokespecial, invokevirtual 를 하기 전에 먼저 this 를 load 한다.
		if (varUse.parent==null && varUse.isUsingThisOrSuper) {	
			FindClassParams parentClass = (FindClassParams)varUse.classToDefineThisVarUse;
			String thisStr = TypeDescriptor.getDescriptorOfThis(parentClass, coreThreadID);
			result.add("aload_0 // local "+thisStr+strmBufferIndex+"\n");
		}
		
		
		
		if (varUse.funcDecl.isConstructor && 
				!varUse.funcDecl.isConstructorThatInitializesStaticFields) {
			FindClassParams parentClass = null;
			if (!varUse.originName.equals("super")) {
				parentClass = (FindClassParams) varUse.funcDecl.parent;
				
				ArrayListChar message = new ArrayListChar(30);
				message.add("new // ");
				message.add( TypeDescriptor.getDescriptorExceptLAndSemicolon(parentClass, coreThreadID) + strmBufferIndex);
				message.add("\n");
				result.add(new String(message.getItems()));				
				result.add("dup // "+strmBufferIndexWithoutCommaAndBlank+"\n");				
			}
			else {
				// public ColorDialog(View owner, Rectangle bounds) {
				// 		super(owner, bounds);
				// }
				// 여기에서 varUse는 super이다.
				// super()는 다음과 같이 컴파일된다.
				// 0     aload Lcom/gsoft/common/gui/ColorDialog; this
				// 2     aload android.view.View owner
				// 4     checkcast java.lang.Object
				// 7     aload com.gsoft.common.Sizing.Rectangle bounds
				// 9     invokespecial com.gsoft.common.gui.Dialog::void Dialog(java/lang/Object, com/gsoft/common/Sizing$Rectangle)


				parentClass = varUse.classToDefineThisVarUse;
				String thisStr = TypeDescriptor.getDescriptorOfThis(parentClass, coreThreadID);
				result.add("aload_0 // local "+thisStr+strmBufferIndex+"\n");
			}
			
		}
		
		if (varUse.index()==3615) {
			int a;
			a=0;
			a++;
		}
		
		boolean addsSystemOutToPrintStackTrace = false;
		if (varUse.parent!=null && varUse.parent.varDecl!=null && 
			varUse.funcDecl.name.equals("printStackTrace") && varUse.funcDecl.listOfFuncArgs.count==0) {
			Console.addsSystemOutToPrintStackTrace(this, varUse, result, coreThreadID);
			return;
		}
		
		if (!addsSystemOutToPrintStackTrace) {
			
			int argIndexOfArray = Member.funcArgIsArrayAndFuncCallParamsIsElementTypeList(compiler, varUse, varUse.funcDecl, coreThreadID);
			
			int i;		
			// f1(f2(1+2)+3)
			for (i=0; i<varUse.listOfFuncCallParams.count; i++) {
				if (argIndexOfArray!=-1 && i==argIndexOfArray) {
					// new ProcessBuilder("java", "-jar", "***.jar")와 같은 함수인 경우
					// System.out.printf("%d %f", 1, 0.5f)와 같은 함수인 경우
					this.traverseFuncCall_ArrayInitializer(src, varUse, argIndexOfArray, result);
					//FindVarParams varForTempLocalArrayInitializer = 
					//		varUse.funcToDefineThisVarUse.getVar(ByteCode_Types.varNameForTempLocalArrayInitializer);
					//LocalVar.printLocalVar_sub_tempLocalVarForArrayInitiaizer(this, varForTempLocalArrayInitializer, 
					//		result, true, strmBufferIndex, coreThreadID);
					break;
				}
				// 파라미터 한개
				FindFuncCallParam funcCallParam = 
						(FindFuncCallParam) varUse.listOfFuncCallParams.getItem(i);
				
				if (funcCallParam.typeFullName==null) continue;
								
				if (funcCallParam.expression!=null) {
					if (funcCallParam.expression.postfix!=null) {
						// 1 2 +
						// 수식트리에서 자식노드들을 방문하기위해 재귀적호출
						traverseChild(funcCallParam, result, coreThreadID);					
					}//if (funcCallParam.expression.postfix!=null) {				
				} //if (funcCallParam.expression!=null) {
				
				// 호출 파라미터가 오브젝트일 경우 함수 선언의 파라미터의 타입으로 
				// 캐스팅(instanceof)될 수 있는지 확인한다.
				//this.printTypeCast_sub(funcCallParam.typeFullName.str, var.typeName, result);
			} //for (i=0; i<varUse.listOfFuncCallParams.count; i++) {
		}
		
		// 함수호출 varUse 출력
		if (varUse.funcDecl!=null) { // 메서드 출력 invokestatic, invokevirtual 등
			this.printFuncCall(varUse, result, coreThreadID);
		}
		
		
		// (Long)arrUsedSpace.getItem(i)에서 
		// varUse는 getItem이고 fullnameTypeCast는 java.lang.Long이 된다.
		if (varUse.index()==2213) {
		}
		if (varUse.fullnameTypeCast!=null) {
			String oldType = varUse.getCurType();
			TypeCast.printTypeCast(this, oldType, varUse.fullnameTypeCast, result, varUse.index(), coreThreadID);
		}
		
	}
	
	/**new ProcessBuilder("java", "-jar", "***.jar")와 같은 함수인 경우에서 
	 * String 파라미터들을 String[]에 넣어서 호출을 한다.<br>
		System.out.printf("%d %f", 1, 0.5f)와 같은 함수인 경우인지를 확인한다.
	 * @param argIndexOfArray */
	void traverseFuncCall_ArrayInitializer(HighArray_CodeString src, FindVarUseParams varUse, 
			int argIndexOfArray, HighArrayCharForByteCode result) {
		if (varUse.index()==259) {
		}
		if (varUse.funcDecl==null) return;
		if (argIndexOfArray==-1) return;
		
		FindFuncCallParam funcCallParam = 
				(FindFuncCallParam) varUse.listOfFuncCallParams.getItem(argIndexOfArray);
		
		String strmBufferIndex = ByteCode_Helper.getSourceLineNumber(compiler, funcCallParam.startIndex());
		String strmBufferIndexWithoutCommaAndBlank = 
				ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(compiler, funcCallParam.startIndex());
		
		// 배열의 길이
		result.add("bipush "+(varUse.listOfFuncCallParams.count-argIndexOfArray)+" // "+strmBufferIndexWithoutCommaAndBlank+"\n");
		
		// 배열 오브젝트를 만든다.
		String typeName = Array.getArrayElementType(((FindVarParams)varUse.funcDecl.listOfFuncArgs.getItem(argIndexOfArray)).typeName);
		//String desc = TypeDescriptor.getDescriptor(typeName, coreThreadID);
		String desc = TypeDescriptor.getDescriptorExceptLAndSemicolon(typeName, coreThreadID);
		
		if (CompilerHelper.IsDefaultType(typeName)) {			
			result.add("newarray // "+desc+", "+ByteCode_Helper.getAType(desc)+strmBufferIndex+"\n");
		}
		else {
			//physical.makeCONSTANT_Class_infoAndPutItIntolistOfConstantTable(typeName, coreThreadID);
			physical.makeCONSTANT_Class_infoAndPutItIntolistOfConstantTable_ExceptLAndSemicolon(desc);
			result.add("anewarray // "+desc+strmBufferIndex+"\n");
		}
				
		
		int i;		
		// f1(f2(1+2)+3)
		for (i=argIndexOfArray; i<varUse.listOfFuncCallParams.count; i++) {
			// 파라미터 한개
			funcCallParam =	(FindFuncCallParam) varUse.listOfFuncCallParams.getItem(i);
			
			String strmBufferIndex2 = ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(compiler, funcCallParam.startIndex());
			
			result.add("dup // "+strmBufferIndex2+"\n");
			
			result.add("bipush "+(i-argIndexOfArray)+" // "+strmBufferIndex2+"\n");
			
			if (funcCallParam.typeFullName==null) continue;
			
			if (CompilerHelper.IsDefaultType(funcCallParam.typeFullName.str)) {
				this.printNewValueObject_firstPassing(funcCallParam.typeFullName.str, result, coreThreadID, funcCallParam.startIndex());
			}
			
			if (funcCallParam.expression!=null) {
				if (funcCallParam.expression.postfix!=null) {
					// 1 2 +
					// 수식트리에서 자식노드들을 방문하기위해 재귀적호출
					traverseChild(funcCallParam, result, coreThreadID);					
				}//if (funcCallParam.expression.postfix!=null) {				
			} //if (funcCallParam.expression!=null) {
			
			if (CompilerHelper.IsDefaultType(funcCallParam.typeFullName.str)) {
				this.printNewValueObject_secondPassing(funcCallParam.typeFullName.str, result, coreThreadID, funcCallParam.startIndex());
			}
			
			result.add("aastore // "+strmBufferIndex2+"\n");
			
			// 호출 파라미터가 오브젝트일 경우 함수 선언의 파라미터의 타입으로 
			// 캐스팅(instanceof)될 수 있는지 확인한다.
			//this.printTypeCast_sub(funcCallParam.typeFullName.str, var.typeName, result);
		} //for (i=0; i<varUse.listOfFuncCallParams.count; i++) {
		
		FindVarParams varForTempLocalArrayInitializer = 
				varUse.funcToDefineThisVarUse.getVar(ByteCode_Types.varNameForTempLocalArrayInitializer);
		funcCallParam =	(FindFuncCallParam) varUse.listOfFuncCallParams.getItem(argIndexOfArray);
		
		String strmBufferIndex2 = ByteCode_Helper.getSourceLineNumber(compiler, funcCallParam.startIndex());
		LocalVar.printLocalVar_sub_tempLocalVarForArrayInitiaizer(this, varForTempLocalArrayInitializer, 
				result, false, strmBufferIndex2, coreThreadID);
		
		LocalVar.printLocalVar_sub_tempLocalVarForArrayInitiaizer(this, varForTempLocalArrayInitializer, 
				result, true, strmBufferIndex2, coreThreadID);
		
		// 함수호출 varUse 출력
		/*if (varUse.funcDecl!=null) { // 메서드 출력 invokestatic, invokevirtual 등
			this.printFuncCall(varUse, result, coreThreadID);
		}
		
		
		// (Long)arrUsedSpace.getItem(i)에서 
		// varUse는 getItem이고 fullnameTypeCast는 java.lang.Long이 된다.
		if (varUse.index()==2213) {
		}
		if (varUse.fullnameTypeCast!=null) {
			String oldType = varUse.getCurType();
			TypeCast.printTypeCast(this, varUse.typeCastedByVarUse, oldType, varUse.fullnameTypeCast, result, varUse.index(), coreThreadID);
		}
		*/
	}
	
	
	
	/** 수식 트리를 순회한다.
	 * @param src
	 * @param varUse : 처음 호출시 사용자가 터치한 varUse, 아니면 자식노드의 varUse
	 * @param indexInmBuffer : 처음 호출시 사용자가 터치한 varUse의 mBuffer에서의 인덱스,
	 * , 아니면 자식노드의 varUse의 mBuffer에서의 인덱스
	 * @return : 수식트리를 순회하면서 함수 파라미터(FindFuncCallParam)에 있는 수식의 포스트픽스 표현들의 리스트
	 */
	public void traverseExpressionTree(HighArray_CodeString src, FindVarUseParams varUse, HighArrayCharForByteCode result) {
		
		if (varUse.index()==855) {
		}
		
		
		boolean isLValue = false, isFuncCall = false, isArrayElement = false, isTypeCast = false;
		
		int indexOfEqual = -1;
		if (varUse.rValue!=null) {
			indexOfEqual = compiler.IsLValue(src, varUse);
		}
		
		if (indexOfEqual!=-1) { // varUse가 LValue이면
			isLValue = true;
		}//if (IsLValue(src, varUse)!=-1) { // varUse가 LValue이면
		
		if (varUse.funcDecl!=null) {
			isFuncCall = true;
		} // if (varUse.funcDecl!=null) {
		
		
		if (varUse.isArrayElement) { // 배열첨자 처리
			isArrayElement = true;
		}//else if (varUse.isArrayElement) {
		
		if (varUse.typeCast!=null && varUse.typeCast.funcCall!=null) { 
			// (타입)(수식)인 경우 varUse는 타입, (타입)varUse와 같은 비수식 타입캐스트는 printVarConstantOrTypecast()에서 출력한다.
			isTypeCast = true;
		}//else if (varUse.typeCast!=null) {
		
		if (isLValue && isArrayElement) {
			// 배열에 저장
			// arr[0] = i; 에서 varUse는 arr이다. 
			// aastore, iastore 등은 스택상태가 arrRef, index(첨자), value(rValue) 이어야 한다.
			// 따라서 arrRef, index(첨자)는 미리 스택에 로드되어 있어야 하고 rValue를 계산한 후에
			// value가 스택에 로드되면 aastore 등을 출력한다.
			traverseArrayElement(src, varUse, varUse.index(), result, coreThreadID);
			EqualOperator.traverseLValue(this, src, varUse, varUse.index(), result, coreThreadID);
		}
		else if (isFuncCall && isArrayElement) {
			// 함수호출이면서 배열원소일 경우
			// 예를들어 func(p1,p2)[0] 와 같은 경우
			traverseFuncCall(src, varUse, result, coreThreadID);
			traverseArrayElement(src, varUse, varUse.index(), result, coreThreadID);
		}
		else if (isLValue) {// int i = a+3;
			EqualOperator.traverseLValue(this, src, varUse, varUse.index(), result, coreThreadID);
		}
		else if (isFuncCall) {
			traverseFuncCall(src, varUse, result, coreThreadID);
		}
		else if (isArrayElement) {
			traverseArrayElement(src, varUse, varUse.index(), result, coreThreadID);
		}
		else if (isTypeCast) { // 수식 타입캐스트, (타입)varUse와 같은 비수식 타입캐스트는 printVarConstantOrTypecast()에서 출력한다.
			TypeCast.traverseTypeCast(this, src, varUse, varUse.index(), result, coreThreadID);
		}
		else {	// 원자적 성질을 갖는다.
			if (varUse.typeCast!=null && varUse.typeCast.funcCall==null) {
				return;
			}
			else {
				printVarConstantOrTypecast(varUse, result);
			}
			
			
		}
		
	} // traverseExpressionTree
	
	
	
	
	/** varUse 가 lValue도 아니고 배열원소도 아니고 수식 타입캐스트도 아니면
		따라서 가장 작은 수식에서 오퍼랜드 하나이거나 str.length 에서 str, length를 말한다.
		getfield, getstatic, putfield, putstatic 와 같은 멤버변수 혹은 스트링, 정수, 실수 등의 상수,
		로컬(지역)변수, (int)f 와 같은 타입캐스트,
		명시적 수식타입캐스트가 아닌 명시적 타입캐스트를 해결한다.*/
	void printVarConstantOrTypecast(FindVarUseParams varUse, HighArrayCharForByteCode result) {
		if (varUse.index()==258) {
		}
		// 일반변수(배열이나 함수호출이 아닌), 일반변수, 상수 등
		if (varUse.memberDecl!=null) return;
		
		// varUse가 this, super이면 super.alpha = 10;에서 super
		if (varUse.varDecl!=null && (varUse.varDecl.isThis || varUse.varDecl.isSuper)) {
			FindClassParams parentClass = (FindClassParams)varUse.classToDefineThisVarUse;
			String thisStr = TypeDescriptor.getDescriptorOfThis(parentClass, coreThreadID);
			result.add("aload_0 // local "+thisStr+ByteCode_Helper.getSourceLineNumber(compiler, varUse.index())+"\n");
			return;
		}		
		
				
		if (varUse.varDecl!=null && varUse.varDecl.isMemberOrLocal) {
			// getfield, getstatic, putfield, putstatic
			this.printMemberVarUse(varUse, result, true, coreThreadID);
		}
		else if (varUse.varDecl!=null && !varUse.varDecl.isMemberOrLocal) {
			// 로컬(지역)변수, 일반상수, load
			LocalVar.printLocalVar(this, varUse, result, true, coreThreadID);
		}
		else {
			String constant = varUse.originName;
			if (!ByteCode_Helper.isSmallInteger(varUse)) { 
				// 스트링, 정수, 실수 등의 상수
				//CodeString constant = compiler.mBuffer.getItem(varUse.index());
				if (CompilerHelper.IsConstant(constant)) {
					this.printConstant(varUse, result);
				}
			}
			else { // 작은 정수
				// true, false 이거나 작은 정수들은 bipush, sipush 를 쓰므로 
				// varUse.constant_info가 null 이다.
				//CodeString constant = compiler.mBuffer.getItem(varUse.index());
				if (constant.equals("null")) {
					result.add("aconst_null // "+ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(compiler, varUse.index())+"\n");				
				}
				else if (CompilerHelper.IsConstant(constant)) {
					this.printSmallIntegerConstant(varUse, result);
				}
			}
		}
		
		
		// int i = (int)f + 2; (수식 타입캐스트가 아닌)에서  varUse 는 f 가 된다.
		if (varUse.index()==258) {
		}
		if (varUse.fullnameTypeCast!=null) {
			String oldType = varUse.getCurType();
			TypeCast.printTypeCast(this, oldType, varUse.fullnameTypeCast, result, varUse.index(), coreThreadID);
		}
	}
	
	
	

	/**phyical.makeConstantTable()의 wrapper*/
	public void makeConstantTable() {
		
		physical.makeConstantTable();
	}

	
	
}