package com.gsoft.common.compiler.bytecode;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.compiler.Array;
import com.gsoft.common.compiler.Checker;
import com.gsoft.common.compiler.CodeStringEx;
import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.CompilerData;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.CompilerStatic;
import com.gsoft.common.compiler.Compiler_types.FindFuncCallParam;
import com.gsoft.common.compiler.Compiler_types.FindVarUseParams;
import com.gsoft.common.compiler.Compiler_types_Special.FindThreeOperandsOperation;
import com.gsoft.common.compiler.Expression;
import com.gsoft.common.compiler.Expression.ReturnOfgetTypeOfVarUseOrFuncCallOfFullName2_sub;
import com.gsoft.common.compiler.Fullname;
import com.gsoft.common.compiler.HighArray_CodeString;
import com.gsoft.common.util.ArrayListIReset;
import com.gsoft.common.util.ArrayListInt;

import com.gsoft.common.compiler.bytecode.ByteCodeGeneratorForClass;
import com.gsoft.common.compiler.bytecode.HighArrayCharForByteCode;
import com.gsoft.common.compiler.bytecode.ByteCode_Helper;
import com.gsoft.common.compiler.bytecode.LocalVar;
import com.gsoft.common.compiler.bytecode.ByteCode_Condition;
import com.gsoft.common.compiler.bytecode.TypeCast;

public class ThreeOperandsOperation {

	/**printFindStatementParams()에서 호출된다. 문장이 할당문이면서 rValue가 삼항연산일 경우 출력을 처리한다.
	 * @param funcCall : 일반적인 수식, rValue
	 * @param varUseFor1StackItem 
	 * @param coreThreadID */
	public static void traverseThreeOperandsOperation(ByteCodeGeneratorForClass generator, FindFuncCallParam funcCall, 
			HighArrayCharForByteCode result, FindVarUseParams varUseFor1StackItem, int coreThreadID) {
		Compiler compiler = generator.compiler;
		int indexOfQuestion = CompilerHelper.indexOfBeforeSemicolon(compiler.data.mBuffer, funcCall.startIndex(), "?");
		int indexOfColon = Checker.CheckParenthesis(compiler,  "?", ":", indexOfQuestion, compiler.data.mBuffer.count-1, false);
		
		if (indexOfQuestion!=-1) {
			// funcCall의 lValue가 초기화가 안되었으면 초기화를 한다. 그렇지 않으면 stack map에서 에러가 발생한다.
			//printInitializeStatement(lValue, result);
			
		
			
			// 삼항 연산자일 경우
			FindFuncCallParam conditionOfThree = getConditionOfThreeOperandsOperation2(compiler, funcCall);
			conditionOfThree.typeFullName = Expression.getTypeOfExpression(compiler, conditionOfThree, coreThreadID);
			
			String strIndex = "";		
					
			int i;
			int len = compiler.data.mlistOfThreeOperandsOperation.count;
			for (i=0; i<len; i++) {
				FindThreeOperandsOperation threeOperandsOperation = (FindThreeOperandsOperation) compiler.data.mlistOfThreeOperandsOperation.getItem(i);
				if (threeOperandsOperation.indexOfQuestion==indexOfQuestion) {
					//threeOperandsOperation.indexOfEndOfThreeOperandsOperation = this.FindEndIndex_ThreeOperandsOperation(compiler.mBuffer, conditionOfThree.startIndex());
					threeOperandsOperation.indexOfEndOfThreeOperandsOperation = ByteCode_Helper.getIndexInmBuffer(compiler, null, (byte)3, conditionOfThree);
					threeOperandsOperation.indexOfCondition = ByteCode_Helper.getIndexInmBuffer(compiler, null, (byte)4, conditionOfThree);
					threeOperandsOperation.indexOfExitOfRun = ByteCode_Helper.getIndexInmBuffer(compiler, null, (byte)2, conditionOfThree);
					threeOperandsOperation.indexOfRunOfThreeOperandsOperation = ByteCode_Helper.getIndexInmBuffer(compiler, null, (byte)0, conditionOfThree);
					break;
				}
			}
			
			
			
			// conditionOfThree
			strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, null, (byte)4, conditionOfThree);
			if (varUseFor1StackItem==null) {
				result.add("// "+strIndex+"condition of Three Operands Operation"+"\n");
			}
			else {
				// a += 1=0 ? 1 : 0 과 같은 경우 삼항연산 앞에서 a를 로드해야 한다. 
				result.add("// "+strIndex+"condition of Three Compositive Operands Operation"+"\n");
			}
					
			ByteCode_Condition.printCondition(generator, null, result, conditionOfThree, coreThreadID);
			
			strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler,null, (byte)1, conditionOfThree);
			result.add("// "+strIndex+"exit_of_condition of Three Operands Operation"+"\n");
		
			
			strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler,null, (byte)2, conditionOfThree);
			result.add("// "+strIndex+"exit"+" of run of Three Operands Operation"+"\n");
			
			
			
			
			// : 다음의 수식을 출력한다.
			FindFuncCallParam thirdFuncCall = getExpressionAfterColonOfThreeOperandsOperation(compiler, funcCall);
			thirdFuncCall.typeFullName = Expression.getTypeOfExpression(compiler, thirdFuncCall, coreThreadID);
		
			if (thirdFuncCall.typeFullName.equals("byte") || thirdFuncCall.typeFullName.equals("short") ||
					thirdFuncCall.typeFullName.equals("char")) {
					thirdFuncCall.typeFullName.setStrAndTypeFullName("int", "int");
			}
			CodeStringEx colon = ThreeOperandsOperation.getColon(compiler, funcCall);
			generator.traverseChild(thirdFuncCall, result, thirdFuncCall.typeFullName.str, 
					colon.getTypeFullNameOrTypeFullNameAfterOperation(), coreThreadID);
			
			strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler,null, (byte)3, conditionOfThree);
			result.add("goto_w "+"// "+strIndex+"go to exit of Three Operands Operation"+"\n");
		
			
			
			
			strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler,null, (byte)0, conditionOfThree);
			result.add("// "+strIndex+"run of Three Operands Operation, "+colon.getTypeFullNameOrTypeFullNameAfterOperation()+"\n");
			
			//printControlBlockBody(null, result, doNotPrintThrowOrReturn);
			
			// 바깥 문장 리스트에 throw문을 포함하면 goto를 출력하지 않는다.
			//if (this.containsThrowOrReturnOrBreakOrContinue(controlBlock, controlBlock)==false) {
			//	strIndex = this.getStringOfmBufferIndex(controlBlock, (byte)3, null);
			//	result.add("goto_w "+"// "+strIndex+"go to exit of if-elseif-else"+"\n");
			//}
			
			
			
			// ? 다음의 수식을 출력한다.
			FindFuncCallParam secondFuncCall = new FindFuncCallParam(compiler, indexOfQuestion+1, indexOfColon-1);
			
			secondFuncCall.typeFullName = Expression.getTypeOfExpression(compiler, secondFuncCall, coreThreadID);
			if (secondFuncCall.typeFullName.equals("byte") || secondFuncCall.typeFullName.equals("short") ||
					secondFuncCall.typeFullName.equals("char")) {
				secondFuncCall.typeFullName.setStrAndTypeFullName("int", "int");
			}
			generator.traverseChild(secondFuncCall, result, secondFuncCall.typeFullName.str, 
					colon.getTypeFullNameOrTypeFullNameAfterOperation(), coreThreadID);
						
			
			
			
			
			strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler,null, (byte)3, conditionOfThree);
			if (varUseFor1StackItem==null) {
				result.add("// "+strIndex+"exit of Three Operands Operation, "+colon.getTypeFullNameOrTypeFullNameAfterOperation()+"\n");
			}
			else {
				//FindVarParams var = varUseFor1StackItem.getOriginalVar();
				FindVarUseParams lValue = varUseFor1StackItem;
				
				int indexOfVarUseInlistOfLValueForThreeOperandsOperationWith1StackItem =
						result.listOfVarUseForThreeOperandsOperationWith1StackItem.count;
				result.listOfVarUseForThreeOperandsOperationWith1StackItem.add(lValue);
				
				// 복합할당연산자와 3항 연산자를 함께 사용할 경우
				result.add("// "+strIndex+"exit of Three Operands Operation, "+colon.getTypeFullNameOrTypeFullNameAfterOperation()+", "+
						indexOfVarUseInlistOfLValueForThreeOperandsOperationWith1StackItem+"\n");
			}
		}
		else {
			// 3항 연산이 아닐 경우
			return;
		}
	}
	
	
	
	static void findCondition(FindFuncCallParam funcCallOfThreeOperandsOperation, CodeStringEx token, ArrayListInt result) {
		result.add(token.indicesInSrc.getItem(0));
		if (token.affectsLeft!=null) {			
			findCondition(funcCallOfThreeOperandsOperation, token.affectsLeft, result);
		}
		if (token.affectsRight!=null) {			
			findCondition(funcCallOfThreeOperandsOperation, token.affectsRight, result);
		}
	}
	
	/** 수식 트리를 순회한다.
	* @param src
	* @param varUse : 처음 호출시 사용자가 터치한 varUse, 아니면 자식노드의 varUse
	* @param indexInmBuffer : 처음 호출시 사용자가 터치한 varUse의 mBuffer에서의 인덱스,
	* , 아니면 자식노드의 varUse의 mBuffer에서의 인덱스
	* @return : 수식트리를 순회하면서 함수 파라미터(FindFuncCallParam)에 있는 수식의 포스트픽스 표현들의 리스트
	*/
	public static FindFuncCallParam findFindFuncCallParamIncludingQuestion( Compiler compiler, FindFuncCallParam funcCall) {
		
		int index = CompilerStatic.getIndexInmListOfAllVarUses2(compiler.data.mlistOfAllVarUses, 0, funcCall.startIndex(), true);
		FindVarUseParams varUse = (FindVarUseParams) compiler.data.mlistOfAllVarUses.getItem(index);
		if (varUse.rValue!=null || varUse.isArrayElement ||
				varUse.funcDecl!=null ||
				(varUse.typeCast!=null && varUse.typeCast.funcCall!=null) ) {
			FindFuncCallParam funcCallParamThreeOperandsOperation = findFindFuncCallParamIncludingQuestion_sub( compiler, varUse);
			if (funcCallParamThreeOperandsOperation!=null) return funcCallParamThreeOperandsOperation;
		}
		return funcCall;
	}
	
	/** 수식 트리를 순회한다.
	* @param src
	* @param varUse : 처음 호출시 사용자가 터치한 varUse, 아니면 자식노드의 varUse
	* @param indexInmBuffer : 처음 호출시 사용자가 터치한 varUse의 mBuffer에서의 인덱스,
	* , 아니면 자식노드의 varUse의 mBuffer에서의 인덱스
	* @return : 수식트리를 순회하면서 함수 파라미터(FindFuncCallParam)에 있는 수식의 포스트픽스 표현들의 리스트
	*/
	public static FindFuncCallParam findFindFuncCallParamIncludingQuestion_sub( Compiler compiler, FindVarUseParams varUse) {
		CompilerData data = compiler.data;
		HighArray_CodeString src = compiler.data.mBuffer;
		int i, j, k;
		if (varUse.index()==5248) {
		}
				
		int indexOfEqual = compiler.IsLValue(src, varUse);
		
		if (indexOfEqual!=-1) { // varUse가 LValue이면
			
			int startIndex = CompilerStatic.getIndexInmListOfAllVarUses(src, data.mlistOfAllVarUses, 0, indexOfEqual+1, true);
			int endIndex=-1;
			
			
			
			if (varUse.arrayInitializer!=null) {
				/*ResultOfFindNode_arrayIntializer_makeString_postfix result = new ResultOfFindNode_arrayIntializer_makeString_postfix(r);
					findNode_arrayIntializer_makeString_postfix(src, 
							varUse.arrayInitializer, varUse.arrayInitializer, result);
				return result.r;*/
			}
			
			if (varUse.rValue==null || varUse.rValue.expression==null) return null;
			
			if (varUse.rValue.expression.postfix==null) return null;
			
			startIndex = CompilerStatic.getIndexInmListOfAllVarUses(src, data.mlistOfAllVarUses, 0, varUse.rValue.startIndex(), true);
			endIndex = CompilerStatic.getIndexInmListOfAllVarUses(src, data.mlistOfAllVarUses, 0, varUse.rValue.endIndex(), false);
			
			
			// 수식트리에서 상위 노드의 포스트픽스를 출력한다.
			for (j=0; j<varUse.rValue.expression.postfix.length; j++) {
				CodeStringEx token = varUse.rValue.expression.postfix[j];
				if (token.equals("?")) return varUse.rValue;				
			}
			
			
			for (k=startIndex; k<=endIndex; k++) {
				if (k==35) {
				}
				FindVarUseParams child = (FindVarUseParams) data.mlistOfAllVarUses.getItem(k);
								
				// 수식트리에서 자식노드들을 방문하기위해 재귀적호출
				FindFuncCallParam funcCallParamThreeOperandsOperation = findFindFuncCallParamIncludingQuestion_sub( compiler, child);
				if (funcCallParamThreeOperandsOperation!=null) return funcCallParamThreeOperandsOperation;
				
				// 중복되어 출력될수있으므로 인덱스값을 처리한 위치 다음으로 바꿔준다.
				boolean isFuncCallAndArrayElement = false;
				if (child.funcDecl!=null && child.isArrayElement)
					isFuncCallAndArrayElement = true;
				
				if (child.funcDecl!=null) {
					if (child.listOfFuncCallParams.count>0) {
						FindFuncCallParam funcCall = (FindFuncCallParam) 
							child.listOfFuncCallParams.getItem(child.listOfFuncCallParams.count-1);
						int endIndexOfFuncCall = funcCall.endIndex()+1;
						k = CompilerStatic.getIndexInmListOfAllVarUses2(data.mlistOfAllVarUses, k, endIndexOfFuncCall, true);
						k--;
					}
				}
				if (child.isArrayElement && child.listOfArrayElementParams!=null) {
					FindFuncCallParam funcCall = (FindFuncCallParam) 
							child.listOfArrayElementParams.getItem(child.listOfArrayElementParams.count-1);
					int endIndexOfFuncCall = funcCall.endIndex()+1;
					k = CompilerStatic.getIndexInmListOfAllVarUses2(data.mlistOfAllVarUses, k, endIndexOfFuncCall, true);
					k--;										
				}
				if (child.typeCast!=null && child.typeCast.funcCall!=null) {
					FindFuncCallParam funcCall = (FindFuncCallParam) child.typeCast.funcCall;
					int endIndexOfFuncCall = funcCall.endIndex()+1;
					k = CompilerStatic.getIndexInmListOfAllVarUses2(data.mlistOfAllVarUses, k, endIndexOfFuncCall, true);
					k--;
				}
				if (isFuncCallAndArrayElement && child.listOfFuncCallParams.count>0) k++;
				
				
			}
		}//if (IsLValue(src, varUse)!=-1) { // varUse가 LValue이면
		
		if (varUse.funcDecl!=null) {
			// f1(f2(1+2)+3)
			for (i=0; i<varUse.listOfFuncCallParams.count; i++) {
				// 파라미터 한개
				FindFuncCallParam funcCallParam = 
						(FindFuncCallParam) varUse.listOfFuncCallParams.getItem(i);
								
				if (funcCallParam.expression!=null) {
					if (funcCallParam.expression.postfix!=null) {					
						
						// 수식트리에서 상위 노드의 포스트픽스
						// f2(1+2) 3 +
						for (j=0; j<funcCallParam.expression.postfix.length; j++) {
							
							CodeStringEx token = funcCallParam.expression.postfix[j];
							if (token.equals("?")) return funcCallParam;
						}
						
						
						// 1 2 +
						// 수식트리에서 자식노드들을 방문하기위해 재귀적호출
						for (j=0; j<funcCallParam.expression.postfix.length; j++) {
							CodeStringEx token = funcCallParam.expression.postfix[j];
							for (k=0; k<token.listOfVarUses.count; k++) {
								FindVarUseParams child = null;
								try {
								child = (FindVarUseParams) token.listOfVarUses.getItem(k);
								}catch(Exception e) {
								}
								if (child!=null) {
									// child를 varUse로 recursive call
									FindFuncCallParam funcCallParamThreeOperandsOperation = findFindFuncCallParamIncludingQuestion_sub( compiler, child);
									if (funcCallParamThreeOperandsOperation!=null) return funcCallParamThreeOperandsOperation;
									
									k = compiler.getIndex(token, child, k);
								}//if (child!=null) {
							}//for (k=0; k<token.listOfVarUses.count; k++) {
						}//for (j=0; j<funcCallParam.expression.postfix.length; j++) {
						
					}//if (funcCallParam.expression.postfix!=null) {
					
				} //if (funcCallParam.expression!=null) {
			} //for (i=0; i<varUse.listOfFuncCallParams.count; i++) {
		} // if (varUse.funcDecl!=null) {
		
		
		if (varUse.isArrayElement) { // 배열첨자 처리
			if (varUse.listOfArrayElementParams==null) return null;
			for (i=0; i<varUse.listOfArrayElementParams.count; i++) {
				FindFuncCallParam funcCallParam = 
						(FindFuncCallParam) varUse.listOfArrayElementParams.getItem(i);
								
				if (funcCallParam.expression!=null) {
					if (funcCallParam.expression.postfix!=null) {					
						
						// 수식트리에서 상위 노드의 포스트픽스
						// f2(1+2) 3 +
						for (j=0; j<funcCallParam.expression.postfix.length; j++) {
							CodeStringEx token = funcCallParam.expression.postfix[j];
							if (token.equals("?")) return funcCallParam;
						}
																
						// 1 2 +
						// 수식트리에서 자식노드들을 방문하기위해 재귀적호출
						for (j=0; j<funcCallParam.expression.postfix.length; j++) {
							CodeStringEx token = funcCallParam.expression.postfix[j];
							if (token==null) continue;
							for (k=0; k<token.listOfVarUses.count; k++) {
								FindVarUseParams child = 
										(FindVarUseParams) token.listOfVarUses.getItem(k);
								if (child!=null) {
									// child를 varUse로 recursive call 
									FindFuncCallParam funcCallParamThreeOperandsOperation = findFindFuncCallParamIncludingQuestion_sub( compiler, child);
									if (funcCallParamThreeOperandsOperation!=null) return funcCallParamThreeOperandsOperation;
									
									k = compiler.getIndex(token, child, k);
								}//if (child!=null) {
							}
						}
					}//if (funcCallParam.expression.postfix!=null) {
					
				} //if (funcCallParam.expression!=null) {
			} //for (i=0; i<varUse.listOfFuncCallParams.count; i++) {
		}//else if (varUse.isArrayElement) {
		
		if (varUse.typeCast!=null && varUse.typeCast.funcCall!=null) { // (타입)(수식)인 경우 varUse는 타입
			FindFuncCallParam funcCallParam = varUse.typeCast.funcCall;
						
			if (funcCallParam.expression!=null) {
				if (funcCallParam.expression.postfix!=null) {					
					
					// 수식트리에서 상위 노드의 포스트픽스
					// f2(1+2) 3 +
					for (j=0; j<funcCallParam.expression.postfix.length; j++) {
						CodeStringEx token = funcCallParam.expression.postfix[j];
						if (token.equals("?")) return funcCallParam;
					}
										
					// 1 2 +
					// 수식트리에서 자식노드들을 방문하기위해 재귀적호출
					for (j=0; j<funcCallParam.expression.postfix.length; j++) {
						CodeStringEx token = funcCallParam.expression.postfix[j];
						for (k=0; k<token.listOfVarUses.count; k++) {
							FindVarUseParams child = 
									(FindVarUseParams) token.listOfVarUses.getItem(k);
							if (child!=null) {
								// child를 varUse로 recursive call 
								FindFuncCallParam funcCallParamThreeOperandsOperation = findFindFuncCallParamIncludingQuestion_sub( compiler, child);
								if (funcCallParamThreeOperandsOperation!=null) return funcCallParamThreeOperandsOperation;
								
								k = compiler.getIndex(token, child, k);
							}//if (child!=null) {
						}
					}
				}//if (funcCallParam.expression.postfix!=null) {
				
			} //if (funcCallParam.expression!=null) {
			
		}//else if (varUse.typeCast!=null) {
		
		return null;
	
	} // findNode_varUse_makeString_postfix
	
	
	/**예를들면 1 + ((1>2 && 3>2+1) ? 1 : 0)에서 삼항연산은 (1>2 && 3>2+1) ? 1 : 0이 된다.*/
	public static FindFuncCallParam getConditionOfThreeOperandsOperation2(Compiler compiler, FindFuncCallParam funcCallParamThreeOperandsOperation) {
		int i;
		int indexQuestion=-1;		
		for (i=0; i<funcCallParamThreeOperandsOperation.expression.postfix.length; i++) {
			CodeStringEx str = funcCallParamThreeOperandsOperation.expression.postfix[i];
			if (str.equals("?")) {
				indexQuestion = i;
				break;
			}
		}
		CodeStringEx lastToken = funcCallParamThreeOperandsOperation.expression.postfix[indexQuestion-1];
		CodeStringEx left = getMostLeftToken(lastToken);
		CodeStringEx right = getMostRightToken(lastToken);
		// (T)o.f() == 1 + (T)o.f2(p1,p2)  ?  ...
		// (classParams.childClasses==null ? 0 : classParams.childClasses.count)
		int startIndex = left.indicesInSrc.getItem(0); // '(' in (T)o.f() == 1
		int endIndex = right.indicesInSrc.getItem(0); // '(' in (T)o.f2(p1,p2)
		endIndex = Fullname.getFullNameIndex(compiler, false, endIndex, false); // in (T)o.f2(p1,p2), ')'
		
		while (true) {
			int prevOfStartIndex = CompilerHelper.SkipBlank(compiler.data.mBuffer, true, 0, startIndex-1);
			if (prevOfStartIndex<funcCallParamThreeOperandsOperation.startIndex()) break;
			
			CodeString prevStr = compiler.data.mBuffer.getItem(prevOfStartIndex); 
			if (prevStr.equals("(")) {
				int rightPair = Checker.CheckParenthesis(compiler, "(", ")", prevOfStartIndex, 
						funcCallParamThreeOperandsOperation.endIndex(), false);
				if (startIndex<=rightPair && rightPair<=endIndex) {
					//  ((dataLen % MaxFragmentLen))!=0 ?	....
					// but condition is  dataLen % MaxFragmentLen)!=0
					// left is dataLen and right is 0.
					// startIndex is index of dataLen. endIndex is index Of '0'
					startIndex = prevOfStartIndex;
				}
				else {
					//  ( (dataLen % MaxFragmentLen)!=0  ?	.... )
					// left is dataLen and right is 0.
					// startIndex is index of dataLen. endIndex is index Of '0'
					break;
				}
			}
			else {
				// If prevStr is not '(', break
				break;
			}
		}
		return new FindFuncCallParam(compiler, startIndex, endIndex);
	}
	
	static CodeStringEx getMostLeftToken(CodeStringEx lastToken) {
		while (true) {
			if (lastToken.affectsLeft==null) return lastToken;
			lastToken = lastToken.affectsLeft;
		}
	}
	
	static CodeStringEx getMostRightToken(CodeStringEx lastToken) {
		if (!CompilerHelper.IsOperator(lastToken)) return lastToken;
		while (true) {
			// 1==1+2, 
			// 1, 1, 2, +, ==
			if (lastToken.affectsRight==null) return lastToken;
			lastToken = lastToken.affectsRight;
		}
	}
	
	public static FindFuncCallParam getConditionOfThreeOperandsOperation2_backup(Compiler compiler, FindFuncCallParam funcCallOfThreeOperandsOperation) {
		int i;
		
	
		HighArray_CodeString src = compiler.data.mBuffer;
		
		int indexQuestion = -1;
		int startIndex = funcCallOfThreeOperandsOperation.startIndex();
		int endIndex = -1;
		for (i=funcCallOfThreeOperandsOperation.startIndex(); i<=funcCallOfThreeOperandsOperation.endIndex(); i++) {
			CodeString str = src.getItem(i);
			if (CompilerHelper.IsComment(str) || CompilerHelper.IsBlank(str)) continue;
			if (str.equals("?")) {
				endIndex = i-1;
				indexQuestion = i;
				break;
			}
		}
		
		int tempStart = CompilerHelper.SkipBlank(src, false, startIndex, src.count-1);
		
		CodeString temp = src.getItem(tempStart);
		while (temp.equals("(")) {
			int rightPair = Checker.CheckParenthesis(compiler,  "(", ")", tempStart, src.count-1, false);
			if (rightPair<indexQuestion) {
				break;
			}
			tempStart = CompilerHelper.SkipBlank(src, false, tempStart+1, src.count-1);
			temp = src.getItem(tempStart);
		}
		startIndex = tempStart;
		return new FindFuncCallParam(compiler, startIndex, endIndex);
	}
	
	public static FindFuncCallParam getExpressionAfterColonOfThreeOperandsOperation(Compiler compiler, FindFuncCallParam funcCallParamThreeOperandsOperation) {
		int i;
		int indexColon=-1;		
		for (i=0; i<funcCallParamThreeOperandsOperation.expression.postfix.length; i++) {
			CodeStringEx str = funcCallParamThreeOperandsOperation.expression.postfix[i];
			if (str.equals(":")) {
				indexColon = i;
				break;
			}
		}
		// 1 : 1+2
		// 1 1 2 + :
		CodeStringEx lastToken = funcCallParamThreeOperandsOperation.expression.postfix[indexColon-1];
		CodeStringEx left = getMostLeftToken(lastToken);
		CodeStringEx right = getMostRightToken(lastToken);
		
		// (T)o.f() : 1 + (T)o.f2(p1,p2) 
		// (T)o.f()   1   (T)o.f2(p1,p2)  +  :
		int startIndex = left.indicesInSrc.getItem(0); // 1
		int endIndex = right.indicesInSrc.getItem(0);  // In (T)o.f2(p1,p2) , '(' 
		endIndex = Fullname.getFullNameIndex(compiler, false, endIndex, false); // ')'
		
		// ...  :   (1 + (T)o.f2(p1,p2))
		// ( ...  :   (1+2) + (T)o.f2(p1,p2) )
		while (true) {
			int prevOfStartIndex = CompilerHelper.SkipBlank(compiler.data.mBuffer, true, 0, startIndex-1);			
			CodeString prevStr = compiler.data.mBuffer.getItem(prevOfStartIndex); 
			if (prevStr.equals("(")) {
				int rightPair = Checker.CheckParenthesis(compiler, "(", ")", prevOfStartIndex, 
						funcCallParamThreeOperandsOperation.endIndex(), false);
				if (startIndex<=rightPair && rightPair<=funcCallParamThreeOperandsOperation.endIndex()) {
					//  ...  :   ((1+2) + (T)o.f2(p1,p2))
					// left is 1 and right is ')' in (T)o.f2(p1,p2)
					// startIndex is index of 1. endIndex is index Of ')' in (T)o.f2(p1,p2)
					startIndex = prevOfStartIndex;
				}
				else {
					//  ( (dataLen % MaxFragmentLen)!=0 ) ?	....
					// left is dataLen and right is 0.
					// startIndex is index of dataLen. endIndex is index Of '0'
					break;
				}
			}
			else {
				// If prevStr is not '(', break
				break;
			}
		}
		
		while (true) {
			int nextOfEndIndex = CompilerHelper.SkipBlank(compiler.data.mBuffer, false, endIndex+1, funcCallParamThreeOperandsOperation.endIndex());			
			CodeString nextStr = compiler.data.mBuffer.getItem(nextOfEndIndex); 
			if (nextStr.equals(")")) {
				int leftPair = Checker.CheckParenthesis(compiler, "(", ")", funcCallParamThreeOperandsOperation.startIndex(), 
						nextOfEndIndex,	true);
				if (startIndex<=leftPair && leftPair<=funcCallParamThreeOperandsOperation.endIndex()) {
					//  ...  :   ((1+2) + (T)o.f2(p1,p2))
					// 마지막 괄호 ')'는 포함된다.
					endIndex = nextOfEndIndex;
				}
				else {
					//  ( ... : (1+2) + (T)o.f2(p1,p2) )
					// 마지막 괄호 ')'는 아니다.
					break;
				}
			}
			else {
				// If nextStr is not '(', break
				break;
			}
		}
		return new FindFuncCallParam(compiler, startIndex, endIndex);
	}
	
	public static FindFuncCallParam getExpressionAfterColonOfThreeOperandsOperation_backup(Compiler compiler, FindFuncCallParam funcCallOfThreeOperandsOperation) {
		int i;
		
		
		
		HighArray_CodeString src = compiler.data.mBuffer;
		
		int indexColon = -1;
		
		int startIndex = -1;
		int endIndex = -1;
		for (i=funcCallOfThreeOperandsOperation.startIndex(); i<=funcCallOfThreeOperandsOperation.endIndex(); i++) {
			CodeString str = compiler.data.mBuffer.getItem(i);
			if (CompilerHelper.IsComment(str) || CompilerHelper.IsBlank(str)) continue;
			if (str.equals(":")) {
				startIndex = i+1;
				indexColon = i;
			}
			else if (str.equals(";")) {
				endIndex = i-1;
				break;
			}
		}
		if (endIndex==-1) {
			endIndex = funcCallOfThreeOperandsOperation.endIndex();
		}
		
		int tempEnd = CompilerHelper.SkipBlank(src, true, 0, endIndex);
		
		CodeString temp = src.getItem(tempEnd);
		while (temp.equals(")")) {
			int leftPair = Checker.CheckParenthesis(compiler,  "(", ")", 0, tempEnd, true);
			if (indexColon<leftPair) {				
				break;
			}
			tempEnd = CompilerHelper.SkipBlank(src, true, 0, tempEnd-1);
			temp = src.getItem(tempEnd);
		}
		endIndex = tempEnd;
		
		return new FindFuncCallParam(compiler, startIndex, endIndex);
	}
	
		
	static void findExpressionAfterColonOfThreeOperandsOperation(FindFuncCallParam funcCallOfThreeOperandsOperation, CodeStringEx token, ArrayListInt result) {
		result.add(token.indicesInSrc.getItem(0));
		if (token.affectsLeft!=null) {
			findExpressionAfterColonOfThreeOperandsOperation(funcCallOfThreeOperandsOperation, token.affectsLeft, result);
		}
		if (token.affectsRight!=null) {			
			findExpressionAfterColonOfThreeOperandsOperation(funcCallOfThreeOperandsOperation, token.affectsRight, result);
		}
	}
	
	
	public static CodeStringEx getColon_backup(Compiler compiler, FindFuncCallParam funcCallOfThreeOperandsOperation) {
		int i;
		CodeStringEx[] postfix = funcCallOfThreeOperandsOperation.expression.postfix;
		for (i=0; i<postfix.length; i++) {
			if (postfix[i].equals(":")) {
				return postfix[i];
			}
		}
		return null;
	}
	
	
	/** In 5 + (1==2 ? 'o' : 'x') , finds 5 */
	public static FindVarUseParams getVarUseWith1StackItem(ByteCodeGeneratorForClass generator, 
			CodeStringEx colon, StartEnd startEndOfThree) {
		CodeStringEx leftOperator = colon.affectedBy_right; // '+'
		if (leftOperator!=null && CompilerHelper.IsOperator(leftOperator)) {
			CodeStringEx left = leftOperator.affectsLeft; // 5
			if (left!=null) {
				int indexOfVarUse = left.indicesInSrc.getItem(0);
				int indexOfVIPVarUse = Fullname.getFullNameIndex(generator.compiler, false, indexOfVarUse, true);
				return CompilerStatic.getVarUseWithIndex(generator.compiler.data.mlistOfAllVarUsesHashed, 
						generator.compiler.data.mBuffer.getItem(indexOfVIPVarUse).str, indexOfVIPVarUse);
			}
		}
		
		return null;
	}
	
		
	/** In 5 + (1==2 ? 'o' : 'x') , finds 5 */
	public static FindVarUseParams getVarUseWith1StackItem(ByteCodeGeneratorForClass generator, 
			CodeStringEx[] postfix, StartEnd startEndOfThree) {
		int i;
		for (i=0; i<postfix.length; i++) {
			if (postfix[i].indicesInSrc.getItem(0)>=startEndOfThree.startIndex) {
				break;
			}
		}
		if (0<i && i<postfix.length) {
			int indexOfVarUse = postfix[i-1].indicesInSrc.getItem(0);
			int indexOfVIPVarUse = Fullname.getFullNameIndex(generator.compiler, false, indexOfVarUse, true);
			return CompilerStatic.getVarUseWithIndex(generator.compiler.data.mlistOfAllVarUsesHashed, 
					generator.compiler.data.mBuffer.getItem(indexOfVIPVarUse).str, indexOfVIPVarUse);
		}
		return null;
	}

	public static CodeStringEx getColon(Compiler compiler, FindFuncCallParam funcCallParamThreeOperandsOperation) {		
		int i;
		CodeStringEx[] postfix = funcCallParamThreeOperandsOperation.expression.postfix;
		for (i=0; i<postfix.length; i++) {
			if (postfix[i].equals(":")) {
				return postfix[i];
			}
		}
		return null;
	}
	
	public static class StartEnd {
		int startIndex;
		int endIndex;
		StartEnd(int startIndex, int endIndex) {
			this.startIndex = startIndex;
			this.endIndex = endIndex;
		}
	}
	
	/**funcCallOfThreeOperandsOperation에서 삼항연산자의 시작과 끝을 찾는다. 
	 * 예를들면 1 + ((1>2 && 3>2+1) ? 1 : 0)에서 삼항연산은 (1>2 && 3>2+1) ? 1 : 0이 된다.*/
	public static StartEnd getStartEndOfThreeOperands_backup(Compiler compiler, FindFuncCallParam funcCallOfThreeOperandsOperation) {
		FindFuncCallParam funcCallParamThreeOperandsOperation = findFindFuncCallParamIncludingQuestion(compiler, funcCallOfThreeOperandsOperation);
		if (funcCallParamThreeOperandsOperation==null) return null;
		
		FindFuncCallParam condition = ThreeOperandsOperation.getConditionOfThreeOperandsOperation2(compiler, funcCallParamThreeOperandsOperation);
		FindFuncCallParam endOfThree = ThreeOperandsOperation.getExpressionAfterColonOfThreeOperandsOperation(compiler, funcCallParamThreeOperandsOperation);
		return new StartEnd(condition.startIndex(), endOfThree.endIndex());
	}
	
	/**funcCallOfThreeOperandsOperation에서 삼항연산자의 시작과 끝을 찾는다. 
	 * 예를들면 1 + ((1>2 && 3>2+1) ? 1 : 0)에서 삼항연산은 (1>2 && 3>2+1) ? 1 : 0이 된다.*/
	public static StartEnd getStartEndOfThreeOperands(Compiler compiler, FindFuncCallParam funcCallOfThreeOperandsOperation) {
		//FindFuncCallParam funcCallParamThreeOperandsOperation = findFindFuncCallParamIncludingQuestion(compiler, funcCallOfThreeOperandsOperation);
		//if (funcCallParamThreeOperandsOperation==null) return null;
		
		FindFuncCallParam condition = ThreeOperandsOperation.getConditionOfThreeOperandsOperation2(compiler, funcCallOfThreeOperandsOperation);
		FindFuncCallParam endOfThree = ThreeOperandsOperation.getExpressionAfterColonOfThreeOperandsOperation(compiler, funcCallOfThreeOperandsOperation);
		return new StartEnd(condition.startIndex(), endOfThree.endIndex());
	}
	
	
	
	
	public static void printLValue_ThreeOperandsOperation(ByteCodeGeneratorForClass generator, FindVarUseParams lValue, HighArrayCharForByteCode result, boolean loadOrStore, int coreThreadID) {
				
		
		if (!lValue.isArrayElement) {
			try {
				if (lValue.varDecl==null) return;
			if (lValue.varDecl.isMemberOrLocal) { 
				//멤버변수에 저장, putfield, putstatic
				generator.printMemberVarUse(lValue, result, loadOrStore, coreThreadID);
			}
			else {//지역변수에 저장, istore, astore 등
				LocalVar.printLocalVar(generator, lValue, result, loadOrStore, coreThreadID);
			}
			}catch(Exception e) {
				if (Common_Settings.g_printsLog) e.printStackTrace();
				
			}
		}
		else { 
			// 배열에 저장
			// arr[0] = i; 에서 varUse는 arr이다. 
			// aastore, iastore 등은 스택상태가 arrRef, index(첨자), value(rValue) 이어야 한다.
			// 따라서 arrRef, index(첨자)는 미리 스택에 로드되어 있어야 하고 rValue를 계산한 후에
			// value가 스택에 로드되면 aastore 등을 출력한다.
			int curDimension = Array.getArrayDimension(generator.compiler, lValue.name);
			generator.printArrayElement(lValue, result, curDimension, curDimension, loadOrStore);
		}
	}
	
	/** 3항연산자에서 수식의 끝 mBuffer 인덱스를 구한다.
	 * @param startIndex : mBuffer에서의 검색 시작 인덱스
	 * */  
	public static int FindEndIndex_ThreeOperandsOperation(Compiler compiler, HighArray_CodeString src, int startIndex) {
		
        int endIndex = src.count;
        int i = startIndex;        
        while (i<endIndex) {
        	CodeString str = src.getItem(i);
        	if (CompilerHelper.IsBlank(str) || CompilerHelper.IsComment(str)) {
        		i++;
        	}
        	else if (CompilerHelper.IsIdentifier(str, compiler) || CompilerHelper.IsDefaultType(str, compiler)) {
		        i++;
        	}
        	else if (str.equals("[")) { // 배열원소
	        	int rightPair = 
		        		Checker.CheckParenthesis(compiler,  "[", "]", i, endIndex, false);
	        	if (rightPair==-1) {
	        		i = endIndex;
	        		break;
	        	}
	        	i = rightPair;		        	
	        	i++;
		    }
        	else if (str.equals("(")) { // 함수호출, 타입캐스트
        		int rightPair = 
		        		Checker.CheckParenthesis(compiler,  "(", ")", i, endIndex, false);
        		if (rightPair==-1) {
	        		i = endIndex;
	        		break;
	        	}
	        	i = rightPair;		        	
	        	i++;
        	}
        	else if (str.equals("?")) {
        		int rightPair = 
		        		Checker.CheckParenthesis(compiler,  "?", ":", i, endIndex, false);
        		if (rightPair==-1) {
	        		i = endIndex;
	        		break;
	        	}
	        	i = rightPair;		        	
	        	i++;
        	}
	        else if (str.equals(",")) break;
	        else if (str.equals(";")) break;
	        else if (str.equals(")")) break; // for (i=0; i<3; i+=2) 에서 i+=2의 경우
	        else {
	        	i++;
	        }
        	
        }
        
        if (i<endIndex && 
        		(src.getItem(i).equals(",") || src.getItem(i).equals(";")  || src.getItem(i).equals(")")) ) {
        	return i;
        }
        else {
        	return -1;
        }
	}
	
	
	
	/**traverseThreeOperandsOperation()에서 호출하여 복합 대입연산자를 출력한다. 
	 * lValue로드, rValue로드, 할당연산자를 제외한 나머지 연산자 출력(예를들어 +=에서 +출력)을 한다.
	   a+=2; 여기에서 a로드, 2로드(traverseChild()), add까지 한다.
	   @param varUse : lValue
	 * @param coreThreadID */
	public static void traverseCompositiveEqualOperator_ThreeOperandsOperation(ByteCodeGeneratorForClass generator, HighArray_CodeString src, FindVarUseParams varUse,			
			FindFuncCallParam rValue, HighArrayCharForByteCode result, int coreThreadID) {
		Compiler compiler = generator.compiler;
		
		
		int endIndexOfLValue = Fullname.getFullNameIndex(compiler,  false, varUse.index(), false);
		
		int startIndexOfOperator = CompilerHelper.SkipBlank(src, false, endIndexOfLValue+1, src.count-1);
		int endIndexOfOperator = compiler.IsLValue(src, varUse);
		
		String operator = Fullname.getFullName(src, startIndexOfOperator, endIndexOfOperator).str;
		String operatorExceptEqual = null;
		CodeStringEx operatorEx = null;
		
		CodeStringEx tokenOfLValue = null;
		CodeStringEx tokenOfRValue = null;
		
		CodeStringEx typeOfRValue = null;
		
		// 복합 대입연산자("+=", "-=", "*=" 등)에 대해서만
		// int ab=0;
		// int ba=ab+(ab+=2)+3; 여기에서 두번째 ab
		// ba=ab-(ab-=2.3f+2)*3; 여기에서 두번째 ab

		int startIndexOfLValue = Fullname.getFullNameIndex(compiler, true, varUse.index(), false);
		int startIndexOfLValueInmListOfAllVarUses = Compiler.getIndexInmListOfAllVarUses(
				compiler.data.mBuffer, compiler.data.mlistOfAllVarUses, 0, 
				startIndexOfLValue, true);
		int endIndexOfLValueInmListOfAllVarUses = Compiler.getIndexInmListOfAllVarUses(
				compiler.data.mBuffer, compiler.data.mlistOfAllVarUses, startIndexOfLValueInmListOfAllVarUses, 
				endIndexOfLValue, false);
		
		
		
		
		////////////////  lValue를 로드한다. start /////////////////////////
		
		// 중첩된 대입연산자의 lValue를 다시 스택에 로드해야 한다.
		// 밑에 있는 traverseExpressionTree()에서 lValue의 rValue를 null로 안하면
		// traverseLValue()가 호출되어 결과가 틀리게 나오기 때문에
		// 위에서 저장된 lValue를 로드만 해야 하기 때문에 rValue를 null로 만들어 준 후
		// 아래와 같이 token에 대해서 traverseExpressionTree()를 호출하여
		// 저장된 lValue를 스택에 로드한다.
		FindFuncCallParam backupRValue = varUse.rValue;
		varUse.rValue = null;
				
		int k;
		for (k=startIndexOfLValueInmListOfAllVarUses; k<=endIndexOfLValueInmListOfAllVarUses; k++) {
			// 오퍼랜드 하나에 있는 varUse들에 대해서 재귀적 호출을 한다.
			FindVarUseParams child = (FindVarUseParams) compiler.data.mlistOfAllVarUses.getItem(k);
			if (child!=null) {
				generator.traverseExpressionTree(src, child, result);
				//k = getIndex(token, child, k);
				k = generator.jump(child, k);
				
			}//if (child!=null) {
		}//for (k=0; k<token.listOfVarUses.count; k++) {
		varUse.rValue = backupRValue;
	
		
		
		CodeStringEx typeOfLValue;
		ReturnOfgetTypeOfVarUseOrFuncCallOfFullName2_sub r = 
				Expression.getTypeOfVarUseOrFuncCallOfFullName(compiler, src, startIndexOfLValue, coreThreadID);
		typeOfLValue = r.typeFullName;
		
		typeOfRValue = new CodeStringEx(rValue.typeFullName.str);
		
		// 복합 대입연산자("+=", "-=", "*=" 등)에서 "="을 제외한 연산자를 구한다.
		operatorExceptEqual = operator.substring(0, operator.length()-1);
		operatorEx = new CodeStringEx(operatorExceptEqual);
		operatorEx.typeFullName = rValue.typeFullName.str;
		operatorEx.isPlusOrMinusForOne = false;
		
		FindFuncCallParam funcCall = new FindFuncCallParam(compiler, startIndexOfLValue, rValue.endIndex());
		ArrayListIReset listOfTypes = new ArrayListIReset(2);
		listOfTypes.add(typeOfLValue);
		listOfTypes.add(typeOfRValue);
		tokenOfLValue = new CodeStringEx("LValue");
		tokenOfRValue = new CodeStringEx("RValue");
		tokenOfLValue.typeFullName = typeOfLValue.str;
		tokenOfRValue.typeFullName = typeOfRValue.str;
		typeOfLValue.operandOrOperator = tokenOfLValue;
		typeOfRValue.operandOrOperator = tokenOfRValue;
		// int ab=0;
		// ba=ab-(ab-=2.3f+2)*3; 여기에서 두번째 ab
		// 두번째 ab와 2.3f+2에 "-"연산을 할때 오퍼랜드들의 
		// 묵시적 타입캐스팅(typeFullNameAfterOperation)을 정한다.
		// 두번째 ab는 int이고 rValue의 타입은 float이므로 "-"연산을 할때 두번째 ab의 타입을 float로 바꿔야 한다.
		CodeStringEx typeOfOperator = 
				Expression.getTypeOfOperator(compiler, funcCall, listOfTypes, operatorEx, coreThreadID);
		if (typeOfOperator!=null)
			operatorEx.typeFullName = typeOfOperator.str;
		
		
		// int ab=0;
		// ba=ab-(ab-=2.3f+2)*3; 여기에서 두번째 ab
		// 두번째 ab는 int이고 rValue의 타입은 float이므로 "-"연산을 할때 두번째 ab의 타입을 float로 바꿔야 한다.
		if (typeOfLValue!=null && tokenOfLValue!=null && tokenOfLValue.getTypeFullNameOrTypeFullNameAfterOperation()!=null) {
			TypeCast.printTypeCast(generator,  tokenOfLValue.typeFullName, 
					tokenOfLValue.getTypeFullNameOrTypeFullNameAfterOperation(), result, varUse.index(), coreThreadID);
		}
		//////////////// lValue를 로드한다. end /////////////////////////
		
		
		//////////////// rValue를 로드한다. start ///////////////////////
		FindFuncCallParam funcCallOfRValue = rValue;
		generator.traverseChild(funcCallOfRValue, result, coreThreadID);
		
				
		if (typeOfRValue!=null && tokenOfRValue!=null && tokenOfRValue.getTypeFullNameOrTypeFullNameAfterOperation()!=null) {
			// int ab=0;
			// ba=ab-(ab-=2+2)*3; 여기에서 두번째 ab
			// 두번째 ab는 int이고 rValue의 타입은 byte이므로 "-"연산을 할때 rValue의 타입을 int로 바꿔야 한다.
			TypeCast.printTypeCast(generator,  tokenOfRValue.typeFullName, 
				tokenOfRValue.getTypeFullNameOrTypeFullNameAfterOperation(), result, varUse.index(), coreThreadID);
		}
		////////////////rValue를 로드한다. end ///////////////////////
		
		// 복합 대입연산자("+=", "-=", "*=" 등)에서 "="을 제외한 이항 연산자를 출력한다.			
		generator.printOperator(operatorEx, result, coreThreadID);
	}
}
