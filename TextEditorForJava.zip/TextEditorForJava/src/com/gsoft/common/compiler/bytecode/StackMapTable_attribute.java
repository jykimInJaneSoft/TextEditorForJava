package com.gsoft.common.compiler.bytecode;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.IO;
import com.gsoft.common.interfaces.IReset;
import com.gsoft.common.compiler.Array;
import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.Compiler_types.CategoryOfControls;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.Compiler_types.FindControlBlockParams;
import com.gsoft.common.compiler.Compiler_types.FindFunctionParams;
import com.gsoft.common.compiler.Compiler_types.FindVarParams;
import com.gsoft.common.compiler.Compiler_types.FindVarUseParams;
import com.gsoft.common.compiler.Compiler_types_Base.Block;
import com.gsoft.common.compiler.Compiler_types_Base.FindStatementParams;
import com.gsoft.common.compiler.Compiler_types_Special.FindSpecialBlockParams;
import com.gsoft.common.compiler.bytecode.ByteCode_Types.Exception_Entry;
import com.gsoft.common.compiler.bytecode.ByteCode_Types.HashItemOfConstantTable;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_Class_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_Utf8_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.Verification_Type_info;
import com.gsoft.common.compiler.classloader.Loader;
import com.gsoft.common.compiler.classloader.PathClassLoader;
import com.gsoft.common.util.ArrayList;


import com.gsoft.common.compiler.bytecode.StackMapTable_Entry;
import com.gsoft.common.compiler.bytecode.OffsetAndForLoopAndParent;
import com.gsoft.common.compiler.bytecode.ByteCodeGeneratorForClass;
import com.gsoft.common.compiler.bytecode.StackMapTable_Helper;
import com.gsoft.common.compiler.bytecode.LocalVar;
import com.gsoft.common.compiler.bytecode.Specials;
import com.gsoft.common.compiler.bytecode.TypeDescriptor;
import com.gsoft.common.compiler.bytecode.ThrowStack;
import com.gsoft.common.compiler.bytecode.PathClassWriter;

public class StackMapTable_attribute implements IReset {
	/** attribute_name_index, attribute_length 이 처음 6바이트를 제외해야 한다.
	 *  Attribute_Info에서 이미 읽었다.*/
	int attribute_name_index;
	/** attribute_name_index, attribute_length 이 처음 6바이트를 제외해야 한다.
	 *  Attribute_Info에서 이미 읽었다.*/
	int attribute_length;
	/** stackMapTable 의 엔트리 개수*/
	int  number_of_entries;
	/** number_of_entries 개 만큼 할당*/
	StackMapTable_Entry[] stackMapTable;
	private Compiler compiler;
	private FindFunctionParams func;
	private ByteCodeGeneratorForClass generator;
	
	
	/** Attribute_Info 의 attribute_length 만큼 읽어들인다.*/
	public static StackMapTable_attribute toStackMapTable_attribute(PathClassLoader loader, InputStream is, 
			ArrayList constantTable, boolean IsLittleEndian) throws IOException {
		StackMapTable_attribute r = new StackMapTable_attribute();
		// Attribute_info 에서 이미 읽었으므로 읽지 않는다.
		//r.attribute_name_index = IO.readUnsignedShort(is);
		//r.attribute_length = IO.readInt(is);
		
		r.number_of_entries = IO.readUnsignedShort(is, IsLittleEndian);
		r.readBytesLen += 2;
				
		r.stackMapTable = new StackMapTable_Entry[r.number_of_entries];
		int i;
		for (i=0; i<r.number_of_entries; i++) {
			r.stackMapTable[i] = StackMapTable_Entry.read(is, constantTable, IsLittleEndian, r);
			r.readBytesLen += r.stackMapTable[i].readBytesLen;
		}
		return r;
	}
	
	StackMapTable_attribute() {
		
	}

	
	StackMapTable_attribute(FindFunctionParams func, ByteCodeGeneratorForClass generator, int indexOfFunc, Compiler compiler, int coreThreadID) {
		this.compiler = compiler;
		this.func = func;
		this.generator = generator;		
		
		ArrayList listOfOffsetDeltas = generator.physical.arrResult[indexOfFunc].listOfOffsetDeltas;
		ArrayList listOfExceptionTable = generator.physical.arrResult[indexOfFunc].exception_table;
		
	
		// 마지막 프레임을 뺀다.
		this.number_of_entries = listOfOffsetDeltas.count - 1;
		
		if (number_of_entries<0) return;
		
		this.stackMapTable = new StackMapTable_Entry[this.number_of_entries];
		
		
		int i, j;
		int start_frame_pc=0, end_frame_pc=0;
		//int old_offset_delta = 0;
		for (i=0; i<this.stackMapTable.length; i++) {
			OffsetAndForLoopAndParent offset_delta = (OffsetAndForLoopAndParent) listOfOffsetDeltas.getItem(i);
			// 다음 프레임의 시작 pc
			end_frame_pc = start_frame_pc + offset_delta.offsetOrOffsetDelta;
			this.stackMapTable[i] = makeStackMapTable_Entry(start_frame_pc, offset_delta);
			start_frame_pc = end_frame_pc;
			
			this.stackMapTable[i].offsetAndForLoopOfChopFrame = offset_delta;
			/*if (offset_delta.forLoop!=null) {
				// chop프레임은 frame_type이 248-250이다. 일단 250으로 설정하고 지역변수의 개수에 따라 나중에 다시 바꾼다.
				this.stackMapTable[i].setFrame_type(250;
			}*/
			//old_offset_delta = offset_delta;
		}
		
		
		// 첫번째 프레임을 제외한 모든 프레임들의 offset_delta에 1을 빼준다.
		// Each stack_map_frame structure specifies the type state at a particular bytecode
		// offset. Each frame type specifies (explicitly or implicitly) a value, offset_delta,
		// that is used to calulate the actual bytecode offset at which it applies. The bytecode
		// offset at which the frame applies is given by adding 1 + offset_delta to the
		// offset of the previous frame, unless the previous frame is the initial frame of the
		// method, in which case the bytecode offset is offset_delta.
		for (i=1; i<this.stackMapTable.length; i++) {
			this.stackMapTable[i].offset_delta--;
		}
		// 자바 가상머신에서 실제로 검증할 때는 바이트코드 오프셋을 구하기위해 이전 프레임에 1+offset_delta를 더한다. 
		// 시작 프레임의 경우에는 offset_delta를 더한다.
		
		
		// this의 start_pcOfScope와 StackMapTable_Entry의 start_frame_pc을 이용하여
		// 알맞은 StackMapTable_Entry에 넣는다.
		FindVarParams localVar = null;
		// this는 넣지 않는다.
		
		
		
		// func의 지역변수들을 지역변수의 start_pcOfScope와 StackMapTable_Entry의 start_frame_pc을 이용하여
		// 알맞은 StackMapTable_Entry에 넣는다.
					
		// 공유변수의 경우 localVarTable에 넣어지고 index는 원래 변수와 공유한다.
		
		
		boolean isFuncArgs = false;
		//for (j=0; j<func.listOfVariableParams.count; j++) {
		for (j=0; j<func.listOfVariableParamsBeforeProcessLocalVars.count; j++) {
			//localVar = (FindVarParams) func.listOfVariableParams.getItem(j);
			localVar = (FindVarParams) func.listOfVariableParamsBeforeProcessLocalVars.getItem(j);
			
			// localVar가 함수레벨에서 선언되었거나 if, for를 가진 for루프레벨에서 선언되지 않았으면 스택맵 엔트리에 넣지 않는다.
			if (!isVarAFunctionLevelOrForLoopLevelWithIFOrFOR2(localVar)) continue;
			
			isFuncArgs = isFuncArg(localVar);
			if (isFuncArgs) continue;
			
	
			
			for (i=0; i<this.stackMapTable.length; i++) {
				StackMapTable_Entry entry = this.stackMapTable[i];				
				
				if (entry.start_frame_pc<=localVar.start_pcOfScope && localVar.start_pcOfScope<=entry.end_frame_pc) {
					// 현재 프레임에 지역변수를 넣는다.
					entry.listOfLocalVars.add(localVar);
					break;
				}
			}//for (i=0; i<this.stackMapTable.length; i++) {
		}
		
		
		
		int indexOfNextEntryOfSwitchStart = -1;
		
		// 지역변수의 개수에 따라 frame_type을 정한다.
		for (i=0; i<this.stackMapTable.length; i++) {
			StackMapTable_Entry entry = this.stackMapTable[i];
			
			
			if (stackMapTable[i].offsetAndForLoopOfChopFrame.message.equals("exit of try")) {
				// try블록이면 same_locals_1_stack_item_frame이거나 full_frame
				
				entry.isTryOrCatchOrFinally = 3;
				this.setException_EntriesToTryBlock(entry, listOfExceptionTable);
				int countOfLocalVars = entry.listOfLocalVars.count;
				if (countOfLocalVars==0) {
					// same_locals_1_stack_item_frame
					// int offset_delta = this.getFrame_type()-64;
					entry.setFrame_type((short) (entry.offset_delta + 64));
					if (!(64<=entry.frame_type && entry.frame_type<=127)) {//SAME_LOCALS_1_STACK_ITEM
						entry.setFrame_type(255);
					}
				}
				else {
					// full_frame
					entry.setFrame_type(255);
				}
				continue;
			}
		
			if (stackMapTable[i].offsetAndForLoopOfChopFrame.message.equals("exit of catch")) {
				// catch블록이면 same_locals_1_stack_item_frame이거나 full_frame
				entry.isTryOrCatchOrFinally = 1;
				this.setException_EntriesToCatchBlock(entry, listOfExceptionTable);
				if (entry.listOfCatchEntries!=null && entry.listOfCatchEntries.count>0) {
					int countOfLocalVars = entry.listOfLocalVars.count;
					if (countOfLocalVars==0) {
						// same_locals_1_stack_item_frame
						// int offset_delta = this.getFrame_type()-64;
						entry.setFrame_type((short) (entry.offset_delta + 64));
						if (!(64<=entry.frame_type && entry.frame_type<=127)) {//SAME_LOCALS_1_STACK_ITEM
							entry.setFrame_type(255);
						}
					}
					else {
						// full_frame
						entry.setFrame_type(255);
					}
					if (128<=entry.getFrame_type()) { // reserved
						entry.setFrame_type(255);
						//continue;
					}
					continue;
				}
			}
		
				
			
			int countOfLocalVars = entry.listOfLocalVars.count;
			if (countOfLocalVars==0) {
				// same_frame_extended
				entry.setFrame_type(251);
			}
			else if (countOfLocalVars<=3) {
				// append_frame
				entry.setFrame_type((short) (entry.listOfLocalVars.count + 251));
			}
			else {
				// full_frame
				entry.setFrame_type(255);
			}
			
		
			
			// 복합할당연산자와 삼항연산자를 같이 사용할 경우에 1개의 삼항연산자의 마지막 프레임				
			if (entry.offsetAndForLoopOfChopFrame.typeNameForThreeOperandsOperation!=null) {					
				if (entry.offsetAndForLoopOfChopFrame.indexOfVarUseInlistOfLValueForThreeOperandsOperationWith1StackItem!=-1) {
					// 복합할당연산자와 삼항연산자를 같이 사용할 경우에 삼항연산자의 마지막 프레임에서 varUseWith1StackItem를 로드하는 프레임을 찾는다.
					
					int indexOfPrevFrame = i-1;
					FindVarUseParams varUseForThreeOperandsOperationWith1StackItem = (FindVarUseParams) entry.offsetAndForLoopOfChopFrame.listOfVarUseForThreeOperandsOperationWith1StackItem.getItem(
							entry.offsetAndForLoopOfChopFrame.indexOfVarUseInlistOfLValueForThreeOperandsOperationWith1StackItem);
				
					// 1_stack_item은 full로, same_frame은 1_stack_item으로, full은 full로 바꾼다.
					this.changeToFrameWithStackItem(stackMapTable, indexOfPrevFrame, varUseForThreeOperandsOperationWith1StackItem);
					stackMapTable[indexOfPrevFrame].indexOfVarUseInlistOfVarsForThreeOperandsOperationWith1StackItem =
							entry.offsetAndForLoopOfChopFrame.indexOfVarUseInlistOfLValueForThreeOperandsOperationWith1StackItem;
					stackMapTable[indexOfPrevFrame].listOfVarsForThreeOperandsOperationWith1StackItem =
							entry.offsetAndForLoopOfChopFrame.listOfVarUseForThreeOperandsOperationWith1StackItem;
					stackMapTable[indexOfPrevFrame].varUseForThreeOperandsOperatorWith1StackItem =
							varUseForThreeOperandsOperationWith1StackItem;
				
				}
			}//if (entry.offsetAndForLoopOfChopFrame.typeNameForThreeOperandsOperation!=null) {
			
			if (entry.offsetAndForLoopOfChopFrame.typeNameForThreeOperandsOperation!=null) {
				if (entry.offsetAndForLoopOfChopFrame.indexOfVarUseInlistOfLValueForThreeOperandsOperationWith1StackItem==-1) {
					// 복합할당연산자 없이 삼항연산자만 사용하는 경우
					// same_locals_1_stack_item_frame
					// int offset_delta = this.getFrame_type()-64;
					entry.setFrame_type((short) (entry.offset_delta + 64));
					if (entry.listOfLocalVars.count>0) {
						entry.setFrame_type(255);
					}
					else if (!(64<=entry.frame_type && entry.frame_type<=127)) {//SAME_LOCALS_1_STACK_ITEM
						entry.setFrame_type(255);
					}
				}
				else {
					// 복합할당연산자와 삼항연산자를 같이 사용할 경우에 1개의 스택 아이템(varUseWith1StackItem)이 출력되는 경우
					// exit of ThreeOperandsOperation, 삼항연산자의 마지막 프레임은 스택 아이템을 2개 갖는다.
					entry.setFrame_type(255);
					// 복합할당연산자와 삼항연산자를 같이 사용할 경우에 삼항연산자의 마지막 프레임에서 lValue의 변수를 추가적으로 locals에 넣는다.					
				}
			}
			
			if (entry.offsetAndForLoopOfChopFrame.message.equals("SwitchStart")) {
				this.changeToFrameWithStackItem(stackMapTable, i, null);
				indexOfNextEntryOfSwitchStart = i+1;
			}
			
			if (i==indexOfNextEntryOfSwitchStart) {
				this.changeToFrameWithStackItem(stackMapTable, i, null);
				entry.offsetAndForLoopOfChopFrame.message = "NextEntryOfSwitchStart";
			}
		}
		
		

		// stackMapTable의 entry에 넣어진 listOfLocalVars을 초기화한다. 
		for (i=0; i<this.stackMapTable.length; i++) {
			StackMapTable_Entry entry = this.stackMapTable[i];
			entry.listOfLocalVars.count = 0;
		}
	
	
		
		
		// 함수 파라미터도 entry가 full_frame일 경우에는 넣어야 하므로 
		// listOfLocalVars을 초기화하여 모든 지역변수들을 다시 넣는다.
		//for (j=0; j<func.listOfVariableParams.count; j++) {
		for (j=0; j<func.listOfVariableParamsBeforeProcessLocalVars.count; j++) {
			
			localVar = (FindVarParams) func.listOfVariableParamsBeforeProcessLocalVars.getItem(j);
			
			
			if (isFuncArg(localVar)) continue;
			
			// localVar가 제어블록 안에서 선언되었으면 스택맵 엔트리에 넣지 않는다.
			if (!isVarAFunctionLevelOrForLoopLevelWithIFOrFOR2(localVar)) continue;
				
			
			for (i=0; i<this.stackMapTable.length; i++) {
				StackMapTable_Entry entry = this.stackMapTable[i];
				if (entry.start_frame_pc<=localVar.start_pcOfScope && localVar.start_pcOfScope<=entry.end_frame_pc) {
					// 현재 프레임에 지역변수를 넣는다.
					entry.listOfLocalVars.add(localVar);
					break;
				}
			}//for (i=0; i<this.stackMapTable.length; i++) {
		}
		
		
		// 지역변수의 개수에 따라 frame_type을 정한다.
		for (i=0; i<this.stackMapTable.length; i++) {
			StackMapTable_Entry entry = this.stackMapTable[i];
			
			if (entry.offsetAndForLoopOfChopFrame.accumulatedOffset==1043) {
			}
			
			if (func.isConstructor && i==0) {
				// 생성자에서 첫번째 엔트리는 full_frame이다.
				// full_frame					
				entry.setFrame_type(255);
				continue;
			}
			
			if (entry.offsetAndForLoopOfChopFrame.message.equals("SwitchStart") ||
					entry.offsetAndForLoopOfChopFrame.message.equals("NextEntryOfSwitchStart")) {
				continue;
			}
			
			if (entry.getFrame_type()==(short) (entry.offset_delta + 64)) {
				// same_locals_1_stack_item_frame
				if (entry.listOfLocalVars.count>0) {
					entry.setFrame_type(255);
				}
				else if (!(64<=entry.frame_type && entry.frame_type<=127)) {//SAME_LOCALS_1_STACK_ITEM
					entry.setFrame_type(255);
				}
				continue;
			}
			
			
			if (entry.getFrame_type()==255) {
				continue;
			}
			
			
			if (entry.listOfLocalVars.count==0) {
				// same_frame_extended
				entry.setFrame_type(251);
			}
			else if (entry.listOfLocalVars.count<=3) {
				// append_frame
				entry.setFrame_type((short) (entry.listOfLocalVars.count + 251));
			}
			else {
				// full_frame
				entry.setFrame_type(255);
			}
		}
		
		//this.processChopFrame(stackMapTable);
		
	
		
		this.processFullFrame(stackMapTable);
		
		//this.processTheEntriesOfTry(stackMapTable);
		
		//this.processCaseAndDefaultFrame(stackMapTable);
		//this.processNextFrameOfSwitch(stackMapTable);
		
	
		for (i=0; i<this.stackMapTable.length; i++) {
			StackMapTable_Entry entry = this.stackMapTable[i];
			
			if (!entry.isChopFrame && !entry.isEntryLastInTry && 
					!entry.forHasOtherControlBlock && !entry.isCaseAndDefaultFrame &&
					entry.getFrame_type()==255) {
				
				this.inheritLocalVars(stackMapTable, i, entry.offsetAndForLoopOfChopFrame.parent);							
			}
			/*if (entry.getFrame_type()==255) {
				inheritThisAndFuncArgs(stackMapTable, i);
			}*/
			this.setVerification_type_info(entry, coreThreadID);
		}
		
				
	}
	
	
	static class ReturnOfgetFrameIndex {
		int frameIndex;
		FindVarUseParams varUseForThreeOperandsOperationWith1StackItem;
		ReturnOfgetFrameIndex(int frameIndex, FindVarUseParams varUseForThreeOperandsOperationWith1StackItem) {
			this.frameIndex = frameIndex;
			this.varUseForThreeOperandsOperationWith1StackItem = varUseForThreeOperandsOperationWith1StackItem;
		}
	}
	
	ReturnOfgetFrameIndex getFrameIndexLoadingLValueForCompositiveEqualOperatorAndThreeOperandsOperation(StackMapTable_Entry[] stackMapTable, 
			int byteCodeOffsetOfConditionForThreeOperandsOperationWith1StackItem, 
			int indexOfVarUseInlistOfLValueForThreeOperandsOperationWith1StackItem, 
			ArrayList listOfVarUseForThreeOperandsOperationWith1StackItem) {
		int i;
		FindVarUseParams varUseWith1StackItem = 
				(FindVarUseParams) listOfVarUseForThreeOperandsOperationWith1StackItem.getItem(indexOfVarUseInlistOfLValueForThreeOperandsOperationWith1StackItem);
		//FindVarParams var = varUseWith1StackItem.getOriginalVar();
		for (i=0; i<stackMapTable.length; i++) {
			StackMapTable_Entry entry = stackMapTable[i];
			int end_frame_pc = entry.end_frame_pc;
			if (end_frame_pc<=byteCodeOffsetOfConditionForThreeOperandsOperationWith1StackItem) {
				if (i+1<stackMapTable.length) {
					int end_frame_pcOfNextFrame = stackMapTable[i+1].end_frame_pc;
					if (byteCodeOffsetOfConditionForThreeOperandsOperationWith1StackItem<end_frame_pcOfNextFrame) {
						return new ReturnOfgetFrameIndex(i, varUseWith1StackItem);
					}
				}
				else {
					return new ReturnOfgetFrameIndex(stackMapTable.length-1, varUseWith1StackItem);
				}
			}
		}
		return null;
	}
	

	void inheritThisAndFuncArgs(StackMapTable_Entry[] stackMapTable, int index) {
		StackMapTable_Entry fullEntry = stackMapTable[index];
		fullEntry.listOfLocalVarsInheritted.count = 0;
		
		if (!func.accessModifier.isStatic) {
			fullEntry.listOfLocalVarsInheritted.add(func.thisVar);
		}
		
		
		
		int i;
		
		for (i=0; i<func.listOfFuncArgs.count; i++) {
			fullEntry.listOfLocalVarsInheritted.add(func.listOfFuncArgs.getItem(i));
		}
	}
	
	/**chop프레임이면서 동시에 full프레임의 경우 자신이 속해있는 레벨에서 선언된 지역변수들을 포함하지 않고 
	 * parent블록에 있는 full프레임과 append프레임에서 선언된 지역변수들을 상속한다. 
	 * @param i : stackMapTable에서의 현재 인덱스, i는 full프레임을 가리킨다.*/
	void inheritLocalVars(StackMapTable_Entry[] stackMapTable,
			int index, Block parentOfEntry) {
		StackMapTable_Entry fullEntry = stackMapTable[index];
		fullEntry.setFrame_type(255);
			
	
		fullEntry.listOfLocalVarsInheritted.count = 0;
		
		if (!func.accessModifier.isStatic) {
			fullEntry.listOfLocalVarsInheritted.add(func.thisVar);
		}
		
		
		
		int i, j;
		
		for (i=0; i<func.listOfFuncArgs.count; i++) {
			fullEntry.listOfLocalVarsInheritted.add(func.listOfFuncArgs.getItem(i));
		}
		
		if (index==0) return;
		
		Block child = parentOfEntry;
		
		boolean includesTheLevelOfChild = false;
		if (fullEntry.isChopFrame) {
			includesTheLevelOfChild = false;
		}
		else if (fullEntry.forHasOtherControlBlock) {
			includesTheLevelOfChild = false;
			fullEntry.listOfLocalVars.count = 0;
			// condition of if, exit of if의 parent는 for루프이다.
			// for루프 상위의 지역변수들을 상속한다.			
		}
		else {
			if (child instanceof FindSpecialBlockParams) {
				FindSpecialBlockParams special = (FindSpecialBlockParams) child;
				if (special.getName().equals("try")) {
					includesTheLevelOfChild = true;
					if (fullEntry.isEntryLastInTry) {
						includesTheLevelOfChild = false;
					}
				}
			}
			else if (child instanceof FindFunctionParams) {
				includesTheLevelOfChild = true;
			}
		}
		
		
		for (i=0; i<stackMapTable.length; i++) {
			StackMapTable_Entry entry = stackMapTable[i];
			if (entry.start_frame_pc<fullEntry.start_frame_pc) {
				for (j=0; j<entry.listOfLocalVars.count; j++) {
					FindVarParams localVar = (FindVarParams) entry.listOfLocalVars.getItem(j);
					
					
					if (this.inherits(localVar, child, includesTheLevelOfChild)) { 
						fullEntry.listOfLocalVarsInheritted.add(localVar);
					}
				}
			}
		}
	}
	
	
	
	
	/** parent에 선언된 지역변수들을 child가 상속을 하는지를 조사한다.
	 * @param includesWhenParentIsChild : 프레임의 parent블록과 같은 레벨에 있는 지역변수들을 포함할지 여부*/
	public boolean inherits(Block parent, Block child) {
		if (parent==null) {
			try {
				throw new Exception("parent is null");
			} catch (Exception e) {
				
				if (Common_Settings.g_printsLog) e.printStackTrace();
			}
		}
		if (parent==child) return true;
		
		//if (parent==child) return true;
		while (true) {
			if (child==null) return false;
			if (parent==child) return true;
			if (child!=null) {
				child = child.parent;
			}
		}
	}
	
	/** parent에 선언된 지역변수들을 child가 상속을 하는지를 조사한다.
	 * @param includesWhenParentIsChild : 프레임의 parent블록과 같은 레벨에 있는 지역변수들을 포함할지 여부*/
	public boolean inherits(FindVarParams localVar, Block child/*, Block limit*/, boolean includesWhenParentIsChild) {
		Block parent = localVar.parent;
		if (parent==null) {
			try {
				throw new Exception("parent is null");
			} catch (Exception e) {
				
				if (Common_Settings.g_printsLog) e.printStackTrace();
			}
		}
		if (parent instanceof FindControlBlockParams) {
			FindControlBlockParams c = (FindControlBlockParams) parent;
			if (c.isVarDefinedInParenthesis(localVar) && parent==child) return true;		
		}
		if (!includesWhenParentIsChild) {			
			if (parent==child) return false;
		}
		else {
			if (parent==child) return true;
		}
		//if (parent==child) return true;
		while (true) {
			if (child==null) return false;
			if (parent==child) return true;
			if (child!=null) {
				child = child.parent;
			}
		}
	}
	
	/** 함수 인자들을 포함할 지를  includesFuncArgs을 통해 결정하고 entry의 지역변수 리스트 listOfLocalVars의 개수를 리턴한다.*/ 
	int getCountOfLocalVarsOfEntry(StackMapTable_Entry entry, boolean includesFuncArgs) {
		if (includesFuncArgs) {
			return entry.listOfLocalVars.count + this.func.listOfFuncArgs.count;
		}
		else {
			return entry.listOfLocalVars.count;
		}
	}
	
	void changeToFrameWithStackItem(StackMapTable_Entry[] stackMapTable, int frameIndex, int countOfStackItem) {
		if (countOfStackItem==1) {
			changeToFrameWithStackItem(stackMapTable, frameIndex, null);
		}
		else {
			stackMapTable[frameIndex].setFrame_type(255);
		}
	}
	
	/** stackMapTable에서 frameIndex로 정해지는 프레임을 스택 아이템 1개가 추가되도록 프레임 타입을 바꾼다.
	 * @param varUseWith1StackItem : 복합할당연산자와 3항연산을 같이 사용할 경우에 복합할당연산자의 varUseWith1StackItem, 그렇지 않으면 null*/
	void changeToFrameWithStackItem(StackMapTable_Entry[] stackMapTable, int frameIndex, FindVarUseParams varUseWith1StackItem) {
		// 1_stack_item은 full로, same_frame은 1_stack_item으로, full은 full로 바꾼다. 
		StackMapTable_Entry entry = stackMapTable[frameIndex]; 
		if (entry.getFrame_type()==entry.offset_delta+64) {				
			entry.setFrame_type(255);
		}
		else if (entry.getFrame_type()!=255) {
			entry.setFrame_type((short) (entry.offset_delta+64));
			int countOfLocalVars = entry.listOfLocalVars.count;
			int countOfFuncArgs = this.func.listOfFuncArgs.count;
			if (frameIndex==0) {
				// 함수 인자는 frameIndex가 0번에 뒤에서 넣어질 것이다.
				countOfLocalVars += countOfFuncArgs; 
			}
			if (countOfLocalVars>3) {
				entry.setFrame_type(255);
			}
			else if (countOfLocalVars==0) {
				if (varUseWith1StackItem==null || 
						varUseWith1StackItem.listOfArrayElementParams==null || varUseWith1StackItem.listOfArrayElementParams.count==0) {
					entry.setFrame_type((short) (entry.offset_delta+64));
					if (128<=entry.frame_type && entry.frame_type<=246) {
						// 보류 상태이므로 풀로 바꾼다.
						entry.setFrame_type(255);
					}
				}
				else {
					entry.setFrame_type(255);
				}
			}
			else {
				entry.setFrame_type(255);
			}
		}
		else {
			entry.setFrame_type(255);
		}
	}
	


	/*
	void processNextFrameOfSwitch(StackMapTable_Entry[] stackMapTable) {
		int i, j;
		for (i=0; i<stackMapTable.length; i++) {
			if (i==5) {
				int a;
				a=0;
				a++;
			}
			if (i-1>0) {
				StackMapTable_Entry prevEntry = stackMapTable[i-1];
				String message = prevEntry.offsetAndForLoopOfChopFrame.message;
				Block parent = prevEntry.offsetAndForLoopOfChopFrame.parent;
				if (message.contains("exit of switch")) {
					Block switchParent = parent;
					StackMapTable_Entry curEntry = stackMapTable[i];
					curEntry.setFrame_type(255);
					curEntry.isCaseAndDefaultFrame = true;
					this.inheritLocalVars(stackMapTable, i, switchParent);
					
					for (j=0; j<switchParent.listOfControlBlocks.count; j++) {
						FindControlBlockParams caseBlock = (FindControlBlockParams) switchParent.listOfControlBlocks.getItem(j);
						int k;
						for (k=0; k<caseBlock.listOfVariableParams.count; k++) {
							FindVarParams localVar = (FindVarParams) caseBlock.listOfVariableParams.getItem(k);
							if (localVar.sharedVar==null) {
								curEntry.listOfLocalVarsInheritted.add(localVar);
							}
						}
					}
				}
			}
		}
	}
	*/
	
	/*
	void processCaseAndDefaultFrame(StackMapTable_Entry[] stackMapTable) {
		int i, j;
		for (i=0; i<stackMapTable.length; i++) {
			if (i==5) {
				int a;
				a=0;
				a++;
			}
			StackMapTable_Entry entry = stackMapTable[i];
			if (entry.isChopFrame) continue;
			
			String message = entry.offsetAndForLoopOfChopFrame.message;
			Block parent = entry.offsetAndForLoopOfChopFrame.parent;
			if (message.contains("case") || message.contains("default")) {
				Block switchParent = parent.parent;
				FindControlBlockParams caseBlock = (FindControlBlockParams) parent;
				//if (caseBlock.indexInListOfControlBlocksOfParent!=0) {
				if (i+1<stackMapTable.length) {
 					StackMapTable_Entry nextEntry = stackMapTable[i+1];
					nextEntry.setFrame_type(255);
					nextEntry.isCaseAndDefaultFrame = true;
					this.inheritLocalVars(stackMapTable, i+1, switchParent);
				}
				//}
			}
		}
	}*/
	
	
	void processFullFrame(StackMapTable_Entry[] stackMapTable) {
		int i, j;
		for (i=0; i<stackMapTable.length; i++) {
			StackMapTable_Entry entry = stackMapTable[i];
			
			if (entry.isChopFrame) continue;
			
			String message = entry.offsetAndForLoopOfChopFrame.message;
			Block parent = entry.offsetAndForLoopOfChopFrame.parent;
			if (message.contains("exit")) {
				if (message.equals("exit of for")) {
					// for루프안에 다른 제어구조가 있을 경우, otherBlock의 condition과 exit of XXX의 프레임을 full 프레임으로 바꾼다.
					ArrayList listOfBlocks = StackMapTable_Helper.getInnerControlBlocks(parent);
					for (j=0; j<listOfBlocks.count; j++) {
						FindControlBlockParams otherBlock = (FindControlBlockParams) listOfBlocks.getItem(j);
						if (otherBlock!=null) {	
							
							//if (StackMapTable_Helper.hasContinueBeforeControlBlock(compiler, (FindControlBlockParams) parent, otherBlock))
							//	continue;
							int indexOfOtherBlock = 
									StackMapTable_Helper.getConditionEntryOfControlBlock(stackMapTable, i, otherBlock);
							if (indexOfOtherBlock!=-1) {
								if (stackMapTable[indexOfOtherBlock].isChopFrame) continue;
								stackMapTable[indexOfOtherBlock].setFrame_type(255);
								this.processFullFrame(stackMapTable, indexOfOtherBlock);
							}
							
							indexOfOtherBlock = 
									StackMapTable_Helper.getLastEntryOfControlBlock(stackMapTable, i, otherBlock);
							if (indexOfOtherBlock!=-1) {
								if (stackMapTable[indexOfOtherBlock].isChopFrame) continue;
								stackMapTable[indexOfOtherBlock].setFrame_type(255);
								this.processFullFrame(stackMapTable, indexOfOtherBlock);
							}
						}
					}
				}
			}
		}
	}
	
	
	void processChopFrame(StackMapTable_Entry[] stackMapTable) {
		int i;
		
		for (i=0; i<stackMapTable.length; i++) {
			
			StackMapTable_Entry entry = stackMapTable[i];
			
			FindControlBlockParams forLoop = entry.offsetAndForLoopOfChopFrame.forLoop;
			if (entry.offsetAndForLoopOfChopFrame.forLoop!=null && StackMapTable_Helper.containsOtherControlBlock(forLoop)!=null) {
				// for루프안에 다른 제어구조가 있을 경우 condition of for 프레임을 chop프레임으로 바꾼다.
				entry.setFrame_type(250);
				
				this.processChopFrame(stackMapTable, i);
			}
			/*
			if (entry.end_frame_pc==56) {
				entry.setFrame_type(250);
				entry.isChopFrame = true;
			}*/
		}
	}
	
	void processFullFrame(StackMapTable_Entry[] stackMapTable, int i) {
		
		//stackMapTable[i].tryHasControlBlock = true;
		//processChopFrame_sub(stackMapTable, i, stackMapTable[i].offsetAndForLoopOfChopFrame.parent);
		stackMapTable[i].forHasOtherControlBlock = true;
		this.inheritLocalVars(stackMapTable, i, stackMapTable[i].offsetAndForLoopOfChopFrame.parent);
	}
	
	
	/** chop 프레임의 지역변수의 개수 k값을 결정하기 위해 chop프레임과 관련된 for루프안에서 append나 full 프레임을 세고 
	 * k가 3개를 넘으면 full_frame으로 바꾼다. append나 full 프레임이 없으면 chop프레임이 아니다.
	 * @param i : chop프레임의 인덱스*/
	void processChopFrame(StackMapTable_Entry[] stackMapTable, int i) {
		int j;
		StackMapTable_Entry chopFrameEntry = stackMapTable[i];
		FindControlBlockParams forLoop = null;
		forLoop = (FindControlBlockParams) chopFrameEntry.offsetAndForLoopOfChopFrame.forLoop;
		
		StackMapTable_Entry[] listOfAppend = new StackMapTable_Entry[stackMapTable.length];
		int countOfAppend = 0;
		// stackMapTable 엔트리 중에서 offsetOfRunOfFor와 offsetOfConditionOfFor 사이에 있는 append나 full 프레임들을 센다.
		
	
		
		
		for (j=0; j<stackMapTable.length; j++) {
			StackMapTable_Entry entry = stackMapTable[j];
			//if (forLoop==entry.offsetAndForLoopOfChopFrame.parent) {
				// chop프레임과 관련된 for루프안에서 append나 full 프레임을 센다.
			if (entry.offsetAndForLoopOfChopFrame.parent==forLoop) {
				if ((252<=entry.getFrame_type() && entry.getFrame_type()<=254) || entry.getFrame_type()==255) { //APPEND or FULL
					listOfAppend[countOfAppend] = entry;
					countOfAppend++;
				}
			}
		}
		
		if (countOfAppend==0) {
			// chop 프레임이 아니다.
			chopFrameEntry.setFrame_type(251);
			return;
		}
		
		
		chopFrameEntry.isChopFrame = true;
		
		int k;
		int countOfLocalVarsOfAppends = 0;
		for (k=0; k<countOfAppend; k++) {
			countOfLocalVarsOfAppends += listOfAppend[k].listOfLocalVars.count;
		}
		
		if (/*countOfLocalVarsOfAppends==0 ||*/ countOfLocalVarsOfAppends>3) { 
			chopFrameEntry.setFrame_type(255); // 3을 넘으므로 full 프레임으로 바꾼다.			
		}
		else {
			// k = 251 - frame_type
			chopFrameEntry.setFrame_type((short) (251 - countOfLocalVarsOfAppends));
		}
		
		if (chopFrameEntry.getFrame_type()==255) {
			//processChopFrame_sub(stackMapTable, i, forLoop);
			this.inheritLocalVars(stackMapTable, i, forLoop);
		}
		
		
		
		
	}
	
	
	
	boolean isFuncArg(FindVarParams localVar) {
		int k;
		for (k=0; k<func.listOfFuncArgs.count; k++) {
			if (localVar==func.listOfFuncArgs.getItem(k)) {
				return true;
			}
		}
		return false;
	}
	
	
	
	/** 지역변수가 func 레벨에서 선언되었거나 다른 블록을 갖고 있는 for loop 레벨에서 선언되었으면 true를 리턴한다.*/
	boolean isVarAFunctionLevelOrForLoopLevelWithIFOrFOR(FindVarParams var) {
		if (var.varNameIndex()==1686) {
		}
		Block parent = var.parent;
		if (parent instanceof FindFunctionParams) return true;
		if (parent instanceof FindSpecialBlockParams) {
			FindSpecialBlockParams special = (FindSpecialBlockParams) parent;
			if (special.specialBlockType==FindSpecialBlockParams.SpecialBlockType_try) {
				if (special.parent instanceof FindFunctionParams) {
					return true;
				}
			}
		}
		if (parent instanceof FindControlBlockParams) {
			FindControlBlockParams controlBlock = (FindControlBlockParams) var.parent;
			Block block = controlBlock;
			if (controlBlock.catOfControls!=null && controlBlock.catOfControls.category==CategoryOfControls.Control_for) {
				// for괄호안에서 선언된 변수의 parent블록을 for의 parent로 바꿔준다.
				if (controlBlock.indexOfLeftParenthesis()<=var.startIndex() && var.endIndex()<=controlBlock.indexOfRightParenthesis()) {
					block = controlBlock.parent;
				}
				int i;
				// for block안에 다른 블록이 있는지를 확인한 후 있으면 true를 리턴한다.
				for (i=0; i<block.listOfStatements.count; i++) {
					FindStatementParams statement = (FindStatementParams) block.listOfStatements.getItem(i); 
					if (statement instanceof FindControlBlockParams) {
						return true;
					}
				}
			}
		}
		return false;
	}
	
	
	
	
	/** 지역변수가 func 레벨, try 레벨에서 선언되었거나 다른 블록을 갖고 있는 for loop 레벨에서 선언되었으면 true를 리턴한다.*/
	boolean isVarAFunctionLevelOrForLoopLevelWithIFOrFOR2(FindVarParams var) {
		
		Block parent = var.parent;
		
		
		if (var.sharedVar!=null) return false;
		
		//if (var.typeName.equals("java.lang.Throwable") && var.isFake)
		//	return false;
		
		if (parent instanceof FindFunctionParams) return true;
		if (parent instanceof FindSpecialBlockParams) {
			FindSpecialBlockParams special = (FindSpecialBlockParams) parent;
			if (special.specialBlockType==FindSpecialBlockParams.SpecialBlockType_try) {
				return true;
			}
			/*else if (special.specialBlockType==FindSpecialBlockParams.SpecialBlockType_catch) {
				return true;
			}*/
		}
		
		if (parent instanceof FindControlBlockParams) {
			
		}
		
		if (parent instanceof FindControlBlockParams) {
			Block block = LocalVar.isVarDefinedInForLoop(compiler, var);
			if (block!=null) {
				if (StackMapTable_Helper.hasContinueBeforeVarDecl(compiler, (FindControlBlockParams)parent, var)) {
					return false;
				}
				
				if (StackMapTable_Helper.containsOtherControlBlock(block)!=null)
					return true;
			}
		}
		
		return false;
	}
	
	
	
	/** parentOfEntryInTry의 위에 있는(감싸고 있는) 블록내 프레임들의 지역변수들을 상속한다.*/
	/*void processTheEntriesOfTry_sub(StackMapTable_Entry entryInTry, Block parentOfEntryInTry) {
		entryInTry.setFrame_type(255;
		
		if (entryInTry.end_frame_pc==78) {
			int a;
			a=0;
			a++;
		}
		
		entryInTry.listOfLocalVars.count = 0;
		entryInTry.listOfLocalVarsInheritted.count = 0;
		
		if (!func.accessModifier.isStatic) {
			entryInTry.listOfLocalVarsInheritted.add(func.thisVar);
		}
		
		int i;		
		for (i=0; i<func.listOfFuncArgs.count; i++) {
			entryInTry.listOfLocalVarsInheritted.add(func.listOfFuncArgs.getItem(i));
		}
		
		//Block child = entryInTry.offsetAndForLoopOfChopFrame.parent;
		Block child = parentOfEntryInTry;
		
		int j;
		for (i=0; i<stackMapTable.length; i++) {
			StackMapTable_Entry entry = stackMapTable[i];
			if (entry.end_frame_pc<=entryInTry.start_frame_pc) {
				for (j=0; j<entry.listOfLocalVars.count; j++) {
					FindVarParams localVar = (FindVarParams) entry.listOfLocalVars.getItem(j);
					if (this.inherits(localVar.parent, child, false)) { 
						entryInTry.listOfLocalVarsInheritted.add(localVar);
					}
				}
			}
		}
		
		entryInTry.tryHasControlBlock = true;
	}*/
	
	/*void processTheEntriesOfTry_sub_LastEntryInTry(StackMapTable_Entry entryInTry, Block parentOfEntryInTry) {
		entryInTry.setFrame_type(255;
		
		if (entryInTry.end_frame_pc==78) {
			int a;
			a=0;
			a++;
		}
		
		entryInTry.listOfLocalVars.count = 0;
		entryInTry.listOfLocalVarsInheritted.count = 0;
		
		if (!func.accessModifier.isStatic) {
			entryInTry.listOfLocalVarsInheritted.add(func.thisVar);
		}
		
		int i;		
		for (i=0; i<func.listOfFuncArgs.count; i++) {
			entryInTry.listOfLocalVarsInheritted.add(func.listOfFuncArgs.getItem(i));
		}
		
		//Block child = entryInTry.offsetAndForLoopOfChopFrame.parent;
		
		int j;
		for (i=0; i<stackMapTable.length; i++) {
			StackMapTable_Entry entry = stackMapTable[i];
			Block parent = entry.offsetAndForLoopOfChopFrame.parent;
			if (entry.end_frame_pc<entryInTry.start_frame_pc && this.inherits(parent, parentOfEntryInTry, false)) {
				for (j=0; j<entry.listOfLocalVars.count; j++) {
					entryInTry.listOfLocalVarsInheritted.add(entry.listOfLocalVars.getItem(j));
				}
			}
		}
		
		entryInTry.tryHasControlBlock = true;
	}*/
	
	
	
	
	
	void processTheEntriesOfTry(StackMapTable_Entry[] stackMapTable) {		
		int i;
		for (i=0; i<stackMapTable.length; i++) {
			
			StackMapTable_Entry entry = stackMapTable[i];
			
			String message = entry.offsetAndForLoopOfChopFrame.message;
			if (message.equals("exit of try")/* || message.equals("exit of catch")*/) {
				Block parentOfEntry = entry.offsetAndForLoopOfChopFrame.parent;
				// try의 마지막 엔트리에만 listOfLocalVars을 0으로 초기화한다.
				entry.listOfLocalVars.count = 0;
				this.inheritLocalVars(stackMapTable, i, parentOfEntry);
			}
		}
	}
	
	
	
	
	
	/** 스택맵 entry가 try 블록의 것이라면 그 다음에 나오는 catch블록이나 finally블록의 Exception_Entry를 
	 * listOfCatchEntries에 넣는다.
	 * @param catchEntry
	 * @param listOfExceptionTable
	 */
	void setException_EntriesToTryBlock(StackMapTable_Entry tryEntry, ArrayList listOfExceptionTable) {		
		if (tryEntry.listOfCatchEntries==null) {
			tryEntry.listOfCatchEntries = new ArrayList(2);
		}
		
		FindSpecialBlockParams tryBlock = (FindSpecialBlockParams) tryEntry.offsetAndForLoopOfChopFrame.parent;
				
		FindControlBlockParams[] listOfCatchBlocks = Specials.getCatchBlocksOfTry(generator, tryBlock.parent, tryBlock.indexInListOfControlBlocksOfParent);
		if (listOfCatchBlocks!=null && listOfCatchBlocks.length>0) {
			Exception_Entry entry = StackMapTable_Helper.getException_EntryOfTryOrCatch(generator, listOfCatchBlocks[0], listOfExceptionTable);
			tryEntry.listOfCatchEntries.add(entry);
		}
		FindControlBlockParams finallyBlock = Specials.getFinallyBlockOfTry(generator, tryBlock.parent, tryBlock.indexInListOfControlBlocksOfParent);
		if (finallyBlock!=null) {
			Exception_Entry entry = StackMapTable_Helper.getException_EntryOfTryOrCatch(generator, finallyBlock, listOfExceptionTable);
			tryEntry.listOfCatchEntries.add(entry);
		}
	}
	
	
	
	
	/** 스택맵 entry가 catch블록의 것이라면 그 다음에 나오는 catch블록이나 finally블록의 Exception_Entry를 
	 * listOfCatchEntries에 넣는다.
	 * @param catchEntry
	 * @param listOfExceptionTable
	 */
	void setException_EntriesToCatchBlock(StackMapTable_Entry catchEntry, ArrayList listOfExceptionTable) {	
		
		if (catchEntry.listOfCatchEntries==null) {
			catchEntry.listOfCatchEntries = new ArrayList(2);
		}
		
		FindSpecialBlockParams catchBlock = (FindSpecialBlockParams) catchEntry.offsetAndForLoopOfChopFrame.parent;
		//FindSpecialBlockParams catchBlock = StackMapTable_Helper.isStackFrameInTryOrCatchOrFinally(generator, catchEntry, input);
		
		FindControlBlockParams tryBlock = catchBlock.tryBlockConnected;
		
		FindControlBlockParams[] listOfCatchBlocks = Specials.getCatchBlocksOfTry(generator, tryBlock.parent, tryBlock.indexInListOfControlBlocksOfParent);
		int i;
		if (listOfCatchBlocks!=null && listOfCatchBlocks.length>0) {
			for (i=0; i<listOfCatchBlocks.length; i++) {
				if (catchBlock==listOfCatchBlocks[i]) {
					if (i+1<listOfCatchBlocks.length) {
						Exception_Entry entry = StackMapTable_Helper.getException_EntryOfTryOrCatch(generator, listOfCatchBlocks[i+1], listOfExceptionTable);
						catchEntry.listOfCatchEntries.add(entry);
						return;
					}
				}
			}
		}
		
		FindControlBlockParams finallyBlock = Specials.getFinallyBlockOfTry(generator, tryBlock.parent, tryBlock.indexInListOfControlBlocksOfParent);
		if (finallyBlock!=null) {
			Exception_Entry entry = StackMapTable_Helper.getException_EntryOfTryOrCatch(generator, finallyBlock, listOfExceptionTable);
			catchEntry.listOfCatchEntries.add(entry);
		}
	}
	
	
	
	
	
	boolean verifyStackMapTable(FindFunctionParams func, ByteCodeGeneratorForClass generator, int coreThreadID) {
		int i;
		int[] arrByteCodeOffset = new int[this.number_of_entries];
		arrByteCodeOffset[0] = 0;
		for (i=1; i<this.stackMapTable.length; i++) {
			StackMapTable_Entry entry = this.stackMapTable[i];
			arrByteCodeOffset[i] = arrByteCodeOffset[i-1] + /*1 +*/ entry.offset_delta;
		}
		int j;
		String message = "";
		int[] arrReferCount = new int[this.number_of_entries];
		for (j=0; j<func.listOfVariableParams.count; j++) {
			FindVarParams localVar = (FindVarParams) func.listOfVariableParams.getItem(j);
			for (i=0; i<this.stackMapTable.length; i++) {
				StackMapTable_Entry entry = this.stackMapTable[i];				
				if (entry.start_frame_pc<=localVar.start_pcOfScope) {
					if (i<stackMapTable.length-1) {
						StackMapTable_Entry nextEntry = this.stackMapTable[i+1];
						if (localVar.start_pcOfScope<nextEntry.start_frame_pc) {
							// 현재 프레임에 지역변수를 넣는다.
							arrReferCount[i]++;
							break;
						}
					}
					else {
						// 마지막 프레임일 경우
						arrReferCount[i]++;
						break;
					}
					
				}
			}//for (i=0; i<this.stackMapTable.length; i++) {
			if (arrReferCount[i]>0) {
				Verification_Type_info info = this.stackMapTable[i].locals[arrReferCount[i]-1];
				/*switch (tagShort) {
				case 0: return "Top_variable_info";
				case 1: return "Integer_variable_info";
				case 2: return "Float_variable_info";
				case 3: return "Double_variable_info";
				case 4: return "Long_variable_info ";
				case 5: return "Null_variable_info";
				case 6: return "UninitializedThis_variable_info";
				case 7: return "Object_variable_info"; // cpool_index
				case 8: return "Uninitialized_variable_info"; // offset
				}
				return "";*/
				if (info.tagShort==1 && localVar.typeName.equals("int")) continue;
				else if (info.tagShort==2 && localVar.typeName.equals("float")) continue;
				else if (info.tagShort==3 && localVar.typeName.equals("double")) continue;
				else if (info.tagShort==4 && localVar.typeName.equals("long")) continue;
				else if (info.tagShort==7 && !CompilerHelper.IsDefaultType(localVar.typeName)) {
					// object
					CONSTANT_Class_info classInfo = 
							(CONSTANT_Class_info) generator.physical.listOfConstantTable.getItem(info.cpool_index);
					String classDesc = 
							((CONSTANT_Utf8_info)generator.physical.listOfConstantTable.getItem(classInfo.name_index)).str;
					String classDesc2 = TypeDescriptor.getDescriptor(localVar.typeName, coreThreadID);
					if (!classDesc2.equals(classDesc)) {
						message = localVar.typeName + " in " + func + " is wrong.\n";
						break;
					}
					continue;
				}
				else {
					message = localVar.typeName + " in " + func + " is wrong.\n";
					break;
				}
			}//if (arrReferCount[i]>0) {
		}//for (j=0; j<func.listOfVariableParams.count; j++) {
		if (message!=null) {
			PathClassWriter.textViewCompilerMessage.setText(PathClassWriter.textViewCompilerMessage.numOfLines-1, 
					new CodeString(message+"\n\n", Common_Settings.textColor));
			PathClassWriter.textViewCompilerMessage.setHides(false);
		}
		return true;
	}
	
	/** entry의 locals를 설정한다.
	 * @param coreThreadID */
	void setVerification_type_info(StackMapTable_Entry entry, int coreThreadID) {
		//try {
		ByteCodeGeneratorForClass generator = this.generator;
		
		int i;			
		
		int specialBlockType = entry.isTryOrCatchOrFinally;
		if (specialBlockType==3 || specialBlockType==1) {
			// try, catch 블록
			if (entry.listOfCatchEntries!=null && entry.listOfCatchEntries.count>0) {
				if (entry.stack==null) {
					entry.stack = new Verification_Type_info[entry.listOfCatchEntries.count];
				}
				Exception_Entry exceptionEntry = (Exception_Entry) entry.listOfCatchEntries.getItem(0);
				
				// try, catch 블록에서 오퍼랜드 스택으로 출력하는 예외 타입
				// object type
				if (exceptionEntry.catch_type!=0) {
					entry.stack[0] = new Verification_Type_info(7);
					// CONSTANT_Class_info
					entry.stack[0].cpool_index = exceptionEntry.catch_type;
					entry.number_of_stack_items = 1;
				}
				else {
					
					// java.lang.Throwable
					entry.stack[0] = new Verification_Type_info(7);
					FindClassParams throwableClass = Loader.loadClass(compiler, "java.lang.Throwable", coreThreadID);
					//String desc = TypeDescriptor.getDescriptorExceptLAndSemicolon(throwableClass, coreThreadID);
					String desc = TypeDescriptor.getDescriptor(throwableClass, coreThreadID);
					// CONSTANT_Class_info
					HashItemOfConstantTable hashItem = (HashItemOfConstantTable) generator.physical.listOfConstantTableHashed.getData(desc);
					int indexOfCONSTANT_Class_info = -1;
					if (hashItem==null) {
						indexOfCONSTANT_Class_info = makeCONSTANT_Class_infoAndPutItIntolistOfConstantTable(desc);
					}
					else {
						indexOfCONSTANT_Class_info = hashItem.index;
					}
					try {
					entry.stack[0].cpool_index = indexOfCONSTANT_Class_info;
					}catch(Exception e) {
						if (Common_Settings.g_printsLog) e.printStackTrace();
					}
					entry.number_of_stack_items = 1;
				}
			}
			
			
		}
		
		
		if (entry.throwStartEnd!=null) {
			int countOfNestedThrow = ThrowStack.getCountOfNestedThrow(entry.throwStartEnd);
			ArrayList exceptionTypeNames = ThrowStack.getExceptionTypeNameOfNestedThrow(entry.throwStartEnd);
			Verification_Type_info[] newStack = null;
			if (entry.stack==null) {
				entry.number_of_stack_items = countOfNestedThrow;
				newStack = new Verification_Type_info[entry.number_of_stack_items];
			}
			else {
				entry.number_of_stack_items = entry.stack.length+countOfNestedThrow;
				newStack = new Verification_Type_info[entry.number_of_stack_items];
				int k;
				for (k=0; k<entry.stack.length; k++) {
					// 기존 stack을 새로운 stack으로 복사한다.
					newStack[k] = entry.stack[k];
				}	
			}
			entry.stack = newStack;
			int m;
			for (m=0; m<countOfNestedThrow; m++) {
				String typeName = (String) exceptionTypeNames.getItem(m);
				setVerification_Type_info_sub(entry, entry.number_of_stack_items-countOfNestedThrow+m, typeName, false, coreThreadID);
			}
		}
		
		
		//  i += i!=0 && j==1 && i==1 ? 3 : 2; 에서
		// 복합할당연산자와 3항연산자를 같이 사용할 경우에 lValue를 로드하는 프레임과 3항 연산자의 마지막 프레임과 
		// 그 사이에 있는 프레임(lValue스택아이템을 전달하는 프레임)에 대해서
		// i에서 1개의 스택 아이템 그리고 3과 2중에서 하나의 스택 아이템 따라서 2개가 된다.
		// i를 갖는 스택프레임은 1개의 스택아이템을 출력해야 한다.			
		if (entry.indexOfVarUseInlistOfVarsForThreeOperandsOperationWith1StackItem!=-1) {
			// 1개의 스택아이템을 추가한다.
			int k;
			FindVarUseParams varUseWith1StackItem = entry.varUseForThreeOperandsOperatorWith1StackItem;
			//String typeName = var.typeName;
			
			Verification_Type_info[] newStack = null;
			int countOfItemsAdded = 1;
			if (entry.stack==null) {
				if (varUseWith1StackItem.listOfArrayElementParams==null || varUseWith1StackItem.listOfArrayElementParams.count==0) {
					entry.number_of_stack_items = 1;
				}
				else {
					// lValue가 배열원소일 경우, 추가되는 아이템수는 배열의 차원에 상관없이 항상 3개를 갖는다.
					countOfItemsAdded = 1+1+1;
					entry.number_of_stack_items = countOfItemsAdded;
				}
				newStack = new Verification_Type_info[entry.number_of_stack_items];
			}
			else {
				if (varUseWith1StackItem.listOfArrayElementParams==null || varUseWith1StackItem.listOfArrayElementParams.count==0) {
					entry.number_of_stack_items = entry.stack.length+1;
				}
				else {
					// lValue가 배열원소일 경우, 추가되는 아이템수는 배열의 차원에 상관없이 항상 3개를 갖는다.
					countOfItemsAdded = 1+1+1;
					entry.number_of_stack_items = entry.stack.length+countOfItemsAdded;
				}
				newStack = new Verification_Type_info[entry.number_of_stack_items];
				for (k=0; k<entry.stack.length; k++) {
					// 기존 stack을 새로운 stack으로 복사한다.
					newStack[k] = entry.stack[k];
				}
			}
			entry.stack = newStack;
			// 1개의 스택아이템을 추가한다.
			setVerification_Type_info_sub(entry, entry.number_of_stack_items-countOfItemsAdded, varUseWith1StackItem, false, coreThreadID);
			
		}
		
		
		// 3항 연산자의 마지막 프레임에 대해서
		if (entry.offsetAndForLoopOfChopFrame.typeNameForThreeOperandsOperation!=null) {
			String typeName = entry.offsetAndForLoopOfChopFrame.typeNameForThreeOperandsOperation;
			if (entry.stack==null) {
				
				if (entry.offsetAndForLoopOfChopFrame.indexOfVarUseInlistOfLValueForThreeOperandsOperationWith1StackItem==-1) {
					// 3항 연산자만 있을 경우
					entry.number_of_stack_items = 1;
					entry.stack = new Verification_Type_info[entry.number_of_stack_items];						
					setVerification_Type_info_sub(entry, 0, typeName, false, coreThreadID);
						
				}
				else {
					// 1스택아이템을 가져야하는 3항 연산자의 마지막 프레임에 대해서
					
					// lValue에서 넘어오는 스택 아이템들의 개수
					int countOfItemsAdded = 0;
					FindVarUseParams varUseWith1StackItem = (FindVarUseParams) entry.offsetAndForLoopOfChopFrame.listOfVarUseForThreeOperandsOperationWith1StackItem.getItem(
							entry.offsetAndForLoopOfChopFrame.indexOfVarUseInlistOfLValueForThreeOperandsOperationWith1StackItem);
					
					if (varUseWith1StackItem.listOfArrayElementParams==null || varUseWith1StackItem.listOfArrayElementParams.count==0) {
						entry.number_of_stack_items = 2;
						entry.stack = new Verification_Type_info[entry.number_of_stack_items];
						
						int k;
						//  i += i!=0 && j==1 && i==1 ? 3 : 2; 에서
						// i에서 1개의 스택 아이템 그리고 3과 2중에서 하나의 스택 아이템 따라서 2개가 된다.							
						
						for (k=0; k<entry.number_of_stack_items; k++) {
							setVerification_Type_info_sub(entry, k, typeName, false, coreThreadID);
							
						}
					}
					else {
						// lValue가 배열원소일 경우, 추가되는 아이템수는 배열의 차원에 상관없이 항상 3개를 갖는다.
						countOfItemsAdded = 1+1+1;
						entry.number_of_stack_items = countOfItemsAdded + 1;
						entry.stack = new Verification_Type_info[entry.number_of_stack_items];
						
						FindVarParams var = varUseWith1StackItem.getOriginalVar();
						String elementTypeName = Array.getArrayElementType(var.typeName);
						
						int newIndex = 0;
						setVerification_Type_info_sub(entry, newIndex, elementTypeName+"[]", false, coreThreadID);
						
						
						newIndex++;
						setVerification_Type_info_sub(entry, newIndex, "int", false, coreThreadID);
						
						newIndex++;							
						setVerification_Type_info_sub(entry, newIndex, elementTypeName, false, coreThreadID);
						
						newIndex++;
						setVerification_Type_info_sub(entry, newIndex, typeName, false, coreThreadID);
					}
					
					
				}					
				
			}
		}
		
		
		ArrayList listOfLocalVars = entry.listOfLocalVars;
		
		
		
		if (entry.locals==null) {
			if (entry.getFrame_type()==255) {
				// full프레임일 경우 상속한 entry.listOfLocalVarsInheritted을 먼저 찍고 
				// 그 다음에 entry.listOfLocalVars 을 출력한다.
				entry.locals = new Verification_Type_info[
				        entry.listOfLocalVarsInheritted.count + listOfLocalVars.count];					
			}
			else {
				entry.locals = new Verification_Type_info[listOfLocalVars.count];
			}
			entry.number_of_locals = entry.locals.length;
		}
		
		int k;
		int countOfLocalVarsOfFullFrame = 0;
		for (k=0; k<2; k++) {
			if (k==0) {
				if (entry.getFrame_type()==255) {
					// full프레임일 경우 상속한 entry.listOfLocalVarsInheritted을 먼저 찍고 
					// 그 다음에 entry.listOfLocalVars 을 출력한다.
					listOfLocalVars = entry.listOfLocalVarsInheritted;
				}
				else {
					// full프레임이 아닐 경우  entry.listOfLocalVars만 출력한다.
					continue;
				}
			}
			else {
				if (entry.getFrame_type()==255) {
					// full프레임일 경우 상속한 entry.listOfLocalVarsInheritted을 먼저 찍고 
					// 그 다음에 entry.listOfLocalVars 을 출력한다.
					//  entry.listOfLocalVars을 출력하기 위해 countOfLocalVarsOfFullFrame을 바꾼다.
					countOfLocalVarsOfFullFrame = entry.listOfLocalVarsInheritted.count;
					listOfLocalVars = entry.listOfLocalVars;
				}
			}
			for (i=0; i<listOfLocalVars.count; i++) {
				FindVarParams var = (FindVarParams) listOfLocalVars.getItem(i);
				
				setVerification_Type_info_sub(entry, countOfLocalVarsOfFullFrame+i, var.typeName, true, coreThreadID);
				
			}//for (i=0; i<listOfLocalVars.count; i++) {
		}//for (k=0; k<2; k++) {
	}
	
	
	
	/**varUseWith1StackItem의 타입을 entry.locals 또는 entry.stack에 쓴다. 
	 * @param index : entry의 locals[] 또는 stack[] 에서의 인덱스
	 * @param typeName : entry의 locals 또는 stack에 넣어질 var의 타입이름
	 * @param isLocalsOrStack : locals에 넣어지면 true, stack에 넣어지면 false
	 * @param coreThreadID 
	 */
	void setVerification_Type_info_sub(StackMapTable_Entry entry, int index, FindVarUseParams varUseWith1StackItem, boolean isLocalsOrStack, int coreThreadID) {
		if (varUseWith1StackItem.listOfArrayElementParams==null || varUseWith1StackItem.listOfArrayElementParams.count==0) {
			// varUseWith1StackItem는 일반변수이다.
			String typeName = null;
			if (varUseWith1StackItem.tokenInPostfix.typeFullNameAfterOperation==null) {
				typeName = varUseWith1StackItem.tokenInPostfix.typeFullName;
			}
			else {
				typeName = varUseWith1StackItem.tokenInPostfix.typeFullNameAfterOperation;
			}
			setVerification_Type_info_sub(entry, index, typeName, isLocalsOrStack, coreThreadID);
		}
		else {
			
			
			// varUseWith1StackItem는 배열이다.
			int newIndex = index;
			FindVarParams var = varUseWith1StackItem.getOriginalVar();
			String typeName = var.typeName;
			String elementTypeName = Array.getArrayElementType(typeName);
			
			setVerification_Type_info_sub(entry, index, elementTypeName+"[]", isLocalsOrStack, coreThreadID);
			
			// 첨자들의 타입을 출력한다.
			newIndex++;
			setVerification_Type_info_sub(entry, newIndex, "int", isLocalsOrStack, coreThreadID);
			
			newIndex++;				
			setVerification_Type_info_sub(entry, newIndex, elementTypeName, isLocalsOrStack, coreThreadID);
		}
	}
	
	/**@param index : entry의 locals[] 또는 stack[] 에서의 인덱스
	 * @param typeName : entry의 locals 또는 stack에 넣어질 var의 타입이름
	 * @param isLocalsOrStack : locals에 넣어지면 true, stack에 넣어지면 false
	 * @param coreThreadID 
	 */
	void setVerification_Type_info_sub(StackMapTable_Entry entry, int index, String typeName, boolean isLocalsOrStack, int coreThreadID) {
		
		if (!isLocalsOrStack) {				
			if (CompilerHelper.IsDefaultType(typeName)) {
				if (typeName.equals("long")) {
					entry.stack[index] = new Verification_Type_info(4);
				}
				else if (typeName.equals("float")) {
					entry.stack[index] = new Verification_Type_info(2);
				}
				else if (typeName.equals("double")) {
					entry.stack[index] = new Verification_Type_info(3);
				}
				else {
					// byte, char, short, int
					entry.stack[index] = new Verification_Type_info(1);
				}
			}
			else {
				// object type
				entry.stack[index] = new Verification_Type_info(7);
				String desc = TypeDescriptor.getDescriptor(typeName, coreThreadID);
				//String desc = TypeDescriptor.getDescriptorExceptLAndSemicolon(typeName, coreThreadID);
				// CONSTANT_Class_info
				//HashItemOfConstantTable hashItem = (HashItemOfConstantTable) generator.listOfConstantTableHashed.getData(desc);
				HashItemOfConstantTable hashItem = (HashItemOfConstantTable) generator.physical.listOfConstantTableHashed.getData(desc);
				int indexOfCONSTANT_Class_info = -1;
				if (hashItem==null) {
					// listOfConstantTableHashed에 없으면
					// 예를들어 classA.arr[0] += 1>0 ? 3 : 2;에서 arr(타입은 int[])은 listOfConstantTableHashed에 들어가지 않는다.
					// 그래서 여기에서 추가를 한다.
					indexOfCONSTANT_Class_info = makeCONSTANT_Class_infoAndPutItIntolistOfConstantTable(desc);
				}
				else {
					indexOfCONSTANT_Class_info = hashItem.index;
				}
				entry.stack[index].cpool_index = indexOfCONSTANT_Class_info;
			}
		}// if (!isLocalsOrStack) {	
		else {
			if (CompilerHelper.IsDefaultType(typeName)) {
				if (typeName.equals("long")) {
					entry.locals[index] = new Verification_Type_info(4);
				}
				else if (typeName.equals("float")) {
					entry.locals[index] = new Verification_Type_info(2);
				}
				else if (typeName.equals("double")) {
					entry.locals[index] = new Verification_Type_info(3);
				}
				else {
					// byte, char, short, int
					entry.locals[index] = new Verification_Type_info(1);
				}
			}
			else {				
				// object type
				entry.locals[index] = new Verification_Type_info(7);
				String desc = TypeDescriptor.getDescriptor(typeName, coreThreadID);
				//String desc = TypeDescriptor.getDescriptorExceptLAndSemicolon(typeName, coreThreadID);
				// CONSTANT_Class_info
				HashItemOfConstantTable hashItem = (HashItemOfConstantTable) generator.physical.listOfConstantTableHashed.getData(desc);
				int indexOfCONSTANT_Class_info = -1;
				if (hashItem==null) {
					indexOfCONSTANT_Class_info = makeCONSTANT_Class_infoAndPutItIntolistOfConstantTable(desc);
				}
				else {
					indexOfCONSTANT_Class_info = hashItem.index;
				}
				entry.locals[index].cpool_index = indexOfCONSTANT_Class_info;					
			}
		}
	}
	
	static class ItemOfConstantTableAddedInStackMap {
		int indexOfConstantTable;
		CONSTANT_Class_info classInfo;
		ItemOfConstantTableAddedInStackMap(int indexOfConstantTable, CONSTANT_Class_info classInfo) {
			this.indexOfConstantTable = indexOfConstantTable;
			this.classInfo = classInfo; 
		}
	}
	
	/** ItemOfConstantTableAddedInStackMap[]*/
	ArrayList listOfItemOfConstantTableAddedInStackMap = new ArrayList(10);
	public int readBytesLen;
	
	/** 스택맵 테이블에서 추가되는 오브젝트 타입의 타입(cpool_index에 CONSTANT_Class_info의 컨스턴트 테이블의 인덱스가 들어간다.)을 체크하기 위해서
	 *  listOfConstantTableHashed에 들어가지 않은 
	 * CONSTANT_Class_info와 CONSTANT_Utf8_info를 추가적으로 listOfConstantTable에 넣는다.
	 * @return CONSTANT_Class_info의 listOfConstantTable에서의 인덱스*/
	int makeCONSTANT_Class_infoAndPutItIntolistOfConstantTable(String typeDesc) {
		ByteCodeGeneratorForClass generator = this.generator;
		HashItemOfConstantTable classInfoItem = (HashItemOfConstantTable) generator.physical.listOfConstantTableHashed.getData(typeDesc); 
		if (classInfoItem==null) {
			ArrayList listOfConstantTable = generator.physical.listOfConstantTable;
			int i;
			// 여기에서 추가된 아이템들의 리스트에서 typeDesc로 검색한다.
			for (i=0; i<listOfItemOfConstantTableAddedInStackMap.count; i++) {
				ItemOfConstantTableAddedInStackMap item = (ItemOfConstantTableAddedInStackMap) listOfItemOfConstantTableAddedInStackMap.getItem(i);
				if (item.classInfo.classNameDescriptor.equals(typeDesc))
					return item.indexOfConstantTable;
			}
			
			CONSTANT_Class_info classInfo = new CONSTANT_Class_info(typeDesc, compiler);
			classInfo.tag = 7;
			listOfConstantTable.add(classInfo);				
			
			int r = listOfConstantTable.count-1;
			
			this.listOfItemOfConstantTableAddedInStackMap.add(new ItemOfConstantTableAddedInStackMap(r, classInfo));
			
			CONSTANT_Utf8_info utf8Info = new CONSTANT_Utf8_info((byte)1, 
					(short)typeDesc.length(), typeDesc);
			HashItemOfConstantTable utf8Item = 
					(HashItemOfConstantTable) generator.physical.listOfConstantTableUtf8Hashed.getData(typeDesc);
			if (utf8Item==null) {
				int indexOfUtf8Hashed = listOfConstantTable.count;
				listOfConstantTable.add(utf8Info);				
				classInfo.name_index = (short) indexOfUtf8Hashed;
			}
			else {
				classInfo.name_index = (short) utf8Item.index;
			}
			return r;
		}
		else {
			return classInfoItem.index;
		}
	}
	
	StackMapTable_Entry makeStackMapTable_Entry(int start_frame_pc, OffsetAndForLoopAndParent offset_delta) {
		StackMapTable_Entry r = new StackMapTable_Entry(this);
		r.start_frame_pc = start_frame_pc;
		r.offset_delta = offset_delta.offsetOrOffsetDelta;
		r.end_frame_pc = start_frame_pc + offset_delta.offsetOrOffsetDelta;
		return r;
	}
	
	/** attribute_name_index, attribute_length 6바이트를 제외한 StackMapTable_attribute의 길이<br>
	 * number_of_entries(u2) + stackMapTable의 바이트 길이*/
	public int getAttributeLength() {
		int lengthOfTable = 2; // number_of_entries(u2)
		int i;
		for (i=0; i<number_of_entries; i++) {
			lengthOfTable += stackMapTable[i].getAttributeLength();
		}
		return lengthOfTable;
	}
	
	/** number_of_entries와 entry들을 쓴다.*/
	void write(OutputStream output, boolean isLittleEndian) {
		int i;
		
		// number_of_entries 쓰기, u2			
		IO.writeShort(output, (short)number_of_entries, isLittleEndian);
		
		for (i=0; i<this.number_of_entries; i++) {
			this.stackMapTable[i].write(output, isLittleEndian);
		}
	}
	
	public String toString() {
		String r = "StackMapTable number_of_entries="+number_of_entries+"\n";
		int i;
		for (i=0; i<number_of_entries; i++) {
			r += "// "+stackMapTable[i] + "\n";
		}
		return r;
	}
	

	@Override
	public void destroy() {
		
		if (this.stackMapTable!=null) {
			int i;
			for (i=0; i<this.number_of_entries; i++) {
				this.stackMapTable[i].destroy();
				this.stackMapTable[i] = null;
			}
			this.stackMapTable = null;
		}
	}

}