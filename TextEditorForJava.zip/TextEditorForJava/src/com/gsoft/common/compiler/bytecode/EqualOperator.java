package com.gsoft.common.compiler.bytecode;

import com.gsoft.common.Common_Settings;
import com.gsoft.common.compiler.Array;
import com.gsoft.common.compiler.CodeStringEx;
import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.Compiler_types.FindFuncCallParam;
import com.gsoft.common.compiler.Compiler_types.FindFunctionParams;
import com.gsoft.common.compiler.Compiler_types.FindVarUseParams;
import com.gsoft.common.compiler.Expression;
import com.gsoft.common.compiler.Expression.ReturnOfgetTypeOfVarUseOrFuncCallOfFullName2_sub;
import com.gsoft.common.compiler.Fullname;
import com.gsoft.common.compiler.HighArray_CodeString;
import com.gsoft.common.compiler.bytecode.ByteCode_Helper.ReturnOfgetIndexWhenContainingEqual;
import com.gsoft.common.compiler.classloader.Loader;
import com.gsoft.common.util.ArrayListChar;
import com.gsoft.common.util.ArrayListIReset;
import com.gsoft.common.util.ArrayListInt;

import com.gsoft.common.compiler.bytecode.ByteCodeGeneratorForClass;
import com.gsoft.common.compiler.bytecode.HighArrayCharForByteCode;
import com.gsoft.common.compiler.bytecode.ByteCode_Helper;
import com.gsoft.common.compiler.bytecode.TypeDescriptor;
import com.gsoft.common.compiler.bytecode.ArrayInitializer;
import com.gsoft.common.compiler.bytecode.TypeCast;
import com.gsoft.common.compiler.bytecode.LocalVar;

public class EqualOperator {
	/** a = 1+(a=2)+3;에서 token은 두번째 a이다.<br>
	 * 중첩된 대입연산자의 lValue를 다시 스택에 로드해야 한다.
		밑에 있는 traverseExpressionTree()에서 lValue의 rValue를 null로 안하면
		traverseLValue()가 호출되어 결과가 틀리게 나오기 때문에
		위에서 저장된 lValue를 로드만 해야 하기 때문에 rValue를 null로 만들어 준 후
		아래와 같이 token에 대해서 traverseExpressionTree()를 호출하여
		저장된 lValue를 스택에 로드한다. 
	 * @param token : a = 1+(a=2)+3;에서 token은 두번째 a이다
	 * @param funcCall : 첫번째 a의 rValue
	 * @return : 중첩된 대입연산자를 포함할 경우 첫번째 a의 rValue의 포스트픽스 상에서 두번째 =의 위치를 리턴하고
	 *  	중첩된 대입연산자를 포함하지 않으면 -1을 리턴한다.*/
	public static int loadLValueInNestedEqualOperator(ByteCodeGeneratorForClass generator, HighArray_CodeString src, FindFuncCallParam funcCall, CodeStringEx token, HighArrayCharForByteCode result) {
		Compiler compiler = generator.compiler;
		
		// a = 1+(a=2)+3;에서 token은 두번째 a이다.
		int j = -1;
		ReturnOfgetIndexWhenContainingEqual r = ByteCode_Helper.getIndexWhenContainingEqual(compiler, token, funcCall);
		if (r!=null && r.index>=0) {
			// 중첩된 대입연산자의 lValue를 다시 스택에 로드해야 한다.
			// 밑에 있는 traverseExpressionTree()에서 lValue의 rValue를 null로 안하면
			// traverseLValue()가 호출되어 결과가 틀리게 나오기 때문에
			// 위에서 저장된 lValue를 로드만 해야 하기 때문에 rValue를 null로 만들어 준 후
			// 아래와 같이 token에 대해서 traverseExpressionTree()를 호출하여
			// 저장된 lValue를 스택에 로드한다.
			FindFuncCallParam backupRValue = r.lValue.rValue;
			r.lValue.rValue = null;
			
			// 토큰 두번째 a에 대해서
			int k;
			for (k=0; k<token.listOfVarUses.count; k++) {
				// 오퍼랜드 하나에 있는 varUse들에 대해서 재귀적 호출을 한다.
				FindVarUseParams child = null;
				child = (FindVarUseParams) token.listOfVarUses.getItem(k);
				if (child!=null) {
					generator.traverseExpressionTree(src, child, result);
					k = ByteCode_Helper.getIndex(compiler, token, child, k);									
					
				}//if (child!=null) {
			}//for (k=0; k<token.listOfVarUses.count; k++) {
			r.lValue.rValue = backupRValue;
			
			// 중첩된 대입연산자가 포함된 경우에만 대입연산자 위치로 점프한다.
			j = r.index;
		}//if (r.index>=0) {
		return j;
	}
	
	
	public static void traverseLValue(ByteCodeGeneratorForClass generator, HighArray_CodeString src, FindVarUseParams varUse, int indexInmBuffer, HighArrayCharForByteCode result, int coreThreadID) {		
		
		
		Compiler compiler = generator.compiler;
		
		
		//Compiler.getIndexInmListOfAllVarUses(src, compiler.data.mlistOfAllVarUses, 0, indexOfEqual+1, true);
		if (varUse.arrayInitializer==null) {
			if (varUse.rValue.expression.postfix==null) {
				varUse.rValue.typeFullName = 
						Expression.getTypeOfExpression(compiler, varUse.rValue, coreThreadID);
				if (varUse.rValue.expression.postfix==null) {
					return;
				}
			}
			
		}
		
		// this가 앞에 붙으면 이 함수의 가장 밑에서 처리한다.
		if (!varUse.isArrayElement) {
			// 배열원소에 저장할 때는 traverseArrayElement()에서 출력하므로
			// 배열이 아닌 일반 멤버변수에 저장하는 putfield 일 때만 this를 출력한다.
			if (varUse.parent==null && varUse.isUsingThisOrSuper) {	
				// putfield 일때만
				// var(var는 인스턴스변수) = i + 2; 이와 같은 경우 다음과 같이
				// 가장 앞에서 rValue 를 계산하기 전에 this 를 load 해야 한다.
				// aload this
				// iload i
				// bipush 2
				// iadd
				// putfield var
				String strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, varUse.index());
				FindClassParams parentClass = (FindClassParams)varUse.classToDefineThisVarUse;
				String thisStr = TypeDescriptor.getDescriptorOfThis(parentClass, coreThreadID);
				result.add("aload_0 // local "+thisStr+strmBufferIndex+"\n");
			}
		}
		
		if (varUse.arrayInitializer!=null) {			
			ArrayInitializer.makeLocalVarsForArrayInit(generator, varUse.arrayInitializer);
			
			//traverseArrayIntializer2(src, varUse.arrayInitializer, varUse.arrayInitializer, result);
			ArrayInitializer.traverseArrayIntializer(generator, src, varUse.arrayInitializer, varUse.arrayInitializer, result, coreThreadID);
			//return;
		}
		else {
						
			int endIndexOfLValue = Fullname.getFullNameIndex(compiler,  false, varUse.index(), false);
			
			int startIndexOfOperator = CompilerHelper.SkipBlank(src, false, endIndexOfLValue+1, src.count-1);
			int endIndexOfOperator = compiler.IsLValue(src, varUse);
			
			String operator = Fullname.getFullName(src, startIndexOfOperator, endIndexOfOperator).str;
		
			// rValue를 traverse
			//CodeStringEx typeFullNameOfRValue = null;
			String rValueType = null;
			String lValueType = null;
			if (operator.length()==1) {	 // 일반적인 = 연산자
				FindFuncCallParam funcCall = varUse.rValue;
				generator.traverseChild(funcCall, result, coreThreadID);
				if (varUse.rValue.typeFullName!=null) {
					rValueType = varUse.rValue.typeFullName.str;
				}
			}
			else {
				// 복합 대입연산자  
				// a+=2; 여기에서 a로드, 2로드(traverseChild()), add까지 한다.
				CodeStringEx typeFullNameOfRValue = traverseCompositiveEqualOperator(generator, src, varUse, result, coreThreadID);
				rValueType = typeFullNameOfRValue.typeFullNameAfterOperation==null ? 
						typeFullNameOfRValue.typeFullName : typeFullNameOfRValue.typeFullNameAfterOperation;
			}
			
			
			// 타입캐스트
			//float x=0;  x -= 3; // 복합할당연산자의 경우에는 제외한다.
			if (rValueType!=null) {
				if (CompilerHelper.IsDefaultType(rValueType)) {
					lValueType = varUse.varDecl.typeName;
					if (Array.getArrayDimension(compiler, lValueType)!=0) {
						lValueType = Array.getArrayElementType(lValueType);
					}
					TypeCast.printTypeCast(generator, rValueType, lValueType, result, varUse.rValue.startIndex(), coreThreadID);
				}
				else {
					// object type
				}
			}
		}//배열초기화가 아니면

		// lValue 출력
		
		if (!varUse.isArrayElement) {
			try {
				if (varUse.varDecl==null) return;
			if (varUse.varDecl.isMemberOrLocal) { 
				//멤버변수에 저장, putfield, putstatic
				generator.printMemberVarUse(varUse, result, false, coreThreadID);
			}
			else {//지역변수에 저장, istore, astore 등
				LocalVar.printLocalVar(generator, varUse, result, false, coreThreadID);
			}
			}catch(Exception e) {
				if (Common_Settings.g_printsLog) e.printStackTrace();
			}
		}
		else { 
			// 배열에 저장
			// arr[0] = i; 에서 varUse는 arr이다. 
			// aastore, iastore 등은 스택상태가 arrRef, index(첨자), value(rValue) 이어야 한다.
			// 따라서 arrRef, index(첨자)는 미리 스택에 로드되어 있어야 하고 rValue를 계산한 후에
			// value가 스택에 로드되면 aastore 등을 출력한다.
			int curDimension = Array.getArrayDimension(compiler, varUse.name);
			int dimensionOfArray = Array.getArrayDimension(compiler, varUse.varDecl.typeName);
			// int[][] arr = new int[3][2];
			// arr[0] = new int[3];
			// varUse is arr in arr[0]. curDimension is 1.  
			generator.printArrayElement(varUse, result, curDimension-1, dimensionOfArray, false);
		}
		
		

	}
	
	
	

	
	
	/**traverseLValue()에서 호출하여 복합 대입연산자를 출력한다. 
	 * lValue로드, rValue로드, 할당연산자를 제외한 나머지 연산자 출력을 한다.
	   a+=2; 여기에서 a로드, 2로드(traverseChild()), add까지 한다.
	   @param varUse : lValue
	 * @param coreThreadID */
	public static CodeStringEx traverseCompositiveEqualOperator(ByteCodeGeneratorForClass generator, HighArray_CodeString src, FindVarUseParams varUse, HighArrayCharForByteCode result, int coreThreadID) {
		if (varUse.index()==215) {
		}
		
		Compiler compiler = generator.compiler;
		
		int endIndexOfLValue = Fullname.getFullNameIndex(compiler,  false, varUse.index(), false);
		
		int startIndexOfOperator = CompilerHelper.SkipBlank(src, false, endIndexOfLValue+1, src.count-1);
		int endIndexOfOperator = compiler.IsLValue(src, varUse);
		
		String operator = Fullname.getFullName(src, startIndexOfOperator, endIndexOfOperator).str;
		String operatorExceptEqual = null;
		CodeStringEx operatorEx = null;
		
		CodeStringEx tokenOfLValue = null;
		CodeStringEx tokenOfRValue = null;
		
		CodeStringEx typeOfRValue = null;
		
		// 복합 대입연산자("+=", "-=", "*=" 등)에 대해서만
		// int ab=0;
		// int ba=ab+(ab+=2)+3; 여기에서 두번째 ab
		// ba=ab-(ab-=2.3f+2)*3; 여기에서 두번째 ab
		int startIndexOfLValue = Fullname.getFullNameIndex(compiler, true, varUse.index(), true);
		int startIndexOfLValueInmListOfAllVarUses = Compiler.getIndexInmListOfAllVarUses(
				compiler.data.mBuffer, compiler.data.mlistOfAllVarUses, 0, 
				startIndexOfLValue, true);
		int endIndexOfLValueInmListOfAllVarUses = Compiler.getIndexInmListOfAllVarUses(
				compiler.data.mBuffer, compiler.data.mlistOfAllVarUses, startIndexOfLValueInmListOfAllVarUses, 
				endIndexOfLValue, false);
				
		
		
		CodeStringEx typeOfLValue;
		ReturnOfgetTypeOfVarUseOrFuncCallOfFullName2_sub r = 
				Expression.getTypeOfVarUseOrFuncCallOfFullName(compiler, src, startIndexOfLValue, coreThreadID);
		typeOfLValue = r.typeFullName;
		
		typeOfRValue = new CodeStringEx(varUse.rValue.typeFullName.str);
		
		// 복합 대입연산자("+=", "-=", "*=" 등)에서 "="을 제외한 연산자를 구한다.
		operatorExceptEqual = operator.substring(0, operator.length()-1);
		operatorEx = new CodeStringEx(operatorExceptEqual);
		operatorEx.typeFullName = varUse.rValue.typeFullName.str;
		operatorEx.isPlusOrMinusForOne = false;
		
		ArrayListInt indicesInSrc = new ArrayListInt(1);
		indicesInSrc.add(startIndexOfOperator);
		operatorEx.indicesInSrc = indicesInSrc;
		
		FindFuncCallParam funcCall = new FindFuncCallParam(compiler, startIndexOfLValue, varUse.rValue.endIndex());
		ArrayListIReset listOfTypes = new ArrayListIReset(2);
		listOfTypes.add(typeOfLValue);
		listOfTypes.add(typeOfRValue);
		tokenOfLValue = new CodeStringEx(typeOfLValue.str);
		tokenOfRValue = new CodeStringEx(typeOfRValue.str);
		tokenOfLValue.typeFullName = typeOfLValue.str;
		tokenOfRValue.typeFullName = typeOfRValue.str;
		typeOfLValue.operandOrOperator = tokenOfLValue;
		typeOfRValue.operandOrOperator = tokenOfRValue;
		
		
		// int ab=0;
		// ba=ab-(ab-=2.3f+2)*3; 여기에서 두번째 ab
		// 두번째 ab와 2.3f+2에 "-"연산을 할때 오퍼랜드들의 
		// 묵시적 타입캐스팅(typeFullNameAfterOperation)을 정한다.
		// 두번째 ab는 int이고 rValue의 타입은 float이므로 "-"연산을 할때 두번째 ab의 타입을 float로 바꿔야 한다.
		CodeStringEx typeOfOperator = 
				Expression.getTypeOfOperator(compiler, funcCall, listOfTypes, operatorEx, coreThreadID);
		if (typeOfOperator!=null) {
			operatorEx.typeFullName = typeOfOperator.str;
		}
		
		
		
		
		//FindFuncCallParam funcCall = new FindFuncCallParam(compiler, startIndexOfLValue, varUse.rValue.endIndex());
		//Expression.getTypeOfExpression(compiler, src, funcCall);
		//tokenOfLValue = funcCall.expression.postfix[0];
	
		
		if (tokenOfLValue.typeFullName.equals("java.lang.String") && operatorEx.equals("+")) {
			int srcIndex = funcCall.startIndex();
			String strmBufferIndex = ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(generator.compiler, srcIndex);
			
			FindClassParams classStringBuilder = Loader.loadClass(compiler, "java.lang.StringBuilder", coreThreadID);
			ArrayListChar message = new ArrayListChar(30);
			message.add("new // ");
			message.add(TypeDescriptor.getDescriptorExceptLAndSemicolon(classStringBuilder, coreThreadID)+
					ByteCode_Helper.getSourceLineNumber(generator.compiler, srcIndex));
			message.add("\n");
			result.add(new String(message.getItems()));
			result.add("dup // "+strmBufferIndex+"\n");
			
			// java.lang.StringBuilder의 인자가 없는 <init>()를 호출한다.
			FindFunctionParams constructorOfStringBuilder = 
					ByteCode_Helper.getConstructorOfStringBuilder(compiler, null, srcIndex, coreThreadID);
			generator.physical.makeCONSTANT_Method_infoAndPutItIntolistOfConstantTable(constructorOfStringBuilder, coreThreadID);						
			
			result.add("invokespecial // "+constructorOfStringBuilder.getMethodInfoStr(coreThreadID)+ByteCode_Helper.getSourceLineNumber(generator.compiler, srcIndex)+"\n");
		}
		
		
		
		
		////////////////  lValue를 로드한다. start /////////////////////////
		
		// 중첩된 대입연산자의 lValue를 다시 스택에 로드해야 한다.
		// 밑에 있는 traverseExpressionTree()에서 lValue의 rValue를 null로 안하면
		// traverseLValue()가 호출되어 결과가 틀리게 나오기 때문에
		// 위에서 저장된 lValue를 로드만 해야 하기 때문에 rValue를 null로 만들어 준 후
		// 아래와 같이 token에 대해서 traverseExpressionTree()를 호출하여
		// 저장된 lValue를 스택에 로드한다.
		FindFuncCallParam backupRValue = varUse.rValue;
		varUse.rValue = null;
				
		int k;
		for (k=startIndexOfLValueInmListOfAllVarUses; k<=endIndexOfLValueInmListOfAllVarUses; k++) {
			// 오퍼랜드 하나에 있는 varUse들에 대해서 재귀적 호출을 한다.
			FindVarUseParams child = (FindVarUseParams) compiler.data.mlistOfAllVarUses.getItem(k);
			if (child!=null) {
				generator.traverseExpressionTree(src, child, result);
				//k = getIndex(token, child, k);
				k = generator.jump(child, k);
				
			}//if (child!=null) {
		}//for (k=0; k<token.listOfVarUses.count; k++) {
		varUse.rValue = backupRValue;
	
		
		if (tokenOfLValue.typeFullName.equals("java.lang.String") && operatorEx.equals("+")) {
			int srcIndex = funcCall.startIndex();
			FindFunctionParams appendOfStringBuilder = 
					ByteCode_Helper.getAppendOfStringBuilder(compiler, tokenOfLValue.typeFullName, srcIndex, coreThreadID);
			generator.physical.makeCONSTANT_Method_infoAndPutItIntolistOfConstantTable(appendOfStringBuilder, coreThreadID);				
			
			result.add("invokevirtual // "+appendOfStringBuilder.getMethodInfoStr(coreThreadID)+ByteCode_Helper.getSourceLineNumber(generator.compiler, srcIndex)+"\n");
		}
		else {
			// int ab=0;
			// ba=ab-(ab-=2.3f+2)*3; 여기에서 두번째 ab
			// 두번째 ab는 int이고 rValue의 타입은 float이므로 "-"연산을 할때 두번째 ab의 타입을 float로 바꿔야 한다.
			if (tokenOfLValue!=null && tokenOfLValue.getTypeFullNameOrTypeFullNameAfterOperation()!=null) {
				TypeCast.printTypeCast(generator,  tokenOfLValue.typeFullName, 
						tokenOfLValue.getTypeFullNameOrTypeFullNameAfterOperation(), result, varUse.index(), coreThreadID);
			}
		}
		//////////////// lValue를 로드한다. end /////////////////////////
		
		
		//////////////// rValue를 로드한다. start ///////////////////////
		FindFuncCallParam funcCallOfRValue = varUse.rValue;
		generator.traverseChild(funcCallOfRValue, result, varUse, coreThreadID);
		
		if (tokenOfLValue.typeFullName.equals("java.lang.String") && operatorEx.equals("+")) {
			int srcIndex = funcCallOfRValue.endIndex();
			// java.lang.StringBuilder의 append()를 호출한다.
			FindFunctionParams appendOfStringBuilder = 
					ByteCode_Helper.getAppendOfStringBuilder(compiler, funcCallOfRValue.typeFullName.str, srcIndex, coreThreadID);
			generator.physical.makeCONSTANT_Method_infoAndPutItIntolistOfConstantTable(appendOfStringBuilder, coreThreadID);				
			
			result.add("invokevirtual // "+appendOfStringBuilder.getMethodInfoStr(coreThreadID)+ByteCode_Helper.getSourceLineNumber(generator.compiler, srcIndex)+"\n");
			
			// java.lang.StringBuilder의 toString()를 호출한다.
			FindFunctionParams toStringOfStringBuilder = 
					ByteCode_Helper.getToStringOfStringBuilder(compiler, srcIndex, coreThreadID);
			generator.physical.makeCONSTANT_Method_infoAndPutItIntolistOfConstantTable(toStringOfStringBuilder, coreThreadID);				
			
			result.add("invokevirtual // "+toStringOfStringBuilder.getMethodInfoStr(coreThreadID)+ByteCode_Helper.getSourceLineNumber(generator.compiler, srcIndex)+"\n");
		}
		else {
			if (typeOfRValue!=null && tokenOfRValue!=null && tokenOfRValue.getTypeFullNameOrTypeFullNameAfterOperation()!=null) {
				int srcIndex = varUse.index();
				// int ab=0;
				// ba=ab-(ab-=2+2)*3; 여기에서 두번째 ab
				// 두번째 ab는 int이고 rValue의 타입은 byte이므로 "-"연산을 할때 rValue의 타입을 int로 바꿔야 한다.
				TypeCast.printTypeCast(generator,  tokenOfRValue.typeFullName, 
					tokenOfRValue.getTypeFullNameOrTypeFullNameAfterOperation(), result, srcIndex, coreThreadID);
				//this.printTypeCast_sub(null, tokenOfRValue.typeFullNameAfterOperation, typeOfLValue.str, result);
			}
		}
		////////////////rValue를 로드한다. end ///////////////////////
		
		// 복합 대입연산자("+=", "-=", "*=" 등)에서 "="을 제외한 이항 연산자를 출력한다.			
		generator.printOperator(operatorEx, result, coreThreadID);
		
		return tokenOfRValue;
	}
	
	
}
