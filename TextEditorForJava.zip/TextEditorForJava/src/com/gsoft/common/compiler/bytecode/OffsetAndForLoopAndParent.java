package com.gsoft.common.compiler.bytecode;

import com.gsoft.common.compiler.Compiler_types.FindControlBlockParams;
import com.gsoft.common.compiler.Compiler_types_Base.Block;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListInt;

/**스택맵 엔트리의 바이트코드 오프셋*/
public class OffsetAndForLoopAndParent {
	/**listOfJumpOffsetsOfStackMap에서는 offset을 말하고, 
	 * listOfOffsetDeltas에서는 offsetDelta를 말한다.*/
	int offsetOrOffsetDelta;
	int accumulatedOffset;
	/** 스택맵 엔트리가 chop 프레임이어야 하면 null이 아닌 값으로서 for루프의 레퍼런스를 갖는다.<br>
	 * for (i=0; i==0; ) {             <br>
	  		if (m==0) {<br>
				System.out.println("m="+m);  i++;<br>
			}<br>
		}<br>
		이와 같이 increments가 없는 경우에 createConstantTableIndex()의 마지막 부분에서 
		condition of for(offset_delta==0)은 exit of if 프레임으로 대체되기 때문에
		conditionItem.message를 condition of for로 바꿔준다. 
		이 경우 conditionItem.parent는 for가 아니라 if가 되므로 conditionItem.forLoop를 설정해 줘야 한다.*/
	FindControlBlockParams forLoop;
	String message;
	/**현재 offset의 parent블록, <br>
	 * goto // (mBufferIndex), go to condition of YYY, <br>
	 * goto // (mBufferIndex), go to exit of YYY, <br>
	 * ifXXX // (mBufferIndex), run 등에서 점프하는 오프셋의 parent블록 혹은 <br>
	 * // (mBufferIndex), FunctionStart(BlockStart)의 오프셋의 parent블록 혹은 <br> 
	 * // (mBufferIndex), exit of XXX의 오프셋의 parent블록 */
	Block parent;
	
	/**현재 스택프레임이 3항연산자에서 stack 아이템 1개를 남겨야 하면 null이 아니다. 
	 * null이 아닌 경우 1 stack item or full frame이어야 한다.
	 * <br>
	 * i += 1>0 ? 3 : 2;<br>이 문장은 다음과 같이 컴파일된다.<br>
	 * 0          iload_2            // local I i, 2, I i<br>
1          goto_w 12         // (153), go to condition of Three Operands Operation<br>
       // (158), run of Three Operands Operation<br>
6          bipush            3  이 프레임은 1_stack_item 이어야 한다.<br> 
8          goto_w 15         // (164), go to exit of Three Operands Operation<br>
       // (153), condition of Three Operands Operation<br>
13         bipush            1<br>
15         bipush            0<br>
17         isub           <br>
18         ifgt -12          // (158), run<br>
       // (160), exit of run<br>
21         bipush            2 이 프레임은 1_stack_item 이어야 한다.<br>
       // (164), exit of Three Operands Operation<br>
23         iadd           <br>
24         istore_2            // local I i, 2, I i   스택에 로드된 1개의 아이템을 저장한다.<br>
*/
	String typeNameForThreeOperandsOperation;
	
	/** FindVarUseParams[], 복합할당연산자와 3항연산자를 함께 사용할 경우에 복합할당연산자의 lValue를 담기위해 사용된다.*/
	ArrayList listOfVarUseForThreeOperandsOperationWith1StackItem;
	
	/**ArrayListInt[], listOfVarsForCompositiveEqualOperatorAndThreeOperandsOperation에 넣어진 
	 * FindVarParams가 배열일 경우 그것의 첨자들을 가리키기 위해 넣어진다. FindVarParams가 배열이 아니면 null을 넣어야 한다. 
	 * 
	 */
	//ArrayList listOfSubscriptionOflistOfVarsForCompositiveEqualOperatorAndThreeOperandsOperation;
	
	/**복합할당연산자와 3항 연산자를 같이 사용할 경우 
	 * lValue(lValue가 지역변수일 경우에는 getOriginalVar()).indexOfLocalVarsInFunctionBeforeProcessLocalVars을 말한다.
	 * 3항 연산자만 사용하는 경우이면 -1이다.*/
	int indexOfVarUseInlistOfLValueForThreeOperandsOperationWith1StackItem=-1;
	
	
	
	/**복합할당연산자와 3항 연산자를 같이 사용할 경우 
	 * 3항연산자의 condition의 시작 바이트코드 오프셋이다.
	 * 3항 연산자만 사용하는 경우이면 -1이다.*/
	int byteCodeOffsetOfConditionForThreeOperandsOperationWith1StackItem=-1;
	
	
	/**배열원소를 접근(로드, 스토어)하는 varUse들의 mBufferIndex들의 리스트*/
	ArrayListInt listOfIndicesOfVarUsesThatAccessesArrayElement;
	public ArrayList mlistOfLocalVars;
	
		
	OffsetAndForLoopAndParent(int offsetOrOffsetDelta) {
		this.offsetOrOffsetDelta = offsetOrOffsetDelta;
		this.accumulatedOffset = offsetOrOffsetDelta;
	}
}