package com.gsoft.common.compiler.bytecode;

import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.Compiler_types.FindAssignStatementParams;
import com.gsoft.common.compiler.Compiler_types.FindFuncCallParam;
import com.gsoft.common.compiler.Compiler_types.FindVarParams;
import com.gsoft.common.compiler.Compiler_types.FindVarUseParams;

public class ValueSetter {
	public static boolean assignmentHasOnlyConstants(Compiler compiler, FindAssignStatementParams statement) {
		int i;
		FindFuncCallParam rValue = statement.rValue;
		
		int startIndex = Compiler.getIndexInmListOfAllVarUses(
				compiler.data.mBuffer, compiler.data.mlistOfAllVarUses, 0, rValue.startIndex(), true);
		int endIndex = Compiler.getIndexInmListOfAllVarUses(
				compiler.data.mBuffer, compiler.data.mlistOfAllVarUses, startIndex, rValue.endIndex(), false);
		
		for (i=startIndex; i<=endIndex; i++) {
			FindVarUseParams varUse = (FindVarUseParams) compiler.data.mlistOfAllVarUses.getItem(i);
			if (CompilerHelper.IsConstant(varUse.name)) continue;
			FindVarParams var = varUse.varDecl;
			if (var.value!=null) continue;
			break;
		}
		
		if (i>endIndex) return true;
		return false;
	}
	
	
}
