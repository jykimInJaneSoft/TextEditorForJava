package com.gsoft.common.compiler.bytecode;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import com.gsoft.common.Common_Settings;
import com.gsoft.common.FileHelper;
import com.gsoft.common.IO;
import com.gsoft.common.IO_types.TextFormat;
import com.gsoft.common.Sizing.Rectangle;
import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.Compiler_types.FindFunctionParams;
import com.gsoft.common.compiler.Compiler_types.FindVarParams;
import com.gsoft.common.compiler.bytecode.ByteCode_Types.ClassFieldMethod;
import com.gsoft.common.compiler.bytecode.ByteCode_Types.HashItemOfConstantTable;
import com.gsoft.common.compiler.bytecode.ByteCode_Types.InnerClasses_attribute;
import com.gsoft.common.compiler.bytecode.ByteCode_Types.SourceFile_attribute;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.Attribute_Info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_Class_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_Double_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_Field_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_Float_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_Integer_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_InterfaceMethod_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_Long_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_Method_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_NameAndTypeDesc_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_String_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_Utf8_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.Field_Info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.Method_Info;
import com.gsoft.common.gui.Control;
import com.gsoft.common.gui.TextView;
import com.gsoft.common.gui.edittext.Edit.ScrollMode;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListChar;
import com.gsoft.common.util.HighArray_byte;
import com.gsoft.common.util.Util.BufferByte;

import com.gsoft.common.compiler.bytecode.ByteCodeGeneratorForClass;
import com.gsoft.common.compiler.bytecode.TypeDescriptor;
import com.gsoft.common.compiler.bytecode.Code_attribute;
import com.gsoft.common.compiler.bytecode.ByteCode_Types;
import com.gsoft.common.compiler.bytecode.ByteCode_Helper;

public class PathClassWriter {
	static byte[] buffer = new byte[1000];
	static BufferByte bufferByte = new BufferByte(buffer);
	static TextView textViewCompilerMessage;
	
	static {
		createTextViewCompilerMessage(false);
	}
	
	
	public static void createTextViewCompilerMessage(boolean changeBounds) {
		//if (CommonGUI.textViewLogBird!=null) return; 
		int x, y, w, h;
		int viewWidth = Control.view.getWidth(); 
		int viewHeight = Control.view.getHeight();
		w = (int) (viewWidth * 0.8f);
		h = (int) (viewHeight * 0.6f);
		x = viewWidth/2 - w/2;
		y = viewHeight/2 - h/2;
		
		Rectangle boundsOfTextView = new Rectangle(x,y,w,h);
		
		if (!changeBounds) {
			if (textViewCompilerMessage==null) {
				textViewCompilerMessage = new TextView(false, false, null, "TextViewCompilerMessage", boundsOfTextView, 
						Control.view.getHeight()*0.03f, false, null, ScrollMode.Both, Common_Settings.backColor);
				textViewCompilerMessage.isReadOnly = true;
				textViewCompilerMessage.isSelecting = true;
			}
		}
		else {
			textViewCompilerMessage.changeBounds(boundsOfTextView);
		}
	}

	/** ClassFile {<br>
			u4 magic;<br>
			u2 minor_version;<br>
			u2 major_version;<br>
			u2 constant_pool_count;<br>
			cp_info constant_pool[constant_pool_count-1];<br>
			u2 access_flags;<br>
			u2 this_class;<br>
			u2 super_class;<br>
			u2 interfaces_count;<br>
			u2 interfaces[interfaces_count];<br>
			u2 fields_count;<br>
			field_info fields[fields_count];<br>
			u2 methods_count;<br>
			method_info methods[methods_count];<br>
			u2 attributes_count;<br>
			attribute_info attributes[attributes_count];<br>
		}<br>
	*/
	public static void makeClassFile(ByteCodeGeneratorForClass generator, HighArray_byte[] codeArrs, Compiler compiler, int coreThreadID) {
		PathClassWriter.textViewCompilerMessage.initialize();
		
		String path = Common_Settings.pathOutput;
		ArrayListChar arrClassPath = new ArrayListChar(50);
		
		TypeDescriptor.getClassDescriptor(generator.classParams.name, arrClassPath, coreThreadID);
		arrClassPath = CompilerHelper.replaceFileSeparator(arrClassPath, File.separatorChar);
		String classPath = path + File.separator + arrClassPath.toString() + ".class";
		
		String dirPath = FileHelper.getDirectory(classPath);
		File dirFile = new File(dirPath);
		
		
		// .class 파일까지의 경로에 이르는 디렉토리들을 모두 없으면 만든다.
		dirFile.mkdirs();
		
		boolean isLittleEndian = false;
		
		FileOutputStream fileOutput = null;
		BufferedOutputStream output = null;
		try {
			createCodeAttributesOfMethods(generator, compiler, coreThreadID);
			
			fileOutput = new FileOutputStream(classPath);
			output = new BufferedOutputStream(fileOutput);
			
			
			byte[] byteBuf = {(byte) 0xCA, (byte) 0xFE, (byte) 0xBA, (byte) 0xBE};
			//byte[] byteBuf = {(byte) (100+'K'), (byte) (100+'K'), (byte) (100+'J'), (byte) (100+'Y')};
			//byte[] byteBuf = {(byte) (255), (byte) (255), (byte) (255), (byte) (255)};
			output.write(byteBuf, 0, byteBuf.length); // u4
			
			short[] bufVersion = {0, 51};
			IO.writeShort(output, bufVersion[0], isLittleEndian); // minor, u2
			IO.writeShort(output, bufVersion[1], isLittleEndian); // major, u2
			
			// constant pool count, u2
			IO.writeShort(output, (short)generator.physical.listOfConstantTable.count, isLittleEndian);
			
			printConstantPoolToClassFile(generator, output, isLittleEndian);
			
			// class access flag 쓰기, u2
			short accessFlag = ByteCode_Types.accessModifierToShort(generator.classParams.accessModifier, ClassFieldMethod.Class);
			IO.writeShort(output, accessFlag, isLittleEndian);
			
			printThisAndSuperAndInterfaces(generator, output, coreThreadID);
			
			printFields(generator, output, coreThreadID);
			
			printMethods(generator, output, compiler, coreThreadID);
			
			// InnerClasses attribute
			short attribute_count = 2; // u2
			IO.writeShort(output, attribute_count, isLittleEndian);
			
			InnerClasses_attribute innerClasses_attribute = new InnerClasses_attribute(generator, coreThreadID);
			Attribute_Info.write(output, generator, innerClasses_attribute, isLittleEndian, coreThreadID);
			
			SourceFile_attribute sourceFile_attribute = new SourceFile_attribute(generator);
			Attribute_Info.write(output, generator, sourceFile_attribute, isLittleEndian, coreThreadID);
			
			output.flush();
			
		} catch (FileNotFoundException e) {
			
			if (Common_Settings.g_printsLog) e.printStackTrace();
		} catch (Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
		}
		finally {
			if (output!=null) {
				try {
					output.close();
				} catch (IOException e) {
					
					if (Common_Settings.g_printsLog) e.printStackTrace();
				}
			}
			if (fileOutput!=null) {
				try {
					fileOutput.close();
				} catch (IOException e) {
					
					if (Common_Settings.g_printsLog) e.printStackTrace();
				}
			}
		}
		
	}
	
	/** Code attribute, LocalVarTable attribute, StackMapTable attribute들을 만든다.
	 * StackMapTable에서 새로 추가되는 CONSTANT_Class_info들을 ConstantTable에 넣으므로  
	 * ConstantTable을 클래스파일에 쓰기전에 이 함수를 호출해야 한다.
	 * @param coreThreadID */
	static void createCodeAttributesOfMethods(ByteCodeGeneratorForClass generator, Compiler compiler, int coreThreadID) {
		short methods_count = (short) generator.classParams.listOfFunctionParams.count; 
		int i;
		for (i=0; i<methods_count; i++) {
			/*CommonGUI.showMessage(true, "createCodeAttributesOfMethods i="+i, true);
			if (i==35) {
				int a;
				a=0;
				a++;
			}*/
			FindFunctionParams func = 
					(FindFunctionParams) generator.classParams.listOfFunctionParams.getItem(i);
			func.codeAttribute = new Code_attribute(generator, func, i, compiler, coreThreadID);
		}
	}
	
	static void printMethods(ByteCodeGeneratorForClass generator, OutputStream output, Compiler compiler, int coreThreadID) {		
		short methods_count = (short) generator.classParams.listOfFunctionParams.count; 
		IO.writeShort(output, methods_count, false);
		int i;
		for (i=0; i<methods_count; i++) {
			FindFunctionParams func = 
					(FindFunctionParams) generator.classParams.listOfFunctionParams.getItem(i);
			
			Method_Info.write(output, generator, false, func, i, compiler, func.codeAttribute, coreThreadID);
		}
	}
	
	static void printFields(ByteCodeGeneratorForClass generator, OutputStream output, int coreThreadID) {
		short fields_count = 0;
		/*if (!generator.classParams.isEnum) {
			// this, super를 제외한다.
			fields_count = (short) (generator.classParams.listOfVariableParams.count-2);
		}
		else {
			fields_count = (short) generator.classParams.listOfVariableParams.count;
		}*/
		// this, super를 제외한다.
		// interface 클래스는 fields_count가 0이다.
		if (!(generator.classParams.isInterface)) {
			fields_count = (short) (generator.classParams.listOfVariableParams.count-2);
		}
		IO.writeShort(output, fields_count, false);
		int i;
		for (i=0; i<fields_count; i++) {
			FindVarParams field = (FindVarParams) generator.classParams.listOfVariableParams.getItem(i);
			// this, super를 제외한다.
			if (field.isThis || field.isSuper) continue;
			Field_Info.write(output, generator, false, field, coreThreadID);
		}
	}
	
	
	static void printThisAndSuperAndInterfaces(ByteCodeGeneratorForClass generator, OutputStream output, int coreThreadID) {
		// this 쓰기
		String thisDesc = TypeDescriptor.getDescriptorExceptLAndSemicolon(generator.classParams, coreThreadID);
		HashItemOfConstantTable hashItem = 
				(HashItemOfConstantTable) generator.physical.listOfConstantTableHashed.getData(thisDesc);
		int thisRef = hashItem.index;
		IO.writeShort(output, (short)thisRef, false);
		
		// super 쓰기
		String superDesc = TypeDescriptor.getDescriptorExceptLAndSemicolon(generator.classParams.classToExtend, coreThreadID);
		hashItem = 
				(HashItemOfConstantTable) generator.physical.listOfConstantTableHashed.getData(superDesc);
		int superRef = hashItem.index;
		IO.writeShort(output, (short)superRef, false);
		
		int i;
		// 구현하는 interface들의 count와 interface 쓰기
		if (generator.classParams.interfacesToImplement==null) {
			generator.classParams.interfacesToImplement = new ArrayList(2);
		}
		short countOfInterfaces = (short) generator.classParams.interfacesToImplement.count;
		IO.writeShort(output, countOfInterfaces, false);
		
		for (i=0; i<countOfInterfaces; i++) {
			FindClassParams c = (FindClassParams) generator.classParams.interfacesToImplement.getItem(i);
			String interfaceDesc = TypeDescriptor.getDescriptorExceptLAndSemicolon(c, coreThreadID);
			hashItem = 
					(HashItemOfConstantTable) generator.physical.listOfConstantTableHashed.getData(interfaceDesc);
			int interfaceRef = hashItem.index;
			IO.writeShort(output, (short)interfaceRef, false);
		}
					
	}
	
	static void printConstantPoolToClassFile(ByteCodeGeneratorForClass generator, OutputStream output, boolean isLittleEndian) throws IOException {
		int i;
		ArrayList listOfConstantTable = generator.physical.listOfConstantTable;
		for (i=0; i<listOfConstantTable.count; i++) {
			Object item = listOfConstantTable.getItem(i);
			
			if (item instanceof CONSTANT_Class_info) {
				CONSTANT_Class_info classInfo = (CONSTANT_Class_info)item;
				IO.writeByte(output, classInfo.tag);
				IO.writeShort(output, (short)classInfo.name_index, isLittleEndian);
			}
			else if (item instanceof CONSTANT_Double_info) {
				CONSTANT_Double_info info = (CONSTANT_Double_info)item;
				IO.writeByte(output, info.tag);
				IO.writeDouble(output, info.d, false);
				
				/*All 8-byte constants take up two entries in the constant_pool table of the class
				file. If a CONSTANT_Long_info or CONSTANT_Double_info structure is the item
				in the constant_pool table at index n , then the next usable item in the pool is
				located at index n + 2 . The constant_pool index n + 1 must be valid but is
				considered unusable.*/
				i++;
			}
			else if (item instanceof CONSTANT_Field_info) {
				CONSTANT_Field_info info = (CONSTANT_Field_info)item;
				IO.writeByte(output, info.tag);
				IO.writeShort(output, (short)info.classRef, isLittleEndian);
				IO.writeShort(output, (short)info.nameAndTypeDescRef, isLittleEndian);
			}
			else if (item instanceof CONSTANT_Float_info) {
				CONSTANT_Float_info info = (CONSTANT_Float_info)item;
				IO.writeByte(output, info.tag);
				IO.writeFloat(output, info.f, isLittleEndian);
			}
			else if (item instanceof CONSTANT_Integer_info) {
				CONSTANT_Integer_info info = (CONSTANT_Integer_info)item;
				IO.writeByte(output, info.tag);
				IO.writeInt(output, info.integer, isLittleEndian);
			}
			else if (item instanceof CONSTANT_InterfaceMethod_info) {
				CONSTANT_InterfaceMethod_info info = (CONSTANT_InterfaceMethod_info)item;
				IO.writeByte(output, info.tag);
				IO.writeShort(output, (short)info.classRef, isLittleEndian);
				IO.writeShort(output, (short)info.nameAndTypeDescRef, isLittleEndian);
			}
			else if (item instanceof CONSTANT_Long_info) {
				CONSTANT_Long_info info = (CONSTANT_Long_info)item;
				IO.writeByte(output, info.tag);
				IO.writeLong(output, info.l, isLittleEndian);
				
				/*All 8-byte constants take up two entries in the constant_pool table of the class
				file. If a CONSTANT_Long_info or CONSTANT_Double_info structure is the item
				in the constant_pool table at index n , then the next usable item in the pool is
				located at index n + 2 . The constant_pool index n + 1 must be valid but is
				considered unusable.*/
				i++;
			}
			else if (item instanceof CONSTANT_Method_info) {
				CONSTANT_Method_info info = (CONSTANT_Method_info)item;
				IO.writeByte(output, info.tag);
				IO.writeShort(output, (short)info.classRef, isLittleEndian);
				IO.writeShort(output, (short)info.nameAndTypeDescRef, isLittleEndian);
			}
			else if (item instanceof CONSTANT_NameAndTypeDesc_info) {
				CONSTANT_NameAndTypeDesc_info info = (CONSTANT_NameAndTypeDesc_info)item;
				IO.writeByte(output, info.tag);
				IO.writeShort(output, (short)info.nameRef, isLittleEndian);
				IO.writeShort(output, (short)info.typeDescRef, isLittleEndian);
			}
			else if (item instanceof CONSTANT_String_info) {
				CONSTANT_String_info info = (CONSTANT_String_info)item;
				
				IO.writeByte(output, info.tag);
				IO.writeShort(output, (short)info.string_index, isLittleEndian);
			}
			else if (item instanceof CONSTANT_Utf8_info) {
				CONSTANT_Utf8_info info = (CONSTANT_Utf8_info)item;
				IO.writeByte(output, info.tag);
								
				String newStr = ByteCode_Helper.removeSymbolsOfString(info.str);
				info.str = ByteCode_Helper.processReverseSlashOfString(newStr);
				
				// utf8 스트링의 바이트 길이를 쓴다.
				IO.writeString(bufferByte, info.str, TextFormat.UTF_8, false, false);
				IO.writeShort(output, (short)bufferByte.offset, isLittleEndian);
				//IO.writeString(output, info.str, TextFormat.UTF_8, false, false);
				output.write(bufferByte.buffer, 0, bufferByte.offset);
				bufferByte.offset = 0;
			}
		}//for (i=0; i<generator.listOfConstantTable.count; i++) {
	}

}
