package com.gsoft.common.compiler.bytecode;

import com.gsoft.common.Common_Settings;
import com.gsoft.common.compiler.Array;
import com.gsoft.common.compiler.HighArray_CodeString;
import com.gsoft.common.compiler.Number;
import com.gsoft.common.compiler.Compiler_types.FindFuncCallParam;
import com.gsoft.common.compiler.Compiler_types.FindVarParams;
import com.gsoft.common.compiler.Compiler_types.FindVarUseParams;
import com.gsoft.common.compiler.Compiler_types_Special.FindArrayInitializerParams;

/**new int[3][2]*/
public class ManyDimensionNewArray {
	/**int[] a = new int[2][1]
	 * 2
	 * anewarray
	 * dup
	 * 0
	 * 1
	 * newarray
	 * aastore
	 * ...
	 * astore
	 * @param generator
	 * @param src
	 * @param varUse
	 * @param depth
	 * @param result
	 * @param indexOfLeftParenthesis
	 * @param coreThreadID
	 */
	/*public static void traverseArrayIntializer(ByteCodeGeneratorForClass generator, HighArray_CodeString src, FindVarUseParams varUse, int depth, 
			HighArrayCharForByteCode result, int indexOfLeftParenthesis, int coreThreadID) {
		int dimension = Array.getArrayDimension(generator.compiler, varUse.name);
		if (dimension<2) return;
		if (depth!=dimension-1) { // 중첩된 배열
			int i;
			printArrayInitializer_newarray_NoBottom(
					generator, depth, varUse, result, indexOfLeftParenthesis, coreThreadID);
			
			int nextArrayLength = Array.getArrayLength(generator.compiler, varUse, depth+1);
			for (i=0; i<nextArrayLength; i++) {
				FindArrayInitializerParams child = (FindArrayInitializerParams) array.listOfFindArrayInitializerParams.getItem(i);
				int mBufferIndexForSrcIndex = child.indexOfLeftParenthesis();
				String strSrcIndex = ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(generator.compiler, mBufferIndexForSrcIndex);
				
				result.add("dup // "+strSrcIndex+"\n");
				try {
					printArrayInitializer_index(generator, i, depth+1, varUse, result, mBufferIndexForSrcIndex, coreThreadID);
				}catch(Exception e) {
					if (Common_Settings.g_printsLog) e.printStackTrace();
				}
				
				//FindArrayInitializerParams child = (FindArrayInitializerParams) array.listOfFindArrayInitializerParams.getItem(i);
				traverseArrayIntializer(generator, src, topArray, child, result, coreThreadID);
				
				printArrayInitializer_store_NoBottom(result, topArray.varUse, child.indexOfRightParenthesis());
				
				printArrayInitializer_inc(generator, Array.getMaxArrayLengthInCurDepth(topArray, array), 
						topArray, array, result, coreThreadID);
			}//for (i=0; i<array.listOfFindArrayInitializerParams.count; i++) {
		}
		else { // 수식, 가장 하위 노드
			// 최하위차원
			
			printArrayInitializer_newarray_bottom(
					generator, Array.getMaxArrayLengthInCurDepth(topArray, array), 
					array.depth, topArray.varUse,
					Array.getArrayElementType(topArray.typeFullName), result, array.indexOfLeftParenthesis(), coreThreadID);
			
			int i;			
			
			for (i=0; i<array.listOfFindFuncCallParam.count; i++) {
				if (i==6) {
					int a;
					a=0;
					a++;
				}
				FindFuncCallParam funcCallParam = (FindFuncCallParam) array.listOfFindFuncCallParam.getItem(i);
				
				int mBufferIndexForSrcIndex = funcCallParam.startIndex();
				String strmBufferIndex = ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(generator.compiler, mBufferIndexForSrcIndex);
				
				result.add("dup // "+strmBufferIndex+"\n");
				try {
					printArrayInitializer_index(generator, i, array.depth, topArray.varUse, result, mBufferIndexForSrcIndex, coreThreadID);
				}catch(Exception e) {
					if (Common_Settings.g_printsLog) e.printStackTrace();
				}
				
				
				if (funcCallParam.startIndex()==256) {
				}
								
				if (funcCallParam.expression.postfix!=null) {					
					
					// 수식트리에서 상위 노드의 포스트픽스
					// f2(1+2) 3 +
					
					// 1 2 +
					// 수식트리에서 자식노드들을 방문하기위해 재귀적호출
					
					generator.traverseChild(funcCallParam, result, coreThreadID);
					
					
					printArrayInitializer_store_bottom(generator, funcCallParam, result, topArray, coreThreadID);
					
					printArrayInitializer_inc(generator, Array.getMaxArrayLengthInCurDepth(topArray, array), 
							topArray, array, result, coreThreadID);
					
				}//if (funcCallParam.expression.postfix!=null) {				
				
			}//for (i=0; i<array.listOfFindFuncCallParam.count; i++) {
			
			
		}// else
	
	}
	
	public static void printArrayInitializer_newarray_NoBottom(ByteCodeGeneratorForClass generator, 
			int depth, FindVarUseParams varUse, HighArrayCharForByteCode result, int indexOfLeftPairInmBuffer, int coreThreadID) {
		// array length print
		printArrayLength(generator, depth, varUse, indexOfLeftPairInmBuffer, result, coreThreadID);
		
		int dimension = varUse.arrayInitializer.dimension;
		int dimensionToPrint = dimension - (depth+1);
		String arrDesc = "";
		int i;
		for (i=0; i<dimensionToPrint; i++) {
			arrDesc += "[";
		}
		String elementTypeDesc = 
			TypeDescriptor.getDescriptorExceptLAndSemicolon(Array.getArrayElementType(varUse.arrayInitializer.typeFullName), coreThreadID);
		String typeDesc = arrDesc + elementTypeDesc;
				
		generator.physical.makeCONSTANT_Class_infoAndPutItIntolistOfConstantTable_ExceptLAndSemicolon(typeDesc);
		String strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, indexOfLeftPairInmBuffer);
		result.add("anewarray // "+typeDesc+strmBufferIndex+"\n");
	}
	
	
	public static void printArrayLength(ByteCodeGeneratorForClass generator, int depth, FindVarUseParams varUse, 
			int indexOfLeftPairInmBuffer, HighArrayCharForByteCode result, int coreThreadID) {
		FindFuncCallParam funcCall = (FindFuncCallParam) varUse.listOfArrayElementParams.getItem(depth);
		generator.traverseChild(funcCall, result, coreThreadID);
		
	}*/

}
