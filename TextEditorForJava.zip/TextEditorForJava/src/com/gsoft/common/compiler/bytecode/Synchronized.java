package com.gsoft.common.compiler.bytecode;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.Compiler_types.FindControlBlockParams;
import com.gsoft.common.compiler.Compiler_types.FindFunctionParams;
import com.gsoft.common.compiler.Compiler_types.FindVarParams;
import com.gsoft.common.compiler.Compiler_types.FindVarUseParams;
import com.gsoft.common.compiler.Compiler_types_Base.Block;
import com.gsoft.common.compiler.Compiler_types_Base.FindStatementParams;
import com.gsoft.common.compiler.Compiler_types_Special.FindSpecialBlockParams;
import com.gsoft.common.compiler.Compiler_types_Special.FindThreeOperandsOperation;
import com.gsoft.common.compiler.HighArray_CodeString;
import com.gsoft.common.compiler.IndexForHighArray;
import com.gsoft.common.compiler.classloader.Loader;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListIReset;
import com.gsoft.common.util.ArrayListInt;

import com.gsoft.common.compiler.bytecode.ByteCodeGeneratorForClass;
import com.gsoft.common.compiler.bytecode.HighArrayCharForByteCode;
import com.gsoft.common.compiler.bytecode.TypeDescriptor;
import com.gsoft.common.compiler.bytecode.ControlBlock;
import com.gsoft.common.compiler.bytecode.Specials;
import com.gsoft.common.compiler.bytecode.ByteCode_Helper;
import com.gsoft.common.compiler.bytecode.ByteCode_Types;
import com.gsoft.common.compiler.bytecode.LocalVar;

public class Synchronized {
	
	static ArrayListInt listOfSynchronizedIndices = null;
	static ArrayList listOfSynchronizedBlocks = null;
	public static FindFunctionParams setBooleanValueToBitMaskArrFunc;
	public static FindFunctionParams getBooleanValueFromBitMaskArrFunc;
	
	
	public static void destroy() {
		if (listOfSynchronizedIndices!=null) {
			listOfSynchronizedIndices.reset2();
			listOfSynchronizedIndices = null;
		}
		if (listOfSynchronizedBlocks!=null) {
			listOfSynchronizedBlocks.destroy();
			listOfSynchronizedBlocks = null;
		}
		if (getBooleanValueFromBitMaskArrFunc!=null) {
			getBooleanValueFromBitMaskArrFunc.destroy();
			getBooleanValueFromBitMaskArrFunc = null;
		}
		if (setBooleanValueToBitMaskArrFunc!=null) {
			setBooleanValueToBitMaskArrFunc.destroy();
			setBooleanValueToBitMaskArrFunc = null;
		}
	}
	
	static int getSerialNumberInBitMaskArr(FindFunctionParams func, int mBufferIndexOfSyncKeyword) {
		if (listOfSynchronizedIndices==null) {
			listOfSynchronizedIndices = new ArrayListInt(2);
			listOfSynchronizedBlocks = new ArrayList(2);
			
			if (func.accessModifier.isSynchronized) {
				int j;
				for (j=func.startIndex(); j<func.endIndex(); j++) {
					CodeString str = func.compiler.data.mBuffer.getItem(j);
					if (str.equals("synchronized")) {
						listOfSynchronizedIndices.add(j);
						listOfSynchronizedBlocks.add(func);
						break;
					}
				}				
			}
			else {
				listOfSynchronizedIndices.add(-1);
				listOfSynchronizedBlocks.add(null);
			}
			findSynchronizedBlocks(func, listOfSynchronizedIndices, listOfSynchronizedBlocks);		
		}// if (listOfSynchronizedIndices==null) {
		
		int count = 0;
		int i;
		for (i=0; i<listOfSynchronizedIndices.count; i++) {
			int indexName = listOfSynchronizedIndices.getItem(i);
			if (indexName==mBufferIndexOfSyncKeyword) return count;
			count++;
		}
		return -1;
	}
	
	static void findSynchronizedBlocks(FindFunctionParams func, ArrayListInt listOfSynchronizedIndices, ArrayList listOfSynchronizedBlocks) {
		int i;
		for (i=0; i<func.listOfControlBlocks.count; i++) {
			FindControlBlockParams block = (FindControlBlockParams) func.listOfControlBlocks.getItem(i);
			if (block.getName().equals("synchronized")) {
				FindSpecialBlockParams special = (FindSpecialBlockParams) block;
				listOfSynchronizedIndices.add(special.nameIndex());
				listOfSynchronizedBlocks.add(special);				
			}
			findSynchronizedBlocks_sub(block, listOfSynchronizedIndices, listOfSynchronizedBlocks);
		}	
	}
	
	static void findSynchronizedBlocks_sub(FindControlBlockParams parentBlock, ArrayListInt listOfSynchronizedIndices, ArrayList listOfSynchronizedBlocks) {
		int i;
		for (i=0; i<parentBlock.listOfControlBlocks.count; i++) {
			FindControlBlockParams block = (FindControlBlockParams) parentBlock.listOfControlBlocks.getItem(i);
			if (block.getName().equals("synchronized")) {
				FindSpecialBlockParams special = (FindSpecialBlockParams) block;
				listOfSynchronizedIndices.add(special.nameIndex());
				listOfSynchronizedBlocks.add(special);
			}
			findSynchronizedBlocks_sub(block, listOfSynchronizedIndices, listOfSynchronizedBlocks);
		}
	}
	
	public static void print_getBooleanValueFromBitMaskArr(ByteCodeGeneratorForClass generator, 
			Block block, HighArrayCharForByteCode result, int coreThreadID) {
		int mBufferIndexOfSync = -1;
		FindFunctionParams func = null;
		FindControlBlockParams controlBlock = null;
		if (block instanceof FindControlBlockParams) {
			controlBlock = (FindControlBlockParams) block;
			mBufferIndexOfSync = controlBlock.nameIndex();
			func = (FindFunctionParams) Compiler.getParent(controlBlock);
		}
		else {
			func = (FindFunctionParams) block;
			int i;
			HighArray_CodeString src = func.compiler.data.mBuffer;
			for (i=func.startIndex(); i<=func.endIndex(); i++) {
				CodeString str = src.getItem(i);
				if (str.equals("synchronized")) {
					mBufferIndexOfSync = i;
					break;
				}
			}
		}
		
		// loads parameters of getBooleanValueFromBitMaskArrFunc()
		
		// prints serialNumberInBitMaskArr
		int sn = getSerialNumberInBitMaskArr(func, mBufferIndexOfSync);
		generator.printSmallIntegerNumber(sn, result, mBufferIndexOfSync);
		
		FindVarParams var = func.getVar("bitMaskArrForSynchronized");
		int localTableIndex = var.indexOfLocalVariableTable;
		
		FindVarParams varBeforeProcessLocalVars = var;
		if (var.sharedVar!=null) {
			var = var.sharedVar;
		}
				
		// 중복변수일 경우 중복처리하기 전 변수의 indexOfLocalVarsInFunctionBeforeProcessLocalVars을,
		// 중복변수가 아니면 그 변수의 indexOfLocalVarsInFunctionBeforeProcessLocalVars을 구한다.
		String strindexOfLocalVarsInFunctionBeforeProcessLocalVars = 
					", "+varBeforeProcessLocalVars.indexOfLocalVarsInFunctionBeforeProcessLocalVars;
		
		strindexOfLocalVarsInFunctionBeforeProcessLocalVars = 
				strindexOfLocalVarsInFunctionBeforeProcessLocalVars+", "+varBeforeProcessLocalVars.getVarStr(coreThreadID);
		
		String strmBufferIndex = null;
		int srcIndex = -1;
		if (block instanceof FindControlBlockParams) {
			srcIndex = controlBlock.nameIndex();
		}
		else {
			srcIndex = func.functionNameIndex();
		}
		strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, srcIndex);
		
		// prints bitMaskArr
		result.add("iload_"+localTableIndex + " // local "+var.getVarStr(coreThreadID)+strindexOfLocalVarsInFunctionBeforeProcessLocalVars+strmBufferIndex+"\n");
		
		FindFunctionParams getBooleanValueFromBitMaskArrFunc = getBooleanValueFromBitMaskArrFunc(generator, srcIndex, coreThreadID);
		
		// calls getBooleanValueFromBitMaskArrFunc()
		generator.physical.makeCONSTANT_Method_infoAndPutItIntolistOfConstantTable(getBooleanValueFromBitMaskArrFunc, coreThreadID);
		result.add("invokestatic // "+getBooleanValueFromBitMaskArrFunc.getMethodInfoStr(coreThreadID)+
				strmBufferIndex+"\n");
	}
	
	static FindFunctionParams getBooleanValueFromBitMaskArrFunc(ByteCodeGeneratorForClass generator, int srcIndex, int coreThreadID) {
		/*if (Synchronized.getBooleanValueFromBitMaskArrFunc!=null) {
			Synchronized.getBooleanValueFromBitMaskArrFunc.functionNameIndex = IndexForHighArray.indexRelative(null, generator.compiler.data.mBuffer, srcIndex);
			return Synchronized.getBooleanValueFromBitMaskArrFunc;
		}*/
		FindClassParams bitMaskArrClassParams = Loader.loadClass(generator.compiler, ByteCode_Types.BitMaskArrForSynchronizedOrFinally, coreThreadID);
		int i;
		FindFunctionParams getBooleanValueFromBitMaskArrFunc = null;
		for (i=0; i<bitMaskArrClassParams.listOfFunctionParams.count; i++) {
			FindFunctionParams f = (FindFunctionParams) bitMaskArrClassParams.listOfFunctionParams.getItem(i);
			if (f.name.equals("getBooleanValueFromBitMaskArr")) {
				getBooleanValueFromBitMaskArrFunc = f;
				break;
			}
		}
		Synchronized.getBooleanValueFromBitMaskArrFunc = getBooleanValueFromBitMaskArrFunc;
		Synchronized.getBooleanValueFromBitMaskArrFunc.functionNameIndex = IndexForHighArray.indexRelative(null, generator.compiler.data.mBuffer, srcIndex);
		return getBooleanValueFromBitMaskArrFunc;
	}
	
	static FindFunctionParams setBooleanValueToBitMaskArr(ByteCodeGeneratorForClass generator, int srcIndex, int coreThreadID) {
		/*if (Synchronized.setBooleanValueToBitMaskArrFunc!=null) {
			Synchronized.setBooleanValueToBitMaskArrFunc.functionNameIndex = IndexForHighArray.indexRelative(null, generator.compiler.data.mBuffer, srcIndex);
			return Synchronized.setBooleanValueToBitMaskArrFunc;
		}*/
		FindClassParams bitMaskArrClassParams = Loader.loadClass(generator.compiler, ByteCode_Types.BitMaskArrForSynchronizedOrFinally, coreThreadID);
		int i;
		FindFunctionParams setBooleanValueToBitMaskArrFunc = null;
		for (i=0; i<bitMaskArrClassParams.listOfFunctionParams.count; i++) {
			FindFunctionParams f = (FindFunctionParams) bitMaskArrClassParams.listOfFunctionParams.getItem(i);
			if (f.name.equals("setBooleanValueToBitMaskArr")) {
				setBooleanValueToBitMaskArrFunc = f;
				break;
			}
		}
		Synchronized.setBooleanValueToBitMaskArrFunc = setBooleanValueToBitMaskArrFunc;
		Synchronized.setBooleanValueToBitMaskArrFunc.functionNameIndex = IndexForHighArray.indexRelative(null, generator.compiler.data.mBuffer, srcIndex);
		return setBooleanValueToBitMaskArrFunc;
	}
	
	/**
	 * 
	 * @param block : function or synchronized
	 * @param booleanValue : true(monitorenter), false(monitorexit)
	 * @param coreThreadID 
	 */
	public static void print_setBooleanValueToBitMaskArr(ByteCodeGeneratorForClass generator, 
			Block block, HighArrayCharForByteCode result, boolean booleanValue, int coreThreadID) {
		int mBufferIndexOfSync = -1;
		FindFunctionParams func = null;
		FindControlBlockParams controlBlock = null;
		if (block instanceof FindControlBlockParams) {
			controlBlock = (FindControlBlockParams) block;
			mBufferIndexOfSync = controlBlock.nameIndex();
			func = (FindFunctionParams) Compiler.getParent(controlBlock);
		}
		else {
			func = (FindFunctionParams) block;
			int i;
			HighArray_CodeString src = func.compiler.data.mBuffer;
			for (i=func.startIndex(); i<=func.endIndex(); i++) {
				CodeString str = src.getItem(i);
				if (str.equals("synchronized")) {
					mBufferIndexOfSync = i;
					break;
				}
			}
		}
		
		// loads parameters of setBooleanValueFromBitMaskArrFunc()
		
		// prints serialNumberInBitMaskArr
		int sn = getSerialNumberInBitMaskArr(func, mBufferIndexOfSync);
		generator.printSmallIntegerNumber(sn, result, mBufferIndexOfSync);
		
		FindVarParams var = func.getVar("bitMaskArrForSynchronized");
		
		int localTableIndex = var.indexOfLocalVariableTable;
		
		FindVarParams varBeforeProcessLocalVars = var;
		if (var.sharedVar!=null) {
			var = var.sharedVar;
		}
				
		// 중복변수일 경우 중복처리하기 전 변수의 indexOfLocalVarsInFunctionBeforeProcessLocalVars을,
		// 중복변수가 아니면 그 변수의 indexOfLocalVarsInFunctionBeforeProcessLocalVars을 구한다.
		String strindexOfLocalVarsInFunctionBeforeProcessLocalVars = 
					", "+varBeforeProcessLocalVars.indexOfLocalVarsInFunctionBeforeProcessLocalVars;
		
		strindexOfLocalVarsInFunctionBeforeProcessLocalVars = 
				strindexOfLocalVarsInFunctionBeforeProcessLocalVars+", "+varBeforeProcessLocalVars.getVarStr(coreThreadID);
		
		String strmBufferIndex = null;
		String strmBufferIndexWithoutCommaAndBlank = null;
		int srcIndex = -1;
		if (block instanceof FindControlBlockParams) {
			srcIndex = controlBlock.nameIndex();
		}
		else {
			srcIndex = func.functionNameIndex();
		}
		strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, srcIndex);
		strmBufferIndexWithoutCommaAndBlank = ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(generator.compiler, srcIndex);
		
		// prints bitMaskArr
		result.add("iload_"+localTableIndex + " // local "+var.getVarStr(coreThreadID)+strindexOfLocalVarsInFunctionBeforeProcessLocalVars+strmBufferIndex+"\n");
		
		int booleanValueInt = 0;
		if (booleanValue) booleanValueInt = 1;
		// prints booleanValue
		generator.printSmallIntegerNumber(booleanValueInt, result, mBufferIndexOfSync);
		result.add("i2z // "+strmBufferIndexWithoutCommaAndBlank+"\n");
		
		FindFunctionParams setBooleanValueToBitMaskArrFunc = setBooleanValueToBitMaskArr(generator, srcIndex, coreThreadID);
		
		// calls setBooleanValueToBitMaskArrFunc()
		generator.physical.makeCONSTANT_Method_infoAndPutItIntolistOfConstantTable(setBooleanValueToBitMaskArrFunc, coreThreadID);
		result.add("invokestatic // "+setBooleanValueToBitMaskArrFunc.getMethodInfoStr(coreThreadID)+
				strmBufferIndex+"\n");
		
		// set bitMaskArr with return value 
		result.add("istore_"+localTableIndex + " // local "+var.getVarStr(coreThreadID)+strindexOfLocalVarsInFunctionBeforeProcessLocalVars+strmBufferIndex+"\n");
	}
	
	public static void putTryFinallyShieldForMonitorExitInFunctionWithSynchronized(Compiler compiler, FindFunctionParams func) {
		
		ArrayListIReset originalControlBlocks = func.listOfControlBlocks;
		ArrayListIReset originalSpecialBlocks = func.listOfSpecialBlocks;
		ArrayListIReset originalStatements = func.listOfStatements;
		
		FindSpecialBlockParams tryBlock = new FindSpecialBlockParams(compiler, 
				FindSpecialBlockParams.SpecialBlockType_try, 
				func.startIndex()+1, func.endIndex()-1);
		tryBlock.parent = func;
		tryBlock.isFake = true;
		tryBlock.anotherName = ByteCode_Types.TryFinallyShieldForFuncWithSync;
		compiler.data.mlistOfAllControlBlocks.add(tryBlock);
		
		int i;
		for (i=0; i<originalControlBlocks.count; i++) {
			FindStatementParams statement = (FindStatementParams) originalControlBlocks.getItem(i);
			statement.parent = tryBlock;
			tryBlock.listOfControlBlocks.add(statement);
		}
		originalControlBlocks.count = 0;
		
		for (i=0; i<originalSpecialBlocks.count; i++) {
			FindStatementParams statement = (FindStatementParams) originalSpecialBlocks.getItem(i);
			statement.parent = tryBlock;
			tryBlock.listOfSpecialBlocks.add(statement);
		}
		originalSpecialBlocks.count = 0;
		
		for (i=0; i<originalStatements.count; i++) {
			FindStatementParams statement = (FindStatementParams) originalStatements.getItem(i);
			statement.parent = tryBlock;
			tryBlock.listOfStatements.add(originalStatements.getItem(i));
			if (statement instanceof FindVarParams) {
				tryBlock.listOfVariableParams.add(statement);
			}
		}
		originalStatements.count = 0;
		
		
		for (i=0; i<compiler.data.mlistOfThreeOperandsOperation.count; i++) {
			FindThreeOperandsOperation three = (FindThreeOperandsOperation) compiler.data.mlistOfThreeOperandsOperation.getItem(i);
			if (three.parent==func) {
				three.parent = tryBlock;
			}
			//tryBlock.listOfStatements.add(originalStatements.getItem(i));
		}
		
		
		
		FindSpecialBlockParams finallyBlock = new FindSpecialBlockParams(compiler, 
				FindSpecialBlockParams.SpecialBlockType_finally, 
				func.startIndex()+1, func.endIndex()-1);
		finallyBlock.parent = func;
		finallyBlock.isFake = true;
		finallyBlock.tryBlockConnected = tryBlock;
		finallyBlock.anotherName = ByteCode_Types.TryFinallyShieldForFuncWithSync;
		
		compiler.data.mlistOfFinally.add(finallyBlock);
		compiler.data.mlistOfAllControlBlocks.add(finallyBlock);
				
		
		tryBlock.indexInListOfControlBlocksOfParent = 0;
		func.listOfControlBlocks.add(tryBlock);
		func.listOfStatements.add(tryBlock);
		
		finallyBlock.indexInListOfControlBlocksOfParent = 1;
		func.listOfControlBlocks.add(finallyBlock);
		func.listOfStatements.add(finallyBlock);
		
		 
	}
	
	/** When func is not static, then print this.
	 * When func is static, then print BitMaskArrForSynchronizedOrFinally.lockForSynchronizedFunc.
	 * @param coreThreadID 
	 */
	public static void printSynchronizedObjectOfFunction(ByteCodeGeneratorForClass generator, FindFunctionParams func, HighArrayCharForByteCode result, int coreThreadID) {
		if (!func.accessModifier.isStatic) { 
			FindClassParams parentClass = (FindClassParams)func.parent;
			String strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, func.functionNameIndex());
			String thisStr = TypeDescriptor.getDescriptorOfThis(parentClass, coreThreadID);
			result.add("aload_0 // local "+thisStr+strmBufferIndex+"\n");
		}
		else {
			FindClassParams bitMaskArrForSynchronizedOrFinallyClass = 
					Loader.loadClass(generator.compiler, "janesoft.common.BitMaskArrForSynchronizedOrFinally", coreThreadID);
			int o;
			FindVarParams lockForSynchronizedFuncVar = null;
			for (o=0; o<bitMaskArrForSynchronizedOrFinallyClass.listOfVariableParams.count; o++) {
				FindVarParams var = (FindVarParams) bitMaskArrForSynchronizedOrFinallyClass.listOfVariableParams.getItem(o);
				if (var.fieldName.equals("lockForSynchronizedFunc")) {
					lockForSynchronizedFuncVar = var;
					break;
				}
			}
			FindVarUseParams fakeVarUse = new FindVarUseParams(func.functionNameIndex);
			fakeVarUse.isFake = true;
			fakeVarUse.isForVarOrForFunc = true;
			fakeVarUse.isLocal = false;
			fakeVarUse.varDecl = lockForSynchronizedFuncVar;
			
			generator.printMemberVarUse(fakeVarUse, result, true, coreThreadID);
		}
	}
	
	public static void printMonitorExitInEndOfFunc(ByteCodeGeneratorForClass generator, FindFunctionParams func, 
			HighArrayCharForByteCode result, int coreThreadID) {
		
		if (Synchronized.listOfSynchronizedBlocks==null) return;
		
		String strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, func.endIndex());
		String strmBufferIndexWithoutCommaAndBlank = ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(generator.compiler, func.endIndex());
		Compiler compiler = generator.compiler;
		int i;
		for (i=0; i<Synchronized.listOfSynchronizedBlocks.count; i++) {
			Object blockObj = Synchronized.listOfSynchronizedBlocks.getItem(i);
			if (blockObj==null) continue;
			if (blockObj instanceof FindSpecialBlockParams) {
				FindSpecialBlockParams controlBlock = (FindSpecialBlockParams) blockObj;
				Synchronized.print_getBooleanValueFromBitMaskArr(generator, controlBlock, result, coreThreadID);
				
				String strIndex = "("+2000000+i+"), ";
				result.add("ifle // "+strIndex+"go to exit of fake if"+strmBufferIndex+"\n"); // 
				
				int startIndex = Compiler.getIndexInmListOfAllVarUses(
						compiler.data.mBuffer, compiler.data.mlistOfAllVarUses, 0, 
						controlBlock.indexOfLeftParenthesis(), true);
				int endIndex = Compiler.getIndexInmListOfAllVarUses(
						compiler.data.mBuffer, compiler.data.mlistOfAllVarUses, startIndex, 
						controlBlock.indexOfRightParenthesis(), false);
				generator.traverse(startIndex, endIndex, result);
				
				result.add("monitorexit // "+strmBufferIndexWithoutCommaAndBlank+"\n");
				
				result.add("// "+strIndex+"exit of fake if"+"\n");
			}// if (blockObj instanceof FindSpecialBlockParams) {
			else {
				Synchronized.print_getBooleanValueFromBitMaskArr(generator, func, result, coreThreadID);
				
				String strIndex = "("+2000000+i+"), ";
				result.add("ifle // "+strIndex+"go to exit of fake if"+strmBufferIndex+"\n");
				
				printSynchronizedObjectOfFunction(generator, func, result, coreThreadID);
				
				result.add("monitorexit // "+strmBufferIndexWithoutCommaAndBlank+"\n");
				
				result.add("// "+strIndex+"exit of fake if"+"\n");
			}
		}
		
		Synchronized.listOfSynchronizedIndices = null;
		Synchronized.listOfSynchronizedBlocks = null;
	}
	   
	   
	   /** @param coreThreadID 
	 * @param doNotPrintThrowOrReturn : <br>
		 * finally { <br>
		 * 		synchronized () {<br>
		 * 			return;<br>
		 *  	}<br>
		 * }<br>
		 * 이런 경우 printFinally()에서 throw를 하기전에 return을 출력을 해서는 안된다.
		 */
	public static void printSynchronized(ByteCodeGeneratorForClass generator, FindControlBlockParams controlBlock, HighArrayCharForByteCode result, int coreThreadID) {
		Compiler compiler = generator.compiler;
		String strmBufferIndex = ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(generator.compiler, controlBlock.nameIndex());
		
			String strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)9, null);
			result.add("// "+strIndex+"BlockStart\n");
			
			result.add("// synchronized starts"+"\n");
			
			int startIndex = Compiler.getIndexInmListOfAllVarUses(
					compiler.data.mBuffer, compiler.data.mlistOfAllVarUses, 0, 
					controlBlock.indexOfLeftParenthesis(), true);
			int endIndex = Compiler.getIndexInmListOfAllVarUses(
					compiler.data.mBuffer, compiler.data.mlistOfAllVarUses, startIndex, 
					controlBlock.indexOfRightParenthesis(), false);
			generator.traverse(startIndex, endIndex, result);
			
			result.add("monitorenter // "+strmBufferIndex+"\n");
			
			//print_setBooleanValueToBitMaskArr(generator, controlBlock, result, true);
			
			
			ControlBlock.printControlBlockBody(generator, controlBlock, result, coreThreadID);
			
			// 바깥 문장 리스트에 throw문을 포함하면 monitorexit를 출력하지 않는다.
			if (!Specials.containsThrowOrReturnOrBreakOrContinue(generator, controlBlock, controlBlock)) {
				// synchronized 괄호 안에 있는 잠금 오브젝트
				generator.traverse(startIndex, endIndex, result);
				result.add("monitorexit "+"\n");
				
				//print_setBooleanValueToBitMaskArr(generator, controlBlock, result, false);
			}
			
			
			
			LocalVar.printsLocalVarEnd(generator, controlBlock, result);
			
			strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)8, null);
			result.add("// "+strIndex+"exit of synchronized"+"\n");
		}
}
