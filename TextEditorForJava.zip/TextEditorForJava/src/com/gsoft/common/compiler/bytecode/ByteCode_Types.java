package com.gsoft.common.compiler.bytecode;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.FileHelper;
import com.gsoft.common.IO;
import com.gsoft.common.interfaces.IReset;
import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.Compiler_types.FindControlBlockParams;
import com.gsoft.common.compiler.Compiler_types.FindFunctionParams;
import com.gsoft.common.compiler.Compiler_types.FindVarParams;
import com.gsoft.common.compiler.Compiler_types_Base.AccessModifier;
import com.gsoft.common.compiler.Compiler_types_Base.AccessModifier.AccessPermission;
import com.gsoft.common.compiler.Compiler_types_Base.Block;
import com.gsoft.common.compiler.Compiler_types_Special.FindSpecialBlockParams;
import com.gsoft.common.compiler.HighArray_CodeString;
import com.gsoft.common.compiler.TemplateBase;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.Attribute_Info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_Class_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_Double_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_Field_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_Float_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_Integer_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_InterfaceMethod_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_Long_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_Method_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_String_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_Utf8_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.Class_Info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.Field_Info;
import com.gsoft.common.compiler.classloader.Loader;
import com.gsoft.common.compiler.classloader.PathClassLoader;
import com.gsoft.common.util.Array;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListChar;
import com.gsoft.common.util.ArrayListInt;
import com.gsoft.common.util.HighArray;
import com.gsoft.common.util.HighArray_CodeChar;
import com.gsoft.common.util.HighArray_byte;
import com.gsoft.common.util.Util;
import com.gsoft.common.util.hash.Hashtable2_Object;

import com.gsoft.common.compiler.bytecode.TypeDescriptor;
import com.gsoft.common.compiler.bytecode.ByteCodeGeneratorForClass;
import com.gsoft.common.compiler.bytecode.HighArrayCharForByteCode;

@SuppressWarnings("unused")
public class ByteCode_Types {
	/**"janesoft.common.Array"*/
	public static String ArrayFullClassName = "janesoft.common.Array";
	/**"janesoft.common.BitMaskArrForSynchronizedOrFinally"*/
	public static String BitMaskArrForSynchronizedOrFinally = "janesoft.common.BitMaskArrForSynchronizedOrFinally";
	/**"janesoft.common.MemoryManager"*/
	public static String MemoryManager = "janesoft.common.MemoryManager";
	
	/////////// HighArrayCharForByteCode에서 바이트 코드 인덱스를 찾기 위해서 사용하는 mBuffer의 인덱스들 ///////////////
	
	/**(2147483637), 
	 * 자바 가상머신에서 에러를 발생시키면 Console에서 에러를 순서에 맞게 출력하기 위해 Fake try, catch문을 사용한다.
	 * e.printStackTrace(System.out)을 참조한다.*/
	public static int startIndexOfFakeTryInMain = Integer.MAX_VALUE-10;
	/**(2147483638), 
	 * 자바 가상머신에서 에러를 발생시키면 Console에서 에러를 순서에 맞게 출력하기 위해 Fake try, catch문을 사용한다.
	 * e.printStackTrace(System.out)을 참조한다.*/
	public static int endIndexOfFakeTryInMain = Integer.MAX_VALUE-9;
	/**(2147483639), 
	 * 자바 가상머신에서 에러를 발생시키면 Console에서 에러를 순서에 맞게 출력하기 위해 Fake try, catch문을 사용한다.
	 * e.printStackTrace(System.out)을 참조한다.*/
	public static int startIndexOfFakeCatchInMain = Integer.MAX_VALUE-8;
	/**(2147483640), 
	 * 자바 가상머신에서 에러를 발생시키면 Console에서 에러를 순서에 맞게 출력하기 위해 Fake try, catch문을 사용한다.
	 * e.printStackTrace(System.out)을 참조한다.*/
	public static int endIndexOfFakeCatchInMain = Integer.MAX_VALUE-7;
	
	/**(2147483627)*/
	public static int startIndexOfFakeTryInFuncWithSync = Integer.MAX_VALUE-20;
	/**(2147483628)*/
	public static int endIndexOfFakeTryInFuncWithSync = Integer.MAX_VALUE-19;
	
	/**(2147483629)*/
	public static int startIndexOfFakeFinallyInFuncWithSync = Integer.MAX_VALUE-18;
	/**(2147483630)*/
	public static int endIndexOfFakeFinallyInFuncWithSync = Integer.MAX_VALUE-17;
	/**2147483631*/
	public static int startIndexOfFakeFinallyHandlerInFuncWithSync = Integer.MAX_VALUE-16;
	
	
	
	/*********************** Refer to Enum.printCompareTo()*****************************/
	public static int mBufferIndexOfconditionOfOrdinalOfThisLessThanOrdinalOfO = Integer.MAX_VALUE-37;
	public static int mBufferIndexOfexit_of_conditionOfOrdinalOfThisLessThanOrdinalOfO = Integer.MAX_VALUE-36;
	public static int mBufferIndexOfRunOfOrdinalOfThisLessThanOrdinalOfO = Integer.MAX_VALUE-35;	
	public static int mBufferIndexOfexit_of_ifOfOrdinalOfThisLessThanOrdinalOfO = Integer.MAX_VALUE-34;
	
	public static int mBufferIndexOfconditionOfOrdinalOfThisEqualOrdinalOfO = Integer.MAX_VALUE-33;
	public static int mBufferIndexOfexit_of_conditionOfOrdinalOfThisEqualOrdinalOfO = Integer.MAX_VALUE-32;
	public static int mBufferIndexOfRunOfOrdinalOfThisEqualOrdinalOfO = Integer.MAX_VALUE-31;
	public static int mBufferIndexOfexit_of_ifOfOrdinalOfThisEqualOrdinalOfO = Integer.MAX_VALUE-30;
	
	
	
	
	
	/**returns start, end, handler index of TryCatchShieldForConsole or TryFinallyShieldForFuncWithSync	<br>
	(2147483637)startIndexOfFakeTryInMain	<br>
	(2147483638)endIndexOfFakeTryInMain = Integer.MAX_VALUE-9;	<br>
	(2147483639)startIndexOfFakeCatchInMain = Integer.MAX_VALUE-8;	<br>
	(2147483640)endIndexOfFakeCatchInMain	<br>
	(2147483627)startIndexOfFakeTryInFuncWithSync = Integer.MAX_VALUE-20;	<br>
	(2147483628)endIndexOfFakeTryInFuncWithSync = Integer.MAX_VALUE-19;	<br>
	(2147483629)startIndexOfFakeFinallyInFuncWithSync = Integer.MAX_VALUE-18;	<br>
	(2147483630)endIndexOfFakeFinallyInFuncWithSync = Integer.MAX_VALUE-17;	<br>
	(2147483631)startIndexOfFakeFinallyHandlerInFuncWithSync	<br>
	 * @param type : 0(start), 1(end), 2(handler)*/
        public static int getFakeTryCatchFinallyIndex(FindSpecialBlockParams special, int type) {
        	if (special.anotherName.equals(TryCatchShieldForConsole)) {
        		if (special.specialBlockType==FindSpecialBlockParams.SpecialBlockType_try) {
	        		if (type==0) return ByteCode_Types.startIndexOfFakeTryInMain;
	        		else if (type==1) return ByteCode_Types.endIndexOfFakeTryInMain;
        		}
        		else if (special.specialBlockType==FindSpecialBlockParams.SpecialBlockType_catch) {
	        		if (type==0) return ByteCode_Types.startIndexOfFakeCatchInMain;
	        		else if (type==1) return ByteCode_Types.endIndexOfFakeCatchInMain;
        		}
        	}
        	else if (special.anotherName.equals(TryFinallyShieldForFuncWithSync)) {
        		if (special.specialBlockType==FindSpecialBlockParams.SpecialBlockType_try) {
	        		if (type==0) return ByteCode_Types.startIndexOfFakeTryInFuncWithSync;
	        		else if (type==1) return ByteCode_Types.endIndexOfFakeTryInFuncWithSync;
        		}
        		else if (special.specialBlockType==FindSpecialBlockParams.SpecialBlockType_finally) {
	        		if (type==0) return ByteCode_Types.startIndexOfFakeFinallyInFuncWithSync;
	        		else if (type==1) return ByteCode_Types.endIndexOfFakeFinallyInFuncWithSync;
	        		else if (type==2) return ByteCode_Types.startIndexOfFakeFinallyHandlerInFuncWithSync;
        		}
        	}
        	return -1;
        }
	
	public static String TryCatchShieldForConsole = "TryCatchShieldForConsole";
	public static String TryFinallyShieldForFuncWithSync = "TryFinallyShieldForFuncWithSync";
	
	/**if (i==9) if (i==3) continue;와 같이 '{', '}'이 없는 if문일 경우 exit of if-elseif-else, 
	 * getIndexInmBuffer()의 mode 3번을 참조한다.*/
	/*public static int getEndIndexOfNestingIfWithoutMiddlePair(int nameIndex) {
		return Integer.MAX_VALUE-nameIndex;
	}*/
	
	/**finally에서 가짜로 만든 throwable 예외 변수*/
	public static String throwableVarNameForFinallyBlock = "__varForLocalVarForFinallyBlock";
	
	/**new ProcessBuilder("java", "-jar", "***.jar")와 같은 함수인 경우 String[]임시지역변수<br>
	System.out.printf("%d %f", 1, 0.5f)와 같은 함수인 경우 Object[]	임시지역변수<br>
	Compiler.FindAllClassesAndItsMembers2_part2(...) 에서 등록한다.*/
	public static String varNameForTempLocalArrayInitializer = "__varForTempLocalArrayInitializer";
	
	/**while (i==9) if (i==3) continue;와 같이 '{', '}'이 없는 while, for문 등일 경우 exit of while 등, exit of YYY<br>
	 *  여기에서 while과 if의 endIndex는 동일해지므로 새로운 endIndex를 나타내는 
		 * endIndexWhenNestingControlBlockWithoutMiddlePair을 갖는다.<br>
	 * getIndexInmBuffer()의 mode 2번을 참조한다.*/
	public static int getEndIndexOfNestingControlBlockWithoutMiddlePair(int nameIndex) {
		return Integer.MAX_VALUE-nameIndex;
	}
	
	
	
	
	
	
	/** var가 catch블록의 괄호안에 선언된 예외이면 true, 그렇지 않으면 false를 리턴한다.*/
	static boolean isVarACatchException(Compiler compiler, FindVarParams var) {
		Block block = (Block) var.parent;
		if (block instanceof FindControlBlockParams) {
			FindControlBlockParams controlBlock = (FindControlBlockParams) block;
			if (controlBlock.catOfControls==null) { 
				FindSpecialBlockParams special = (FindSpecialBlockParams) controlBlock;
				String keyword = special.getName();
				if (keyword.equals("catch")) {
					if (controlBlock.indexOfLeftParenthesis()<=var.startIndex() && 
							var.endIndex()<=controlBlock.indexOfRightParenthesis()) {
						return true;
					}
				}
			}
		}
		return false;
	}
	
	public static Hashtable2_Object hashTableInstructionSet;
	
	
	static short accessModifierToShort(AccessModifier modifier, ClassFieldMethod type) {
		short accessFlags = 0;
		if (type==ClassFieldMethod.Class) {
			/**Flag Name Value Interpretation 
			ACC_PUBLIC 0x0001 Declared public; may be accessed from outside its package. 
			ACC_FINAL 0x0010 Declared final; no subclasses allowed. 
			ACC_SUPER 0x0020 Treat superclass methods specially when invoked by the invokespecial instruction. 
			ACC_INTERFACE 0x0200 Is an interface, not a class. 
			ACC_ABSTRACT 0x0400 Declared abstract; must not be instantiated. 
			ACC_SYNTHETIC 0x1000 Declared synthetic; Not present in the source code. 
			ACC_ANNOTATION 0x2000 Declared as an annotation type. 
			ACC_ENUM 0x4000 Declared as an enum type.*/
			if (modifier.accessPermission == AccessPermission.Public)
				accessFlags |= 0x0001;				
			if (modifier.accessPermission == AccessPermission.Private)
				accessFlags |= 0x0002;			
			if (modifier.accessPermission == AccessPermission.Protected)
				accessFlags |= 0x0004;
			//if (modifier.isStatic)
			//	accessFlags |= 0x0008;
			if (modifier.isFinal)
				accessFlags |= 0x0010;
			if (modifier.isSuper)
				accessFlags |= 0x0020;
			if (modifier.isInterface) {
				accessFlags |= 0x0200;
			}
			if (modifier.isAbstract)
				accessFlags |= 0x0400;
			
			// class에서 사용시에는 enum타입, 필드에서 사용시는 enum의 원소이다.
			if (modifier.isEnum)
				accessFlags |= 0x4000;			
		}
		else if (type==ClassFieldMethod.Field) {
			 /**Flag Name 		Value Interpretation 
			 * ACC_PUBLIC 		0x0001 Declared public; may be accessed from outside its package. 
			 * ACC_PRIVATE 		0x0002 Declared private; usable only within the defining class. 
			 * ACC_PROTECTED 	0x0004 Declared protected; may be accessed within subclasses. 
			 * ACC_STATIC 		0x0008 Declared static. 
			 * ACC_FINAL	 	0x0010 Declared final; no further assignment after initialization. 
			 * ACC_VOLATILE 	0x0040 Declared volatile; cannot be cached. 
			 * ACC_TRANSIENT 	0x0080 Declaredtransient; not written or read by a persistent object manager. 
			 * ACC_SYNTHETIC 	0x1000 Declared synthetic; Not present in the source code. 
			 * ACC_ENUM 		0x4000 Declared as an element of an enum.*/
			if (modifier.accessPermission == AccessPermission.Public)
				accessFlags |= 0x0001;				
			if (modifier.accessPermission == AccessPermission.Private)
				accessFlags |= 0x0002;			
			if (modifier.accessPermission == AccessPermission.Protected)
				accessFlags |= 0x0004;
			
			if (modifier.isStatic)
				accessFlags |= 0x0008;
			if (modifier.isFinal)
				accessFlags |= 0x0010;
			if (modifier.isEnum)
				accessFlags |= 0x4000;
		
		}
		else if (type==ClassFieldMethod.Method) {
			/**Flag Name Value Interpretation
			ACC_PUBLIC 0x0001 Declared public ; may be accessed	from outside its package.
			ACC_PRIVATE 0x0002 Declared private ; accessible only within the defining class.
			ACC_PROTECTED 0x0004 Declared protected ; may be accessed within subclasses.
			ACC_STATIC 0x0008 Declared static .
			ACC_FINAL 0x0010 Declared final ; must not be over-ridden.
			ACC_SYNCHRONIZED 0x0020 Declared synchronized ; invocation is wrapped in a monitor lock.
			ACC_BRIDGE 0x0040 A bridge method, generated by the	compiler.
			ACC_VARARGS 0x0080 Declared with variable number of	arguments.
			ACC_NATIVE 0x0100 Declared native ; implemented in a language other than Java.
			ACC_ABSTRACT 0x0400 Declared abstract ; no implementa-tion is provided.
			ACC_STRICT 0x0800 Declared strictfp ; floating-point mode is FP-strict
			ACC_SYNTHETIC 0x1000 Declared synthetic ; Not present in the source code.*/
			if (modifier.accessPermission == AccessPermission.Public)
				accessFlags |= 0x0001;				
			if (modifier.accessPermission == AccessPermission.Private)
				accessFlags |= 0x0002;			
			if (modifier.accessPermission == AccessPermission.Protected)
				accessFlags |= 0x0004;
			
			if (modifier.isStatic)
				accessFlags |= 0x0008;
			if (modifier.isFinal)
				accessFlags |= 0x0010;			
			if (modifier.isSynchronized)
				accessFlags |= 0x0020;
			if (modifier.isNative) {
				accessFlags |= 0x0100;
				//accessFlags |= 0x0400;
			}
			if (modifier.isAbstract)
				accessFlags |= 0x0400;
		
		}
		
		return accessFlags;
	}
	
	/**
	 * @param accessFlags
	 * @param type
	 * @return
	 */
	public static AccessModifier toAccessModifier(short accessFlags, ClassFieldMethod type) {
		AccessModifier modifier = new AccessModifier(null, -1, -1);
		if (type==ClassFieldMethod.Class) {
			/** Flag Name Value Interpretation 
			ACC_PUBLIC 0x0001 Declared public; may be accessed from outside its package. 
			ACC_FINAL 0x0010 Declared final; no subclasses allowed. 
			ACC_SUPER 0x0020 Treat superclass methods specially when invoked by the invokespecial instruction. 
			ACC_INTERFACE 0x0200 Is an interface, not a class. 
			ACC_ABSTRACT 0x0400 Declared abstract; must not be instantiated. 
			ACC_SYNTHETIC 0x1000 Declared synthetic; Not present in the source code. 
			ACC_ANNOTATION 0x2000 Declared as an annotation type. 
			ACC_ENUM 0x4000 Declared as an enum type.*/
			if ((accessFlags & 0x0001)==0x0001)
				modifier.accessPermission = AccessPermission.Public;
			
			modifier.accessPermission = AccessPermission.Public;
			
			if ((accessFlags & 0x0008)==0x0008)
				modifier.isStatic = true;
			if ((accessFlags & 0x0010)==0x0010)
				modifier.isFinal = true;
			if ((accessFlags & 0x0020)==0x0020)
				modifier.isSuper = true;
			if ((accessFlags & 0x0200)==0x0200)
				modifier.isInterface = true;
			if ((accessFlags & 0x0400)==0x0400)
				modifier.isAbstract = true;
			
			// class에서 사용시에는 enum타입, 필드에서 사용시는 enum의 원소이다.
			if ((accessFlags & 0x4000)==0x4000)
				modifier.isEnum = true;
		}
		else if (type==ClassFieldMethod.Field) {
			 /** Flag Name 		Value Interpretation 
			 * ACC_PUBLIC 		0x0001 Declared public; may be accessed from outside its package. 
			 * ACC_PRIVATE 		0x0002 Declared private; usable only within the defining class. 
			 * ACC_PROTECTED 	0x0004 Declared protected; may be accessed within subclasses. 
			 * ACC_STATIC 		0x0008 Declared static. 
			 * ACC_FINAL	 	0x0010 Declared final; no further assignment after initialization. 
			 * ACC_VOLATILE 	0x0040 Declared volatile; cannot be cached. 
			 * ACC_TRANSIENT 	0x0080 Declaredtransient; not written or read by a persistent object manager. 
			 * ACC_SYNTHETIC 	0x1000 Declared synthetic; Not present in the source code. 
			 * ACC_ENUM 		0x4000 Declared as an element of an enum.*/
			if ((accessFlags & 0x0001)==0x0001)
				modifier.accessPermission = AccessPermission.Public;
			if ((accessFlags & 0x0002)==0x0002)
				modifier.accessPermission = AccessPermission.Private;
			if ((accessFlags & 0x0004)==0x0004)
				modifier.accessPermission = AccessPermission.Protected;
			
			if (modifier.accessPermission==null) 
				modifier.accessPermission = AccessPermission.Default;
			
		
			if ((accessFlags & 0x0008)==0x0008)
				modifier.isStatic = true;
			if ((accessFlags & 0x0010)==0x0010)
				modifier.isFinal = true;
			if ((accessFlags & 0x4000)==0x4000)
				modifier.isEnum = true;
		}
		else if (type==ClassFieldMethod.Method) {
			/**Flag Name Value Interpretation
			ACC_PUBLIC 0x0001 Declared public ; may be accessed	from outside its package.
			ACC_PRIVATE 0x0002 Declared private ; accessible only within the defining class.
			ACC_PROTECTED 0x0004 Declared protected ; may be accessed within subclasses.
			ACC_STATIC 0x0008 Declared static .
			ACC_FINAL 0x0010 Declared final ; must not be over-ridden.
			ACC_SYNCHRONIZED 0x0020 Declared synchronized ; invocation is wrapped in a monitor lock.
			ACC_BRIDGE 0x0040 A bridge method, generated by the	compiler.
			ACC_VARARGS 0x0080 Declared with variable number of	arguments.
			ACC_NATIVE 0x0100 Declared native ; implemented in a language other than Java.
			ACC_ABSTRACT 0x0400 Declared abstract ; no implementa-tion is provided.
			ACC_STRICT 0x0800 Declared strictfp ; floating-point mode is FP-strict
			ACC_SYNTHETIC 0x1000 Declared synthetic ; Not present in the source code.*/
			if ((accessFlags & 0x0001)==0x0001)
				modifier.accessPermission = AccessPermission.Public;
			if ((accessFlags & 0x0002)==0x0002)
				modifier.accessPermission = AccessPermission.Private;
			if ((accessFlags & 0x0004)==0x0004)
				modifier.accessPermission = AccessPermission.Protected;
			
			if (modifier.accessPermission==null) 
				modifier.accessPermission = AccessPermission.Default;
			
		
			if ((accessFlags & 0x0008)==0x0008)
				modifier.isStatic = true;
			if ((accessFlags & 0x0010)==0x0010)
				modifier.isFinal = true;
			if ((accessFlags & 0x0020)==0x0020)
				modifier.isSynchronized = true;
			if ((accessFlags & 0x0100)==0x0100) 
				modifier.isNative = true;
			if ((accessFlags & 0x0400)==0x0400)
				modifier.isAbstract = true;
		}
		return modifier;
		
		
	}
	
	
	
	public enum ClassFieldMethod {
		Class,
		Field,
		Method
	}
	
	
	
	
	
	public static class ByteCodeInstruction {
		public String mnemonic;
		/** 해시테이블의 키가 된다.*/
		public short opcodeHexa;
		/**"lookupswitch" (4개이상), "tableswitch" (4개이상), "wide" (3개나 5개) 은 
		 * 가변 인덱스를 갖는다. opcode의 인덱스 개수*/
		public short numOfOtherBytes;
		/** numOfOtherBytes 개의 다른 바이트들을 갖는다. 
		 * Code_Attribute 의 toString()에서 호출한다. short or int*/
		public ArrayListInt indices;
		public String messageOfIndices;
		public String message;
		public boolean hasError;
		
		/** tableswitch의 경우 패딩의 개수는 원래 0-3까지 4개이나 더 많을 수도 있다.*/
		public short countOfPadding;
		
		ByteCodeInstruction(String mnemonic, short opcodeHexa, short numOfOtherBytes) {
			this.mnemonic = mnemonic;
			this.opcodeHexa = opcodeHexa;
			this.numOfOtherBytes = numOfOtherBytes;
			if (numOfOtherBytes!=0) {
				indices = new ArrayListInt(numOfOtherBytes);
			}
		}
		
		ByteCodeInstruction(String mnemonic, short opcodeHexa, short numOfOtherBytes, String message) {
			this.mnemonic = mnemonic;
			this.opcodeHexa = opcodeHexa;
			this.numOfOtherBytes = numOfOtherBytes;
			if (numOfOtherBytes!=0) {
				indices = new ArrayListInt(numOfOtherBytes);
			}
			this.message = message;
		}
		
		/** instruction 을 복사하는 생성자, 
		 * 예를들어 goto 문은 쓰임에 따라 인덱스가 달라지기 때문에 
		 * indices 를 새로 만들어야 한다.*/
		ByteCodeInstruction(ByteCodeInstruction instruction) {
			this.mnemonic = instruction.mnemonic;
			this.opcodeHexa = instruction.opcodeHexa;
			this.numOfOtherBytes = instruction.numOfOtherBytes;
			if (numOfOtherBytes!=0) {
				indices = new ArrayListInt(numOfOtherBytes);
			}
			this.message = instruction.message;
		}
		
		/**"lookupswitch" (4개이상), "tableswitch" (4개이상), "wide" (3개나 5개) 은 
		 * 가변 인덱스를 갖는다. Code_attribute의 toCodeString()에서 인덱스 개수가 결정된다.<br>
		 * 
		 * tableswitch<br>
		   4+: [0-3 bytes padding],<br> 
		   case의 조건들 : defaultbyte1, defaultbyte2, defaultbyte3, defaultbyte4,<br> 
		   jump offsets : lowbyte1, lowbyte2, lowbyte3, lowbyte4, highbyte1, highbyte2, highbyte3, highbyte4,<br> 
			...<br>
				
			switch (i) {<br>
			      case 0:  return  0;<br>
			      case 1:  return  1;<br>
			      case 2:  return  2;<br>
			      default: return -1;<br>
			}<br>
				<br>
		
			Type Description 
			u1   tableswitch opcode = 0xAA (170) 
			-    0-3 bytes of padding ... 
			s4   default_offset 
			s4   <low> 
			s4   <low> + N - 1 
			s4   offset_1 
			s4   offset_2 
			... 
			... 
			s4   offset_N 
			* */	
		boolean hasVariableIndices() {
			if (mnemonic.equals("lookupswitch") ||  mnemonic.equals("tableswitch") || 
					mnemonic.equals("wide")) return true;
			return false;
		}
		
		
		
		/**"lookupswitch" (4개이상), "tableswitch" (4개이상), "wide" (3개나 5개) 은 
		 * 가변 인덱스임을 주의한다.
		 * instruction 의 인덱스 정보에 에러가 있으면 
		 * instruction 의 color 를 Compiler.keywordColor로 바꾼다.*/
		public CodeString toCodeString() {
			CodeString r = null;
			int textColor = Common_Settings.textColor;
			if (this.hasError) textColor = Common_Settings.keywordColor;
			if (mnemonic.equals("invokeinterface")) {
				r = new CodeString(mnemonic, Common_Settings.funcUseColor);
			}
			else {
				r = new CodeString(mnemonic, textColor);
			}
			String otherBytes = "";
			if (indices!=null) {
				for (int i=0; i</*numOfOtherBytes*/indices.count; i++) {
					try {
					int otherByte = indices.getItem(i);
					otherBytes += " #" + otherByte;
					}catch(Exception e) {
						if (Common_Settings.g_printsLog) e.printStackTrace();
					}
				}
				r = r.concate(new CodeString(otherBytes,textColor));
			}
			
			return r;
		}
		
		/**"lookupswitch" (4개이상), "tableswitch" (4개이상), "wide" (3개나 5개) 은 
		 * 가변 인덱스임을 주의한다.*/
		int getLenOfIndices() {
			return this.numOfOtherBytes;
		}
	}
	
	
	
	
	
	
	/** 바이트코드 생성시 필요하다.
	 * typeName 으로부터 디스크립터를 얻는다.
	 * typeName이 오브젝트인 경우 Lcom/gsoft/common/Util$ArrayList; 와 같이 만든다.
	 * typeName이 배열인 경우 디스크립터 앞에 '['을 차원에 맞춰서 붙인다.*/
	static void getDescriptor(String typeName, ArrayListChar result, int coreThreadID) {
		try {
		int dimension = com.gsoft.common.compiler.Array.getArrayDimension(null, typeName);
		if (dimension!=0) {
			typeName = com.gsoft.common.compiler.Array.getArrayElementType(typeName);
		}
		typeName = TemplateBase.getTemplateOriginalType(typeName);
		int i;
		for (i=0; i<dimension; i++) {
			result.add('[');
		}
		if (typeName.equals("void")) result.add('V');
		else if (typeName.equals("byte")) result.add('B');
		else if (typeName.equals("char")) result.add('C');
		else if (typeName.equals("double")) result.add('D');
		else if (typeName.equals("float")) result.add('F');
		else if (typeName.equals("int")) result.add('I');
		else if (typeName.equals("long")) result.add('J');
		else if (typeName.equals("short")) result.add('S');
		else if (typeName.equals("boolean")) result.add('Z');
		else {
			result.add('L');
			
			TypeDescriptor.getClassDescriptor(typeName, result, coreThreadID);
			result.add(';');
			
		}
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
			return;
		}
	}
	
	
	
	
	
	
	
	
	/** method_info의 attribute이다.*/
	static class Exceptions_attribute implements IReset {
		/** attribute_name_index, attribute_length 이 처음 6바이트를 제외해야 한다.
		 *  Attribute_Info에서 이미 읽었다.*/
		int attribute_name_index;
		/** attribute_name_index, attribute_length 이 처음 6바이트를 제외해야 한다.
		 *  Attribute_Info에서 이미 읽었다.*/
		int attribute_length;
		/**exception_index_table의 entry 개수*/
		int number_of_exceptions;
		/** 각각의 값은 constant table로의 인덱스이다. 
		 * 인덱스가 가리키는 constant table내 값은 CONSTANT_Class_info이다.
		 * CONSTANT_Class_info는 메서드가 throw하는 클래스 타입이다. 예외 타입이다.
		 */
		int[] exception_index_table;
		public int readBytesLen;
		
		public static Exceptions_attribute read(InputStream is, boolean IsLittleEndian) {
			Exceptions_attribute r = new Exceptions_attribute();
			//r.attribute_name_index = IO.readUnsignedShort(is, IsLittleEndian);
			//r.attribute_length = IO.readInt(is, IsLittleEndian);
			r.number_of_exceptions = IO.readUnsignedShort(is, IsLittleEndian);
			r.readBytesLen += 2;
			
			r.exception_index_table = new int[r.number_of_exceptions];
			int i;
			for (i=0; i<r.number_of_exceptions; i++) {
				r.exception_index_table[i] = IO.readUnsignedShort(is, IsLittleEndian);
				r.readBytesLen += 2;
			}
			return r;
		}

		public void destroy() {
			
			exception_index_table = null;
		}
	}
	
	static class Exception_Entry implements IReset {
		/** 예외핸들러가 활동(try)중인 code 배열안 범위, [start_pc(포함), end_pc(불포함)), opcode 의 인덱스, 
		 * nested 될 수 있다. end_pc보다 항상 작다.*/
		public int start_pc;
		/** 예외핸들러가 활동(try)중인 code 배열안 범위, [start_pc(포함), end_pc(불포함)), opcode 의 인덱스나 code 배열의 길이,
		 * nested 될 수 있다. start_pc보다 항상 크다.*/
		public int end_pc;
		/** 예외핸들러의 시작, opcode 의 인덱스*/
		public int handler_pc;
		/** catch_type 이 0이 아니면 constant table 내 CONSTANT_Class_info의 인덱스,
		 * 이것은 catch 해야 할 예외 클래스 타입이다.
		 * catch_type 이 0이면 모든 예외에 대해서 실행되는 finally 구문이 된다.
		 */
		public int catch_type;
		
		/**catch나 finally의 nameIndex*/
		public int mBufferIndexOfNameOfCatchOrFinally;
		public boolean updatedInchangeJumpIndexOfIfAndGotoInCalledFinallyAndOriginalFinally;
		int readBytesLen;
		
		/**바이트코드를 생성할 때 필요*/
		public Exception_Entry(int start_pc, int end_pc, int handler_pc, int catch_type, int mBufferIndexOfNameOfCatchOrFinally) {
			this.start_pc = start_pc;
			this.end_pc = end_pc;
			this.handler_pc = handler_pc;
			this.catch_type = catch_type;
			this.mBufferIndexOfNameOfCatchOrFinally = mBufferIndexOfNameOfCatchOrFinally;
		}
				
		
		public Exception_Entry() {
			
		}
		
		public static int getAttributeLength() {
			return 2 * 4;
		}
		
		public static void write(OutputStream output, Exception_Entry entry, boolean IsLittleEndian) {
			IO.writeShort(output, (short)entry.start_pc, IsLittleEndian);
			IO.writeShort(output, (short)entry.end_pc, IsLittleEndian);
			IO.writeShort(output, (short)entry.handler_pc, IsLittleEndian);
			IO.writeShort(output, (short)entry.catch_type, IsLittleEndian);
		}
		
		public static Exception_Entry read(InputStream is, boolean IsLittleEndian) {
			Exception_Entry r = new Exception_Entry();
			r.start_pc = IO.readUnsignedShort(is, IsLittleEndian);
			r.end_pc = IO.readUnsignedShort(is, IsLittleEndian);
			r.handler_pc = IO.readUnsignedShort(is, IsLittleEndian);
			r.catch_type = IO.readUnsignedShort(is, IsLittleEndian);
			
			r.readBytesLen += 8;
			return r;
		}

		public void destroy() {
			
			
		}
	}
	
	/** local_variable_table의 엔트리, 
	 * 각 엔트리는 어떤 지역변수가 값을 갖고있는 Code_Attribute 내 code 배열안에서 인덱스 범위를 말한다.*/
	static class LocalVariableTable_Entry implements IReset { 
		public int readBytesLen;
		/**  주어진 지역변수는 Code_Attribute 의 code array 안 
		 * [start_pc, start_pc+length) 인덱스 구간내에서 값을 갖는다. 
		 * start_pc 는 code 배열로의 opcode 인덱스이다.
		 */
		int start_pc;
		/**  주어진 지역변수는 Code_Attribute 의 code array 안 
		 * [start_pc, start_pc+length) 인덱스 구간내에서 값을 갖는다. 
		 * start_pc+length 는 code 배열로의 opcode 인덱스이거나 code 배열의 끝 다음 인덱스이다.
		 */
		int length;
		/** CONSTANT_Utf8_info 의 constant table 내 인덱스,  지역변수의 unqualified name */
		int name_index;
		/** CONSTANT_Utf8_info 의 constant table 내 인덱스, 
		 * 지역변수의 타입을 표현하는 디스크립터*/
		int descriptor_index;
		/** 현재 스택프레임내 지역변수 array 내 어떤 지역변수의 인덱스, 
		 * long 이나 double 의 경우 index, index+1을 말한다.*/
		int index;
		
		/** 지역변수의 unqualified name*/
		String name;
		/** 지역변수의 타입, I, Ljava/lang/Object; 등*/
		String descriptor;
		
		FindSpecialBlockParams tryCatchFinally;
		
		/** LocalVariableTable_Entry의 바이트 길이, u2*5=10 <br>
		 *  u2 start_pc; <br>
			u2 length; <br>
			u2 name_index; <br>
			u2 descriptor_index; <br>
			u2 index; <br>
		*/
		public static int getAttributeLength() {
			return 2*5; // u2 * 5
		}
		
		public String toString() {
			return " name="+name+" desc="+descriptor+" scope=["+start_pc+", "+start_pc+"+"+length+"), index="+index+", ";
		}
		
		/** u2 start_pc; <br>
			u2 length; <br>
			u2 name_index; <br>
			u2 descriptor_index; <br>
			u2 index; <br>
		 * @param coreThreadID 
		*/
		public static void write(OutputStream output, ByteCodeGeneratorForClass generator, 
				FindFunctionParams func, FindVarParams var, int index, boolean IsLittleEndian, int indexOfFunc, int coreThreadID) {
			
			short start_pc = (short) var.start_pcOfScope;
			short length = 0;
			
			if (var.fieldName.equals("this")) {
			}
		
		
			// 지역변수의 scope(life time)가 function에서 끝나는 경우에는 
			// end_pcOfScope는 code.length가 된다. HighArrayCharForByteCode.createConstantTableIndex()를 참조한다.
			/*if (var.end_pcOfScope==-1) {
				if (func.name.equals("main")) {
					int a;
					a=0;
					a++;
				}
				var.end_pcOfScope = generator.physical.arrResult3[indexOfFunc].count;
			}*/
			var.end_pcOfScope = generator.physical.arrResult3[indexOfFunc].count;
			
			length = (short) (var.end_pcOfScope - start_pc);
			
			// constant table에서 CONSTANT_Utf8_info를 가리킨다.
			HashItemOfConstantTable hashItemName = 
					(HashItemOfConstantTable) generator.physical.listOfConstantTableUtf8Hashed.getData(var.fieldName);
			String typeDesc = TypeDescriptor.getDescriptor(var, coreThreadID);
			//String typeDesc = TypeDescriptor.getDescriptorExceptLAndSemicolon(var, coreThreadID);
			HashItemOfConstantTable hashItemType = 
					(HashItemOfConstantTable) generator.physical.listOfConstantTableUtf8Hashed.getData(typeDesc);
			
			
			IO.writeShort(output, start_pc, IsLittleEndian); // 안 쓴다.
			IO.writeShort(output, length, IsLittleEndian);	// 안 쓴다.
			try {
			IO.writeShort(output, (short)hashItemName.index, IsLittleEndian);
			IO.writeShort(output, (short)hashItemType.index, IsLittleEndian);
			}catch(Exception e) {
				if (Common_Settings.g_printsLog) e.printStackTrace();
			}
			IO.writeShort(output, (short)index, IsLittleEndian);
		}
		
		public static LocalVariableTable_Entry read(InputStream is, ArrayList constantTable, boolean IsLittleEndian) {
			LocalVariableTable_Entry r = new LocalVariableTable_Entry();
			r.start_pc = IO.readUnsignedShort(is, IsLittleEndian);
			r.length = IO.readUnsignedShort(is, IsLittleEndian);
			r.name_index = IO.readUnsignedShort(is, IsLittleEndian);
			r.descriptor_index = IO.readUnsignedShort(is, IsLittleEndian);
			r.index = IO.readUnsignedShort(is, IsLittleEndian);
			
			r.readBytesLen += 10;
			try {
			r.name = ((CONSTANT_Utf8_info)constantTable.getItem(r.name_index)).str;
			r.descriptor = ((CONSTANT_Utf8_info)constantTable.getItem(r.descriptor_index)).str;
			}catch(Exception e) {
				if (Common_Settings.g_printsLog) e.printStackTrace();
			}
			return r;
		}

		public void destroy() {
			
			this.name = null;
			this.descriptor = null;
		}
	}
	
	
	static class LocalVariableTable_attribute implements IReset {
		/** attribute_name_index, attribute_length 이 처음 6바이트를 제외해야 한다.
		 *  Attribute_Info에서 이미 읽었다.*/
		int attribute_name_index;
		/** attribute_name_index, attribute_length 이 처음 6바이트를 제외해야 한다.
		 *  Attribute_Info에서 이미 읽었다.*/
		int attribute_length;
		/** local_variable_table 의 엔트리 개수*/
		int local_variable_table_length;
		/**local_variable_table_length 개 만큼 할당*/
		LocalVariableTable_Entry[] local_variable_table;
		private FindFunctionParams func;
		private int indexOfFunc;
		private ByteCodeGeneratorForClass generator;
		public int readBytesLen;
		
		
		
		/** Attribute_Info 의 attribute_length 만큼 읽어들인다.*/
		public static LocalVariableTable_attribute toLocalVariableTable_attribute(InputStream is, 
				ArrayList constantTable, boolean IsLittleEndian) throws IOException {
			LocalVariableTable_attribute r = new LocalVariableTable_attribute();
			// Attribute_info 에서 이미 읽었으므로 읽지 않는다.
			//r.attribute_name_index = IO.readUnsignedShort(is);
			//r.attribute_length = IO.readInt(is);
			
			r.local_variable_table_length = IO.readUnsignedShort(is, IsLittleEndian); // 18, 18
			r.readBytesLen += 2;
			
			r.local_variable_table = new LocalVariableTable_Entry[r.local_variable_table_length];
			int i;
			for (i=0; i<r.local_variable_table_length; i++) {
				// this : index=0, owner=1, bounds=2
				r.local_variable_table[i] = LocalVariableTable_Entry.read(is, constantTable, IsLittleEndian);
				r.readBytesLen += r.local_variable_table[i].readBytesLen;
			}
			return r;
		}
		
		LocalVariableTable_attribute() {
			
		}
		
		LocalVariableTable_attribute(FindFunctionParams func, ByteCodeGeneratorForClass generator, int indexOfFunc) {
			// 함수가 static이냐에 따라서 this를 추가또는 제외한다.
			this.func = func;
			this.indexOfFunc = indexOfFunc;
			this.generator = generator;
		
			if (func.accessModifier.isStatic) {
				//local_variable_table_length = func.listOfVariableParams.count;
				local_variable_table_length = func.listOfVariableParamsBeforeProcessLocalVars.count;
			}
			else {
				//local_variable_table_length = func.listOfVariableParams.count+1;
				local_variable_table_length = func.listOfVariableParamsBeforeProcessLocalVars.count+1;
			}
			
		
		}
		
		/**attribute_name_index, attribute_length 6바이트를 제외한 LocalVariableTable_attribute의 길이<br>
		 * LocalVariableTable length(u2) + local_variable_table_length * 10*/
		int getAttributeLength() {
			return 
					2 + local_variable_table_length * LocalVariableTable_Entry.getAttributeLength();
		}
		
		/** local_variable_table_length와 LocalVariableTable entry 쓰기
		 * @param coreThreadID */
		public void write(OutputStream output, int coreThreadID) {
			FindFunctionParams func = this.func;
			ByteCodeGeneratorForClass generator = this.generator;
			int indexOfFunc = this.indexOfFunc;
			
			int i;
			
			// LocalVariableTable length 쓰기(LocalVariableTable의 엔트리 개수), u2			
			IO.writeShort(output, (short)local_variable_table_length, false);
			
			
			if (func.accessModifier.isStatic) {
			}
			else {
				// FindVarParams(Compiler compiler, boolean isThis, boolean isClass, boolean isSuper, FindClassParams parentClassParams) {
				// this 변수 만들기
				FindVarParams var = func.thisVar;
				if (var==null) {
					int a;
					a=0;
					a++;
				}
				LocalVariableTable_Entry.write(output, generator, func, var, var.indexOfLocalVariableTable, false, indexOfFunc, coreThreadID);
				
			}
			if (func.functionNameIndex()==3767) {
				int a;
				a=0;
				a++;
			}
			//for (i=0; i<func.listOfVariableParams.count; i++) {				
			for (i=0; i<func.listOfVariableParamsBeforeProcessLocalVars.count; i++) {
				//FindVarParams var = (FindVarParams) func.listOfVariableParams.getItem(i);
				FindVarParams var = (FindVarParams) func.listOfVariableParamsBeforeProcessLocalVars.getItem(i);
				LocalVariableTable_Entry.write(output, generator, func, var, var.indexOfLocalVariableTable, false, indexOfFunc, coreThreadID);
			}
		}
		
		public String toString() {
			String entries = "";
			int i;
			for (i=0; i<local_variable_table_length; i++) {
				entries += local_variable_table[i];
			}
			return " local_variable_table_length="+local_variable_table_length+" "+entries;
		}

		@Override
		public void destroy() {
			
			if (this.local_variable_table!=null) {
				int i;
				for (i=0; i<this.local_variable_table_length; i++) {
					this.local_variable_table[i].destroy();
					this.local_variable_table[i] = null;
				}
				this.local_variable_table = null;
			}
		}
	}
	
	
	
	
	
	
	
	/**
	 * InnerClasses_attribute {<br>
			u2 attribute_name_index;<br>
			u4 attribute_length;<br>
			u2 number_of_classes;	<br>		
			{ <br>
			u2 inner_class_info_index;<br>
			u2 outer_class_info_index;<br>
			u2 inner_name_index;<br>
			u2 inner_class_access_flags;<br>
			} classes[number_of_classes];<br>
	   }<br>
	 * @author user
	 *
	 */
	public static class InnerClasses_attribute {
		int number_of_classes;
		public Class_Info[] classes;
		ByteCodeGeneratorForClass generator;
		public int readBytesLen;

		static InnerClasses_attribute toInnerClasses_attribute(InputStream is, 
				ArrayList constantTable, boolean IsLittleEndian) {
			InnerClasses_attribute r = new InnerClasses_attribute();
			r.number_of_classes = IO.readUnsignedShort(is, IsLittleEndian);
			r.readBytesLen += 2;
			
			r.classes = new Class_Info[r.number_of_classes];
			int i;
			CONSTANT_Class_info inner_class_info, outer_class_info = null;
			for (i=0; i<r.classes.length; i++) {
				r.classes[i] = new Class_Info();
				r.classes[i].inner_class_info_index = IO.readUnsignedShort(is, IsLittleEndian);
				r.readBytesLen += 2;
				
				inner_class_info = ((CONSTANT_Class_info)constantTable.getItem(r.classes[i].inner_class_info_index));
				r.classes[i].innerClassName = ((CONSTANT_Utf8_info) constantTable.getItem(inner_class_info.name_index)).str;
				
				r.classes[i].outer_class_info_index = IO.readUnsignedShort(is, IsLittleEndian);
				r.readBytesLen += 2;
				
				if (r.classes[i].outer_class_info_index!=0) {
					outer_class_info = ((CONSTANT_Class_info)constantTable.getItem(r.classes[i].outer_class_info_index));
					r.classes[i].outerClassName = ((CONSTANT_Utf8_info) constantTable.getItem(outer_class_info.name_index)).str;
				}
				
				r.classes[i].inner_name_index = IO.readUnsignedShort(is, IsLittleEndian);
				r.readBytesLen += 2;
				
				r.classes[i].simpleInnerName = ((CONSTANT_Utf8_info) constantTable.getItem(r.classes[i].inner_name_index)).str;
				
				r.classes[i].inner_class_access_flags = IO.readShort(is, IsLittleEndian);
				r.readBytesLen += 2;
				
				r.classes[i].accessModifier = ByteCode_Types.toAccessModifier(r.classes[i].inner_class_access_flags, ClassFieldMethod.Class);
			}
			return r;
		}
		
		InnerClasses_attribute() {
			
		}
		
		InnerClasses_attribute(ByteCodeGeneratorForClass generator, int coreThreadID) {
			this.generator = generator;
			FindClassParams classParams = generator.classParams;
			// Class_Info[]
			ArrayList classesResult = new ArrayList(5);
			makeChildClasses(classParams, classesResult, coreThreadID);
			//this.classes = (Class_Info[])classesResult.getItems();
			
			this.classes = new Class_Info[classesResult.count];
			int i;
			for (i=0; i<this.classes.length; i++) {
				classes[i] = (Class_Info) classesResult.getItem(i);
			}
			this.number_of_classes = this.classes.length;
		}
		
		void makeChildClasses(FindClassParams classParams, ArrayList classesResult, int coreThreadID) {
			int i;
			// 자식 클래스부터 호출
			for (i=0; i<classParams.childClasses.count; i++) {
				FindClassParams child = (FindClassParams) classParams.childClasses.getItem(i);
				makeChildClasses(child, classesResult, coreThreadID);
			}
			
			// 현재 클래스의 Class_Info를 만든다.
			Class_Info classInfo = new Class_Info();
			
			// innerClass
			String descriptor = TypeDescriptor.getDescriptorExceptLAndSemicolon(classParams, coreThreadID);						
			HashItemOfConstantTable hashItem = 
					(HashItemOfConstantTable) generator.physical.listOfConstantTableHashed.getData(descriptor);
			classInfo.inner_class_info_index = hashItem.index;
			
			// outerClass
			if (classParams.parent!=null) {
				descriptor = TypeDescriptor.getDescriptorExceptLAndSemicolon((FindClassParams)classParams.parent, coreThreadID);						
				hashItem = 
						(HashItemOfConstantTable) generator.physical.listOfConstantTableHashed.getData(descriptor);
				classInfo.outer_class_info_index = hashItem.index;
			}
			
			String simpleName = CompilerHelper.getShortName(classParams.name);
			hashItem = 
					(HashItemOfConstantTable) generator.physical.listOfConstantTableUtf8Hashed.getData(simpleName);
			classInfo.inner_name_index = hashItem.index;
			
			classInfo.inner_class_access_flags = 
					ByteCode_Types.accessModifierToShort(classParams.accessModifier, ClassFieldMethod.Class);
			
			
			classesResult.add(classInfo);
		}
		
		/** 처음 6바이트를 제외한 바이트길이*/
		int getAttributeLength() {
			return 2 + this.number_of_classes*Class_Info.getAttributeLength();
		}
		
		void write(OutputStream os) {
			/*
			 * InnerClasses_attribute {<br>
				u2 attribute_name_index;<br>
				u4 attribute_length;<br>
				u2 number_of_classes;	<br>		
				{ <br>
				u2 inner_class_info_index;<br>
				u2 outer_class_info_index;<br>
				u2 inner_name_index;<br>
				u2 inner_class_access_flags;<br>
				} classes[number_of_classes];<br>
			  }<br>*/
			IO.writeShort(os, (short)number_of_classes, false);
			
			int i;
			for (i=0; i<this.classes.length; i++) {
				classes[i].write(os);
			}
		}
	}
	
	/** line_number_table 의 엔트리*/
	static class LineNumber_Entry implements IReset {
		public int readBytesLen;
		/** Code_Attribute의 code 배열안 인덱스, 소스파일에서 새로운 라인이 시작되었다.
		 * code_length 보다 작아야 한다.
		 */
		int start_pc;
		/** start_pc에 대응하는 소스파일의 새로운 라인 번호*/
		int line_number;
		
		/** LineNumber_Entry의 바이트 길이, u2*2=4 <br>
		 *  u2 start_pc; <br>
			u2 line_number; <br>
		*/
		public static int getAttributeLength() {
			return 2*2; // u2 * 2
		}
		
		public static LineNumber_Entry read(InputStream is, boolean IsLittleEndian) {
			LineNumber_Entry r = new LineNumber_Entry();
			r.start_pc = IO.readUnsignedShort(is, IsLittleEndian);
			r.line_number = IO.readUnsignedShort(is, IsLittleEndian);
			
			r.readBytesLen += 4;
			return r;
		}
		
		public static void write(OutputStream output, int start_pc, int line_number, boolean isLittleEndian) {
			IO.writeShort(output, (short)start_pc, isLittleEndian);
			IO.writeShort(output, (short)line_number, isLittleEndian);
		}
		
		@Override
		public void destroy() {
			
			
		}
	}
	
	/** 디버거에 의해 사용된다. 
	 * Code_Attribute의 code 배열의 어떤 부분이 소스파일의 어떤 라인을 표현하는지를 말한다.
	 * @author kjy
	 *
	 */
	static class LineNumberTable_attribute implements IReset {
		/** attribute_name_index, attribute_length 이 처음 6바이트를 제외해야 한다.
		 *  Attribute_Info에서 이미 읽었다.*/
		int attribute_name_index;
		/** attribute_name_index, attribute_length 이 처음 6바이트를 제외해야 한다.
		 *  Attribute_Info에서 이미 읽었다.*/
		int attribute_length;
		/** line_number_table 내 엔트리 개수*/
		int line_number_table_length;
		/** 각 엔트리는 code array 의 어떤 부분이 소스파일의 어떤 라인과 대응하는지를 말한다.*/
		LineNumber_Entry[] line_number_table;
		private ResultOfgetLineNumberEntries entries;
		public int readBytesLen;
		
		/** Attribute_Info 의 attribute_length 만큼 읽어들인다.*/
		public static LineNumberTable_attribute toLineNumberTable_attribute(InputStream is, 
				ArrayList constantTable, boolean IsLittleEndian) throws IOException {
			LineNumberTable_attribute r = new LineNumberTable_attribute();
			// Attribute_info 에서 이미 읽었으므로 읽지 않는다.
			//r.attribute_name_index = IO.readUnsignedShort(is);
			//r.attribute_length = IO.readInt(is);
			
			r.line_number_table_length = IO.readUnsignedShort(is, IsLittleEndian);
			r.readBytesLen += 2;
			
			r.line_number_table = new LineNumber_Entry[r.line_number_table_length];
			int i;
			for (i=0; i<r.line_number_table_length; i++) {
				r.line_number_table[i] = LineNumber_Entry.read(is, IsLittleEndian);
				r.readBytesLen += r.line_number_table[i].readBytesLen;
			}
			return r;
		}
		
		static class ResultOfgetLineNumberEntries {
			ArrayListInt listOfLineNumbers;
			ArrayListInt listOfStartPCs;
			ResultOfgetLineNumberEntries(ArrayListInt listOfLineNumbers, ArrayListInt listOfStartPCs) {
				this.listOfLineNumbers = listOfLineNumbers;
				this.listOfStartPCs = listOfStartPCs;
			}
		}
		
		ResultOfgetLineNumberEntries getLineNumberEntries(ByteCodeGeneratorForClass generator, HighArrayCharForByteCode input) {
			ResultOfgetLineNumberEntries r = null;
			ArrayListInt listOfLineNumbers = new ArrayListInt(input.listOfIndicesOfNewLines.count);
			ArrayListInt listOfStartPCs = new ArrayListInt(input.listOfIndicesOfNewLines.count);
			int i, j;
			HighArray listOfStrs = input.listOfStrs;
			ArrayListInt listOfIndicesOfNewLines = input.listOfIndicesOfNewLines;
			
			HighArray_CodeString src = generator.compiler.data.mBuffer;
			ArrayListInt listOfIndicesOfNewLinesInSrc = generator.compiler.data.mlistOfNewLines;
			
			for (i=0; i<listOfIndicesOfNewLines.count; i++) {
				int indexOfNewLine = input.listOfIndicesOfNewLines.getItem(i);
				String str = null;
				str = (String) listOfStrs.getItem(indexOfNewLine-1);
				int lineNumber = -2;
				int start_pc = -1;
				if (listOfStrs.getItem(indexOfNewLine-3).equals("[") && str.equals("]")) {
					lineNumber = Integer.parseInt((String)listOfStrs.getItem(indexOfNewLine-2));
					if (lineNumber==9814) {
						int a;
						a=0;
						a++;
					}
					int k;
					for (k=indexOfNewLine-4; k>=0; k--) {
						String str2 = (String)listOfStrs.getItem(k);
						if (str2.equals("\n")) {
							try {
							if (com.gsoft.common.compiler.Number.IsNumber2((String)listOfStrs.getItem(k+1))!=0) {
								start_pc = Integer.parseInt((String)listOfStrs.getItem(k+1));
								listOfStartPCs.add(start_pc);
							}
							else {
								int a;
								a=0;
								a++;
							}
							}catch(Exception e) {
								if (Common_Settings.g_printsLog) e.printStackTrace();
							}
							break;
						}
					}
					if (k==-1) {
						start_pc = Integer.parseInt((String)listOfStrs.getItem(0));
						listOfStartPCs.add(start_pc);
					}
					
					listOfLineNumbers.add(lineNumber);
				}
				
				
				
			}// for (i=0; i<listOfIndicesOfNewLines.count; i++) {
			
			r = new ResultOfgetLineNumberEntries(listOfLineNumbers, listOfStartPCs);
			return r;
		}
		
		LineNumberTable_attribute(FindFunctionParams func, ByteCodeGeneratorForClass generator, int indexOfFunc) {
			entries = this.getLineNumberEntries(generator, generator.physical.arrResult[indexOfFunc]);
		
			line_number_table_length = entries.listOfLineNumbers.count;
		
		}
		
		public LineNumberTable_attribute() {
			
		}

		/**attribute_name_index, attribute_length 6바이트를 제외한 LineNumberTable_attribute의 길이<br>
		 * line_number_table_length(u2) + line_number_table_length * 4*/
		int getAttributeLength() {
			return 
					2 + line_number_table_length * LineNumber_Entry.getAttributeLength();
		}
		
		/** line_number_table_length와 LineNumber_entry 쓰기*/
		public void write(OutputStream output) {
			// line_number_table_length 쓰기(LineNumberTable의 엔트리 개수), u2			
			IO.writeShort(output, (short)line_number_table_length, false);
			int i;
			ArrayListInt listOfLineNumbers = entries.listOfLineNumbers;
			ArrayListInt listOfStartPCs = entries.listOfStartPCs;
			for (i=0; i<line_number_table_length; i++) {
				LineNumber_Entry.write(output, listOfStartPCs.getItem(i), listOfLineNumbers.getItem(i), false);
			}
		}

		@Override
		public void destroy() {
			
			if (this.line_number_table!=null) {
				int i;
				for (i=0; i<this.line_number_table_length; i++) {
					this.line_number_table[i].destroy();
					this.line_number_table[i] = null;
				}
			}
		}
	}
	
	static class SourceFile_attribute implements IReset {
		/** attribute_name_index, attribute_length 이 처음 6바이트를 제외해야 한다.
		 *  Attribute_Info에서 이미 읽었다. u2*/
		int attribute_name_index;
		/** attribute_name_index, attribute_length 이 처음 6바이트를 제외해야 한다.
		 *  Attribute_Info에서 이미 읽었다. u4*/
		int attribute_length;
		
		/**u2*/
		int sourcefile_index;
		
		String sourceFileName;
		
		ByteCodeGeneratorForClass generator;
		public int readBytesLen;
		
		/** Attribute_Info 의 attribute_length 만큼 읽어들인다.*/
		public static SourceFile_attribute toSourceFile_attribute(InputStream is, 
				ArrayList constantTable, boolean IsLittleEndian) throws IOException {
			SourceFile_attribute r = new SourceFile_attribute();
			// Attribute_info 에서 이미 읽었으므로 읽지 않는다.
			//r.attribute_name_index = IO.readUnsignedShort(is);
			//r.attribute_length = IO.readInt(is);
			
			r.sourcefile_index = IO.readUnsignedShort(is, IsLittleEndian);
			r.readBytesLen += 2;
			
			CONSTANT_Utf8_info utf8Info = (CONSTANT_Utf8_info) constantTable.getItem(r.sourcefile_index);
			r.sourceFileName = utf8Info.str;
			return r;
		}
		
		/**클래스 파일을 쓸때 호출*/
		SourceFile_attribute(ByteCodeGeneratorForClass generator) {
			this.generator = generator;
			
			String sourceFileName = FileHelper.getFilename(generator.compiler.data.filename.toString());
			HashItemOfConstantTable hashItem = 
					(HashItemOfConstantTable) generator.physical.listOfConstantTableUtf8Hashed.getData(sourceFileName);
			if (hashItem!=null) {
				sourcefile_index = hashItem.index;
			}
		}
		
		public SourceFile_attribute() {
			
		}

		int getAttributeLength() {
			return 2;
		}
		
		/** sourcefile_index 쓰기*/
		public void write(OutputStream output) {
			IO.writeShort(output, (short)this.sourcefile_index, false);
		}

		@Override
		public void destroy() {
			
			
		}
		
		

	}
	
	
	
	
	static class HashItemOfConstantTable {
		int index;
		String descriptor;
		HighArray listCode = new HighArray(10);
		/**CONSTANT_Class_info, CONSTANT_Field_info, CONSTANT_Method_info 등*/ 
		Object constant_info;
		/**0(해당없음, 상수가 아님),<br> 
		 * 1(int), 2(Float), 3(Double), 4(String), 5(Long), <br> 
		 * 6(Class), 7(field), 8(method), 9(nameAndType), 10(interfaceMethod),<br> 
		 * 11(Utf8) <br>
		 * ByteCode_Physical.makeCONSTANT_XXXX_info()에서 상수 타입에 따라 설정되고,
		 * ByteCode_Physical.updateConstantTableIndex_sub()에서 상수 타입을 구분한다.*/
		byte constant_type;
		
	
		
		/**@param constant_type : 0(해당없음, 상수가 아님), 1(int), 2(Float), 3(Double), 4(String), 5(Long), 
		 * 6(Class), 7(field), 8(method), 9(nameAndType), 10(interfaceMethod), 11(Utf8)*/
		HashItemOfConstantTable(String descriptor, int constant_type) {
			this.descriptor = descriptor;
			this.constant_type = (byte)constant_type;
		}
	}
	
}