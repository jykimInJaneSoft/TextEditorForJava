package com.gsoft.common.compiler.bytecode;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.CompilerStatic;
import com.gsoft.common.compiler.Compiler_types.CategoryOfControls;
import com.gsoft.common.compiler.Compiler_types.FindAssignStatementParams;
import com.gsoft.common.compiler.Compiler_types.FindControlBlockParams;
import com.gsoft.common.compiler.Compiler_types.FindVarParams;
import com.gsoft.common.compiler.Compiler_types_Base.Block;
import com.gsoft.common.compiler.Compiler_types_Base.FindStatementParams;
import com.gsoft.common.compiler.Compiler_types_Special.FindSpecialStatementParams;
import com.gsoft.common.compiler.Expression;
import com.gsoft.common.compiler.Fullname;
import com.gsoft.common.compiler.Number;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListIReset;
import com.gsoft.common.util.Sort;
import com.gsoft.common.util.Sort.SortItemIReset;

import com.gsoft.common.compiler.bytecode.ByteCodeGeneratorForClass;
import com.gsoft.common.compiler.bytecode.ByteCode_Helper;
import com.gsoft.common.compiler.bytecode.ByteCode_Condition;
import com.gsoft.common.compiler.bytecode.HighArrayCharForByteCode;
import com.gsoft.common.compiler.bytecode.Specials;
import com.gsoft.common.compiler.bytecode.LocalVar;

public class ControlBlock {
	
	public static void printSpecialStatement(ByteCodeGeneratorForClass generator, FindSpecialStatementParams statement, HighArrayCharForByteCode result, int coreThreadID) {
		if (statement.kewordIndex()==2408) {
		}
		Compiler compiler = generator.compiler;
		String keyword = compiler.data.mBuffer.getItem(statement.kewordIndex()).str;
		if (keyword.equals("return")) {
			// printReturn()에서 처리
		}
		else if (keyword.equals("continue")) {
			ControlBlock.printContinue(generator, statement, result, coreThreadID);
		}
		else if (keyword.equals("break")) {
			ControlBlock.printBreak(generator, statement, result, coreThreadID);
		}//else if (keyword.equals("break")) {
		else if (keyword.equals("throw")) {
			// printThrow()에서 처리
		}
		
	}
	
	
	/**if-elseif-else 구조에서 해당 if, else if, else블록이 끝나면 true, 아니면 false를 리턴한다. 
	 * @param controlBlock : if-elseif-else 구조에서 해당 if, else if, else블록*/
	public static boolean if_elseEnds(FindControlBlockParams controlBlock) {
		if (controlBlock.catOfControls==null) return true;
		if (controlBlock.catOfControls.category==CategoryOfControls.Control_else)
		{
			return true;
		}
		
		// else가 아니면
		Block parentBlock = controlBlock.parent;
		FindStatementParams statement = (FindStatementParams) parentBlock.listOfControlBlocks.getItem(
				controlBlock.indexInListOfControlBlocksOfParent);
		if (statement!=null) {
			if (controlBlock.catOfControls.category==CategoryOfControls.Control_if ||
					controlBlock.catOfControls.category==CategoryOfControls.Control_elseif)
			{
				
				if (parentBlock.listOfControlBlocks.count>controlBlock.indexInListOfControlBlocksOfParent+1) {
					FindControlBlockParams control = (FindControlBlockParams) parentBlock.listOfControlBlocks.getItem(
							controlBlock.indexInListOfControlBlocksOfParent+1);
					if (control.catOfControls==null) return true;//try, catch 등
					
					if ((control.catOfControls!=null && 
							(control.catOfControls.category==CategoryOfControls.Control_elseif ||
						control.catOfControls.category==CategoryOfControls.Control_else))) {
						// 다음 제어구조가 else if이거나 else이면
						return false;
					}
					else { // 다른 if나 아니면 다른 while, for등의 제어블록이 올 경우
						return true;
					}
				}
				else {
					// parentBlock에서 마지막 블록일 경우
					return true;
				}
			}
			
		}
		return true;
	}
	
	
	
	/** @param coreThreadID 
	 * @param doNotPrintThrowOrReturn : <br>
	 * finally { <br>
	 * 		while () {<br>
	 * 			return;<br>
	 *  	}<br>
	 * }<br>
	 * 이런 경우 printFinally()에서 throw를 하기전에 return을 출력을 해서는 안된다.
	 */
	public static void printWhile(ByteCodeGeneratorForClass generator, FindControlBlockParams controlBlock, HighArrayCharForByteCode result, int coreThreadID) {
		/*Compiler compiler = generator.compiler;
		
		
		int i;
		String strIndex = "";
		
		String strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, controlBlock.nameIndex());
		
		String bufferIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)9, null);
		result.add("// "+bufferIndex+"BlockStart\n");
		
		strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)4, null);
		result.add("goto_w "+"// "+strIndex+"go to condition of "+controlBlock+strmBufferIndex+"\n");
		
		// run
		strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)0, null);
		result.add("// "+strIndex+"run of "+controlBlock+"\n");
		for (i=0; i<controlBlock.listOfStatements.count; i++) {
			FindStatementParams statement = (FindStatementParams) controlBlock.listOfStatements.getItem(i);
			generator.printFindStatementParams(statement, result, false);
		}
		
		// condition
		strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)4, null);
		result.add("// "+strIndex+"condition of "+controlBlock+"\n");
		
		
		ByteCode_Condition.printCondition(generator, controlBlock, result, null);
		
		strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)1, null);
		result.add("// "+strIndex+"exit_of_condition of "+controlBlock+"\n");
		
		
		LocalVar.printsLocalVarEnd(generator, controlBlock, result);
		
		strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)2, null);
		result.add("// "+strIndex+"exit of "+controlBlock+"\n");
		*/
		
		Compiler compiler = generator.compiler;
		
		
		String strIndex = "";
		

		// condition
		strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)4, null);
		result.add("// "+strIndex+"condition of "+controlBlock+"\n");
		
		
		ByteCode_Condition.printCondition(generator, controlBlock, result, null, coreThreadID);
		
		strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)1, null);
		result.add("// "+strIndex+"exit_of_condition of "+controlBlock+"\n");
		
		
		String sourceIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, controlBlock.indexOfRightParenthesis());		
		
		strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)2, null);
		result.add("goto_w "+"// "+strIndex+"exit of "+controlBlock+sourceIndex+"\n");
		
		// run
		strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)0, null);
		result.add("// "+strIndex+"run of "+controlBlock+"\n");
		
		printControlBlockBody(generator, controlBlock, result, coreThreadID);
		
		// 바깥 문장 리스트에 throw문을 포함하면 goto, inc를 출력하지 않는다.
		// 불필요한 문장이어서 increment문장을 출력해서는 안 된다.
		if (!Specials.containsThrowOrReturnOrBreakOrContinue(generator, controlBlock, controlBlock)) {			
			sourceIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, controlBlock.endIndex());
			strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)4, null);
			result.add("goto_w "+"// "+strIndex+"go to condition of "+controlBlock+sourceIndex+"\n");
		}
		
		
		LocalVar.printsLocalVarEnd(generator, controlBlock, result);
		
		strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)2, null);
		result.add("// "+strIndex+"exit of "+controlBlock+"\n");
	}
	
	
	
	
	
	/**		switch (i) {<br>
			      case 0:  return  0;<br>
			      case 1:  return  1;<br>
			      case 2:  return  2;<br>
			      default: return -1;<br>
			}<br>
			<br>
		
			Type Description <br>
			u1   tableswitch opcode = 0xAA (170)<br> 
			-    0-3 bytes of padding ... <br>
			s4   default_offset <br>
			s4   low <br>
			s4   low + N - 1(high)<br> 
			s4   offset_1 <br>
			s4   offset_2 <br>
			... <br>
			... <br>
			s4   offset_N <br>
			
			<br>
			
			lookupswitch
	        key1   : label1 <br>
	        key2   : label2 <br>
	        ...
	        keyN   : labelN <br>
	        default  : labelDefault <br>
	        
	        <br>
	        
			Type Description <br>
			u1  lookupswitch opcode = 0xAB (171) <br>
			-   ...0-3 bytes of padding ... <br>
			s4  default_offset <br>
			s4  n <br>
			s4  key_1 <br>
			s4  offset_1 <br>
			s4  key_2 <br>
			s4  offset_2 <br>
			... <br>
			... <br>
			s4  key_n <br>
			s4  offset_n <br>
	 * @param coreThreadID 
		*/
	public static void printSwitch(ByteCodeGeneratorForClass generator, FindControlBlockParams controlBlock, HighArrayCharForByteCode result, int coreThreadID) {
		Compiler compiler = generator.compiler;
		
		String bufferIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)9, null);
		result.add("// "+bufferIndex+"BlockStart\n");
				
		ArrayList listOfLocalVars = LocalVar.getLocalVarsDefinedInSwitch(compiler, controlBlock);
		int i;
		for (i=0; i<listOfLocalVars.count; i++) {
			FindVarParams var = (FindVarParams) listOfLocalVars.getItem(i);
			LocalVar.initializeLocalVar(generator, var, result, coreThreadID);
		}
		
		
		// switch 괄호안의 수식을 출력한다.
		generator.traverseChild(controlBlock.funcCall, result, coreThreadID);
		
		int low = 0, high = 0;
		//int i;
		int[] arrValues = new int[controlBlock.listOfControlBlocks.count];
		int count = 0;
		FindControlBlockParams defaultBlock = null;
		for (i=0; i<controlBlock.listOfControlBlocks.count; i++) {
			FindControlBlockParams caseBlock = 
					(FindControlBlockParams) controlBlock.listOfControlBlocks.getItem(i);
			if (!compiler.data.mBuffer.getItem(caseBlock.nameIndex()).equals("default")) {
				CodeString strValue = Fullname.getFullName(compiler.data.mBuffer, 
						caseBlock.indexOfLeftParenthesis(), caseBlock.indexOfRightParenthesis()-1);
				int value = 0;
				if (strValue.str.charAt(0)=='\'' || strValue.str.charAt(0)=='"') {
					// case 'ㄱ':
					// case '\t':
					String str = ByteCode_Helper.removeSymbolsOfString(strValue.str);
					str = ByteCode_Helper.processReverseSlashOfString(str);
					value = (int)str.charAt(0);
				}
				else {
					value = Number.parseInt(strValue.str);
				}
				arrValues[count++] = value;
			}
			else {
				defaultBlock = caseBlock;
			}
		}
		if (count>0) {
			// case 상수들에서 low, high값을 알아낸다.
			low = arrValues[0];
			high = arrValues[0];
			for (i=1; i<count; i++) {
				int value = arrValues[i];
				if (low>value) low = value;
				else if (high<value) high = value;
			}
		}
		
		int diff = high-low+1;
		if (diff*0.4f<count) {
			printTableSwitch(generator, controlBlock, low, high, defaultBlock, result, coreThreadID);			
		}
		else {
			printLookupSwitch(generator, controlBlock, count, low, high, defaultBlock, result, coreThreadID);
		}
		
		bufferIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)2, null);
		result.add("// "+bufferIndex+"exit of "+controlBlock+"\n");
	}
	
	/**	Type Description <br>
			u1   tableswitch opcode = 0xAA (170)<br> 
			-    0-3 bytes of padding ... <br>
			s4   default_offset <br>
			s4   low <br>
			s4   low + N - 1(high)<br> 
			s4   offset_1 <br>
			s4   offset_2 <br>
			... <br>
			... <br>
			s4   offset_N <br> 
	 * 분기할 offset을 만들 때 low와 high순으로 정렬을 하여 default를 제외한 offset을 출력한다.
	 * @param coreThreadID */
	public static void printTableSwitch(ByteCodeGeneratorForClass generator, FindControlBlockParams controlBlock, int low, int high, FindControlBlockParams defaultBlock, 
			HighArrayCharForByteCode result, int coreThreadID) {
		Compiler compiler = generator.compiler;
		
		String index = "";
				
		// tableswitch의 마지막 오프셋의 LSB 바이트가 tableswitch의 다음 명령어(아래 예에서는 fload_0)를 대신하는 바이트코드가 된다.
		// tableswitch의 마지막 오프셋은 0이 아닌  LSB 바이트가 tableswitch의 다음 명령어(아래 예에서는 fload_0)가 되고 
		// 0인 바이트들은 추가되는 패딩바이트(아래 예에서는 원래 패딩바이트 1개에서 추가된 3바이트가 된다)가 된다.
		// fload_0의 다음 명령어는 4바이트 정렬이 되어 있어야 한다.
		// 206        tableswitch #0 #0 #0 #0 #34 #0 #4 #34 #34 #34 #34;  [] // (  Default Offset : 34 Low : 0 High : 4 Offset :(0, 34)  (1, 34)  (2, 34)  (3, 34)   )
		// 239        fload_0;  [] // ( [Ljava/lang/String; args )
		// 240        return;  [] //
		
		
		// 206        tableswitch 34 1      // (587), exit of switch (a)
		// 212        low            0
		// 216        high            4
		// 220        offset 34        // (527), case  0:
		// 224        offset 34        // (541), case  1:
		// 228        offset 34        // (587), exit of switch (a)
		// 232        offset 34        // (555), case  3:
		// 236        offsetEnd 34        // (573), case  4:
		           // offset addresses end 
		           // (527), case  0:
		           // (541), case  1:
		           // (555), case  3:
		           // (573), case  4:
		           // (587), exit of switch (a)
		// 240        return           


		int curOffset = result.indexOfByteCode;
		int countOfPadding = 0;
		int countOfOffsets = high-low+1;
		// tableswitch의  다음 명령어(위 예에서 return)의 오프셋을 4바이트 정렬시키기 위해 추가하는 패딩 바이트 1을 계산한다.
		for (countOfPadding=0; countOfPadding<4; countOfPadding++) {
			// 1은 tableswitch의 바이트 길이, defaultAddress, low, high
			if ( (curOffset+1+countOfPadding+4*(1+1+1+countOfOffsets) ) % 4 == 0) {
				break;
			}
		}
		
		String strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, controlBlock.nameIndex());
				
		if (defaultBlock==null) {
			// default가 없으면 switch를 나가는 것을 default로 한다.
			index = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)2, null);
			
			result.add("tableswitch "+"// "+index+"exit of "+controlBlock+strmBufferIndex+ "\n", countOfPadding);
		}
		else {
			index = "("+defaultBlock.nameIndex()+"), ";
			result.add("tableswitch "+"// "+index+defaultBlock+strmBufferIndex+"\n", countOfPadding);
		}
		
		
		result.add("low "+low+"\n");
		result.add("high "+high+"\n");
		
		int i;
		
		// default를 제외한 offset 들을 case의 값으로 정렬한다.
		// low부터 high까지의 배열을 만들어서 case의 값으로 그 배열에 저장하여 배열순으로 반복하면
		// low와 high순으로 정렬을 한 효과를 갖게 된다. 
		FindControlBlockParams[] arr = new FindControlBlockParams[high-low+1];
		
		for (i=0; i<controlBlock.listOfControlBlocks.count; i++) {			
			FindControlBlockParams caseBlock = 
					(FindControlBlockParams) controlBlock.listOfControlBlocks.getItem(i);
			if (!compiler.data.mBuffer.getItem(caseBlock.nameIndex()).equals("default")) {
				CodeString strValue = Fullname.getFullName(compiler.data.mBuffer, 
						caseBlock.indexOfLeftParenthesis(), caseBlock.indexOfRightParenthesis()-1);
				int value;
				if (strValue.str.charAt(0)=='\'' || strValue.str.charAt(0)=='"') {
					// case 'ㄱ':
					// case '\t':
					String str = ByteCode_Helper.removeSymbolsOfString(strValue.str);
					str = ByteCode_Helper.processReverseSlashOfString(str);
					value = (int)str.charAt(0);
				}
				else {
					value = Number.parseInt(strValue.str);
				}
				arr[value-low] = caseBlock;
			}
		}
		
		// default를 제외한 offset을 출력한다.
		for (i=0; i<arr.length; i++) {			
			FindControlBlockParams caseBlock = (FindControlBlockParams) arr[i];
			String strOffset = null;
			if (i==arr.length-1) {
				strOffset = "offsetEnd ";
			}
			else {
				strOffset = "offset ";
			}
						
			
			if (caseBlock==null) {
				if (defaultBlock==null) {
					/*switch(3) {				
					case 1:
						break;
					case 2:
						return;				
					case 4:break;
					}*/
					// 여기에서 case 3이 없으므로 default로 가야 하는데 default가 없으므로 
					// switch를 나가야 한다.
					strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, controlBlock.nameIndex());
					index = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)2, null);
					result.add(strOffset+"// "+index+"exit of "+controlBlock+strmBufferIndex+ "\n");
				}
				else {
					/*switch(2) {				
					case 1:
						break;
					default:
						return;				
					case 3:break;
					}*/
					strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, defaultBlock.nameIndex());
					index = "("+defaultBlock.nameIndex()+"), ";
					result.add(strOffset+"// "+index+defaultBlock+strmBufferIndex+"\n");
				}
			}
			else {
				strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, caseBlock.nameIndex());				
				index = "("+caseBlock.nameIndex()+"), ";
				result.add(strOffset+"// "+index+caseBlock+strmBufferIndex+"\n");
			}
		}//for (i=0; i<arr.length; i++) {		
		
		result.add("// offset addresses end "+"\n");
		
		
		
		// case, default안의 코드를 출력한다.
		for (i=0; i<controlBlock.listOfControlBlocks.count; i++) {
			FindControlBlockParams caseBlock = 
					(FindControlBlockParams) controlBlock.listOfControlBlocks.getItem(i);
			//if (compiler.mBuffer.getItem(caseBlock.nameIndex()).equals("default")==false) {
			index = "("+caseBlock.nameIndex()+"), ";
			result.add("// "+index+caseBlock+"\n");
			printControlBlockBody(generator, caseBlock, result, coreThreadID);
			//}
		}
	}
	
	
	
	
	/**Type Description <br>
	u1  lookupswitch opcode = 0xAB (171) <br>
	-   ...0-3 bytes of padding ... <br>
	s4  default_offset <br>
	s4  n <br>
	s4  key_1 <br>
	s4  offset_1 <br>
	s4  key_2 <br>
	s4  offset_2 <br>
	... <br>
	... <br>
	s4  key_n <br>
	s4  offset_n <br>
	@param count : case에 있는 상수들의 개수, default는 포함 안한다.
	 * @param coreThreadID */
	public static void printLookupSwitch_backup(ByteCodeGeneratorForClass generator, FindControlBlockParams controlBlock, int count, int low, int high, 
			FindControlBlockParams defaultBlock,
			HighArrayCharForByteCode result, int coreThreadID) {
		Compiler compiler = generator.compiler;

		String index = "";

		int curOffset = result.indexOfByteCode;
		int countOfPadding = 0;
		// tableswitch의  다음 명령어(위 예에서 return)의 오프셋을 4바이트 정렬시키기 위해 추가하는 패딩 바이트 1을 계산한다.
		for (countOfPadding=0; countOfPadding<4; countOfPadding++) {
			// 1은 tableswitch의 바이트 길이, defaultAddress, count, -4는 마지막 오프셋을 제외한다.
			if ( (curOffset+1+countOfPadding+4*(1+1+2*count) ) % 4 == 0) {
				break;
			}
		}

		//countOfPadding = 0;

		if (defaultBlock==null) {
			// default가 없으면 switch를 나가는 것을 default로 한다.
			index = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)2, null);
			result.add("lookupswitch "+"// "+index+"exit of "+controlBlock+ "\n", countOfPadding);
		}
		else {
			index = "("+defaultBlock.nameIndex()+"), ";
			result.add("lookupswitch "+"// "+index+defaultBlock+"\n", countOfPadding);
		}

		result.add("count "+count+"\n");

		int i;

		// default를 제외한 offset 들을 case의 값으로 정렬한다.
		// low부터 high까지의 배열을 만들어서 case의 값으로 그 배열에 저장하여 배열순으로 반복하면
		// low와 high순으로 정렬을 한 효과를 갖게 된다. 
		FindControlBlockParams[] arr = new FindControlBlockParams[high-low+1];

		for (i=0; i<controlBlock.listOfControlBlocks.count; i++) {			
			FindControlBlockParams caseBlock = 
					(FindControlBlockParams) controlBlock.listOfControlBlocks.getItem(i);
			if (!compiler.data.mBuffer.getItem(caseBlock.nameIndex()).equals("default")) {
				CodeString strValue = Fullname.getFullName(compiler.data.mBuffer, 
						caseBlock.indexOfLeftParenthesis(), caseBlock.indexOfRightParenthesis()-1);
				int value;
				if (strValue.str.charAt(0)=='\'' || strValue.str.charAt(0)=='"') {
					// case 'ㄱ':
					value = (int)strValue.str.charAt(1);
				}
				else {
					value = Number.parseInt(strValue.str);
				}
				//int value = Integer.parseInt(strValue.str);
				arr[value-low] = caseBlock;
			}
		}


		// default를 제외한 key와 offset을 출력한다.
		for (i=0; i<arr.length; i++) {			
			FindControlBlockParams caseBlock = arr[i];
			if (caseBlock==null) continue;
			
			CodeString strValue = Fullname.getFullName(compiler.data.mBuffer, 
					caseBlock.indexOfLeftParenthesis(), caseBlock.indexOfRightParenthesis()-1);
			int key;
			if (strValue.str.charAt(0)=='\'' || strValue.str.charAt(0)=='"') {
				// case 'ㄱ':
				key = (int)strValue.str.charAt(1);
			}
			else {
				key = Number.parseInt(strValue.str);
			}
			//int key = Integer.parseInt(strValue.str);
			index = "("+caseBlock.nameIndex()+"), ";
			if (i!=arr.length-1) {
				// offset_Lookup_과 key를 연결한다.
				result.add("offset_Lookup_"+key+" // "+index+caseBlock+"\n");
			}
			else {
				// offsetEnd_Lookup_과 key를 연결한다.
				result.add("offsetEnd_Lookup_"+key+" // "+index+caseBlock+"\n");
			}
		} // for (i=0; i<arr.length; i++) {

		result.add("// offset addresses end "+"\n");



		// case, default안의 코드를 출력한다.
		for (i=0; i<controlBlock.listOfControlBlocks.count; i++) {
			FindControlBlockParams caseBlock = 
					(FindControlBlockParams) controlBlock.listOfControlBlocks.getItem(i);
			index = "("+caseBlock.nameIndex()+"), ";
			result.add("// "+index+caseBlock+"\n");
			printControlBlockBody(generator, caseBlock, result, coreThreadID);
		}
	}
	
	/**Type Description <br>
			u1  lookupswitch opcode = 0xAB (171) <br>
			-   ...0-3 bytes of padding ... <br>
			s4  default_offset <br>
			s4  n <br>
			s4  key_1 <br>
			s4  offset_1 <br>
			s4  key_2 <br>
			s4  offset_2 <br>
			... <br>
			... <br>
			s4  key_n <br>
			s4  offset_n <br>
		@param count : case에 있는 상수들의 개수, default는 포함 안한다.
	 * @param coreThreadID */
	public static void printLookupSwitch(ByteCodeGeneratorForClass generator, FindControlBlockParams controlBlock, int count, int low, int high, 
			FindControlBlockParams defaultBlock,
			HighArrayCharForByteCode result, int coreThreadID) {
		Compiler compiler = generator.compiler;
		
		String index = "";
		
		int curOffset = result.indexOfByteCode;
		int countOfPadding = 0;
		// tableswitch의  다음 명령어(위 예에서 return)의 오프셋을 4바이트 정렬시키기 위해 추가하는 패딩 바이트 1을 계산한다.
		for (countOfPadding=0; countOfPadding<4; countOfPadding++) {
			// 1은 tableswitch의 바이트 길이, defaultAddress, count, -4는 마지막 오프셋을 제외한다.
			if ( (curOffset+1+countOfPadding+4*(1+1+2*count)-4 ) % 4 == 0) {
				break;
			}
		}
		
		String strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, controlBlock.nameIndex());
		
		//countOfPadding = 0;
		
		if (defaultBlock==null) {
			// default가 없으면 switch를 나가는 것을 default로 한다.
			index = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)2, null);
			result.add("lookupswitch "+"// "+index+"exit of "+controlBlock+strmBufferIndex+ "\n", countOfPadding);
		}
		else {
			index = "("+defaultBlock.nameIndex()+"), ";
			result.add("lookupswitch "+"// "+index+defaultBlock+strmBufferIndex+"\n", countOfPadding);
		}
		
		result.add("count "+count+"\n");
		
		int i;
		
		// default를 제외한 offset 들을 case의 값으로 정렬한다.
		// low부터 high까지의 배열을 만들어서 case의 값으로 그 배열에 저장하여 배열순으로 반복하면
		// low와 high순으로 정렬을 한 효과를 갖게 된다. 
		//FindControlBlockParams[] arr = new FindControlBlockParams[high-low+1];
		
		ArrayListIReset arrSortItem = new ArrayListIReset(controlBlock.listOfControlBlocks.count); 
		
		for (i=0; i<controlBlock.listOfControlBlocks.count; i++) {			
			FindControlBlockParams caseBlock = 
					(FindControlBlockParams) controlBlock.listOfControlBlocks.getItem(i);
			if (!compiler.data.mBuffer.getItem(caseBlock.nameIndex()).equals("default")) {
				CodeString strValue = Fullname.getFullName(compiler.data.mBuffer, 
						caseBlock.indexOfLeftParenthesis(), caseBlock.indexOfRightParenthesis()-1);
				int value;
				if (strValue.str.charAt(0)=='\'' || strValue.str.charAt(0)=='"') {
					// case 'ㄱ':
					// case '\t':
					String str = ByteCode_Helper.removeSymbolsOfString(strValue.str);
					str = ByteCode_Helper.processReverseSlashOfString(str);
					value = (int)str.charAt(0);
				}
				else {
					value = Number.parseInt(strValue.str);
				}
				SortItemIReset sortItem = new SortItemIReset(value, caseBlock);
				arrSortItem.add(sortItem);
				//arr[value-low] = caseBlock;
			}
		}
		
		Sort.sort(arrSortItem);
		
		
		// default를 제외한 key와 offset을 출력한다.
		//for (i=0; i<arr.length; i++) {
			//FindControlBlockParams caseBlock = arr[i];
			// if (caseBlock==null) continue;
		for (i=0; i<arrSortItem.count; i++) {
			FindControlBlockParams caseBlock = (FindControlBlockParams) ((SortItemIReset) arrSortItem.getItem(i)).obj;
			//if (caseBlock==null) continue;
			
			CodeString strValue = Fullname.getFullName(compiler.data.mBuffer, 
					caseBlock.indexOfLeftParenthesis(), caseBlock.indexOfRightParenthesis()-1);
			int key;
			if (strValue.str.charAt(0)=='\'' || strValue.str.charAt(0)=='"') {
				// case 'ㄱ':
				//key = (int)strValue.str.charAt(1);
				// case 'ㄱ':
				// case '\t':
				String str = ByteCode_Helper.removeSymbolsOfString(strValue.str);
				str = ByteCode_Helper.processReverseSlashOfString(str);
				key = (int)str.charAt(0);
			}
			else {
				key = Number.parseInt(strValue.str);
			}
			
			strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, caseBlock.nameIndex());
			
			//int key = Integer.parseInt(strValue.str);
			index = "("+caseBlock.nameIndex()+"), ";
			if (i!=arrSortItem.count-1) {
				// offset_Lookup_과 key를 연결한다.
				result.add("offset_Lookup_"+key+" // "+index+caseBlock+strmBufferIndex+"\n");
			}
			else {
				// offsetEnd_Lookup_과 key를 연결한다.
				result.add("offsetEnd_Lookup_"+key+" // "+index+caseBlock+strmBufferIndex+"\n");
			}
		} // for (i=0; i<arr.length; i++) {
		
		result.add("// offset addresses end "+"\n");
		
		
		
		// case, default안의 코드를 출력한다.
		for (i=0; i<controlBlock.listOfControlBlocks.count; i++) {
			FindControlBlockParams caseBlock = 
					(FindControlBlockParams) controlBlock.listOfControlBlocks.getItem(i);
			index = "("+caseBlock.nameIndex()+"), ";
			result.add("// "+index+caseBlock+"\n");
			printControlBlockBody(generator, caseBlock, result, coreThreadID);
			
			LocalVar.printsLocalVarEnd(generator, caseBlock, result);
		}
	}
	
	public static void printDoWhile(ByteCodeGeneratorForClass generator, FindControlBlockParams controlBlock, HighArrayCharForByteCode result, int coreThreadID) {
		
		Compiler compiler = generator.compiler;
		
		String strIndex = "";
		// run
		strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)0, null);
		result.add("// "+strIndex+"run of "+controlBlock+"\n");
		
		printControlBlockBody(generator, controlBlock, result, coreThreadID);
		
		
		// 바깥 문장 리스트에 throw문을 포함하면 goto, inc를 출력하지 않는다.
				// 불필요한 문장이어서 increment문장을 출력해서는 안 된다.
		//if (!Specials.containsThrowOrReturnOrBreakOrContinue(generator, controlBlock, controlBlock)) {
			// do{
		    //     break;
		    // }while(true);
		
			// // (317), run of do_while (true)
			// 105 goto_w 10     // (345), go to exit of do_while (true), [23]
			// // (343), condition of do_while (true)
			           // true 
			// 110 bipush       1 // [24]
			// 112 ifgt -7     // (317), run, [24]
			// // (344), exit_of_condition of do_while (true)
			// // (345), exit of do_while (true)
		
			// 105 라인은 break문이다. 
      		// containsThrowOrReturnOrBreakOrContinue()을 호출하면 조건문을 출력할 수 없다.

			// condition
			strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)4, null);
			result.add("// "+strIndex+"condition of "+controlBlock+"\n");
			
			 
			ByteCode_Condition.printCondition(generator, controlBlock, result, null, coreThreadID);
			
			strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)1, null);
			result.add("// "+strIndex+"exit_of_condition of "+controlBlock+"\n");
		//}
		
				
		LocalVar.printsLocalVarEnd(generator, controlBlock, result);
		
		strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)2, null);
		result.add("// "+strIndex+"exit of "+controlBlock+"\n");
		
		
	}
	
	
	/** @param coreThreadID 
	 * @param doNotPrintThrowOrReturn : <br>
	 * finally { <br>
	 * 		for () {<br>
	 * 			return;<br>
	 *  	}<br>
	 * }<br>
	 * 이런 경우 printFinally()에서 throw를 하기전에 return을 출력을 해서는 안된다.
	 */
	public static void printFor(ByteCodeGeneratorForClass generator, FindControlBlockParams controlBlock, HighArrayCharForByteCode result, int coreThreadID) {		
				
		Compiler compiler = generator.compiler;
		if (controlBlock.funcCall==null) return;
		
		int indexOfSemicolon1 = controlBlock.funcCall.startIndex();
		indexOfSemicolon1 = 
				CompilerHelper.SkipBlank(compiler.data.mBuffer, true, 0, indexOfSemicolon1-1);
		
		int indexOfSemicolon2 = controlBlock.funcCall.endIndex();
		indexOfSemicolon2 = 
				CompilerHelper.SkipBlank(compiler.data.mBuffer, false, indexOfSemicolon2+1, compiler.data.mBuffer.count-1);
		
		String strIndex = "";
		if (indexOfSemicolon1==1655) {
		}
		int i;
		// 초기화 문장을 실행한다.
		for (i=0; i<controlBlock.listOfStatementsInParenthesis.count; i++) {
			FindStatementParams statement = (FindStatementParams) controlBlock.listOfStatementsInParenthesis.getItem(i);
			if (statement.endIndex()<=indexOfSemicolon1) {
				if (statement instanceof FindAssignStatementParams) {
					FindAssignStatementParams assign = (FindAssignStatementParams) statement;
					assign.rValue.typeFullName = Expression.getTypeOfExpression(compiler, assign.rValue, coreThreadID);
				}
				generator.printFindStatementParams(statement, result, coreThreadID);
			}
		}
		
		// condition
		strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)4, null);
		result.add("// "+strIndex+"condition of "+controlBlock+"\n");
		
		ByteCode_Condition.printCondition(generator, controlBlock, result, null, coreThreadID);
		
		strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)1, null);
		result.add("// "+strIndex+"exit_of_condition of "+controlBlock+"\n");
		
				
		String sourceIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, controlBlock.indexOfRightParenthesis());
		
				
		strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)2, null);
		result.add("goto_w "+"// "+strIndex+"exit of "+controlBlock+sourceIndex+"\n");
	
		
		// run
		strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)0, null);
		result.add("// "+strIndex+"run of "+controlBlock+"\n");
		
		printControlBlockBody(generator, controlBlock, result, coreThreadID);
		
		
		
		// 바깥 문장 리스트에 throw문을 포함하면 goto, inc를 출력하지 않는다.
		// 불필요한 문장이어서 increment문장을 출력해서는 안 된다.
		//if (!Specials.containsThrowOrReturnOrBreakOrContinue(generator, controlBlock, controlBlock)) {
			/*if (controlBlock.specialStatement!=null) {
				result.add("nop\n");
			}*/
			strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)5, null);
			result.add("// "+strIndex+"increments of "+controlBlock+"\n");
			
			// for루프 괄호안 뒷 증감문
			for (i=0; i<controlBlock.listOfStatementsInParenthesis.count; i++) {
				FindStatementParams statement = 
						(FindStatementParams) controlBlock.listOfStatementsInParenthesis.getItem(i);
				if (statement.startIndex()>=indexOfSemicolon2) {
					generator.printFindStatementParams(statement, result, coreThreadID);
				}
			}
			
			sourceIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, controlBlock.endIndex());
			
			strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)4, null);
			result.add("goto_w "+"// "+strIndex+"go to condition of "+controlBlock+sourceIndex+"\n");
		//}
		
		LocalVar.printsLocalVarEnd(generator, controlBlock, result);
		
		strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)2, null);
		
		result.add("// "+strIndex+"exit of "+controlBlock+"\n");
	}
	
	/**else if나 else에서 연결된 if블록을 찾는다.*/
	public static FindControlBlockParams getIFBlock(Compiler compiler, FindControlBlockParams ifOrElseIfOrElseBlock) {
		Block parentBlock = ifOrElseIfOrElseBlock.parent;
		int i;
		for (i=ifOrElseIfOrElseBlock.indexInListOfControlBlocksOfParent; i>=0; i--) {
			FindControlBlockParams controlBlock = (FindControlBlockParams) parentBlock.listOfControlBlocks.getItem(i);
			String name = controlBlock.getName();
			if (name.equals("if")) return controlBlock;
			else if (name.equals("else if")) continue;
			else if (name.equals("else")) continue;
		}
		return null;
	}
	
	
	/** 전체 If_ElseIf_Else를 한번에 출력한다.
	 * @param coreThreadID 
	 * @param doNotPrintThrowOrReturn : <br>
	 * finally { <br>
	 * 		if () {<br>
	 * 			return;<br>
	 *  	}<br>
	 * }<br>
	 * 이런 경우 printFinally()에서 throw를 하기전에 return을 출력을 해서는 안된다.
	 */
	public static void printIf_ElseIf_Else(ByteCodeGeneratorForClass generator, FindControlBlockParams ifBlock, HighArrayCharForByteCode result, int coreThreadID) {
		Compiler compiler = generator.compiler;
		
		Block parentBlock = ifBlock.parent;
		int i;
		int indexEnd = parentBlock.listOfControlBlocks.count-1;
		for (i=ifBlock.indexInListOfControlBlocksOfParent+1; i<parentBlock.listOfControlBlocks.count; i++) {
			FindControlBlockParams controlBlock = (FindControlBlockParams) parentBlock.listOfControlBlocks.getItem(i);
			// 다음 controlBlock이 없는 try, catch문이거나 
			if ( controlBlock.catOfControls==null) {
				indexEnd = i-1;
				break;
			}
			// 다음 controlBlock이 else if나 else가 아니면
			if (!(controlBlock.catOfControls.category==CategoryOfControls.Control_elseif || 
				controlBlock.catOfControls.category==CategoryOfControls.Control_else)) {
				indexEnd = i-1;
				break;
			}
		}
		
		String strIndex = "";
		
		//HighArrayCharForByteCode result = null;
		for (i=ifBlock.indexInListOfControlBlocksOfParent; i<=indexEnd; i++) {
			FindControlBlockParams controlBlock = (FindControlBlockParams) parentBlock.listOfControlBlocks.getItem(i);
			
			if (controlBlock.catOfControls.category==CategoryOfControls.Control_if) {
				//result.add("// BlockStart\n");
				
				printIfControlBlock(generator, controlBlock, result, coreThreadID);				
				if (if_elseEnds(controlBlock)) {
					// if문의 끝나는 영역
					strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)2, null);
					result.add("// "+strIndex+"exit"+" of "+controlBlock+"\n");
					strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)3, null);
					result.add("// "+strIndex+"exit of if-elseif-else"+"\n");
				}
				else { // if-elseif-else에서 if나 else if구조가 끝났을 때
					//strIndex = this.ByteCode_Helper.getStringOfmBufferIndex(controlBlock, (byte)3);
					//result.add("goto_w "+"// "+strIndex+"exit of if-elseif-else"+"\n");
					// if문의 끝나는 영역
					strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)2, null);
					result.add("// "+strIndex+"exit"+" of "+controlBlock+"\n");
				}
			}
			else if (controlBlock.catOfControls.category==CategoryOfControls.Control_elseif) {
				//result.add("// BlockStart\n");
				
				printIfControlBlock(generator, controlBlock, result, coreThreadID);
				if (if_elseEnds(controlBlock)) {
					// else if문의 끝나는 영역
					strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)2, null);
					result.add("// "+strIndex+"exit"+" of "+controlBlock+"\n");
					strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)3, null);
					result.add("// "+strIndex+"exit of if-elseif-else"+"\n");
				}
				else {// if-elseif-else에서 if나 else if구조가 끝났을 때
					//strIndex = this.ByteCode_Helper.getStringOfmBufferIndex(controlBlock, (byte)3);
					//result.add("goto_w "+"// "+strIndex+"exit of if-elseif-else"+"\n");
					// else if문의 끝나는 영역
					strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)2, null);
					result.add("// "+strIndex+"exit"+" of "+controlBlock+"\n");
				}
			}
			else if (controlBlock.catOfControls.category==CategoryOfControls.Control_else) {
				//result.add("// BlockStart\n");
				
				printElseControlBlock(generator, controlBlock, result, coreThreadID);
				if (if_elseEnds(controlBlock)) {
					strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)3, null);
					result.add("// "+strIndex+"exit of if-elseif-else"+"\n");					
				}
				else {// if-elseif-else에서 if나 else if구조가 끝났을 때
					//strIndex = this.ByteCode_Helper.getStringOfmBufferIndex(controlBlock, (byte)3);
					//result.add("goto_w "+"// "+strIndex+"exit of if-elseif-else"+"\n");
				}
			}
		}//for (i=ifBlock.indexInListOfControlBlocksOfParent; i<=indexEnd; i++) {
		
	}
	
	
	public static void printElseControlBlock(ByteCodeGeneratorForClass generator, FindControlBlockParams controlBlock, HighArrayCharForByteCode result, int coreThreadID) {
		printControlBlockBody(generator, controlBlock, result, coreThreadID);
		
		LocalVar.printsLocalVarEnd(generator, controlBlock, result);
	}
	
	
	
	
	
	/** 조건문의 끝나는 지점과 if 문장 영역(run영역) 사이에  exit_of_condition 영역을 두어서
		조건문에서 exit_of_condition 를 하게 되면 이 영역으로 오게 되어 goto_w 명령으로 exit 하게 된다.
		바이트코드 if문의 64K 한계를 극복하게 된다.<br>		
		만약에 조건을 만족하지 못하면 exit_of_condition 영역을 거쳐서 if 블록을 빠져나가에 되어
		다음 else if블록을 실행할 수도 있다.
	 * @param coreThreadID */
	public static void printIfControlBlock(ByteCodeGeneratorForClass generator, FindControlBlockParams controlBlock, HighArrayCharForByteCode result, int coreThreadID) {
		
		Compiler compiler = generator.compiler;
				
		
		String strIndex = "";
		String sourceIndex = null;
			
		// condition
		strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)4, null);
		result.add("// "+strIndex+"condition of "+controlBlock+"\n");
				
		ByteCode_Condition.printCondition(generator, controlBlock, result, null, coreThreadID);
		
		strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)1, null);
		result.add("// "+strIndex+"exit_of_condition of "+controlBlock+"\n");
		
		strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)2, null);
		sourceIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, controlBlock.indexOfRightParenthesis());
		result.add("goto_w "+"// "+strIndex+"exit of "+controlBlock+sourceIndex+"\n");
		
		strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)0, null);
		result.add("// "+strIndex+"run of "+controlBlock+"\n");
		
		printControlBlockBody(generator, controlBlock, result, coreThreadID);
		
		
		// 바깥 문장 리스트에 throw문을 포함하면 goto를 출력하지 않는다.
		if (!Specials.containsThrowOrReturnOrBreakOrContinue(generator, controlBlock, controlBlock)) {
			strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)3, null);
			sourceIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, controlBlock.endIndex());
			result.add("goto_w "+"// "+strIndex+"go to exit of if-elseif-else"+sourceIndex+"\n");
		}
		
		LocalVar.printsLocalVarEnd(generator, controlBlock, result);
		
	}
	
	
	
	public static void printControlBlockBody(ByteCodeGeneratorForClass generator, FindControlBlockParams controlBlock, HighArrayCharForByteCode result, int coreThreadID) {
		Compiler compiler = generator.compiler;
		int i=0;
		
		// 제어블록내에 있는 문장들을 수행한다.
		for (i=0; i<controlBlock.listOfStatements.count; i++) {
			FindStatementParams statement = (FindStatementParams) controlBlock.listOfStatements.getItem(i);
			generator.printFindStatementParams(statement, result, coreThreadID);
			// 현재 문장이 throw문이면 뒷 문장들을 출력하지 않는다.
			if (Specials.isThrowOrReturnOrBreakOrContinue(generator, statement)) {
				if (i+1<controlBlock.listOfStatements.count) {
					FindStatementParams nextStatement = (FindStatementParams) controlBlock.listOfStatements.getItem(i+1);
					FindStatementParams lastStatement = (FindStatementParams) controlBlock.listOfStatements.getItem(controlBlock.listOfStatements.count-1);
					CompilerStatic.errors.add(
						new com.gsoft.common.compiler.Compiler_types_Base.Error(
								compiler, nextStatement.startIndex(), lastStatement.endIndex(), 
								"Remove statements after throw, return, break or continue."));
				}
				break;
			}
		}		
	}
	
	public static void printBreak(ByteCodeGeneratorForClass generator, FindSpecialStatementParams statement, HighArrayCharForByteCode result, int coreThreadID) {
		Compiler compiler = generator.compiler;
		
		String strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, statement.kewordIndex());
		
		Specials.checkSynchronizedAndFinally(generator, statement, null, result, coreThreadID);
		
		FindControlBlockParams controlBlock = 
				(FindControlBlockParams) CompilerStatic.getParentIterationBlock(statement.parent);
		if (controlBlock!=null) {
			controlBlock.specialStatement = statement;
			String strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)2, null);
			result.add("goto_w "+"// "+strIndex+"go to exit of "+controlBlock+strmBufferIndex+"\n");
		}
	}
	
	public static void printContinue(ByteCodeGeneratorForClass generator, FindSpecialStatementParams statement, HighArrayCharForByteCode result, int coreThreadID) {
		Compiler compiler = generator.compiler;
		
		String strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, statement.kewordIndex());
		
		Specials.checkSynchronizedAndFinally(generator, statement, null, result, coreThreadID);
		
		FindControlBlockParams controlBlock = 
					(FindControlBlockParams) CompilerStatic.getParentIterationBlock(statement.parent);
		if (controlBlock!=null) {
			String strIndex;
			if (controlBlock.catOfControls.category==CategoryOfControls.Control_for) {
				controlBlock.specialStatement = statement;
				strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)5, null);
				result.add("goto_w "+"// "+strIndex+"go to increments of "+controlBlock+strmBufferIndex+"\n");
			}
			else { // while, do while
				strIndex = ByteCode_Helper.getStringOfmBufferIndex(compiler, controlBlock, (byte)4, null);
				result.add("goto_w "+"// "+strIndex+"go to condition of "+controlBlock+strmBufferIndex+"\n");
			}
		}
	}
}
