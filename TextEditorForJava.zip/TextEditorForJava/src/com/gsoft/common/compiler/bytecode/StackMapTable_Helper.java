package com.gsoft.common.compiler.bytecode;

import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.Compiler_types.FindControlBlockParams;
import com.gsoft.common.compiler.Compiler_types.FindVarParams;
import com.gsoft.common.compiler.Compiler_types_Base.Block;
import com.gsoft.common.compiler.Compiler_types_Base.FindStatementParams;
import com.gsoft.common.compiler.Compiler_types_Special.FindSpecialBlockParams;
import com.gsoft.common.compiler.Compiler_types_Special.FindSpecialStatementParams;
import com.gsoft.common.compiler.bytecode.ByteCode_Types.Exception_Entry;
import com.gsoft.common.compiler.bytecode.HighArrayCharForByteCode.StartEndIndex;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListIReset;

import com.gsoft.common.compiler.bytecode.ByteCodeGeneratorForClass;
import com.gsoft.common.compiler.bytecode.ByteCode_Types;
import com.gsoft.common.compiler.bytecode.StackMapTable_Entry;
import com.gsoft.common.compiler.bytecode.HighArrayCharForByteCode;
import com.gsoft.common.compiler.bytecode.Specials;

public class StackMapTable_Helper {
	
	private static boolean hasContinue(Compiler compiler, FindControlBlockParams controlBlock) {
		int i;
		for (i=0; i<controlBlock.listOfStatements.count; i++) {
			FindStatementParams statement = (FindStatementParams) controlBlock.listOfStatements.getItem(i);
			if (statement instanceof FindControlBlockParams) {
				FindControlBlockParams block = (FindControlBlockParams) statement;
				if (compiler.data.mBuffer.getItem(block.nameIndex()).equals("if")) {
					boolean r = hasContinue(compiler, block);
					if (r) return true;
				}				
			}			
			else if (statement instanceof FindSpecialStatementParams) {
				FindSpecialStatementParams specialStatement = (FindSpecialStatementParams) statement;
				if (compiler.data.mBuffer.getItem(specialStatement.kewordIndex()).equals("continue"))
					return true;
			}
			else if (statement instanceof FindVarParams) {
				return false;
			}
		}
		return false;
	}
	
	/** for () { <br>
	 * 		if () continue; <br>
	 * 		int a;<br>
	 *  }<br>
	 *  여기에서 a는 빼야 한다.<br>
	 * @param compiler
	 * @param controlBlock : var가 선언된 parent블록
	 * @param var : 스택맵 엔트리에 넣어야 하는지를 결정해야할 지역변수
	 * @return
	 */
	public static boolean hasContinueBeforeVarDecl(Compiler compiler, FindControlBlockParams controlBlock, FindVarParams var) {
		int i, j;
		for (i=0; i<controlBlock.listOfStatements.count; i++) {
			FindStatementParams statement = (FindStatementParams) controlBlock.listOfStatements.getItem(i);
			if (statement==var) {
				for (j=0; j<i; j++) {
					FindStatementParams statement2 = 
							(FindStatementParams) controlBlock.listOfStatements.getItem(j);
					if (statement2 instanceof FindControlBlockParams) {
						FindControlBlockParams block = (FindControlBlockParams) statement2;
						if (compiler.data.mBuffer.getItem(block.nameIndex()).equals("if")) {
							boolean r = hasContinue(compiler, block);
							if (r) return true;
						}
					}
					else if (statement2 instanceof FindSpecialStatementParams) {
						FindSpecialStatementParams specialStatement = (FindSpecialStatementParams) statement2;
						if (compiler.data.mBuffer.getItem(specialStatement.kewordIndex()).equals("continue"))
							return true;
					}
				}
			}
		}
		return false;
	}
	
	
	
	public static FindSpecialBlockParams getCatchOrFinallyBlock(ByteCodeGeneratorForClass generator, int nameIndexOfCatchOrFinally) {
		int i;
		com.gsoft.common.compiler.Compiler compiler = generator.compiler;
		ArrayListIReset controlBlocks = compiler.data.mlistOfAllControlBlocks; 
		for (i=0; i<controlBlocks.count; i++) {
			FindControlBlockParams control = (FindControlBlockParams) controlBlocks.getItem(i);
			//CodeString name = compiler.mBuffer.getItem(control.nameIndex());
			String name = null;
			if (control instanceof FindSpecialBlockParams) {
				FindSpecialBlockParams special = (FindSpecialBlockParams)control;
				name = special.getName();
				
				if (name.equals("catch")) {
					
					if (!special.isFake) {
						if (special.nameIndex()==nameIndexOfCatchOrFinally) {
							return special;
						}
					}
					else {
						if (name.equals("catch")) {
							if (ByteCode_Types.startIndexOfFakeCatchInMain==nameIndexOfCatchOrFinally) {
								return special;
							}
						}
					}
				}
				else if (name.equals("finally")) {
					if (!special.isFake) {
						if (special.findBlockParams.startIndex()==nameIndexOfCatchOrFinally) {
							return special;
						}
					}
					else {
						if (name.equals("finally")) {
							if (ByteCode_Types.startIndexOfFakeFinallyHandlerInFuncWithSync==nameIndexOfCatchOrFinally) {
								return special;
							}
						}
					}
				}
			}
			
		}
		return null;
	}
	
	public static Exception_Entry getException_EntryOfTryOrCatch(ByteCodeGeneratorForClass generator, FindControlBlockParams catchOrFinallyBlock, ArrayList listOfExceptionTable) {
		int i;
		for (i=0; i<listOfExceptionTable.count; i++) {
			Exception_Entry exceptionEntry2 = (Exception_Entry) listOfExceptionTable.getItem(i);
			FindSpecialBlockParams catchOrFinallyBlock2 = getCatchOrFinallyBlock(generator, exceptionEntry2.mBufferIndexOfNameOfCatchOrFinally);
			if (catchOrFinallyBlock==catchOrFinallyBlock2) {
				return exceptionEntry2;
			}
		}
		return null;
	}
	
	/**block이 다른 controlBlock을 포함한다면*/
	public static boolean containsOtherControlBlock_backup(Block block) {
		if (block.listOfControlBlocks.count>0) {
			return true;
		}
		return false;
	}
	
	/**block이 다른 controlBlock을 포함(직접적 자식 뿐만아니라 내부 블록도 포함)한다면
	 * 내부 블록들의 리스트를 리턴한다.*/
	public static ArrayList getInnerControlBlocks(Block block) {
		int i;
		ArrayList r = new ArrayList(5);
		for (i=block.listOfControlBlocks.count-1; i>=0; i--) {
			FindControlBlockParams c = (FindControlBlockParams) block.listOfControlBlocks.getItem(i);
			if (c.catOfControls!=null) {
				r.add(c);
				ArrayList result = getInnerControlBlocks(c);
				int j;
				for (j=0; j<result.count; j++) {
					r.add(result.getItem(j));
				}
			}
		}
		/*if (block.listOfControlBlocks.count>0) {
			return (FindControlBlockParams) block.listOfControlBlocks.getItem(block.listOfControlBlocks.count-1);
		}*/
		return r;
	}
	
	/**block이 다른 controlBlock을 포함한다면 다른 controlBlock을 리턴한다. 
	 * try, catch, finally, synchronized는 제외한다.*/
	public static FindControlBlockParams containsOtherControlBlock(Block block) {
		int i;
		if (block==null) return null;
		if (block.listOfControlBlocks==null) return null;
		
		for (i=block.listOfControlBlocks.count-1; i>=0; i--) {
			FindControlBlockParams c = (FindControlBlockParams) block.listOfControlBlocks.getItem(i);
			if (c.catOfControls!=null) return c;
		}
		/*if (block.listOfControlBlocks.count>0) {
			return (FindControlBlockParams) block.listOfControlBlocks.getItem(block.listOfControlBlocks.count-1);
		}*/
		return null;
	}
	
	public static int getLastEntryOfControlBlock(StackMapTable_Entry[] stackMapTable, int startIndex, FindControlBlockParams controlBlock) {
		int i;
		int r=-1;
		for (i=0; i<stackMapTable.length; i++) {
			StackMapTable_Entry entry = stackMapTable[i];
			if (entry.offsetAndForLoopOfChopFrame.parent==controlBlock) {
				r = i;
			}
			//else if (r!=-1) return r;
		}
		return r;
	}
	
	public static int getConditionEntryOfControlBlock(StackMapTable_Entry[] stackMapTable, int startIndex, FindControlBlockParams controlBlock) {
		int i;
		
		for (i=0; i<stackMapTable.length; i++) {
			StackMapTable_Entry entry = stackMapTable[i];
			Block parent = entry.offsetAndForLoopOfChopFrame.parent;			
			if (parent==controlBlock) {
				String message = entry.offsetAndForLoopOfChopFrame.message;
				if (message.contains("condition")) {
					return i;
				}
			}
		}
		return -1;
	}
	
	
	/**try 안에서 마지막 엔트리이면 그 try의 FindSpecialBlockParams를 리턴한다.*/
	/*public static FindSpecialBlockParams isEntryLastInTry(ByteCodeGeneratorForClass generator, StackMapTable_Entry[] stackMapTable, int i, HighArrayCharForByteCode input) {
		
		StackMapTable_Entry curEntry = stackMapTable[i];	
		FindSpecialBlockParams specialOfCurEntry = isStackFrameInTryOrCatchOrFinally(generator, curEntry, input);
		if (specialOfCurEntry==null) return null;
		if (specialOfCurEntry.specialBlockType==FindSpecialBlockParams.SpecialBlockType_try) {
			if (isEqualWithEndPCOfSpecial(specialOfCurEntry, curEntry.end_frame_pc)) return specialOfCurEntry;
		}
		return null;
	}*/
	
	/**catch 안에서 마지막 엔트리이면 true를 리턴한다.*/
	/*public static FindSpecialBlockParams isEntryLastInCatch(ByteCodeGeneratorForClass generator, StackMapTable_Entry[] stackMapTable, int i, HighArrayCharForByteCode input) {	
		
		StackMapTable_Entry curEntry = stackMapTable[i];
		if (curEntry.start_frame_pc==221) {
			int a;
			a=0;
			a++;
		}
		FindSpecialBlockParams specialOfCurEntry = isStackFrameInTryOrCatchOrFinally(generator, curEntry, input);
		if (specialOfCurEntry==null) return null;
		if (specialOfCurEntry.specialBlockType==FindSpecialBlockParams.SpecialBlockType_catch) {
			if (isEqualWithEndPCOfSpecial(specialOfCurEntry, curEntry.end_frame_pc)) return specialOfCurEntry;
		}
		return null;
	}*/
	
	
	
	/**finallyBlock이 try, catch에 넣어진 블록일 경우 해당 try, catch를 리턴하고 그렇지않으면 finallyBlock을 리턴한다.*/
	public static FindSpecialBlockParams isInFinallyInputtedToTryOrCatch_backup(ByteCodeGeneratorForClass generator, 
			StackMapTable_Entry entry, FindSpecialBlockParams finallyBlock,
			HighArrayCharForByteCode input) {
		ArrayList listOfStartPCAndEndPC = input.listOfStartPCAndEndPCOfFinallyStartsAndEnds;
		int i, j;
		for (i=0; i<listOfStartPCAndEndPC.count; i++) {
			StartEndIndex index = (StartEndIndex) listOfStartPCAndEndPC.getItem(i);
			// entry의 end_frame_pc를 가지고 옮겨진 finally블록을 찾는다.
			if (index.startPCOfFinallyStarts<=entry.end_frame_pc && entry.end_frame_pc<=index.endPCOfFinallyEnds) {
				FindSpecialBlockParams tryBlock = finallyBlock.tryBlockConnected;
				int k;
				for (k=0; k<tryBlock.listOfStartPC.count; k++) {
					int startPC = tryBlock.listOfStartPC.getItem(k);
					int endPC = tryBlock.listOfEndPC.getItem(k);
					if (startPC<=index.startPCOfFinallyStarts && index.endPCOfFinallyEnds<=endPC) {
						return tryBlock;
					}
				}
				FindControlBlockParams[] listOfCatch = 
					Specials.getCatchBlocksOfTry(generator, tryBlock.parent, tryBlock.indexInListOfControlBlocksOfParent);
				for (j=0; j<listOfCatch.length; j++) {
					FindSpecialBlockParams catchBlock = (FindSpecialBlockParams) listOfCatch[j];
					for (k=0; k<catchBlock.listOfStartPC.count; k++) {
						int startPC = catchBlock.listOfStartPC.getItem(k);
						int endPC = catchBlock.listOfEndPC.getItem(k);
						if (startPC<=index.startPCOfFinallyStarts && index.endPCOfFinallyEnds<=endPC) {
							return catchBlock;
						}
					}
				}
			}
		}
		return finallyBlock;
	}
	
	
	
	/** try, catch, finally가 finally 안에 선언되어 있는 경우 finally가 연결된 try, catch에 복제되기 때문에
	 * try, catch, finally의 startPC와 endPC는 리스트가 되어야 한다. 
	 * 이 리스트에서 endPCOfEntry을 가지고 동일한 endPC를 찾는다. 
	 * @param special
	 * @param endPCOfEntry
	 * @return
	 */
	static boolean isEqualWithEndPCOfSpecial(FindSpecialBlockParams special, int endPCOfEntry) {
		int i;
		for (i=0; i<special.listOfEndPC.count; i++) {
			int endPC = special.listOfEndPC.getItem(i);
			if (endPC==endPCOfEntry) return true;
		}
		return false;
	}
	
	
	
	/** try, catch, finally 블록 안에 있는 엔트리이면 FindSpecialBlockParams을 리턴한다.*/
	/*public static FindSpecialBlockParams isStackFrameInTryOrCatchOrFinally(ByteCodeGeneratorForClass generator, 
			StackMapTable_Entry entry, HighArrayCharForByteCode input) {		
		Block parent = entry.offsetAndForLoopOfChopFrame.parent;
		while (true) {			
			if (parent instanceof FindSpecialBlockParams) {
				FindSpecialBlockParams special = (FindSpecialBlockParams) parent;
				String name = special.getName();
				if (name.equals("try")) return special;
				else if (name.equals("catch")) return special;
				else if (name.equals("finally")) {
					//special = isInFinallyInputtedToTryOrCatch(generator, entry, special, input);
					if (ThrowStack.isInFinallyCalledByThrow(generator, entry, input)!=null) {
						return special;
					}
				}
			}
			try {
			parent = parent.parent;
			}catch(Exception e) {
				if (Common_Settings.g_printsLog) e.printStackTrace();
			}
			if (parent==null) return null;
			if (parent instanceof FindFunctionParams) return null;
			if (parent instanceof FindClassParams) return null;			
		}
	}*/
	
	
	
}
