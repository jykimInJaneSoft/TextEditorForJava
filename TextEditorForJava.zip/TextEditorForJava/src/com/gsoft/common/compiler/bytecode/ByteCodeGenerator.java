package com.gsoft.common.compiler.bytecode;

import com.gsoft.common.CommonGUI;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.Compiler_types.CategoryOfControls;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.Compiler_types.FindControlBlockParams;
import com.gsoft.common.compiler.Compiler_types.FindFunctionParams;
import com.gsoft.common.compiler.Compiler_types.FindVarUseParams;
import com.gsoft.common.compiler.Compiler_types_Base.FindStatementParams;
import com.gsoft.common.compiler.Compiler_types_Special.FindSpecialBlockParams;
import com.gsoft.common.compiler.Compiler_types_Special.FindSpecialStatementParams;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListIReset;
import com.gsoft.common.util.HighArray_char;

import com.gsoft.common.compiler.bytecode.ByteCodeGeneratorForClass;
import com.gsoft.common.compiler.bytecode.HighArrayCharForByteCode;

public class ByteCodeGenerator {
	ArrayListIReset mlistOfClass;
	Compiler compiler;
	
	ArrayList listOfGeneratorsForClass = new ArrayList(10);
	private int coreThreadID;
	
	
	/** @param mlistOfClass : 가장 바깥(inner 가 아닌) 클래스의 리스트*/
	public ByteCodeGenerator(Compiler compiler, ArrayListIReset mlistOfClass, int coreThreadID) {
		this.compiler = compiler;
		this.mlistOfClass = mlistOfClass;
		this.coreThreadID = coreThreadID;
		
		makeGenerators();
	}
	
	
	
	public void destroy() {
		try {
		if (this.listOfGeneratorsForClass!=null) {
			/*for (i=0; i<this.listOfGeneratorsForClass.count; i++) {
				ByteCodeGeneratorForClass g = (ByteCodeGeneratorForClass) listOfGeneratorsForClass.getItem(i);				
				g.destroy();			
			}*/
			int i;
			for (i=0; i<listOfGeneratorsForClass.count; i++) {
				((ByteCodeGeneratorForClass)listOfGeneratorsForClass.getItem(i)).destroy();
				listOfGeneratorsForClass.list[i] = null;
			}
			listOfGeneratorsForClass = null;
		}
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
		}
	}
	
	
	public void makeGenerators() {
		int i;
		for (i=0; i<mlistOfClass.count; i++) {
			FindClassParams classParams = (FindClassParams) mlistOfClass.getItem(i);
			makeGenerators(classParams);
		}
	}
	
	/** 클래스 단위로 부모/자식클래스들을 순회하며 재귀적 호출한다.*/
	void makeGenerators(FindClassParams classParams) {
		if (classParams==null) return;
		
		int i;
		if (classParams.childClasses!=null) {	// 자식 클래스부터 바이트코드를 생성한다.	
			for (i=0; i<classParams.childClasses.count; i++) {
				FindClassParams child = (FindClassParams) classParams.childClasses.getItem(i);
				makeGenerators(child);
			}
		}
		
		// 가장 아래 자식클래스이거나 자식클래스들의 코드를 모두 생성한 부모클래스가 된다.
		// 바이트코드를 생성한다.	
		
		ByteCodeGeneratorForClass generator = new ByteCodeGeneratorForClass(compiler, classParams, coreThreadID);
		listOfGeneratorsForClass.add(generator);
		
		generator.makeConstantTable();
	}
	
	/** main 함수 역할한다.*/
	public void generate(Compiler compiler) {
		this.compiler = compiler;
		int i;
		for (i=0; i<mlistOfClass.count; i++) {
			FindClassParams classParams = (FindClassParams) mlistOfClass.getItem(i);
			printClassRecursively(compiler, classParams);
		}
	}
	
	
	/** 클래스 단위로 부모/자식클래스들을 순회하며 재귀적 호출하며 classParams 안에 있는 모든 클래스들에 대해 클래스 파일을 만든다.
	 * @param compiler */
	public void printClassRecursively(Compiler compiler, FindClassParams classParams) {
		if (classParams==null) return;
		
		int i;
		if (classParams.childClasses!=null) {	// 자식 클래스부터 바이트코드를 생성한다.	
			for (i=0; i<classParams.childClasses.count; i++) {
				FindClassParams child = (FindClassParams) classParams.childClasses.getItem(i);
				printClassRecursively(compiler, child);
			}
		}
		
		// 가장 아래 자식클래스이거나 자식클래스들의 코드를 모두 생성한 부모클래스가 된다.
		// 바이트코드를 생성한다.	
		
		ByteCodeGeneratorForClass generator = this.findByteCodeGeneratorForClass(classParams);
		generator.printClass(compiler, classParams, false, coreThreadID);
	}
	
	
	ByteCodeGeneratorForClass findByteCodeGeneratorForClass(FindClassParams c) {
		int i;
		for (i=0; i<this.listOfGeneratorsForClass.count; i++) {
			ByteCodeGeneratorForClass g = (ByteCodeGeneratorForClass) listOfGeneratorsForClass.getItem(i);
			if (g.classParams==c) return g;
		}
		return null;
	}
	
	ByteCodeGeneratorForClass findByteCodeGeneratorForClass(FindVarUseParams varUse) {
		FindClassParams c = varUse.classToDefineThisVarUse;
		int i;
		for (i=0; i<this.listOfGeneratorsForClass.count; i++) {
			ByteCodeGeneratorForClass g = (ByteCodeGeneratorForClass) listOfGeneratorsForClass.getItem(i);
			if (g.classParams==c) return g;
		}
		return null;
	}
	
	ByteCodeGeneratorForClass findByteCodeGeneratorForClass(FindControlBlockParams controlBlock) {
		FindFunctionParams func = (FindFunctionParams) Compiler.getParent(controlBlock);
		if (func==null) return null;
		FindClassParams c = (FindClassParams) func.parent;
		int i;
		for (i=0; i<this.listOfGeneratorsForClass.count; i++) {
			ByteCodeGeneratorForClass g = (ByteCodeGeneratorForClass) listOfGeneratorsForClass.getItem(i);
			if (g.classParams==c) return g;
		}
		return null;
	}
	
	ByteCodeGeneratorForClass findByteCodeGeneratorForClass(FindSpecialStatementParams specialStatement) {
		FindFunctionParams func = (FindFunctionParams) Compiler.getParent(specialStatement.parent);
		if (func==null) return null;
		FindClassParams c = (FindClassParams) func.parent;
		int i;
		for (i=0; i<this.listOfGeneratorsForClass.count; i++) {
			ByteCodeGeneratorForClass g = (ByteCodeGeneratorForClass) listOfGeneratorsForClass.getItem(i);
			if (g.classParams==c) return g;
		}
		return null;
	}
	
	ByteCodeGeneratorForClass findByteCodeGeneratorForClass(FindFunctionParams func) {
		FindClassParams c = (FindClassParams) func.parent;
		int i;
		for (i=0; i<this.listOfGeneratorsForClass.count; i++) {
			ByteCodeGeneratorForClass g = (ByteCodeGeneratorForClass) listOfGeneratorsForClass.getItem(i);
			if (g.classParams==c) return g;
		}
		return null;
	}
	
	
	
	
	
	public String print_findNode(Object node, HighArrayCharForByteCode mByteCodeResult) {
		if (!Common_Settings.showsByteCodes()) {
			return null;
		}
		if (node instanceof FindClassParams) {
			FindClassParams classP = (FindClassParams)node;
			ByteCodeGeneratorForClass generator = findByteCodeGeneratorForClass(classP);			
			generator.resetHashTablesAndConstantTable(node);
			
			CommonGUI.loggingForMessageBox.setText(true, 
					"Compiling "+classP.name + "... You can find its class file in output folder.", false);
			CommonGUI.loggingForMessageBox.setHides(false);
		
			
			HighArray_char output = generator.printClass(classP.compiler, classP, true, coreThreadID);
			
			return output.getItems();
			
		}
		else if (node instanceof FindVarUseParams) {
			// varUse를 포함하는 최소의 문장을 찾는다.
			FindVarUseParams varUse = (FindVarUseParams) node;
			ByteCodeGeneratorForClass generator = findByteCodeGeneratorForClass(varUse);
			generator.resetHashTablesAndConstantTable(node);
			FindStatementParams statement = compiler.findFindStatementParams(varUse);
						
			if (statement instanceof FindControlBlockParams) {
				FindControlBlockParams controlBlock = (FindControlBlockParams) statement;
				if (controlBlock.catOfControls!=null) {
					if (controlBlock.catOfControls.category==CategoryOfControls.Control_if) {
						generator.printFindStatementParams(statement, mByteCodeResult, coreThreadID);
					}
					else { // if문을 제외한 다른 제어구조
						generator.printFindStatementParams_findNode(statement, mByteCodeResult, coreThreadID);
					}
				}
				else {
					// try, catch 등			
				}
			}
			else {
				generator.printFindStatementParams_findNode(statement, mByteCodeResult, coreThreadID);
			}
			
			mByteCodeResult.add('\n');
			
			//if (varUse.funcToDefineThisVarUse==null) return null;
			if (varUse.funcToDefineThisVarUse==null) {
				// 클래스의 초기화문에 있는 varUse를 클릭할 경우
				ArrayList listConstructors = varUse.classToDefineThisVarUse.getConstructors();
				varUse.funcToDefineThisVarUse = (FindFunctionParams) listConstructors.getItem(0); 
			}
			String byteCodeStr = generator.physical.makeByteCodeIndicesAndUpdateConstantTable(mByteCodeResult, varUse.funcToDefineThisVarUse);
			return byteCodeStr;
		}
		else if (node instanceof FindControlBlockParams) {
			FindControlBlockParams controlBlock = (FindControlBlockParams) node;
			ByteCodeGeneratorForClass generator = findByteCodeGeneratorForClass(controlBlock);
			if (generator==null) return null;
			generator.resetHashTablesAndConstantTable(node);
			
			
			String str = null;
			if (controlBlock.catOfControls==null) {
				FindSpecialBlockParams special = (FindSpecialBlockParams) controlBlock;
				str = special.getName();
				if (str.equals("try")) {
					generator.printFindStatementParams(controlBlock, mByteCodeResult, coreThreadID);
				}
				else if (str.equals("catch") || str.equals("finally")) { // if문을 제외한 다른 제어구조
					
					generator.printFindStatementParams_findNode(controlBlock, mByteCodeResult, coreThreadID);
					
				}
				else if (str.equals("synchronized")) {
					
					generator.printFindStatementParams(controlBlock, mByteCodeResult, coreThreadID);
				}
				if (mByteCodeResult!=null) {
					mByteCodeResult.add('\n');
					
					String byteCodeStr = generator.physical.makeByteCodeIndicesAndUpdateConstantTable(mByteCodeResult, 
							(FindFunctionParams)Compiler.getParent(controlBlock));
					return byteCodeStr;
				}
			}
			return null;	
		}
		else if (node instanceof FindFunctionParams) {
			FindFunctionParams func = (FindFunctionParams)node;
			ByteCodeGeneratorForClass generator = findByteCodeGeneratorForClass(func);
			generator.resetHashTablesAndConstantTable(node);
			generator.printFindStatementParams(func, mByteCodeResult, coreThreadID);
			mByteCodeResult.add('\n');
			
			String byteCodeStr = generator.physical.makeByteCodeIndicesAndUpdateConstantTable(mByteCodeResult, func);
			return byteCodeStr;
		}
		else if (node instanceof FindSpecialStatementParams) {
			FindSpecialStatementParams specialStatement = (FindSpecialStatementParams)node;
			ByteCodeGeneratorForClass generator = findByteCodeGeneratorForClass(specialStatement);
			generator.resetHashTablesAndConstantTable(node);
			generator.printFindStatementParams(specialStatement, mByteCodeResult, coreThreadID);
			mByteCodeResult.add('\n');
			
			FindFunctionParams func = (FindFunctionParams)Compiler.getParent(specialStatement.parent);
			String byteCodeStr = generator.physical.makeByteCodeIndicesAndUpdateConstantTable(mByteCodeResult, func);
			return byteCodeStr;
		}
		return null;
	}
}
