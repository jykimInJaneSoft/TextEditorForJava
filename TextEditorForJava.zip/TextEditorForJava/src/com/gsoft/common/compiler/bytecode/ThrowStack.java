package com.gsoft.common.compiler.bytecode;

import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.bytecode.HighArrayCharForByteCode.StartEndIndex;
import com.gsoft.common.util.ArrayList;

import com.gsoft.common.compiler.bytecode.StackMapTable_Entry;
import com.gsoft.common.compiler.bytecode.ByteCodeGeneratorForClass;
import com.gsoft.common.compiler.bytecode.HighArrayCharForByteCode;

public class ThrowStack {
	public static class ThrowStartEnd {
		int startPC;
		int endPC;
		int kewordIndex;
		ThrowStartEnd parentThrow;
		String fullTypeNameOfExceptionToThrow;
		/**ThrowStartEnd[]*/
		ArrayList listOfChild = new ArrayList(1);
		ThrowStartEnd(int kewordIndex) {
			this.kewordIndex = kewordIndex;
		}
		public void setExceptionTypeName(String typeNameOfException) {
			
			this.fullTypeNameOfExceptionToThrow = typeNameOfException;
		}
	}
	
	public static ThrowStartEnd findThrowStartEnd(Compiler compiler, int kewordIndex) {
		int i;
		ArrayList listOfThrowStartEnd = compiler.data.listOfThrowStartEnd;
		for (i=0; i<listOfThrowStartEnd.count; i++) {
			ThrowStartEnd throwStartEnd = (ThrowStartEnd) listOfThrowStartEnd.getItem(i);
			ThrowStartEnd r = findThrowStartEnd_sub(throwStartEnd, kewordIndex);
			if (r!=null) return r;
		}
		return null;
	}
	
	static ThrowStartEnd findThrowStartEnd_sub(ThrowStartEnd parent, int kewordIndex) {
		int i;
		ArrayList listOfThrowStartEnd = parent.listOfChild;
		for (i=0; i<listOfThrowStartEnd.count; i++) {
			ThrowStartEnd throwStartEnd = (ThrowStartEnd) listOfThrowStartEnd.getItem(i);
			ThrowStartEnd r =  findThrowStartEnd_sub(throwStartEnd, kewordIndex);
			if (r!=null) return r;
		}
		if (parent.kewordIndex==kewordIndex) {
			return parent;
		}
		return null;
	}
	
	public static ThrowStartEnd findThrowStartEnd(Compiler compiler, StackMapTable_Entry entry) {
		int i;
		ArrayList listOfThrowStartEnd = compiler.data.listOfThrowStartEnd;
		for (i=0; i<listOfThrowStartEnd.count; i++) {
			ThrowStartEnd throwStartEnd = (ThrowStartEnd) listOfThrowStartEnd.getItem(i);
			ThrowStartEnd r = findThrowStartEnd_sub(throwStartEnd, entry);
			if (r!=null) return r;
		}
		return null;
	}
	
	static ThrowStartEnd findThrowStartEnd_sub(ThrowStartEnd parent, StackMapTable_Entry entry) {
		int i;
		ArrayList listOfThrowStartEnd = parent.listOfChild;
		for (i=0; i<listOfThrowStartEnd.count; i++) {
			ThrowStartEnd throwStartEnd = (ThrowStartEnd) listOfThrowStartEnd.getItem(i);
			ThrowStartEnd r =  findThrowStartEnd_sub(throwStartEnd, entry);
			if (r!=null) return r;
		}
		if (parent.startPC<=entry.end_frame_pc && entry.end_frame_pc<=parent.endPC) {
			return parent;
		}
		return null;
	}
	
	
	
	public static int getCountOfNestedThrow(ThrowStartEnd throwStartEnd) {
		int count = 0;
		ThrowStartEnd parent = throwStartEnd;
		while (true) {
			if (parent==null) break;
			count++;
			parent = throwStartEnd.parentThrow;			
		}
		return count;
	}
	
	/**@return : String[], full typeName of Exception*/
	public static ArrayList getExceptionTypeNameOfNestedThrow(ThrowStartEnd throwStartEnd) {
		ArrayList r = new ArrayList(1);
		ThrowStartEnd parent = throwStartEnd;
		while (true) {
			if (parent==null) break;
			r.add(throwStartEnd.fullTypeNameOfExceptionToThrow);
			parent = throwStartEnd.parentThrow;			
		}
		int i;
		ArrayList newR = new ArrayList(r.count);
		for (i=r.count-1; i>=0; i--) {
			newR.add(r.getItem(i));
		}
		return newR;
	}
	
	
	
	/**asks if entry is in finally called by throw.<br> 
	 * // finally starts<br> 
	 * // finally ends<br>*/
	public static StartEndIndex isInFinallyCalledByThrow(ByteCodeGeneratorForClass generator, 
			StackMapTable_Entry entry, HighArrayCharForByteCode input) {
		ArrayList listOfStartPCAndEndPC = input.listOfStartPCAndEndPCOfFinallyStartsAndEnds;
		int i;
		for (i=0; i<listOfStartPCAndEndPC.count; i++) {
			StartEndIndex index = (StartEndIndex) listOfStartPCAndEndPC.getItem(i);
			// entry의 end_frame_pc를 가지고 옮겨진 finally블록을 찾는다.
			if (index.startPCOfFinallyStarts<=entry.end_frame_pc && entry.end_frame_pc<=index.endPCOfFinallyEnds) {
				return index;
			}
		}
		return null;
	}
	
}
