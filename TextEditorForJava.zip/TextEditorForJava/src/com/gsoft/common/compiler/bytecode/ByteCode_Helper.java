package com.gsoft.common.compiler.bytecode;

import com.gsoft.common.Common_Settings;
import com.gsoft.common.compiler.Checker;
import com.gsoft.common.compiler.CodeStringEx;
import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.CompilerStatic;
import com.gsoft.common.compiler.Compiler_types.CategoryOfControls;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.Compiler_types.FindControlBlockParams;
import com.gsoft.common.compiler.Compiler_types.FindFuncCallParam;
import com.gsoft.common.compiler.Compiler_types.FindFunctionParams;
import com.gsoft.common.compiler.Compiler_types.FindVarParams;
import com.gsoft.common.compiler.Compiler_types.FindVarUseParams;
import com.gsoft.common.compiler.Compiler_types_Base.Block;
import com.gsoft.common.compiler.Compiler_types_Special.FindSpecialBlockParams;
import com.gsoft.common.compiler.Fullname;
import com.gsoft.common.compiler.IndexForHighArray;
import com.gsoft.common.compiler.Number;
import com.gsoft.common.compiler.classloader.Loader;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListChar;
import com.gsoft.common.util.ArrayListInt;
import com.gsoft.common.util.HighArray_char;

import com.gsoft.common.compiler.bytecode.ThreeOperandsOperation;
import com.gsoft.common.compiler.bytecode.ByteCode_Types;

@SuppressWarnings("unused")
public class ByteCode_Helper {
	
	/**constantPool에 있는 CONSTANT_INFO와 그 내용을 보여준다.*/
	public static String getConstantTableTypesAndContents(ArrayList constantPool) {
		int i, j;
		HighArray_char r = new HighArray_char(200);
		
		int countOfColumns = 10;
		int countOfRows = constantPool.count/countOfColumns+1; 
		for (i=0; i<countOfRows; i++) {			
			r.add("/*");
			for (j=0; j<countOfColumns; j++) {
				int index = countOfColumns*i+j;
				if (index==8) {
					int a;
					a=0;
					a++;
				}
				if (index==constantPool.count) {
					break;
				}
				if (constantPool.getItem(index)==null) {
					continue;
				}
				String type = constantPool.getItem(index).getClass().getName();
				String shortType = CompilerHelper.getShortName(type);
				String content = constantPool.getItem(index).toString();
				r.add(" ("+ index + ":" + shortType + "-" + content + ")");
			}
			r.add("*/");
			r.add('\n');
		}
		return r.getItems();
	}
	
	/**, [LineNumber]*/
	public static String getSourceLineNumber(Compiler compiler, int mBufferIndex) {		
		String lineNumberStr = getSourceLineNumberWithoutCommaAndBlank(compiler, mBufferIndex);
		return new String(", "+lineNumberStr);
	}
	
	
	static int getLineNumber(Compiler compiler, int mBufferIndex) {
		ArrayListInt listOfIndicesOfNewLinesInSrc = compiler.data.mlistOfNewLines;
		int lineNumber = -1;
		int j;
		// +1은 라인번호가 1부터 시작하므로 1을 증가시키기 위한 것이다.
		if (mBufferIndex!=-2) {
			if (mBufferIndex!=-1) {
				if (mBufferIndex<listOfIndicesOfNewLinesInSrc.getItem(0)) {
					lineNumber = 0+1;
				}
				for (j=1; j<listOfIndicesOfNewLinesInSrc.count; j++) {
					int indexOfNewLineInSrc = listOfIndicesOfNewLinesInSrc.getItem(j);
					int indexOfNewLineInSrc_prev = -1;
					indexOfNewLineInSrc_prev = listOfIndicesOfNewLinesInSrc.getItem(j-1);
					if (indexOfNewLineInSrc_prev<mBufferIndex && mBufferIndex<indexOfNewLineInSrc) {
						lineNumber = j+1;
						break;
					}
				}
			}
			else {
				// [-1]인 경우
				lineNumber = 0+1;
			}
		}
		return lineNumber;
	}
	
	/**[lineNumber]*/
	public static String getSourceLineNumberWithoutCommaAndBlank(Compiler compiler, int mBufferIndex) {
		int lineNumber = getLineNumber(compiler, mBufferIndex);
		if (lineNumber==-1) {
			// increment statement
			int count = compiler.data.mBuffer.count;
			if ((compiler.data.mBuffer.getItem(count-2).equals("+") || compiler.data.mBuffer.getItem(count-2).equals("-")) && 
					compiler.data.mBuffer.getItem(count-1).equals("1")) {
				int j;
				for (j=0; j<compiler.data.mlistOfAllVarUses.count; j++) {
					FindVarUseParams varUse = (FindVarUseParams) compiler.data.mlistOfAllVarUses.getItem(j);
					if (varUse.index()==mBufferIndex) {
						mBufferIndex = varUse.inc.lValue.index();
						// compiler having original lValue
						lineNumber = getLineNumber( varUse.inc.lValue.classToDefineThisVarUse.compiler, mBufferIndex);
						break;
					}
				}
			}
		}
		return new String("["+lineNumber+"]");
	}
	
	/**var가 for루프의 괄호안에서 정의되면 true를 리턴한다.*/
	public static boolean varIsDefinedInForLoopParentheis(Compiler compiler, FindVarParams var) {
		Block block = var.parent;
		if (block instanceof FindControlBlockParams) {
			FindControlBlockParams controlBlock = (FindControlBlockParams) block;
			if (controlBlock.catOfControls!=null)	{					
				// for루프의 경우에는 괄호안 초기화 문장도 세야 한다. 
				if (controlBlock.catOfControls.category==CategoryOfControls.Control_for) {
					int indexOfSemicolon1 = controlBlock.funcCall.startIndex();
					indexOfSemicolon1 = 
							CompilerHelper.SkipBlank(compiler.data.mBuffer, true, 0, indexOfSemicolon1-1);
					if (controlBlock.indexOfLeftParenthesis()<=var.startIndex() && var.endIndex()<=indexOfSemicolon1)
						return true;
				}
			}
		}
		return false;
	}
	

	/**newarray는 primitive type의 배열을 생성하므로 constant table에 넣지 않는다.<br>
	 * The atype operand of each newarray instruction must take one of the values
	   T_BOOLEAN (4), T_CHAR (5), T_FLOAT (6), T_DOUBLE (7), T_BYTE (8), T_SHORT
	   (9), T_INT (10), or T_LONG (11)*/
	public static int getAType(String typeDesc) {
		if (typeDesc.equals("Z")) return 4; // boolean
		else if (typeDesc.equals("C")) return 5;
		else if (typeDesc.equals("F")) return 6;
		else if (typeDesc.equals("D")) return 7;
		else if (typeDesc.equals("B")) return 8;
		else if (typeDesc.equals("S")) return 9;
		else if (typeDesc.equals("I")) return 10;
		else if (typeDesc.equals("J")) return 11; // long
		return -1;
	}
	
	
	
	
	
	
	public static FindFunctionParams getConcatFunctionInStringClass(FindClassParams classParams) {
		int i;
		for (i=0; i<classParams.listOfFunctionParams.count; i++) {
			FindFunctionParams func = (FindFunctionParams) classParams.listOfFunctionParams.getItem(i);
			if (func.name.equals("concat")) {
				if (func.listOfFuncArgs.count==1) {
					FindVarParams var = (FindVarParams) func.listOfFuncArgs.getItem(0);
					if (var.typeName.equals("java.lang.String")) {
						return func;
					}
				}
			}
		}
		return null;
	}
	
	public static FindFunctionParams getToStringFunction(FindClassParams classParams) {
		int i;
		try {
		//if (classParams==null) return null;
		for (i=0; i<classParams.listOfFunctionParams.count; i++) {
			FindFunctionParams func = (FindFunctionParams) classParams.listOfFunctionParams.getItem(i);
			if (func.name.equals("toString")) {
				if (func.listOfFuncArgs.count==0) return func;
			}
		}
		for (i=0; i<classParams.listOfFunctionParamsInherited.count; i++) {
			FindFunctionParams func = (FindFunctionParams) classParams.listOfFunctionParamsInherited.getItem(i);
			if (func.name.equals("toString")) {
				if (func.listOfFuncArgs.count==0) return func;
			}
		}
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
		}
		return null;
	}
	
	/**@param argTypeName : null이면 arg가 없는 생성자를 리턴하고 null이 아니면 String을 인자로 갖는 생성자를 리턴한다.
	 * @param coreThreadID */
	public static FindFunctionParams getConstructorOfStringBuilder(Compiler compiler, String argTypeName, int srcIndex, int coreThreadID) {
		FindClassParams classParams = Loader.loadClass(compiler, "java.lang.StringBuilder", coreThreadID);
		int i;
		for (i=0; i<classParams.listOfFunctionParams.count; i++) {
			FindFunctionParams func = (FindFunctionParams) classParams.listOfFunctionParams.getItem(i);
			if (func.isConstructor) {
				if (argTypeName==null) {
					if (func.listOfFuncArgs.count==0) {
						func.functionNameIndex = IndexForHighArray.indexRelative(func, compiler.data.mBuffer, srcIndex);
						return func;
					}
				}
				else {
					if (func.listOfFuncArgs.count==1) {
						FindVarParams var = (FindVarParams) func.listOfFuncArgs.getItem(0);
						if (var.typeName.equals("String")) {
							func.functionNameIndex = IndexForHighArray.indexRelative(func, compiler.data.mBuffer, srcIndex);
							return func;
						}
					}
				}
			}
		}
		return null;
	}
	
	/**Returns constructor of classValueObject. For example, Integer(int), Float(float)*/
	public static FindFunctionParams getConstructorOfValueObject(Compiler compiler, FindClassParams classValueObject, int srcIndex, int coreThreadID) {
		int i;
		for (i=0; i<classValueObject.listOfFunctionParams.count; i++) {
			FindFunctionParams func = (FindFunctionParams) classValueObject.listOfFunctionParams.getItem(i);
			if (func.isConstructor) {
				if (func.listOfFuncArgs.count==1) {
					FindVarParams var = (FindVarParams) func.listOfFuncArgs.getItem(0);
					if (classValueObject.name.equals("java.lang.Integer")) {
						if (var.typeName.equals("int")) return func;
					}
					else if (classValueObject.name.equals("java.lang.Byte")) {
						if (var.typeName.equals("byte")) return func;
					}
					else if (classValueObject.name.equals("java.lang.Byte")) {
						if (var.typeName.equals("byte")) return func;
					}
					else if (classValueObject.name.equals("java.lang.Short")) {
						if (var.typeName.equals("short")) return func;
					}
					else if (classValueObject.name.equals("java.lang.Character")) {
						if (var.typeName.equals("char")) return func;
					}
					else if (classValueObject.name.equals("java.lang.Long")) {
						if (var.typeName.equals("long")) return func;
					}
					else if (classValueObject.name.equals("java.lang.Float")) {
						if (var.typeName.equals("float")) return func;
					}
					else if (classValueObject.name.equals("java.lang.Double")) {
						if (var.typeName.equals("double")) return func;
					}
				}
			}
		}
		return null;
	}
	
	public static FindFunctionParams getToStringOfStringBuilder(Compiler compiler, int srcIndex, int coreThreadID) {
		FindClassParams classParams = Loader.loadClass(compiler, "java.lang.StringBuilder", coreThreadID);
		int i;
		for (i=0; i<classParams.listOfFunctionParams.count; i++) {
			FindFunctionParams func = (FindFunctionParams) classParams.listOfFunctionParams.getItem(i);
			if (func.name.equals("toString")) {
				func.functionNameIndex = IndexForHighArray.indexRelative(null, compiler.data.mBuffer, srcIndex);
				return func;
			}
		}
		return null;
	}
	
	
	public static FindFunctionParams getAppendOfStringBuilder(Compiler compiler, String argTypeName, int srcIndex, int coreThreadID) {
		if (argTypeName.equals("null")) {
			// str + null 에서 null일 경우
			// null + str 에서 null일 경우
			argTypeName = "java.lang.String";
		}
		FindClassParams classParams = Loader.loadClass(compiler, "java.lang.StringBuilder", coreThreadID);
		int i;
		if (CompilerHelper.IsDefaultType(argTypeName) || argTypeName.equals("char[]") ||
				argTypeName.equals("CharSequence")) {
			if (argTypeName.equals("byte") || argTypeName.equals("short"))
				argTypeName = "int"; // byte, short는 int로 연결한다.
			for (i=0; i<classParams.listOfFunctionParams.count; i++) {
				FindFunctionParams func = (FindFunctionParams) classParams.listOfFunctionParams.getItem(i);
				if (func.name.equals("append")) {
					if (func.listOfFuncArgs.count==1) {
						if (func.returnType!=null && func.returnType.equals("java.lang.StringBuilder")) {
							FindVarParams var = (FindVarParams) func.listOfFuncArgs.getItem(0);
							// append(boolean), append(char), append(int) 등
							if (var.typeName.equals(argTypeName)) {
								func.functionNameIndex = IndexForHighArray.indexRelative(func, compiler.data.mBuffer, srcIndex);
								return func;
							}
						}
					}
				}
			}
		}
		else {
			// java.lang.String이거나 그것의 서브클래스일 경우
			FindClassParams stringClass = Loader.loadClass(compiler, "java.lang.String", coreThreadID);
			FindClassParams childClass = Loader.loadClass(compiler, argTypeName, coreThreadID);
			boolean r = FindClassParams.isARelation(compiler, stringClass, childClass, coreThreadID);
			if (r) {
				for (i=0; i<classParams.listOfFunctionParams.count; i++) {
					FindFunctionParams func = (FindFunctionParams) classParams.listOfFunctionParams.getItem(i);
					if (func.name.equals("append")) {
						if (func.listOfFuncArgs.count==1) {
							if (func.returnType!=null && func.returnType.equals("java.lang.StringBuilder")) {
								FindVarParams var = (FindVarParams) func.listOfFuncArgs.getItem(0);						
								if (var.typeName.equals("java.lang.String")) {
									func.functionNameIndex = IndexForHighArray.indexRelative(func, compiler.data.mBuffer, srcIndex);
									return func;
								}
							}
						}
					}
				}
			}
			else {
				// append(Object)에 연결한다.
				for (i=0; i<classParams.listOfFunctionParams.count; i++) {
					FindFunctionParams func = (FindFunctionParams) classParams.listOfFunctionParams.getItem(i);
					if (func.name.equals("append")) {
						if (func.listOfFuncArgs.count==1) {
							if (func.returnType!=null && func.returnType.equals("java.lang.StringBuilder")) {
								FindVarParams var = (FindVarParams) func.listOfFuncArgs.getItem(0);						
								if (var.typeName.equals("java.lang.Object")) {
									func.functionNameIndex = IndexForHighArray.indexRelative(func, compiler.data.mBuffer, srcIndex);
									return func;
								}
							}
						}
					}
				}
			}
		}
		
		
		return null;
	}
	
	
	/** @param type : 0-Byte, 1-Char, 2-Short, 3-Integer, 4-Long, 5-Float, 6-Double, 
	 * 7-String, 8-java.lang.Boolean*/
	public static FindFunctionParams getConstructor(FindClassParams classParams, int type) {
		int i;
		if (type==0) { // Byte
			for (i=0; i<classParams.listOfFunctionParams.count; i++) {
				FindFunctionParams func = (FindFunctionParams) classParams.listOfFunctionParams.getItem(i);
				if (func.isConstructor) {
					if (func.listOfFuncArgs.count==1) {
						FindVarParams var = (FindVarParams) func.listOfFuncArgs.getItem(0);
						if (var.typeName.equals("byte")) {
							return func;
						}
					}
				}
			}
		}
		else if (type==1) { //Char
			for (i=0; i<classParams.listOfFunctionParams.count; i++) {
				FindFunctionParams func = (FindFunctionParams) classParams.listOfFunctionParams.getItem(i);
				if (func.isConstructor) {
					if (func.listOfFuncArgs.count==1) {
						FindVarParams var = (FindVarParams) func.listOfFuncArgs.getItem(0);
						if (var.typeName.equals("char")) {
							return func;
						}
					}
				}
			}
		}
		else if (type==2) { //Short
			for (i=0; i<classParams.listOfFunctionParams.count; i++) {
				FindFunctionParams func = (FindFunctionParams) classParams.listOfFunctionParams.getItem(i);
				if (func.isConstructor) {
					if (func.listOfFuncArgs.count==1) {
						FindVarParams var = (FindVarParams) func.listOfFuncArgs.getItem(0);
						if (var.typeName.equals("short")) {
							return func;
						}
					}
				}
			}
		}
		else if (type==3) { //Integer
			for (i=0; i<classParams.listOfFunctionParams.count; i++) {
				FindFunctionParams func = (FindFunctionParams) classParams.listOfFunctionParams.getItem(i);
				if (func.isConstructor) {
					if (func.listOfFuncArgs.count==1) {
						FindVarParams var = (FindVarParams) func.listOfFuncArgs.getItem(0);
						if (var.typeName.equals("int")) {
							return func;
						}
					}
				}
			}
		}
		else if (type==4) { //Long
			for (i=0; i<classParams.listOfFunctionParams.count; i++) {
				FindFunctionParams func = (FindFunctionParams) classParams.listOfFunctionParams.getItem(i);
				if (func.isConstructor) {
					if (func.listOfFuncArgs.count==1) {
						FindVarParams var = (FindVarParams) func.listOfFuncArgs.getItem(0);
						if (var.typeName.equals("long")) {
							return func;
						}
					}
				}
			}
		}
		else if (type==5) { //Float
			for (i=0; i<classParams.listOfFunctionParams.count; i++) {
				FindFunctionParams func = (FindFunctionParams) classParams.listOfFunctionParams.getItem(i);
				if (func.isConstructor) {
					if (func.listOfFuncArgs.count==1) {
						FindVarParams var = (FindVarParams) func.listOfFuncArgs.getItem(0);
						if (var.typeName.equals("float")) {
							return func;
						}
					}
				}
			}
		}
		else if (type==6) { //Double
			for (i=0; i<classParams.listOfFunctionParams.count; i++) {
				FindFunctionParams func = (FindFunctionParams) classParams.listOfFunctionParams.getItem(i);
				if (func.isConstructor) {
					if (func.listOfFuncArgs.count==1) {
						FindVarParams var = (FindVarParams) func.listOfFuncArgs.getItem(0);
						if (var.typeName.equals("double")) {
							return func;
						}
					}
				}
			}
		}
		else if (type==7) { //String
			for (i=0; i<classParams.listOfFunctionParams.count; i++) {
				FindFunctionParams func = (FindFunctionParams) classParams.listOfFunctionParams.getItem(i);
				if (func.isConstructor) {
					if (func.listOfFuncArgs.count==1) {
						FindVarParams var = (FindVarParams) func.listOfFuncArgs.getItem(0);
						if (var.typeName.equals("byte[]")) {
							return func;
						}
					}
				}
			}
		}
		else if (type==8) { //Boolean
			for (i=0; i<classParams.listOfFunctionParams.count; i++) {
				FindFunctionParams func = (FindFunctionParams) classParams.listOfFunctionParams.getItem(i);
				if (func.isConstructor) {
					if (func.listOfFuncArgs.count==1) {
						FindVarParams var = (FindVarParams) func.listOfFuncArgs.getItem(0);
						if (var.typeName.equals("boolean")) {
							return func;
						}
					}
				}
			}
		}
		return null;
	}
	
	
	
	
	/**배열초기화에서 short범위를 넘어서는 인덱스와, array length를 위한 지역변수를 얻어오기 위해서
	 * varUse를 정의하는 클래스나 함수를 얻어온다.
	 * getLocalVarForArrayInit()와 getLocalVarForArrayInit_arrayLength()를 참조한다. 
	 * @param varUse : 배열초기화문의 lValue*/
	public static Object getFunctionOrClassToDefineLocalVarsForArrayInit(FindVarUseParams varUse) {
		if (varUse.classToDefineThisVarUse!=null) {
			return varUse.classToDefineThisVarUse;
		}
		else if (varUse.funcToDefineThisVarUse!=null) {
			FindFunctionParams func = varUse.funcToDefineThisVarUse;
			return func;
		}
		return null;		
	}
	
	
	static class ReturnOfgetIndexWhenContainingEqual {
		int index;
		FindVarUseParams lValue;
		ReturnOfgetIndexWhenContainingEqual(int index, FindVarUseParams lValue) {
			this.index = index;
			this.lValue = lValue;
		}
	}
	
	/** int i = (i=2)+1; f(a=2, 3);
		int i = 1 + (i=2);에서  lValue는 i이다. 
		중첩된 대입연산자의 경우 중첩된 할당문을 출력했으므로 중복 출력을 막기위해서 
		인덱스 j를 증가시켜야 한다.
		@return : 포스트픽스 상에서 중첩된 대입 연산자 위치로 점프하기 위한 index를 리턴한다. 
		문장안에 대입문을 포함하는 경우 index는 0이상이고 
		그렇지 않은 일반적인 경우에는 null, -1을 리턴한다.*/
	public static ReturnOfgetIndexWhenContainingEqual getIndexWhenContainingEqual(Compiler compiler, CodeStringEx token, FindFuncCallParam funcCall) {
		int j = -1;
		// int i = 1 + (i=2);에서  lValue는 i이다. 
		// 중첩된 대입연산자의 경우 인덱스 j를 증가시켜야 한다.
		int indexOfTokenInmBuffer = token.indicesInSrc.getItem(0);
		if (indexOfTokenInmBuffer==4) {
			int a;
			a=0;
			a++;
		}
		int indexOfVarUse = Fullname.getFullNameIndex(compiler, false, indexOfTokenInmBuffer, true);
		if (indexOfVarUse==compiler.data.mBuffer.count) {
			return null;
		}
		String varUseName = null;
		varUseName = compiler.data.mBuffer.getItem(indexOfVarUse).str;
		FindVarUseParams r = 
			Compiler.getVarUseWithIndex(compiler.data.mlistOfAllVarUsesHashed, varUseName, indexOfVarUse);
		
		FindVarUseParams lValue = r;
		if (lValue==null) {
			// token이 lValue가 아닌 일반적인 경우
			return null;
		}
		int indexOfEqual = compiler.IsLValue(compiler.data.mBuffer, lValue);
		// 포스트픽스상에서 =의 인덱스와 같은 토큰을 찾는다.
		if (indexOfEqual>0) {
			int m;
			boolean found = false;
			CodeStringEx[] postfixArr = funcCall.expression.postfix;
			for (m=0; m<postfixArr.length; m++) {
				CodeStringEx tokenInPostfix = postfixArr[m];
				int n;
				// 대입연산자는 =, +=, -=, *=, /=, %= 등이 될 수 있다.
				for (n=0; n<tokenInPostfix.indicesInSrc.count; n++) {
					int indexOfTokenInPostfix = tokenInPostfix.indicesInSrc.getItem(n);
					if (indexOfTokenInPostfix==indexOfEqual) {
						found = true;
						break;
					}
				}
				if (found) break;
			}
			if (m<postfixArr.length) {
				// 중첩된 대입 연산자 위치로 점프한다.
				j = m;
			}
		}//if (indexOfEqual>0) {
		return new ReturnOfgetIndexWhenContainingEqual(j, lValue);
	}
	
	
	/** findNode_varUse_makeString_postfix에서 호출한다.
	 * 수식이 중복되어 처리될수있으므로 인덱스값을 child의 마지막 위치 다음으로 바꿔준다.*/
	public static int getIndex(Compiler compiler, CodeStringEx token, FindVarUseParams child, int k) {
		boolean isFuncCallAndArrayElement = false;
		if (child.funcDecl!=null && child.isArrayElement)
			isFuncCallAndArrayElement = true;
		
		/*if (child.rValue!=null) { // 대입문인 경우, a=1+(a=2);에서 child는 두번째 a이다.
			FindFuncCallParam funcCall = child.rValue;
			int endIndexOfFuncCall = funcCall.endIndex()/*+1*/;
			//k = compiler.getIndexInmListOfAllVarUses2(token.listOfVarUses, k, endIndexOfFuncCall, /*true*/false);
			//k--;
		//}*/
		
		if (child.funcDecl!=null && child.listOfFuncCallParams!=null) {
			if (child.listOfFuncCallParams.count>0) {
				FindFuncCallParam funcCall = (FindFuncCallParam) 
					child.listOfFuncCallParams.getItem(child.listOfFuncCallParams.count-1);
				int endIndexOfFuncCall = funcCall.endIndex()/*+1*/;
				k = CompilerStatic.getIndexInmListOfAllVarUses2(token.listOfVarUses, k, endIndexOfFuncCall, /*true*/false);
				//k--;				
			}
		}
		if (child.isArrayElement && child.listOfArrayElementParams!=null) {
			try {
			FindFuncCallParam funcCall = (FindFuncCallParam) 
					child.listOfArrayElementParams.getItem(child.listOfArrayElementParams.count-1);
			int endIndexOfFuncCall = funcCall.endIndex()/*+1*/;
			
			k = CompilerStatic.getIndexInmListOfAllVarUses2(token.listOfVarUses, k, endIndexOfFuncCall, /*true*/false);
			//k--;
			}catch(Exception e) {
				if (Common_Settings.g_printsLog) e.printStackTrace();
			}
		}
		if (child.typeCast!=null && child.typeCast.funcCall!=null) {
			FindFuncCallParam funcCall = (FindFuncCallParam) child.typeCast.funcCall;
			int endIndexOfFuncCall = funcCall.endIndex()/*+1*/;
			// (Control[])Array.Resize(list, capacity) 에서 endIndexOfFuncCall은 Resize를 가리킨다.
			// 따라서 올바른 endIndexOfFuncCall의 끝을 찾기위해 endIndexOfFuncCall이 함수호출을 가리킬 경우
			// 그 함수호출의 끝을 찾는다.
			FindVarUseParams funcCallVarUse = CompilerStatic.getVarUseWithIndex(compiler.data.mlistOfAllVarUsesHashed, 
					compiler.data.mBuffer.getItem(endIndexOfFuncCall).str, endIndexOfFuncCall);
			if (funcCallVarUse!=null && !funcCallVarUse.isForVarOrForFunc) {
				int indexLeftPair = CompilerHelper.SkipBlank(compiler.data.mBuffer, false, 
						endIndexOfFuncCall+1, compiler.data.mBuffer.count+1);				
				endIndexOfFuncCall = Checker.CheckParenthesis(compiler, "(", ")", 
						indexLeftPair, compiler.data.mBuffer.count-1, false);
			}
			k = CompilerStatic.getIndexInmListOfAllVarUses2(token.listOfVarUses, k, endIndexOfFuncCall, /*true*/false);
			//k--;
		}
		if (isFuncCallAndArrayElement && child.listOfFuncCallParams.count>0) k++;
		return k;
	}
	
	
	/**mode 6, 7, 8은 try-catch-finally에서 마지막 블록이어야 한다.<br> 
	 * @param mode: 0-run(controlBlock.findBlockParams.startIndex()),<br>
	 * 1:exit_of_condition(controlBlock.indexOfRightParenthesis()),<br> 
	 * 2:exit of control(controlBlock.endIndex()),<br>
	 * 3:exit of if-elseif-else(lastBlock.endIndex()),<br>
	 * 4:condition(controlBlock.indexOfLeftParenthesis()+1),<br>
	 * 5:increments in for(controlBlock.funcCall.endIndex()+1 SkipBlank),<br> 
	 * 6:finally starts(controlBlock.startIndex()),<br>
	 * 7:exit of try-catch-finally(controlBlock.endIndex()),<br>
	 * 8:finally ends(controlBlock.endIndex()),<br>
	 * 9:BlockStart(controlBlock.nameIndex())<br>
	 * @param funcCall : 3항연산자에서 조건식 부분을 말한다. 3항 연산일 경우 null이 아니고, controlBlock은 null이 된다.*/
	public static int getIndexInmBuffer(Compiler compiler, FindControlBlockParams controlBlock, byte mode, FindFuncCallParam funcCall) {
		if (mode==0) {
			int indexOfRun = -1;
			if (controlBlock!=null) {
				if (controlBlock.isBlock) {
					indexOfRun = controlBlock.findBlockParams.startIndex();
				}
				else {
					indexOfRun = CompilerHelper.SkipBlank(compiler.data.mBuffer, false, controlBlock.indexOfRightParenthesis()+1, compiler.data.mBuffer.count-1);
				}
			}
			else {
				// int i = 1>0 ? 3 : 2;
				// ? 다음의 인덱스, 3의 인덱스
				int indexOfQuestion = CompilerHelper.indexOfBeforeSemicolon(compiler.data.mBuffer, funcCall.endIndex(), "?");
				return indexOfQuestion+1;	
			}
			return indexOfRun;
		}
		else if (mode==1) {
			int indexOfExitOfGotoW = -1;
			if (controlBlock!=null) {
				indexOfExitOfGotoW = controlBlock.indexOfRightParenthesis();
			}
			else {
				// int i = 1>0 ? 3 : 2;
				// ? 이전의 인덱스
				int indexOfQuestion = CompilerHelper.indexOfBeforeSemicolon(compiler.data.mBuffer, funcCall.endIndex(), "?");
				return indexOfQuestion-1;
			}
			return indexOfExitOfGotoW;
		}
		else if (mode==2) {
			int indexOfExitOfControl = -1;
			if (controlBlock!=null) {
				if (controlBlock.nameIndex()==3284) {
					int a;
					a=0;
					a++;
				}
				indexOfExitOfControl = controlBlock.endIndex();
				// while (true) if (i==3) continue;와 같이 '{', '}'이 없는 while, for, do-while문일 경우 
				/*if (controlBlock.findBlockParams==null && controlBlock.listOfControlBlocks.count>0) {
					indexOfExitOfControl = ByteCode_Types.getEndIndexOfNestingControlBlockWithoutMiddlePair(controlBlock.nameIndex());
				}*/
				if (controlBlock.endIndexWhenNestingControlBlockWithoutMiddlePair!=-1) {
					indexOfExitOfControl = controlBlock.endIndexWhenNestingControlBlockWithoutMiddlePair;
				}
			}
			else {
				// int i = 1>0 ? 3 : 2;
				// : 이전의 인덱스
				int indexOfQuestion = CompilerHelper.indexOfBeforeSemicolon(compiler.data.mBuffer, funcCall.endIndex(), "?");				
				int indexOfColon = Checker.CheckParenthesis(compiler, "?", ":", indexOfQuestion, compiler.data.mBuffer.count-1, false);
				return indexOfColon-1;
			}
			return indexOfExitOfControl;
		}
		else if (mode==3) {
			int indexOfExitOfIf_ElseIf_Else = -1;
			if (controlBlock!=null) {
				int i;
				Block parentBlock = controlBlock.parent;
				int indexEnd = parentBlock.listOfControlBlocks.count-1;
				for (i=controlBlock.indexInListOfControlBlocksOfParent+1; i<parentBlock.listOfControlBlocks.count; i++) {
					FindControlBlockParams block = (FindControlBlockParams) parentBlock.listOfControlBlocks.getItem(i);
					// 다음 controlBlock이 없는 try, catch문이거나 
					if ( block.catOfControls==null) {
						indexEnd = i-1;
						break;
					}
					// 다음 controlBlock이 else if나 else가 아니면
					if (!(block.catOfControls.category==CategoryOfControls.Control_elseif || 
							block.catOfControls.category==CategoryOfControls.Control_else)) {
						indexEnd = i-1;
						break;
					}
				}
				FindControlBlockParams lastBlock = 
						(FindControlBlockParams) parentBlock.listOfControlBlocks.getItem(indexEnd);
				indexOfExitOfIf_ElseIf_Else = lastBlock.endIndex();
				
				// if (i==9) if (i==3) continue;와 같이 '{', '}'이 없는 if문일 경우 
				/*if (controlBlock.findBlockParams==null && controlBlock.listOfControlBlocks.count>0) {
					indexOfExitOfIf_ElseIf_Else = ByteCode_Types.getEndIndexOfNestingIfWithoutMiddlePair(controlBlock.nameIndex());
				}*/
				if (controlBlock.endIndexWhenNestingControlBlockWithoutMiddlePair!=-1) {
					indexOfExitOfIf_ElseIf_Else = controlBlock.endIndexWhenNestingControlBlockWithoutMiddlePair;
				}
			}
			else {
				// int i = 1>0 ? 3 : 2;
				return ThreeOperandsOperation.FindEndIndex_ThreeOperandsOperation(compiler, compiler.data.mBuffer, funcCall.startIndex());
			}
			return indexOfExitOfIf_ElseIf_Else;
		}
		else if (mode==4) {
			if (controlBlock!=null) {
				return controlBlock.indexOfLeftParenthesis()+1;
			}
			else {
				// int i = 1>0 ? 3 : 2;
				// 조건식의 시작부분 mBuffer 인덱스를 구한다.
				return funcCall.startIndex();
			}
		}
		else if (mode==5) {//increments in for
			int indexOfSemicolon2 = controlBlock.funcCall.endIndex();
			indexOfSemicolon2 = 
					CompilerHelper.SkipBlank(compiler.data.mBuffer, false, indexOfSemicolon2+1, compiler.data.mBuffer.count-1);
			return indexOfSemicolon2;			
		}
		else if (mode==6) { // finally starts
			return controlBlock.startIndex();
		}
		else if (mode==7) { // exit of try-catch-finally
			return controlBlock.endIndex();
		}
		else if (mode==8) { // finally ends
			return controlBlock.endIndex();
		}
		else if (mode==9) { // BlockStart
			return controlBlock.nameIndex();
		}
		else if (mode==10) { // exit of finally (handler)
			return controlBlock.endIndex()-1;
		}
		return -1;
	}
	
	
	
	/**mode 6, 7, 8은 try-catch-finally에서 마지막 블록이어야 한다. 
	 * @param mode: 0-run(controlBlock.findBlockParams.startIndex()),<br>
	 * 1:exit_of_condition(controlBlock.indexOfRightParenthesis()),<br> 
	 * 2:exit of control(controlBlock.endIndex()),<br>
	 * 3:exit of if-elseif-else(lastBlock.endIndex()),<br>
	 * 4:condition(controlBlock.indexOfLeftParenthesis()+1),<br>
	 * 5:increments in for(controlBlock.funcCall.endIndex()+1 SkipBlank),<br> 
	 * 6:finally starts(controlBlock.startIndex()),<br>
	 * 7:exit of try-catch-finally(controlBlock.endIndex()),<br>
	 * 8:finally ends(controlBlock.endIndex()),<br>
	 * 9:BlockStart(controlBlock.nameIndex())<br>
	 * 가짜 try, catch블록의 시작은 9번으로 호출하고, 끝은 2번으로 호출한다.
	 * @param funcCall : 3항연산자에서 조건식 부분을 말한다. 3항 연산일 경우 null이 아니고, controlBlock은 null이 된다.*/
	public static String getStringOfmBufferIndex(Compiler compiler, FindControlBlockParams controlBlock, byte mode, FindFuncCallParam funcCall) {
		if ((controlBlock!=null && !controlBlock.isFake) || controlBlock==null) {
			return "("+getIndexInmBuffer(compiler, controlBlock, mode, funcCall)+"), ";
		}
		else {
			// main()에 있는 가짜 try, catch
			if (mode==0) {
				if (controlBlock instanceof FindSpecialBlockParams) {
					FindSpecialBlockParams special = (FindSpecialBlockParams) controlBlock;
					if (special.anotherName.equals(ByteCode_Types.TryFinallyShieldForFuncWithSync)) {
						return "("+ByteCode_Types.startIndexOfFakeFinallyInFuncWithSync+"), ";
					}
				}
			}
			else if (mode==9) {
				if (controlBlock instanceof FindSpecialBlockParams) {
					FindSpecialBlockParams special = (FindSpecialBlockParams) controlBlock;
					/*if (special.specialBlockType==FindSpecialBlockParams.SpecialBlockType_try) {
						if (special.anotherName.equals(ByteCode_Types.TryCatchShieldForConsole)) {
							return "("+ByteCode_Types.startIndexOfFakeTryInMain+"), ";
						}
						else {
							return "("+ByteCode_Types.startIndexOfFakeTryInFuncWithSync+"), ";
						}
					}
					else if (special.specialBlockType==FindSpecialBlockParams.SpecialBlockType_catch) {
						if (special.anotherName.equals(ByteCode_Types.TryCatchShieldForConsole)) {
							return "("+ByteCode_Types.startIndexOfFakeCatchInMain+"), ";
						}
					}
					else if (special.specialBlockType==FindSpecialBlockParams.SpecialBlockType_finally) {
						if (special.anotherName.equals(ByteCode_Types.TryFinallyShieldForFuncWithSync)) {
							return "("+ByteCode_Types.startIndexOfFakeFinallyInFuncWithSync+"), ";
						}
					}*/
					return "("+ByteCode_Types.getFakeTryCatchFinallyIndex(special, 0)+"), ";
				}
			}
			else if (mode==2) {
				if (controlBlock instanceof FindSpecialBlockParams) {
					FindSpecialBlockParams special = (FindSpecialBlockParams) controlBlock;
					/*if (special.specialBlockType==FindSpecialBlockParams.SpecialBlockType_try) {
						if (special.anotherName.equals(ByteCode_Types.TryCatchShieldForConsole)) {
							return "("+ByteCode_Types.endIndexOfFakeTryInMain+"), ";
						}
						else {
							return "("+ByteCode_Types.endIndexOfFakeTryInFuncWithSync+"), ";
						}
					}
					else if (special.specialBlockType==FindSpecialBlockParams.SpecialBlockType_catch) {
						return "("+ByteCode_Types.endIndexOfFakeCatchInMain+"), ";
					}
					else if (special.specialBlockType==FindSpecialBlockParams.SpecialBlockType_finally) {
						return "("+ByteCode_Types.endIndexOfFakeFinallyInFuncWithSync+"), ";
					}*/
					return "("+ByteCode_Types.getFakeTryCatchFinallyIndex(special, 1)+"), ";
				}
			}
			else if (mode==6) {
				if (controlBlock instanceof FindSpecialBlockParams) {
					FindSpecialBlockParams special = (FindSpecialBlockParams) controlBlock;
					if (special.specialBlockType==FindSpecialBlockParams.SpecialBlockType_finally) {
						return "("+ByteCode_Types.startIndexOfFakeFinallyInFuncWithSync+"), ";
					}
				}
			}
			else if (mode==8) {
				if (controlBlock instanceof FindSpecialBlockParams) {
					FindSpecialBlockParams special = (FindSpecialBlockParams) controlBlock;
					if (special.specialBlockType==FindSpecialBlockParams.SpecialBlockType_finally) {
						return "("+ByteCode_Types.endIndexOfFakeFinallyInFuncWithSync+"), ";
					}
				}
			}
			else if (mode==7) {
				if (controlBlock instanceof FindSpecialBlockParams) {
					FindSpecialBlockParams special = (FindSpecialBlockParams) controlBlock;
					/*if (special.specialBlockType==FindSpecialBlockParams.SpecialBlockType_catch) {
						return "("+ByteCode_Types.endIndexOfFakeCatchInMain+"), ";
					}
					if (special.specialBlockType==FindSpecialBlockParams.SpecialBlockType_finally) {
						return "("+ByteCode_Types.endIndexOfFakeFinallyInFuncWithSync+"), ";
					}*/
					return "("+ByteCode_Types.getFakeTryCatchFinallyIndex(special, 1)+"), ";
				}
			}
		}
		return null;
	}
	
	
	
	
	
	
	
	public static boolean isSmallInteger(FindVarUseParams varUse) {
		String constant = varUse.originName;
		if (constant.charAt(0)=='"'/* || constant.charAt(0)=='\''*/) return false;
		if (constant.equals("null")) return true;
		if (constant.equals("true") || constant.equals("false")) return true;
		
		if (constant.charAt(0)=='\'') {
			if (constant.charAt(1)!='\\') {
				int unicode = (int)varUse.name.charAt(1);
				if (Short.MIN_VALUE<=unicode && unicode<=Short.MAX_VALUE)
					return true;
			}
			else {
				int unicode = (int)varUse.name.charAt(2);
				if (Short.MIN_VALUE<=unicode && unicode<=Short.MAX_VALUE)
					return true;
			}
		}
		
		if (Number.IsNumber2(constant)==7 || 
				Number.IsNumber2(constant)==2) return true;
		
		return false;
	}
	
	/**number이 숫자이면 'f', 'd', 'l"과 같은 접미사를 제거한 스트링을 리턴한다.*/
	public static String removeLastCharOfNumber(String number) {
		// str이 숫자이면 'f', 'd', 'l"과 같은 접미사를 제거한 스트링을 리턴한다.		
		if (number.length()>0) {
			if (number.length()>2 && number.charAt(0)=='0' && number.charAt(1)=='x') {
				char chLast = number.charAt(number.length()-1);
				if (!(('A'<=chLast && chLast<='F') || ('a'<=chLast && chLast<='f'))) {
					if (('A'<=chLast && chLast<='Z') || ('a'<=chLast && chLast<='z')) {
						number = number.substring(0, number.length()-1);
					}
				}
				return number;
			}
			else {
				char chLast = number.charAt(number.length()-1);
				if (('A'<=chLast && chLast<='Z') || ('a'<=chLast && chLast<='z')) {
					number = number.substring(0, number.length()-1);
				}
			}
		}
		return number;
	}
	
	/**str이 스트링이면 '"', '\''을 제거한 스트링을 리턴한다.*/
	public static String removeSymbolsOfString(String str) {
		try {
		if (str.charAt(0)=='"' || str.charAt(0)=='\'') {
			return str.substring(1, str.length()-1);
		}
		return str;
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
		}
		return null;
	}
	
	/** converts \n to "\\"+"n"*/
	public static String convertNewLineCharTo2Chars(String str) {
		int i;
		ArrayListChar r = new ArrayListChar(str.length());
		int len = str.length();
		for (i=0; i<len; i++) {
			char c = str.charAt(i);
			if (c=='\n') {
				r.add('\\');
				r.add('n');
			}
			else {
				r.add(c);
			}
		}
		return new String(r.getItems());
	}
	
	/**StringTokenizer.ConvertToStringArray2(HighArray_CodeChar input, int initMaxLengthOfArray, Language language)에서
	 * "\"", "\'", "\\" 등은 모두 \을 포함한 스트링을 리턴하므로 
	 * 클래스 파일을 쓸때 역슬레시를 제거해 준다.<br>
	 * "\"", "\'", "\\"에서 \을 skip한다. 
	 * "\n", "\r", "\t", "\b"을 역슬래시를 제거한 한문자로 저장한다.*/
	public static String processReverseSlashOfString(String str) {
		int i;
		ArrayListChar r = new ArrayListChar(str.length());
		int len = str.length();
		for (i=0; i<len; i++) {
			char c = str.charAt(i);
			if (c=='\\') {
				char prevc = 0;
				if (i>0) {
					prevc = str.charAt(i-1);
					char nextc = 0;
					if (i+1<str.length()) {
						nextc = str.charAt(i+1);
						if (prevc!='\\' && (nextc=='"' || nextc=='\'' || nextc=='\\')) {
							// "\"", "\'", "\\"에서 \을 skip한다.
							continue;
						}
						else if (prevc!='\\' && (nextc=='n' || nextc=='r' || nextc=='t' || nextc=='b' || nextc=='0')) {
							// "\n", "\r", "\t", "\b"을 역슬래시를 제거한 한문자로 저장한다.
							// \n, \r, \t, \b
							if (nextc=='n') r.add('\n');
							else if (nextc=='r') r.add('\r');
							else if (nextc=='t') r.add('\t');
							else if (nextc=='b') r.add('\b');
							else if (nextc=='0') r.add('\0');
							// 다음 문자를 skip한다.
							i++;
							continue;
						}
						else {
							r.add(c);
						}
					}
					else {
						// "\\"에서 c는 두번째 \
						if (prevc=='\\') {
							r.add(c);
						}
						else {
							r.add(c);
						}
					}
				}
				else {
					char nextc = 0;
					if (i+1<str.length()) {
						nextc = str.charAt(i+1);
						if ((nextc=='"' || nextc=='\'' || nextc=='\\')) {
							// "\"", "\'", "\\"에서 \을 skip한다.
							continue;
						}
						else if (nextc=='n' || nextc=='r' || nextc=='t' || nextc=='b') {
							// "\n", "\r", "\t", "\b"을 역슬래시를 제거한 한문자로 저장한다.
							// \n, \r, \t, \b
							if (nextc=='n') r.add('\n');
							else if (nextc=='r') r.add('\r');
							else if (nextc=='t') r.add('\t');
							else if (nextc=='b') r.add('\b');
							// 다음 문자를 skip한다.
							i++;
							continue;
						}
						else {
							r.add(c);
						}
					}
					else {
						// 스트링이 \으로 끝날 경우
						r.add(c);
					}
				}
			}
			else {
				r.add(c);
			}
		}
		return new String(r.getItems());
	}
}
