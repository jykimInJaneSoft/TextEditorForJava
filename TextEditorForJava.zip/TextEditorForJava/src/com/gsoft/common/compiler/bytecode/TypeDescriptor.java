package com.gsoft.common.compiler.bytecode;

import java.io.File;

import android.graphics.Color;

import com.gsoft.common.Common_Settings;
import com.gsoft.common.FileHelper;
import com.gsoft.common.Code.CodeString;
import com.gsoft.common.compiler.Array;
import com.gsoft.common.compiler.ClassCache;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.CompilerStatic;
import com.gsoft.common.compiler.HighArray_CodeString;
import com.gsoft.common.compiler.StringTokenizer;
import com.gsoft.common.compiler.TemplateBase;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.Compiler_types.FindFunctionParams;
import com.gsoft.common.compiler.Compiler_types.FindVarParams;
import com.gsoft.common.compiler.Compiler_types.Language;
import com.gsoft.common.compiler.classloader.Loader;
import com.gsoft.common.util.ArrayListChar;
import com.gsoft.common.util.HighArray_CodeChar;

import com.gsoft.common.compiler.bytecode.ByteCode_Types;

public class TypeDescriptor {
	
	/**android.view$View, com.gsoft.common.gui.Menu*/
	public static String toBinaryName(String fullName, int coreThreadID) {
		String binaryName = TypeDescriptor.getDescriptorExceptLAndSemicolon(fullName, coreThreadID);
		binaryName = binaryName.replace('/', '.');
		return binaryName;
	}
	
	/** Lcom/gsoft/common/gui/Util$HighArray; 을 L과 ;이 안 붙는 com/gsoft/common/gui/Util$HighArray 의 형태로 바꾼다.*/
	public static String toFullQualifiedName(String classDesc) {
		if (classDesc.charAt(0)!='[') {
			if (classDesc.charAt(0)=='L' && classDesc.charAt(classDesc.length()-1)==';') {
				classDesc = classDesc.substring(1, classDesc.length()-1);
			}
		}
		else {
			int i;
			for (i=0; i<classDesc.length(); i++) {
				if (classDesc.charAt(i)!='[') {
					break;
				}
			}
			String dimension = classDesc.substring(0, i);
			String objDesc = classDesc.substring(i);
			String desc = toFullQualifiedName(objDesc);
			return dimension + desc;
			// [[I
		}
		return classDesc;
	}
	
	static public String getDescriptor(FindClassParams classParams, int coreThreadID) {
		if (classParams==null) return null;
		ArrayListChar result = new ArrayListChar(30);		
		ByteCode_Types.getDescriptor(classParams.name, result, coreThreadID);
		String r = new String(result.getItems());
		return r;
	}
	
	
	/** L과 ;이 붙는 func 의 파라미터 리스트와 리턴타입으로
	 *  ([Lcom/gsoft/common/Util$ArrayList;I)[[Lcom/gsoft/common/ColorEx; 
	 * 와 같은 디스크립터를 리턴한다.*/
	static public String getDescriptor(FindFunctionParams func, int coreThreadID) {
		
		ArrayListChar descriptorArr = new ArrayListChar(50);
		
		// func 의 파라미터들에 대해서 디스크립터를 생성한다.
		descriptorArr.add('(');
		int i;
		for (i=0; i<func.listOfFuncArgs.count; i++) {
			FindVarParams param = (FindVarParams) func.listOfFuncArgs.getItem(i);
			ByteCode_Types.getDescriptor(param.typeName, descriptorArr, coreThreadID);
		}
		descriptorArr.add(')');
		
		// func 의 리턴타입에 대해서 디스크립터를 생성한다.
		if (func.isConstructor) {
			ByteCode_Types.getDescriptor("void", descriptorArr, coreThreadID);
		}
		else {
			ByteCode_Types.getDescriptor(func.returnType, descriptorArr, coreThreadID);
		}
		return new String(descriptorArr.getItems());
	}
	
	/** L과 ;이 붙는 Lcom/gsoft/common/ColorDialog; this 이와 같은 형태를 얻는다.*/
	static public String getDescriptorOfThis(FindClassParams classParams, int coreThreadID) {
		ArrayListChar result = new ArrayListChar(30);
		ByteCode_Types.getDescriptor(classParams.name, result, coreThreadID);
		result.add(" this");
		return new String(result.getItems());
		
		//return getDescriptor(classParams) + " this";
	}
	
	/** L과 ;이 안 붙는 com/gsoft/common/ColorEx 이와 같은 클래스의 디스크립터를 얻는다.*/
	static public String getDescriptorExceptLAndSemicolon(FindClassParams classParams, int coreThreadID) {
		if (classParams==null) return null;
		ArrayListChar result = new ArrayListChar(30);		
		ByteCode_Types.getDescriptor(classParams.name, result, coreThreadID);
		String r = new String(result.getItems());
		return TypeDescriptor.toFullQualifiedName(r);
	}
	
	/** L과 ;이 붙는 I, F, [[Lcom/gsoft/common/ColorEx; 등 이와 같은 클래스의 디스크립터를 얻는다.*/
	static public String getDescriptor(String typeName, int coreThreadID) {
		ArrayListChar result = new ArrayListChar(30);
		ByteCode_Types.getDescriptor(typeName, result, coreThreadID);
		return new String(result.getItems());
	}
	
	/** L과 ;이 안 붙는 I, F, [[com/gsoft/common/ColorEx 등 이와 같은 클래스의 디스크립터를 얻는다.*/
	static public String getDescriptorExceptLAndSemicolon(String typeName, int coreThreadID) {
		ArrayListChar result = new ArrayListChar(30);
		ByteCode_Types.getDescriptor(typeName, result, coreThreadID);
		String desc = new String(result.getItems());
		return TypeDescriptor.toFullQualifiedName(desc);
	}
	
	/** L과 ;이 붙는 [[Lcom/gsoft/common/ColorEx; 혹은 I 이와 같은 필드의 디스크립터를 얻는다.
	 * Refer to FindVarParams.getVarStr() and FindVarParams.getFieldStr()*/
	static public String getDescriptor(FindVarParams field, int coreThreadID) {
		
		ArrayListChar result = new ArrayListChar(30);
		ByteCode_Types.getDescriptor(field.typeName, result, coreThreadID);
		return new String(result.getItems());
	}
	
	/** L과 ;이 안 붙는 I, F, [[com/gsoft/common/ColorEx 등 이와 같은 클래스의 디스크립터를 얻는다.*/
	static public String getDescriptorExceptLAndSemicolon(FindVarParams field, int coreThreadID) {
		ArrayListChar result = new ArrayListChar(30);
		ByteCode_Types.getDescriptor(field.typeName, result, coreThreadID);
		String desc = new String(result.getItems());
		return TypeDescriptor.toFullQualifiedName(desc);
	}
	
	
	
	
	static public String[] getTokensFromFieldDesc(String fieldDesc) {
		String[] r = new String[2];
		int i;
		for (i=0; i<fieldDesc.length(); i++) {
			char c = fieldDesc.charAt(i);
			if (c==':' && fieldDesc.charAt(i+1)==':') {
				r[0] = fieldDesc.substring(0, i);
				r[1] = fieldDesc.substring(i+2, fieldDesc.length());
				return r;
			}
		}
		return null;
	}
	
	static public String[] getTokensFromMethodDesc(String methodDesc) {
		String[] r = new String[2];
		int i;
		for (i=0; i<methodDesc.length(); i++) {
			char c = methodDesc.charAt(i);
			if (c==':' && methodDesc.charAt(i+1)==':') {
				r[0] = methodDesc.substring(0, i);
				r[1] = methodDesc.substring(i+2, methodDesc.length());
				return r;
			}
		}
		return null;
	}
	
	/** @param nameAndTypeDesc : typeDesc + " " + name	 * 
	 *  @return : 0 : typeDesc, 1 : name
	 */
	static public String[] getTokensFromNameAndTypeDesc(String nameAndTypeDesc) {
		String[] r = new String[2];
		int i;
		for (i=0; i<nameAndTypeDesc.length(); i++) {
			char c = nameAndTypeDesc.charAt(i);
			if (c==' ') {
				r[0] = nameAndTypeDesc.substring(0, i);
				r[1] = nameAndTypeDesc.substring(i+1, nameAndTypeDesc.length());
				return r;
			}
		}
		return null;
	}
	
	
	/** typeName 인 com.gsoft.common.Util.ArrayList 을 
	 * 디렉토리 경로 형태인 com/gsoft/common/Util$ArrayList 로 바꾼다.
	 * 바이트코드를 만드는 것이므로 '/'으로 바꿔준다.*/
	public static void getClassDescriptor(String typeName, ArrayListChar result, int coreThreadID) {
		typeName = Array.getArrayElementType(typeName);
		typeName = TemplateBase.getTemplateOriginalType(typeName);
		
		if (CompilerHelper.IsDefaultType(typeName)) return;
		
		if (typeName.equals("com.gsoft.common.Util.HighArray_char")) {
		}
		
		String classFilePath = null;
		String sourcePath = null;
		
		FindClassParams classParams = 
				ClassCache.getFindClassParams(CompilerStatic.mlistOfAllClassesHashed[coreThreadID], typeName);
		if (classParams!=null) {
			String filename = classParams.compiler.data.filename;
			String ext = FileHelper.getExt(filename);
			if (ext.equals(".class")) {
				classFilePath = filename;
			}
			else if (ext.equals(".java")) {
				//sourcePath = filename;
				String filenameExceptExt = FileHelper.getFilenameExceptExt(filename);
				String newFilename = Common_Settings.pathProjectSrc+File.separator+classParams.name.replace('.', File.separatorChar);
				if (newFilename.contains(filenameExceptExt) && newFilename.length()>filenameExceptExt.length()) {
					// classParams는 filename의 내부클래스이다.
					sourcePath = filename;
				}
				else {
					// classParams는 filename에 있는 유일한 클래스이거나 대등관계로 존재하는 클래스이다.
					// class A{
					// }
					// class B{
					// }
					sourcePath = newFilename+".java";
				}
			}
		}
		else {		
			String slashedTypeName = typeName.replace('.', File.separatorChar);
			String path = Common_Settings.pathAndroid + File.separator + slashedTypeName;
			
			int i;
			int[] modes = {0, 1, 3};
			for (i=0; i<modes.length; i++) {
				File file = CompilerStatic.getAbsPath_FromVariousClassPath(modes[i], slashedTypeName);
				if (file==null) continue;
				path = file.getAbsolutePath();
				classFilePath = Loader.fixClassPath(path);
				if (classFilePath!=null) break;
			}
		}
		
		
		
		if (classFilePath!=null) {
			int i;
			int[] modes = {0, 1, 3};
			
			for (i=0; i<modes.length; i++) {
				String slashedFullname = CompilerStatic.getSlashedFullname_FromVariousClassPath(modes[i], classFilePath, typeName);
				if (slashedFullname==null) continue;
				String fullname = slashedFullname.replace('/', '.');
				fullname = fullname.replace('$', '.');
				if (fullname.equals(typeName)) {
					result.add(slashedFullname);
					// classFilePath 를 얻었으므로 리턴한다.
					// classFilePath 를 얻지 못하면 소스패스를 확인한다.
					return;
				}
			}
		}
		
		
		
		if (classFilePath==null && sourcePath==null) {
			sourcePath = Common_Settings.pathProjectSrc + File.separator + typeName.replace('.', File.separatorChar);
			sourcePath = Loader.getSourceFilePath(sourcePath);
			if (sourcePath==null) return;
			// java.lang.String의 소스파일은 없으므로 직접 만든 소스파일을 제공해야 한다.
			// 직접 만든 소스파일의 위치를 찾는다.
			//classFilePath = CompilerHelper.getSourceFilePathAddingComGsoftCommon(typeName);
			
			//if (classFilePath==null) return;
			
			sourcePath = FileHelper.getFilenameExceptExt(sourcePath);
		}
		
		if (typeName.contains("PathClassWriter")) {
		}
		
		// com.gsoft.common.Util.ArrayList
		
		HighArray_CodeString stringArr1 = 
			new StringTokenizer().ConvertToStringArray2(new HighArray_CodeChar(typeName,Color.BLACK), 20, Language.Java);
		
		// Control.pathProjectSrc + File.separator + com\gsoft\common\Util + ".java"
		HighArray_CodeString stringArr2;
		
		stringArr2 = new StringTokenizer().ConvertToStringArray2(new HighArray_CodeChar(sourcePath,Color.BLACK), 20, Language.Java);
		
		
		
		
		int i;
		// Util
		for (i=stringArr2.count-1; i>=0; i--) {
			CodeString str = stringArr2.getItem(i);
			if (CompilerHelper.IsSeparator(str)) continue;
			if (str.equals("java") || str.equals("class")) continue;
			break;				
		}
		
		CodeString lastStr = null;
		try {
		lastStr = stringArr2.getItem(i); // Util
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
		}
		int j;
		for (j=stringArr1.count-1; j>=0; j--) {
			CodeString str = stringArr1.getItem(j);
			if (CompilerHelper.IsSeparator(str)) continue;
			try {
			if (str.equals(lastStr.str)) {
				break;
			}
			}catch(Exception e) {
				return;
				//if (Common_Settings.g_printsLog) e.printStackTrace();
			}
		}
		int lastIndex = j;
	
		for (j=0; j<=lastIndex; j++) { // separator 를 디렉토리 경로 문자로 변경
			CodeString str = stringArr1.getItem(j);
			if (!CompilerHelper.IsSeparator(str)) {
				result.add(str.str);
			}
			else {
				result.add('/'); // 자바 클래스 파일 경로 문자
			}
		}
		
		for (j=lastIndex+1; j<stringArr1.count; j++) { // separator 를 내부클래스 구분 문자($)로 변경
			CodeString str = stringArr1.getItem(j);
			if (!CompilerHelper.IsSeparator(str)) {
				result.add(str.str);
			}
			else {
				result.add('$'); // 내부클래스 구분 문자($)
			}
		}
		
	
	}
}
