package com.gsoft.common.compiler.bytecode;

import com.gsoft.common.compiler.bytecode.ByteCode_Types.ByteCodeInstruction;

public class InstructionSet {
	/** no name cb-fd
	"lookupswitch" (4개이상), "tableswitch" (4개이상), "wide" (3개나 5개) 은 가변 인덱스이다.*/
public static ByteCodeInstruction[] instructionSet = 
{
	new ByteCodeInstruction("aaload", (short)0x0032, (short)0, "arrayref, index → value\nload onto the stack a reference from an array"),
	new ByteCodeInstruction("aastore", (short)0x0053, (short)0, "arrayref, index, value →\nstore into a reference in an array"),
	new ByteCodeInstruction("aconst_null", (short)0x0001, (short)0, "→ null\npush a null reference onto the stack"),
	
	new ByteCodeInstruction("aload", (short)0x0019, (short)1, "→ objectref\nload a reference onto the stack from a local variable #index"),
	new ByteCodeInstruction("aload_0", (short)0x002a, (short)0, "→ objectref\nload a reference onto the stack from local variable 0"),
	new ByteCodeInstruction("aload_1", (short)0x002b, (short)0, "→ objectref\nload a reference onto the stack from local variable 1"),
	new ByteCodeInstruction("aload_2", (short)0x002c, (short)0, "→ objectref\nload a reference onto the stack from local variable 2"),
	new ByteCodeInstruction("aload_3", (short)0x002d, (short)0, "→ objectref\nload a reference onto the stack from local variable 3"),
	
	new ByteCodeInstruction("anewarray", (short)0x00bd, (short)2, "count → arrayref\ncreate a new array of references of length count and component type identified by the class reference index (indexbyte1 << 8 + indexbyte2) in the constant pool"),
	new ByteCodeInstruction("areturn", (short)0x00b0, (short)0, "objectref → [empty]\nreturn a reference from a method"),
	new ByteCodeInstruction("arraylength", (short)0x00be, (short)0, "arrayref → length\nget the length of an array"),
	
	new ByteCodeInstruction("astore", (short)0x003a, (short)1, "objectref →\nstore a reference into a local variable #index"),
	new ByteCodeInstruction("astore_0", (short)0x004b, (short)0, "objectref →\nstore a reference into a local variable 0"),
	new ByteCodeInstruction("astore_1", (short)0x004c, (short)0, "objectref →\nstore a reference into a local variable 1"),
	new ByteCodeInstruction("astore_2", (short)0x004d, (short)0, "objectref →\nstore a reference into a local variable 2"),
	new ByteCodeInstruction("astore_3", (short)0x004e, (short)0, "objectref →\nstore a reference into a local variable 3"),
	
	new ByteCodeInstruction("athrow", (short)0x00bf, (short)0, "objectref → [empty], objectref\nthrows an error or exception (notice that the rest of the stack is cleared, leaving only a reference to the Throwable)"),
	
	new ByteCodeInstruction("baload", (short)0x0033, (short)0, "arrayref, index → value\nload a byte or Boolean value from an array"),
	new ByteCodeInstruction("bastore", (short)0x0054, (short)0, "arrayref, index, value →\nstore a byte or Boolean value into an array"),
	new ByteCodeInstruction("bipush", (short)0x0010, (short)1, "→ value\npush a byte onto the stack as an integer value"),
	new ByteCodeInstruction("breakpoint", (short)0x00ca, (short)0, "reserved for breakpoints in Java debuggers; should not appear in any class file"),
	
	new ByteCodeInstruction("caload", (short)0x0034, (short)0, "arrayref, index → value\nload a char from an array"),
	new ByteCodeInstruction("castore", (short)0x0055, (short)0, "arrayref, index, value →\nstore a char into an array"),
	new ByteCodeInstruction("checkcast", (short)0x00c0, (short)2, "objectref → objectref\nchecks whether an objectref is of a certain type, the class reference of which is in the constant pool at index (indexbyte1 << 8 + indexbyte2)"),
	
	
	new ByteCodeInstruction("d2f", (short)0x0090, (short)0, "value → result\nconvert a double to a float"),
	new ByteCodeInstruction("d2i", (short)0x008e, (short)0, "value → result\nconvert a double to an int"),
	new ByteCodeInstruction("d2l", (short)0x008f, (short)0, "value → result\nconvert a double to a long"),
	new ByteCodeInstruction("dadd", (short)0x0063, (short)0, "value1, value2 → result\nadd two doubles"),
	
	new ByteCodeInstruction("daload", (short)0x0031, (short)0, "arrayref, index → value\nload a double from an array"),
	new ByteCodeInstruction("dastore", (short)0x0052, (short)0, "arrayref, index, value →\nstore a double into an array"),
	new ByteCodeInstruction("dcmpg", (short)0x0098, (short)0, "value1, value2 → result\ncompare two doubles"),
	new ByteCodeInstruction("dcmpl", (short)0x0097, (short)0, "value1, value2 → result\ncompare two doubles"),
	
	new ByteCodeInstruction("dconst_0", (short)0x000e, (short)0, "→ 0.0\npush the constant 0.0 onto the stack"),
	new ByteCodeInstruction("dconst_1", (short)0x000f, (short)0, "→ 1.0\npush the constant 1.0 onto the stack"),
	
	new ByteCodeInstruction("ddiv", (short)0x006f, (short)0, "value1, value2 → result\ndivide two doubles"),
	
	new ByteCodeInstruction("dload", (short)0x0018, (short)1, "→ value\nload a double value from a local variable #index"),
	new ByteCodeInstruction("dload_0", (short)0x0026, (short)0, "→ value\nload a double value from a local variable 0"),
	new ByteCodeInstruction("dload_1", (short)0x0027, (short)0, "→ value\nload a double value from a local variable 1"),
	new ByteCodeInstruction("dload_2", (short)0x0028, (short)0, "→ value\nload a double value from a local variable 2"),
	new ByteCodeInstruction("dload_3", (short)0x0029, (short)0, "→ value\nload a double value from a local variable 3"),
	
	new ByteCodeInstruction("dmul", (short)0x006b, (short)0, "value1, value2 → result\nmultiply two doubles"),
	new ByteCodeInstruction("dneg", (short)0x0077, (short)0, "value → result\nnegate a double"),
	new ByteCodeInstruction("drem", (short)0x0073, (short)0, "value1, value2 → result\nget the remainder from a division between two doubles"),
	new ByteCodeInstruction("dreturn", (short)0x00af, (short)0, "value → [empty]\nreturn a double from a method"),
	
	new ByteCodeInstruction("dstore", (short)0x0039, (short)1, "value →\nstore a double value into a local variable #index"),
	new ByteCodeInstruction("dstore_0", (short)0x0047, (short)0, "value →\nstore a double value into a local variable 0"),
	new ByteCodeInstruction("dstore_1", (short)0x0048, (short)0, "value →\nstore a double value into a local variable 1"),
	new ByteCodeInstruction("dstore_2", (short)0x0049, (short)0, "value →\nstore a double value into a local variable 2"),
	new ByteCodeInstruction("dstore_3", (short)0x004a, (short)0, "value →\nstore a double value into a local variable 3"),
	
	new ByteCodeInstruction("dsub", (short)0x0067, (short)0, "value1, value2 → result\nsubtract a double from another"),
	
	new ByteCodeInstruction("dup", (short)0x0059, (short)0, "value → value, value\nduplicate the value on top of the stack"),
	new ByteCodeInstruction("dup_x1", (short)0x005a, (short)0, "value2, value1 → value1, value2, value1\ninsert a copy of the top value into the stack two values from the top. value1 and value2 must not be of the type double or long."),
	new ByteCodeInstruction("dup_x2", (short)0x005b, (short)0, "value3, value2, value1 → value1, value3, value2, value1\ninsert a copy of the top value into the stack two (if value2 is double or long it takes up the entry of value3, too) or three values (if value2 is neither double nor long) from the top"),
	new ByteCodeInstruction("dup2", (short)0x005c, (short)0, "{value2, value1} → {value2, value1}, {value2, value1}\nduplicate top two stack words (two values, if value1 is not double nor long; a single value, if value1 is double or long)"),
	new ByteCodeInstruction("dup2_x1", (short)0x005d, (short)0, "value3, {value2, value1} → {value2, value1}, value3, {value2, value1}\nduplicate two words and insert beneath third word (see explanation above)"),
	new ByteCodeInstruction("dup2_x2", (short)0x005e, (short)0, "{value4, value3}, {value2, value1} → {value2, value1}, {value4, value3}, {value2, value1}\nduplicate two words and insert beneath fourth word"),
	
	new ByteCodeInstruction("f2d", (short)0x008d, (short)0, "value → result\nconvert a float to a double"),
	new ByteCodeInstruction("f2i", (short)0x008b, (short)0, "value → result\nconvert a float to an int"),
	new ByteCodeInstruction("f2l", (short)0x008c, (short)0, "value → result\nconvert a float to a long"),
	
	new ByteCodeInstruction("fadd", (short)0x0062, (short)0, "value1, value2 → result\nadd two floats"),
	new ByteCodeInstruction("faload", (short)0x0030, (short)0, "arrayref, index → value\nload a float from an array"),
	new ByteCodeInstruction("fastore", (short)0x0051, (short)0, "arrayref, index, value →\nstore a float in an array"),
	new ByteCodeInstruction("fcmpg", (short)0x0096, (short)0, "value1, value2 → result\ncompare two floats"),
	new ByteCodeInstruction("fcmpl", (short)0x0095, (short)0, "value1, value2 → result\ncompare two floats"),
	
	new ByteCodeInstruction("fconst_0", (short)0x000b, (short)0, "→ 0.0f\npush 0.0f on the stack"),
	new ByteCodeInstruction("fconst_1", (short)0x000c, (short)0, "→ 1.0f\npush 1.0f on the stack"),
	new ByteCodeInstruction("fconst_2", (short)0x000d, (short)0, "→ 2.0f\npush 2.0f on the stack"),
	
	new ByteCodeInstruction("fdiv", (short)0x006e, (short)0, "value1, value2 → result\ndivide two floats"),
	
	new ByteCodeInstruction("fload", (short)0x0017, (short)1, "→ value\nload a float value from a local variable #index"),
	new ByteCodeInstruction("fload_0", (short)0x0022, (short)0, "→ value\nload a float value from a local variable 0"),
	new ByteCodeInstruction("fload_1", (short)0x0023, (short)0, "→ value\nload a float value from a local variable 1"),
	new ByteCodeInstruction("fload_2", (short)0x0024, (short)0, "→ value\nload a float value from a local variable 2"),
	new ByteCodeInstruction("fload_3", (short)0x0025, (short)0, "→ value\nload a float value from a local variable 3"),
	
	new ByteCodeInstruction("fmul", (short)0x006a, (short)0, "value1, value2 → result\nmultiply two floats"),
	new ByteCodeInstruction("fneg", (short)0x0076, (short)0, "value → result\nnegate a float"),
	new ByteCodeInstruction("frem", (short)0x0072, (short)0, "value1, value2 → result\nget the remainder from a division between two floats"),
	new ByteCodeInstruction("freturn", (short)0x00ae, (short)0, "value → [empty]\nreturn a float"),
	
	new ByteCodeInstruction("fstore", (short)0x0038, (short)1, "value →\nstore a float value into a local variable #index"),
	new ByteCodeInstruction("fstore_0", (short)0x0043, (short)0, "value →\nstore a float value into a local variable 0"),
	new ByteCodeInstruction("fstore_1", (short)0x0044, (short)0, "value →\nstore a float value into a local variable 1"),
	new ByteCodeInstruction("fstore_2", (short)0x0045, (short)0, "value →\nstore a float value into a local variable 2"),
	new ByteCodeInstruction("fstore_3", (short)0x0046, (short)0, "value →\nstore a float value into a local variable 3"),
	
	new ByteCodeInstruction("fsub", (short)0x0066, (short)0, "value1, value2 → result\nsubtract two floats"),
	
	new ByteCodeInstruction("getfield", (short)0x00b4, (short)2, "objectref → value\nget a field value of an object objectref, where the field is identified by field reference in the constant pool index (index1 << 8 + index2)"),
	new ByteCodeInstruction("getstatic", (short)0x00b2, (short)2, "→ value\nget a static field value of a class, where the field is identified by field reference in the constant pool index (index1 << 8 + index2)"),
	new ByteCodeInstruction("goto", (short)0x00a7, (short)2, "goes to another instruction at branchoffset (signed short constructed from unsigned bytes branchbyte1 << 8 + branchbyte2)"),
	new ByteCodeInstruction("goto_w", (short)0x00c8, (short)4, "goes to another instruction at branchoffset (signed int constructed from unsigned bytes branchbyte1 << 24 + branchbyte2 << 16 + branchbyte3 << 8 + branchbyte4)"),
	
	new ByteCodeInstruction("i2b", (short)0x0091, (short)0, "value → result\nconvert an int into a byte"),
	new ByteCodeInstruction("i2c", (short)0x0092, (short)0, "value → result\nconvert an int into a character"),
	new ByteCodeInstruction("i2d", (short)0x0087, (short)0, "value → result\nconvert an int into a double"),
	new ByteCodeInstruction("i2f", (short)0x0086, (short)0, "value → result\nconvert an int into a float"),
	new ByteCodeInstruction("i2l", (short)0x0085, (short)0, "value → result\nconvert an int into a long"),
	new ByteCodeInstruction("i2s", (short)0x0093, (short)0, "value → result\nconvert an int into a short"),
	
	new ByteCodeInstruction("iadd", (short)0x0060, (short)0, "value1, value2 → result\nadd two ints"),
	new ByteCodeInstruction("iaload", (short)0x002e, (short)0, "arrayref, index → value\nload an int from an array"),
	new ByteCodeInstruction("iand", (short)0x007e, (short)0, "value1, value2 → result\nperform a bitwise and on two integers"),
	new ByteCodeInstruction("iastore", (short)0x004f, (short)0, "arrayref, index, value → \nstore an int into an array"),
	
	new ByteCodeInstruction("iconst_m1", (short)0x0002, (short)0, "→ -1\nload the int value -1 onto the stack"),
	new ByteCodeInstruction("iconst_0", (short)0x0003, (short)0, "→ 0\nload the int value 0 onto the stack"),
	new ByteCodeInstruction("iconst_1", (short)0x0004, (short)0, "→ 1\nload the int value 1 onto the stack"),
	new ByteCodeInstruction("iconst_2", (short)0x0005, (short)0, "→ 2\nload the int value 2 onto the stack"),
	new ByteCodeInstruction("iconst_3", (short)0x0006, (short)0, "→ 3\nload the int value 3 onto the stack"),
	new ByteCodeInstruction("iconst_4", (short)0x0007, (short)0, "→ 4\nload the int value 4 onto the stack"),
	new ByteCodeInstruction("iconst_5", (short)0x0008, (short)0, "→ 5\nload the int value 5 onto the stack"),
	
	new ByteCodeInstruction("idiv", (short)0x006c, (short)0, "value1, value2 → result\ndivide two integers"),
	
	new ByteCodeInstruction("if_acmpeq", (short)0x00a5, (short)2, "value1, value2 →\nif references are equal, branch to instruction at branchoffset (signed short constructed from unsigned bytes branchbyte1 << 8 + branchbyte2)"),
	new ByteCodeInstruction("if_acmpne", (short)0x00a6, (short)2, "value1, value2 →\nif references are not equal, branch to instruction at branchoffset (signed short constructed from unsigned bytes branchbyte1 << 8 + branchbyte2)"),
	new ByteCodeInstruction("if_icmpeq", (short)0x009f, (short)2, "value1, value2 →\nif ints are equal, branch to instruction at branchoffset (signed short constructed from unsigned bytes branchbyte1 << 8 + branchbyte2)"),
	new ByteCodeInstruction("if_icmpge", (short)0x00a2, (short)2, "value1, value2 →\nif value1 is greater than or equal to value2, branch to instruction at branchoffset (signed short constructed from unsigned bytes branchbyte1 << 8 + branchbyte2)"),
	new ByteCodeInstruction("if_icmpgt", (short)0x00a3, (short)2, "value1, value2 →\nif value1 is greater than value2, branch to instruction at branchoffset (signed short constructed from unsigned bytes branchbyte1 << 8 + branchbyte2)"),
	new ByteCodeInstruction("if_icmple", (short)0x00a4, (short)2, "value1, value2 →\nif value1 is less than or equal to value2, branch to instruction at branchoffset (signed short constructed from unsigned bytes branchbyte1 << 8 + branchbyte2)"),
	new ByteCodeInstruction("if_icmplt", (short)0x00a1, (short)2, "value1, value2 →\nif value1 is less than value2, branch to instruction at branchoffset (signed short constructed from unsigned bytes branchbyte1 << 8 + branchbyte2)"),
	new ByteCodeInstruction("if_icmpne", (short)0x00a0, (short)2, "value1, value2 →\nif ints are not equal, branch to instruction at branchoffset (signed short constructed from unsigned bytes branchbyte1 << 8 + branchbyte2)"),
	
	new ByteCodeInstruction("ifeq", (short)0x0099, (short)2, "value →\nif value is 0, branch to instruction at branchoffset (signed short constructed from unsigned bytes branchbyte1 << 8 + branchbyte2)"),
	new ByteCodeInstruction("ifge", (short)0x009c, (short)2, "value →\nif value is greater than or equal to 0, branch to instruction at branchoffset (signed short constructed from unsigned bytes branchbyte1 << 8 + branchbyte2)"),
	new ByteCodeInstruction("ifgt", (short)0x009d, (short)2, "value →\nif value is greater than 0, branch to instruction at branchoffset (signed short constructed from unsigned bytes branchbyte1 << 8 + branchbyte2)"),
	new ByteCodeInstruction("ifle", (short)0x009e, (short)2, "value →\nif value is less than or equal to 0, branch to instruction at branchoffset (signed short constructed from unsigned bytes branchbyte1 << 8 + branchbyte2)"),
	new ByteCodeInstruction("iflt", (short)0x009b, (short)2, "value →\nif value is less than 0, branch to instruction at branchoffset (signed short constructed from unsigned bytes branchbyte1 << 8 + branchbyte2)"),
	new ByteCodeInstruction("ifne", (short)0x009a, (short)2, "value →\nif value is not 0, branch to instruction at branchoffset (signed short constructed from unsigned bytes branchbyte1 << 8 + branchbyte2)"),
	new ByteCodeInstruction("ifnonnull", (short)0x00c7, (short)2, "value →\nif value is not null, branch to instruction at branchoffset (signed short constructed from unsigned bytes branchbyte1 << 8 + branchbyte2)"),
	new ByteCodeInstruction("ifnull", (short)0x00c6, (short)2, "value →\nif value is null, branch to instruction at branchoffset (signed short constructed from unsigned bytes branchbyte1 << 8 + branchbyte2)"),
	
	new ByteCodeInstruction("iinc", (short)0x0084, (short)2, "[No change]\nincrement local variable #index by signed byte const"),
	
	new ByteCodeInstruction("iload", (short)0x0015, (short)1, "→ value\nload an int value from a local variable #index"),
	new ByteCodeInstruction("iload_0", (short)0x001a, (short)0, "→ value\nload an int value from a local variable 0"),
	new ByteCodeInstruction("iload_1", (short)0x001b, (short)0, "→ value\nload an int value from a local variable 1"),
	new ByteCodeInstruction("iload_2", (short)0x001c, (short)0, "→ value\nload an int value from a local variable 2"),
	new ByteCodeInstruction("iload_3", (short)0x001d, (short)0, "→ value\nload an int value from a local variable 3"),
	
	new ByteCodeInstruction("impdep1", (short)0x00fe, (short)0, "reserved for implementation-dependent operations within debuggers; should not appear in any class file"),
	new ByteCodeInstruction("impdep2", (short)0x00ff, (short)0, "reserved for implementation-dependent operations within debuggers; should not appear in any class file"),
	
	new ByteCodeInstruction("imul", (short)0x0068, (short)0, "value1, value2 → result\nmultiply two integers"),
	new ByteCodeInstruction("ineg", (short)0x0074, (short)0, "value → result\nnegate int"),
	
	new ByteCodeInstruction("instanceof", (short)0x00c1, (short)2, "objectref → result\ndetermines if an object objectref is of a given type, identified by class reference index in constant pool (indexbyte1 << 8 + indexbyte2)"),
	
	new ByteCodeInstruction("invokedynamic", (short)0x00ba, (short)4, "[arg1, [arg2 ...]] →\ninvokes a dynamic method identified by method reference index in constant pool (indexbyte1 << 8 + indexbyte2)"),
	new ByteCodeInstruction("invokeinterface", (short)0x00b9, (short)4, "objectref, [arg1, arg2, ...] →\ninvokes an interface method on object objectref, where the interface method is identified by method reference index in constant pool (indexbyte1 << 8 + indexbyte2)"),
	new ByteCodeInstruction("invokespecial", (short)0x00b7, (short)2, "objectref, [arg1, arg2, ...] →\ninvoke instance method on object objectref, where the method is identified by method reference index in constant pool (indexbyte1 << 8 + indexbyte2)"),
	new ByteCodeInstruction("invokestatic", (short)0x00b8, (short)2, "[arg1, arg2, ...] →\ninvoke a static method, where the method is identified by method reference index in constant pool (indexbyte1 << 8 + indexbyte2)"),
	new ByteCodeInstruction("invokevirtual", (short)0x00b6, (short)2, "objectref, [arg1, arg2, ...] →\ninvoke virtual method on object objectref, where the method is identified by method reference index in constant pool (indexbyte1 << 8 + indexbyte2)"),
	

	new ByteCodeInstruction("ior", (short)0x0080, (short)0, "value1, value2 → result\nbitwise int or"),
	new ByteCodeInstruction("irem", (short)0x0070, (short)0, "value1, value2 → result\nlogical int remainder"),
	new ByteCodeInstruction("ireturn", (short)0x00ac, (short)0, "value → [empty]\nreturn an integer from a method"),
	new ByteCodeInstruction("ishl", (short)0x0078, (short)0, "value1, value2 → result\nint shift left"),
	new ByteCodeInstruction("ishr", (short)0x007a, (short)0, "value1, value2 → result\nint arithmetic shift right"),
	
	new ByteCodeInstruction("istore", (short)0x0036, (short)1, "value →\nstore int value into variable #index"),
	new ByteCodeInstruction("istore_0", (short)0x003b, (short)0, "value →\nstore int value into variable 0"),
	new ByteCodeInstruction("istore_1", (short)0x003c, (short)0, "value →\nstore int value into variable 1"),
	new ByteCodeInstruction("istore_2", (short)0x003d, (short)0, "value →\nstore int value into variable 2"),
	new ByteCodeInstruction("istore_3", (short)0x003e, (short)0, "value →\nstore int value into variable 3"),
	
	new ByteCodeInstruction("isub", (short)0x0064, (short)0, "value1, value2 → result\nint subtract"),
	
	new ByteCodeInstruction("iushr", (short)0x007c, (short)0, "value1, value2 → result\nint logical shift right"),
	new ByteCodeInstruction("ixor", (short)0x0082, (short)0, "value1, value2 → result\nint xor"),
	
	new ByteCodeInstruction("jsr", (short)0x00a8, (short)2, "→ address\njump to subroutine at branchoffset (signed short constructed from unsigned bytes branchbyte1 << 8 + branchbyte2) and place the return address on the stack"),
	new ByteCodeInstruction("jsr_w", (short)0x00c9, (short)4, "→ address\njump to subroutine at branchoffset (signed int constructed from unsigned bytes branchbyte1 << 24 + branchbyte2 << 16 + branchbyte3 << 8 + branchbyte4) and place the return address on the stack"),
	
	new ByteCodeInstruction("l2d", (short)0x008a, (short)0, "value → result\nconvert a long to a double"),
	new ByteCodeInstruction("l2f", (short)0x0089, (short)0, "value → result\nconvert a long to a float"),
	new ByteCodeInstruction("l2i", (short)0x0088, (short)0, "value → result\nconvert a long to a int"),
	
	new ByteCodeInstruction("ladd", (short)0x0061, (short)0, "value1, value2 → result\nadd two longs"),
	new ByteCodeInstruction("laload", (short)0x002f, (short)0, "arrayref, index → value\nload a long from an array"),
	new ByteCodeInstruction("land", (short)0x007f, (short)0, "value1, value2 → result\nbitwise and of two longs"),
	new ByteCodeInstruction("lastore", (short)0x0050, (short)0, "arrayref, index, value →\nstore a long to an array"),		
	new ByteCodeInstruction("lcmp", (short)0x0094, (short)0, "value1, value2 → result\ncompare two longs values"),
	
	new ByteCodeInstruction("lconst_0", (short)0x0009, (short)0, "→ 0L\npush the long 0 onto the stack"),
	new ByteCodeInstruction("lconst_1", (short)0x000a, (short)0, "→ 1L\npush the long 1 onto the stack"),
	
	new ByteCodeInstruction("ldc", (short)0x0012, (short)1, "→ value\npush a constant #index from a constant pool (String, int or float) onto the stack"),
	new ByteCodeInstruction("ldc_w", (short)0x0013, (short)2, "→ value\npush a constant #index from a constant pool (String, int or float) onto the stack (wide index is constructed as indexbyte1 << 8 + indexbyte2)"),
	new ByteCodeInstruction("ldc2_w", (short)0x0014, (short)2, "→ value\npush a constant #index from a constant pool (double or long) onto the stack (wide index is constructed as indexbyte1 << 8 + indexbyte2)"),
	
	new ByteCodeInstruction("ldiv", (short)0x006d, (short)0, "value1, value2 → result\ndivide two longs"),
	
	new ByteCodeInstruction("lload", (short)0x0016, (short)1, "value load a long value from a local variable #index"), 
	new ByteCodeInstruction("lload_0", (short)0x001e, (short)0,  "value load a long value from a local variable 0"), 
	new ByteCodeInstruction("lload_1", (short)0x001f, (short)0,  "value load a long value from a local variable 1"),
	new ByteCodeInstruction("lload_2", (short)0x0020, (short)0,  "value load a long value from a local variable 2"),
	new ByteCodeInstruction("lload_3", (short)0x0021, (short)0,  "value load a long value from a local variable 3"),
	
	
	new ByteCodeInstruction("lmul", (short)0x0069, (short)0, "value1, value2 → result\nmultiply two longs"),
	new ByteCodeInstruction("lneg", (short)0x0075, (short)0, "value → result\nnegate a long"),
	
	new ByteCodeInstruction("lookupswitch", (short)0x00ab, (short)4, "key →\na target address is looked up from a table using a key and execution continues from the instruction at that address"),
	
	new ByteCodeInstruction("lor", (short)0x0081, (short)0, "value1, value2 → result\nbitwise or of two longs"),
	new ByteCodeInstruction("lrem", (short)0x0071, (short)0, "value1, value2 → result\nremainder of division of two longs"),
	new ByteCodeInstruction("lreturn", (short)0x00ad, (short)0, "value → [empty]\nreturn a long value"),
	new ByteCodeInstruction("lshl", (short)0x0079, (short)0, "value1, value2 → result\nbitwise shift left of a long value1 by int value2 positions"),
	new ByteCodeInstruction("lshr", (short)0x007b, (short)0, "value1, value2 → result\nbitwise shift right of a long value1 by int value2 positions"),
	
	new ByteCodeInstruction("lstore", (short)0x0037, (short)1, "value →\nstore a long value in a local variable #index"),
	new ByteCodeInstruction("lstore_0", (short)0x003f, (short)0, "value →\nstore a long value in a local variable 0"),
	new ByteCodeInstruction("lstore_1", (short)0x0040, (short)0, "value →\nstore a long value in a local variable 1"),
	new ByteCodeInstruction("lstore_2", (short)0x0041, (short)0, "value →\nstore a long value in a local variable 2"),
	new ByteCodeInstruction("lstore_3", (short)0x0042, (short)0, "value →\nstore a long value in a local variable 3"),
	
	new ByteCodeInstruction("lsub", (short)0x0065, (short)0, "value1, value2 → result\nsubtract two longs"),
	new ByteCodeInstruction("lushr", (short)0x007d, (short)0, "value1, value2 → result\nbitwise shift right of a long value1 by int value2 positions, unsigned"),
	new ByteCodeInstruction("lxor", (short)0x0083, (short)0, "value1, value2 → result\nbitwise exclusive or of two longs"),
	
	new ByteCodeInstruction("monitorenter", (short)0x00c2, (short)0, "objectref →\nenter monitor for object (grab the lock - start of synchronized() section)"),
	new ByteCodeInstruction("monitorexit", (short)0x00c3, (short)0, "objectref →\nexit monitor for object (release the lock - end of synchronized() section)"),
	new ByteCodeInstruction("multianewarray", (short)0x00c5, (short)3, "count1, [count2,...] → arrayref\ncreate a new array of dimensions dimensions with elements of type identified by class reference in constant pool index (indexbyte1 << 8 + indexbyte2); the sizes of each dimension is identified by count1, [count2, etc.]"),
	
	new ByteCodeInstruction("new", (short)0x00bb, (short)2, "→ objectref\ncreate new object of type identified by class reference in constant pool index (indexbyte1 << 8 + indexbyte2)"),
	new ByteCodeInstruction("newarray", (short)0x00bc, (short)1, "count → arrayref\ncreate new array with count elements of primitive type identified by atype"),
	new ByteCodeInstruction("nop", (short)0x0000, (short)0, "[No change]\nperform no operation"),
	
	new ByteCodeInstruction("pop", (short)0x0057, (short)0, "value →\ndiscard the top value on the stack"),
	new ByteCodeInstruction("pop2", (short)0x0058, (short)0, "{value2, value1} →\ndiscard the top two values on the stack (or one value, if it is a double or long)"),
	new ByteCodeInstruction("putfield", (short)0x00b5, (short)2, "objectref, value →\nset field to value in an object objectref, where the field is identified by a field reference index in constant pool (indexbyte1 << 8 + indexbyte2)"),
	new ByteCodeInstruction("putstatic", (short)0x00b3, (short)2, "value →\nset static field to value in a class, where the field is identified by a field reference index in constant pool (indexbyte1 << 8 + indexbyte2)"),
	
	new ByteCodeInstruction("ret", (short)0x00a9, (short)1, "[No change]\ncontinue execution from address taken from a local variable #index (the asymmetry with jsr is intentional)"),
	new ByteCodeInstruction("return", (short)0x00b1, (short)0, "→ [empty]\nreturn void from method"),
	
	new ByteCodeInstruction("saload", (short)0x0035, (short)0, "arrayref, index → value\nload short from array"),
	new ByteCodeInstruction("sastore", (short)0x0056, (short)0, "arrayref, index, value →\nstore short to array"),
	new ByteCodeInstruction("sipush", (short)0x0011, (short)2, "→ value\npush a short onto the stack"), 
	new ByteCodeInstruction("swap", (short)0x005f, (short)0, "value2, value1 → value1, value2\nswaps two top words on the stack (note that value1 and value2 must not be double or long)"),		
	
	new ByteCodeInstruction("tableswitch", (short)0x00aa, (short)4, "index →\ncontinue execution from an address in the table at offset index"),
	new ByteCodeInstruction("wide", (short)0x00c4, (short)3, "[same as for corresponding instructions]\nexecute opcode, where opcode is either iload, fload, aload, lstore, dload, lstore, fstore, astore, lstore, dstore, or ret, but assume the index is 16 bit; or execute iinc, where the index is 16 bits and the constant to increment by is a signed 16 bit short")
	
}; // ByteCodeInstruction[] instructionSet

}
