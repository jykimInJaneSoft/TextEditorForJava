package com.gsoft.common.compiler.bytecode;

import com.gsoft.common.compiler.CodeStringEx;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.Compiler_types.FindFuncCallParam;
import com.gsoft.common.compiler.Compiler_types.FindVarUseParams;
import com.gsoft.common.compiler.HighArray_CodeString;
import com.gsoft.common.compiler.TypeCast_Syntax;

import com.gsoft.common.compiler.bytecode.ByteCodeGeneratorForClass;
import com.gsoft.common.compiler.bytecode.HighArrayCharForByteCode;
import com.gsoft.common.compiler.bytecode.TypeDescriptor;
import com.gsoft.common.compiler.bytecode.ByteCode_Helper;

public class TypeCast {
	/** 스택에서 사용되므로 byte, short, char 타입은 int로서 다뤄진다.
	 * byte-int, byte-char, short-int, 등 간은 스택에서 다뤄지므로 무시할 수 있다. 
	 * int-long, int-float, int-double, long-float 등 간은 무시해서는 안 된다.
	 * @param token : token.typeFullNameAfterOperation이 null이 아닌 token
	 * @return : token.typeFullNameAfterOperation을 무시할수있으면 true, 
	 * 그렇지 않으면(int-long, int-float의 경우처럼) false
	 */
	public static boolean abortsTypeFullNameAfterOperation(CodeStringEx token) {
		// 스택에서 사용되므로 byte, short, char 타입은 int로서 다뤄진다.
		String oldType = token.typeFullName;
		String curType = token.typeFullNameAfterOperation;
		return abortsTypeFullNameAfterOperation(oldType, curType);
	}
	
	/** 스택에서 사용되므로 byte, short, char 타입은 int로서 다뤄진다.
	 * byte-int, byte-char, short-int, 등 간은 스택에서 다뤄지므로 무시할 수 있다. 
	 * int-long, int-float, int-double, long-float 등 간은 무시해서는 안 된다.
	 * @param token : token.typeFullNameAfterOperation이 null이 아닌 token
	 * @return : token.typeFullNameAfterOperation을 무시할수있으면 true, 
	 * 그렇지 않으면(int-long, int-float의 경우처럼) false
	 */
	public static boolean abortsTypeFullNameAfterOperation(String oldType, String curType) {
		// 스택에서 사용되므로 byte, short, char 타입은 int로서 다뤄진다.
		if (oldType==null || curType==null) return true;
		if (oldType.equals("byte") || oldType.equals("short") || oldType.equals("char")) {
			oldType = "int";
		}
		if (curType.equals("byte") || curType.equals("short") || curType.equals("char")) {
			curType = "int";
		}
		// int-long, int-float는 무시해서는 안 된다.
		if (!oldType.equals(curType)) return false;
		
		return true;
	}
	
	
	
	
	/** 명시적 수식 타입캐스트를 해결한다. <br>
	 * (타입)(수식)와 같은 수식 타입캐스트를 출력한다. <br>
	 * (타입)varUse와 같은 비수식 타입캐스트는 printVarConstantOrTypecast()에서 출력한다.<br>
	 * 수식 타입캐스트는 affectsExpression이 true이고 funcCall은 null이 아니다.
	 * 비수식 타입캐스트는 affectsExpression이 false이고 funcCall은 null이다.
	 * @param coreThreadID */
	public static void traverseTypeCast(ByteCodeGeneratorForClass generator, HighArray_CodeString src, FindVarUseParams varUse, int indexInmBuffer, HighArrayCharForByteCode result, int coreThreadID) {
		FindFuncCallParam funcCallParam = varUse.typeCast.funcCall;
		
		if (varUse.index()==26184) {
		}
		
		if (funcCallParam.expression!=null) {
			if (funcCallParam.expression.postfix!=null) {					
				
				// 수식트리에서 상위 노드의 포스트픽스
				// f2(1+2) 3 +
				
				// 1 2 +
				// 수식트리에서 자식노드들을 방문하기위해 재귀적호출
				generator.traverseChild(funcCallParam, result, coreThreadID);
				
			}//if (funcCallParam.expression.postfix!=null) {
			
		} //if (funcCallParam.expression!=null) {
		// 타입 캐스트 varUse 출력
		
		// int i = (int)(f + 2); 에서 타입캐스트 int 가 varUse
		// 이런 경우 f+2를 처리한 뒤에 타입캐스트 int 를 처리한다.
		//if (varUse.typeCast.affectsExpression) {
		if (varUse.typeCast.funcCall!=null) {
			printTypeCast(generator, funcCallParam.typeFullNameBeforeTypeCast, 
					varUse.typeCast.name, result, varUse.index(), coreThreadID);
			
		}
	}
	
	/** 타입캐스트를 출력한다.
	 * varUseTypeCast 가 null인 경우에는 oldType, curType으로 타입캐스트를 출력하고,
	 * varUseTypeCast 가 null이 아니면 oldType, varUseTypeCast 으로 타입캐스트를 출력한다.
	 * @param coreThreadID */
	/*public static void printTypeCast(ByteCodeGeneratorForClass generator, FindVarUseParams varUseTypeCast, String oldType, String curType, HighArrayCharForByteCode result, int mBufferIndex, int coreThreadID) {
		if (varUseTypeCast.typeCast!=null) {
			// 수식 타입캐스트, (int)(f+2)
			if (CompilerHelper.IsDefaultType(varUseTypeCast.typeCast.name) && 
					CompilerHelper.IsDefaultType(oldType)) {
				// 둘다 디폴트 타입이면
				printTypeCast_sub(generator, varUseTypeCast, oldType, curType, result, mBufferIndex, coreThreadID);
			}
			else {
				if (!CompilerHelper.IsDefaultType(varUseTypeCast.typeCast.name) &&
						!CompilerHelper.IsDefaultType(oldType)) {
					// 둘다 object이면
					//result.add("checkcast " +varUse.typeCast.name+"\n");
					printTypeCast_sub(generator, varUseTypeCast, oldType, varUseTypeCast.typeCast.name, result, mBufferIndex, coreThreadID);
				}
				else {
				
				} 
			}
		}
	}*/
	
	
	
	
	/**수식을 연산할때 operand나 operator(수식의 임시연산결과)가 묵시적 타입캐스트가 되는 것을 출력한다.
	 * 명시적 타입캐스트도 출력한다. 실제적으로 타입캐스트를 바이트코드로 변환한다. 
	 * checkcast는 타입캐스트가 object일 경우,
	 * varUseTypeCast 가 null인 경우에는 oldType, curType으로 타입캐스트를 출력하고,
	 * varUseTypeCast 가 null이 아니면 oldType, varUseTypeCast 으로 타입캐스트를 출력한다.
	 * <br>
	 * 수식을 연산할때 operand나 operator(수식의 임시연산결과)가 묵시적 타입캐스트가 되는 것을 출력한다.
	 * 명시적 타입캐스트도 출력한다. 실제적으로 타입캐스트를 바이트코드로 변환한다. 
	 * checkcast는 타입캐스트가 object일 경우 
	 * 둘 다 디폴트타입일 경우에만 가능하다.
	 * @param coreThreadID */
	public static void printTypeCast(ByteCodeGeneratorForClass generator, String oldType, String curType, HighArrayCharForByteCode result, int mBufferIndex, int coreThreadID) {
		if (oldType==null || curType==null) return;
		if (oldType.equals(curType)) return;
		
		if (!CompilerHelper.IsDefaultType(oldType) && 
				!CompilerHelper.IsDefaultType(curType)) {
			// 둘다 오브젝트이면				
			if (!CompilerHelper.IsDefaultType(oldType) && 
					!CompilerHelper.IsDefaultType(curType)) {
				if (!TypeCast_Syntax.isCompatibleType(generator.compiler, generator.compiler, 
						new CodeStringEx(curType), new CodeStringEx(oldType), 2, null, coreThreadID)) {
					String typeDesc = TypeDescriptor.getDescriptorExceptLAndSemicolon(curType, coreThreadID);
					generator.physical.makeCONSTANT_Class_infoAndPutItIntolistOfConstantTable_ExceptLAndSemicolon(typeDesc);
					result.add("checkcast // " +typeDesc+ByteCode_Helper.getSourceLineNumber(generator.compiler, mBufferIndex)+"\n");
				}
			}
		}// 둘다 오브젝트이면
		else {
			// 둘다 디폴트 타입이면
			
			// 스택에서 사용되므로 byte, short, char 타입은 int로서 다뤄진다.
			if (oldType.equals("byte") || oldType.equals("short") || oldType.equals("char")) {
				oldType = "int";
			}
			
			String strmBufferIndex = ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(result.compiler, mBufferIndex);
			
			if (oldType.equals("int")) {
				if (curType.equals("byte")) {
					result.add("i2b // "+strmBufferIndex+"\n");
				}
				else if (curType.equals("char")) {
					result.add("i2c // "+strmBufferIndex+"\n");
				}
				else if (curType.equals("short")) {
					result.add("i2s // "+strmBufferIndex+"\n");
				}
				else if (curType.equals("long")) {
					result.add("i2l // "+strmBufferIndex+"\n");
				}
				else if (curType.equals("float")) {
					result.add("i2f // "+strmBufferIndex+"\n");
				}
				else if (curType.equals("double")) {
					result.add("i2d // "+strmBufferIndex+"\n");
				}
			}
			else if (oldType.equals("long")) {
				if (curType.equals("byte")) {
					result.add("l2i // "+strmBufferIndex+"\n");
					result.add("i2b // "+strmBufferIndex+"\n");
				}
				else if (curType.equals("short")) {
					result.add("l2i // "+strmBufferIndex+"\n");
					result.add("i2s // "+strmBufferIndex+"\n");
				}
				else if (curType.equals("char")) {
					result.add("l2i // "+strmBufferIndex+"\n");
					result.add("i2c // "+strmBufferIndex+"\n");
				}
				else if (curType.equals("int")) {
					result.add("l2i // "+strmBufferIndex+"\n");
				}
				else if (curType.equals("float")) {
					result.add("l2f // "+strmBufferIndex+"\n");
				}
				else if (curType.equals("double")) {
					result.add("l2d // "+strmBufferIndex+"\n");
				}
			}
			else if (oldType.equals("float")) {
				if (curType.equals("byte")) {
					result.add("f2i // "+strmBufferIndex+"\n");
					result.add("i2b // "+strmBufferIndex+"\n");
				}
				else if (curType.equals("short")) {
					result.add("f2i // "+strmBufferIndex+"\n");
					result.add("i2s // "+strmBufferIndex+"\n");
				}
				else if (curType.equals("char")) {
					result.add("f2i // "+strmBufferIndex+"\n");
					result.add("i2c // "+strmBufferIndex+"\n");
				}
				else if (curType.equals("int")) {
					result.add("f2i // "+strmBufferIndex+"\n");
				}
				else if (curType.equals("long")) {
					result.add("f2l // "+strmBufferIndex+"\n");
				}
				else if (curType.equals("double")) {
					result.add("f2d // "+strmBufferIndex+"\n");
				}
			}
			else if (oldType.equals("double")) {
				if (curType.equals("byte")) {
					result.add("d2i // "+strmBufferIndex+"\n");
					result.add("i2b // "+strmBufferIndex+"\n");
				}
				else if (curType.equals("short")) {
					result.add("d2i // "+strmBufferIndex+"\n");
					result.add("i2s // "+strmBufferIndex+"\n");
				}
				else if (curType.equals("char")) {
					result.add("d2i // "+strmBufferIndex+"\n");
					result.add("i2c // "+strmBufferIndex+"\n");
				}
				else if (curType.equals("int")) {
					result.add("d2i // "+strmBufferIndex+"\n");
				}
				else if (curType.equals("long")) {
					result.add("d2l // "+strmBufferIndex+"\n");
				}
				else if (curType.equals("float")) {
					result.add("d2f // "+strmBufferIndex+"\n");
				}
			}// else if (oldType.equals("double")) {
		}// 둘다 디폴트 타입이면
	}
	
	
	
}
