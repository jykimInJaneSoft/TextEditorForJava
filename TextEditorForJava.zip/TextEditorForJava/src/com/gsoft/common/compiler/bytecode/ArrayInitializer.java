package com.gsoft.common.compiler.bytecode;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.compiler.Array;
import com.gsoft.common.compiler.Checker;
import com.gsoft.common.compiler.CodeStringEx;
import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.CompilerStatic;
import com.gsoft.common.compiler.Expression;
import com.gsoft.common.compiler.TypeCast_Syntax;
import com.gsoft.common.compiler.Compiler_types_Base.Error;
import com.gsoft.common.compiler.Compiler_types_Base.FindStatementParams;
import com.gsoft.common.compiler.Compiler_types.FindAssignStatementParams;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.Compiler_types.FindFuncCallParam;
import com.gsoft.common.compiler.Compiler_types.FindFunctionParams;
import com.gsoft.common.compiler.Compiler_types.FindVarParams;
import com.gsoft.common.compiler.Compiler_types.FindVarUseParams;
import com.gsoft.common.compiler.Compiler_types_Special.FindArrayInitializerParams;
import com.gsoft.common.compiler.HighArray_CodeString;
import com.gsoft.common.compiler.Number;
import com.gsoft.common.compiler.bytecode.ByteCode_Types.HashItemOfConstantTable;
import com.gsoft.common.util.ArrayListIReset;
import com.gsoft.common.util.ArrayListInt;

import com.gsoft.common.compiler.bytecode.ByteCode_Physical;
import com.gsoft.common.compiler.bytecode.ByteCodeGeneratorForClass;
import com.gsoft.common.compiler.bytecode.HighArrayCharForByteCode;
import com.gsoft.common.compiler.bytecode.ByteCode_Helper;
import com.gsoft.common.compiler.bytecode.TypeDescriptor;
import com.gsoft.common.compiler.bytecode.LocalVar;
import com.gsoft.common.compiler.bytecode.TypeCast;

@SuppressWarnings("unused")
public class ArrayInitializer {
	
	/** 현재 varUse가 배열초기화문의 변수가 아니면 false를 리턴한다.*/
	public static int isArrayInitializer(Compiler compiler,  FindVarUseParams varUse) {
		HighArray_CodeString src = compiler.data.mBuffer;
		int indexEqual = CompilerHelper.SkipBlank(src, false, varUse.index()+1, src.count-1);           
        if (indexEqual==src.count) return -1;        
        CodeString equal = src.getItem(indexEqual);
        if (!equal.equals("=")) return -1;
        
        int indexLeftPair = CompilerHelper.SkipBlank(src, false, indexEqual+1, src.count-1);
        if (indexLeftPair==src.count) return -1;
        CodeString leftPair = src.getItem(indexLeftPair);
        
        if (leftPair.equals("{")) {
        	int rightPair = Checker.CheckParenthesis(compiler, "{", "}", indexLeftPair, src.count-1, false);
        	return rightPair;
        }
        return -1;
        
	}
	
	
	public static void traverseArrayIntializer2_sub(ByteCodeGeneratorForClass generator, HighArray_CodeString src, FindArrayInitializerParams topArray, 
			FindArrayInitializerParams array, HighArrayCharForByteCode result, ArrayListInt listOfIndex, int coreThreadID) {
		if (array.listOfFindArrayInitializerParams.count>0) { // 중첩된 배열
			int i;
			//generator.printArrayInitializer_newarray_NoBottom(
			//		CompilerHelper.getMaxArrayLengthInCurDepth(topArray, array), 
			//		array.depth, topArray.varUse, result);
			
			for (i=0; i<array.listOfFindArrayInitializerParams.count; i++) {
				//result.add("dup"+"\n");
				//printArrayInitializer_index(i, array.listOfFindFuncCallParam.count, 
				//		array.depth, topArray.varUse, result);
				
				if (i==1) {
				}
				
				
				FindArrayInitializerParams child = (FindArrayInitializerParams) array.listOfFindArrayInitializerParams.getItem(i);
				listOfIndex.list[array.depth] = i;
				traverseArrayIntializer2_sub(generator, src, topArray, child, result, listOfIndex, coreThreadID);
				
				//printArrayInitializer_store_NoBottom(result);
				
				//printArrayInitializer_inc(CompilerHelper.getMaxArrayLengthInCurDepth(topArray, array), 
				//		topArray, array, result);
			}//for (i=0; i<array.listOfFindArrayInitializerParams.count; i++) {
		}
		else { // 수식, 가장 하위 노드
			// 최하위차원
			
		//	generator.printArrayInitializer_newarray_bottom(
		//			CompilerHelper.getMaxArrayLengthInCurDepth(topArray, array), 
		//			array.depth, topArray.varUse,
		//			CompilerHelper.getArrayElementType(topArray.typeFullName), result);
			
			int i;
			for (i=0; i<array.listOfFindFuncCallParam.count; i++) {
				if (i==6) {
					int a;
					a=0;
					a++;
				}
				result.add("dup"+"\n");
				/*try {
					printArrayInitializer_index(i, CompilerHelper.getMaxArrayLengthInCurDepth(topArray, array),
							array.depth, topArray.varUse, result);
				}catch(Exception e) {
					if (Common_Settings.g_printsLog) e.printStackTrace();
				}*/
				
				FindFuncCallParam funcCallParam = (FindFuncCallParam) array.listOfFindFuncCallParam.getItem(i);
				
				// 현재 인덱스를 계산한다. 2면2행3열에서 (1,1,1)의 경우 1*2*3+1*3+1이 된다.
				int index = getIndex_ArrayInitializer(listOfIndex, i, topArray);
				generator.printSmallIntegerNumber(index, result, funcCallParam.startIndex());
				
				
				if (funcCallParam.startIndex()==256) {
				}
								
				if (funcCallParam.expression.postfix!=null) {					
					
					// 수식트리에서 상위 노드의 포스트픽스
					// f2(1+2) 3 +
					
					// 1 2 +
					// 수식트리에서 자식노드들을 방문하기위해 재귀적호출
					
					generator.traverseChild(funcCallParam, result, coreThreadID);
					
					
					printArrayInitializer_store_bottom(generator, funcCallParam, result, topArray, coreThreadID);
					
					//printArrayInitializer_inc(CompilerHelper.getMaxArrayLengthInCurDepth(topArray, array), 
					//		topArray, array, result);
					
				}//if (funcCallParam.expression.postfix!=null) {				
				
			}//for (i=0; i<array.listOfFindFuncCallParam.count; i++) {
			
			
		}// else
	}
	
	
	/**int[][][] colors2 = {<br>
	{//a0<br>
		{Color.BLACK, Color.WHITE, Color.RED}, //a00<br>
		{Color.YELLOW,Color.BLUE, Color.GREEN} //a01<br>
	},
	 
	{//a1<br>
		{Color.BLACK, Color.WHITE, Color.RED}, //a10<br>
	    {Color.YELLOW,Color.BLUE, Color.GREEN} //a11<br>
	}
	};//2면 2행 3열<br>
	 * @param coreThreadID 
	*/
	public static void traverseArrayIntializer2(ByteCodeGeneratorForClass generator, HighArray_CodeString src, FindArrayInitializerParams topArray, 
			FindArrayInitializerParams array, HighArrayCharForByteCode result, int coreThreadID) {
		FindVarUseParams varUse = topArray.varUse;
		ArrayListInt listOfIndex = new ArrayListInt(varUse.arrayInitializer.dimension);
		int k;
		for (k=0; k<varUse.arrayInitializer.dimension; k++) {
			listOfIndex.add(0);
		}
		int arrayLength=1;
		ArrayListInt listOfLength = varUse.arrayInitializer.listOfLength;
		for (k=0; k<listOfLength.count; k++) {
			arrayLength *= listOfLength.getItem(k);
		}
		printArrayInitializer_newarray_bottom(
				generator, arrayLength, 0, varUse,
				Array.getArrayElementType(varUse.arrayInitializer.typeFullName), result, topArray.indexOfLeftParenthesis(), coreThreadID);
		
		traverseArrayIntializer2_sub(generator, src, topArray, array, result, listOfIndex, coreThreadID);
	}
	
	/** 2면3행4열에서 (1,2,3)의 경우 1*3*4 + 3*4 + 3이 된다.
	 * @param listOfIndex : 상위차원들의 인덱스 리스트, 위 예에서 1, 2, 0이 된다.
	 * @param index : 마지막 차원에서 인덱스, 위 예에서 마지막 3이 된다.*/
	public static int getIndex_ArrayInitializer(ArrayListInt listOfIndex, int index, FindArrayInitializerParams topArray) {
		int r=0;
		ArrayListInt listOfLength = topArray.listOfLength;
		
		int i, j;
		for (i=0; i<listOfIndex.count; i++) {
			int curIndex = listOfIndex.getItem(i);
			int count=1;
			for (j=i+1; j<listOfLength.count; j++) {
				int curLength = listOfLength.getItem(j);
				count *= curLength;
			}
			
			r += curIndex * count;
		}
		r += index;
		return r;
	}
	
	
	
	
	/**int[][][] colors2 = {<br>
	{//a0<br>
		{Color.BLACK, Color.WHITE, Color.RED}, //a00<br>
		{Color.YELLOW,Color.BLUE, Color.GREEN} //a01<br>
	},
	 
	{//a1<br>
		{Color.BLACK, Color.WHITE, Color.RED}, //a10<br>
	    {Color.YELLOW,Color.BLUE, Color.GREEN} //a11<br>
	}
	};//2면 2행 3열<br>
	colors2->a0->a00->Color.BLACK, Color.WHITE, Color.RED <br>
		   ->a01->Color.YELLOW,Color.BLUE, Color.GREEN <br>
	->a1->a10->Color.BLACK, Color.WHITE, Color.RED <br>
	   ->a11->Color.YELLOW,Color.BLUE, Color.GREEN <br>
	깊이 :0    1    2
	 * @param coreThreadID */
	public static void traverseArrayIntializer(ByteCodeGeneratorForClass generator, HighArray_CodeString src, FindArrayInitializerParams topArray, 
			FindArrayInitializerParams array, HighArrayCharForByteCode result, int coreThreadID) {
		if (array.listOfFindArrayInitializerParams.count>0) { // 중첩된 배열
			int i;
			printArrayInitializer_newarray_NoBottom(
					generator, Array.getMaxArrayLengthInCurDepth(topArray, array), 
					array.depth, topArray.varUse, result, array.indexOfLeftParenthesis(), coreThreadID);
			
			for (i=0; i<array.listOfFindArrayInitializerParams.count; i++) {
				FindArrayInitializerParams child = (FindArrayInitializerParams) array.listOfFindArrayInitializerParams.getItem(i);
				int mBufferIndexForSrcIndex = child.indexOfLeftParenthesis();
				String strSrcIndex = ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(generator.compiler, mBufferIndexForSrcIndex);
				
				result.add("dup // "+strSrcIndex+"\n");
				try {
					printArrayInitializer_index(generator, i, array.depth, topArray.varUse, result, mBufferIndexForSrcIndex, coreThreadID);
				}catch(Exception e) {
					if (Common_Settings.g_printsLog) e.printStackTrace();
				}
				
				//FindArrayInitializerParams child = (FindArrayInitializerParams) array.listOfFindArrayInitializerParams.getItem(i);
				traverseArrayIntializer(generator, src, topArray, child, result, coreThreadID);
				
				printArrayInitializer_store_NoBottom(result, topArray.varUse, child.indexOfRightParenthesis());
				
				printArrayInitializer_inc(generator, Array.getMaxArrayLengthInCurDepth(topArray, array), 
						topArray, array, result, coreThreadID);
			}//for (i=0; i<array.listOfFindArrayInitializerParams.count; i++) {
		}
		else { // 수식, 가장 하위 노드
			// 최하위차원
			
			printArrayInitializer_newarray_bottom(
					generator, Array.getMaxArrayLengthInCurDepth(topArray, array), 
					array.depth, topArray.varUse,
					Array.getArrayElementType(topArray.typeFullName), result, array.indexOfLeftParenthesis(), coreThreadID);
			
			int i;			
			
			for (i=0; i<array.listOfFindFuncCallParam.count; i++) {
				if (i==6) {
					int a;
					a=0;
					a++;
				}
				FindFuncCallParam funcCallParam = (FindFuncCallParam) array.listOfFindFuncCallParam.getItem(i);
				
				int mBufferIndexForSrcIndex = funcCallParam.startIndex();
				String strmBufferIndex = ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(generator.compiler, mBufferIndexForSrcIndex);
				
				result.add("dup // "+strmBufferIndex+"\n");
				try {
					printArrayInitializer_index(generator, i, array.depth, topArray.varUse, result, mBufferIndexForSrcIndex, coreThreadID);
				}catch(Exception e) {
					if (Common_Settings.g_printsLog) e.printStackTrace();
				}
				
				
				if (funcCallParam.startIndex()==256) {
				}
								
				if (funcCallParam.expression.postfix!=null) {					
					
					// 수식트리에서 상위 노드의 포스트픽스
					// f2(1+2) 3 +
					
					// 1 2 +
					// 수식트리에서 자식노드들을 방문하기위해 재귀적호출
					
					generator.traverseChild(funcCallParam, result, coreThreadID);
					
					
					printArrayInitializer_store_bottom(generator, funcCallParam, result, topArray, coreThreadID);
					
					printArrayInitializer_inc(generator, Array.getMaxArrayLengthInCurDepth(topArray, array), 
							topArray, array, result, coreThreadID);
					
				}//if (funcCallParam.expression.postfix!=null) {				
				
			}//for (i=0; i<array.listOfFindFuncCallParam.count; i++) {
			
			
		}// else
	
	}
	
	
	/** 배열초기화에서 topArray의 listOfLength를 확인하여 array length가 short범위를 넘어서면
	 * index와 array length를 위한 지역변수들을 만든다. 깊이별로 조직해야 하므로 어떤 깊이에서
	 * length가 short범위를 넘지 않으면 null을 넣는다. FindArrayInitializerParams를 참조한다.
	 * @param topArray : 최상위 array, lValue가 가르키는 array
	 */
	public static void makeLocalVarsForArrayInit(ByteCodeGeneratorForClass generator, FindArrayInitializerParams topArray) {
		Compiler compiler = generator.compiler;
		ArrayListInt listOfLength = topArray.listOfLength;
		int i;
		for (i=0; i<listOfLength.count; i++) {
			int length = listOfLength.getItem(i);
			int numberType = Number.IsNumber2(String.valueOf(length));
			if (numberType==3 || numberType==4) {
				FindVarParams var = new FindVarParams(compiler, "int", "___varForArrayInit_"+i);
				FindVarParams var2 = new FindVarParams(compiler, "int", "___varForArrayInit_arrayLength_"+i);
				var.isFake = true;
				var2.isFake = true;
				Object r = ByteCode_Helper.getFunctionOrClassToDefineLocalVarsForArrayInit(topArray.varUse);
				if (r instanceof FindClassParams) {
					FindClassParams classParams = (FindClassParams) r;
					//classParams.listOfLocalVarsForArrayInit.add(var);
					//classParams.listOfLocalVarsForArrayInit_arrayLength.add(var2);
					// 이미 가짜 지역변수가 등록되어있는지 확인한다.
					FindVarParams memberVar = classParams.getMemberVar(var);
					if (memberVar!=null) var = memberVar;
					else {
						// 등록이 안되어 있으면 등록한다.
						classParams.listOfVariableParams.add(var);
					}
					FindVarParams memberVar2 = classParams.getMemberVar(var2);
					if (memberVar2!=null) var2 = memberVar2;
					else {
						// 등록이 안되어 있으면 등록한다.
						classParams.listOfVariableParams.add(var2);
					}
					
				}
				else if (r instanceof FindFunctionParams) {
					FindFunctionParams func = (FindFunctionParams) r;
					//func.listOfLocalVarsForArrayInit.add(var);
					//func.listOfLocalVarsForArrayInit_arrayLength.add(var2);
					// 이미 가짜 지역변수가 등록되어있는지 확인한다.
					FindVarParams localVar = func.getLocalVar(var);
					if (localVar!=null) var = localVar;
					else {
						// 등록이 안되어 있으면 등록한다.
						func.listOfVariableParams.add(var);
					}
					FindVarParams localVar2 = func.getLocalVar(var2);
					if (localVar2!=null) var2 = localVar2;
					else {
						// 등록이 안되어 있으면 등록한다.
						func.listOfVariableParams.add(var2);
					}
				}
			}//if (numberType==3 || numberType==4) {
			else { // short 범위를 넘어서지 않으면
				/*Object r = generator.getFunctionOrClassToDefineLocalVarsForArrayInit(topArray.varUse);
				if (r instanceof FindClassParams) {
					FindClassParams classParams = (FindClassParams) r;
					classParams.listOfLocalVarsForArrayInit.add(null);
					classParams.listOfLocalVarsForArrayInit_arrayLength.add(null);
				}
				else if (r instanceof FindFunctionParams) {
					FindFunctionParams func = (FindFunctionParams) r;
					func.listOfLocalVarsForArrayInit.add(null);
					func.listOfLocalVarsForArrayInit_arrayLength.add(null);
				}*/
			}
		}//for (i=0; i<listOfLength.count; i++) {
	}
	
	
	public static void printArrayInitializer_newarray_NoBottom(ByteCodeGeneratorForClass generator, int arrayLength, 
			int depth, FindVarUseParams varUse, HighArrayCharForByteCode result, int indexOfLeftPairInmBuffer, int coreThreadID) {
		ByteCode_Physical physical = generator.physical;
		// array length print
		printArrayLength(arrayLength, depth, varUse, indexOfLeftPairInmBuffer, result);
		
		int dimension = varUse.arrayInitializer.dimension;
		int dimensionToPrint = dimension - (depth+1);
		String arrDesc = "";
		int i;
		for (i=0; i<dimensionToPrint; i++) {
			arrDesc += "[";
		}
		String elementTypeDesc = 
			TypeDescriptor.getDescriptorExceptLAndSemicolon(Array.getArrayElementType(varUse.arrayInitializer.typeFullName), coreThreadID);
		String typeDesc = arrDesc + elementTypeDesc;
				
		generator.physical.makeCONSTANT_Class_infoAndPutItIntolistOfConstantTable_ExceptLAndSemicolon(typeDesc);
		String strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, indexOfLeftPairInmBuffer);
		result.add("anewarray // "+typeDesc+strmBufferIndex+"\n");
	}
	
	
	public static void printArrayLength(int arrayLength, int depth, FindVarUseParams varUse, 
			int indexOfLeftPairInmBuffer, HighArrayCharForByteCode result) {
		int numberType = Number.IsNumber2(String.valueOf(arrayLength));
		
		String strmBufferIndex = ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(result.compiler, indexOfLeftPairInmBuffer);
		
		if (arrayLength<6) {
			switch (arrayLength) {
			case 0:	result.add("iconst_0 // "+strmBufferIndex+"\n"); break;
			case 1:	result.add("iconst_1 // "+strmBufferIndex+"\n"); break;
			case 2:	result.add("iconst_2 // "+strmBufferIndex+"\n"); break;
			case 3:	result.add("iconst_3 // "+strmBufferIndex+"\n"); break;
			case 4:	result.add("iconst_4 // "+strmBufferIndex+"\n"); break;
			case 5:	result.add("iconst_5 // "+strmBufferIndex+"\n"); break;
			}
			//result.add("iconst "+arrayLength+"\n");
			return;
		}
		if (numberType==7) {
			result.add("bipush "+arrayLength+" // "+strmBufferIndex+"\n");
		}
		else if (numberType==1 || numberType==2) {
			result.add("sipush "+arrayLength+" // "+strmBufferIndex+"\n");
		}
		else if (numberType==3) { // 배열초기화를 위한 임시 지역변수 
			FindVarParams var = getLocalVarForArrayInit_arrayLength(depth, varUse);
			result.add("iload "+var.toString()+" // "+strmBufferIndex+"\n");
		}
		else if (numberType==4) {
		}
	}
	
	/** 배열초기화에서 newarray, anewarray가 사용되므로 배열타입을 constant table에 등록하기 위해
	 * 배열타입의 varUse를 찾아서 리턴한다.
	 * @param arr : 배열초기화문
	 * @return : 배열타입의 varUse이면 true, 그렇지 않으면 false
	 */
	public static boolean isVarUseOfTypeOfArrayInitializer(FindArrayInitializerParams arr, FindVarUseParams anyVarUse) {
		FindVarParams var = arr.varUse.varDecl;
		int index = anyVarUse.index();
		if (var.typeStartIndex()<=index && index<=var.typeEndIndex()) return true;
		return false;
	}
	
	/** 배열초기화에서 newarray, anewarray가 사용되므로 배열타입을 constant table에 등록하기 위해
	 * 배열타입의 varUse를 찾아서 리턴한다.
	 * @param varUse : 배열초기화의 lValue
	 * @return : 배열타입의 varUse
	 */
	public static FindVarUseParams getVarUseOfTypeOfArrayInitializer(ByteCodeGeneratorForClass generator, FindVarUseParams varUse) {
		Compiler compiler = generator.compiler;
		int i;
		for (i=0; i<compiler.data.mlistOfAllArrayIntializers.count; i++) {
			FindArrayInitializerParams arr = (FindArrayInitializerParams) compiler.data.mlistOfAllArrayIntializers.getItem(i);
			if (arr.varUse==varUse) {
				String elementTypeName = Array.getArrayElementType(arr.typeFullName);
				FindVarParams var = arr.varUse.varDecl;
				int typeIndex = CompilerHelper.SkipBlank(compiler.data.mBuffer, true, 0, var.typeEndIndex());
				int j;
				for (j=typeIndex; j>=0; j--) {
					int index = CompilerHelper.SkipBlank(compiler.data.mBuffer, true, 0, j);
					CodeString str = compiler.data.mBuffer.getItem(index);
					if (str.equals("]")) {
						index = Checker.CheckParenthesis(compiler,  "[", "]", 0, index, true);
						j = index;
					}
					else if (str.equals(">")) {
						index = Checker.CheckParenthesis(compiler,  "<", ">", 0, index, true);
						j = index;
					} 
					else break;
				}
				FindVarUseParams r = 
					Compiler.getVarUseWithIndex(compiler.data.mlistOfAllVarUsesHashed, elementTypeName, j);
				if (r!=null) return r;
			}
		}
		return null;
	}
	
	public static void printArrayInitializer_newarray_bottom(ByteCodeGeneratorForClass generator, int arrayLength, int depth, FindVarUseParams varUse, String typeName, 
			HighArrayCharForByteCode result, int indexOfLeftPairInmBuffer, int coreThreadID) {
		ByteCode_Physical physical = generator.physical;
		// array length 출력
		printArrayLength(arrayLength, depth, varUse, indexOfLeftPairInmBuffer, result);
				
		String desc = TypeDescriptor.getDescriptorExceptLAndSemicolon(typeName, coreThreadID);
		
		String strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, indexOfLeftPairInmBuffer);
		
		if (CompilerHelper.IsDefaultType(typeName)) {			
			result.add("newarray // "+desc+", "+ByteCode_Helper.getAType(desc)+strmBufferIndex+"\n");
		}
		else {
			physical.makeCONSTANT_Class_infoAndPutItIntolistOfConstantTable_ExceptLAndSemicolon(desc);
			
			result.add("anewarray // "+desc+strmBufferIndex+"\n");
		}
	}
	
	
	/**배열초기화에서 short범위를 넘어서는 인덱스를 위한 지역변수를 얻어온다.
	 * makeLocalVarsForArrayInit를 참조한다. 
	 * @param varUse : 배열초기화문의 lValue*/
	public static FindVarParams getLocalVarForArrayInit(int depth, FindVarUseParams varUse) {
		Object r = ByteCode_Helper.getFunctionOrClassToDefineLocalVarsForArrayInit(varUse);
		if (r==null) return null;
		if (r instanceof FindClassParams) {
			FindClassParams c = (FindClassParams) r;
			//FindVarParams var = (FindVarParams) c.listOfLocalVarsForArrayInit.getItem(depth);
			boolean isStatic = varUse.varDecl.accessModifier.isStatic;
			int indexOfLocalVariableTable = 0;
			if (isStatic) {
				
			}
			else {
				indexOfLocalVariableTable++;
			}
			int i;
			for (i=0; i<c.listOfVariableParams.count; i++) {
				FindVarParams var = (FindVarParams) c.listOfVariableParams.getItem(i);
				var.indexOfLocalVariableTable = indexOfLocalVariableTable;
				if (var.fieldName.equals("___varForArrayInit_"+depth))
					return var;
				if (var.typeName.equals("long") || var.typeName.equals("double")) {
					indexOfLocalVariableTable += 2;
				}
				else {
					indexOfLocalVariableTable++;
				}
			}
			return null;
		}
		else if (r instanceof FindFunctionParams) {
			FindFunctionParams func = (FindFunctionParams) r;
			boolean isStatic = func.accessModifier.isStatic;
			int indexOfLocalVariableTable = 0;
			if (isStatic) {
				
			}
			else {
				indexOfLocalVariableTable++;
			}
			int i;
			for (i=0; i<func.listOfVariableParams.count; i++) {
				FindVarParams var = (FindVarParams) func.listOfVariableParams.getItem(i);
				var.indexOfLocalVariableTable = indexOfLocalVariableTable;
				if (var.fieldName.equals("___varForArrayInit_"+depth))
					return var;
				if (var.typeName.equals("long") || var.typeName.equals("double")) {
					indexOfLocalVariableTable += 2;
				}
				else {
					indexOfLocalVariableTable++;
				}
			}
			return null;
		}
		return null;
	}
	
	/**배열초기화에서 short범위를 넘어서는 array length를 위한 지역변수를 얻어온다.
	 * makeLocalVarsForArrayInit를 참조한다.  
	 * @param varUse : 배열초기화문의 lValue*/
	public static FindVarParams getLocalVarForArrayInit_arrayLength(int depth, FindVarUseParams varUse) {
		Object r = ByteCode_Helper.getFunctionOrClassToDefineLocalVarsForArrayInit(varUse);
		if (r==null) return null;
		if (r instanceof FindClassParams) {
			FindClassParams c = (FindClassParams) r;
			boolean isStatic = varUse.varDecl.accessModifier.isStatic;
			int indexOfLocalVariableTable = 0;
			if (isStatic) {
				
			}
			else {
				indexOfLocalVariableTable++;
			}
			int i;
			for (i=0; i<c.listOfVariableParams.count; i++) {
				FindVarParams var = (FindVarParams) c.listOfVariableParams.getItem(i);
				var.indexOfLocalVariableTable = indexOfLocalVariableTable;
				if (var.fieldName.equals("___varForArrayInit_arrayLength_"+depth))
					return var;
				if (var.typeName.equals("long") || var.typeName.equals("double")) {
					indexOfLocalVariableTable += 2;
				}
				else {
					indexOfLocalVariableTable++;
				}
			}
			return null;
		}
		else if (r instanceof FindFunctionParams) {
			FindFunctionParams func = (FindFunctionParams) r;
			boolean isStatic = func.accessModifier.isStatic;
			int indexOfLocalVariableTable = 0;
			if (isStatic) {
				
			}
			else {
				indexOfLocalVariableTable++;
			}
			int i;
			for (i=0; i<func.listOfVariableParams.count; i++) {
				FindVarParams var = (FindVarParams) func.listOfVariableParams.getItem(i);
				var.indexOfLocalVariableTable = indexOfLocalVariableTable;
				if (var.fieldName.equals("___varForArrayInit_arrayLength_"+depth))
					return var;
				if (var.typeName.equals("long") || var.typeName.equals("double")) {
					indexOfLocalVariableTable += 2;
				}
				else {
					indexOfLocalVariableTable++;
				}
			}
			return null;
		}
		return null;
	}
	
	/** @param varUse : 배열초기화문의 lValue
	 * @param coreThreadID */
	public static void printArrayInitializer_index(ByteCodeGeneratorForClass generator, int index, int depth, FindVarUseParams varUse, 
			HighArrayCharForByteCode result, int mBufferIndexForSrcIndex, int coreThreadID){
		int numberType = Number.IsNumber2(String.valueOf(index));
		if (numberType==0) {
			
		}
		else if (numberType==3) { // 배열초기화를 위한 임시 지역변수 
			int localVarTableIndex = LocalVar.getLocalVarTableIndex(generator, varUse.funcToDefineThisVarUse, varUse.varDecl);
			// iload0-iload3 까지 밖에 없지만 임시로 iload_index를 붙여 놓고 
			// HighArrayCharForByteCode.createConstantTableIndex()에서
			// iload0-iload3 까지는 그대로 놔두고 iload index 으로 분리한다.	
			FindVarParams var = getLocalVarForArrayInit(depth, varUse);
			String strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, mBufferIndexForSrcIndex);
			result.add("iload_"+localVarTableIndex+" // local "+var.getVarStr(coreThreadID)+strmBufferIndex+"\n");
		}
		else if (numberType==4) {
		}
		else { // byte, char, short
			generator.printSmallIntegerNumber(index, result, mBufferIndexForSrcIndex);
		}
	}
	
	/** maxIndex에 따라서 출력을 결정한다. 
	 * maxIndex가 255 이하(bipush), 64000(sipush)이면 출력을 안하고 
	 * 그 이상이면 iinc를 출력한다. integer범위를 넘어서면 ladd를 사용한다.
	 * @param maxIndex
	 * @param topArray
	 * @param curArray
	 * @param result
	 * @param coreThreadID 
	 */
	public static void printArrayInitializer_inc(ByteCodeGeneratorForClass generator, int maxIndex, FindArrayInitializerParams topArray, 
			FindArrayInitializerParams curArray, HighArrayCharForByteCode result, int coreThreadID) {
		int numberType = Number.IsNumber2(String.valueOf(maxIndex));
		String strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, curArray.startIndex());
		if (numberType==3) { // 배열초기화를 위한 임시 지역변수
			FindVarParams var = getLocalVarForArrayInit(curArray.depth, topArray.varUse);
			int index = LocalVar.getLocalVarTableIndex(generator, (FindFunctionParams)var.parent, var);
			result.add("iinc "+index+" 1 // local "+var.getVarStr(coreThreadID)+strmBufferIndex+"\n");
			//result.add("iinc "+var+"\n");
		}
		else if (numberType==4) {
			// ladd를 사용해야 한다.
			
		}
	}
	
	public static void printArrayInitializer_store_NoBottom(HighArrayCharForByteCode result, 
			FindVarUseParams varUse, int indexRightPair) {
		String strmBufferIndex = ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(result.compiler, indexRightPair);
		result.add("aastore // "+strmBufferIndex+"\n");
	}
	
	public static void printArrayInitializer_store_bottom(ByteCodeGeneratorForClass generator, FindFuncCallParam funcCall, 
			HighArrayCharForByteCode result, FindArrayInitializerParams topArray, int coreThreadID) {
		if (funcCall.typeFullName==null) {			
			return;
		}
		String elementTypeNameOfArray = Array.getArrayElementType(topArray.typeFullName);
		String elementTypeName = funcCall.typeFullName.str;
		
		String strmBufferIndex = ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(generator.compiler, funcCall.endIndex());
		
		if (elementTypeName.equals("byte") || elementTypeName.equals("short") || 
				elementTypeName.equals("char") || elementTypeName.equals("int")) {
			if (elementTypeNameOfArray.equals("byte")) {
				TypeCast.printTypeCast(generator, "int", elementTypeNameOfArray, result, funcCall.startIndex(), coreThreadID);
				result.add("bastore // "+strmBufferIndex+"\n");
			}
			else if (elementTypeNameOfArray.equals("char")) {
				TypeCast.printTypeCast(generator, "int", elementTypeNameOfArray, result, funcCall.startIndex(), coreThreadID);
				result.add("castore // "+strmBufferIndex+"\n");
			}
			else if (elementTypeNameOfArray.equals("short")) {
				TypeCast.printTypeCast(generator, "int", elementTypeNameOfArray, result, funcCall.startIndex(), coreThreadID);
				result.add("sastore // "+strmBufferIndex+"\n");
			}
			else if (elementTypeNameOfArray.equals("int")) {
				result.add("iastore // "+strmBufferIndex+"\n");
			}
			else if (elementTypeNameOfArray.equals("long")) {
				TypeCast.printTypeCast(generator, "int", elementTypeNameOfArray, result, funcCall.startIndex(), coreThreadID);
				result.add("lastore // "+strmBufferIndex+"\n");
			}
			else if (elementTypeNameOfArray.equals("float")) {
				TypeCast.printTypeCast(generator, "int", elementTypeNameOfArray, result, funcCall.startIndex(), coreThreadID);
				result.add("fastore // "+strmBufferIndex+"\n");
			}
			else if (elementTypeNameOfArray.equals("double")) {
				TypeCast.printTypeCast(generator, "int", elementTypeNameOfArray, result, funcCall.startIndex(), coreThreadID);
				result.add("dastore // "+strmBufferIndex+"\n");
			}
			else {
				
			}
		}
		else if (elementTypeName.equals("long")) {
			if (elementTypeNameOfArray.equals("byte")) {
				TypeCast.printTypeCast(generator, "long", elementTypeNameOfArray, result, funcCall.startIndex(), coreThreadID);
				result.add("bastore // "+strmBufferIndex+"\n");
			}
			else if (elementTypeNameOfArray.equals("char")) {
				TypeCast.printTypeCast(generator, "long", elementTypeNameOfArray, result, funcCall.startIndex(), coreThreadID);
				result.add("castore // "+strmBufferIndex+"\n");
			}
			else if (elementTypeNameOfArray.equals("short")) {
				TypeCast.printTypeCast(generator, "long", elementTypeNameOfArray, result, funcCall.startIndex(), coreThreadID);
				result.add("sastore // "+strmBufferIndex+"\n");
			}
			else if (elementTypeNameOfArray.equals("int")) {
				TypeCast.printTypeCast(generator, "long", elementTypeNameOfArray, result, funcCall.startIndex(), coreThreadID);
				result.add("iastore // "+strmBufferIndex+"\n");
			}
			else if (elementTypeNameOfArray.equals("long")) {
				//generator.printTypeCast("long", elementTypeNameOfArray, result);
				result.add("lastore // "+strmBufferIndex+"\n");
			}
			else if (elementTypeNameOfArray.equals("float")) {
				TypeCast.printTypeCast(generator, "long", elementTypeNameOfArray, result, funcCall.startIndex(), coreThreadID);
				result.add("fastore // "+strmBufferIndex+"\n");
			}
			else if (elementTypeNameOfArray.equals("double")) {
				TypeCast.printTypeCast(generator, "long", elementTypeNameOfArray, result, funcCall.startIndex(), coreThreadID);
				result.add("dastore // "+strmBufferIndex+"\n");
			}
			else {
				
			}
		}
		else if (elementTypeName.equals("float")) {
			if (elementTypeNameOfArray.equals("byte")) {
				TypeCast.printTypeCast(generator, "float", elementTypeNameOfArray, result, funcCall.startIndex(), coreThreadID);
				result.add("bastore // "+strmBufferIndex+"\n");
			}
			else if (elementTypeNameOfArray.equals("char")) {
				TypeCast.printTypeCast(generator, "float", elementTypeNameOfArray, result, funcCall.startIndex(), coreThreadID);
				result.add("castore // "+strmBufferIndex+"\n");
			}
			else if (elementTypeNameOfArray.equals("short")) {
				TypeCast.printTypeCast(generator, "float", elementTypeNameOfArray, result, funcCall.startIndex(), coreThreadID);
				result.add("sastore // "+strmBufferIndex+"\n");
			}
			else if (elementTypeNameOfArray.equals("int")) {
				TypeCast.printTypeCast(generator, "float", elementTypeNameOfArray, result, funcCall.startIndex(), coreThreadID);
				result.add("iastore // "+strmBufferIndex+"\n");
			}
			else if (elementTypeNameOfArray.equals("long")) {
				TypeCast.printTypeCast(generator, "float", elementTypeNameOfArray, result, funcCall.startIndex(), coreThreadID);
				result.add("lastore // "+strmBufferIndex+"\n");
			}
			else if (elementTypeNameOfArray.equals("float")) {
				//generator.printTypeCast("float", elementTypeNameOfArray, result);
				result.add("fastore // "+strmBufferIndex+"\n");
			}
			else if (elementTypeNameOfArray.equals("double")) {
				TypeCast.printTypeCast(generator, "float", elementTypeNameOfArray, result, funcCall.startIndex(), coreThreadID);
				result.add("dastore // "+strmBufferIndex+"\n");
			}
			else {
				
			}
		}
		else if (elementTypeName.equals("double")) {
			if (elementTypeNameOfArray.equals("byte")) {
				TypeCast.printTypeCast(generator, "double", elementTypeNameOfArray, result, funcCall.startIndex(), coreThreadID);
				result.add("bastore // "+strmBufferIndex+"\n");
			}
			else if (elementTypeNameOfArray.equals("char")) {
				TypeCast.printTypeCast(generator, "double", elementTypeNameOfArray, result, funcCall.startIndex(), coreThreadID);
				result.add("castore // "+strmBufferIndex+"\n");
			}
			else if (elementTypeNameOfArray.equals("short")) {
				TypeCast.printTypeCast(generator, "double", elementTypeNameOfArray, result, funcCall.startIndex(), coreThreadID);
				result.add("sastore // "+strmBufferIndex+"\n");
			}
			else if (elementTypeNameOfArray.equals("int")) {
				TypeCast.printTypeCast(generator, "double", elementTypeNameOfArray, result, funcCall.startIndex(), coreThreadID);
				result.add("iastore // "+strmBufferIndex+"\n");
			}
			else if (elementTypeNameOfArray.equals("long")) {
				TypeCast.printTypeCast(generator, "double", elementTypeNameOfArray, result, funcCall.startIndex(), coreThreadID);
				result.add("lastore // "+strmBufferIndex+"\n");
			}
			else if (elementTypeNameOfArray.equals("float")) {
				TypeCast.printTypeCast(generator, "double", elementTypeNameOfArray, result, funcCall.startIndex(), coreThreadID);
				result.add("fastore // "+strmBufferIndex+"\n");
			}
			else if (elementTypeNameOfArray.equals("double")) {
				//generator.printTypeCast("double", elementTypeNameOfArray, result);
				result.add("dastore // "+strmBufferIndex+"\n");
			}
			else {
				
			}
		}
		else {
			result.add("aastore // "+strmBufferIndex+"\n");
		}
	}
	
	
	
	/** 처음 호출시에는 최상위 배열초기화문(FindArrayInitializerParams)이고, 
	 * 재귀적 호출시에는 원래 배열안의 중첩된 배열에 대해서 호출한다. 
	 * 배열초기화문의 차원수(dimension)와 원소 타입과 행과 열들의 길이(length)도 정해준다.<br>
	 * int[][] colors = {
    		{Color.BLACK, Color.WHITE, Color.RED}, 
    		{Color.YELLOW,Color.BLUE, Color.GREEN}
	}; <br>
	이 경우 2차원이고 2행 3열이다. 
	 * @param coreThreadID */
	public static void findTypesOfExpressionsOfArrayInitializer( Compiler compiler, FindAssignStatementParams assign, int coreThreadID) {
		HighArray_CodeString src = compiler.data.mBuffer;
		FindVarParams var = assign.lValue.varDecl;
		assign.arrayInitializer.varUse = assign.lValue;
		assign.arrayInitializer.typeFullName = var.typeName;
		int dimension = Array.getArrayDimension(compiler, var.typeName);
		// int[][] arr; 
		// arr[0] = {1,2,3};
		// dimension is 2. dimensionOfVarUse is 1.
		int dimensionOfVarUse = Array.getArrayDimension(compiler, assign.lValue.name);
		String arrayOriginalType = Array.getArrayElementType(var.typeName);
		
		getDimensionOfArrayInitializer( compiler, assign.arrayInitializer, assign.arrayInitializer);
		
		//assign.arrayInitializer.dimension = 0; // 여러번 호출될 경우를 대비해서 초기화해준다.		
		findTypesOfExpressionsOfArrayInitializer_sub( compiler, assign.arrayInitializer, assign.arrayInitializer, arrayOriginalType, coreThreadID);
		
		//assign.arrayInitializer.dimension = 0; // 여러번 호출될 경우를 대비해서 초기화해준다.
		//if (assign.arrayInitializer.listOfLength!=null) assign.arrayInitializer.listOfLength.reset2();
		//getDimensionAndLengthOfArrayInitializer(src, assign.arrayInitializer, assign.arrayInitializer);
		
		getLengthOfArrayInitializer( compiler, assign.arrayInitializer, assign.arrayInitializer);
		
		// int[][] arr; 
		// arr[0] = {1,2,3};
		// dimension - dimensionOfVarUse is 1. assign.arrayInitializer.dimension is 1.	
		if (dimension-dimensionOfVarUse!=assign.arrayInitializer.dimension) {
			CompilerStatic.errors.add(new Error(compiler, assign.lValue.index(), assign.lValue.index(), "invalid array dimension : "+dimension+"-"+assign.arrayInitializer.dimension));
		}
	}
	
	/** 배열초기화문의 길이를 정해준다.
	 * 트리의 모든 노드를 순회하면서 현재 배열의 길이가 최상위 노드에 있는 같은 깊이의 현재 길이보다 크면 바꿔주면서 
	 * 모든 깊이의 길이를 올바르게 정해준다.<br> 
	 * int[][][] colors2 = {<br>
    		{//a0<br>
	    		{Color.BLACK, Color.WHITE}, //a00<br>
	    		{Color.YELLOW,Color.BLUE, Color.GREEN} //a01<br>
    		},
    		 
    		{//a1<br>
        	    {Color.YELLOW,Color.BLUE, Color.GREEN} //a11<br>
        	}
	};//2면 2행 3열<br>
	colors2->a0->a00->Color.BLACK, Color.WHITE <br>
			   ->a01->Color.YELLOW,Color.BLUE, Color.GREEN <br>
	 	   ->a1->a11->Color.YELLOW,Color.BLUE, Color.GREEN <br>
	 	   @param upmost : 배열의 최상위노드
	 	   @param array : 처음 호출시는 최상위노드이고 재귀적호출시에는 해당 배열 */
	static void getLengthOfArrayInitializer( Compiler compiler, FindArrayInitializerParams upmost, FindArrayInitializerParams array) {
		HighArray_CodeString src = compiler.data.mBuffer;
		try {
		if (array.listOfFindArrayInitializerParams.count>0) { // 자식 배열초기화문이 있으면
			if (upmost.listOfLength==null) {
				upmost.listOfLength = new ArrayListInt(upmost.dimension);
				upmost.listOfLength.count = upmost.dimension;
			}
			if (upmost.listOfLength.list[array.depth] < array.listOfFindArrayInitializerParams.count) {
				// max length
				upmost.listOfLength.list[array.depth] = array.listOfFindArrayInitializerParams.count;
			}
			int i;
			for (i=0; i<array.listOfFindArrayInitializerParams.count; i++) {
				FindArrayInitializerParams child = (FindArrayInitializerParams) array.listOfFindArrayInitializerParams.getItem(i);
				getLengthOfArrayInitializer( compiler, upmost, child);
			}			
		}
		else { // 수식들의 배열
			if (upmost.listOfLength==null) {
				upmost.listOfLength = new ArrayListInt(upmost.dimension);
				upmost.listOfLength.count = upmost.dimension;
			}
			if (upmost.listOfLength.list[array.depth] < array.listOfFindFuncCallParam.count) {
				// max length
				upmost.listOfLength.list[array.depth] = array.listOfFindFuncCallParam.count;
			}
		}
		}catch(Exception e) {
			//if (Common_Settings.g_printsLog) e.printStackTrace();
		}
	}
	
	/** 배열초기화문의 차원을 정해서 최상위 노드에 그 값을 저장한다.
	 * @param upmost : 배열의 최상위노드
	 * @param array : 처음 호출시는 최상위노드이고 재귀적호출시에는 해당 배열*/
	static void getDimensionOfArrayInitializer( Compiler compiler, FindArrayInitializerParams upmost, FindArrayInitializerParams array) {
		HighArray_CodeString src = compiler.data.mBuffer;
		if (array.listOfFindArrayInitializerParams.count>0) { // 자식 배열초기화문이 있으면
			upmost.dimension++;
			
			FindArrayInitializerParams child = (FindArrayInitializerParams) array.listOfFindArrayInitializerParams.getItem(0);
			getDimensionOfArrayInitializer( compiler, upmost, child);
		}
		else {
			upmost.dimension++;
		}
	}
	
	/** 현재 배열의 깊이를 리턴한다. 최상위 배열초기화문의 노드의 깊이는 0이다.*/
	static int getDepth(FindArrayInitializerParams array) {
		int depth = 0;
		while (array.parent!=null) {			
			if (array.parent instanceof FindArrayInitializerParams) {
				array = (FindArrayInitializerParams) array.parent;
				depth++;
			}
			else break;
		}
		return depth;
	}
	
	static void checkArrayInitializer(Compiler compiler, FindArrayInitializerParams array) {
		int i;
		boolean includesArray = false;
		int countOfComma = 0;
		for (i=array.indexOfLeftParenthesis()+1; i<array.indexOfRightParenthesis(); i++) {
			CodeString str = compiler.data.mBuffer.getItem(i);
			if (CompilerHelper.IsBlank(str) || CompilerHelper.IsComment(str)) continue;
			if (str.equals("{")) {
				includesArray = true;
				int rightPair = Checker.CheckParenthesis(compiler, "{", "}", i, array.indexOfRightParenthesis(), false);
				if (rightPair==-1) return;
				i = rightPair;
			}
			else if (str.equals(",")) {				
				int indexNext = CompilerHelper.SkipBlank(compiler.data.mBuffer, false, i+1, array.indexOfRightParenthesis());
				if (indexNext>=array.indexOfRightParenthesis()) {
					CompilerStatic.errors.add(new Error(compiler, indexNext, indexNext, "invalid array initializer empty element"));
					return;
				}
				CodeString next = compiler.data.mBuffer.getItem(indexNext);
				if (next.equals("{")) {
					if (!includesArray) {
						CompilerStatic.errors.add(new Error(compiler, indexNext, indexNext, "invalid array initializer element"));
						return;
					}
					includesArray = true;
				}
				else if (CompilerHelper.IsIdentifier(next, compiler)) {
					if (includesArray) {
						CompilerStatic.errors.add(new Error(compiler, indexNext, indexNext, "invalid array initializer element"));
						return;
					}
				}
				else if (next.equals(",")) {
					CompilerStatic.errors.add(new Error(compiler, indexNext, indexNext, "invalid array initializer empty element"));
					return;
				}
				if (countOfComma==0) {
					int indexPrev = CompilerHelper.SkipBlank(compiler.data.mBuffer, true, array.indexOfLeftParenthesis(), i-1);
					if (indexPrev<=array.indexOfLeftParenthesis()) {
						CompilerStatic.errors.add(new Error(compiler, indexPrev, indexPrev, "invalid array initializer empty element"));
						return;
					}
					else {
						CodeString prev = compiler.data.mBuffer.getItem(indexPrev);
						if (prev.equals("}")) {
							if (!includesArray) {
								CompilerStatic.errors.add(new Error(compiler, indexPrev, indexPrev, "invalid array initializer element"));
								return;
							}
						}
						else if (CompilerHelper.IsIdentifier(prev, compiler)) {
							if (includesArray) {
								CompilerStatic.errors.add(new Error(compiler, indexPrev, indexPrev, "invalid array initializer element"));
								return;
							}
						}
					}
				}// if (countOfComma==0) {
				countOfComma++;
			}//else if (str.equals(",")) {
		}
	}
	
	
	/** findTypesOfExpressionsOfArrayInitializer()의 sub이다.<br>
	 * int[][] colors = {<br>
    		{Color.BLACK, Color.WHITE, Color.RED}, //a0[]<br>
    		{Color.YELLOW,Color.BLUE, Color.GREEN} //a1[]<br>
	};<br>
	colors->a0->Color.BLACK, Color.WHITE, Color.RED <br>
	 	  ->a1->Color.YELLOW,Color.BLUE, Color.GREEN<br>
	 	  <br>
	int[][][] colors2 = {<br>
    		{//a0<br>
	    		{Color.BLACK, Color.WHITE}, //a00<br>
	    		{Color.YELLOW,Color.BLUE, Color.GREEN} //a01<br>
    		},
    		 
    		{//a1<br>
        	    {Color.YELLOW,Color.BLUE, Color.GREEN} //a11<br>
        	}
	};//2면 2행 3열<br>
	colors2->a0->a00->Color.BLACK, Color.WHITE <br>
			   ->a01->Color.YELLOW,Color.BLUE, Color.GREEN <br>
	 	   ->a1->a11->Color.YELLOW,Color.BLUE, Color.GREEN <br>
	 	   @param upmost : 배열의 최상위노드
	 	   @param array : 처음 호출시는 최상위노드이고 재귀적호출시에는 해당 배열 
	 	   @param arrayOriginalType : int[][]일 경우 int
	 * @param coreThreadID */
	static void findTypesOfExpressionsOfArrayInitializer_sub(Compiler compiler, 
			 FindArrayInitializerParams upmost, 
			FindArrayInitializerParams array, String arrayOriginalType, int coreThreadID) {
		
		checkArrayInitializer(compiler, array);
		
		HighArray_CodeString src = compiler.data.mBuffer;
		if (array.listOfFindArrayInitializerParams.count>0) { // 자식 배열초기화문이 있으면
			array.depth = getDepth(array);
			int i;
			// 자식 배열들을 재귀적 호출한다.
			for (i=0; i<array.listOfFindArrayInitializerParams.count; i++) {
				FindArrayInitializerParams child = (FindArrayInitializerParams) array.listOfFindArrayInitializerParams.getItem(i);
				child.index = i;
				findTypesOfExpressionsOfArrayInitializer_sub(compiler, upmost, child, arrayOriginalType, coreThreadID);
			}			
		}
		else { // 수식들의 배열
			// 현재 배열의 깊이를 알아낸다.
			array.depth = getDepth(array);
			
			if (array.depth+1!=upmost.dimension) {
				int indexError = CompilerHelper.SkipBlank(compiler.data.mBuffer, false, array.indexOfLeftParenthesis()+1, array.endIndex());
				CompilerStatic.errors.add(new Error(compiler, indexError, indexError, "invalid dimension element in array initializer"));
			}
			
			ArrayListIReset listOfExpressions = null;
			if (array.listOfFindFuncCallParam==null || array.listOfFindFuncCallParam.count==0) {
				// 현재 배열의 수식들의 개수를 인덱스들을 알아낸다.
				listOfExpressions = 
						compiler.compilerStack.findFuncCallParams(src, array.indexOfLeftParenthesis(), array.indexOfRightParenthesis(), null);
			}
			else {
				// 배열초기화문에서 funcCallParam 하나만 바뀌는 경우
				listOfExpressions = array.listOfFindFuncCallParam;
				int i;
				for (i=0; i<listOfExpressions.count; i++) {				
					FindFuncCallParam expression = (FindFuncCallParam) listOfExpressions.getItem(i);
					if (expression.startIndex()==546) {
					}
					CodeStringEx typeFullName = expression.typeFullName;
					if (!TypeCast_Syntax.isCompatibleType(compiler, compiler, 
							new CodeStringEx(arrayOriginalType), typeFullName, 1, expression, coreThreadID)) {
						if (typeFullName==null) {
							CompilerStatic.errors.add(
								new Error(compiler, expression.startIndex(), expression.endIndex(), 
									"invalid array initialization. : " + arrayOriginalType + "-" + null));
						}
						else {
							CompilerStatic.errors.add(
								new Error(compiler, expression.startIndex(), expression.endIndex(), 
									"invalid array initialization. : " + arrayOriginalType + "-" + typeFullName.str));
						}
					}
					
				}//for (i=0; i<listOfExpressions.count; i++) {
				return;
			}
			
			int i;
			// 현재 배열의 수식들을 포스트픽스로 바꾸고 그 타입을 정하여 현재 배열에 그것들을 넣어주고 
			// 그 타입이 틀린 타입이면 에러를 출력한다.
			if (listOfExpressions==null) return;
			for (i=0; i<listOfExpressions.count; i++) {				
				FindFuncCallParam expression = (FindFuncCallParam) listOfExpressions.getItem(i);
				if (expression.startIndex()==546) {
				}
				CodeStringEx typeFullName = Expression.getTypeOfExpression(compiler, expression, coreThreadID);
				array.listOfFindFuncCallParam.add(expression);
				if (!TypeCast_Syntax.isCompatibleType(compiler, compiler, 
						new CodeStringEx(arrayOriginalType), typeFullName, 1, expression, coreThreadID)) {
					if (typeFullName==null) {
						CompilerStatic.errors.add(
							new Error(compiler, expression.startIndex(), expression.endIndex(), 
								"invalid array initialization. : " + arrayOriginalType + "-" + null));
					}
					else {
						CompilerStatic.errors.add(
							new Error(compiler, expression.startIndex(), expression.endIndex(), 
								"invalid array initialization. : " + arrayOriginalType + "-" + typeFullName.str));
					}
				}
				
			}//for (i=0; i<listOfExpressions.count; i++) {	
		}
	}
	
}
