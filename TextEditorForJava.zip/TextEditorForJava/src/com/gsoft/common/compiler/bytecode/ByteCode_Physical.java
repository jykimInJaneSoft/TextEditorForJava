package com.gsoft.common.compiler.bytecode;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.CommonGUI;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.FileHelper;
import com.gsoft.common.IO;
import com.gsoft.common.compiler.Array;
import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.CompilerStatic;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.Compiler_types.FindControlBlockParams;
import com.gsoft.common.compiler.Compiler_types.FindFunctionParams;
import com.gsoft.common.compiler.Compiler_types.FindVarParams;
import com.gsoft.common.compiler.Compiler_types.FindVarUseParams;
import com.gsoft.common.compiler.Compiler_types_Base.AccessModifier;
import com.gsoft.common.compiler.Compiler_types_Special.FindArrayInitializerParams;
import com.gsoft.common.compiler.IndexForHighArray;
import com.gsoft.common.compiler.Number;
import com.gsoft.common.compiler.Number.Hexa;
import com.gsoft.common.compiler.TemplateBase;
import com.gsoft.common.compiler.bytecode.ByteCode_Types.ByteCodeInstruction;
import com.gsoft.common.compiler.bytecode.ByteCode_Types.HashItemOfConstantTable;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_Class_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_Double_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_Field_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_Float_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_Integer_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_InterfaceMethod_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_Long_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_Method_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_NameAndTypeDesc_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_String_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_Utf8_info;
import com.gsoft.common.compiler.classloader.Loader;
import com.gsoft.common.compiler.util.Builder;
import com.gsoft.common.gui.Control;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListIReset;
import com.gsoft.common.util.ArrayListInt;
import com.gsoft.common.util.ArrayListString;
import com.gsoft.common.util.HighArray;
import com.gsoft.common.util.HighArray_byte;
import com.gsoft.common.util.HighArray_char;
import com.gsoft.common.util.Sort;
import com.gsoft.common.util.Sort.SortItem;
import com.gsoft.common.util.hash.Hashtable2_Object;
import com.gsoft.common.util.hash.Hashtable2_String;
import com.gsoft.common.util.hash.Hashtable2_String.HashItem;

import com.gsoft.common.compiler.bytecode.ByteCodeGeneratorForClass;
import com.gsoft.common.compiler.bytecode.HighArrayCharForByteCode;
import com.gsoft.common.compiler.bytecode.PathClassWriter;
import com.gsoft.common.compiler.bytecode.TypeDescriptor;
import com.gsoft.common.compiler.bytecode.ByteCode_Helper;
import com.gsoft.common.compiler.bytecode.LocalVar;
import com.gsoft.common.compiler.bytecode.Enum;

@SuppressWarnings("unused")
public class ByteCode_Physical {
	/** printClass()에서 생성되는 바이트코드 결과, Exception_Entry[]이 저장되어 있다.*/
	HighArrayCharForByteCode[] arrResult;
	
	/**result of createConstantTableIndex()*/
	HighArray[] arrResult2;
	
	/** printClass()에서 함수별 생성된 code 배열의 결과를 담는다.*/
	HighArray_byte[] arrResult3;
	
	
	/** 바이트코드를 생성하는 클래스의 ConstantTable, 
	 * 코드에서 외부클래스의 필드나 메서드를 참조할 때 
	 * 참조하는 외부클래스의 풀이름과 필드나 메서드의 이름과 타입 디스크립터가 들어간다. 
	 * CONSTANT_Class_info, CONSTANT_Method_info, CONSTANT_Field_info 가 들어간다.
	 **CONSTANT_String_info, CONSTANT_Integer_info, CONSTANT_Float_info 등이 들어간다.*/
	Hashtable2_String listOfConstantTableHashed = new Hashtable2_String(100, 3);
	
	/** 바이트코드를 생성하는 클래스의 ConstantTable,  
	 * CONSTANT_Class_info, CONSTANT_NameAndTypeDesc_info가 참조하는
	 * Utf8 스트링이 들어간다. 
	 */
	Hashtable2_String listOfConstantTableUtf8Hashed = new Hashtable2_String(100, 3);

	/** constant table, 처음에는 arrOfPrimitiveTypes이 차지하고 
	 * 그 다음에는 listOfConstantTableHashed에서 
	 * Hashtable2_String_ForConstantTable.toArray()를 이용해서
	 * 일차원 배열  listOfConstantTable으로 변환된다.
	 *  그 다음에는 listOfConstantTableUtf8Hashed에서 
	 * Hashtable2_String_ForConstantTable.toArray()를 이용해서
	 * 일차원 배열  listOfConstantTable으로 변환된다.
	 */
	ArrayList listOfConstantTable;
	
	//HighArray<CONSTANT_Utf8_info> listOfUtf8Infos = new HighArray<CONSTANT_Utf8_info>(50); 
	
	/**{ "Z", "B", "C", "S", "I", "J", "F", "D"}, atype 
	 * 디폴트 타입의 디스크립터는 여기에 넣고 다시 검색한다.<br>
	 * listOfConstantTable의 첫번째 아이템이 null이므로 arrOfPrimitiveTypes의 첫번째 아이템도 null이다.
	 * createConstantTableIndex()에서 디폴트타입을 찾을때 arrOfPrimitiveTypes에서 찾게되므로
	 * 찾은 인덱스는 항상 0보다 크게 된다. 
	 * newarray의 인덱스는 1바이트이므로 constant table에서 맨 앞에 놓인다.*/
	//ArrayListString arrOfPrimitiveTypes = new ArrayListString(9);

	private ByteCodeGeneratorForClass generator;

	private Compiler compiler;
	
	
	/** tableswitch, lookupswitch의 디폴트 어드레스와 오프셋들을 little endian으로 쓰면 true, 그렇지 않으면 false,
	 * 초기값은 false*/
	private boolean mIsLittleEndianOfSwitch = false;
	/** tableswitch의 low*/
	private int mLowOfSwitch;
	/** tableswitch의 high*/
	private int mHighOfSwitch;

	/** tableswitch, lookupswitch의 오프셋 리스트*/
	private ArrayListInt mListOfOffsetsOfSwitch = new ArrayListInt(10);
	/** tableswitch, lookupswitch의 패딩 개수*/
	private int mCountOfPaddingOfSwitch;

	/** tableswitch, lookupswitch의 디폴트 어드레스*/
	private int mDefaultAddressOfSwitch;

	/** tableswitch, lookupswitch의 opcode*/
	private short mOpcodeHexaOfSwitch;
	/** lookupswitch의 key 리스트*/
	private ArrayListInt mListOfKeysOfLookupSwitch = new ArrayListInt(10);
	/** lookupswitch의 count (key와 오프셋쌍의 개수)*/
	private int mCountOfLookupSwitch;

	
	
	//private int curHashIndex;

	
	

	ArrayList arrOfClassFieldMethods;
	ArrayList arrOfHashItemsOfLocalVars;
	ArrayList arrOfAttributes;
	ArrayList arrOfChildClasses;

	private int curHashIndex;

	private int hashIndexOfField;

	private int hashIndexOfLocalVars;

	private int hashIndexOfAttributes;

	private int hashIndexOfChildClasses;

	private int hashIndexOfTheOthers;
	
	
	
	ByteCode_Physical(ByteCodeGeneratorForClass generator) {
		this.generator = generator;
		this.compiler = generator.compiler;
		
		//arrOfPrimitiveTypes.add((String)null); // 첫번째 아이템은 null이다.
	}
	
	/** 사용자가 소스에서 어떤 노드를 클릭할 때마다 새로운 constant table(listOfConstantTable)이 만들어진다.*/
	public void resetHashTablesAndConstantTable(Object node) {
		if (this.listOfConstantTable!=null) this.listOfConstantTable.reset();
		/*if (this.arrOfPrimitiveTypes!=null) {
			arrOfPrimitiveTypes.count = 0;
			arrOfPrimitiveTypes.add((String)null);
		}*/
		if (this.listOfConstantTableHashed!=null) this.listOfConstantTableHashed.reset();
		if (this.listOfConstantTableUtf8Hashed!=null) this.listOfConstantTableUtf8Hashed.reset();
		
		if (this.listOfConstantTable==null) {
			listOfConstantTable = new ArrayList(100+3*compiler.data.numOfLines);
		}
		
		this.makeConstantTable();
	}
	
	public void destroy() {
		/*if (this.arrOfPrimitiveTypes!=null) {
			this.arrOfPrimitiveTypes.destroy();
			this.arrOfPrimitiveTypes = null;
		}*/
		if (this.arrResult!=null) {
			int i;
			for (i=0; i<arrResult.length; i++) {
				if (this.arrResult[i]!=null) {
					this.arrResult[i].destroy();
					this.arrResult[i] = null;
				}
			}
			this.arrResult = null;
		}
		if (this.arrResult2!=null) {
			int i;
			for (i=0; i<arrResult2.length; i++) {
				if (this.arrResult2[i]!=null) {
					this.arrResult2[i].destroy();
					this.arrResult2[i] = null;
				}
			}
			this.arrResult2 = null;
		}
		if (this.arrResult3!=null) {
			int i;
			for (i=0; i<arrResult3.length; i++) {
				if (this.arrResult3[i]!=null) {
					this.arrResult3[i].destroy();
					this.arrResult3[i] = null;
				}
			}
			this.arrResult3 = null;
		}
		
		if (this.listOfConstantTable!=null) {
			this.listOfConstantTable.destroy();
			this.listOfConstantTable = null;
		}
		if (this.listOfConstantTableHashed!=null) {
			this.listOfConstantTableHashed.destroy();
			this.listOfConstantTableHashed = null;
		}
		if (this.listOfConstantTableUtf8Hashed!=null) {
			this.listOfConstantTableUtf8Hashed.destroy();
			this.listOfConstantTableUtf8Hashed = null;
		}
	}
	
	
	
	/** varUse 가 참조하는 memberDecl 을 가지고 CONSTANT_Class_info 을 만들어서 
	 * varUse.constant_info 에 설정하고 
	 * listOfConstantTableHashed 에 CONSTANT_Class_info 을 넣는다.
	 * @param varUse
	 */
	void makeCONSTANT_Class_infoAndPutItIntolistOfConstantTable(FindVarUseParams varUse, int coreThreadID) {
		if (varUse.index()==-1) {
			int a;
			a=0;
			a++;
		}
		if (varUse.memberDecl instanceof FindClassParams) {
			FindClassParams classParams = (FindClassParams)varUse.memberDecl;
			this.makeCONSTANT_Class_infoAndPutItIntolistOfConstantTable(classParams.name, coreThreadID);
		}
		
	}
	
	/** varUse 가 참조하는 memberDecl 을 가지고 CONSTANT_Class_info 을 만들어서 
	 * varUse.constant_info 에 설정하고 
	 * listOfConstantTableHashed 에 CONSTANT_Class_info 을 넣는다.
	 * @param varUse
	 */
	void makeCONSTANT_Class_infoAndPutItIntolistOfConstantTable(String typeName, int coreThreadID) {
	
		if (!CompilerHelper.IsDefaultType(typeName)) {
			String descriptor = TypeDescriptor.getDescriptor(typeName, coreThreadID);
			
			if (listOfConstantTableHashed.getData(descriptor)!=null) return;
			
			/*CONSTANT_Class_info { 
				u1 tag; //CONSTANT_Class (7)
				u2 name_index; // CONSTANT_Utf8_info를 가르키는 constantTable의 인덱스
			}*/
			/*CONSTANT_Utf8_info {
				u1 tag; 
				u2 length; // 바이트수
				u1 bytes[length]; //utf-8,  not null-terminated
			}*/
			
			HashItemOfConstantTable hashItem = new HashItemOfConstantTable(descriptor, 6);
			if (listOfConstantTableHashed.getData(descriptor)==null) {
				listOfConstantTableHashed.input(descriptor, hashItem);
			}
			hashItem.index = this.curHashIndex+1;
			
			
			CONSTANT_Class_info classInfo = new CONSTANT_Class_info(hashItem.descriptor, compiler);
			classInfo.tag = 7;
			hashItem.constant_info = classInfo;
			
			this.listOfConstantTable.setItem(hashItem.index, classInfo);
			
			
			// Utf8 스트링을 없으면 UTF8 해시에 추가한다.
			hashItem = new HashItemOfConstantTable(descriptor, 11);
			if (listOfConstantTableUtf8Hashed.getData(descriptor)==null) {
				this.listOfConstantTableUtf8Hashed.input(descriptor, hashItem);
			}
			hashItem.index = this.curHashIndex + 2;
			
			
			
			CONSTANT_Utf8_info utf8Info = new CONSTANT_Utf8_info((byte)1, 
					(short)hashItem.descriptor.length(), hashItem.descriptor);
			HashItemOfConstantTable utf8Item = hashItem;		
			int indexOfUtf8Hashed = utf8Item.index;
			this.listOfConstantTable.setItem(indexOfUtf8Hashed, utf8Info);
			
			classInfo.name_index = (short) indexOfUtf8Hashed;
			
			
			curHashIndex += 2;
		}
	}
	
	void makeCONSTANT_Class_infoAndPutItIntolistOfConstantTable_ExceptLAndSemicolon(String descriptor) {
		
		if (listOfConstantTableHashed.getData(descriptor)!=null) return;
		
		HashItemOfConstantTable hashItem = new HashItemOfConstantTable(descriptor, 6);
		if (listOfConstantTableHashed.getData(descriptor)==null) {
			listOfConstantTableHashed.input(descriptor, hashItem);
		}
		hashItem.index = this.curHashIndex+1;
		
		
		CONSTANT_Class_info classInfo = new CONSTANT_Class_info(hashItem.descriptor, compiler);
		classInfo.tag = 7;
		hashItem.constant_info = classInfo;
		
		this.listOfConstantTable.setItem(hashItem.index, classInfo);
		
		
		// Utf8 스트링을 없으면 UTF8 해시에 추가한다.
		hashItem = new HashItemOfConstantTable(descriptor, 11);
		if (listOfConstantTableUtf8Hashed.getData(descriptor)==null) {
			this.listOfConstantTableUtf8Hashed.input(descriptor, hashItem);
		}
		hashItem.index = this.curHashIndex + 2;
		
		
		
		CONSTANT_Utf8_info utf8Info = new CONSTANT_Utf8_info((byte)1, 
				(short)hashItem.descriptor.length(), hashItem.descriptor);
		HashItemOfConstantTable utf8Item = hashItem;		
		int indexOfUtf8Hashed = utf8Item.index;
		this.listOfConstantTable.setItem(indexOfUtf8Hashed, utf8Info);
		
		classInfo.name_index = (short) indexOfUtf8Hashed;
		
		
		curHashIndex += 2;

	}
	
	
	
	/** varUse 가 참조하는 varDecl 을 가지고 CONSTANT_Field_info 을 만들어서 
	 * varUse.constant_info 에 설정하고 
	 * listOfConstantTableHashed 에 CONSTANT_Field_info 을 넣는다.
	 * @param varUse
	 */
	void makeCONSTANT_Field_infoAndPutItIntolistOfConstantTable(FindVarUseParams varUse, int coreThreadID) {
		if (varUse.index()==-1) {
			int a;
			a=0;
			a++;
		}
		if (compiler.data.mBuffer.getItem(varUse.index()).equals("x")) {
			int a;
			a=0;
			a++;
		}
		FindVarParams field = varUse.varDecl;
		this.makeCONSTANT_Field_infoAndPutItIntolistOfConstantTable(field, coreThreadID);
	}
	
	
	/** varUse 가 참조하는 varDecl 을 가지고 CONSTANT_Field_info 을 만들어서 
	 * varUse.constant_info 에 설정하고 
	 * listOfConstantTableHashed 에 CONSTANT_Field_info 을 넣는다.
	 * @param varUse
	 */
	void makeCONSTANT_Field_infoAndPutItIntolistOfConstantTable(FindVarParams var, int coreThreadID) {
		if (var.varNameIndex()==-1) {
			int a;
			a=0;
			a++;
		}
		
		try {
			
		FindClassParams parentClass = (FindClassParams) var.parent;
		// prints arraylength in ByteCodeGeneratorForClass.printMemberVarUse()
		//if (parentClass.name.equals(ByteCode_Types.ArrayFullClassName)) return;
		
		/*CONSTANT_Fieldref_info { 
			u1 tag; // CONSTANT_Fieldref (9). 
			u2 class_index; // CONSTANT_Class_info을 가르키는 constantTable의 인덱스
			u2 name_and_type_index; //CONSTANT_NameAndType_info 을 가르키는 constantTable의 인덱스
		}*/
		
		String classDescriptor = TypeDescriptor.getDescriptorExceptLAndSemicolon(parentClass, coreThreadID);
		String descriptor = TypeDescriptor.getDescriptor(var, coreThreadID);
		String nameAndTypeDesc = var.getVarStr(coreThreadID);
		CONSTANT_Field_info field = new CONSTANT_Field_info(classDescriptor, 
				var.fieldName, descriptor, compiler);
		
		
		String fieldInfoStr = field.getFieldInfoStr();
		
		if (listOfConstantTableHashed.getData(fieldInfoStr)!=null) return;
		
		HashItemOfConstantTable hashItem = new HashItemOfConstantTable(fieldInfoStr, 7);
		if (listOfConstantTableHashed.getData(fieldInfoStr)==null) { // CONSTANT_Field_info
			listOfConstantTableHashed.input(fieldInfoStr, hashItem);
		}
		hashItem.index = this.curHashIndex + 1;
		
		// CONSTANT_Field_info 를 만든다.
		field.tag = 9;
		hashItem.constant_info = field;
		this.listOfConstantTable.setItem(hashItem.index, field);
		
		
		
		hashItem = new HashItemOfConstantTable(classDescriptor, 6);
		if (listOfConstantTableHashed.getData(classDescriptor)==null) { // CONSTANT_Class_info
			listOfConstantTableHashed.input(classDescriptor, hashItem);
		}
		hashItem.index = this.curHashIndex + 2;		
		
		
		CONSTANT_Class_info classInfo = new CONSTANT_Class_info(hashItem.descriptor, compiler);
		classInfo.tag = 7;
		hashItem.constant_info = classInfo;
		field.classRef = hashItem.index;
		this.listOfConstantTable.setItem(hashItem.index, classInfo);
		
		
		// Utf8 of CONSTANT_Class_info
		hashItem = new HashItemOfConstantTable(classDescriptor, 11);
		if (listOfConstantTableUtf8Hashed.getData(classDescriptor)==null) {
			this.listOfConstantTableUtf8Hashed.input(classDescriptor, hashItem);
		}
		hashItem.index = this.curHashIndex + 3;
		
		
		
		CONSTANT_Utf8_info utf8Info = new CONSTANT_Utf8_info((byte)1, 
				(short)hashItem.descriptor.length(), hashItem.descriptor);
		HashItemOfConstantTable utf8Item = hashItem;		
		int indexOfUtf8Hashed = utf8Item.index;
		this.listOfConstantTable.setItem(indexOfUtf8Hashed, utf8Info);
		
		classInfo.name_index = (short) indexOfUtf8Hashed;
		
		
		hashItem = new HashItemOfConstantTable(nameAndTypeDesc, 9);
		if (listOfConstantTableHashed.getData(nameAndTypeDesc)==null) { // nameAndTypeDesc
			listOfConstantTableHashed.input(nameAndTypeDesc, hashItem);
		}
		hashItem.index = this.curHashIndex + 4;
		
		
		CONSTANT_NameAndTypeDesc_info nameAndTypeDescInfo = new CONSTANT_NameAndTypeDesc_info(var.fieldName, descriptor);
		nameAndTypeDescInfo.tag = 12;
		hashItem.constant_info = nameAndTypeDescInfo;
		field.nameAndTypeDescRef = hashItem.index;
		this.listOfConstantTable.setItem(hashItem.index, nameAndTypeDescInfo);
		
			
		// Utf8 typeDesc of nameAndTypeDesc
		hashItem = new HashItemOfConstantTable(descriptor, 11);
		if (this.listOfConstantTableUtf8Hashed.getData(descriptor)==null) { // typeDesc
			this.listOfConstantTableUtf8Hashed.input(descriptor, hashItem);
		}
		hashItem.index = this.curHashIndex + 5;
		
		utf8Info = new CONSTANT_Utf8_info((byte)1, 
				(short)hashItem.descriptor.length(), hashItem.descriptor);
		utf8Item = hashItem;		
		indexOfUtf8Hashed = utf8Item.index;
		this.listOfConstantTable.setItem(indexOfUtf8Hashed, utf8Info);
		
		nameAndTypeDescInfo.typeDescRef = (short) indexOfUtf8Hashed;
		
		// Utf8 name of nameAndTypeDesc
		hashItem = new HashItemOfConstantTable(var.fieldName, 11);
		if (this.listOfConstantTableUtf8Hashed.getData(var.fieldName)==null) { // name
			this.listOfConstantTableUtf8Hashed.input(var.fieldName, hashItem);
		}
		hashItem.index = this.curHashIndex + 6;
		
		utf8Info = new CONSTANT_Utf8_info((byte)1, 
				(short)hashItem.descriptor.length(), hashItem.descriptor);
		utf8Item = hashItem;		
		indexOfUtf8Hashed = utf8Item.index;
		this.listOfConstantTable.setItem(indexOfUtf8Hashed, utf8Info);
		
		nameAndTypeDescInfo.nameRef = (short) indexOfUtf8Hashed;
		
		curHashIndex += 6;
		
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
		}
		
	}
	
	/** varUse 가 참조하는 funcDecl 을 가지고 CONSTANT_Method_info 을 만들어서 
	 * varUse.constant_info 에 설정하고 
	 * listOfConstantTableHashed 에 CONSTANT_Method_info 을 넣는다.
	 * @param varUse
	 */
	void makeCONSTANT_Method_infoAndPutItIntolistOfConstantTable(FindVarUseParams varUse, int coreThreadID) {
		this.makeCONSTANT_Method_infoAndPutItIntolistOfConstantTable(varUse.funcDecl, coreThreadID);
	}
	
	
	void makeCONSTANT_Method_infoAndPutItIntolistOfConstantTable(FindFunctionParams func, int coreThreadID) {
		if (func==null) {
			int a;
			a=0;
			a++;
		}
		if (func==null) {
			int a;
			a=0;
			a++;
		}		
		
		FindClassParams parentClass = (FindClassParams) func.parent;
		
		String classDescriptor = TypeDescriptor.getDescriptorExceptLAndSemicolon(parentClass, coreThreadID);
		String descriptor = TypeDescriptor.getDescriptor(func, coreThreadID);
		String nameAndTypeDesc = func.getFunctionStr(coreThreadID);
		String name = func.name;
		
		if (func.isConstructor) {
			if (!func.isConstructorThatInitializesStaticFields) {
				name = "<init>";
			}
			else {
				name = "<clinit>";
			}
		}
		
		CONSTANT_Method_info method = new CONSTANT_Method_info(classDescriptor, 
				name, descriptor, compiler);
		
		
		String methodInfoStr = method.getMethodInfoStr();
		
		if (listOfConstantTableHashed.getData(methodInfoStr)!=null) {
			return;
		}
		
		HashItemOfConstantTable hashItem = new HashItemOfConstantTable(methodInfoStr, 8);
		if (listOfConstantTableHashed.getData(methodInfoStr)==null) { // CONSTANT_Method_info
			listOfConstantTableHashed.input(methodInfoStr, hashItem);
		}
		hashItem.index = this.curHashIndex + 1;
		
		// CONSTANT_Method_info 를 만든다.
		method.tag = 10;
		hashItem.constant_info = method;
		this.listOfConstantTable.setItem(hashItem.index, method);
		
		
		
		hashItem = new HashItemOfConstantTable(classDescriptor, 6);
		if (listOfConstantTableHashed.getData(classDescriptor)==null) { // CONSTANT_Class_info
			listOfConstantTableHashed.input(classDescriptor, hashItem);
		}
		hashItem.index = this.curHashIndex + 2;		
		
		
		CONSTANT_Class_info classInfo = new CONSTANT_Class_info(hashItem.descriptor, compiler);
		classInfo.tag = 7;
		hashItem.constant_info = classInfo;
		method.classRef = hashItem.index;
		this.listOfConstantTable.setItem(hashItem.index, classInfo);
		
		
		// Utf8 of CONSTANT_Class_info
		hashItem = new HashItemOfConstantTable(classDescriptor, 11);
		if (listOfConstantTableUtf8Hashed.getData(classDescriptor)==null) {
			this.listOfConstantTableUtf8Hashed.input(classDescriptor, hashItem);
		}
		hashItem.index = this.curHashIndex + 3;
		
		
		
		CONSTANT_Utf8_info utf8Info = new CONSTANT_Utf8_info((byte)1, 
				(short)hashItem.descriptor.length(), hashItem.descriptor);
		HashItemOfConstantTable utf8Item = hashItem;		
		int indexOfUtf8Hashed = utf8Item.index;
		this.listOfConstantTable.setItem(indexOfUtf8Hashed, utf8Info);
		
		classInfo.name_index = (short) indexOfUtf8Hashed;
		
		
		hashItem = new HashItemOfConstantTable(nameAndTypeDesc, 9);
		if (listOfConstantTableHashed.getData(nameAndTypeDesc)==null) { // nameAndTypeDesc
			listOfConstantTableHashed.input(nameAndTypeDesc, hashItem);
		}
		hashItem.index = this.curHashIndex + 4;
		
		
		CONSTANT_NameAndTypeDesc_info nameAndTypeDescInfo = new CONSTANT_NameAndTypeDesc_info(name, descriptor);
		nameAndTypeDescInfo.tag = 12;
		hashItem.constant_info = nameAndTypeDescInfo;
		method.nameAndTypeDescRef = hashItem.index;
		this.listOfConstantTable.setItem(hashItem.index, nameAndTypeDescInfo);
		
			
		// Utf8 typeDesc of nameAndTypeDesc
		hashItem = new HashItemOfConstantTable(descriptor, 11);
		if (this.listOfConstantTableUtf8Hashed.getData(descriptor)==null) { // typeDesc
			this.listOfConstantTableUtf8Hashed.input(descriptor, hashItem);
		}
		hashItem.index = this.curHashIndex + 5;
		
		utf8Info = new CONSTANT_Utf8_info((byte)1, 
				(short)hashItem.descriptor.length(), hashItem.descriptor);
		utf8Item = hashItem;		
		indexOfUtf8Hashed = utf8Item.index;
		this.listOfConstantTable.setItem(indexOfUtf8Hashed, utf8Info);
		
		nameAndTypeDescInfo.typeDescRef = (short) indexOfUtf8Hashed;
		
		// Utf8 name of nameAndTypeDesc
		hashItem = new HashItemOfConstantTable(name, 11);
		if (this.listOfConstantTableUtf8Hashed.getData(name)==null) { // name
			this.listOfConstantTableUtf8Hashed.input(name, hashItem);
		}
		hashItem.index = this.curHashIndex + 6;
		
		utf8Info = new CONSTANT_Utf8_info((byte)1, 
				(short)hashItem.descriptor.length(), hashItem.descriptor);
		utf8Item = hashItem;		
		indexOfUtf8Hashed = utf8Item.index;
		this.listOfConstantTable.setItem(indexOfUtf8Hashed, utf8Info);
		
		nameAndTypeDescInfo.nameRef = (short) indexOfUtf8Hashed;
		
		curHashIndex += 6;
	}
	
	/** varUse 가 참조하는 funcDecl 을 가지고 CONSTANT_InterfaceMethod_info 을 만들어서 
	 * varUse.constant_info 에 설정하고 
	 * listOfConstantTableHashed 에 CONSTANT_InterfaceMethod_info 을 넣는다.
	 * @param varUse
	 */
	void makeCONSTANT_InterfaceMethod_infoAndPutItIntolistOfConstantTable(FindVarUseParams varUse, int coreThreadID) {
		
		FindFunctionParams func = varUse.funcDecl;
		FindClassParams parentClass = (FindClassParams) func.parent;
		
		String classDescriptor = TypeDescriptor.getDescriptorExceptLAndSemicolon(parentClass, coreThreadID);
		String descriptor = TypeDescriptor.getDescriptor(func, coreThreadID);
		String nameAndTypeDesc = func.getFunctionStr(coreThreadID);
		String name = func.name;
		
			
		CONSTANT_InterfaceMethod_info method = new CONSTANT_InterfaceMethod_info(classDescriptor, 
				name, descriptor, compiler);
		
		
		String methodInfoStr = method.getMethodInfoStr();
		
		if (listOfConstantTableHashed.getData(methodInfoStr)!=null) {
			return;
		}
		
		int srcIndex = varUse.index();
		
		HashItemOfConstantTable hashItem = new HashItemOfConstantTable(methodInfoStr, 10);
		if (listOfConstantTableHashed.getData(methodInfoStr)==null) { // CONSTANT_InterfaceMethod_info
			listOfConstantTableHashed.input(methodInfoStr, hashItem);
		}
		hashItem.index = this.curHashIndex + 1;
		
		// CONSTANT_InterfaceMethod_info 를 만든다.
		method.tag = 11;
		hashItem.constant_info = method;
		this.listOfConstantTable.setItem(hashItem.index, method);
		
		
		
		hashItem = new HashItemOfConstantTable(classDescriptor, 6);
		if (listOfConstantTableHashed.getData(classDescriptor)==null) { // CONSTANT_Class_info
			listOfConstantTableHashed.input(classDescriptor, hashItem);
		}
		hashItem.index = this.curHashIndex + 2;		
		
		
		CONSTANT_Class_info classInfo = new CONSTANT_Class_info(hashItem.descriptor, compiler);
		classInfo.tag = 7;
		hashItem.constant_info = classInfo;
		method.classRef = hashItem.index;
		this.listOfConstantTable.setItem(hashItem.index, classInfo);
		
		
		// Utf8 of CONSTANT_Class_info
		hashItem = new HashItemOfConstantTable(classDescriptor, 11);
		if (listOfConstantTableUtf8Hashed.getData(classDescriptor)==null) {
			this.listOfConstantTableUtf8Hashed.input(classDescriptor, hashItem);
		}
		hashItem.index = this.curHashIndex + 3;
		
		
		
		CONSTANT_Utf8_info utf8Info = new CONSTANT_Utf8_info((byte)1, 
				(short)hashItem.descriptor.length(), hashItem.descriptor);
		HashItemOfConstantTable utf8Item = hashItem;		
		int indexOfUtf8Hashed = utf8Item.index;
		this.listOfConstantTable.setItem(indexOfUtf8Hashed, utf8Info);
		
		classInfo.name_index = (short) indexOfUtf8Hashed;
		
		
		hashItem = new HashItemOfConstantTable(nameAndTypeDesc, 9);
		if (listOfConstantTableHashed.getData(nameAndTypeDesc)==null) { // nameAndTypeDesc
			listOfConstantTableHashed.input(nameAndTypeDesc, hashItem);
		}
		hashItem.index = this.curHashIndex + 4;
		
		
		CONSTANT_NameAndTypeDesc_info nameAndTypeDescInfo = new CONSTANT_NameAndTypeDesc_info(name, descriptor);
		nameAndTypeDescInfo.tag = 12;
		hashItem.constant_info = nameAndTypeDescInfo;
		method.nameAndTypeDescRef = hashItem.index;
		this.listOfConstantTable.setItem(hashItem.index, nameAndTypeDescInfo);
		
			
		// Utf8 typeDesc of nameAndTypeDesc
		hashItem = new HashItemOfConstantTable(descriptor, 11);
		if (this.listOfConstantTableUtf8Hashed.getData(descriptor)==null) { // typeDesc
			this.listOfConstantTableUtf8Hashed.input(descriptor, hashItem);
		}
		hashItem.index = this.curHashIndex + 5;
		
		utf8Info = new CONSTANT_Utf8_info((byte)1, 
				(short)hashItem.descriptor.length(), hashItem.descriptor);
		utf8Item = hashItem;		
		indexOfUtf8Hashed = utf8Item.index;
		this.listOfConstantTable.setItem(indexOfUtf8Hashed, utf8Info);
		
		nameAndTypeDescInfo.typeDescRef = (short) indexOfUtf8Hashed;
		
		// Utf8 name of nameAndTypeDesc
		hashItem = new HashItemOfConstantTable(name, 11);
		if (this.listOfConstantTableUtf8Hashed.getData(name)==null) { // name
			this.listOfConstantTableUtf8Hashed.input(name, hashItem);
		}
		hashItem.index = this.curHashIndex + 6;
		
		utf8Info = new CONSTANT_Utf8_info((byte)1, 
				(short)hashItem.descriptor.length(), hashItem.descriptor);
		utf8Item = hashItem;		
		indexOfUtf8Hashed = utf8Item.index;
		this.listOfConstantTable.setItem(indexOfUtf8Hashed, utf8Info);
		
		nameAndTypeDescInfo.nameRef = (short) indexOfUtf8Hashed;
		
		curHashIndex += 6;
	}
	
	/** varUse 가 참조하는 name 을 가지고 CONSTANT_String_info 을 만들어서 
	 * listOfConstantTableHashed 에 CONSTANT_String_info 을 넣는다.
	 * ldc_w의 스트링 상수는 해시테이블에는 "이 없는 스트링이 넣어지고,
	 * HighArrayCharForByteCode에는 "이 있는 스트링이 출력된다.
	 * @param varUse
	 */
	void makeCONSTANT_String_infoAndPutItIntolistOfConstantTable(FindVarUseParams varUse) {	
		if (varUse.index()==130) {
			int a;
			a=0;
			a++;
		}
		String newStr = varUse.name;
		this.makeCONSTANT_String_infoAndPutItIntolistOfConstantTable(newStr);
	}
	
	/** varUse 가 참조하는 name 을 가지고 CONSTANT_String_info 을 만들어서 
	 * listOfConstantTableHashed 에 CONSTANT_String_info 을 넣는다.
	 * ldc_w의 스트링 상수는 해시테이블에는 "이 없는 스트링이 넣어지고,
	 * HighArrayCharForByteCode에는 "이 있는 스트링이 출력된다.
	 * @param varUse
	 */
	void makeCONSTANT_String_infoAndPutItIntolistOfConstantTable(String str) {
		if (listOfConstantTableHashed.getData(str)!=null) {
			return;
		}
		
		HashItemOfConstantTable hashItem = new HashItemOfConstantTable(str, (byte)4);
		if (listOfConstantTableHashed.getData(str)==null) {
			listOfConstantTableHashed.input(str, hashItem);
		}
		hashItem.index = this.curHashIndex+1;
		
		//CONSTANT_String_info stringInfo = new CONSTANT_String_info(str);
		CONSTANT_String_info stringInfo = new CONSTANT_String_info((byte)8, hashItem.index+1, listOfConstantTable);
		stringInfo.tag = 8;
		hashItem.constant_info = stringInfo;
		this.listOfConstantTable.setItem(hashItem.index, stringInfo);
		
		
		// Utf8 스트링을 없으면 UTF8 해시에 추가한다.
		hashItem = new HashItemOfConstantTable(hashItem.descriptor, 11);
		if (this.listOfConstantTableUtf8Hashed.getData(hashItem.descriptor)==null) {
			this.listOfConstantTableUtf8Hashed.input(hashItem.descriptor, hashItem);
		}
		hashItem.index = this.curHashIndex+2;
		
		CONSTANT_Utf8_info utf8Info = new CONSTANT_Utf8_info((byte)1, 
				(short)hashItem.descriptor.length(), hashItem.descriptor);	
		int indexOfUtf8Hashed = hashItem.index;
		
		this.listOfConstantTable.setItem(indexOfUtf8Hashed, utf8Info);
		
		stringInfo.string_index = (short) indexOfUtf8Hashed;
		
		this.curHashIndex += 2;
	}
	
	/**'ㅅ', 'ㅠ'와 같은 유니코드 값을 컨스턴트 테이블에 넣는다.
	 * 문자형 정수 상수, short범위를 넘지 않는 문자 상수는 bipush, sipush로 넣는다. 
	  short범위를 넘는 문자상수는 makeCONSTANT_Number_infoAndPutItIntolistOfConstantTable(unicode_value)로 넣는다.
	 * listOfConstantTableHashed 에 CONSTANT_Integer_info 등을 넣는다.
	 * byte나 short의 경우에는 bipush( byte 를 스택에 push), 
	 * sipush( short 를 스택에 push)를 써야 하므로
	 *  constant table 에 넣지 않는다.
	 * @param unicode_value :  short범위를 넘는 문자상수
	 */
	void makeCONSTANT_Number_infoAndPutItIntolistOfConstantTable(int unicode_value) {
		//varUse.constant_info = integer;
		//if (unicode_value<16*16*16*16-1) {
			int value = unicode_value;
			if (listOfConstantTableHashed.getData(value+"")!=null) {
				return;
			}
			HashItemOfConstantTable hashItem = new HashItemOfConstantTable(value+"", (byte)1);
			if (listOfConstantTableHashed.getData(value+"")==null) {
				listOfConstantTableHashed.input(value+"", hashItem);
			}
			hashItem.index = this.curHashIndex+1;
			
			CONSTANT_Integer_info integer = new CONSTANT_Integer_info(value);
			integer.tag = 3;
			hashItem.constant_info = integer;
			this.listOfConstantTable.setItem(hashItem.index, integer);
			this.curHashIndex += 1;
		//}
	}
	
	/** varUse 가 참조하는 숫자상수 을 가지고 CONSTANT_Integer_info 등을 만들어서 
	 * varUse.constant_info 에 설정하고 
	 * listOfConstantTableHashed 에 CONSTANT_Integer_info 등을 넣는다.
	 * @param varUse
	 * @param numberType : 숫자가 아니면 0을 리턴, char이면 1, short이면 2,
	 * integer이면 3을 리턴, long이면 4를, float이면 5를, double이면 6, byte이면 7을 리턴한다.
	 * 16진수인 경우 CompilerHelper.IsHexa(str)을 참조한다.
	 * 
	 * byte나 short의 경우에는 bipush( byte 를 스택에 push), 
	 * sipush( short 를 스택에 push)를 써야 하므로
	 *  constant table 에 넣지 않는다.
	 *  
	 *  varUse가 0xff0000과 같은 16진수인 경우에는 정수로 바꿔준다.
		createConstantTableIndex()을 참조한다.
	 */
	void makeCONSTANT_Number_infoAndPutItIntolistOfConstantTable(FindVarUseParams varUse, int numberType) {
		String varUseName = varUse.name;
		varUseName = ByteCode_Helper.removeLastCharOfNumber(varUseName);
		/*
		if (numberType==3 || numberType==4) {
			if (Hexa.IsHexa(varUseName)!=0) {
				// 0x0000ff, 0x00ff00 
				if (listOfConstantTableHashed.getData(varUseName)!=null) {
					return;
				}
				HashItemOfConstantTable hashItem = new HashItemOfConstantTable(varUseName, (byte)1);
				if (listOfConstantTableHashed.getData(varUseName)==null) {
					listOfConstantTableHashed.input(varUseName, hashItem);
				}
				
				varUseName = Number.parseHexaIntLong(varUseName);
				String str = varUseName;
				
				hashItem.index = this.curHashIndex+1;
				
				CONSTANT_String_info stringInfo = new CONSTANT_String_info(str);
				stringInfo.tag = 8;
				hashItem.constant_info = stringInfo;
				this.listOfConstantTable.setItem(hashItem.index, stringInfo);			
				
				hashItem.index = this.curHashIndex+2;
				
				CONSTANT_Utf8_info utf8Info = new CONSTANT_Utf8_info((byte)1, 
						(short)str.length(), str);	
				int indexOfUtf8Hashed = hashItem.index;				
				this.listOfConstantTable.setItem(indexOfUtf8Hashed, utf8Info);
				
				stringInfo.string_index = (short) indexOfUtf8Hashed;
				
				this.curHashIndex += 2;
				return;
			}
		}*/
		
		HashItemOfConstantTable hashItem = null;
		switch (numberType) {
		case 1:  break; // char
		case 2:  break; // short
		case 3: //int
			int value = Number.parseInt(varUseName);
			if (Hexa.IsHexa(varUseName)!=0) {
				// 0x0000ff, 0x00ff00 
				if (listOfConstantTableHashed.getData(varUseName)!=null) {
					return;
				}
				hashItem = new HashItemOfConstantTable(varUseName, (byte)1);
				if (listOfConstantTableHashed.getData(varUseName)==null) {
					listOfConstantTableHashed.input(varUseName, hashItem);
				}
			}
			else {
				if (listOfConstantTableHashed.getData(value+"")!=null) {
					return;
				}
				hashItem = new HashItemOfConstantTable(value+"", (byte)1);
				if (listOfConstantTableHashed.getData(value+"")==null) {
					listOfConstantTableHashed.input(value+"", hashItem);
				}
			}
			
			hashItem.index = this.curHashIndex+1;
			
			CONSTANT_Integer_info integer = new CONSTANT_Integer_info(value);
			integer.tag = 3;
			hashItem.constant_info = integer;
			this.listOfConstantTable.setItem(hashItem.index, integer);
			this.curHashIndex += 1;
			break;
		case 4: //long
			/*CONSTANT_Long_info { 
				u1 tag; 
				u4 high_bytes; //8bytes
				u4 low_bytes; 
			}*/
			long valueLong = Number.parseLong(varUseName);
			if (Hexa.IsHexa(varUseName)!=0) {
				// 0x0000ff, 0x00ff00 
				if (listOfConstantTableHashed.getData(varUseName)!=null) {
					return;
				}
				hashItem = new HashItemOfConstantTable(varUseName, (byte)1);
				if (listOfConstantTableHashed.getData(varUseName)==null) {
					listOfConstantTableHashed.input(varUseName, hashItem);
				}
			}
			else {
				if (listOfConstantTableHashed.getData(valueLong+"")!=null) {
					return;
				}
				hashItem = new HashItemOfConstantTable(valueLong+"", (byte)5);
				if (listOfConstantTableHashed.getData(valueLong+"")==null) {
					listOfConstantTableHashed.input(valueLong+"", hashItem);
				}
			}
			
			hashItem.index = this.curHashIndex+1;
			
			CONSTANT_Long_info longInfo = new CONSTANT_Long_info(valueLong);
			longInfo.tag = 5;
			hashItem.constant_info = longInfo;
			this.listOfConstantTable.setItem(hashItem.index, longInfo);
			
			/*All 8-byte constants take up two entries in the constant_pool table of the class
			file. If a CONSTANT_Long_info or CONSTANT_Double_info structure is the item
			in the constant_pool table at index n , then the next usable item in the pool is
			located at index n + 2 . The constant_pool index n + 1 must be valid but is
			considered unusable.*/
			this.curHashIndex += 2;
			break;
		case 5: //float
			/*CONSTANT_Float_info { 
				u1 tag; 
				u4 bytes; //IEEE 754 floating point single format
			}*/
			float valueFloat = Number.parseFloat(varUseName);
			if (listOfConstantTableHashed.getData(valueFloat+"")!=null) {
				return;
			}
			hashItem = new HashItemOfConstantTable(valueFloat+"", (byte)2);
			if (listOfConstantTableHashed.getData(valueFloat+"")==null) {
				listOfConstantTableHashed.input(valueFloat+"", hashItem);
			}
			hashItem.index = this.curHashIndex+1;
			
			CONSTANT_Float_info floatInfo = new CONSTANT_Float_info(valueFloat);
			floatInfo.tag = 4;
			hashItem.constant_info = floatInfo;
			this.listOfConstantTable.setItem(hashItem.index, floatInfo);
			this.curHashIndex += 1;
			break;
		case 6: // double
			/*CONSTANT_Double_info { 
				u1 tag; 
				u4 high_bytes; //8bytes
				u4 low_bytes; 
			}*/
			double valueDouble = Number.parseDouble(varUseName);
			if (listOfConstantTableHashed.getData(valueDouble+"")!=null) {
				return;
			}
			hashItem = new HashItemOfConstantTable(valueDouble+"", (byte)3);
			if (listOfConstantTableHashed.getData(valueDouble+"")==null) {
				listOfConstantTableHashed.input(valueDouble+"", hashItem);
			}
			hashItem.index = this.curHashIndex+1;
			
			CONSTANT_Double_info doubleInfo = new CONSTANT_Double_info(valueDouble);
			doubleInfo.tag = 6;
			hashItem.constant_info = doubleInfo;
			this.listOfConstantTable.setItem(hashItem.index, doubleInfo);
			
			/*All 8-byte constants take up two entries in the constant_pool table of the class
			file. If a CONSTANT_Long_info or CONSTANT_Double_info structure is the item
			in the constant_pool table at index n , then the next usable item in the pool is
			located at index n + 2 . The constant_pool index n + 1 must be valid but is
			considered unusable.*/
			this.curHashIndex += 2;
			break;
		case 7: // byte 
			break;
		}
	}
	
	
	/** Constant table 에 들어가는 CONSTANT_Class_info와 
	 * CONSTANT_Field_info 나 CONSTANT_Method_info 를
	 * 만들어서 Constant table(listOfConstantTableHashed) 에 넣는다.<br>
	 * 
	 * true, false, byte, short 는 constant table 에 넣지 않는다. 
	 * 이것들은 sipush, bipush 를 사용하여 스택에 직접 넣는다.<br>
	 * 
	 * 로컬 변수는 LocalTableEntry의 인덱스를 참조하게 되므로 ConstantTable에 저장하지 않는다.<br>
	 * 
	 * newarray	bc	1: atype	count → arrayref	create new array with count elements of primitive type identified by atype
	 * 와 같이 defaultType의 배열을 생성할 경우 인덱스가 1바이트이므로 constant table(arrOfPrimitiveTypes)에 맨 앞에 넣는다.<br>
	 * 
	 * 배열초기화에서 newarray, anewarray가 사용되므로 배열타입(CONSTANT_Class_info)을 
	 * constant table(arrOfPrimitivesTypes, 해시테이블 listOfConstantTableHashed)에 등록해야 한다.<br>
	 * 
	 * <br><br>
	 * 추가된 타입과 변수, 함수호출은 <br>
	 * 1. 지역변수. 이것은 ConstantTable에 저장하지 않는다.<br>
	 * 2. Compiler.putTryCatchShieldToSynchronizedOrFunction()에서 함수나 synchronized블록에서
	 * 예외가 발생할 경우 호출함수에 발생한 예외를 던지는 기능을 만들기 위해 추가된 try-catch블록에서
	 * 사용되는 java.lang.Exception e 지역변수가 있다. 삭제됨<br>
	 * 3. CompilerHelper.makeFuncCallToDefaultConstructorOfSuperClass()에서 생성자에서 super클래스의
	 * 생성자를 호출하는 문장이 없으면 super클래스의 디폴트 생성자를 호출하는 문장을 자동으로 만들어주기 위해
	 * FindIndependentFuncCallParam(독립적인 함수 호출문)과 varUseSuper(super())를 자동으로 만들어줘야 한다.<br>
	 * 4. 그리고 CompilerHelper.makeDefaultConstructor()와 CompilerHelper.makeStaticConstructor()에서 
	 * 인스턴스 필드와 스태틱 필드를 초기화하기 위해 자동으로 만들어주는 생성자들이 있다.<br>
	 * Compiler.FindAllClassesAndItsMembers2()의 마지막 부분을 참조한다.
	 */
	public void makeConstantTable() {
		
	}
	
	void makeConstantItemsOfExceptionAndThrowable(int coreThreadID) {
		int i;
		
		// CodeAttribute의 exception_table의 Exception_Entry의 catch_type의 
		// CONSTANT_Class_info를 등록한다.
		for (i=0; i<compiler.data.mlistOfAllControlBlocks.count; i++) {
			FindControlBlockParams block = (FindControlBlockParams) compiler.data.mlistOfAllControlBlocks.getItem(i);
			CodeString name = CompilerHelper.getNameOfControlBlock(compiler, block);
			if (name.equals("catch")) {
				FindVarParams exceptionVar = 
					(FindVarParams) block.listOfStatementsInParenthesis.getItem(0);
				if (exceptionVar==null) {
					continue;
				}
				/*FindClassParams classParams = 
						Loader.loadClass(compiler, exceptionVar.typeName);
				String descriptor = TypeDescriptor.getDescriptor(classParams);
				if (this.listOfConstantTableHashed.getData(descriptor)==null) {
					this.listOfConstantTableHashed.input(descriptor, new HashItemOfConstantTable(descriptor, 6, block.nameIndex()));
				}*/
				FindClassParams classParams = 
						Loader.loadClass(compiler, exceptionVar.typeName, coreThreadID);
				String descriptor = TypeDescriptor.getDescriptorExceptLAndSemicolon(classParams, coreThreadID);
				if (this.listOfConstantTableHashed.getData(descriptor)==null) {					
					this.makeCONSTANT_Class_infoAndPutItIntolistOfConstantTable_ExceptLAndSemicolon(descriptor);
				}
			}
			else if (name.equals("finally")) {
				/*FindClassParams classParams = 
						Loader.loadClass(compiler, "java.lang.Throwable");
				String descriptor = TypeDescriptor.getDescriptor(classParams);
				if (this.listOfConstantTableHashed.getData(descriptor)==null) {
					this.listOfConstantTableHashed.input(descriptor, new HashItemOfConstantTable(descriptor, 6, block.nameIndex()));
				}*/
				FindClassParams classParams = 
						Loader.loadClass(compiler, "java.lang.Throwable", coreThreadID);
				String descriptor = TypeDescriptor.getDescriptorExceptLAndSemicolon(classParams, coreThreadID);
				if (this.listOfConstantTableHashed.getData(descriptor)==null) {					
					this.makeCONSTANT_Class_infoAndPutItIntolistOfConstantTable_ExceptLAndSemicolon(descriptor);
				}
			}
		}
	}
	
	/**배열초기화문에서 newarray(디폴트타입), anewarray(오브젝트타입)을 해야 하므로
		배열타입의 varUse를 찾아서 constant table에 그 타입을 등록하고
		constant_info를 배열타입의 varUse에 연결한다.<br>
		int[][] arr = { {}, {} };<br>
		int[][][] arr2 = { { {}, {} }, { {}, {} } };<br> 
		이런 다차원배열인 경우 anewarray에서 int[]을 필요로 한다.<br>
		이런 다차원배열인 경우 anewarray에서 int[][], int[]을 필요로 한다.*/
	/*void makeCONSTANT_info_ArrayInitializer(FindVarUseParams varUse) {
		if (varUse.index()==-1) {
			int a;
			a=0;
			a++;
		}
		int i;
		for (i=0; i<compiler.data.mlistOfAllArrayIntializers.count; i++) {
			FindArrayInitializerParams arr = (FindArrayInitializerParams) compiler.data.mlistOfAllArrayIntializers.getItem(i);
			boolean r = ArrayInitializer.isVarUseOfTypeOfArrayInitializer(arr, varUse);
			if (r) {
				if (varUse.index()==247) {
				}
				this.makeCONSTANT_Class_infoAndPutItIntolistOfConstantTable(varUse);
				
				int dimension = Array.getArrayDimension(compiler, varUse.name);
				if (dimension>1) {
									
					// int[][] arr = { {}, {} };
					// 이런 다차원배열인 경우 anewarray에서 int[]을 필요로 한다.
					// int[][][] arr2 = { { {}, {} }, { {}, {} } };
					// 이런 다차원배열인 경우 anewarray에서 int[][], int[]을 필요로 한다.
					int j, k;
					for (j=0; j<dimension-1; j++) {
						// dimension이 2이면 1
						// dimension이 3이면 2, 1
						int dimensionToPrint = dimension - (j+1);
						String arrDesc = "";
						for (k=0; k<dimensionToPrint; k++) {
							arrDesc += "[";
						}
						String elementTypeDesc = 
							TypeDescriptor.getDescriptor(varUse.originName);
						String typeDesc = arrDesc + elementTypeDesc;
						
						// constant table에 먼저 등록한다.
						if (this.listOfConstantTableHashed.getData(typeDesc)==null) {
							this.listOfConstantTableHashed.input(typeDesc, new HashItemOfConstantTable(typeDesc, 6, varUse.index()));
						}
					}//for (j=0; j<dimension-1; j++) {
				}// if (dimension>1) {
				return;
			}
		}
	}*/
	
	
	/** 일차원배열 constant table(arrOfPrimitivesTypes, 해시테이블 listOfConstantTableHashed)을 만든다.,
	 * arrOfPrimitiveTypes을 일차원배열 constant table에 가장 먼저 넣는다.
	 * listOfConstantTableHashed에서 Hashtable2_String_ForConstantTable.toArray()를 이용해서
	 * 일차원 배열  listOfConstantTable으로 변환된다. 
	 * listOfConstantTableHashed의 해시아이템에 constant table에서의 index를 결정한다.*/
	ArrayList convertArrOfPrimitiveTypesAndListOfConstantTableHashedToConstantTable() {
		// 구문트리를 순회할 때 listOfConstantTableHashed 해시리스트에 넣어진 
		// constant table 아이템(클래스, 필드, 메소드, 스트링, 숫자 등의 상수)을 
		// 일차원 배열로 변환한다.
		ArrayList arrOfConstantTableHashed = listOfConstantTableHashed.toArray();
		arrOfConstantTableHashed = arrOfConstantTableHashed.resize(100+3*listOfConstantTableHashed.count);
		
		int i;
		listOfConstantTable = new ArrayList(100+3*listOfConstantTableHashed.count);			
		
		listOfConstantTable.add(null); // 첫번째 아이템
		
		/*for (i=1; i<this.arrOfPrimitiveTypes.count; i++) {
			String primitive = arrOfPrimitiveTypes.getItem(i);
			CONSTANT_Utf8_info info = 
					new CONSTANT_Utf8_info((byte)1, (short)primitive.length(), primitive);
				listOfConstantTable.add(info);
		}*/		
		
		// 이 함수의 앞부분에서 변환된 배열을 이용하여 hashItem의 인덱스를 정해준다.
		// 정해지는 해시아이템은 CONSTANT_Class_info, CONSTANT_Field_info, CONSTANT_Method_info, 숫자, 스트링 등으로 구성된다. 
		for (i=0; i<arrOfConstantTableHashed.count; i++) {
			HashItemOfConstantTable hashItem = (HashItemOfConstantTable) arrOfConstantTableHashed.getItem(i);
			// arrOfPrimitiveTypes을 일차원배열 constant table에 가장 먼저 넣으므로
			//hashItem.index = 1 + i;
		}
		
		return arrOfConstantTableHashed;
	}
	
	
	
	
	
	/** classParams 하나에 대해 클래스파일을 만들고 showsResult 플래그에 의해 화면에 바이트코드를 출력할 지 안할지를 결정한다. 
	 * @param compiler 
	 * @param classParams : 출력할 클래스
	 * @param showsResult : 바이트코드 결과를 화면에 보여주면 true, 아니면 false
	 * @return
	 */
	HighArray_char printClass(Compiler compiler, FindClassParams classParams, boolean showsResult, int coreThreadID) {		
		this.compiler = compiler;
		if (classParams.isEnum) {
			Enum.processEnumClass(generator, classParams);
		}
		/*if (classParams.isInterface) {
			this.processInterfaceClass(classParams);
		}*/
		
		if (classParams.template!=null) {
			// 클래스파일에서 읽었을 경우에는 classParams.template가 null이다.
			// 이 경우에는 클래스 파일을 로드하거나 클래스 파일이 없으면 소스파일에서 로드한다.
			TemplateBase.applyTypeNameToChangeToTemplateClass(compiler, classParams, classParams.name, (byte)2);
		}
		
		int j;
		
		arrResult = 
				new HighArrayCharForByteCode[classParams.listOfFunctionParams.count];
		
		
				
		if (this.listOfConstantTable==null) {
			listOfConstantTable = new ArrayList(100+3*compiler.data.numOfLines);
		}
		
		
		arrOfClassFieldMethods = new ArrayList(100+classParams.listOfVariableParams.count*2+classParams.listOfFunctionParams.count*2);
		
		curHashIndex = printThisAndSuperAndInterfacesToConstantTable_FirstPassing(classParams, coreThreadID);
		
		printThisAndSuperAndInterfacesToConstantTable_SecondPassing(classParams);
		
		
		
		hashIndexOfField = curHashIndex + 1;
		
		ArrayListIReset backup_listOfVariableParams = classParams.listOfVariableParams;
		ArrayListIReset new_listOfVariableParams = new ArrayListIReset(backup_listOfVariableParams.count); 
		int i;
		for (i=0; i<classParams.listOfVariableParams.count; i++) {
			FindVarParams var = (FindVarParams) classParams.listOfVariableParams.getItem(i);
			if (var.isThis || var.isSuper) continue;
			new_listOfVariableParams.add(var);
		}
		classParams.listOfVariableParams = new_listOfVariableParams;
		
		curHashIndex = printFieldsAndMethodsToConstantTable_FirstPassing(classParams, coreThreadID);
		
		printFieldsAndMethodsToConstantTable_SecondPassing(classParams);
		
		classParams.listOfVariableParams = backup_listOfVariableParams;
		
		
		
		
		hashIndexOfLocalVars = curHashIndex + 1; 
		
		int countOfarrOfHashItemsOfLocalVars = 0;
		for (i=0; i<classParams.listOfFunctionParams.count; i++) {			
			FindFunctionParams func = (FindFunctionParams) classParams.listOfFunctionParams.getItem(i);
			countOfarrOfHashItemsOfLocalVars += 2 * (1+func.listOfVariableParamsBeforeProcessLocalVars.count);
		}		
		arrOfHashItemsOfLocalVars = new ArrayList(countOfarrOfHashItemsOfLocalVars);
		
		curHashIndex = printLocalVarsToConstantTable_FirstPassing(classParams, coreThreadID);
		
		printLocalVarsToConstantTable_SecondPassing(classParams);
		
		
		
		hashIndexOfAttributes = curHashIndex + 1;
		
		arrOfAttributes = new ArrayList(6+1);
		
		curHashIndex = printAttributeToConstantTable_FirstPassing();
		
		printAttributeToConstantTable_SecondPassing();
		
		
		
		hashIndexOfChildClasses = curHashIndex + 1;
		
		arrOfChildClasses = new ArrayList(5);
		
		curHashIndex = makeChildClasses_FirstPassing(classParams, coreThreadID);
		
		makeChildClasses_SecondPassing(classParams, 0, coreThreadID);
		
		
				
		
		CommonGUI.loggingForMessageBox.setText(true, "ByteCodeGeneratorForClass.printFunction() for "+classParams.name+" ...", false);
		CommonGUI.loggingForMessageBox.setHides(false);
		//Control.view.postInvalidate();
		
		
		this.hashIndexOfTheOthers = curHashIndex + 1;
		
	
		
		makeConstantItemsOfExceptionAndThrowable(coreThreadID);
		
		
		// func별 바이트코드를 생성하고 constant table 해시 리스트(listOfConstantTableHashed)에 class, field, method, 상수 등을 넣는다.
		int arrayLimitOfHighArrayCharForByteCode = 1000;
		if (classParams.isInterface) arrayLimitOfHighArrayCharForByteCode = 100;
		for (j=0; j<classParams.listOfFunctionParams.count; j++) {			
			HighArrayCharForByteCode result = new HighArrayCharForByteCode(compiler, arrayLimitOfHighArrayCharForByteCode);
			FindFunctionParams func = (FindFunctionParams) classParams.listOfFunctionParams.getItem(j);
			if (!classParams.isInterface) {
			//if (!func.accessModifier.isAbstract) {
				CommonGUI.loggingForMessageBox.setText(true, "ByteCodeGeneratorForClass.printFunction() for "+
						func.name+" in "+classParams.name+" ...", false);
				CommonGUI.loggingForMessageBox.setHides(false);
				
				generator.printFunction(func, result, coreThreadID);
			//}
			}
			
			arrResult[j] = result;
		}
				
				
		
		
		
		arrResult2 = 
				new HighArray[classParams.listOfFunctionParams.count];
		
		CommonGUI.loggingForMessageBox.setText(true, "Making byte code indices and constant table indices for "+classParams.name+" ...", false);
		CommonGUI.loggingForMessageBox.setHides(false);
		//Control.view.postInvalidate();
		
		// func별 바이트코드 인덱스(라벨, 오프셋)과 constant table인덱스를 생성하고 
		// constant table에 utf8 스트링을 넣어서 완벽하게 한다.
		for (j=0; j<arrResult2.length; j++) {
			HighArrayCharForByteCode result = arrResult[j];
			FindFunctionParams func = (FindFunctionParams) classParams.listOfFunctionParams.getItem(j);
			
			HighArray result2 = 
				result.createConstantTableIndex(generator, listOfConstantTableHashed, 
						/*arrOfPrimitiveTypes,*/ func);
						
			arrResult2[j] = result2;
		}
		
			
		
		this.listOfConstantTable.count = 1 + this.curHashIndex;
		
				
		// 함수별 생성된 code 배열의 결과를 담는다.
		arrResult3 = 
				new HighArray_byte[classParams.listOfFunctionParams.count];
		
		CommonGUI.loggingForMessageBox.setText(true, "Making byte code array for "+classParams.name+" ...", false);
		CommonGUI.loggingForMessageBox.setHides(false);
		//Control.view.postInvalidate();
				
		// 함수별 code 배열을 생성한다.
		int k = 0, m;
		for (j=0; j<arrResult2.length; j++) {
			HighArray result = arrResult2[j];
			arrResult3[j] = new HighArray_byte(300);
			
			////////////////////// 바이트코드에서 첫번째 라인을 처리한다. 시작 ////////////////////
			// 0은 라인번호 혹은 공백이다.
			if (result.count>0) {
				k = 0;
				String lineNumber = (String)result.getItem(k);
				if (Number.isNumber(lineNumber)) {
					for (m=k+1; m<result.count; m++) {
						if (!result.getItem(m).equals(" ")) break;
					}
					if (m<result.count) k = m;
					// k 인덱스의 스트링은 //이거나 instruction 이름
					if (!result.getItem(k).equals("//")) {
						this.makeCodePerInstruction(result, k, arrResult3[j]);
					}
				}
			}
			//////////////////////바이트코드에서 첫번째 라인을 처리한다. 끝 ////////////////////
			
			//////////////////////바이트코드에서 다음 라인을 처리한다. 시작 ////////////////////
			for (k=0; k<result.count; k++) {
				String str = (String)result.getItem(k);
				// \n의 다음 라인을 처리한다.
				int indexOfNewLine = k;
				if (indexOfNewLine==609) {
				}
				if (k+1<result.count && str.equals("\n")) {
					// k+1은 라인번호 혹은 공백이다.
					String lineNumber = (String)result.getItem(k+1);
					if (Number.isNumber(lineNumber)) {
						for (m=k+2; m<result.count; m++) {
							if (!result.getItem(m).equals(" ")) break;
						}
						if (m<result.count) k = m;
						// k 인덱스의 스트링은 //이거나 instruction 이름
						if (!result.getItem(k).equals("//")) {
							this.makeCodePerInstruction(result, k, arrResult3[j]);
						}
						// 현재 라인의 마지막 \n을 찾는다.
						for (m=k+1; m<result.count; m++) {
							if (result.getItem(m).equals("\n")) break;
						}
						if (m<result.count) k = m-1; // 다음 라인의 \n 바로 전 인덱스
						else break; // 마지막 라인의 경우
					} // k+1이 숫자 라인 번호이면
				}
			}
			//////////////////////바이트코드에서 다음 라인을 처리한다. 끝 ////////////////////
		}//for (j=0; j<arrResult2.length; j++) {
		
		CommonGUI.loggingForMessageBox.setText(true, "Making class file for "+classParams.name+" ...", false);
		CommonGUI.loggingForMessageBox.setHides(false);
		//Control.view.postInvalidate();
		
		PathClassWriter.makeClassFile(generator, arrResult3, compiler, coreThreadID);
		
		CompilerStatic.menuProblemList_EditText.setEditTexts(
				CompilerStatic.menuProblemList_EditText.getMenuListEditTexts(CompilerStatic.errors));
		
		if (showsResult) {
			HighArray_char listChar = new HighArray_char(500);
			//HighArray r = new HighArray(500);
			
			this.listOfConstantTable.setItem(0, new Integer(0));
			String typeAndContents = ByteCode_Helper.getConstantTableTypesAndContents(this.listOfConstantTable);
			listChar.add(typeAndContents);
			
			for (j=0; j<arrResult2.length; j++) {
				//CommonGUI.showMessage(true, "arrResult2 j="+j, true);
				FindFunctionParams func = (FindFunctionParams) classParams.listOfFunctionParams.getItem(j);
				listChar.add(func.toString()+"\n");
				HighArray result = arrResult2[j];
				for (k=0; k<result.count; k++) {
					String str = (String)result.getItem(k); 
					//r.add(str);
					listChar.add(str);
				}
				listChar.add("\n");
			}
			
			//String rStr = listChar.getItems();
			
			for (j=0; j<arrResult3.length; j++) {
				/*CommonGUI.showMessage(true, "arrResult3 j="+j, true);
				if (j==35) {
					int a;
					a=0;
					a++;
				}*/
				FindFunctionParams func = (FindFunctionParams) classParams.listOfFunctionParams.getItem(j);
				listChar.add(func.toString()+"\n");
				listChar.add("ByteCode Array Length : "+arrResult3[j].count+"\n");
				listChar.add(arrResult3[j].toString());
				listChar.add("\n\n");
			}
			//listChar.add("\n\n");
			return listChar;
		}
		return null;
		
	}
	
		
	
	
	void processInterfaceClass(FindClassParams classParams) {
		if (classParams.isInterface) {
			if (!CompilerHelper.staticConstructorExists(compiler, classParams)) {
				FindFunctionParams func = CompilerHelper.makeStaticDefaultConstructor(compiler, classParams);
				//func.getLocalVarTableIndexInFunction();
				LocalVar.processLocalVars(func);
			}
			
			if (!CompilerHelper.noneStaticConstructorExists(compiler, classParams)) {
				FindFunctionParams func = CompilerHelper.makeNoneStaticDefaultConstructor(compiler, classParams);
				//func.getLocalVarTableIndexInFunction();
				LocalVar.processLocalVars(func);
			}
			
			FindVarParams varThis = new FindVarParams(compiler, true, false, false, classParams);
			FindVarParams varSuper = new FindVarParams(compiler, false, false, true, classParams);
			AccessModifier accessModifierThis = new AccessModifier(compiler, -1, -1);
			AccessModifier accessModifierSuper = new AccessModifier(compiler, -1, -1);
			varThis.accessModifier = accessModifierThis;
			varSuper.accessModifier = accessModifierSuper;
			
			classParams.listOfVariableParams.add(varThis);
			classParams.listOfVariableParams.add(varSuper);
			
			
			int i;
			for (i=0; i<classParams.listOfFunctionParams.count; i++) {
				FindFunctionParams func = (FindFunctionParams) classParams.listOfFunctionParams.getItem(i);
				FindVarParams varThis2 = new FindVarParams(compiler, true, false, false, classParams);
				func.thisVar = varThis2;
			}
		
			
		}
	}
	
	
	
	/**classParams의 this와 super와 interface들을 listOfConstantTableHashed, listOfConstantTableUtf8Hashed에 넣는다.*/
	int printThisAndSuperAndInterfacesToConstantTable_FirstPassing(FindClassParams classParams, int coreThreadID) {
		// L이 안붙는 타입디스크립터 this를 쓴다.
		String classDesc = TypeDescriptor.getDescriptorExceptLAndSemicolon(classParams, coreThreadID);
		HashItemOfConstantTable hashItem = null;
		
		hashItem = new HashItemOfConstantTable(classDesc, 6);
		if (listOfConstantTableHashed.getData(classDesc)==null) {
			this.listOfConstantTableHashed.input(classDesc, hashItem);
		}
		hashItem.index = 1;
		arrOfClassFieldMethods.add(hashItem);
		
		hashItem = new HashItemOfConstantTable(classDesc, 11);
		if (listOfConstantTableUtf8Hashed.getData(classDesc)==null) {
			this.listOfConstantTableUtf8Hashed.input(classDesc, hashItem);
		}
		hashItem.index = 2;
		arrOfClassFieldMethods.add(hashItem);
		
		
		
		// super를 쓴다.
		String superClassDesc = TypeDescriptor.getDescriptorExceptLAndSemicolon(classParams.classToExtend, coreThreadID);
		HashItemOfConstantTable hashItemSuper = new HashItemOfConstantTable(superClassDesc, 6);
		if (listOfConstantTableHashed.getData(superClassDesc)==null) {
			this.listOfConstantTableHashed.input(superClassDesc, hashItemSuper);
		}
		hashItemSuper.index = 3;
		arrOfClassFieldMethods.add(hashItemSuper);
		
		hashItemSuper = new HashItemOfConstantTable(superClassDesc, 11);
		if (listOfConstantTableUtf8Hashed.getData(superClassDesc)==null) {
			this.listOfConstantTableUtf8Hashed.input(superClassDesc, hashItemSuper);
		}
		hashItemSuper.index = 4;
		arrOfClassFieldMethods.add(hashItemSuper);
		
		int curHashIndex = 4;
		
		
		int i;
		if (classParams.interfacesToImplement!=null) {
			for (i=0; i<classParams.interfacesToImplement.count; i++) {
				String interfaceDesc = 
						TypeDescriptor.getDescriptorExceptLAndSemicolon((FindClassParams)classParams.interfacesToImplement.getItem(i), coreThreadID);
				HashItemOfConstantTable hashItemInterface = new HashItemOfConstantTable(interfaceDesc, 6);
				if (listOfConstantTableHashed.getData(interfaceDesc)==null) {
					this.listOfConstantTableHashed.input(interfaceDesc, hashItemInterface);
				}
				hashItemInterface.index = curHashIndex+1 + 2 * i;
				arrOfClassFieldMethods.add(hashItemInterface);
				
				hashItemInterface = new HashItemOfConstantTable(interfaceDesc, 11);
				if (listOfConstantTableUtf8Hashed.getData(interfaceDesc)==null) {
					this.listOfConstantTableUtf8Hashed.input(interfaceDesc, hashItemInterface);
				}
				hashItemInterface.index = curHashIndex+2 + 2 * i;
				arrOfClassFieldMethods.add(hashItemInterface);
			}
		}//if (classParams.interfacesToImplement!=null) {
		
		if (classParams.interfacesToImplement!=null) {
			curHashIndex = curHashIndex +  2 * classParams.interfacesToImplement.count;
		}
		return curHashIndex;
	}
	
	
	/**classParams의 this와 super와 interface들을 constant table에 쓴다.*/
	void printThisAndSuperAndInterfacesToConstantTable_SecondPassing(FindClassParams classParams) {
		// L이 붙지 않는 타입 디스크립터 this를 쓴다.
		HashItemOfConstantTable hashItem = (HashItemOfConstantTable) arrOfClassFieldMethods.getItem(0);
		CONSTANT_Class_info classInfo = new CONSTANT_Class_info(hashItem.descriptor, compiler);
		classInfo.tag = 7;
		this.listOfConstantTable.setItem(hashItem.index, classInfo);
		
		
		hashItem = (HashItemOfConstantTable) arrOfClassFieldMethods.getItem(1);
		CONSTANT_Utf8_info utf8Info = new CONSTANT_Utf8_info((byte)1, 
				(short)hashItem.descriptor.length(), hashItem.descriptor);
		this.listOfConstantTable.setItem(hashItem.index, utf8Info);
		
		classInfo.name_index = hashItem.index;
		
		
		
		
		// super를 쓴다.
		hashItem = (HashItemOfConstantTable) arrOfClassFieldMethods.getItem(2);
		classInfo = new CONSTANT_Class_info(hashItem.descriptor, compiler);
		classInfo.tag = 7;
		this.listOfConstantTable.setItem(hashItem.index, classInfo);
		
		hashItem = (HashItemOfConstantTable) arrOfClassFieldMethods.getItem(3);
		utf8Info = new CONSTANT_Utf8_info((byte)1, 
				(short)hashItem.descriptor.length(), hashItem.descriptor);
		this.listOfConstantTable.setItem(hashItem.index, utf8Info);
		
		classInfo.name_index = hashItem.index;
		
		int i;
		if (classParams.interfacesToImplement!=null) {
			for (i=0; i<classParams.interfacesToImplement.count; i++) {
				hashItem = (HashItemOfConstantTable) arrOfClassFieldMethods.getItem(4+2*i);
				classInfo = new CONSTANT_Class_info(hashItem.descriptor, compiler);
				classInfo.tag = 7;
				this.listOfConstantTable.setItem(hashItem.index, classInfo);
				
				hashItem = (HashItemOfConstantTable) arrOfClassFieldMethods.getItem(4+2*i+1);
				utf8Info = new CONSTANT_Utf8_info((byte)1, 
						(short)hashItem.descriptor.length(), hashItem.descriptor);
				this.listOfConstantTable.setItem(hashItem.index, utf8Info);
				
				classInfo.name_index = hashItem.index;
			}
		}//if (classParams.interfacesToImplement!=null) {
	}
	
	
	/** 사용자가 소스에서 어떤 노드를 클릭할 때마다 구문트리를 순회하고 constant table을 만든다.
	 * printClass()와는 다르게 문장이나 제어구조, 함수를 클릭할때 바이트코드를 만든다.*/
	String makeByteCodeIndicesAndUpdateConstantTable(HighArrayCharForByteCode byteCodeResult, FindFunctionParams func) {
				
		//this.convertArrOfPrimitiveTypesAndListOfConstantTableHashedToConstantTable();
		//byteCodeResult.createByteCodeIndex();
		HighArray result = 
			byteCodeResult.createConstantTableIndex(generator, listOfConstantTableHashed, 
					/*arrOfPrimitiveTypes,*/ func);
		
		
		this.listOfConstantTable.count = 1  + 
				this.curHashIndex;
		
		String r = byteCodeResult.toString(result);
		if (result!=null) {
			result.destroy();
		}
		return r;
	}
	
	
	
	
	int getCountOflistOfConstantTable_MinusCONSTANT_Utf8_info() {
		return 1 /*this.arrOfPrimitiveTypes.count*/ + this.listOfConstantTableHashed.count;
	}
	
	
	
	int getIndexOflistOfConstantTable(int indexOfUtf8Hashed) {
		return  1 /*this.arrOfPrimitiveTypes.count*/ + 
				this.listOfConstantTableHashed.count + indexOfUtf8Hashed;
	}
	
	
	
	
	
	/**classParams의 모든 함수들에 있는 지역변수들의 name과 typeDesc을 listOfConstantTableUtf8Hashed에 넣는다.
	 * @param curHashIndex */
	int printLocalVarsToConstantTable_FirstPassing(FindClassParams classParams, int coreThreadID) {
		int i, j;		
		
		
		String classDesc = TypeDescriptor.getDescriptor(classParams.name, coreThreadID);
		//String classDesc = TypeDescriptor.getDescriptorExceptLAndSemicolon(classParams.name, coreThreadID);
		HashItemOfConstantTable hashItem = null;
		
				
		String name = "this";
		hashItem = new HashItemOfConstantTable(name, 11);
		if (listOfConstantTableUtf8Hashed.getData(name)==null) {
			this.listOfConstantTableUtf8Hashed.input(name, hashItem);
		}
		hashItem.index = curHashIndex+1;
		arrOfHashItemsOfLocalVars.add(hashItem);
		
		hashItem = new HashItemOfConstantTable(classDesc, 11);
		if (listOfConstantTableUtf8Hashed.getData(classDesc)==null) {
			this.listOfConstantTableUtf8Hashed.input(classDesc, hashItem);
		}
		hashItem.index = curHashIndex+2;
		arrOfHashItemsOfLocalVars.add(hashItem);
		
		curHashIndex += 2;
				
		for (i=0; i<classParams.listOfFunctionParams.count; i++) {
			FindFunctionParams func = (FindFunctionParams) classParams.listOfFunctionParams.getItem(i);
			
			// 모든 함수들에 대해서
			for (j=0; j<func.listOfVariableParamsBeforeProcessLocalVars.count; j++) {
				FindVarParams var = (FindVarParams) func.listOfVariableParamsBeforeProcessLocalVars.getItem(j);
				String typeDesc = TypeDescriptor.getDescriptor(var, coreThreadID);
				//String typeDesc = TypeDescriptor.getDescriptorExceptLAndSemicolon(var, coreThreadID);
				
				name = var.fieldName;
				hashItem = new HashItemOfConstantTable(name, 11);
				if (listOfConstantTableUtf8Hashed.getData(name)==null) {
					this.listOfConstantTableUtf8Hashed.input(name, hashItem);
				}				
				hashItem.index = curHashIndex+1 + 2*j;
				arrOfHashItemsOfLocalVars.add(hashItem);
				
				hashItem = new HashItemOfConstantTable(typeDesc, 11);
				if (listOfConstantTableUtf8Hashed.getData(typeDesc)==null) {
					this.listOfConstantTableUtf8Hashed.input(typeDesc, hashItem);
				}
				hashItem.index = curHashIndex+2 + 2*j;
				arrOfHashItemsOfLocalVars.add(hashItem);
			}
			curHashIndex += 2*func.listOfVariableParamsBeforeProcessLocalVars.count;
		}//for (i=0; i<classParams.listOfFunctionParams.count; i++) {
		
		return curHashIndex;
	}
	
	/**classParams의 모든 함수들에 있는 지역변수들의 name과 typeDesc을 constant table에 쓴다.*/
	void printLocalVarsToConstantTable_SecondPassing(FindClassParams classParams) {
		int i, j;
		int indexInarrOfHashItemsOfLocalVars = 0;
				
		// StackMapTable_entry의 cpool_index를 쓰기 위해서 L이 붙는 타입 디스크립터 this를 쓴다.
		/*HashItemOfConstantTable hashItem = (HashItemOfConstantTable) arrOfHashItemsOfLocalVars.getItem(0);
		CONSTANT_Class_info classInfo = new CONSTANT_Class_info(hashItem.descriptor, compiler);
		classInfo.tag = 7;
		this.listOfConstantTable.setItem(hashItem.index, classInfo);*/
		
		String name = "this";
		HashItemOfConstantTable hashItem = (HashItemOfConstantTable) arrOfHashItemsOfLocalVars.getItem(0);
		CONSTANT_Utf8_info utf8Info = new CONSTANT_Utf8_info((byte)1, 
				(short)hashItem.descriptor.length(), hashItem.descriptor);
		this.listOfConstantTable.setItem(hashItem.index, utf8Info);
		
		//classInfo.name_index = hashItem.index;
		
		
		hashItem = (HashItemOfConstantTable) arrOfHashItemsOfLocalVars.getItem(1);
		utf8Info = new CONSTANT_Utf8_info((byte)1, 
				(short)hashItem.descriptor.length(), hashItem.descriptor);
		this.listOfConstantTable.setItem(hashItem.index, utf8Info);
		
		indexInarrOfHashItemsOfLocalVars = 1;
					
		
		for (i=0; i<classParams.listOfFunctionParams.count; i++) {
			FindFunctionParams func = (FindFunctionParams) classParams.listOfFunctionParams.getItem(i);
			
			// 모든 함수들에 대해서
			for (j=0; j<func.listOfVariableParamsBeforeProcessLocalVars.count; j++) {
				FindVarParams var = (FindVarParams) func.listOfVariableParamsBeforeProcessLocalVars.getItem(j);
				
				// stackMapTable의 Verification_Type_info를 위해서 firstPassing에서 넣어진 CONSTANT_Class_info의 자리를 얻는다.
				
				/*hashItem = (HashItemOfConstantTable) arrOfHashItemsOfLocalVars.getItem(indexInarrOfHashItemsOfLocalVars+1+3*j);
				classInfo = new CONSTANT_Class_info(hashItem.descriptor, compiler);
				classInfo.tag = 7;
				this.listOfConstantTable.setItem(hashItem.index, classInfo);*/
				
				name = var.fieldName;
				
				hashItem = (HashItemOfConstantTable) arrOfHashItemsOfLocalVars.getItem(indexInarrOfHashItemsOfLocalVars+1+2*j);
				utf8Info = new CONSTANT_Utf8_info((byte)1, 
						(short)hashItem.descriptor.length(), hashItem.descriptor);
				this.listOfConstantTable.setItem(hashItem.index, utf8Info);
				
				//classInfo.name_index = hashItem.index;
				
				
				hashItem = (HashItemOfConstantTable) arrOfHashItemsOfLocalVars.getItem(indexInarrOfHashItemsOfLocalVars+2+2*j);
				utf8Info = new CONSTANT_Utf8_info((byte)1, 
						(short)hashItem.descriptor.length(), hashItem.descriptor);
				this.listOfConstantTable.setItem(hashItem.index, utf8Info);
					
			}
			indexInarrOfHashItemsOfLocalVars += 2*func.listOfVariableParamsBeforeProcessLocalVars.count;
			
		}//for (i=0; i<classParams.listOfFunctionParams.count; i++) {
	}
	
	
	/**classParams의 field와 method들의 name과 typeDesc을 listOfConstantTableHashed, listOfConstantTableUtf8Hashed에 넣는다.
	 * @param curHashIndex 
	 * @param arrOfClassFieldMethods 
	 * @return */
	int printFieldsAndMethodsToConstantTable_FirstPassing(FindClassParams classParams, int coreThreadID) {
		int i;
				
		// fields를 쓴다.
		for (i=0; i<classParams.listOfVariableParams.count; i++) {
			FindVarParams field = (FindVarParams) classParams.listOfVariableParams.getItem(i);
			String typeDesc = TypeDescriptor.getDescriptor(field, coreThreadID);
			HashItemOfConstantTable hashItem = new HashItemOfConstantTable(typeDesc, 11);
			if (listOfConstantTableUtf8Hashed.getData(typeDesc)==null) {
				this.listOfConstantTableUtf8Hashed.input(typeDesc, hashItem);
			}
			hashItem.index = curHashIndex+1 + 2 * i;
			arrOfClassFieldMethods.add(hashItem);
			
			
			
			String name = field.fieldName;
			hashItem = new HashItemOfConstantTable(name, 11);
			if (listOfConstantTableUtf8Hashed.getData(name)==null) {
				this.listOfConstantTableUtf8Hashed.input(name, hashItem);
			}
			hashItem.index = (curHashIndex+2) + 2 * i;
			arrOfClassFieldMethods.add(hashItem);
		}//for (i=0; i<classParams.listOfVariableParams.count; i++) {
		
		curHashIndex +=  2 * classParams.listOfVariableParams.count;
		
		
		// methods를 쓴다.
		for (i=0; i<classParams.listOfFunctionParams.count; i++) {
			FindFunctionParams method = (FindFunctionParams) classParams.listOfFunctionParams.getItem(i);
			String typeDesc = TypeDescriptor.getDescriptor(method, coreThreadID);
			HashItemOfConstantTable hashItem = new HashItemOfConstantTable(typeDesc, 11);
			if (listOfConstantTableUtf8Hashed.getData(typeDesc)==null) {
				this.listOfConstantTableUtf8Hashed.input(typeDesc, hashItem);
			}
			hashItem.index = curHashIndex+1 + 2 * i;
			arrOfClassFieldMethods.add(hashItem);
			
			String name = method.name;
			if (method.isConstructor) {
				if (method.isConstructorThatInitializesStaticFields)
					name = "<clinit>";
				else name = "<init>";
			}
			hashItem = new HashItemOfConstantTable(name, 11);
			if (listOfConstantTableUtf8Hashed.getData(name)==null) {
				this.listOfConstantTableUtf8Hashed.input(name, hashItem);
			}
			hashItem.index = (curHashIndex+2) + 2 * i;
			arrOfClassFieldMethods.add(hashItem);
		}//for (i=0; i<classParams.listOfFunctionParams.count; i++) {
		
		curHashIndex +=  2 * classParams.listOfFunctionParams.count;
		
		return curHashIndex;
	}
	
	/**classParams의 field와 method들의 name과 typeDesc을 constant table에 쓴다.
	 * @param arrOfClassFieldMethods, int hashIndexOfField */
	void printFieldsAndMethodsToConstantTable_SecondPassing(FindClassParams classParams) {
		int i;
		
		int curHashIndex = hashIndexOfField-1;
		
		// fields를 쓴다.
		for (i=0; i<classParams.listOfVariableParams.count; i++) {
			
			HashItemOfConstantTable hashItem = 
					(HashItemOfConstantTable) arrOfClassFieldMethods.getItem(curHashIndex+1+2*i-1);
			CONSTANT_Utf8_info utf8Info = new CONSTANT_Utf8_info((byte)1, 
					(short)hashItem.descriptor.length(), hashItem.descriptor);
			this.listOfConstantTable.setItem(hashItem.index, utf8Info);
			
			hashItem = (HashItemOfConstantTable) arrOfClassFieldMethods.getItem(curHashIndex+2+2*i-1);
			utf8Info = new CONSTANT_Utf8_info((byte)1, 
					(short)hashItem.descriptor.length(), hashItem.descriptor);
			this.listOfConstantTable.setItem(hashItem.index, utf8Info);
		}//for (i=0; i<classParams.listOfVariableParams.count; i++) {
		
		curHashIndex += 2*classParams.listOfVariableParams.count;
		
		
		
		// methods를 쓴다.
		for (i=0; i<classParams.listOfFunctionParams.count; i++) {
			HashItemOfConstantTable hashItem = (HashItemOfConstantTable) arrOfClassFieldMethods.getItem(curHashIndex+1+2*i-1);
			CONSTANT_Utf8_info utf8Info = new CONSTANT_Utf8_info((byte)1, 
					(short)hashItem.descriptor.length(), hashItem.descriptor);
			this.listOfConstantTable.setItem(hashItem.index, utf8Info);
			
		
			hashItem = (HashItemOfConstantTable) arrOfClassFieldMethods.getItem(curHashIndex+2+2*i-1);
			utf8Info = new CONSTANT_Utf8_info((byte)1, 
					(short)hashItem.descriptor.length(), hashItem.descriptor);
			this.listOfConstantTable.setItem(hashItem.index, utf8Info);
		}//for (i=0; i<classParams.listOfFunctionParams.count; i++) {
		
		curHashIndex += 2*classParams.listOfFunctionParams.count;
	}
	
	/** "Code", "LocalVariableTable", "StackMapTable", "LineNumberTable", "SourceFile"을  listOfConstantTableUtf8Hashed에 넣는다.
	 * @param curHashIndex */
	int printAttributeToConstantTable_FirstPassing() {
		String[] arrUtf8Str = {"Code", "LocalVariableTable", "StackMapTable", "InnerClasses", "LineNumberTable", "SourceFile"};
		
		//ArrayList arrOfAttributes = new ArrayList(arrUtf8Str.length+1);
		int i;
		for (i=0; i<arrUtf8Str.length; i++) {
			String utf8Str = arrUtf8Str[i];
			HashItemOfConstantTable hashItem = new HashItemOfConstantTable(utf8Str, 11);
			if (listOfConstantTableUtf8Hashed.getData(utf8Str)==null) {
				this.listOfConstantTableUtf8Hashed.input(utf8Str, hashItem);			
			}
			hashItem.index = curHashIndex+1+i;
			arrOfAttributes.add(hashItem);
		}
		
		curHashIndex += arrUtf8Str.length;
		
		String sourceFileName = FileHelper.getFilename(compiler.data.filename);
		HashItemOfConstantTable hashItem = new HashItemOfConstantTable(sourceFileName, 11);
		if (listOfConstantTableUtf8Hashed.getData(sourceFileName)==null) {
			this.listOfConstantTableUtf8Hashed.input(sourceFileName, hashItem);			
		}
		hashItem.index = curHashIndex+1;
		arrOfAttributes.add(hashItem);
		
		curHashIndex++;
		
		return curHashIndex;
	}
	
	/** "Code", "LocalVariableTable", "StackMapTable", "LineNumberTable", "SourceFile"을 ConstantTable에 쓴다.
	 * @param arrOfAttributes */
	void printAttributeToConstantTable_SecondPassing() {
		String[] arrUtf8Str = {"Code", "LocalVariableTable", "StackMapTable", "InnerClasses", "LineNumberTable", "SourceFile"};
		
		int i;
		for (i=0; i<arrUtf8Str.length; i++) {
			String utf8Str = arrUtf8Str[i];
			HashItemOfConstantTable hashItem = 
				(HashItemOfConstantTable) arrOfAttributes.getItem(i);
			CONSTANT_Utf8_info utf8Info = new CONSTANT_Utf8_info((byte)1, 
					(short)hashItem.descriptor.length(), hashItem.descriptor);
			this.listOfConstantTable.setItem(hashItem.index, utf8Info);
		}
		
		String sourceFileName = FileHelper.getFilename(compiler.data.filename);
		HashItemOfConstantTable hashItem = 
				(HashItemOfConstantTable) arrOfAttributes.getItem(arrUtf8Str.length);
		CONSTANT_Utf8_info utf8Info = new CONSTANT_Utf8_info((byte)1, 
					(short)hashItem.descriptor.length(), hashItem.descriptor);
		this.listOfConstantTable.setItem(hashItem.index, utf8Info);
	}
	
	/**classParams의 innerClass, outerClass, simpleName들을 listOfConstantTableHashed, listOfConstantTableUtf8Hashed에 넣는다.*/
	int makeChildClasses_FirstPassing(FindClassParams classParams, int coreThreadID) {
		int i;
		// 자식 클래스부터 호출
		for (i=0; i<classParams.childClasses.count; i++) {
			FindClassParams child = (FindClassParams) classParams.childClasses.getItem(i);
			curHashIndex = makeChildClasses_FirstPassing(child, coreThreadID);
		}
		
		// 현재 클래스의 innerClass, outerClass, simpleName을 해시테이블에 쓴다. 
		
		// innerClass
		String descriptor = TypeDescriptor.getDescriptorExceptLAndSemicolon(classParams, coreThreadID);		
		HashItemOfConstantTable hashItem = new HashItemOfConstantTable(descriptor, 6);
		if (listOfConstantTableHashed.getData(descriptor)==null) {
			listOfConstantTableHashed.input(descriptor, hashItem); 			
		}
		arrOfChildClasses.add(hashItem);
		hashItem.index = curHashIndex+1;
		
		hashItem = new HashItemOfConstantTable(descriptor, 11);
		if (listOfConstantTableUtf8Hashed.getData(descriptor)==null) {
			listOfConstantTableUtf8Hashed.input(descriptor, hashItem); 			
		}
		arrOfChildClasses.add(hashItem);
		hashItem.index = curHashIndex+2;
		
		curHashIndex+=2;
				
		// outerClass
		if (classParams.parent!=null) {
			FindClassParams outerClass = (FindClassParams)classParams.parent;
			descriptor = TypeDescriptor.getDescriptorExceptLAndSemicolon(outerClass, coreThreadID);
			hashItem = new HashItemOfConstantTable(descriptor, 6);
			if (listOfConstantTableHashed.getData(descriptor)==null) {
				listOfConstantTableHashed.input(descriptor, hashItem);						
			}
			arrOfChildClasses.add(hashItem);
			hashItem.index = curHashIndex+1;
			
			hashItem = new HashItemOfConstantTable(descriptor, 11);
			if (listOfConstantTableUtf8Hashed.getData(descriptor)==null) {
				listOfConstantTableUtf8Hashed.input(descriptor, hashItem);						
			}
			arrOfChildClasses.add(hashItem);
			hashItem.index = curHashIndex+2;
			
			curHashIndex+=2;
		}
		
		
		
		String simpleName = CompilerHelper.getShortName(classParams.name);
		hashItem = new HashItemOfConstantTable(simpleName, 11);
		if (listOfConstantTableUtf8Hashed.getData(simpleName)==null) {
			listOfConstantTableUtf8Hashed.input(simpleName, hashItem);
		}
		arrOfChildClasses.add(hashItem);
		hashItem.index = curHashIndex+1;
		
		curHashIndex++;
		
		return curHashIndex;
	}
	
	/**classParams의 innerClass, outerClass, simpleName들의  CONSTANT_Class_info, CONSTANT_Utf8_info들을
	 * listOfConstantTable에 쓴다.
	 * @param arrOfChildClasses */
	int makeChildClasses_SecondPassing(FindClassParams classParams, int indexInarrOfChildClasses, int coreThreadID) {
		int i;
		int curIndex = indexInarrOfChildClasses;
		// 자식 클래스부터 호출
		for (i=0; i<classParams.childClasses.count; i++) {
			FindClassParams child = (FindClassParams) classParams.childClasses.getItem(i);
			curIndex = makeChildClasses_SecondPassing(child, curIndex, coreThreadID);
		}
		
		// 현재 클래스의 innerClass, outerClass, simpleName을 해시테이블에 쓴다. 
		
		// innerClass
		String descriptor = TypeDescriptor.getDescriptorExceptLAndSemicolon(classParams, coreThreadID);
	
		HashItemOfConstantTable hashItem = (HashItemOfConstantTable) arrOfChildClasses.getItem(curIndex);
		CONSTANT_Class_info classInfo = new CONSTANT_Class_info(descriptor, compiler);
		classInfo.tag = 7;
		this.listOfConstantTable.setItem(hashItem.index, classInfo);
		
		curIndex++;
		
		hashItem = (HashItemOfConstantTable) arrOfChildClasses.getItem(curIndex);
		CONSTANT_Utf8_info utf8Info = new CONSTANT_Utf8_info((byte)1, 
				(short)hashItem.descriptor.length(), hashItem.descriptor);
		this.listOfConstantTable.setItem(hashItem.index, utf8Info);
		
		classInfo.name_index = hashItem.index;
		
		curIndex++;
		
				
		// outerClass
		if (classParams.parent!=null) {
			descriptor = TypeDescriptor.getDescriptorExceptLAndSemicolon((FindClassParams)classParams.parent, coreThreadID);
			
			hashItem = (HashItemOfConstantTable) arrOfChildClasses.getItem(curIndex);
			classInfo = new CONSTANT_Class_info(descriptor, compiler);
			classInfo.tag = 7;
			this.listOfConstantTable.setItem(hashItem.index, classInfo);
			
			curIndex++;
			
			
			hashItem = (HashItemOfConstantTable) arrOfChildClasses.getItem(curIndex);
			utf8Info = new CONSTANT_Utf8_info((byte)1, 
					(short)hashItem.descriptor.length(), hashItem.descriptor);
			this.listOfConstantTable.setItem(hashItem.index, utf8Info);
			
			curIndex++;
			
			classInfo.name_index = hashItem.index;
		}
		
		// simpleName
		String simpleName = CompilerHelper.getShortName(classParams.name);
		hashItem = (HashItemOfConstantTable) arrOfChildClasses.getItem(curIndex);
		utf8Info = new CONSTANT_Utf8_info((byte)1, 
				(short)hashItem.descriptor.length(), hashItem.descriptor);
		this.listOfConstantTable.setItem(hashItem.index, utf8Info);
		
		curIndex++;
		
		return curIndex;
		
	}
	
	/** input에서 startIndex부터 instruction과 instruction의 인덱스를 찾아 result에 바이트 배열을 쓴다.
	 * @param startIndex : input에서 명령어(코드) index*/
	void makeCodePerInstruction(HighArray input, int startIndex, HighArray_byte result) {
		String instructionName = null;
		String code = (String) input.getItem(startIndex);
		if (!code.equals("//")) {				
			instructionName = code;
		}
		else {
			return;
		}
		
		if (instructionName.equals("multianewarray")) {
		}
		
		
		
		int i;
		// 값을 찾는다.
		for (i=startIndex+1; i<input.count; i++) {
			if (!input.getItem(i).equals(" ")) break;
		}
		int value = -1;
		String next = (String)input.getItem(i);
		try {
		if (i<input.count && !next.equals("//") && !next.equals("\n")) {
			//  aload_0   // L****;	이런 경우 next는 //
			//  dup			이런 경우 next는 \n 이 된다.
			if (Hexa.IsHexa(next)!=0) {
				value = Hexa.getHexaValue(next);
			}
			else {
				value = Integer.parseInt(next);
			}
		}
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
		}
		byte[] byteIndex = null;
		
		ByteCodeInstruction instruction = 
				(ByteCodeInstruction) ByteCodeGeneratorForClass.hashTableInstructionSet.getData(instructionName);
		
		if (instruction==null) {
			if (instructionName.equals("low") || instructionName.equals("high") ||
					instructionName.equals("offset") || instructionName.equals("offsetEnd") || 
					instructionName.equals("count")) {
				
				// switch의 case에서 분기할 주소를 출력할 때 low, high, 분기주소(offset)는 
				// instruction이 아니므로 null이 된다.
				
				// defaultOffset 부터 low, high, offset들은 모두 little endian으로 써야 한다.
				// CodeAttribute.processTableSwitch()에서 바이트를 읽으므로 참조한다.
			
				
				
				// tableswitch의 마지막 오프셋의 LSB 바이트가 tableswitch의 다음 명령어(아래 예에서는 fload_0)를 대신하는 바이트코드가 된다.
				// tableswitch의 마지막 오프셋은 0이 아닌  LSB 바이트가 tableswitch의 다음 명령어(아래 예에서는 fload_0)가 되고 
				// 0인 바이트들은 추가되는 패딩바이트(아래 예에서는 원래 패딩바이트 1개에서 추가된 3바이트가 된다)가 된다.
				// fload_0의 다음 명령어는 4바이트 정렬이 되어 있어야 한다.
				// 206        tableswitch #0 #0 #0 #0 #34 #0 #4 #34 #34 #34 #34;  [] // (  Default Offset : 34 Low : 0 High : 4 Offset :(0, 34)  (1, 34)  (2, 34)  (3, 34)   )
				// 239        fload_0;  [] // ( [Ljava/lang/String; args )
				// 240        return;  [] //
				
				
				// 206        tableswitch 34 1      // (587), exit of switch (a)
				// 212        low            0
				// 216        high            4
				// 220        offset 34        // (527), case  0:
				// 224        offset 34        // (541), case  1:
				// 228        offset 34        // (587), exit of switch (a)
				// 232        offset 34        // (555), case  3:
				// 236        offsetEnd 34        // (573), case  4:
				           // offset addresses end 
				           // (527), case  0:
				           // (541), case  1:
				           // (555), case  3:
				           // (573), case  4:
				           // (587), exit of switch (a)
				// 240        return         
				
				if (instructionName.equals("low")) {
					mLowOfSwitch = value; 
				}
				else if (instructionName.equals("high")) {
					mHighOfSwitch = value; 
				}
				else if (instructionName.equals("offset")) {
					mListOfOffsetsOfSwitch.add(value); 
				}
				else if (instructionName.equals("count")) {
					this.mCountOfLookupSwitch = value;
				}
				else if (instructionName.equals("offsetEnd")) {
					
					IO.toBytes(mOpcodeHexaOfSwitch, false, IO.arrByte_Len2);
					byteIndex = IO.arrByte_Len2;
					result.add(byteIndex[byteIndex.length-1]); // 명령어 코드 1바이트 쓰기
					
				
					int countOfPadding = this.mCountOfPaddingOfSwitch;
					// 패딩 바이트 쓰기
					int k;
					for (k=0; k<countOfPadding; k++) {
						result.add((byte)0);
					}
					
					boolean isReverse = false;
				
					
					IO.toBytes(this.mDefaultAddressOfSwitch, mIsLittleEndianOfSwitch, IO.arrByte_Len4);
					byteIndex = IO.arrByte_Len4;
					// 4바이트 쓰기, 디폴트 어드레스
					writeBuffer(byteIndex, isReverse, result);
					
					IO.toBytes(this.mLowOfSwitch, mIsLittleEndianOfSwitch, IO.arrByte_Len4);
					byteIndex = IO.arrByte_Len4;
					writeBuffer(byteIndex, isReverse, result);
					
					IO.toBytes(this.mHighOfSwitch, mIsLittleEndianOfSwitch, IO.arrByte_Len4);
					byteIndex = IO.arrByte_Len4;
					writeBuffer(byteIndex, isReverse, result);
					
					mListOfOffsetsOfSwitch.add(value);
					
					for (k=0; k<this.mListOfOffsetsOfSwitch.count; k++) {
						IO.toBytes(mListOfOffsetsOfSwitch.getItem(k), mIsLittleEndianOfSwitch, IO.arrByte_Len4);
						byteIndex = IO.arrByte_Len4;
						writeBuffer(byteIndex, isReverse, result);
					}					
				
				}//else if (instructionName.equals("offsetEnd")) {
			} // if (instructionName.equals("low") || instructionName.equals("high") ||
			// instructionName.equals("offset") || instructionName.equals("offsetEnd") || 
			// instructionName.equals("count")) {
			
			else if (instructionName.contains("offsetEnd_Lookup")) {				
				
				IO.toBytes(mOpcodeHexaOfSwitch, false, IO.arrByte_Len2);
				byteIndex = IO.arrByte_Len2;
				result.add(byteIndex[byteIndex.length-1]); // 명령어 코드 1바이트 쓰기
				
			
				int countOfPadding = this.mCountOfPaddingOfSwitch;
				// 패딩 바이트 쓰기
				int k;
				for (k=0; k<countOfPadding; k++) {
					result.add((byte)0);
				}
				
				boolean isReverse = false;
				
				
				IO.toBytes(this.mDefaultAddressOfSwitch, mIsLittleEndianOfSwitch, IO.arrByte_Len4);
				byteIndex = IO.arrByte_Len4;
				// 4바이트 쓰기, 디폴트 어드레스
				writeBuffer(byteIndex, isReverse, result);
				
				// count를 쓴다.
				IO.toBytes(this.mCountOfLookupSwitch, mIsLittleEndianOfSwitch, IO.arrByte_Len4);
				byteIndex = IO.arrByte_Len4;
				writeBuffer(byteIndex, isReverse, result);
				
				String strKey = instructionName.substring("offsetEnd_Lookup".length()+1);
				int lastKey = Integer.parseInt(strKey);
				this.mListOfKeysOfLookupSwitch.add(lastKey);
				
				mListOfOffsetsOfSwitch.add(value);
				
				// offset_Lookup에서 저장한 key와 offset 리스트
				for (k=0; k<this.mListOfOffsetsOfSwitch.count; k++) {
					IO.toBytes(mListOfKeysOfLookupSwitch.getItem(k), mIsLittleEndianOfSwitch, IO.arrByte_Len4);
					byteIndex = IO.arrByte_Len4;
					writeBuffer(byteIndex, isReverse, result);
					
					IO.toBytes(mListOfOffsetsOfSwitch.getItem(k), mIsLittleEndianOfSwitch, IO.arrByte_Len4);
					byteIndex = IO.arrByte_Len4;
					writeBuffer(byteIndex, isReverse, result);
				}
				
			} // else if (instructionName.contains("offsetEnd_Lookup")) {
			
			else {
				if (instructionName.contains("offset_Lookup")) { 
					// 숫자인 경우, lookupswitch에서 key와 address
					// lookupswitch 에서 key와 offset부분에서 key는 정수이고
					// instructionName은 null이 된다.
					
					// key 쓰기
					String strKey = instructionName.substring("offset_Lookup".length()+1);
					int key = Integer.parseInt(strKey);
					this.mListOfKeysOfLookupSwitch.add(key);
					
					
					// offset 쓰기					
					this.mListOfOffsetsOfSwitch.add(value);
				}				
			}			
		}//if (instruction==null) {
		else {
			if (instruction.hasVariableIndices() ) {
				if (instructionName.equals("tableswitch") || instructionName.equals("lookupswitch")) {
					// defaultOffset 부터 low, high, offset들은 모두 little endian으로 써야 한다.
					// CodeAttribute.processTableSwitch()에서 바이트를 읽으므로 참조한다.
					
					
					// 명령어 1바이트 + 패딩 4바이트 + 디폴트 어드레스 4바이트
									
					if (instructionName.equals("tableswitch")) {
						this.mListOfOffsetsOfSwitch.reset2();
						this.mOpcodeHexaOfSwitch = instruction.opcodeHexa;
						mCountOfPaddingOfSwitch = 0;
						int k;
						for (k=i+1; k<input.count; k++) {
							if (!input.getItem(k).equals(" ")) {
								mCountOfPaddingOfSwitch = Integer.parseInt((String)input.getItem(k));
								break;
							}
						}
						mDefaultAddressOfSwitch = value;
						
					}
					else if (instructionName.equals("lookupswitch")) {
						this.mListOfOffsetsOfSwitch.reset2();
						this.mListOfKeysOfLookupSwitch .reset2();
						this.mOpcodeHexaOfSwitch = instruction.opcodeHexa;
						mCountOfPaddingOfSwitch = 0;
						int k;
						for (k=i+1; k<input.count; k++) {
							if (!input.getItem(k).equals(" ")) {
								mCountOfPaddingOfSwitch = Integer.parseInt((String)input.getItem(k));
								break;
							}
						}
						mDefaultAddressOfSwitch = value;
						
					}
					else {
						
					}
				}
				else {
					
				}
			}//if (instruction.hasVariableIndices() ) {
			else {
				// 명령어 코드 1바이트 쓰기
				IO.toBytes(instruction.opcodeHexa, false, IO.arrByte_Len2);
				byteIndex = IO.arrByte_Len2;
				result.add(byteIndex[byteIndex.length-1]); 
				
				if (instructionName.equals("iinc")) {
					IO.toBytes(value, false, IO.arrByte_Len4);
					byteIndex = IO.arrByte_Len4;
					result.add(byteIndex[byteIndex.length-1]); // 1바이트 쓰기
					
					// const 쓰기
					i++;
					for (; i<input.count; i++) {
						if (!input.getItem(i).equals(" ")) break;
					}
					value = -1;
					if (i<input.count) value = Integer.parseInt((String)input.getItem(i));
					
					IO.toBytes(value, false, IO.arrByte_Len4);
					byteIndex = IO.arrByte_Len4;
					result.add(byteIndex[byteIndex.length-1]); // 1바이트 쓰기
				}
				else if (instructionName.equals("invokeinterface")) {
					// index 쓰기
					IO.toBytes(value, false, IO.arrByte_Len4);
					byteIndex = IO.arrByte_Len4;
					// 빅엔디안, msb를 먼저 쓴다
					result.add(byteIndex[byteIndex.length-2]); // 1바이트 쓰기
					result.add(byteIndex[byteIndex.length-1]); // 1바이트 쓰기
					
					// count는 invokeinterface가 호출하는 메소드의 args들의 개수이다.
					// count, HighArrayCharForByteCode.createConstantTableIndex()를 참조한다.
					i++;
					for (; i<input.count; i++) {
						if (!input.getItem(i).equals(" ")) break;
					}
					value = -1;
					if (i<input.count) value = Integer.parseInt((String)input.getItem(i));
					
					IO.toBytes(value, false, IO.arrByte_Len4);
					byteIndex = IO.arrByte_Len4;
					result.add(byteIndex[byteIndex.length-1]); // 1바이트 쓰기
					
					// 0을 쓴다.
					IO.toBytes(0, false, IO.arrByte_Len4);
					byteIndex = IO.arrByte_Len4;
					result.add(byteIndex[byteIndex.length-1]); // 1바이트 쓰기
				}
				else if (instructionName.equals("multianewarray")) {
					IO.toBytes(value, false, IO.arrByte_Len4);
					byteIndex = IO.arrByte_Len4;
					// 빅엔디안, msb를 먼저 쓴다
					result.add(byteIndex[byteIndex.length-2]); // 1바이트 쓰기
					result.add(byteIndex[byteIndex.length-1]); // 1바이트 쓰기
					
					// dimension 쓰기
					i++;
					for (; i<input.count; i++) {
						if (!input.getItem(i).equals(" ")) break;
					}
					value = -1;
					try {
					if (i<input.count) value = Integer.parseInt((String)input.getItem(i));
					}catch(Exception e) {
						if (Common_Settings.g_printsLog) e.printStackTrace();
					}
					
					IO.toBytes(value, false, IO.arrByte_Len4);
					byteIndex = IO.arrByte_Len4;
					result.add(byteIndex[byteIndex.length-1]); // 1바이트 쓰기
				}
				else if (instructionName.equals("invokedynamic")) {
					
				}
				else {
					//this.indexOfByteCode += 1 + instruction.getLenOfIndices();
					
					// 인덱스 쓰기
					int countOfIndices = instruction.getLenOfIndices(); 
					if (countOfIndices==1) { // aload, iload 등
						IO.toBytes(value, false, IO.arrByte_Len4);
						byteIndex = IO.arrByte_Len4;
						result.add(byteIndex[byteIndex.length-1]); // 1바이트 쓰기
					}
					else if (countOfIndices==2) { // goto, anewarray, checkcast 등
						IO.toBytes(value, false, IO.arrByte_Len4);
						byteIndex = IO.arrByte_Len4;
						// 빅엔디안, msb를 먼저 쓴다
						result.add(byteIndex[byteIndex.length-2]); // 1바이트 쓰기
						result.add(byteIndex[byteIndex.length-1]); // 1바이트 쓰기
					}
					else if (countOfIndices==4) { // goto_w
						IO.toBytes(value, false, IO.arrByte_Len4);
						byteIndex = IO.arrByte_Len4;
						result.add(byteIndex); // 4바이트 쓰기
					}
				}
			} // 고정길이 인덱스
		}//instruction!=null
	}
	
	
	
	
	/**buffer의 4바이트를 한번에 쓴다. buffer에 있는 숫자들은 little endian으로 되어 있다.
	 * offset의 크기가 256보다 이상이면 countOfPaddingOfNextInstructionOfSwitch은 3보다 작게 된다.
	 * isReverse가 true이면 buffer의 0과 1번째 바이트들을 바꿔서 result에 쓴다.*/
	void writeBuffer(byte[] buffer, boolean isReverse, HighArray_byte result) {
		result.add(buffer);
	}
	
	/** tableswitch, lookupswitch의 마지막 오프셋은 tableswitch, lookupswitch의 바로 다음 의미없는 명령어의 바이트코드와 0인 바이트들은 패딩 바이트가 된다.
	 * 여기에서 마지막 오프셋의 0인 바이트의 개수를 리턴한다.
	 * offset의 크기가 하나라도 256보다 이상이면 리턴하는 countOfPaddingOfNextInstructionOfSwitch은 2가 되고,
	 * 이 경우 tableswitch, lookupswitch의 마지막 오프셋은 패딩 바이트 2와 나머지 2개의 바이트들은 tableswitch, lookupswitch의 다음에 붙는 명령어가 된다.
	 * 그리고 모든 4바이트 오프셋을 읽고 저장할 때 0과 1번째 바이트들을 바꿔서 저장해야 한다. 
	 * 모든 offset의 크기가 256보다 작으면  리턴하는 countOfPaddingOfNextInstructionOfSwitch은 1이 된다.
	 * 이 경우 tableswitch, lookupswitch의 마지막 오프셋은 패딩 바이트 3와 나머지 1개의 바이트는 tableswitch, lookupswitch의 다음에 붙는 명령어가 된다.
	 * @param value : offsetEnd, offsetEnd_Lookup의 offset값
	 * @param mListOfOffsetsOfSwitch : case문들의 offset값들
	 * @param defaultAddressOfSwitch */
	int getCountOfPaddingOfNextInstructionOfSwitch(byte[] buffer, ArrayListInt mListOfOffsetsOfSwitch, int value, int defaultAddressOfSwitch) {
		/*int i;
		for (i=buffer.length-1; i>=0; i--) {
			byte b = buffer[i];
			if (b!=0) break;
		}
		if (i>=0) {
			int r = buffer.length-1-i;
			boolean isLargerThan256 = false;
			int j;
			for (j=0; j<mListOfOffsetsOfSwitch.count; j++) {
				if (mListOfOffsetsOfSwitch.getItem(j)>=256) {
					isLargerThan256 = true;
					break;
				}
			}
			if (value>=256) {
				isLargerThan256 = true;
			}
			if (isLargerThan256) {
				// offset의 크기가 256보다 이상이면 리턴하는 countOfPaddingOfNextInstructionOfSwitch은 3보다 작게 된다.
				return r-1;
			}
			return r;
		}
		else {
			// 전부 0인 경우
			return 4;
		}*/
		
		
		boolean isLargerThan256 = false;
		int j;
		for (j=0; j<mListOfOffsetsOfSwitch.count; j++) {
			if (mListOfOffsetsOfSwitch.getItem(j)>=256) {
				isLargerThan256 = true;
				break;
			}
		}
		if (value>=256) {
			isLargerThan256 = true;
		}
		if (defaultAddressOfSwitch>=256) {
			isLargerThan256 = true;
		}
		if (isLargerThan256) {
			// offset의 크기가 256보다 이상이면 리턴하는 countOfPaddingOfNextInstructionOfSwitch은 3보다 작게 된다.
			return 2;
		}
		return 3;
	}
	
	
	
}
