package com.gsoft.common.compiler.bytecode;

import com.gsoft.common.CommonGUI;
import com.gsoft.common.compiler.CodeStringEx;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.CompilerStatic;
import com.gsoft.common.compiler.Member;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.Compiler_types.FindFuncCallParam;
import com.gsoft.common.compiler.Compiler_types.FindFunctionParams;
import com.gsoft.common.compiler.Compiler_types.FindVarParams;
import com.gsoft.common.compiler.Compiler_types.FindVarUseParams;
import com.gsoft.common.compiler.Compiler_types_Base.AccessModifier;
import com.gsoft.common.compiler.Compiler_types_Base.AccessModifier.AccessPermission;
import com.gsoft.common.util.ArrayListChar;
import com.gsoft.common.util.ArrayListIReset;
import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.classloader.Loader;

import com.gsoft.common.compiler.bytecode.ByteCodeGeneratorForClass;
import com.gsoft.common.compiler.bytecode.LocalVar;
import com.gsoft.common.compiler.bytecode.ByteCode_Helper;
import com.gsoft.common.compiler.bytecode.HighArrayCharForByteCode;
import com.gsoft.common.compiler.bytecode.TypeDescriptor;
import com.gsoft.common.compiler.bytecode.ByteCode_Types;

public class Enum {
	/** enum classParams에 static 생성자가 아닌 인스턴스 생성자가 존재하는지를 확인한다.*/
	public static boolean noneStaticDefaultConstructorExists_enum(Compiler compiler, FindClassParams classParams) {
		//if (classParams.isEnum) return false;
		int i;
		String shortName = CompilerStatic.getShortName(classParams.name);
		for (i=0; i<classParams.listOfFunctionParams.count; i++) {
			FindFunctionParams func = (FindFunctionParams) classParams.listOfFunctionParams.getItem(i);
			if (func.listOfFuncArgs.count!=0) continue;
			if (func.accessModifier!=null && func.accessModifier.isStatic) continue;
			if (func.name.equals(shortName)) return true;
		}
		return false;
	}
	
	/** enum classParams에 static 생성자가 존재하는지를 확인한다.*/
	public static boolean staticConstructorExists_enum(Compiler compiler, FindClassParams classParams) {
		//if (classParams.isEnum) return false;
		int i;
		String shortName = CompilerHelper.getShortName(classParams.name);
		for (i=0; i<classParams.listOfFunctionParams.count; i++) {
			FindFunctionParams func = (FindFunctionParams) classParams.listOfFunctionParams.getItem(i);
			//if (func.listOfFuncArgs.count!=0) continue;
			if (func.accessModifier!=null && !func.accessModifier.isStatic) continue;
			if (func.name.equals(shortName)) return true;
			//if (func.name.equals(staticConstructorName)) return true;
		}
		return false;
	}
	
	/** enum classParams에 compareTo()가 존재하는지를 확인한다.*/
	public static boolean compareToFuncExists_enum(Compiler compiler, FindClassParams classParams) {
		//if (classParams.isEnum) return false;
		int i;
		String shortName = "compareTo";
		for (i=0; i<classParams.listOfFunctionParams.count; i++) {
			FindFunctionParams func = (FindFunctionParams) classParams.listOfFunctionParams.getItem(i);
			if (func.listOfFuncArgs.count!=0) continue;
			if (func.accessModifier!=null && func.accessModifier.isStatic) continue;
			if (func.name.equals(shortName)) return true;
		}
		return false;
	}
	
	/** enum classParams에 디폴트 생성자를 만든다.*/
	public static FindFunctionParams makeNoneStaticDefaultConstructor_enum(Compiler compiler, FindClassParams classParams) {
		//if (classParams.isEnum) return;
		FindFunctionParams func=null;
		String fullname = classParams.name;
		String name = CompilerStatic.getShortName(fullname);
		func = new FindFunctionParams(compiler, name);
		// func는 존재하지 않으므로 classNameIndex를 대신 넣는다.
		func.functionNameIndex = classParams.classNameIndex;
		func.returnType = fullname;
		func.parent = classParams;
		func.isConstructor = true;
		if (func.listOfFuncArgs==null) {
			func.listOfFuncArgs = new ArrayListIReset(2);			
		}
		FindVarParams var0 = new FindVarParams(compiler, -1, -1);
		var0.typeName = "java.lang.String";
		var0.fieldName = "name";
		var0.isFake = true;
		func.listOfFuncArgs.add(var0);
		func.listOfVariableParams.add(var0);
		
		FindVarParams var1 = new FindVarParams(compiler, -1, -1);
		var1.typeName = "int";
		var1.fieldName = "ordinal";
		var1.isFake = true;
		func.listOfFuncArgs.add(var1);
		func.listOfVariableParams.add(var1);
		
		if (func.accessModifier==null){
			func.accessModifier = new AccessModifier(compiler, -1, -1);
		}
		func.accessModifier.accessPermission = AccessPermission.Public;
		func.isFake = true;
		classParams.listOfFunctionParams.add(func);
		classParams.listOfConstructor.add(func);
		//compiler.data.mlistOfAllFunctions.add(func);
		return func;
	}
	
	public static FindFunctionParams makeStaticDefaultConstructor_enum(Compiler compiler, FindClassParams classParams) {
		FindFunctionParams func = new FindFunctionParams(classParams.compiler, CompilerHelper.getShortName(classParams.name));
		// func는 존재하지 않으므로 classNameIndex를 대신 넣는다.
		func.functionNameIndex = classParams.classNameIndex;
		func.accessModifier = new AccessModifier(classParams.compiler, -1, -1);
		func.accessModifier.accessPermission = AccessPermission.Public;
		func.accessModifier.isStatic = true;
		func.isConstructor = true;
		func.isConstructorThatInitializesStaticFields = true;
		func.parent = classParams;
		//classParams.staticConstructorThatCompilerMakes = func;
		func.isFake = true;
		
		classParams.listOfFunctionParams.add(func);
		classParams.listOfConstructor.add(func);
		//compiler.data.mlistOfAllFunctions.add(func);
		return func;
	}
	/** classParams이 enum class일 경우 this와 super 필드를 넣고 static과 none-static 생성자가 없으면 그것들을 추가하고
	 * 필드들을 static으로 만든다.
	 * @param classParams : enum
	 */
	public static void processEnumClass(ByteCodeGeneratorForClass generator, FindClassParams classParams) {
		if (classParams.isEnum) {
			Compiler compiler = generator.compiler;
			if (!Enum.staticConstructorExists_enum(compiler, classParams)) {
				FindFunctionParams func = Enum.makeStaticDefaultConstructor_enum(compiler, classParams);
				//func.getLocalVarTableIndexInFunction();
				LocalVar.processLocalVars(func);
			}
			else {
				return;
			}
			
			if (!Enum.noneStaticDefaultConstructorExists_enum(compiler, classParams)) {
				FindFunctionParams func = Enum.makeNoneStaticDefaultConstructor_enum(compiler, classParams);
				//func.getLocalVarTableIndexInFunction();
				LocalVar.processLocalVars(func);
			}
			
			/*if (!compareToFuncExists_enum(compiler, classParams)) {
				FindFunctionParams compareTo = Enum.makeCompareTo(compiler, classParams);
				LocalVar.processLocalVars(compareTo);
			}*/
			
			FindVarParams varThis = new FindVarParams(compiler, true, false, false, classParams);
			FindVarParams varSuper = new FindVarParams(compiler, false, false, true, classParams);
			AccessModifier accessModifierThis = new AccessModifier(compiler, -1, -1);
			AccessModifier accessModifierSuper = new AccessModifier(compiler, -1, -1);
			varThis.accessModifier = accessModifierThis;
			varSuper.accessModifier = accessModifierSuper;
			
			classParams.listOfVariableParams.add(varThis);
			classParams.listOfVariableParams.add(varSuper);
			
			
			int i;
			for (i=0; i<classParams.listOfFunctionParams.count; i++) {
				FindFunctionParams func = (FindFunctionParams) classParams.listOfFunctionParams.getItem(i);
				if (!func.accessModifier.isStatic) {
					FindVarParams varThis2 = new FindVarParams(compiler, true, false, false, classParams);
					func.thisVar = varThis2;
				}
			}			
		}//if (classParams.isEnum) {
	}
	
	static FindFunctionParams getOrdinalFunc(int coreThreadID) {
		int i;
		FindClassParams enumClass = Loader.loadClass(CommonGUI.editText_compiler.getCompiler(), "java.lang.Enum", coreThreadID);
		for (i=0; i<enumClass.listOfFunctionParams.count; i++) {
			FindFunctionParams func = (FindFunctionParams) enumClass.listOfFunctionParams.getItem(i);
			if (func.name.equals("ordinal") && func.listOfFuncArgs.count==0)
				return func;
		}
		return null;
	}
	
	
	public static FindFunctionParams makeCompareTo(Compiler compiler, FindClassParams classParams) {		
		FindFunctionParams compareToFunc = new FindFunctionParams(compiler, "compareTo");		
		
		// func는 존재하지 않으므로 classNameIndex를 대신 넣는다.
		compareToFunc.functionNameIndex = classParams.classNameIndex;
		compareToFunc.returnType = "int";
		compareToFunc.parent = classParams;
		compareToFunc.name = "compareTo";
		
		if (compareToFunc.listOfFuncArgs==null) {
			compareToFunc.listOfFuncArgs = new ArrayListIReset(2);			
		}
		
		FindVarParams var0 = new FindVarParams(compiler, -1, -1);
		var0.typeName = classParams.name;
		var0.fieldName = "o";
		var0.isFake = true;
		compareToFunc.listOfFuncArgs.add(var0);
		compareToFunc.listOfVariableParams.add(var0);
		
				
		/*FindVarParams varThis = new FindVarParams(compiler, true, false, false, classParams);
		compareToFunc.thisVar = varThis;
		varThis.isFake = true;
		compareToFunc.listOfVariableParams.add(varThis);*/
		
		FindVarParams localVar = new FindVarParams(compiler, "int", "ordinalOfThis");
		localVar.isFake = true;
		compareToFunc.listOfVariableParams.add(localVar);
		
		localVar = new FindVarParams(compiler, "int", "ordinalOfO");
		localVar.isFake = true;
		compareToFunc.listOfVariableParams.add(localVar);
		
		if (compareToFunc.accessModifier==null) {
			compareToFunc.accessModifier = new AccessModifier(compiler, -1, -1);
		}
		compareToFunc.accessModifier.accessPermission = AccessPermission.Public;
		compareToFunc.accessModifier.isFinal = true;
		compareToFunc.isFake = true;
		
		classParams.listOfFunctionParams.add(compareToFunc);
		//compiler.data.mlistOfAllFunctions.add(compareToFunc);
		return compareToFunc;
	}
	
	
	public static void printCompareTo(ByteCodeGeneratorForClass generator, FindClassParams classParams, HighArrayCharForByteCode result, int coreThreadID) {
		//
		//	int compareTo(Enum o) {
		//	   int ordinalOfThis = this.ordinal();
		//	   int ordinalOfO = o.ordinal();
		//	   if (ordinalOfThis<ordinalOfO) return -1;
		//	   else if (ordinalOfThis==ordinalOfO) return 0;
		//	   else return 1;
		//	}
		//
		
		Compiler compiler = generator.compiler;
		
		
		
		String strSourceIndex = ByteCode_Helper.getSourceLineNumber(compiler, classParams.classNameIndex());
		String strSourceIndexWithoutCommaAndBlank = 
				ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(compiler, classParams.classNameIndex());
		
		String thisStr = TypeDescriptor.getDescriptorOfThis(classParams, coreThreadID);
		String thisDesc = TypeDescriptor.getDescriptor(classParams.name, coreThreadID);
		
		FindFunctionParams ordinalFunc = getOrdinalFunc(coreThreadID);
		generator.physical.makeCONSTANT_Method_infoAndPutItIntolistOfConstantTable(ordinalFunc, coreThreadID);
		
		
		
		
		
		result.add("aload_0 // local "+thisStr+strSourceIndex+"\n");
		result.add("invokevirtual"+" // java/lang/Enum::()I ordinal"+strSourceIndex+"\n");
		result.add("istore_2"+" // local I ordinalOfThis, 1, I ordinalOfThis"+strSourceIndex+"\n");
		result.add("aload_1"+" // local "+thisDesc+" o, 0, "+thisDesc+" o"+strSourceIndex+"\n");
		result.add("invokevirtual"+" // java/lang/Enum::()I ordinal"+strSourceIndex+"\n");		
		result.add("istore_3 // local I ordinalOfO, 2, I ordinalOfO"+strSourceIndex+"\n");
		
		String mBufferIndex = "("+ByteCode_Types.mBufferIndexOfconditionOfOrdinalOfThisLessThanOrdinalOfO+"),";
		result.add("// "+mBufferIndex+" condition of if (ordinalOfThis<ordinalOfO)"+"\n");
		result.add("iload_2 // local I ordinalOfThis, 1, I ordinalOfThis"+strSourceIndex+"\n");
		result.add("iload_3 // local I ordinalOfO, 2, I ordinalOfO"+strSourceIndex+"\n");
		result.add("isub // "+strSourceIndexWithoutCommaAndBlank+"\n");
		
		mBufferIndex = "("+ByteCode_Types.mBufferIndexOfRunOfOrdinalOfThisLessThanOrdinalOfO+"),";
		result.add("iflt // "+mBufferIndex+" run"+strSourceIndex+"\n");
		
		mBufferIndex = "("+ByteCode_Types.mBufferIndexOfexit_of_conditionOfOrdinalOfThisLessThanOrdinalOfO+"),";
		result.add("// "+mBufferIndex+" exit_of_condition of if (ordinalOfThis<ordinalOfO)"+"\n");
		
		mBufferIndex = "("+ByteCode_Types.mBufferIndexOfexit_of_ifOfOrdinalOfThisLessThanOrdinalOfO+"),";
		result.add("goto_w // "+mBufferIndex+" exit of if (ordinalOfThis<ordinalOfO)"+strSourceIndex+"\n");
		
		mBufferIndex = "("+ByteCode_Types.mBufferIndexOfRunOfOrdinalOfThisLessThanOrdinalOfO+"),";
		result.add("// "+mBufferIndex+" run of if (ordinalOfThis<ordinalOfO)"+"\n");
		
		result.add("iconst_1 // "+strSourceIndexWithoutCommaAndBlank+"\n");
		result.add("ineg // "+strSourceIndexWithoutCommaAndBlank+"\n");
		result.add("ireturn // "+strSourceIndexWithoutCommaAndBlank+"\n");
		result.add("// exit of return"+"\n");
		
		mBufferIndex = "("+ByteCode_Types.mBufferIndexOfexit_of_ifOfOrdinalOfThisLessThanOrdinalOfO+"),";
		result.add("// "+mBufferIndex+" exit of if (ordinalOfThis<ordinalOfO)"+"\n");
		
		
		
		
		mBufferIndex = "("+ByteCode_Types.mBufferIndexOfconditionOfOrdinalOfThisEqualOrdinalOfO+"),";
		result.add("// "+mBufferIndex+" condition of else if (ordinalOfThis==ordinalOfO)"+"\n");
		
		result.add("iload_2 // local I ordinalOfThis, 1, I ordinalOfThis"+strSourceIndex+"\n");
		result.add("iload_3 // local I ordinalOfO, 2, I ordinalOfO"+strSourceIndex+"\n");
		result.add("isub // "+strSourceIndexWithoutCommaAndBlank+"\n");
		
		mBufferIndex = "("+ByteCode_Types.mBufferIndexOfRunOfOrdinalOfThisEqualOrdinalOfO+"),";
		result.add("ifeq // "+mBufferIndex+" run"+strSourceIndex+"\n");
		
		mBufferIndex = "("+ByteCode_Types.mBufferIndexOfexit_of_conditionOfOrdinalOfThisEqualOrdinalOfO+"),";
		result.add("// "+mBufferIndex+" exit_of_condition of else if (ordinalOfThis==ordinalOfO)"+"\n");
		
		mBufferIndex = "("+ByteCode_Types.mBufferIndexOfexit_of_ifOfOrdinalOfThisEqualOrdinalOfO+"),";
		result.add("goto_w // "+mBufferIndex+" exit of else if (ordinalOfThis==ordinalOfO)"+strSourceIndex+"\n");
		
		mBufferIndex = "("+ByteCode_Types.mBufferIndexOfRunOfOrdinalOfThisEqualOrdinalOfO+"),";
		result.add("// "+mBufferIndex+" run of else if (ordinalOfThis==ordinalOfO)"+"\n");
		
		
		result.add("iconst_0 // "+strSourceIndexWithoutCommaAndBlank+"\n");
		result.add("ireturn // "+strSourceIndexWithoutCommaAndBlank+"\n");
		result.add("// exit of return"+"\n");
		
		mBufferIndex = "("+ByteCode_Types.mBufferIndexOfexit_of_ifOfOrdinalOfThisEqualOrdinalOfO+"),";
		result.add("// "+mBufferIndex+" exit of else if (ordinalOfThis==ordinalOfO)"+"\n");
		result.add("iconst_1 // "+strSourceIndexWithoutCommaAndBlank+"\n");
		result.add("ireturn // "+strSourceIndexWithoutCommaAndBlank+"\n");
		result.add("// exit of return"+"\n");
		
		mBufferIndex = "("+ByteCode_Types.mBufferIndexOfexit_of_ifOfOrdinalOfThisEqualOrdinalOfO+"),";
		result.add("// "+mBufferIndex+" exit of if-elseif-else"+"\n");
		result.add("iconst_0 // "+strSourceIndexWithoutCommaAndBlank+"\n");
		result.add("ireturn // "+strSourceIndexWithoutCommaAndBlank+"\n");

	}
	
	public static void printEnumConstructorCall(ByteCodeGeneratorForClass generator, FindVarUseParams varUseSuper, HighArrayCharForByteCode result, int coreThreadID) {
		Compiler compiler = generator.compiler;
		FindClassParams parentClass = varUseSuper.classToDefineThisVarUse;
		FindFunctionParams func = varUseSuper.funcToDefineThisVarUse;
		
		varUseSuper.listOfFuncCallParams = new ArrayListIReset(2);
		FindFuncCallParam funcCallParam = new FindFuncCallParam(compiler, -1, -1);
		funcCallParam.typeFullName = new CodeStringEx("java.lang.String");
		varUseSuper.listOfFuncCallParams.add(funcCallParam);
		
		funcCallParam = new FindFuncCallParam(compiler, -1, -1);
		funcCallParam.typeFullName = new CodeStringEx("int");
		varUseSuper.listOfFuncCallParams.add(funcCallParam);
		
		varUseSuper.funcDecl = Member.getFunction(compiler, parentClass, varUseSuper, coreThreadID);
		
		String strSourceIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, parentClass.classNameIndex());
		
		String thisStr = TypeDescriptor.getDescriptorOfThis(parentClass, coreThreadID);
		result.add("aload_0 // local "+thisStr+strSourceIndex+"\n");
		
		String strindexOfLocalVarsInFunctionBeforeProcessLocalVars = null;
		
		FindVarParams arg0 = (FindVarParams) func.listOfFuncArgs.getItem(0);
		strindexOfLocalVarsInFunctionBeforeProcessLocalVars = ", "+arg0.indexOfLocalVarsInFunctionBeforeProcessLocalVars;
		strindexOfLocalVarsInFunctionBeforeProcessLocalVars += ", "+arg0.getVarStr(coreThreadID);
		result.add("aload_1 // local "+arg0.getVarStr(coreThreadID)+strindexOfLocalVarsInFunctionBeforeProcessLocalVars+strSourceIndex+"\n");
		
		FindVarParams arg1 = (FindVarParams) func.listOfFuncArgs.getItem(1);
		strindexOfLocalVarsInFunctionBeforeProcessLocalVars = ", "+arg1.indexOfLocalVarsInFunctionBeforeProcessLocalVars;
		strindexOfLocalVarsInFunctionBeforeProcessLocalVars += ", "+arg1.getVarStr(coreThreadID);
		result.add("iload_2 // local "+arg1.getVarStr(coreThreadID)+strindexOfLocalVarsInFunctionBeforeProcessLocalVars+strSourceIndex+"\n");
		
		generator.printFuncCall(varUseSuper, result, coreThreadID);
	}
	
	public static void printEnumStaticConstructor(ByteCodeGeneratorForClass generator, FindClassParams classParams, HighArrayCharForByteCode result, int coreThreadID) {
		
		int i;
		FindFunctionParams noneStaticConstructor = null;
		for (i=0; i<classParams.listOfFunctionParams.count; i++) {			
			FindFunctionParams func = (FindFunctionParams) classParams.listOfFunctionParams.getItem(i);
			if (func.isConstructorThatInitializesStaticFields) {
			}
			else if (func.isConstructor) {
				noneStaticConstructor = func;
			}
		}
		
		FindClassParams parentClass = classParams;
		
		for (i=0; i<classParams.listOfVariableParams.count; i++) {			
			FindVarParams field = (FindVarParams) classParams.listOfVariableParams.getItem(i);
			if (field.isThis || field.isSuper) continue;
			// enum클래스 Language의 Java = new Language()에서 Language()는 없으므로 Java의 varNameIndex을 대신 넣는다.
			// super가 없으므로 생성자의 functionNameIndex을 대신 넣는다.
			
			String strmBufferIndex = ByteCode_Helper.getSourceLineNumber(generator.compiler, field.varNameIndex());
			String strmBufferIndexWithoutCommaAndBlank = ByteCode_Helper.getSourceLineNumberWithoutCommaAndBlank(generator.compiler, field.varNameIndex()); 
			
			FindVarUseParams funcCall = new FindVarUseParams(field.varNameIndex);
			funcCall.isFake = true;
			funcCall.funcDecl = noneStaticConstructor;
			funcCall.originName = CompilerHelper.getShortName(classParams.name);
			funcCall.name = funcCall.originName;
			funcCall.listOfFuncCallParams = new ArrayListIReset(2);
			
			//FindFuncCallParam param0 = new FindFuncCallParam(compiler, -1, -1);
			//param0.typeFullName = new CodeStringEx("java.lang.String");
			
			ArrayListChar message = new ArrayListChar(30);
			message.add("new // ");
			message.add(TypeDescriptor.getDescriptorExceptLAndSemicolon(parentClass, coreThreadID)+strmBufferIndex);
			message.add("\n");
			result.add(new String(message.getItems()));				
			result.add("dup // "+strmBufferIndexWithoutCommaAndBlank+"\n");
			
			String name = field.fieldName;
			generator.physical.makeCONSTANT_String_infoAndPutItIntolistOfConstantTable(name);
			result.add("ldc_w // "+name+strmBufferIndex+"\n");
			
			generator.printSmallIntegerNumber(i, result, field.varNameIndex());
			
			generator.printFuncCall(funcCall, result, coreThreadID);
			//generator.traverseFuncCall(generator.compiler.data.mBuffer, funcCall, result);
			
			FindVarUseParams lValue = new FindVarUseParams(field.varNameIndex);
			lValue.isFake = true;
			lValue.varDecl = field;
			lValue.originName = field.fieldName;
			lValue.name = lValue.originName;
			if (lValue.varDecl.isMemberOrLocal) { 
				//멤버변수에 저장, putfield, putstatic
				generator.printMemberVarUse(lValue, result, false, coreThreadID);
			}
		}
	}
	
}
