package com.gsoft.common.compiler.bytecode;

import com.gsoft.common.CommonGUI;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.CompilerStatic;
import com.gsoft.common.compiler.Compiler_types.CategoryOfControls;
import com.gsoft.common.compiler.Compiler_types.FindControlBlockParams;
import com.gsoft.common.compiler.Compiler_types.FindFunctionParams;
import com.gsoft.common.compiler.Compiler_types.FindVarParams;
import com.gsoft.common.compiler.Compiler_types_Base.Error;
import com.gsoft.common.compiler.Compiler_types_Special.FindSpecialBlockParams;
import com.gsoft.common.compiler.Compiler_types_Special.FindThreeOperandsOperation;
import com.gsoft.common.compiler.Number;
import com.gsoft.common.compiler.StringTokenizer;
import com.gsoft.common.compiler.bytecode.ByteCode_Types.ByteCodeInstruction;
import com.gsoft.common.compiler.bytecode.ByteCode_Types.Exception_Entry;
import com.gsoft.common.compiler.bytecode.ByteCode_Types.HashItemOfConstantTable;
import com.gsoft.common.util.Array;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListChar;
import com.gsoft.common.util.ArrayListInt;
import com.gsoft.common.util.HighArray;
import com.gsoft.common.util.hash.Hashtable2_String;

import com.gsoft.common.compiler.bytecode.OffsetAndForLoopAndParent;
import com.gsoft.common.compiler.bytecode.ByteCodeGeneratorForClass;
import com.gsoft.common.compiler.bytecode.ByteCode_Types;



public class HighArrayCharForByteCode extends com.gsoft.common.util.HighArray_char {
	/** 마지막 바이트코드 오프셋*/
	int indexOfByteCode;
	
	/** Exception_Entry[], Code_Attribute의 exception_table*/
	ArrayList exception_table = new ArrayList(2);
	
	/** offset, label에 사용되는 왼쪽괄호의 리스트*/
	ArrayListInt indicesOfLeftParent = new ArrayListInt(100); 
	
	/**OffsetAndForLoopAndParent[]*/
	ArrayList listOfOffsetDeltas = new ArrayList(10);
	
	/**OffsetAndForLoopAndParent[]*/
	ArrayList listOfJumpOffsetsOfStackMap = new ArrayList(5);
	
	//ByteCodeGeneratorForClass generator;
	Compiler compiler;
	
	/** (mBufferIndex), exit of for를 만나서 chop 프레임을 찾기 위해 
	 * (mBufferIndex), condition of for의 오프셋과 같은 오프셋을 갖는
	 * 프레임(for루프의 조건문전에 있는 마지막프레임)을 chop 프레임으로 리턴한다.*/
	//int offsetOfConditionOfFor = -1;
	
	int byteCodeOffsetOfConditionForThreeOperandsOperationWith1StackItem;
	
	/** FindVarUseParams[], 복합할당연산자와 3항연산자를 함께 사용할 경우에 복합할당연산자의 lValue를 담기위해 사용된다.
	 * 같은 소스파일에 복합할당연산자와 3항연산자를 함께 사용할 경우가 여러 개 있는 경우를 해결할 수 있다. */
	ArrayList listOfVarUseForThreeOperandsOperationWith1StackItem = 
			new ArrayList(5);
	
	
	/** tableswitch, lookupswitch의 오프셋에서 상대적인 점프 오프셋을 계산하기 위해 사용한다.*/
	private int mCurOffsetOfSwitch;
	
	/**배열원소를 접근(로드, 스토어)하는 varUse들의 mBufferIndex들의 리스트*/
	ArrayListInt listOfIndicesOfVarUsesThatAccessesArrayElement = new ArrayListInt(8);
	
	/**HighArray에서 "\n"의 인덱스 리스트*/
	ArrayListInt listOfIndicesOfNewLines = new ArrayListInt(40);
	/**HighArray에서 "//"의 인덱스 리스트*/
	private ArrayListInt listOfIndicesOfComments;

	/**createConstantTableIndex()의 결과 스트링 리스트*/
	HighArray listOfStrs;

	private int startPCOfFinallyStarts;

	/** try, catch, finally구문에서 try, catch에 포함되는 finally의 startPC, endPC 리스트*/ 
	public ArrayList listOfStartPCAndEndPCOfFinallyStartsAndEnds = new ArrayList(5);
	
	/**called finally block by throw, return, continue or break<br>
	 * index of Comment*/
	ArrayListInt listOfAllIndicesOfTokenizerOfIfAndGotoForCalledFinallyAndOriginalFinally = new ArrayListInt(5);
	
	/**called finally block by throw, return, continue or break, 0(// finally starts), 1(// finally ends), ....<br>
	 * index of comment*/
	ArrayListInt listOfAllIndicesOfTokenizerOfCalledFinallyAndOriginalFinally = new ArrayListInt(5);

	
	
	/**modeCreateOrShow는 기본적으로 false가 되므로 byte배열에 출력하는 것이 아니라
	 *  보여주기 위해 char배열에 출력한다.
	 * @param arrayLimit
	 */
	public HighArrayCharForByteCode(Compiler compiler, int arrayLimit) {
		super(arrayLimit);
		this.compiler = compiler;
	}
	
	public String toString(HighArray result) {
		int i;
		ArrayListChar r = new ArrayListChar(result.count*5+100);
		for (i=0; i<result.count; i++) {
			r.add((String)result.getItem(i));
		}
		return new String(r.getItems());
	}
	
	
	/** iload_index에서 index를 리턴한다.*/
	int getLocalTableIndex(String code) {
		int _index = code.indexOf("_");
		String r = code.substring(_index+1, code.length());
		return Integer.parseInt(r);
	}
	
	/** catch starts T// (try_start_offset) T// (try_end_offset) // java.lang.Exception 에서
	 *  java.lang.Exception의 constant table에서의 인덱스를 
	 *  exception_table에서 알맞은 Exception_Entry에 넣어준다.
	 * @param i : // catch starts T// (try_start_offset) T// (try_end_offset) // java.lang.Exception 에서 맨처음 주석의 인덱스*/
	void setCatchType(ByteCodeGeneratorForClass generator, HighArray list, int i, Hashtable2_String listOfConstantTableHashed) {
		
		int labelIndex = findLabelIndexOfNextLine_String(list, i);
		int j;
		String exceptionDesc = null;
		int indexInHashItem = -1;
		for (j=i+1; j<list.count; j++) {
			String str = (String) list.getItem(j);
			if (str.equals("//")) {
				if (!list.getItem(j-1).equals("T")) {
					exceptionDesc = (String) list.getItem(j+2);
					
					generator.physical.makeCONSTANT_Class_infoAndPutItIntolistOfConstantTable_ExceptLAndSemicolon(exceptionDesc);
					HashItemOfConstantTable item = 
							(HashItemOfConstantTable) listOfConstantTableHashed.getData(exceptionDesc, false);
					
					indexInHashItem = item.index;
					break;
				}
			}
		}
		for (j=0; j<this.exception_table.count; j++) {
			Exception_Entry entry = (Exception_Entry) exception_table.getItem(j);
			// catch문의 code[]에서의 시작인덱스로 entry를 검색한다.
			if (entry.handler_pc==labelIndex) {
				entry.catch_type = indexInHashItem;
			}
		}
	}
	
	/** try, catch, finally의 startPC, endPC를 정해준다.
	 * @param startPCOrEndPC : true이면 startPC, false이면 endPC를 정한다.*/
	void setStartPCOrEndPCToSpecialBlock(int nameIndexInmBuffer, int PC, boolean startPCOrEndPC) {
		int i;
		for (i=0; i<compiler.data.mlistOfAllControlBlocks.count; i++) {
			FindControlBlockParams control = (FindControlBlockParams) compiler.data.mlistOfAllControlBlocks.getItem(i);
			
			if (startPCOrEndPC) {
				int nameIndex = -1;
				if (control.isFake) {
					/*if (control.getName().equals("try")) {
						if (control instanceof FindSpecialBlockParams) {
							FindSpecialBlockParams special = (FindSpecialBlockParams) control;
							if (special.anotherName.equals(ByteCode_Types.TryCatchShieldForConsole)) {
								nameIndex = ByteCode_Types.startIndexOfFakeTryInMain;
							}
							else {
								nameIndex = ByteCode_Types.startIndexOfFakeTryInFuncWithSync;
							}
						}
					}
					else if (control.getName().equals("catch")) {
						nameIndex = ByteCode_Types.startIndexOfFakeCatchInMain;
					}
					else if (control.getName().equals("finally")) {
						nameIndex = ByteCode_Types.startIndexOfFakeFinallyInFuncWithSync;
					}*/
					if (control instanceof FindSpecialBlockParams) {
						FindSpecialBlockParams special = (FindSpecialBlockParams) control;
						nameIndex = ByteCode_Types.getFakeTryCatchFinallyIndex(special, 0);
					}
				}
				else {
					nameIndex = control.nameIndex();
				}
				if (nameIndex==nameIndexInmBuffer) {				
					FindSpecialBlockParams special = (FindSpecialBlockParams) control;
					special.listOfStartPC.add(PC);
				}
			}
			else {
				int endIndex = -1;
				if (control.isFake) {
					/*if (control.getName().equals("try")) {
						if (control instanceof FindSpecialBlockParams) {
							FindSpecialBlockParams special = (FindSpecialBlockParams) control;
							if (special.anotherName.equals(ByteCode_Types.TryCatchShieldForConsole)) {
								endIndex = ByteCode_Types.endIndexOfFakeTryInMain;
							}
							else {
								endIndex = ByteCode_Types.endIndexOfFakeTryInFuncWithSync;
							}
						}
					}
					else if (control.getName().equals("catch")) {
						endIndex = ByteCode_Types.endIndexOfFakeCatchInMain;
					}
					else if (control.getName().equals("finally")) {
						endIndex = ByteCode_Types.endIndexOfFakeFinallyInFuncWithSync;
					}*/
					if (control instanceof FindSpecialBlockParams) {
						FindSpecialBlockParams special = (FindSpecialBlockParams) control;
						endIndex = ByteCode_Types.getFakeTryCatchFinallyIndex(special, 1);
					}
				}
				else {
					if (control.findBlockParams!=null) {
						endIndex = control.findBlockParams.endIndex();
					}
				}
				if (endIndex==nameIndexInmBuffer) {				
					FindSpecialBlockParams special = (FindSpecialBlockParams) control;
					special.listOfEndPC.add(PC);
				}
			}
		}
	}
	
	/** 다음 라인의 첫번째 바이트 코드 오프셋을 가져온다.*/
	int getByteCodeOffset(int i, HighArray result) {
		int j;
		int newI = i;
		while (true) {
			for (j=newI+1; j<result.count; j++) {
				if (result.getItem(j).equals("\n")) break;
			}
			if (j==result.count) break;
			newI = j;
			// 다음 라인의 첫번째 스트링
			try {
				int byteCodeIndex = Integer.parseInt((String)result.getItem(j+1));
				return byteCodeIndex;
			}catch(Exception e) {
				
			}
		}
		return this.indexOfByteCode;
	}
	
		
	/**i번째 스트링이 주석인지 여부를 확인한다.*/
	boolean isComment(HighArray input, int i) {
		int k;
		for (k=i; k>=0; k--) {
			String str = (String) input.getItem(k);
			if (str.equals("//")) return true;
			else if (str.equals("\n")) return false;
		}
		return false;
	}
	
	
	
	/** (YYY), BlockStart 등과 같은 라벨을 찾는다.
	 * @param i : //의 인덱스*/
	boolean isLabel(HighArray input, int i) {
		int j;
		for (j=i-1; j>=0; j--) {
			String s = (String) input.getItem(j);
			if (s.equals(" ")) continue;
			if (s.equals("\n")) {
				return true;
			}
			else break;
		}
		if (j==-1) return true;
		return false;
	}
	
	
	
	/** Label 주석기호에서 이전 라인의 '\n'의 거리, 1*/
	static final byte diffFromNewLineToLabelComment = 1;
	
	/** 코드에서 offset 주석기호의 거리, 8*/
	static final byte diffFromCodeToOffsetComment = 8;
	
	/** 라인넘버에서 코드의 거리, 2*/
	static final byte diffFromLineNumberToCode = 2;
	
	/**opcode gap // (offset) 또는<br>
	 * gap // (Label) 에서 
	 * 주석 다음에 붙는 (offset), (Label)을 기반으로 goto 인덱스 또는 ifgt 인덱스 등의 
	 * 바이트코드 인덱스(code[]에서의 인덱스)를 생성한다.
	 * 또한 // catch(finally) starts T// (try_start_offset), T// (try_end_offset) 에서
	 * try_start_offset, try_end_offset의 바이트코드 인덱스(code[]에서의 인덱스)를 생성한다.*/
	public void createByteCodeIndex2(HighArray input, StringTokenizer tokenizer) {
		this.indicesOfLeftParent = tokenizer.getListOfIndicesOfSeparator("(");
		int i;
		ArrayListInt listOfLabels = new ArrayListInt(indicesOfLeftParent.count);
		ArrayListInt listOfOffsets = new ArrayListInt(indicesOfLeftParent.count);
		for (i=0; i<indicesOfLeftParent.count; i++) {
			// // (YYY), 에서 '('을 찾는다.
			int indexOfLeftPair = this.indicesOfLeftParent.getItem(i);
			if (!((String)input.getItem(indexOfLeftPair-2)).equals("//")) continue;
			if (((String)input.getItem(indexOfLeftPair+2)).equals(")")) {
				String offset = (String)input.getItem(indexOfLeftPair+1);
				if (Number.isNumber(offset)) {
					int indexOfNewLine = indexOfLeftPair-(diffFromNewLineToLabelComment+2);
					if (indexOfNewLine<0 || ((String)input.getItem(indexOfNewLine)).equals("\n")) {
						// label
						listOfLabels.add(indexOfLeftPair);
					}
					else {
						// offset
						listOfOffsets.add(indexOfLeftPair);
					}
				}
			}
		}
		
		int try_start_pc = -1;
		int nameIndexOfCatchOrFinally = -1;
		int catchOrFinallyIndex = -1;
		
		for (i=0; i<listOfOffsets.count; i++) {
			int indexOfOffset = listOfOffsets.getItem(i);
			// // YYY code 		// (YYY), 
			int offset_mBufferIndex = -1;
			String strOffset = (String)input.getItem(indexOfOffset+1);
			if (Number.isNumber(strOffset)) {
				offset_mBufferIndex = Integer.parseInt(strOffset);
			}
			int j;
			for (j=0; j<listOfLabels.count; j++) {
				//CommonGUI.showMessage(true, "i="+i+" j="+j);
				
				int indexOfLabel = listOfLabels.getItem(j);
				int label_mBufferIndex = -1;
				String strLabel = (String)input.getItem(indexOfLabel+1);
				if (Number.isNumber(strLabel)) {
					label_mBufferIndex = Integer.parseInt(strLabel);
				}
				
				if (offset_mBufferIndex==label_mBufferIndex) {
					this.listOfAllIndicesOfTokenizerOfIfAndGotoForCalledFinallyAndOriginalFinally.add(indexOfOffset-2);
					
					int lineNumber = this.findLabelIndexOfNextLine_String(input, indexOfLabel-2);
					if (!((String)input.getItem(indexOfOffset-3)).equals("T")) {
						int codeIndex = indexOfOffset - (diffFromCodeToOffsetComment+2);
						this.input(input, codeIndex+2, lineNumber);
						
						this.modifyGotoIfXXXTableswitch(input, indexOfOffset);
					} // goto, ifXXX, tableswitch 등
					else {
						// // (609), catch starts, T// (543), , T// (608),  // java/lang/Exception
						int catchIndex = indexOfOffset-8;
						int finallyIndex = indexOfOffset-12;
						String catchStr = (String)input.getItem(catchIndex);
						String finallyStr = (String)input.getItem(finallyIndex);
						if (catchStr.equals("catch")) {
							// (543), try starts
							// 251        iconst_0            // [559]
							// 여기에서 lineNumber는 251이 된다.
							try_start_pc = lineNumber;
							nameIndexOfCatchOrFinally = Integer.parseInt((String)input.getItem(catchIndex-4));
							catchOrFinallyIndex = catchIndex;
						}
						// // (4263), finally (handler) starts, T// (3823), , T// (4255),
						else if (finallyStr.equals("finally")) {				
							try_start_pc = lineNumber;
							nameIndexOfCatchOrFinally = Integer.parseInt((String)input.getItem(finallyIndex-4));
							catchOrFinallyIndex = finallyIndex;
						}
						else {
							// (608), exit of try
							// (609), catch starts, T// (543), , T// (608),  // java/lang/Exception
							// 280        astore 9          // local Ljava/lang/Exception; e, 9, [609]
							// handler_pc는 280이 된다.
							//int handler_pc = this.findLabelIndexOfNextLine_String(input, indexOfLabel-2);
							int handler_pc = -1;
							handler_pc = this.getByteCodeOffset(catchOrFinallyIndex, input);
							// catch_type은 예외 타입의 디스크립터의 constant table 인덱스 검색을  
							// createConstantTableIndex()에서 한다.
							// finally의 경우 catch_type이 0이므로 디폴트로 catch_type을 0으로 한다.
							// finally은 createConstantTableIndex()에서 constant table 인덱스 검색을 하지 않기 때문이다.
							Exception_Entry entry = 
									new Exception_Entry(try_start_pc, lineNumber, handler_pc, 0, nameIndexOfCatchOrFinally);
							if (entry.end_pc==-1) {
								entry.end_pc = this.indexOfByteCode;
							}
							this.exception_table.add(entry);
						}
					}
					break;
				}
			}// for (j=0; j<listOfLabels.count; j++) {
		}// for (i=0; i<listOfOffsets.count; i++) {
	}
	
	/** changes jump offsets of ifXXX, goto, and exception entries in a called finally or an original finally*/
	void changeJumpIndexOfIfAndGotoInCalledFinallyAndOriginalFinally(HighArray input, StringTokenizer tokenizer) {
		int i, j, k;
		
		this.indicesOfLeftParent = tokenizer.getListOfIndicesOfSeparator("(");
		ArrayListInt listOfLabels = new ArrayListInt(indicesOfLeftParent.count);
		ArrayListInt listOfOffsets = new ArrayListInt(indicesOfLeftParent.count);
		for (i=0; i<indicesOfLeftParent.count; i++) {
			// // (YYY), 에서 '('을 찾는다.
			int indexOfLeftPair = this.indicesOfLeftParent.getItem(i);
			if (!((String)input.getItem(indexOfLeftPair-2)).equals("//")) continue;
			if (((String)input.getItem(indexOfLeftPair+2)).equals(")")) {
				String offset = (String)input.getItem(indexOfLeftPair+1);
				if (Number.isNumber(offset)) {
					int indexOfNewLine = indexOfLeftPair-(diffFromNewLineToLabelComment+2);
					if (indexOfNewLine<0 || ((String)input.getItem(indexOfNewLine)).equals("\n")) {
						// label
						listOfLabels.add(indexOfLeftPair);
					}
					else {
						// offset
						listOfOffsets.add(indexOfLeftPair);
					}
				}
			}
		}
		
		int try_start_pc = -1;
		int nameIndexOfCatchOrFinally = -1;
		int catchOrFinallyIndex = -1;
		
		for (i=0; i<this.listOfAllIndicesOfTokenizerOfCalledFinallyAndOriginalFinally.count; i+=2) {
			//ArrayListInt listOfAllIndicesOfTokenizerOfIfAndGotoForCalledFinally_OneFinally = new ArrayListInt(5);
			int startOfFinally = listOfAllIndicesOfTokenizerOfCalledFinallyAndOriginalFinally.getItem(i);
			int endOfFinally = listOfAllIndicesOfTokenizerOfCalledFinallyAndOriginalFinally.getItem(i+1);
			for (j=0; j<this.listOfAllIndicesOfTokenizerOfIfAndGotoForCalledFinallyAndOriginalFinally.count; j++) {
				int indexOfCommentOfIfAndGoto = listOfAllIndicesOfTokenizerOfIfAndGotoForCalledFinallyAndOriginalFinally.getItem(j);				
				
				if (startOfFinally<indexOfCommentOfIfAndGoto && indexOfCommentOfIfAndGoto<endOfFinally) {
					int indexOfOffset = indexOfCommentOfIfAndGoto + 2;
					int offset_mBufferIndex = -1;
					String strOffset = (String)input.getItem(indexOfOffset+1);
					if (Number.isNumber(strOffset)) {
						offset_mBufferIndex = Integer.parseInt(strOffset);
					}
					for (k=0; k<listOfLabels.count; k++) {
						//CommonGUI.showMessage(true, "i="+i+" k="+k, false);
						
						int indexOfLabel = listOfLabels.getItem(k);						
						if (startOfFinally<indexOfLabel && indexOfLabel<endOfFinally) {
							int label_mBufferIndex = -1;
							String strLabel = (String)input.getItem(indexOfLabel+1);
							if (Number.isNumber(strLabel)) {
								label_mBufferIndex = Integer.parseInt((String)input.getItem(indexOfLabel+1));
							}
							if (offset_mBufferIndex==label_mBufferIndex) {
								int lineNumber = this.findLabelIndexOfNextLine_String(input, indexOfLabel-2);
								if (!((String)input.getItem(indexOfOffset-3)).equals("T")) {
									int codeIndex = indexOfOffset - (diffFromCodeToOffsetComment+2);
									this.input(input, codeIndex+2, lineNumber);
									
									this.modifyGotoIfXXXTableswitch(input, indexOfOffset);
								} // goto, ifXXX, tableswitch 등
								else {
									// // (609), catch starts, T// (543), , T// (608),  // java/lang/Exception
									int catchIndex = indexOfOffset-8;
									int finallyIndex = indexOfOffset-12;
									String catchStr = (String)input.getItem(catchIndex);
									String finallyStr = (String)input.getItem(finallyIndex);
									if (catchStr.equals("catch")) {
										// (543), try starts
										// 251        iconst_0            // [559]
										// 여기에서 lineNumber는 251이 된다.
										try_start_pc = lineNumber;
										nameIndexOfCatchOrFinally = Integer.parseInt((String)input.getItem(catchIndex-4));
										catchOrFinallyIndex = catchIndex;
									}
									// // (4263), finally (handler) starts, T// (3823), , T// (4255),
									else if (finallyStr.equals("finally")) {				
										try_start_pc = lineNumber;
										nameIndexOfCatchOrFinally = Integer.parseInt((String)input.getItem(finallyIndex-4));
										catchOrFinallyIndex = finallyIndex;
									}
									else {
										// (608), exit of try
										// (609), catch starts, T// (543), , T// (608),  // java/lang/Exception
										// 280        astore 9          // local Ljava/lang/Exception; e, 9, [609]
										// handler_pc는 280이 된다.
										//int handler_pc = this.findLabelIndexOfNextLine_String(input, indexOfLabel-2);
										int handler_pc = -1;
										handler_pc = this.getByteCodeOffset(catchOrFinallyIndex, input);
										// catch_type은 예외 타입의 디스크립터의 constant table 인덱스 검색을  
										// createConstantTableIndex()에서 한다.
										// finally의 경우 catch_type이 0이므로 디폴트로 catch_type을 0으로 한다.
										// finally은 createConstantTableIndex()에서 constant table 인덱스 검색을 하지 않기 때문이다.
										/*Exception_Entry entry = 
												new Exception_Entry(try_start_pc, lineNumber, handler_pc, 0, nameIndexOfCatchOrFinally, true);
										if (entry.end_pc==-1) {
											entry.end_pc = this.indexOfByteCode;
										}*/
										int o;
										for (o=0; o<this.exception_table.count; o++) {
											Exception_Entry ee = (Exception_Entry) this.exception_table.getItem(o);
											if (ee.mBufferIndexOfNameOfCatchOrFinally==nameIndexOfCatchOrFinally) {
												
												if (ee.updatedInchangeJumpIndexOfIfAndGotoInCalledFinallyAndOriginalFinally) 
													continue;
												ee.start_pc = try_start_pc;
												ee.end_pc = lineNumber;
												ee.handler_pc = handler_pc;
												ee.updatedInchangeJumpIndexOfIfAndGotoInCalledFinallyAndOriginalFinally = true;
												break;
											}
										}
									}
								}
								break;
							}// if (offset_mBufferIndex==label_mBufferIndex) {
						}
					}// for (k=0; k<listOfLabels.count; k++) {
				}// if (startOfFinally<indexOfIfAndGoto && indexOfIfAndGoto<endOfFinally) {
			}// for (j=0; j<this.listOfAllIndicesOfTokenizerOfIfAndGotoForCalledFinallyAndOriginalFinally.count; j++) {
		}
	}
	
	void modifyGotoIfXXXTableswitch(HighArray input, int indexOfLeftPair) {
		
		int i = indexOfLeftPair - 2;
		int j;
		
		// goto gap // (offset), go to YYY
		// goto gap // (offset), ixor, ! 에서 '/'의 인덱스<br>
		// ifXXX gap // (offset), YYY
		
		
		String code = null;
		j = i-diffFromCodeToOffsetComment+2;
		//j = i-diffFromCodeToComment+2;
		// 시작부분에서 code가 없는 // synchronized starts와 같은 경우 j는 -1이 된다.
		// 시작부분에서           // (348), run of do_while ((float)a<6)
		// 0          iload_2            // local I count
		// 1          iload_1            // local I a
		// 와 같은 경우에는 j는 -1이 된다.
		if (j==-1) return;
		
		String jumpIndexStr = null;
		jumpIndexStr = (String) input.getItem(j);
		
		
		//if (Number.IsNumber2(jumpIndexStr)!=0) {
		if (Number.isNumber(jumpIndexStr)) {
			// code는 createByteCodeIndex()에서 넣어진 인덱스이다.
			int jumpIndex = Integer.parseInt(jumpIndexStr);
			
			j = i - diffFromCodeToOffsetComment;
			// 시작부분에서 code가 없는 // synchronized starts와 같은 경우 j는 -1이 된다.
			//if (j==-1) continue;
			
			int codeIndex = j;
			code = (String) input.getItem(j);
			if (code.equals("goto_w") || code.equals("goto") ||
				code.equals("ifgt") || code.equals("iflt") || code.equals("ifge") || 
				code.equals("ifle") || code.equals("ifeq") || code.equals("ifne") ||
				code.equals("ifnull") || code.equals("ifnonnull") ||
				code.equals("if_acmpeq") || code.equals("if_acmpne")) {
				j = codeIndex - diffFromLineNumberToCode;
				// code의 현재 offset
				int byteCodeOffset = Integer.parseInt((String)input.getItem(j));
				// 계산된 인덱스를 gap공간에 넣는다.
				this.input(input, codeIndex+2, jumpIndex-byteCodeOffset); 
				//}
				return;
			}
			// "tableswitch", "lookupswitch", "offset" 인 경우에는 continue한다.
			if (code!=null) {
				if (code.equals("tableswitch") || code.equals("lookupswitch")) {
					int k;
					mCurOffsetOfSwitch=0;
					// j는 tableswitch의 인덱스
					// j는 tableswitch의 인덱스
					k = j - diffFromLineNumberToCode;
					mCurOffsetOfSwitch = Integer.parseInt((String)input.getItem(k));
					int offsetOfNextInstruction = this.getByteCodeOffset(i, input);
					// 1은 tableswitch의 바이트길이, 4는 defaultAddress의 길이
					int countOfPadding = (offsetOfNextInstruction-mCurOffsetOfSwitch)-(1+4);
					
					// j는 tableswitch의 인덱스
					k = j + 2;
					int jumpOffset = Integer.parseInt((String)input.getItem(k));
					this.input(input, k, jumpOffset-mCurOffsetOfSwitch);
					this.input(input, k+2, countOfPadding);										
					
					i = k;
				}
				else if ((code.equals("offset") || code.equals("offsetEnd"))) {
					int k;										
					k = codeIndex + 2;
					String strOffset = (String) input.getItem(k);
					// tableswitch의 오프셋에서 상대적인 점프 오프셋을 계산한다.
					int offset = Integer.parseInt(strOffset);
					this.input(input, k, offset-this.mCurOffsetOfSwitch);
					i = k;
					return;
				}
				else if ((code.contains("offset_Lookup") || code.contains("offsetEnd_Lookup"))) {
					int k;										
					k = codeIndex + 2;
					String strOffset = (String) input.getItem(k);
					// tableswitch의 오프셋에서 상대적인 점프 오프셋을 계산한다.
					int offset = Integer.parseInt(strOffset);
					this.input(input, k, offset-this.mCurOffsetOfSwitch);
					i = k;
					return;
				}
				return;
			}
		
		}// if (Number.IsNumber(code)) {
	}
	
	/** 클래스접근, 멤버변수 접근, 메서드 호출 등의 constant table에서의 인덱스를 찾는다.
	 * getstatic, getfield, putstatic, putfield, invokeXXX, ldc_w 에서 주석으로부터 
	 *  constant table에서의 인덱스를 찾는다.
	 * 지역변수의 경우 iload_index를 iload index로 분리한다.*/
	public HighArray createConstantTableIndex(ByteCodeGeneratorForClass generator, 
			Hashtable2_String listOfConstantTableHashed, 
			/*ArrayListString arrOfPrimitiveTypes,*/ FindFunctionParams func) {
		if (func==null) return null;
		
		CommonGUI.loggingForMessageBox.setText(true, "Making byte code indices and constant table indices for "+func.name+"() ...", false);
		CommonGUI.loggingForMessageBox.setHides(false);
		//Control.view.postInvalidate();
		
		StringTokenizer tokenizer = new StringTokenizer();
		String[] separators = {" ", "//", "(", ")", ",", "::", "[", "]", "\n"};
		
		CommonGUI.loggingForMessageBox.setText(true, "Tokenizing for "+func.name+"() ...", false);
		CommonGUI.loggingForMessageBox.setHides(false);
		//Control.view.postInvalidate();
		
		HighArray input = tokenizer.ConvertToStringArray(this, 100, separators);
		
		CommonGUI.loggingForMessageBox.setText(true, "Making byte code indices for "+func.name+"() ...", false);
		CommonGUI.loggingForMessageBox.setHides(false);
		//Control.view.postInvalidate();
		
		this.createByteCodeIndex2(input, tokenizer);
		
		CommonGUI.loggingForMessageBox.setText(true, "Making constant table indices for "+func.name+"() ...", false);
		CommonGUI.loggingForMessageBox.setHides(false);
		//Control.view.postInvalidate();
		
		listOfIndicesOfNewLines = tokenizer.getListOfIndicesOfSeparator("\n");
		listOfIndicesOfComments = tokenizer.getListOfIndicesOfSeparator("//");
		this.listOfStrs = input;
		
		int i, j;
		
		ReturnOfGetCode returnOfGetCode = new ReturnOfGetCode(0, null);
		//int indexOfLineNumber=-1;
		
		int len = this.listOfIndicesOfComments.count;
		for (int p=0; p<len; p++) {			
			i = this.listOfIndicesOfComments.list[p];
			String str = (String)input.getItem(i);
			
			//CommonGUI.showMessage(true, "p="+p);
			
			if (i==1888) {
			}
						
			
			if (str.equals("//")) {
				//boolean isLabel = this.isLabel(input, i);
				//if (isLabel) continue;
				int indexOfComment = i;
				int indexOfNewLine = indexOfComment - diffFromNewLineToLabelComment;
				if (indexOfNewLine<0 || ((String)input.getItem(indexOfNewLine)).equals("\n")) {
					// label 이면 continue한다.
					continue;
				}
				
				//if (input.getItem(i+1).equals(" ")) {
					String str2 = (String) input.getItem(i+2);
					
					// offset이면 continue한다.
					if (str2.equals("(")) continue;
					
					
					/*else if (str2.equals("2")) continue;
					else if (str2.equals("iconst_0") ||
							str2.equals("iconst_1")) continue;*/
					if (str2.equals("local")) { // 지역변수이면 
						int localTableIndex = -1;
						String code = null;
						this.getCode(i, input, returnOfGetCode);
						if (returnOfGetCode.code!=null) {
							code = returnOfGetCode.code;
							j = returnOfGetCode.codeIndex;
							if (code.contains("load") || code.contains("store")) {
								
								// LocalVarTable
								localTableIndex = this.getLocalTableIndex(code);
								
								if (localTableIndex>3) {
									// iload_4에서 4를 떼어내서 gap공간에 넣는다.
									// j는 iload code의 인덱스
									int _index = code.indexOf("_");
									input.setItem(j, code.substring(0, _index)); // iload로 대체
									this.input(input, j+2, localTableIndex); // 인덱스를 gap공간에 넣는다.
								}
							}
							// 변수의 start_pcOfScope을 구한다.
							if (code.contains("store")) {
								int indexOfLineNumber = this.getCurOffset(input, j);
								this.processStore(input, i, func, indexOfLineNumber);	
							}
						}

						i = this.getIndexOfNewLine(i, input);
						continue;
					} // if (str2.equals("local")) { // 지역변수이면 
					else {
						String code = null;
						this.getCode(i, input, returnOfGetCode);
						if (returnOfGetCode.code!=null) {
							code = returnOfGetCode.code;
							j = returnOfGetCode.codeIndex;
							if (code.equals("newarray")) { // atype
								String descriptorAndAType = this.getDescriptor(input, i);
								int indexOfComma = descriptorAndAType.indexOf(",");
								descriptorAndAType.substring(0, indexOfComma);
								String atype = descriptorAndAType.substring(indexOfComma+2, descriptorAndAType.length());
								int intAtype = Integer.parseInt(atype);
								
								this.input(input, j+2, intAtype);// 인덱스를 gap공간에 넣는다.
								continue;
							}
							else if (code.equals("multianewarray")) {
								String descriptorAndDimension = this.getDescriptor(input, i);
								int indexOfComma = descriptorAndDimension.indexOf(",");
								String descriptor = descriptorAndDimension.substring(0, indexOfComma);
								String dimensionStr = descriptorAndDimension.substring(indexOfComma+2, descriptorAndDimension.length());
								int dimension = Integer.parseInt(dimensionStr);
								
								int k;
								HashItemOfConstantTable hashItem = 
										(HashItemOfConstantTable) listOfConstantTableHashed.getData(descriptor, false);
								k = hashItem.index;
								hashItem.listCode.add(code);
								
								int lenOfk = String.valueOf(k).length();
								this.input(input, j+2, k);// 인덱스를 gap공간에 넣는다.
								this.input(input, j+lenOfk+4, dimension);// 차원을 gap공간에 넣는다.
								continue;
							}
							else if (code.equals("invokeinterface")) {
								String descriptorAndCountAndZero = this.getDescriptor(input, i);
								int indexOfComma = descriptorAndCountAndZero.indexOf(",");
								String descriptor = descriptorAndCountAndZero.substring(0, indexOfComma);
								int indexOfComma2 = descriptorAndCountAndZero.indexOf(",", indexOfComma+1);
								String countStr = descriptorAndCountAndZero.substring(indexOfComma+2, indexOfComma2);
								int countOfArgs = Integer.parseInt(countStr);
								
								int k;
								HashItemOfConstantTable hashItem = 
										(HashItemOfConstantTable) listOfConstantTableHashed.getData(descriptor, false);
								k = hashItem.index;
								hashItem.listCode.add(code);
								
								int lenOfk = String.valueOf(k).length();
								this.input(input, j+2, k);// 인덱스를 gap공간에 넣는다.
								this.input(input, j+lenOfk+4, countOfArgs);// args count을 gap공간에 넣는다.
								continue;
							}
							else if ((code.contains("aload") && code.length()==6) ||
									(code.contains("astore") && code.length()==7)) {
								int indexOfVarUseThatAccessesArrayElement = this.getSourceIndex(input, i);
								this.listOfIndicesOfVarUsesThatAccessesArrayElement.add(indexOfVarUseThatAccessesArrayElement);
							}
							else {
								// getstatic, getfield, putstatic, putfield, invokeXXX, ldc_w
								ByteCodeInstruction instruction = 
										(ByteCodeInstruction) ByteCodeGeneratorForClass.hashTableInstructionSet.getData(code);
								if (instruction==null) {
									continue;
								}
								
								
								String descriptor = this.getDescriptor(input, i);
								/*if (code.equals("ldc_w") || code.equals("ldc2_w")) {
									if (descriptor.length()>0 && descriptor.charAt(0)=='"') {
										// ldc_w의 스트링 상수는 해시테이블에는 "이 없는 스트링이 넣어지고,
										// HighArrayCharForByteCode에는 "이 있는 스트링이 출력된다.
										//descriptor = ByteCode_Helper.removeSymbolsOfString(descriptor);
									}
									else {
										int numberType = Hexa.IsHexa(descriptor);
										// descriptor가 0xff0000과 같은 16진수인 경우에는 정수로 바꿔준다.
										// ByteCode_Phsical.makeCONSTANT_Number_infoAndPutItIntolistOfConstantTable()을 참조한다.
										if (numberType!=0) {
											switch(numberType) {
											case 1:
											case 2:
											case 7:
											case 3: descriptor = String.valueOf(Number.parseInt(descriptor)); break;
											case 4: descriptor = String.valueOf(Number.parseLong(descriptor)); break;
											}
										}
									}
								}*/
								
								HashItemOfConstantTable hashItem = 
										(HashItemOfConstantTable) listOfConstantTableHashed.getData(descriptor, false);
								try {
									if (hashItem!=null) {
										
										this.input(input, j+2, hashItem.index);
										hashItem.listCode.add(code);
									}
								}catch(Exception e) {
									if (Common_Settings.g_printsLog) e.printStackTrace();
								}
								continue;
							}
						}
					}
				//}
			}// if (str.equals("//")) {
		}// for (i=0; i<count; i++) {
				
		
		CommonGUI.loggingForMessageBox.setText(true, "Making informations for stack map entries and local table for "+func.name+"() ...", false);
		CommonGUI.loggingForMessageBox.setHides(false);
		//Control.view.postInvalidate();
		
		len = this.listOfIndicesOfComments.count;
		for (int p=0; p<len; p++) {
			
			
			i = this.listOfIndicesOfComments.list[p];			
			
			int indexOfComment = i;
			int indexOfNewLine = indexOfComment - diffFromNewLineToLabelComment;
			if (!(indexOfNewLine<0 || ((String)input.getItem(indexOfNewLine)).equals("\n"))) {
				// label 이 아니면 continue한다.
				continue;
			}
			
			String str2 = (String)input.getItem(i+2);
			
			
			
			if (i+9<input.count && input.getItem(i+7).equals("try") && input.getItem(i+9).equals("starts")) {
				// (YYY), try starts
				int startIndex = Integer.parseInt((String)input.getItem(i+3));
				
				int startPC = this.getByteCodeOffset(i, input);
				setStartPCOrEndPCToSpecialBlock(startIndex, startPC, true);
				
				int offset = this.getByteCodeOffset(i, input);
				OffsetAndForLoopAndParent item = new OffsetAndForLoopAndParent(offset);
				this.getParentBlock(item, input, i+3);
				item.message = "try starts";
				putItemToListOfJumpOffsetsOfStackMap(item);
			}
			else if (i+9<input.count && input.getItem(i+7)/*str2*/.equals("catch") && input.getItem(i+/*4*/9).equals("starts")) {
				// (YYY), catch starts
				setCatchType(generator, input, i, listOfConstantTableHashed);
				int startPC = Integer.parseInt((String)input.getItem(i+3));
				setStartPCOrEndPCToSpecialBlock(startPC, this.getByteCodeOffset(i, input), true);
				
				int offset = this.getByteCodeOffset(i, input);
				OffsetAndForLoopAndParent item = new OffsetAndForLoopAndParent(offset);
				this.getParentBlock(item, input, i+3);
				item.message = "catch starts";
				putItemToListOfJumpOffsetsOfStackMap(item);
				
				// catch의 try start end offset(catch핸들러가 활동중인 try영역)은 createByteCodeIndex()에서 정해진다.
				// 따라서 다음 라인으로 점프한다.
				i = this.getIndexOfNewLine(i, input);
				
				continue;
			}
			else if (i+4<input.count && input.getItem(i+2).equals("finally") && input.getItem(i+4).equals("starts")) {
				// finally starts
				// called finally block by throw, return, continue or break
				startPCOfFinallyStarts = this.getByteCodeOffset(i, input);
				
				OffsetAndForLoopAndParent item = new OffsetAndForLoopAndParent(startPCOfFinallyStarts);
				//this.getParentBlock(item, input, i+3);
				item.message = "finally starts by throw";
				putItemToListOfJumpOffsetsOfStackMap(item);
				
				listOfAllIndicesOfTokenizerOfCalledFinallyAndOriginalFinally.add(i);
			}
			else if (i+4<input.count && input.getItem(i+2).equals("finally") && input.getItem(i+4).equals("ends")) {
				// finally ends
				// called finally block by throw, return, continue or break
				int endPCOfFinallyEnds = this.getByteCodeOffset(i, input);
				listOfStartPCAndEndPCOfFinallyStartsAndEnds.add(new StartEndIndex(startPCOfFinallyStarts, endPCOfFinallyEnds));
				
				OffsetAndForLoopAndParent item = new OffsetAndForLoopAndParent(endPCOfFinallyEnds);
				item.message = "finally ends by throw";
				putItemToListOfJumpOffsetsOfStackMap(item);
				
				listOfAllIndicesOfTokenizerOfCalledFinallyAndOriginalFinally.add(i);
			}
			else if (i+9<input.count && input.getItem(i+7).equals("finally") && input.getItem(i+13).equals("starts")) {
				// (YYY), finally (handler) starts
				int startPC = Integer.parseInt((String)input.getItem(i+3));
				setStartPCOrEndPCToSpecialBlock(startPC, this.getByteCodeOffset(i, input), true);
				
				int offset = this.getByteCodeOffset(i, input);
				OffsetAndForLoopAndParent item = new OffsetAndForLoopAndParent(offset);
				//this.getParentBlock(item, input, i+3);
				item.message = "finally (handler) starts";
				putItemToListOfJumpOffsetsOfStackMap(item);
			}
			else if (i+9<input.count && input.getItem(i+7).equals("finally") && input.getItem(i+9).equals("starts")) {
				// (YYY), finally starts, 
				// original finally
				int offset = this.getByteCodeOffset(i, input);
				
				OffsetAndForLoopAndParent item = new OffsetAndForLoopAndParent(offset);
				this.getParentBlock(item, input, i+3);
				item.message = "finally starts";
				putItemToListOfJumpOffsetsOfStackMap(item);
				
				listOfAllIndicesOfTokenizerOfCalledFinallyAndOriginalFinally.add(i);
			}
			else if (i+9<input.count && input.getItem(i+7).equals("finally") && input.getItem(i+9).equals("ends")) {
				// (YYY), finally ends
				// original finally
				listOfAllIndicesOfTokenizerOfCalledFinallyAndOriginalFinally.add(i);
			}
			
			else if (i+9<input.count && input.getItem(i+7).equals("throw") && input.getItem(i+9).equals("ends")) {
				// (YYY), throw ends
				/*int throwIndex = Integer.parseInt((String)input.getItem(i+3));
				ThrowStartEnd throwStartEnd = ThrowStack.findThrowStartEnd(compiler, throwIndex);
				int offset = this.getByteCodeOffset(i, input);
				throwStartEnd.endPC = offset;*/
				
				int offset = this.getByteCodeOffset(i, input);
				OffsetAndForLoopAndParent item = new OffsetAndForLoopAndParent(offset);
				item.message = "throw ends";
				putItemToListOfJumpOffsetsOfStackMap(item);
			}
			
		
			/** (mBufferIndex), BlockStart*/
			/*if (i+7<input.count && input.getItem(i+7).equals("BlockStart")) {
				// synchronized, try, catch, finally 등
				int offset = this.getByteCodeOffset(i, input);
				if (offset==2) {
					int a;
					a=0;
					a++;
				}
				OffsetAndForLoopAndParent item = new OffsetAndForLoopAndParent(offset);
				this.getParentBlock(item, input, i+3);
				item.message = "BlockStart";
				putItemToListOfJumpOffsetsOfStackMap(item);
			}//else if (str2.equals("BlockStart")) {
			*/
			
			if (i+2<input.count && input.getItem(i+2).equals("BeforeGoTo")) {
				int offset = this.getByteCodeOffset(i, input);
				OffsetAndForLoopAndParent item = new OffsetAndForLoopAndParent(offset);
				item.message = "BeforeGoTo";
				putItemToListOfJumpOffsetsOfStackMap(item);
			}
			/** (mBufferIndex), case YYY: */
			else if (i+7<input.count && (input.getItem(i+7).equals("case") || input.getItem(i+7).equals("default"))) {
				// // case 0: 
				int offset = this.getByteCodeOffset(i, input);
				OffsetAndForLoopAndParent item = new OffsetAndForLoopAndParent(offset);
				this.getParentBlock(item, input, i+3);
				if (input.getItem(i+7).equals("case")) {
					item.message = "case "+input.getItem(i+10);
				}
				else {
					item.message = "default";
				}
				putItemToListOfJumpOffsetsOfStackMap(item);
			}
			/** (mBufferIndex), increments of for*/
			else if (i+9<input.count && (input.getItem(i+7).equals("increments") && input.getItem(i+9).equals("of"))) {
				// if, for, while 등
				int incrementIndex = Integer.parseInt((String)input.getItem(i+3));
				
				FindControlBlockParams forLoop = this.getForBlockWithIncrementIndex(incrementIndex);
				if (forLoop!=null && forLoop.specialStatement!=null) {
					int offset = this.getByteCodeOffset(i, input);							
					OffsetAndForLoopAndParent item = new OffsetAndForLoopAndParent(offset);
					this.getParentBlock(item, input, i+3);
					item.message = "run of "+input.getItem(i+11);
					putItemToListOfJumpOffsetsOfStackMap(item);
				}
			}
			/** (mBufferIndex), run of YYY*/
			else if (i+9<input.count && (input.getItem(i+7).equals("run") && input.getItem(i+9).equals("of"))) {
				// if, for, while 등
				//if (input.getItem(i+11).equals("Three")==false) {
					int offset = this.getByteCodeOffset(i, input);
					OffsetAndForLoopAndParent item = new OffsetAndForLoopAndParent(offset);
					this.getParentBlock(item, input, i+3);
					item.message = "run of "+input.getItem(i+11);
					putItemToListOfJumpOffsetsOfStackMap(item);
				//}
			}
			/** (mBufferIndex), condition of YYY*/
			else if (i+9<input.count && (input.getItem(i+7).equals("condition") && input.getItem(i+9).equals("of"))) {
				// if, for, while 등
				int offset = this.getByteCodeOffset(i, input);
				boolean makesStackMapEntry = false;
				if (input.getItem(i+11).equals("Three")) {
					makesStackMapEntry = false;
				}
				else {
					makesStackMapEntry = true;
				}
				if (makesStackMapEntry) {
					OffsetAndForLoopAndParent item = new OffsetAndForLoopAndParent(offset);
					this.getParentBlock(item, input, i+3);
					item.message = "condition of "+input.getItem(i+11);
					putItemToListOfJumpOffsetsOfStackMap(item);
				}
				/*if (input.getItem(i+11).equals("Three")) {
					byteCodeOffsetOfConditionForThreeOperandsOperationWith1StackItem =
							offset;
				}*/
			}//else if (input.getItem(i+7).equals("condition") && input.getItem(i+9).equals("of")) {
			else if (i+6<input.count && (input.getItem(i+2).equals("exit") && input.getItem(i+6).equals("return"))) {
				// // exit of return
				int offset = this.getByteCodeOffset(i, input);
				
				OffsetAndForLoopAndParent item = new OffsetAndForLoopAndParent(offset);
				item.message = "exit of "+input.getItem(i+6);
				putItemToListOfJumpOffsetsOfStackMap(item);
			}
			/** (mBufferIndex), exit of YYY*/
			else if (i+9<input.count && (input.getItem(i+7).equals("exit") && input.getItem(i+9).equals("of"))) {
				if (!(i+15<input.count && (input.getItem(i+11).equals("run") && input.getItem(i+13).equals("of")  && input.getItem(i+15).equals("Three")))) {
					// (YYY), exit of run of Three operands operation은 제외한다.
					int offset = this.getByteCodeOffset(i, input);
					OffsetAndForLoopAndParent item = new OffsetAndForLoopAndParent(offset);
					
					this.getParentBlock(item, input, i+3);
					item.message = "exit of "+input.getItem(i+11);
					putItemToListOfJumpOffsetsOfStackMap(item);
					
					if (i+11<input.count && (input.getItem(i+11).equals("Three"))) { // Three operands operation
						item.message = "exit of Three Operands Operation";
						// (mBufferIndex), exit of Three Operands Operation, typeName, indexOfLocalVarsInFunctionBeforeProcessLocalVarsForThreeOperandsOperation
						item.typeNameForThreeOperandsOperation = (String)input.getItem(i+18);
						if (input.getItem(i+19).equals(",")) { // Three operands operation
							item.indexOfVarUseInlistOfLValueForThreeOperandsOperationWith1StackItem = 
									Integer.parseInt((String)input.getItem(i+21));
							item.listOfVarUseForThreeOperandsOperationWith1StackItem = this.listOfVarUseForThreeOperandsOperationWith1StackItem;
							
							// (mBufferIndex), condition of Three Operands Operation에서 설정된 오프셋을 저장한다.
							item.byteCodeOffsetOfConditionForThreeOperandsOperationWith1StackItem = 
									byteCodeOffsetOfConditionForThreeOperandsOperationWith1StackItem;
						}
					}
					else if (i+11<input.count && (input.getItem(i+11).equals("try") || input.getItem(i+11).equals("catch") || 
							input.getItem(i+11).equals("finally"))) {
						// (YYY), exit of try 등
						int endIndex = Integer.parseInt((String)input.getItem(i+3));
						int endPC = this.getByteCodeOffset(i, input);
						setStartPCOrEndPCToSpecialBlock(endIndex, endPC, false);
					}
				}
			}//else if (input.getItem(i+7).equals("exit") && input.getItem(i+9).equals("of")) {
			/** (mBufferIndex), exit_of_condition*/
			else if (i+7<input.count && input.getItem(i+7).equals("exit_of_condition")) {
				if (!input.getItem(i+11).equals("Three")) {
					int offset = this.getByteCodeOffset(i, input);
					OffsetAndForLoopAndParent item = new OffsetAndForLoopAndParent(offset);
					this.getParentBlock(item, input, i+3);
					item.message = "exit_of_condition" + " "+input.getItem(i+9)+" " + input.getItem(i+11);
					putItemToListOfJumpOffsetsOfStackMap(item);
				}
			}
			/** (mBufferIndex), or*/
			else if (i+7<input.count && input.getItem(i+7).equals("or")) {	
				// or로 점프하는 오프셋에서 스택 프레임을 추가한다. 
				int offset = this.getByteCodeOffset(i, input);
				OffsetAndForLoopAndParent item = new OffsetAndForLoopAndParent(offset);
				this.getParentBlock(item, input, i+3);
				item.message = "or";
				putItemToListOfJumpOffsetsOfStackMap(item);
			}//else if (input.getItem(i+7).equals("or")) {
			/** (mBufferIndex), or*/
			else if (i+7<input.count && input.getItem(i+7).equals("and")) {
				// and로 점프하는 오프셋에서 스택 프레임을 추가한다. 
				int offset = this.getByteCodeOffset(i, input);
				OffsetAndForLoopAndParent item = new OffsetAndForLoopAndParent(offset);
				this.getParentBlock(item, input, i+3);
				item.message = "and";
				putItemToListOfJumpOffsetsOfStackMap(item);
			}//else if (input.getItem(i+7).equals("and")) {
			
			
			
			//else if (str2.equals("local")) continue; // 지역변수이면 continue;
			else if (str2.equals("localVarStart")) {
				// localVarStart 1
				FindVarParams var = null;
				String thisOrIndexOfLocalVarInFunc = (String)input.getItem(i+4);
				if (thisOrIndexOfLocalVarInFunc.equals("this")) {
					var = func.thisVar;
				}
				else {
					//int indexOfLocalVarInFunc = Integer.parseInt(thisOrIndexOfLocalVarInFunc);
					//var = (FindVarParams) func.listOfVariableParams.getItem(indexOfLocalVarInFunc);
					try {
					int indexOfLocalVarsInFunctionBeforeProcessLocalVars = 
							Integer.parseInt(thisOrIndexOfLocalVarInFunc);
					var = (FindVarParams) func.listOfVariableParamsBeforeProcessLocalVars.getItem(indexOfLocalVarsInFunctionBeforeProcessLocalVars);
					}catch(Exception e) {
						if (Common_Settings.g_printsLog) e.printStackTrace();
					}
				}
				try {
				var.start_pcOfScope = this.getByteCodeOffset(i, input);
				}catch(Exception e) {
					if (Common_Settings.g_printsLog) e.printStackTrace();
				}
				
			}
			else if (str2.equals("localVarEnd")) {
				// localVarEnd 1
				FindVarParams var = null;
				String thisOrIndexOfLocalVarInFunc = (String)input.getItem(i+4);
				if (thisOrIndexOfLocalVarInFunc.equals("this")) {
					var = func.thisVar;
				}
				else {
					//int indexOfLocalVarTable = Integer.parseInt(thisOrIndexOfLocalVarInFunc);
					//var = (FindVarParams) func.getLocalVar(indexOfLocalVarTable);
					int indexOfLocalVarsInFunctionBeforeProcessLocalVars = 
							Integer.parseInt(thisOrIndexOfLocalVarInFunc);
					var = (FindVarParams) func.listOfVariableParamsBeforeProcessLocalVars.getItem(indexOfLocalVarsInFunctionBeforeProcessLocalVars);
					if (var==null) {
						CompilerStatic.errors.add(new Error(compiler, func.functionNameIndex(), func.functionNameIndex(),
								"invalid var ("+indexOfLocalVarsInFunctionBeforeProcessLocalVars+") in a function "+func) );
						continue;
					}
				}
			
				var.end_pcOfScope = this.getByteCodeOffset(i, input);
				
				if (var.parent instanceof FindSpecialBlockParams) {
					FindSpecialBlockParams special = (FindSpecialBlockParams) var.parent;
					if (special.specialBlockType==FindSpecialBlockParams.SpecialBlockType_try ||
							special.specialBlockType==FindSpecialBlockParams.SpecialBlockType_catch) {
						int end_pcOfScope = this.getOffsetOfGoToOfTryOrCatch(input, i);
						if (end_pcOfScope!=-1) {
							var.end_pcOfScope = end_pcOfScope;
						}
					}
				}
			}//else if (str2.equals("localVarEnd")) {
			/** exit of function*/
			else if (i+6<input.count && (str2.equals("exit") && input.getItem(i+4).equals("of") && input.getItem(i+6).equals("function"))) {							
				int offset = this.getByteCodeOffset(i, input);
				OffsetAndForLoopAndParent item = new OffsetAndForLoopAndParent(offset);
				//this.getParentBlock(item, input, i+3);
				item.parent = null;
				item.message = "exit of function";
				putItemToListOfJumpOffsetsOfStackMap(item);
			}//else if (input.getItem(i+7).equals("exit") && input.getItem(i+9).equals("of")) {
			
			else {							
				//String str3 = input.getItem(i+5);
				//if (str3.equals(",")) continue;
				
				
				
			}// else
		}//for (i=0; i<count; i++) {
		
		changeJumpIndexOfIfAndGotoInCalledFinallyAndOriginalFinally(input, tokenizer);
		
		OffsetAndForLoopAndParent[] arr = toOffsetAndForLoopAndParentArray(this.listOfJumpOffsetsOfStackMap.getItems());
		sort(arr);
		this.listOfJumpOffsetsOfStackMap.list = arr;
					
		int old_offset = 0;
		/** (YYY), exit of for를 만나기 전 마지막 프레임(for루프의 조건문전 마지막 프레임)을 chop프레임으로 설정한다.*/
		for (i=0; i<this.listOfJumpOffsetsOfStackMap.count; i++) {
			OffsetAndForLoopAndParent offset = (OffsetAndForLoopAndParent) this.listOfJumpOffsetsOfStackMap.getItem(i);
			
			int offset_delta = offset.offsetOrOffsetDelta - old_offset;
			old_offset = offset.offsetOrOffsetDelta;
			if (offset_delta>0) {
				OffsetAndForLoopAndParent item = new OffsetAndForLoopAndParent(offset_delta);
				
				//item.forLoop = offset.forLoop;
				item.accumulatedOffset = offset.offsetOrOffsetDelta;
				item.parent = offset.parent;
				item.message = offset.message;
				item.typeNameForThreeOperandsOperation = offset.typeNameForThreeOperandsOperation;
				item.indexOfVarUseInlistOfLValueForThreeOperandsOperationWith1StackItem = 
						offset.indexOfVarUseInlistOfLValueForThreeOperandsOperationWith1StackItem;
				item.listOfVarUseForThreeOperandsOperationWith1StackItem =
						offset.listOfVarUseForThreeOperandsOperationWith1StackItem;
				item.byteCodeOffsetOfConditionForThreeOperandsOperationWith1StackItem =
						offset.byteCodeOffsetOfConditionForThreeOperandsOperationWith1StackItem;
				item.listOfIndicesOfVarUsesThatAccessesArrayElement = 
						offset.listOfIndicesOfVarUsesThatAccessesArrayElement;
				/*if (item.message.contains("exit of")) {
					// for루프안에 다른 제어구조가 있을 경우 condition of for 프레임을 chop프레임으로 바꾼다.
					if (item.parent instanceof FindControlBlockParams) {
						FindControlBlockParams block = (FindControlBlockParams) item.parent;
						if (block.catOfControls!=null) {		// 제어블록	
							int indexConditionItem = listOfOffsetDeltas.count-1;
							if (indexConditionItem==14) {
								int a;
								a=0;
								a++;
							}
							OffsetAndForLoopAndParent conditionItem = (OffsetAndForLoopAndParent) listOfOffsetDeltas.getItem(indexConditionItem);
							conditionItem.message = "condition of "+block.getName();
							conditionItem.parent = block;
						}
					}
				}*/
				this.listOfOffsetDeltas.add(item);
			} // if (offset_delta>0) {
			else {
				if (offset.message.equals("exit of try") || offset.message.equals("exit of catch") || 
						offset.message.equals("exit of finally")) {
					OffsetAndForLoopAndParent oldOffset = (OffsetAndForLoopAndParent) this.listOfOffsetDeltas.getItem(listOfOffsetDeltas.count-1);
					oldOffset.message = offset.message;
					oldOffset.parent = offset.parent;
				}
			}
		}
		
		
		/*for (i=0; i<listOfJumpOffsetsOfStackMap_backup.count; i++) {
			OffsetAndForLoopAndParent item = (OffsetAndForLoopAndParent) listOfJumpOffsetsOfStackMap_backup.getItem(i);
			for (j=0; j<this.listOfOffsetDeltas.count; j++) {
				OffsetAndForLoopAndParent item2 = (OffsetAndForLoopAndParent) listOfOffsetDeltas.getItem(j);
				if (item.accumulatedOffset==item2.accumulatedOffset) {
					item2.mlistOfLocalVars = item.mlistOfLocalVars;
					break;
				}
			}
		}*/
		return input;
	}
	
	/**@param i : //의 input에서의 인덱스
	 * @param j : code의 input에서의 인덱스*/
	/*int getStackMapEntryOffset(HighArray input, int i, String code, int j) {
		int curOffset = this.getCurOffset(input, j);
		int entryOffset = curOffset;
		if (code.contains("if")) {
			entryOffset = this.getByteCodeOffset(i, input);
		}
		return entryOffset;
	}*/
	
	/**@param j : code의 input에서의 인덱스*/
	int getCurOffset(HighArray input, int j) {
		/*int m;
		m = j;
		for (j=m-1; j>=0; j--) {
			if (input.getItem(j).equals(" ")) continue;
			else break;
		}*/
		j = j - diffFromLineNumberToCode;
		
		// code의 현재 offset
		int curOffset = Integer.parseInt((String)input.getItem(j));
		return curOffset;
	}
	
	/*boolean hasAlreadyVisited(int entryOffset) {
		int o;
		for (o=0; o<this.listOfOffsetsVisited.count; o++) {
			int offset = this.listOfOffsetsVisited.getItem(o);
			if (offset==entryOffset) {
				return true;
			}
		}
		return false;
	}*/
	
	
	/**@param i : //의 input에서의 인덱스
	 * @param j : code의 input에서의 인덱스*/
	/*int makeStackMapEntryAndMoveToJumpOffset(HighArray input, int i, String code, int j, int jumpIndex) {
		int curOffset = this.getCurOffset(input, j);
		if (curOffset==103) {
			int a;
			a=0;
			a++;
		}
		int entryOffset = this.getStackMapEntryOffset(input, i, code, j);
		
		
		int jumpOffset = jumpIndex+curOffset;
		
		OffsetAndForLoopAndParent item = new OffsetAndForLoopAndParent(entryOffset);
		item.mlistOfLocalVars = this.mlistOfLocalVars;
		this.mlistOfLocalVars = new ArrayList(2);
		putItemToListOfJumpOffsetsOfStackMap(item);
		
		int indexOfOffsetToMove = this.moveToOffset(input, jumpOffset);		
		
		// for루프에서 i++이 되기 때문에 -1을 한다.
		i = indexOfOffsetToMove-1;
		return i;
	}*/
	
	int moveToOffset(HighArray input, int offsetToMove) {
		int i;
		for (i=0; i<listOfIndicesOfNewLines.count; i++) {
			int indexOfNewLine = listOfIndicesOfNewLines.getItem(i);
			String str = (String)input.getItem(indexOfNewLine+1);
			if (Number.IsNumber2(str)!=0) {
				int offset = Integer.parseInt(str);
				if (offset==offsetToMove) {
					return indexOfNewLine+1;
				}
			}
		}
		return -1;
	}
	
	/** goto와 ifXXX를 따라 다니면서 스택맵 프레임과 지역변수들을 찾는 함수이다. 
	 * 지금은 사용하지 않는다.
	 * @param input
	 * @param func
	 * @return : this.listOfJumpOffsetsOfStackMap, 찾은 스택맵 프레임과 지역변수들을 담는다. 
	 */
	/*ArrayList checkLocalVars(HighArray input, FindFunctionParams func) {
		boolean jumped = false;
		int i, j;
		
		int count = input.getCount();
		
		ReturnOfGetCode returnOfGetCode = new ReturnOfGetCode(0, null);
		
		for (i=0; i<count; i++) {
			String str = (String)input.getItem(i);
			
			if (i>0 && input.getItem(i-1).equals("\n") && Number.IsNumber2(str)!=0) {
				int curOffset = Integer.parseInt(str);
				if (curOffset==103) {
					int a;
					a=0;
					a++;
				}
				if (this.hasAlreadyVisited(curOffset)) {
					i = this.getIndexOfNewLine(i, input);
					continue;
				}
				else {
					putCurOffsetTolistOfOffsetsVisited(curOffset);	
				}
			}
			
			if (jumped && Number.IsNumber2(str)!=0) {
				jumped = false;
				int entryOffset = Integer.parseInt(str);
				OffsetAndForLoopAndParent item = new OffsetAndForLoopAndParent(entryOffset);
				item.mlistOfLocalVars = this.mlistOfLocalVars;
				this.mlistOfLocalVars = new ArrayList(2);				
				putItemToListOfJumpOffsetsOfStackMap(item);
			}
			else if (str.equals("//")) {
				//boolean isLabel = this.isLabel(input, i);
				
				//if (isLabel) continue;
				
				if (input.getItem(i+1).equals(" ")) {
					String str2 = (String)input.getItem(i+2);
					
					
					// goto gap // (offset), go to YYY
					// goto gap // (offset), ixor, ! 에서 '/'의 인덱스<br>
					// ifXXX gap // (offset), YYY
					if (str2.equals("(")) {
						if (input.getItem(i+3).equals("114")) {
						}
						String code = null;
						int m=i;
						for (j=m-1; j>=0; j--) {
							if (input.getItem(j).equals(" ")) continue;
							else break;
						}
						// 시작부분에서 code가 없는 // synchronized starts와 같은 경우 j는 -1이 된다.
						// 시작부분에서           // (348), run of do_while ((float)a<6)
						// 0          iload_2            // local I count
						// 1          iload_1            // local I a
						// 와 같은 경우에는 j는 -1이 된다.
						if (j==-1) continue;
						
						String jumpIndexStr = null;
						try {
						jumpIndexStr = (String)input.getItem(j);
						}catch(Exception e) {
							if (Common_Settings.g_printsLog) e.printStackTrace();
						}
						
						
						if (Number.IsNumber2(jumpIndexStr)!=0) {
							// code는 createByteCodeIndex()에서 넣어진 인덱스이다.
							int jumpIndex = Integer.parseInt(jumpIndexStr);
							m = j;
							for (j=m-1; j>=0; j--) {
								if (input.getItem(j).equals(" ")) continue;
								else break;
							}
							// 시작부분에서 code가 없는 // synchronized starts와 같은 경우 j는 -1이 된다.
							//if (j==-1) continue;
							
							int codeIndex = j;
							code = (String)input.getItem(j);
							if (code.equals("goto_w") || code.equals("goto")) {								
								i = makeStackMapEntryAndMoveToJumpOffset(input, i, code, j, jumpIndex);
								//if (input.getItem(i+7).equals("go") && input.getItem(i+9).equals("to") && input.getItem(i+11).equals("increments")) {
									jumped = true;
								//}
								continue;
							}
							else if (code.equals("ifgt") || code.equals("iflt") || code.equals("ifge") || 
								code.equals("ifle") || code.equals("ifeq") || code.equals("ifne") ||
								code.equals("ifnull") || code.equals("ifnonnull")) {								
								i = makeStackMapEntryAndMoveToJumpOffset(input, i, code, j, jumpIndex);
								jumped = true;
								continue;
							}
							// "tableswitch", "lookupswitch", "offset" 인 경우에는 continue한다.
							if (code!=null) {
								if (code.equals("tableswitch") || code.equals("lookupswitch")) {
									int k;
									mCurOffsetOfSwitch=0;
									// j는 tableswitch의 인덱스
									for (k=j-1; k>=0; k--) {
										if (!input.getItem(k).equals(" ")) {
											mCurOffsetOfSwitch = Integer.parseInt((String)input.getItem(k));
											break;
										}
									}
									int offsetOfNextInstruction = this.getByteCodeOffset(i, input);
									// 1은 tableswitch의 바이트길이, 4는 defaultAddress의 길이
									int countOfPadding = (offsetOfNextInstruction-mCurOffsetOfSwitch)-(1+4);
									
									for (k=j+1; k<input.count; k++) {
										if (!input.getItem(k).equals(" ")) {
											// k는 defaultAddress의 인덱스
											int jumpOffset = Integer.parseInt((String)input.getItem(k));
											//this.input(input, k, jumpOffset-mCurOffsetOfSwitch);
											//this.input(input, k+2, countOfPadding);
											break;
										}
									}
									i = k;
								}									
								continue;
							}
						
						}// if (Number.IsNumber2(code)!=0) {
						
					}// if (str2.equals("(")) {
					
					else if (str2.equals("local")) { // 지역변수이면 
						String code = null;
						this.getCode(i, input, returnOfGetCode);
						if (returnOfGetCode.code!=null) {
							code = returnOfGetCode.code;
							j = returnOfGetCode.codeIndex;
							
							// 변수의 start_pcOfScope을 구한다.
							if (code.contains("store")) {
								FindVarParams varBeforeProcessLocalVars = processStore(input, i, func, j);
								
								// 값이 이미 들어가 있으면 continue
								if (varBeforeProcessLocalVars==null) continue;
								
								mlistOfLocalVars.add(varBeforeProcessLocalVars);
								
							}
						}

						i = this.getIndexOfNewLine(i, input);
						continue;
					} // if (str2.equals("local")) { // 지역변수이면
					
				}
			}
		}// for (i=0; i<count; i++) {
		
		return this.listOfJumpOffsetsOfStackMap;
	}*/
	
	FindControlBlockParams getForBlockWithIncrementIndex(int mBufferIndex) {
		int i;
		int len = compiler.data.mlistOfAllControlBlocks.count;
		for (i=0; i<len; i++) {
			FindControlBlockParams block = (FindControlBlockParams) compiler.data.mlistOfAllControlBlocks.getItem(i);
			if (block.catOfControls==null) continue;
			
			if (compiler.data.mBuffer.getItem(block.nameIndex()).equals("for")) {
				int indexOfSemicolon2 = block.funcCall.endIndex();
				indexOfSemicolon2 = 
						CompilerHelper.SkipBlank(compiler.data.mBuffer, false, indexOfSemicolon2+1, compiler.data.mBuffer.count-1);
				int indexOfIncrement = indexOfSemicolon2;
				if (mBufferIndex==indexOfIncrement) {
					return block;
				}
			}
		}
		return null;
	}
	
	/**스택맵 프레임의 parent블럭을 정해준다. index는 mBuffer에서의 인덱스이다. 
	 * @param index : gotoXX // (mBufferIndex), go to *** 또는 
	 * ifXXX // (mBufferIndex), run 에서 mBufferIndex의 index*/
	private void getParentBlock(OffsetAndForLoopAndParent item,
			HighArray result, int index) {
		
		int mBufferIndex = Integer.parseInt((String)result.getItem(index));
					
		String str4 = (String)result.getItem(index+4);
		// // (mBufferIndex), run of for, if등
		if (str4.equals("run") && result.getItem(index+6).equals("of")) {
			// for, while, do-while의 run 영역 혹은 if, else-if, else의 run 영역
			if (!result.getItem(index+8).equals("Three")) {
				int i;
				int len = compiler.data.mlistOfAllControlBlocks.count;
				for (i=0; i<len; i++) {
					FindControlBlockParams block = (FindControlBlockParams) compiler.data.mlistOfAllControlBlocks.getItem(i);
					if (block.catOfControls==null) continue;
					
					int indexOfRun = -1;
					if (block.isBlock) {
						indexOfRun = block.findBlockParams.startIndex();
					}
					else {
						indexOfRun = CompilerHelper.SkipBlank(compiler.data.mBuffer, false, 
								block.indexOfRightParenthesis()+1, compiler.data.mBuffer.count-1);
					}
					
					// func() {
					// 		for () {} : 
					// }
					// 여기에서 for루프는 다음처럼 시작된다. 
					// (mBufferIndex), run of for
					// 여기에서 item의 parent는 func()가 된다.
					if (indexOfRun==mBufferIndex) {
						if (!block.getName().equals("do_while")) {
							item.parent = block;
						}
						else {
							item.parent = block.parent;
						}
						break;
					}
				}
			}
			else {
				// (mBufferIndex), run of Three Operands Operation
				int i;
				int len = compiler.data.mlistOfThreeOperandsOperation.count;
				for (i=0; i<len; i++) {
					FindThreeOperandsOperation threeOperandsOperation = (FindThreeOperandsOperation) compiler.data.mlistOfThreeOperandsOperation.getItem(i);
					//if (block.catOfControls==null) continue;
					
					int indexOfRun = threeOperandsOperation.indexOfRunOfThreeOperandsOperation;
					if (mBufferIndex==indexOfRun) {
						// (mBufferIndex), run of Three Operands Operation
						// ...
						// (mBufferIndex), exit of YYY 
						// 여기에서 item의 parent는 해당 block이 된다.
						item.parent = threeOperandsOperation.parent;
						//item.parent = threeOperandsOperation;
						break;
					}
				}
			}
		}
		// (mBufferIndex), increments of for 등
		else if (str4.equals("increments") && result.getItem(index+6).equals("of")) {
			int i;
			int len = compiler.data.mlistOfAllControlBlocks.count;
			for (i=0; i<len; i++) {
				FindControlBlockParams block = (FindControlBlockParams) compiler.data.mlistOfAllControlBlocks.getItem(i);
				if (block.catOfControls==null) continue;
				
				if (compiler.data.mBuffer.getItem(block.nameIndex()).equals("for")) {
					int indexOfSemicolon2 = block.funcCall.endIndex();
					indexOfSemicolon2 = 
							CompilerHelper.SkipBlank(compiler.data.mBuffer, false, indexOfSemicolon2+1, compiler.data.mBuffer.count-1);
					int indexOfIncrement = indexOfSemicolon2;
					if (mBufferIndex==indexOfIncrement) {
						
						item.parent = block;
						break;
					}
				}
			}
		}
		// // (mBufferIndex), condition of if, for 등
		else if (str4.equals("condition") && result.getItem(index+6).equals("of")) {
			if (!result.getItem(index+8).equals("Three")) {
				int i;
				
				int len = compiler.data.mlistOfAllControlBlocks.count;
				for (i=0; i<len; i++) {
					FindControlBlockParams block = (FindControlBlockParams) compiler.data.mlistOfAllControlBlocks.getItem(i);
					if (block.catOfControls==null) continue;
					
					int indexOfCondition = block.indexOfLeftParenthesis()+1;
					if (mBufferIndex==indexOfCondition) {
						
						if (!block.getName().equals("do_while")) {
							item.parent = block.parent;
						}
						else {
							item.parent = block;
						}
						break;
					}
				} // for (i=0; i<len; i++) {
			} // if (result.getItem(index+8).equals("Three")==false) {
			else {
				// (mBufferIndex), condition of Three Operands Operation
				int i;
				int len = compiler.data.mlistOfThreeOperandsOperation.count;
				for (i=0; i<len; i++) {
					FindThreeOperandsOperation threeOperandsOperation = (FindThreeOperandsOperation) compiler.data.mlistOfThreeOperandsOperation.getItem(i);
					//if (block.catOfControls==null) continue;
					
					int indexOfCondition = threeOperandsOperation.indexOfCondition;
					if (mBufferIndex==indexOfCondition) {
						// (mBufferIndex), BlockStart
						// ...
						// (mBufferIndex), exit of YYY 
						// 여기에서 item의 parent는 해당 block이 된다.
						item.parent = threeOperandsOperation.parent;
						//item.parent = threeOperandsOperation;
						break;
					}
				}
			}
		}// if (str4.equals("condition") && result.getItem(index+6).equals("of")) {
		// // (mBufferIndex), and, or 등, 
		// 예를들어 if (!(b<1 && c<1) || !(b<0 || c<0)) 에서 &&, || 등
		else if (str4.equals("and") || str4.equals("or") || str4.equals("exit_of_condition")) {
			int i;
			int len = compiler.data.mlistOfAllControlBlocks.count;
			for (i=0; i<len; i++) {
				FindControlBlockParams block = (FindControlBlockParams) compiler.data.mlistOfAllControlBlocks.getItem(i);
				if (block.catOfControls==null) continue;
				if (block.indexOfLeftParenthesis()==-1) continue;
				
				if (block.indexOfLeftParenthesis()<=mBufferIndex && mBufferIndex<=block.indexOfRightParenthesis()) {
					// (mBufferIndex), run of if
					// ...
					// (mBufferIndex), condition of if
					// ...
					// (mBufferIndex), and(or)
					// ...
					// (mBufferIndex), exit_of_condition of if 
					// 여기에서 item의 parent는 if가 된다.
					item.parent = block;
					break;
				}
			}
		}
		// // (mBufferIndex), FunctionStart
		else if (str4.equals("FunctionStart")) {
			int i;
			int len = compiler.data.mlistOfAllFunctions.count;
			for (i=0; i<len; i++) {
				FindFunctionParams func = (FindFunctionParams) compiler.data.mlistOfAllFunctions.getItem(i);
				if (func.findBlockParams.startIndex()==mBufferIndex) {
					item.parent = func;
					break;
				}
			}
		}
		// // (mBufferIndex), BlockStart
		else if (str4.equals("BlockStart")) {
			int i;
			int len = compiler.data.mlistOfAllControlBlocks.count;
			for (i=0; i<len; i++) {
				FindControlBlockParams block = (FindControlBlockParams) compiler.data.mlistOfAllControlBlocks.getItem(i);
				
				int indexOfKeyword = -1;
				if (!block.isFake) {
					indexOfKeyword = block.nameIndex();
				}
				else {
					if (block instanceof FindSpecialBlockParams) {
						FindSpecialBlockParams special = (FindSpecialBlockParams) block;
						/*if (special.specialBlockType==FindSpecialBlockParams.SpecialBlockType_try) {
							if (special.anotherName.equals(ByteCode_Types.TryCatchShieldForConsole)) {
								indexOfKeyword = ByteCode_Types.startIndexOfFakeTryInMain;
							}
							else {
								indexOfKeyword = ByteCode_Types.startIndexOfFakeTryInFuncWithSync;
							}
						}
						else if (special.specialBlockType==FindSpecialBlockParams.SpecialBlockType_catch) {
							indexOfKeyword = ByteCode_Types.startIndexOfFakeCatchInMain;
						}
						else if (special.specialBlockType==FindSpecialBlockParams.SpecialBlockType_finally) {
							indexOfKeyword = ByteCode_Types.startIndexOfFakeFinallyInFuncWithSync;
						}*/
						indexOfKeyword = ByteCode_Types.getFakeTryCatchFinallyIndex(special, 0);
					}
				}
							
				if (indexOfKeyword==mBufferIndex) {
					if (mBufferIndex==2901) {
					}
					
					// func() {
					// 		for () {} : 
					// }
					// 여기에서 for루프는 다음처럼 시작된다. 
					// (mBufferIndex), run of for
					// 여기에서 item의 parent는 func()가 된다.
					item.parent = block.parent;
					break;
				}
			}
			
		}
		// // (mBufferIndex), exit of function, exit of YYY, exit of Three Operands Operation 등
		else if (str4.equals("exit")) {
			if (result.getItem(index+8).equals("function")) {
				int i;
				int len = compiler.data.mlistOfAllFunctions.count;
				for (i=0; i<len; i++) {
					FindFunctionParams func = (FindFunctionParams) compiler.data.mlistOfAllFunctions.getItem(i);
					if (func.findBlockParams.endIndex()==mBufferIndex) {
						item.parent = func;
						break;
					}
				}
			}
			else if (result.getItem(index+8).equals("Three")) {
				// (mBufferIndex), exit of Three Operands Operation
				int i;
				int len = compiler.data.mlistOfThreeOperandsOperation.count;
				for (i=0; i<len; i++) {
					FindThreeOperandsOperation threeOperandsOperation = (FindThreeOperandsOperation) compiler.data.mlistOfThreeOperandsOperation.getItem(i);
					//if (block.catOfControls==null) continue;
					
					int indexOfExit = threeOperandsOperation.indexOfEndOfThreeOperandsOperation;
					if (mBufferIndex==indexOfExit) {
						// (mBufferIndex), BlockStart
						// ...
						// (mBufferIndex), exit of YYY 
						// 여기에서 item의 parent는 해당 block이 된다.
						item.parent = threeOperandsOperation.parent;
						//item.parent = threeOperandsOperation;
						break;
					}
				}
			}// else if (result.getItem(index+8).equals("Three")) {
			else if (result.getItem(index+8).equals("run")) {
				// (mBufferIndex), exit of run of Three Operands Operation
				int i;
				int len = compiler.data.mlistOfThreeOperandsOperation.count;
				for (i=0; i<len; i++) {
					FindThreeOperandsOperation threeOperandsOperation = (FindThreeOperandsOperation) compiler.data.mlistOfThreeOperandsOperation.getItem(i);
					//if (block.catOfControls==null) continue;
					
					int indexOfExit = threeOperandsOperation.indexOfExitOfRun;
					if (mBufferIndex==indexOfExit) {
						// (mBufferIndex),  exit of run of Three Operands Operation
						// ...
						// (mBufferIndex), exit of YYY 
						// 여기에서 item의 parent는 해당 block이 된다.
						item.parent = threeOperandsOperation.parent;
						//item.parent = threeOperandsOperation;
						break;
					}
				}
			}// else if (result.getItem(index+8).equals("run")) {
			else {
				int i;
				int len = compiler.data.mlistOfAllControlBlocks.count;
				for (i=0; i<len; i++) {
					FindControlBlockParams block = (FindControlBlockParams) compiler.data.mlistOfAllControlBlocks.getItem(i);
					
					int indexOfExit = -1;
					if (!block.isFake) {
						if (block.endIndexWhenNestingControlBlockWithoutMiddlePair==-1) { 
							indexOfExit = block.endIndex();
						}
						else {
							indexOfExit = block.endIndexWhenNestingControlBlockWithoutMiddlePair;
						}
						if (mBufferIndex==indexOfExit) {
							// (mBufferIndex), BlockStart
							// ...
							// (mBufferIndex), exit of YYY 
							// 여기에서 item의 parent는 해당 block이 된다.
							
							item.parent = block;
							break;
						}
					} // if (!block.isFake) {
					else {
						if (block instanceof FindSpecialBlockParams) {
							FindSpecialBlockParams special = (FindSpecialBlockParams) block;
							int endIndex = ByteCode_Types.getFakeTryCatchFinallyIndex(special, 1);							
							/*if (special.specialBlockType==FindSpecialBlockParams.SpecialBlockType_try) {
								if (special.anotherName.equals(ByteCode_Types.TryCatchShieldForConsole)) {
									endIndex = ByteCode_Types.endIndexOfFakeTryInMain;
								}
								else if (special.anotherName.equals(ByteCode_Types.TryFinallyShieldForFuncWithSync)) {
									endIndex = ByteCode_Types.endIndexOfFakeTryInFuncWithSync;
								}
							}
							else if (special.specialBlockType==FindSpecialBlockParams.SpecialBlockType_catch) {
								endIndex = ByteCode_Types.endIndexOfFakeCatchInMain;
							}
							else if (special.specialBlockType==FindSpecialBlockParams.SpecialBlockType_finally) {
								endIndex = ByteCode_Types.endIndexOfFakeFinallyInFuncWithSync;
							}*/
							if (mBufferIndex==endIndex) {
								item.parent = block;
								break;
							}
						}// if (block instanceof FindSpecialBlockParams) {
					}
				}// for (i=0; i<len; i++) {				
			}
			
		}//else if (str4.equals("exit")) {
		else if (str4.equals("try") || str4.equals("catch")) {
			// // (mBufferIndex), try starts
			int i;
			int len = compiler.data.mlistOfAllControlBlocks.count;
			for (i=0; i<len; i++) {
				FindControlBlockParams block = (FindControlBlockParams) compiler.data.mlistOfAllControlBlocks.getItem(i);
				
				int indexOfKeyword = -1;
				if (!block.isFake) {
					indexOfKeyword = block.nameIndex();
				}
				else {
					if (block instanceof FindSpecialBlockParams) {
						FindSpecialBlockParams special = (FindSpecialBlockParams) block;
						/*if (special.specialBlockType==FindSpecialBlockParams.SpecialBlockType_try) {
							if (special.anotherName.equals(ByteCode_Types.TryCatchShieldForConsole)) {
								indexOfKeyword = ByteCode_Types.startIndexOfFakeTryInMain;
							}
							else {
								indexOfKeyword = ByteCode_Types.startIndexOfFakeTryInFuncWithSync;
							}
						}
						else if (special.specialBlockType==FindSpecialBlockParams.SpecialBlockType_catch) {
							indexOfKeyword = ByteCode_Types.startIndexOfFakeCatchInMain;
						}
						else if (special.specialBlockType==FindSpecialBlockParams.SpecialBlockType_finally) {
							indexOfKeyword = ByteCode_Types.startIndexOfFakeFinallyInFuncWithSync;
						}*/
						indexOfKeyword = ByteCode_Types.getFakeTryCatchFinallyIndex(special, 0);
					}
				}
							
				if (indexOfKeyword==mBufferIndex) {
					if (mBufferIndex==2901) {
					}
					item.parent = block.parent;
					break;
				}
			}
		}// else if (str4.equals("try") || str4.equals("catch")) {
		
		else if (str4.equals("case") || str4.equals("default")) {
			// switch의 case문
			int i;
			int len = compiler.data.mlistOfAllControlBlocks.count;
			for (i=0; i<len; i++) {
				FindControlBlockParams block = (FindControlBlockParams) compiler.data.mlistOfAllControlBlocks.getItem(i);
				//if (block.catOfControls==null) continue;
				
				int indexOfName = block.nameIndex();
				if (mBufferIndex==indexOfName) {
					// (mBufferIndex), case
					// ...
					// (mBufferIndex), case 
					// 여기에서 item의 parent는 해당 block이 된다.
					//item.parent = block.parent;
					item.parent = block;
					break;
				}
			}
		}
		else if (str4.equals("SwitchStart")) {
			// switch의 case문
			int i;
			int len = compiler.data.mlistOfAllControlBlocks.count;
			for (i=0; i<len; i++) {
				FindControlBlockParams block = (FindControlBlockParams) compiler.data.mlistOfAllControlBlocks.getItem(i);
				//if (block.catOfControls==null) continue;
				
				int indexOfName = block.nameIndex();
				if (mBufferIndex==indexOfName) {
					// (mBufferIndex), SwitchStart
					// 여기에서 item의 parent는 해당 block이 된다.
					item.parent = block.parent;
					break;
				}
			}
		}
	}
	
	
	void putItemToListOfJumpOffsetsOfStackMap(OffsetAndForLoopAndParent item) {
		if (this.listOfIndicesOfVarUsesThatAccessesArrayElement.count>0) {
			item.listOfIndicesOfVarUsesThatAccessesArrayElement = 
					new ArrayListInt(listOfIndicesOfVarUsesThatAccessesArrayElement.count);
			Array.Copy(this.listOfIndicesOfVarUsesThatAccessesArrayElement.list, 0, 
					item.listOfIndicesOfVarUsesThatAccessesArrayElement.list, 0, this.listOfIndicesOfVarUsesThatAccessesArrayElement.count);
			this.listOfIndicesOfVarUsesThatAccessesArrayElement.count = 0;
		}
		this.listOfJumpOffsetsOfStackMap.add(item);
	}
	
	
	/**@return : 변수의 start_pcOfScope이 바뀌었으면 바뀐 지역변수를 리턴하고, 그렇지 않으면 null를 리턴한다.*/
	FindVarParams processStore(HighArray input, int i, FindFunctionParams func, int lineNumber) {
		
		int indexOfLocalVarsInFunctionBeforeProcessLocalVars = 
				this.getIndexOfLocalVarsInFunctionBeforeProcessLocalVars(input, i);
		if (indexOfLocalVarsInFunctionBeforeProcessLocalVars==-1) {
			return null;
		}
		
		FindVarParams varBeforeProcessLocalVars = null;
		try {
			varBeforeProcessLocalVars = (FindVarParams) func.listOfVariableParamsBeforeProcessLocalVars.getItem(indexOfLocalVarsInFunctionBeforeProcessLocalVars);
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
			
		}
		
		if (varBeforeProcessLocalVars==null) {
			CompilerStatic.errors.add(new Error(compiler, func.functionNameIndex(), func.functionNameIndex(),
					"invalid var ("+indexOfLocalVarsInFunctionBeforeProcessLocalVars+") in a function "+func) );
			return null;
		}
		// 값이 이미 들어가 있으면 continue
		if (varBeforeProcessLocalVars.start_pcOfScope!=-1) return null;
		
		// 변수가 정의된 이후에 최초로 값이 저장될 때를 start_pcOfScope로 삼는다.
		// k는 store의 바이트코드 인덱스
		varBeforeProcessLocalVars.start_pcOfScope = lineNumber;
	
		return varBeforeProcessLocalVars;
	}

	/** mBufferIndexOfForLoopEnd가 for루프의 endIndex이고 for루프 안에 if블록이 있으면 for루프의 레퍼런스를 리턴한다.*/
	FindControlBlockParams findForLoop(int mBufferIndexOfRunOfFor) {
		int i;
		int len = compiler.data.mlistOfAllControlBlocks.count;
		for (i=0; i<len; i++) {
			FindControlBlockParams block = (FindControlBlockParams) compiler.data.mlistOfAllControlBlocks.getItem(i);
			if (block.catOfControls==null || block.catOfControls.category!=CategoryOfControls.Control_for)
				continue;
			
			int indexOfRun = -1;
			if (block.isBlock) {
				indexOfRun = block.findBlockParams.startIndex();
			}
			else {
				indexOfRun = CompilerHelper.SkipBlank(compiler.data.mBuffer, false, 
						block.indexOfRightParenthesis()+1, compiler.data.mBuffer.count-1);
			}
			
			if (indexOfRun==mBufferIndexOfRunOfFor) {
				return block;
			}
		}
		return null;
	}
	
	static class ReturnOfGetCode {
		int codeIndex;
		String code;
		ReturnOfGetCode(int codeIndex, String code) {
			this.codeIndex = codeIndex;
			this.code = code;
		}
	}
	
	static class StartEndIndex {
		int startPCOfFinallyStarts;
		int endPCOfFinallyEnds;
		StartEndIndex(int startPCOfFinallyStarts, int endPCOfFinallyEnds) {
			this.startPCOfFinallyStarts = startPCOfFinallyStarts;
			this.endPCOfFinallyEnds = endPCOfFinallyEnds;
		}
	}
	
	int getIndexOfNewLine(int i, HighArray input) {
		int j;
		for (j=i+1; j<input.count; j++) {
			if (input.getItem(j).equals("\n")) return j;
		}
		return -1;
	}
	
	/** 숫자	code	index	// xxxx <br>
	 * 숫자	code	// xxxx <br>
	 * 에서 code를 리턴한다.
	 * @param i : input에서의 주석 // 의 인덱스*/
	void getCode(int i, HighArray input, ReturnOfGetCode returnOfGetCode) {
		int j;
		String code = null;
		/*for (j=i-1; j>=0; j--) {
			if (input.getItem(j).equals(" ")) continue;
			else break;
		}*/
		j = i - diffFromCodeToOffsetComment;
		// 시작부분에서 code가 없는 // synchronized starts와 같은 경우 j는 -1이 된다.
		if (j==-1) {
			returnOfGetCode.code = null;
			return;
		}
		
		code = (String)input.getItem(j);
		
		// 		// synchronized starts와 같은 경우 j는 /n을 가리킨다.
		if (code.equals("\n")) {
			returnOfGetCode.code = null;
			return;
		}
		
		//if (Number.IsNumber2(code)!=0) {
		/*if (this.isNumber(code)) {
			// code가 숫자이면 진짜 code를 찾는다.
			// 숫자	code	index	// 와 같은 경우
			int k;
			do {
				for (k=j-1; k>=0; k--) {
					if (input.getItem(k).equals(" ")) continue;
					else break;
				}
				code = (String)input.getItem(k);
				//if (Number.IsNumber2(code)==0) {
				if (!this.isNumber(code)) {
					returnOfGetCode.codeIndex = k;
					returnOfGetCode.code = code;
					return;
				}
				j = k;
			}while(true);
		}*/
		// code가 숫자가 아닌 경우
		returnOfGetCode.codeIndex = j;
		returnOfGetCode.code = code;
	}
	
	/** mBufferIndexOfExitOfFor가 for루프의 endIndex이고 for루프 안에 if블록이나 for블록이 있으면, 
	 * 즉 chop프레임을 포함하면 for루프의 레퍼런스를 리턴한다.*/
	/*FindControlBlockParams isChopFrame(int mBufferIndexOfExitOfFor) {
		int i, j;
		int len = compiler.mlistOfAllControlBlocks.count;
		for (i=0; i<len; i++) {
			FindControlBlockParams block = (FindControlBlockParams) compiler.mlistOfAllControlBlocks.getItem(i);
			if (block.endIndex()==mBufferIndexOfExitOfFor) {
				// 원하는 for루프를 찾았다.
				for (j=0; j<block.listOfStatements.count; j++) {
					FindStatementParams statement = (FindStatementParams) block.listOfStatements.getItem(j);
					if (statement instanceof FindControlBlockParams) {
						return block;
					}
				}
			}
		}
		return null;
	}*/
	
	/** (mBufferIndex), exit of for를 만나서 chop 프레임을 찾기 위해 
	 * (mBufferIndex), condition of for의 오프셋과 같은 오프셋을 갖는
	 * 프레임(for루프의 조건문전에 있는 마지막프레임)을 chop 프레임으로 리턴한다.
	 * chop프레임의 OffsetAndForLoopAndParent을 리턴한다.
	 * @return ArrayList : OffsetAndForLoopAndParent[]*/
	/*OffsetAndForLoopAndParent getOffsetAndForLoopAndParentOfChopFrame(FindFunctionParams func) {
		int i;
		ArrayList r = new ArrayList(3);
		if (func.name.equals("f")) {
			int a;
			a=0;
			a++;
		}
		for (i=0; i<this.listOfJumpOffsetsOfStackMap.count; i++) {
			OffsetAndForLoopAndParent offset = (OffsetAndForLoopAndParent) this.listOfJumpOffsetsOfStackMap.getItem(i);
			
			if (offset.offsetOrOffsetDelta == this.offsetOfConditionOfFor) {
				r.add(offset);
			}
		}
		
		OffsetAndForLoopAndParent offset_old = null;
		if (r.count>0) {
			offset_old = (OffsetAndForLoopAndParent) r.getItem(0);
			return offset_old;
		}
		return null;
	}*/
	
	OffsetAndForLoopAndParent[] toOffsetAndForLoopAndParentArray(Object[] arr) {
		OffsetAndForLoopAndParent[] r = new OffsetAndForLoopAndParent[arr.length];
		int i;
		for (i=0; i<r.length; i++) {
			r[i] = (OffsetAndForLoopAndParent) arr[i];
		}
		return r;
	}
	
	public static void sort(OffsetAndForLoopAndParent[] arr) {
		int i, j;
		OffsetAndForLoopAndParent temp;
		int len = arr.length;
		for (i=0; i<len; i++) {
			int min = arr[i].offsetOrOffsetDelta;
			int newMinIndex = i;
			for (j=i+1; j<len; j++) {
				
				int cur = arr[j].offsetOrOffsetDelta;
				if (min>cur) {
					newMinIndex = j;
					min = cur;
				}
			}
			// swapping
			if (arr[i].offsetOrOffsetDelta>arr[newMinIndex].offsetOrOffsetDelta) {
				temp = arr[i];
				arr[i] = arr[newMinIndex];
				arr[newMinIndex] = temp;
			}
		}
	}
	
	int getIndexOfLocalVarsInFunctionBeforeProcessLocalVars(HighArray result, int i) {
		if (result.getItem(i+2).equals("local")) {
			int j;
			boolean found = false;
			for (j=i; j<result.count; j++) {
				String str = (String)result.getItem(j); 
				if (str.equals(",")) {
					found = true;
					break;
				}
				else if (str.equals("\n"))
					break;
			}
			if (found) {
				String str = (String)result.getItem(j+2);
				//if (Number.IsNumber2(str)!=0) {
				if (Number.isNumber(str)) {
					return Integer.parseInt(str);
				}
			}
		}
		return -1;
	}
	
	
	/** srcIndex에 constantTableIndex를 string으로 변환하여 
	 * insert가 아니라 공백을 constantTableIndex으로 replace한다.
	 * @param result ; result of tokenizer in createConstantTableIndex()*/
	void input(HighArray result, int srcIndex, int byteCodeOffset) {
		String strbyteCodeOffset = String.valueOf(byteCodeOffset);
		result.setItem(srcIndex, strbyteCodeOffset);
	}
	
	/** i는 //의 인덱스이고 // 다음에 있는 [SourceIndex]에서 SourceIndex를 얻는다.*/
	int getSourceIndex(HighArray result, int i) {
		int j;
		for (j=i+2; j<=result.count; j++) {
			String str = (String)result.getItem(j);
			if (result.getItem(j).equals(",") && result.getItem(j+1).equals(" ") && 
					result.getItem(j+2).equals("[") && result.getItem(j+4).equals("]")) {
				return Integer.parseInt((String)result.getItem(j+3));
			}
			if (str.equals("\n")) return -1;
		}
		return -1;
	}
	
	/** i는 //의 인덱스이고 // 다음에 있는 필드나 메서드, 클래스의 디스크립터를 얻는다.*/
	String getDescriptor(HighArray input, int i) {
		int j;
		String r = "";
		
		for (j=i+2; j<input.count; j++) {
			String str = (String)input.getItem(j);
			if (j+4<input.count && (str.equals(",") && input.getItem(j+1).equals(" ") && 
					input.getItem(j+2).equals("[") && input.getItem(j+4).equals("]"))) {
				return r;
			}
			if (str.equals("\n")) return r;
			r += str;
		}
		return null;
	}
	
	
	
	
	int getOffsetOfCatchOrFinally(int byteCodeIndex) {
		int i;
		int leftPair=-1, rightPair=-1;
		ArrayListChar offset = new ArrayListChar(5); 
		for (i=byteCodeIndex-1; i>=0; i--) {
			char c = this.getItem(i);			
			if (c==')') {
				rightPair = i;
			}
			else if (c=='/' && this.getItem(i-1)=='/' && this.getItem(i-2)!='T' && this.getItem(i+2)=='(') {
				leftPair = i+2;
				int j;
				for (j=leftPair+1; j<rightPair; j++) {
					offset.add(this.getItem(j));
				}
				break;
			}
		}
		String strOffset = new String(offset.getItems());
		return Integer.parseInt(strOffset);
	}
	
	int findLabelIndex(int offset) {
		int i, j, k;
		int count = this.getCount();
		ArrayListChar r = new ArrayListChar(3);
		
		if (offset==1635) {
		}
		//for (i=0; i<count; i++) {
		for (k=0; k<this.indicesOfLeftParent.count; k++) {
			i = this.indicesOfLeftParent.getItem(k);
			char c = this.getItem(i);
			if (c=='(') 
			{
				r.reset2();
				for (j=i+1; j<count; j++) {
					char c2 = this.getItem(j);
					if (c2==')') break;
					else r.add(c2);
				}
				String str = new String(r.getItems());
				int offsetInParent = -1;
				try {
					offsetInParent = Integer.parseInt(str);
				}catch(Exception e) {
					continue;
				}
				// offset 또는 label이면
				if (offset==offsetInParent) {
					
					// i-1=공백, i-2=/, i-3=/
					if (this.isOffsetOrLabel(i-3)==2) {
						return this.findLabelIndexOfNextLine(i);
					}//if (this.isOffsetOrLabel(i-3)==false) {
				}//if (offset==offsetInParent) {
			}//if (c=='(') 
		}//for (i=0; i<count; i++) {
		return -1;
	}//int findLabelIndex(int offset) {
	
	/** @param i : gap // (label) 에서 (의 인덱스*/
	int findLabelIndexOfNextLine(int i) {
		// label
		ArrayListChar address = new ArrayListChar(3);
		int startIndex = i;
		while (true) {
			int k;
			address.reset2();
			// address를 찾기위해 다음 줄로 간다.
			for (k=startIndex+1; k<count; k++) {
				char c3 = this.getItem(k);
				if (c3==' ') continue;
				else if (c3=='\n') break;
				else continue;
			}
			int m;
			// 바이트코드 행번호를 찾는다.
			for (m=k+1; m<count; m++) {
				char c4 = this.getItem(m);
				if (c4==' ') break;
				else address.add(c4);
			}
			startIndex = k+1;
			if (startIndex>=this.count) {
				break;
			}
			try {
				return Integer.parseInt(new String(address.getItems()));
			}catch(Exception e) {
				// 행번호가 없을 경우 예외가 발생하고 다음 행을 찾는다.
				continue;
			}
		}//while (true) {
		return -1;
	}
	
	
	/** @param i : gap // (label) 에서 //의 인덱스*/
	int findLabelIndexOfNextLine_String(HighArray list, int i) {
		// label
		//ArrayListChar address = new ArrayListChar(3);
		int startIndex = i;
		while (true) {
			int k;
			//address.reset2();
			// address를 찾기위해 다음 줄로 간다.
			for (k=startIndex+1; k<list.count; k++) {
				String c3 = (String)list.getItem(k);
				//if (c3.equals("\n")) break;
				if (c3.charAt(0)=='\n') break;
			}
			if (k>=list.count) {
				break;
			}
			startIndex = k;
			try {
				return Integer.parseInt((String)list.getItem(k+1));
			}catch(Exception e) {
				// 행번호가 없을 경우 예외가 발생하고 다음 행을 찾는다.
				continue;
			}
		}//while (true) {
		return -1;
	}
	
	FindSpecialBlockParams getTryOrCatch(int mBufferIndexOfEndOfTryOrCatch) {
		int i;
		FindSpecialBlockParams r = null;
		for (i=0; i<compiler.data.mlistOfAllControlBlocks.count; i++) {
			FindControlBlockParams control = (FindControlBlockParams) compiler.data.mlistOfAllControlBlocks.getItem(i);
			if (control instanceof FindSpecialBlockParams) {
				FindSpecialBlockParams special = (FindSpecialBlockParams) control;
				if (!special.isFake) {
					if (special.endIndex()==mBufferIndexOfEndOfTryOrCatch) {
						r = special;
						break;
					}
				}
				else {
					/*if (special.specialBlockType==FindSpecialBlockParams.SpecialBlockType_try) {
						if (ByteCode_Types.endIndexOfFakeTryInMain==mBufferIndexOfEndOfTryOrCatch) {
							r = special;
							break;
						}
						if (ByteCode_Types.endIndexOfFakeTryInFuncWithSync==mBufferIndexOfEndOfTryOrCatch) {
							r = special;
							break;
						}
					}
					else if (special.specialBlockType==FindSpecialBlockParams.SpecialBlockType_catch) {
						if (ByteCode_Types.endIndexOfFakeCatchInMain==mBufferIndexOfEndOfTryOrCatch) {
							r = special;
							break;
						}
					}
					else if (special.specialBlockType==FindSpecialBlockParams.SpecialBlockType_finally) {
						if (ByteCode_Types.endIndexOfFakeFinallyInFuncWithSync==mBufferIndexOfEndOfTryOrCatch) {
							r = special;
							break;
						}
					}*/
					if (ByteCode_Types.getFakeTryCatchFinallyIndex(special, 1)==mBufferIndexOfEndOfTryOrCatch) {
						r = special;
						break;
					}
						
				}// if (isFake)
			}
		}
		return r;
	}
	
	/**try, catch 안에서 선언된 변수의 endPC_scope를 try, catch의 마지막 goto문의 바이트코드 오프셋으로 
	 * 바꿔주기 위해 호출한다.
	 * @param input
	 * @param index
	 * @return
	 */
	int getOffsetOfGoToOfTryOrCatch(HighArray input, int index) {
		int mBufferIndexOfEndOfTryOrCatch = 
				this.getmBufferIndexOfEndOfTryOrCatch_createConstantTableIndex(input, index);
		return this.getOffsetOfGoToOfTryOrCatch_sub(input, index, mBufferIndexOfEndOfTryOrCatch);
	}
	
	int getOffsetOfGoToOfTryOrCatch_sub(HighArray input, int index, int mBufferIndexOfEndOfTryOrCatch) {
		FindSpecialBlockParams r = getTryOrCatch(mBufferIndexOfEndOfTryOrCatch);
		if (r==null) return -1;
		if (r.tryCatchFinallyHasGoTo) {
			int i;
			for (i=index-1; i>=0; i--) {
				String str = (String)input.getItem(i);
				if (str.equals("goto") || str.equals("goto_w")) {
					int j;
					for (j=i-1; j>=0; j--) {
						String str2 = (String)input.getItem(j);
						if (str2.equals(" ")) continue;
						else {
							return Integer.parseInt(str2);
						}
								
					}
				}
			}
		}
		return -1;
	}
	
	int getmBufferIndexOfEndOfTryOrCatch_createConstantTableIndex(HighArray input, int index) {
		int i;
		for (i=index+1; i<input.count; i++) {
			// (YYY), exit of try 등
			if (input.getItem(i).equals("exit") && input.getItem(i+2).equals("of")) {
				String str4 = (String)input.getItem(i+4); 
				if (str4.equals("try") || str4.equals("catch")) {
					return Integer.parseInt((String)input.getItem(i-4));
				}
			}
		}
		return i-1;
	}
	
	/** try, catch가 goto를 마지막 부분에 갖고 있다면 goto의 바이트코드 오프셋을 리턴한다.*/
	int findLabelIndexOfGoTo_createByteCodeIndex(int mBufferIndexOfEndOfTryOrCatch, int index) {
		FindSpecialBlockParams r = getTryOrCatch(mBufferIndexOfEndOfTryOrCatch);
		int i;
		
		if (r.tryCatchFinallyHasGoTo) {
			for (i=index-1; i>=0; i--) {
				if (i-3>=0 && this.getItem(i-3)=='g' && this.getItem(i-2)=='o' && this.getItem(i-1)=='t' && this.getItem(i)=='o') {
					int j;
					ArrayListChar offset = new ArrayListChar(6);
					for (j=i-4; j>=0; j--) {
						char c = this.getItem(j);
						if (c==' ') continue;
						else if (c=='\n') {
							int k;
							for (k=j+1; k<this.count; k++) {
								char c2 = this.getItem(k);
								if (c2==' ') break;
								offset.add(c2);								
							}
							break;
						}
					}
					return Integer.parseInt(new String(offset.getItems()));
				}
			}
		}
		return -1;
	}
	
	/**@param i : opcode // (offset) 에서 '/'의 인덱스*/
	int getOffset_createByteCodeIndex(int i) {
		if (i==16613) {
		}
		char c = this.getItem(i);
		int j;
		ArrayListChar r = new ArrayListChar(3); 
		if (c=='/' && this.getItem(i+1)=='/') {
			// i+2=공백, i+3='('
			char leftParent = this.getItem(i+3);
			if (leftParent=='(') {
				int count = this.getCount();
				for (j=i+4; j<count; j++) {
					char rightParent = this.getItem(j);
					if (rightParent==')') break;
					else {
						r.add(rightParent);
					}
				}
				
			}
		}
		try {
			char[] arr = r.getItems();
			String str = new String(arr);
			return Integer.parseInt(str);
		}catch(Exception e) {
			// 30 ldc_w		// " // (" 와 같이 인용문 안에 있는 ( 은 에러를 일으킨다. 
			if (Common_Settings.g_printsLog) e.printStackTrace();
		}
		return -1;
	}
	
	
	
	
	/**일반 주석이면 0을 리턴하고 
	 * opcode gap // (offset) 이면 1을 리턴하고, 
	 * gap // (Label) 이면 2를 리턴한다. 
	 * catch(finally) starts T// (try_start_offset), T// (try_end_offset) 이면 8을 리턴한다.
	 * 
	 * @param i : <br>
	 * opcode gap // (offset) 에서 '/'의 인덱스<br>
	 * gap // (Label)에서 '/'의 인덱스<br>
	 * catch(finally) starts T// (try_start_offset), T// (try_end_offset)
	 */
	byte isOffsetOrLabel(int i) {
		if (i==1750) {
		}
		char c = this.getItem(i);
		int j;
		
		int count = this.count;
		// i는 //에서 첫번째 /의 인덱스
		if (c=='/' && this.getItem(i+1)=='/') {
			if (i+3<count && (getItem(i+2)==' ' && getItem(i+3)=='(')) {
				for (j=i-1; j>=0; j--) {
					char c2 = this.getItem(j);
					if (c2==' ') continue;
					else if (c2=='\n') {
						return 2; //    gap // (Label)
					}
					else {
						// 1, 6, 7이 나올 수 있다.
						int k;
						for (k=i+3; k<count; k++) {
							char rightParent = this.getItem(k);
							if (rightParent==')') {
								break;
							}
						}
						//int mBufferOffset = getMBufferOffset(i+3, k);
						if (k==count) return 0; 
						
						if (c2=='T') {
							// 	// catch(finally) starts T// (try_start_offset), T// (try_end_offset)
							return 8;
						}
						
						// opcode gap // (offset)
						return 1;
						  
					}
				} // for (j=i-1; j>=0; j--) {
				if (j<0) return 2;  // 맨 처음 gap // (label)인 경우
			}// if (i+3<count && (getItem(i+2)==' ' && getItem(i+3)=='(')) {
			else {
				if (i+3>=count) return 0;
				
				return 0;
			}//else
		}// if (c=='/' && this.getItem(i+1)=='/') {
		return 0;
	}
	
	/** tableswitch, lookupswitch 에서만 호출한다.*/
	public void add(String code, int countOfPadding) {
		int i;
		String strInstruciton = code;
		
		
		// code에서 
		// goto_w 55 // (1828), exit of if (Control.CurrentSystem.equals(Control.CurrentSystemIsJava) &&
		// 이와 같이 주석을 포함할 경우 \n을 포함하여 끊어준다. 
		int codeLen = code.length();
		for (i=0; i<codeLen; i++) {
			if (code.charAt(i)=='\n') {
				code = code.substring(0, i+1);
				break;
			}
		}
		
		String instructionName = null;
		// bytecode index를 넣을 공간을 미리 준다. insert()가 일어나지 않도록 한다.
		//String gap = "           ";
		String gap = "      ";
		if (code.charAt(0)!='/') {	
			// 주석이 아닌 코드
			for (i=0; i<code.length(); i++) {
				char ch = code.charAt(i);
				if (ch==' ' || ch=='\n') break;
			}
			instructionName = code.substring(0, i);
			String remainder = code.substring(i, code.length());
			strInstruciton = /*Util.getLineOffset(indexOfByteCode)*/indexOfByteCode + " " + 
					instructionName + gap + remainder;
		}
		else {
			// 주석일 경우
			// getLineOffset()만큼 공백을 준다.
			strInstruciton = code;
		}
		
		if (instructionName!=null && instructionName.equals("istore")) {
		}
		                
		super.add(strInstruciton);
		
		// 다음 명령어의 indexOfByteCode를 센다.
		if (code.charAt(0)!='/') {
			ByteCodeInstruction instruction = 
				(ByteCodeInstruction) ByteCodeGeneratorForClass.hashTableInstructionSet.getData(instructionName, false);
			
					
			if (instruction!=null && instruction.hasVariableIndices() ) {
				if (instructionName.equals("tableswitch") || instructionName.equals("lookupswitch")) {
					// 명령어 1바이트 + 패딩 4바이트 + 디폴트 어드레스 4바이트
					this.indexOfByteCode += 1 + countOfPadding + 4;
				}
			}
		}
	}
	
	/**add(String code)와는 달리 str만 추가한다.*/
	public void addString(String str) {
		super.add(str);
	}
	
	
	
	
	/** code는 aload_0, iadd 등의 instrution 등이거나 혹은 
	 * // exit of control 등의 주석이 될 수 있다. 
	 * 이와 같은 명령문이나 주석에 gap을 부여하고 라인번호를 부여한다.*/
	public void add(String code) {
		int i;
		String strInstruciton = code;
		
		
		// code에서 
		// goto_w 55 // (1828), exit of if (Control.CurrentSystem.equals(Control.CurrentSystemIsJava) &&
		// 이와 같이 주석을 포함할 경우 \n을 포함하여 끊어준다. 
		int codeLen = code.length();
		for (i=0; i<codeLen; i++) {
			if (code.charAt(i)=='\n') {
				code = code.substring(0, i+1);
				break;
			}
		}
		
		String instructionName = null;
		// bytecode index를 넣을 공간을 미리 준다. insert()가 일어나지 않도록 한다.
		//String gap = "           ";
		String gap = "      ";
		if (code.charAt(0)!='/') {
			// 주석이 아닌 코드
			for (i=0; i<code.length(); i++) {
				char ch = code.charAt(i);
				if (ch==' ' || ch=='\n') break;
			}
			instructionName = code.substring(0, i);
			String remainder = code.substring(i, code.length());
			strInstruciton = /*Util.getLineOffset(indexOfByteCode)*/indexOfByteCode + " " + 
					instructionName + gap + remainder;
		}
		else {
			// 주석일 경우
			// getLineOffset()만큼 공백을 준다.
			//strInstruciton = gap + code;
			strInstruciton = code;
		}
		
		if (instructionName!=null && instructionName.equals("istore")) {
		}
		
		super.add(strInstruciton);
		
		// 다음 명령어의 indexOfByteCode를 센다.
		if (code.charAt(0)!='/') {
			if (instructionName.equals("")) {
			}
			ByteCodeInstruction instruction = 
				(ByteCodeInstruction) ByteCodeGeneratorForClass.hashTableInstructionSet.getData(instructionName, false);
			if (instruction==null) {
				if (instructionName.equals("low") || instructionName.equals("high") ||
					instructionName.equals("offset") || instructionName.equals("offsetEnd") || 
					instructionName.equals("count")) {
					// tableswitch의 마지막 오프셋의 LSB 바이트가 tableswitch의 다음 명령어(아래 예에서는 fload_0)를 대신하는 바이트코드가 된다.
					// tableswitch의 마지막 오프셋은 0이 아닌  LSB 바이트가 tableswitch의 다음 명령어(아래 예에서는 fload_0)가 되고 
					// 0인 바이트들은 추가되는 패딩바이트(아래 예에서는 원래 패딩바이트 1개에서 추가된 3바이트가 된다)가 된다.
					// fload_0의 다음 명령어는 4바이트 정렬이 되어 있어야 한다.
					// 206        tableswitch #0 #0 #0 #0 #34 #0 #4 #34 #34 #34 #34;  [] // (  Default Offset : 34 Low : 0 High : 4 Offset :(0, 34)  (1, 34)  (2, 34)  (3, 34)   )
					// 239        fload_0;  [] // ( [Ljava/lang/String; args )
					// 240        return;  [] //
					
					
					// 206        tableswitch 34 1      // (587), exit of switch (a)
					// 212        low            0
					// 216        high            4
					// 220        offset 34        // (527), case  0:
					// 224        offset 34        // (541), case  1:
					// 228        offset 34        // (587), exit of switch (a)
					// 232        offset 34        // (555), case  3:
					// 236        offsetEnd 34        // (573), case  4:
					           // offset addresses end 
					           // (527), case  0:
					           // (541), case  1:
					           // (555), case  3:
					           // (573), case  4:
					           // (587), exit of switch (a)
					// 240        return         
					
					
					/*
					0          bipush            3
					2          tableswitch 37         // (85), default :
					11         low            0
					15         high            2
					19         offset 38         // (98), case  0:
					23         offset 31         // (51), case  1:
					27         offset 36         // (66), case  2:
					           // offset addresses end 
					           // (51), case  1:
					31         goto_w -1         // (108), exit of switch (3)
					           // (66), case  2:
					36         return           
					           // (85), default :
					37         return           
					           // (98), case  0:
					38         goto_w -1         // (108), exit of switch (3)
					           // exit of switch (3)
					 */
					// switch의 case에서 분기할 주소를 출력할 때 low, high, 분기주소(offset)는 
					// instruction이 아니므로 null이 된다.
					//if (!instructionName.equals("offsetEnd")) {
						this.indexOfByteCode += 4;
					//}
				}
				else {
					if (instructionName.contains("offset_Lookup") || instructionName.contains("offsetEnd_Lookup")) {
						/*
						0          sipush            300
						3          ineg           
						4          iconst_1           
						5          iadd           
						6          lookupswitch 54         // (208), default :
						15         count            3
						19         offset_Lookup_-100 43         // (167), case  -100:
						27         offset_Lookup_0 48         // (178), case  0:
						35         offset_Lookup_300 53         // (193), case  300:
						           // offset addresses end 
						           // (167), case  -100:
						43         goto_w -1         // (221), exit of switch (-300)
						           // (178), case  0:
						48         goto_w -1         // (221), exit of switch (-300)
						           // (193), case  300:
						53         return           
						           // (208), default :
						54         return           
						           // exit of switch (-300)
						 */
						// lookupswitch 에서 key와 offset부분에서 key는 정수이고
						// instructionName은 null이 된다.
						this.indexOfByteCode += 8;
					}
					else if (instructionName.contains("aload") || instructionName.contains("astore") || 
							instructionName.contains("dload") || instructionName.contains("dstore") ||
							instructionName.contains("fload") || instructionName.contains("fstore") ||
							instructionName.contains("iload") || instructionName.contains("istore") || 
							instructionName.contains("lload") || instructionName.contains("lstore") ) {
						// instructionName이 iload_14 이렇게 될 수도 있으므로 이런 경우 instructionName은 null이 된다.
						// 그래서 iload로 분리를 해서 다시 해시테이블에서 instructionName을 찾는다.
						instructionName = instructionName.substring(0, instructionName.indexOf('_'));
						instruction = 
								(ByteCodeInstruction) ByteCodeGeneratorForClass.hashTableInstructionSet.getData(instructionName, false);
						try {
						this.indexOfByteCode += 1 + instruction.getLenOfIndices();
						}catch(Exception e) {
							if (Common_Settings.g_printsLog) e.printStackTrace();
						}
					}
				}
				
			}//if (instruction==null) {
			else {
				if (instruction.hasVariableIndices() ) {
					if (instructionName.equals("tableswitch") || instructionName.equals("lookupswitch")) {
						// 명령어 1바이트 + 패딩 4바이트 + 디폴트 어드레스 4바이트
						this.indexOfByteCode += 1 + 4 + 4;
					}
					else {
						
					}
				}
				else {
					this.indexOfByteCode += 1 + instruction.getLenOfIndices();
				}
				//this.indexOfByteCode += 1 + instruction.getLenOfIndices();
			}
		}//if (code.charAt(0)!='/') {
		
	}
	
	public String toString() {
		return this.getItems();
	}

	public void reset2() {
		
		super.reset2();
		this.count = 0;
		this.indexOfByteCode = 0;
		this.listOfVarUseForThreeOperandsOperationWith1StackItem.reset();
		
	}
	
}