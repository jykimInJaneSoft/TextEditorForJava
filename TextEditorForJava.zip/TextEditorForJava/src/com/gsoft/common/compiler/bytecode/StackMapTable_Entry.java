package com.gsoft.common.compiler.bytecode;

import java.io.InputStream;
import java.io.OutputStream;

import com.gsoft.common.Common_Settings;
import com.gsoft.common.IO;
import com.gsoft.common.interfaces.IReset;
import com.gsoft.common.compiler.Compiler_types.FindVarUseParams;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.Verification_Type_info;
import com.gsoft.common.compiler.bytecode.ThrowStack.ThrowStartEnd;
import com.gsoft.common.util.ArrayList;

import com.gsoft.common.compiler.bytecode.StackMapTable_attribute;
import com.gsoft.common.compiler.bytecode.OffsetAndForLoopAndParent;


public class StackMapTable_Entry implements IReset {
	StackMapTable_attribute stackMapTable_attribute;
	
	/** [0-63]이면 same_frame, [64, 127]이면 same_locals_1_stack_item_frame,
	 * [128-246]이면 보류, 247이면 same_locals_1_stack_item_frame_extended,
	 *   [248-250]이면 chop_frame,  251이면 same_frame_extended, 
	 *  [252-254]이면 append, 255이면 full_frame 이다.
	 */
	short frame_type;
	
	short getFrame_type() {
		return this.frame_type;
	}
	void setFrame_type(int frame_type) {
		
		this.frame_type = (short) frame_type;
	}
	
	/** same_locals_1_stack_item_frame, same_locals_1_stack_item_frame_extended 이면 
	 * null 이 아님, 원소개수는 1개이다.*/
	Verification_Type_info[] stack; 
	/** same_locals_1_stack_item_frame_extended, chop_frame, same_frame_extended,
	 * append_frame 이면 
	 * 0이 아님*/
	int offset_delta;
	
	/** append_frame 이면 null 이 아님,
	 * verification_type_info locals[frame_type -251]*/
	Verification_Type_info[] locals;
	/**full_frame 이면 0 이 아님*/
	int number_of_locals;
	/**full_frame 이면 null 이 아님, 
	 * verification_type_info locals[number_of_locals];*/
	//Verification_Type_info[] locals_FullFrame;
	/**full_frame 이면 0 이 아님*/
	int number_of_stack_items;
	/**full_frame 이면 null 이 아님, 
	 * verification_type_info stack[number_of_stack_items]*/
	//Verification_Type_info[] stack_FullFrame;
	
	/** Stack Map Frame의 시작 pc*/
	int start_frame_pc;
	/** Stack Map Frame의 영역 [start_frame_pc, start_frame_pc+offset_delta)에 들어가는 지역변수 리스트*/
	ArrayList listOfLocalVars = new ArrayList(3);
	
	/** full프레임의 경우 parent블록에 있는 full프레임에서 선언된 지역변수들을 상속해야 한다.*/
	ArrayList listOfLocalVarsInheritted = new ArrayList(3);
	
	/** catch블록이면 1을 finally블록이면 2, try블록이면 3, 해당사항 없으면 0*/
	//FindSpecialBlockParams isTryOrCatchOrFinally;
	int isTryOrCatchOrFinally;
	
	/** 현재 entry가 try블록의 엔트리이면 연결된 catch블록의 예외 엔트리(Exception_Entry) 리스트를 갖는다.*/
	ArrayList listOfCatchEntries;
	public int end_frame_pc;
	
	/** 스택맵 엔트리의 offsetAndForLoopOfChopFrame,
	 * 스택맵 엔트리가 chop 프레임일 경우 offsetAndForLoopOfChopFrame의 forLoop 멤버는 null이 아니다.*/
	OffsetAndForLoopAndParent offsetAndForLoopOfChopFrame;
	
	/** 복합할당연산자와 3항연산자를 함께 사용할 경우에 복합할당연산자의 varUseWith1StackItem를 담기위해 사용된다.*/
	ArrayList listOfVarsForThreeOperandsOperationWith1StackItem;
	
	/**복합할당연산자와 3항 연산자를 같이 사용할 경우 
	 * varUseWith1StackItem(varUseWith1StackItem가 지역변수일 경우에는 getOriginalVar()).indexOfLocalVarsInFunctionBeforeProcessLocalVars을 말한다.
	 * 3항 연산자만 사용하는 경우이면 -1이다.*/
	int indexOfVarUseInlistOfVarsForThreeOperandsOperationWith1StackItem=-1;

	/**복합할당연산자와 3항 연산자를 같이 사용할 경우 varUseWith1StackItem*/
	public FindVarUseParams varUseForThreeOperandsOperatorWith1StackItem;

	public boolean isForwardForThreeOperandsOperationWith1StackItem;
	

	//public boolean tryHasControlBlock;
	/**for루프안에 다른 제어구조가 있을 경우, otherBlock들의 condition과 exit of XXX의 프레임을 full 프레임으로 바꾼다.*/
	public boolean forHasOtherControlBlock;
	/**for루프안에 다른 제어구조가 있을 경우 condition of for 프레임을 chop프레임으로 바꾼다*/
	public boolean isChopFrame;
	/**try의 마지막 엔트리를 255로 바꾼다.*/
	public boolean isEntryLastInTry;

	public boolean isCaseAndDefaultFrame;
	
	public ThrowStartEnd throwStartEnd;

	int readBytesLen;

	public StackMapTable_Entry(
			StackMapTable_attribute stackMapTable_attribute) {
		
		this.stackMapTable_attribute = stackMapTable_attribute;
	}
	
	

	public StackMapTable_Entry() {
		
	}

	


	public int getAttributeLength() {
		if (0<=frame_type && frame_type<=63) {// SAME
			// 더이상 작업할 필요가 없다.
			//same_frame {
			//	u1 frame_type = SAME;/* 0-63 */
			//}
			return 1;
		}
		
		else if (frame_type==251) {//SAME_FRAME_EXTENDED
			//same_frame_extended {
			//	u1 frame_type = SAME_FRAME_EXTENDED;/* 251*/
			//	u2 offset_delta;
			//}
			return 3;
		}
		else if (64<=frame_type && frame_type<=127) {//SAME_LOCALS_1_STACK_ITEM
			//same_locals_1_stack_item_frame {
			//	u1 frame_type = SAME_LOCALS_1_STACK_ITEM;/* 64-127 */
			//	verification_type_info stack[1];
			//}
			try {
				
				return 1 + stack[0].getAttributeLength();
			}catch(Exception e) {
				if (Common_Settings.g_printsLog) e.printStackTrace();
				return -1;
			}
		}
		else if (248<=frame_type && frame_type<=250) {//chop
			//chop_frame {
			//	u1 frame_type=CHOP; /* 248-250 */
			//	u2 offset_delta;
			//}
			//  the k last locals are absent. The value of k is given by the formula 251-frame_type.
			return 3;
		}
		else if (252<=frame_type && frame_type<=254) {//APPEND
			//append_frame {
			//	u1 frame_type = APPEND; /* 252-254 */
			//	u2 offset_delta;
			//	verification_type_info locals[frame_type -251];
			//}
			int r = 1+2;
			int i;
			for (i=0; i<this.number_of_locals; i++) {
				r += this.locals[i].getAttributeLength();
			}
			return r;
		}
		else if (frame_type==255) {//FULL_FRAME
			//full_frame {
			//	u1 frame_type = FULL_FRAME; /* 255 */
			//	u2 offset_delta;
			//	u2 number_of_locals;
			//	verification_type_info locals[number_of_locals];
			//	u2 number_of_stack_items;
			//	verification_type_info stack[number_of_stack_items];
			//}
			int r = 1+2+2;
			int i;
			for (i=0; i<this.number_of_locals; i++) {
				try {
				r += this.locals[i].getAttributeLength();
				}catch(Exception e) {
					if (Common_Settings.g_printsLog) e.printStackTrace();
				}
			}
			r += 2;
			for (i=0; i<this.number_of_stack_items; i++) {
				try {
				r += this.stack[i].getAttributeLength();
				}catch(Exception e) {
					if (Common_Settings.g_printsLog) e.printStackTrace();
				}
			}
			return r;
		}
		return 0;
	}
	
	@Override
	public void destroy() {
		
		
	}
	
	int getOffsetUntilHere() {
		int i;
		int r = 0;
		if (this.stackMapTable_attribute==null || 
				this.stackMapTable_attribute.stackMapTable==null) return 0;
		
		StackMapTable_Entry[] entries = this.stackMapTable_attribute.stackMapTable;
		for (i=0; i<entries.length; i++) {
			if (i==0) {
				r += entries[i].offset_delta;
			}
			else {
				r += entries[i].offset_delta + 1;
			}
			if (entries[i]==this) return r;
		}
		return r;
	}
	
	public String toString() {
		String result = "";
		String strOffset = "";
		int r = getOffsetUntilHere();
		if (r!=0) strOffset = "("+getOffsetUntilHere()+")";
		if (0<=frame_type && frame_type<=63) {// SAME
			// 더이상 작업할 필요가 없다.
			//same_frame {
			//	u1 frame_type = SAME;/* 0-63 */
			//}
			result = "same_frame"+"("+frame_type+") "+" implicit offset_delta="+frame_type+" "+strOffset;
		}
		else if (64<=frame_type && frame_type<=127) {//SAME_LOCALS_1_STACK_ITEM
			//same_locals_1_stack_item_frame {
			//	u1 frame_type = SAME_LOCALS_1_STACK_ITEM;/* 64-127 */
			//	verification_type_info stack[1];
			//}
			String message = " verification_type_info stack=";
			for (int i=0; i<stack.length; i++) {
				message += stack[i].toString()+" ";
			}
			int offset_delta = this.frame_type-64;
			result =  "same_locals_1_stack_item_frame"+"("+frame_type+")"+" offset_delta="+offset_delta+strOffset+message;
		}
		else if (128<=frame_type && frame_type<=246) {//reserved
			
		}
		else if (frame_type==247) {//SAME_LOCALS_1_STACK_ITEM_EXTENDED
			//same_locals_1_stack_item_frame_extended {
			//	u1 frame_type = SAME_LOCALS_1_STACK_ITEM_EXTENDED;/* 247 */
			//	u2 offset_delta;
			//	verification_type_info stack[1];
			//}
			String message = " verification_type_info stack=";
			for (int i=0; i<stack.length; i++) {
				message += stack[i].toString()+" ";
			}
			result =  "same_locals_1_stack_item_frame_extended"+"("+frame_type+")"+" offset_delta="+offset_delta+strOffset+message;
		}
		else if (248<=frame_type && frame_type<=250) {//CHOP
			//chop_frame {
			//	u1 frame_type=CHOP; /* 248-250 */
			//	u2 offset_delta;
			//}
			result =  "chop_frame"+"("+frame_type+")"+" offset_delta="+offset_delta+" "+strOffset;
		}
		else if (frame_type==251) {//SAME_FRAME_EXTENDED
			//same_frame_extended {
			//	u1 frame_type = SAME_FRAME_EXTENDED;/* 251*/
			//	u2 offset_delta;
			//}
			result =  "same_frame_extended"+"("+frame_type+")"+" offset_delta="+offset_delta+" "+strOffset;
		}
		else if (252<=frame_type && frame_type<=254) {//APPEND
			//append_frame {
			//	u1 frame_type = APPEND; /* 252-254 */
			//	u2 offset_delta;
			//	verification_type_info locals[frame_type -251];
			//}
			String message = " verification_type_info locals=";
			if (this.listOfLocalVars==null || this.listOfLocalVars.count==0) { // 바이트코드를 읽을때
				for (int i=0; i<locals.length; i++) {					
					message += locals[i].toString()+" ";
				}
			}
			else { // 바이트코드를 쓸때
				for (int i=0; i<locals.length; i++) {					
					message += this.listOfLocalVars.getItem(i) + "-" + locals[i].toString()+";";
				}
			}
			result =  "append_frame"+"("+frame_type+")"+" offset_delta="+offset_delta+" "+strOffset+message;
		}
		else if (frame_type==255) {//FULL_FRAME
			//full_frame {
			//	u1 frame_type = FULL_FRAME; /* 255 */
			//	u2 offset_delta;
			//	u2 number_of_locals;
			//	verification_type_info locals[number_of_locals];
			//	u2 number_of_stack_items;
			//	verification_type_info stack[number_of_stack_items];
			//}
		
			int i;
			String message = " number_of_locals="+number_of_locals+ " verification_type_info locals=";
			if (this.listOfLocalVars==null || this.listOfLocalVars.count==0) { // 바이트코드를 읽을때
				for (i=0; i<locals.length; i++) {					
					message += locals[i].toString()+" ";
				}
			}
			else { // 바이트코드를 쓸때
				for (i=0; i<locals.length; i++) {					
					message += this.listOfLocalVars.getItem(i) + "-" + locals[i].toString()+";";
				}
			}
			
			message += " number_of_stack_items="+number_of_stack_items+ " verification_type_info stacks=";
			if (stack!=null) {
				for (i=0; i<stack.length; i++) {
					message += stack[i].toString()+" ";
				}
			}
			result =  "full_frame"+"("+frame_type+")"+" offset_delta="+offset_delta+strOffset+message;
		}
		if (this.offsetAndForLoopOfChopFrame!=null && this.offsetAndForLoopOfChopFrame.parent!=null) {
			return result+" "+this.offsetAndForLoopOfChopFrame.parent;
		}
		return result;
	}

	public static StackMapTable_Entry read(InputStream is,
			ArrayList constantTable, boolean isLittleEndian, StackMapTable_attribute stackMapTable_attribute) {
		
		StackMapTable_Entry entry = new StackMapTable_Entry(stackMapTable_attribute);
		byte tag = IO.readByte(is);
		entry.readBytesLen += 1;
		
		byte[] arr = {tag, 0};
		entry.frame_type = IO.toShort(arr, true);
		
	
		if (0<=entry.frame_type && entry.frame_type<=63) {// SAME
			// 더이상 작업할 필요가 없다.
			//same_frame {
			//	u1 frame_type = SAME;/* 0-63 */
			//}
			entry.offset_delta = entry.frame_type;
		}
		else if (64<=entry.frame_type && entry.frame_type<=127) {//SAME_LOCALS_1_STACK_ITEM
			//same_locals_1_stack_item_frame {
			//	u1 frame_type = SAME_LOCALS_1_STACK_ITEM;/* 64-127 */
			//	verification_type_info stack[1];
			//}
			entry.offset_delta = entry.frame_type-64;
			entry.stack = new Verification_Type_info[1];
			entry.stack[0] = Verification_Type_info.read(is, constantTable, isLittleEndian);
			entry.readBytesLen += entry.stack[0].readBytesLen;
		}
		else if (128<=entry.frame_type && entry.frame_type<=246) {//reserved
			
		}
		else if (entry.frame_type==247) {//SAME_LOCALS_1_STACK_ITEM_EXTENDED
			//same_locals_1_stack_item_frame_extended {
			//	u1 frame_type = SAME_LOCALS_1_STACK_ITEM_EXTENDED;/* 247 */
			//	u2 offset_delta;
			//	verification_type_info stack[1];
			//}
			entry.offset_delta = IO.readUnsignedShort(is, isLittleEndian);
			entry.readBytesLen += 2;
			entry.stack = new Verification_Type_info[1];
			entry.stack[0] = Verification_Type_info.read(is, constantTable, isLittleEndian);
			entry.readBytesLen += entry.stack[0].readBytesLen;
		}
		else if (248<=entry.frame_type && entry.frame_type<=250) {//CHOP
			//chop_frame {
			//	u1 frame_type=CHOP; /* 248-250 */
			//	u2 offset_delta;
			//}
		    //  the k last locals are absent. The value of k is given by the formula 251-frame_type.
			entry.offset_delta = IO.readUnsignedShort(is, isLittleEndian);
			entry.readBytesLen += 2;
		}
		else if (entry.frame_type==251) {//SAME_FRAME_EXTENDED
			//same_frame_extended {
			//	u1 frame_type = SAME_FRAME_EXTENDED;/* 251*/
			//	u2 offset_delta;
			//}
			entry.offset_delta = IO.readUnsignedShort(is, isLittleEndian);
			entry.readBytesLen += 2;
		}
		else if (252<=entry.frame_type && entry.frame_type<=254) {//APPEND
			//append_frame {
			//	u1 frame_type = APPEND; /* 252-254 */
			//	u2 offset_delta;
			//	verification_type_info locals[frame_type -251];
			//}
			entry.offset_delta = IO.readUnsignedShort(is, isLittleEndian);
			entry.readBytesLen += 2;
			entry.locals = new Verification_Type_info[entry.frame_type-251];
			int i;
			for (i=0; i<entry.locals.length; i++) {
				entry.locals[i] = Verification_Type_info.read(is, constantTable, isLittleEndian);
				entry.readBytesLen += entry.locals[i].readBytesLen;
			}
		}
		else if (entry.frame_type==255) {//FULL_FRAME
			//full_frame {
			//	u1 frame_type = FULL_FRAME; /* 255 */
			//	u2 offset_delta;
			//	u2 number_of_locals;
			//	verification_type_info locals[number_of_locals];
			//	u2 number_of_stack_items;
			//	verification_type_info stack[number_of_stack_items];
			//}
			entry.offset_delta = IO.readUnsignedShort(is, isLittleEndian);
			entry.readBytesLen += 2;
			
			entry.number_of_locals = IO.readUnsignedShort(is, isLittleEndian);
			entry.readBytesLen += 2;
			
			entry.locals = new Verification_Type_info[entry.number_of_locals];
			int i;
			for (i=0; i<entry.locals.length; i++) {
				entry.locals[i] = Verification_Type_info.read(is, constantTable, isLittleEndian);
				entry.readBytesLen += entry.locals[i].readBytesLen;
			}
			
			entry.number_of_stack_items = IO.readUnsignedShort(is, isLittleEndian);
			entry.readBytesLen += 2;
			
			entry.stack = new Verification_Type_info[entry.number_of_stack_items];
			//int i;
			for (i=0; i<entry.stack.length; i++) {
				entry.stack[i] = Verification_Type_info.read(is, constantTable, isLittleEndian);
				entry.readBytesLen += entry.stack[i].readBytesLen;
			}
		}
		return entry;
	}
	
	void write(OutputStream os, boolean isLittleEndian) {
		IO.writeByte(os, (byte)frame_type);
		if (0<=frame_type && frame_type<=63) {// SAME
			// 더이상 작업할 필요가 없다.
			//same_frame {
			//	u1 frame_type = SAME;/* 0-63 */
			//}
		}
		else if (frame_type==251) {//SAME_FRAME_EXTENDED
			//same_frame_extended {
			//	u1 frame_type = SAME_FRAME_EXTENDED;/* 251*/
			//	u2 offset_delta;
			//}
			IO.writeShort(os, (short)offset_delta, isLittleEndian);
		}
		else if (64<=frame_type && frame_type<=127) {//SAME_LOCALS_1_STACK_ITEM
			//same_locals_1_stack_item_frame {
			//	u1 frame_type = SAME_LOCALS_1_STACK_ITEM;/* 64-127 */
			//	verification_type_info stack[1];
			//}
			stack[0].write(os, isLittleEndian);
		}
		else if (248<=frame_type && frame_type<=250) {//chop
			//chop_frame {
			//	u1 frame_type=CHOP; /* 248-250 */
			//	u2 offset_delta;
			//}
			//  the k last locals are absent. The value of k is given by the formula 251-frame_type.
			IO.writeShort(os, (short)offset_delta, isLittleEndian);
		}
		else if (252<=frame_type && frame_type<=254) {//APPEND
			//append_frame {
			//	u1 frame_type = APPEND; /* 252-254 */
			//	u2 offset_delta;
			//	verification_type_info locals[frame_type -251];
			//}
			IO.writeShort(os, (short)offset_delta, isLittleEndian);
			int i;
			for (i=0; i<locals.length; i++) {
				locals[i].write(os, isLittleEndian);
			}
		}
		else if (frame_type==255) {//FULL_FRAME
			//full_frame {
			//	u1 frame_type = FULL_FRAME; /* 255 */
			//	u2 offset_delta;
			//	u2 number_of_locals;
			//	verification_type_info locals[number_of_locals];
			//	u2 number_of_stack_items;
			//	verification_type_info stack[number_of_stack_items];
			//}
			IO.writeShort(os, (short)offset_delta, isLittleEndian);
			
			int i;
			IO.writeShort(os, (short)number_of_locals, isLittleEndian);
			for (i=0; i<locals.length; i++) {
				locals[i].write(os, isLittleEndian);
			}
		
			IO.writeShort(os, (short)number_of_stack_items, isLittleEndian);
			for (i=0; i<number_of_stack_items; i++) {
				stack[i].write(os, isLittleEndian);
			}
			
		}
	}
	
}