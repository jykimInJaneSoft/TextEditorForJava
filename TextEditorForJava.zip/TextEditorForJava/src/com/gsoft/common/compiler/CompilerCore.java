package com.gsoft.common.compiler;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.CommonGUI;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.compiler.CompilerStack.ReturnOfFindAccessModifier;
import com.gsoft.common.compiler.Compiler_types.CategoryOfBlock;
import com.gsoft.common.compiler.Compiler_types.CategoryOfControls;
import com.gsoft.common.compiler.Compiler_types.FindAssignStatementParams;
import com.gsoft.common.compiler.Compiler_types.FindBlockParams;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.Compiler_types.FindControlBlockParams;
import com.gsoft.common.compiler.Compiler_types.FindFunctionParams;
import com.gsoft.common.compiler.Compiler_types.FindIndependentFuncCallParams;
import com.gsoft.common.compiler.Compiler_types.FindVarParams;
import com.gsoft.common.compiler.Compiler_types.FindVarUseParams;
import com.gsoft.common.compiler.Compiler_types.ModeAllOrUpdate;
import com.gsoft.common.compiler.Compiler_types_Base.AccessModifier;
import com.gsoft.common.compiler.Compiler_types_Base.AccessModifier.AccessPermission;
import com.gsoft.common.compiler.Compiler_types_Base.Block;
import com.gsoft.common.compiler.Compiler_types_Base.DocuComment;
import com.gsoft.common.compiler.Compiler_types_Base.Error;
import com.gsoft.common.compiler.Compiler_types_Base.FindStatementParams;
import com.gsoft.common.compiler.Compiler_types_Base.OldTypeIndex;
import com.gsoft.common.compiler.Compiler_types_Base.ReturnOfFindVarDecl;
import com.gsoft.common.compiler.Compiler_types_Special.Constructor;
import com.gsoft.common.compiler.Compiler_types_Special.FindArrayInitializerParams;
import com.gsoft.common.compiler.Compiler_types_Special.FindIncrementStatementParams;
import com.gsoft.common.compiler.Compiler_types_Special.FindSpecialBlockParams;
import com.gsoft.common.compiler.Compiler_types_Special.FindSpecialStatementParams;
import com.gsoft.common.compiler.Compiler_types_Special.FindThreeOperandsOperation;
import com.gsoft.common.compiler.TemplateBase.Template;
import com.gsoft.common.compiler.classloader.Loader;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListIReset;
import com.gsoft.common.util.ArrayListString;
import com.gsoft.common.util.HighArray_CodeChar;
import com.gsoft.common.util.Stack;

import com.gsoft.common.compiler.CompilerStatic;
import com.gsoft.common.compiler.HighArray_CodeString;
import com.gsoft.common.compiler.CompilerStack;
import com.gsoft.common.compiler.CompilerData;
import com.gsoft.common.compiler.IndexForHighArray;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.Checker;
import com.gsoft.common.compiler.TemplateBase;
import com.gsoft.common.compiler.Fullname;
import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.Array;

public class CompilerCore {
	CompilerStack compilerStack;
	CompilerData data;
	Compiler compiler;
	
	//public static ArrayListIReset errors = CompilerStatic.errors;


	CompilerCore(CompilerStack compilerStack) {
		this.compilerStack = compilerStack;
		this.compiler = compilerStack.compiler;
		data = compilerStack.data;
	}
	
	/**모든 '\n'의 mBuffer에서의 인덱스를 CompilerStack.listOfNewLines에 저장한다.
	 * @param endIndex : 포함
	 * @param startIndex : 포함*/
	public void findNewLines(int startIndex, int endIndex) {
		int i;
		int len = endIndex+1;
		for (i=startIndex; i<len; i++) {
			if (data.mBuffer.getItem(i).equals("\n")) {
				data.mlistOfNewLines.add(i);
			}
		}
	}
	
	
	public boolean checkConditions_backup() {
		HighArray_CodeString src = data.mBuffer;
		int i, j;
		
		for (i=0; i<src.count; i++) {
			CodeString str = src.getItem(i);
			if (CompilerHelper.IsComment(str)) {
				continue;
			}
			if (CompilerHelper.IsBlank(str)) {
				continue;
			}
			if (str.equals("if") || str.equals("while") || str.equals("for")) {
				int leftPairIndex = CompilerHelper.SkipBlank(data.mBuffer, false, i+1, src.count-1);
				int rightPairIndex = Checker.CheckParenthesis(compiler, "(", ")", leftPairIndex, src.count-1, false);
				for (j=leftPairIndex+1; j<rightPairIndex; j++) {					
					CodeString str2 = src.getItem(j);
					if (CompilerHelper.IsComment(str2)) continue;
					if (CompilerHelper.IsBlank(str2)) continue;
					if (str2.equals("=") || str2.equals("!")) {
						int nextIndexEqual = CompilerHelper.SkipBlank(src, false, j+1, src.count-1);
						if (src.getItem(nextIndexEqual).equals("=")) {
							int trueFalseIndex = CompilerHelper.SkipBlank(src, false, nextIndexEqual+1, src.count-1);
							String trueOrFalse = src.getItem(trueFalseIndex).str;
							// if ( (a>2)==!(!(false)) ) 이런 경우는 에러로 처리한다.
							if (trueOrFalse.equals("false") || trueOrFalse.equals("true")) {
								CompilerStatic.errors.add(new Error(compiler, j, trueFalseIndex, "invalid condition : use !"));								
							}
						}
					}
				}
			}
			//if (haveToModify) break;
		}// for (i=0; i<src.count; i++) {
		
		return true;
	}
	
	public boolean checkConditions() {
		HighArray_CodeString src = data.mBuffer;
		int i;
		
		for (i=0; i<src.count; i++) {
			CodeString str = src.getItem(i);
			if (CompilerHelper.IsComment(str)) {
				continue;
			}
			if (CompilerHelper.IsBlank(str)) {
				continue;
			}
			if (str.equals("false") || str.equals("true")) {
				int nextIndexTrueOrFalse = i;
				CodeString nextTrueOrFalse = null;
				do {
					nextIndexTrueOrFalse = CompilerHelper.SkipBlank(src, false, nextIndexTrueOrFalse+1, src.count-1);
					nextTrueOrFalse = src.getItem(nextIndexTrueOrFalse);
					if (!nextTrueOrFalse.equals(")")) break;
				}while(true);
				if (nextTrueOrFalse.equals("=") || nextTrueOrFalse.equals("!")) {
					int nextIndexEqual = CompilerHelper.SkipBlank(src, false, nextIndexTrueOrFalse+1, src.count-1);
					String nextEqual = src.getItem(nextIndexEqual).str;
					// if ( !(!(false))==(a>2) ) 이런 경우는 에러로 처리한다.
					if (nextEqual.equals("=")) {
						CompilerStatic.errors.add(new Error(compiler, i, nextIndexEqual, "invalid condition : use !"));								
					}
				}
				int prevIndexTrueOrFalse = i;
				CodeString prevTrueOrFalse = null;
				do {
					prevIndexTrueOrFalse = CompilerHelper.SkipBlank(src, true, 0, prevIndexTrueOrFalse-1);
					prevTrueOrFalse = src.getItem(prevIndexTrueOrFalse);
					if ( !(prevTrueOrFalse.equals("(") || prevTrueOrFalse.equals("!")) ) break;
				}while(true);
				if (prevTrueOrFalse.equals("=")) {
					int prevIndexEqual = CompilerHelper.SkipBlank(src, true, 0, prevIndexTrueOrFalse-1);
					String prevEqual = src.getItem(prevIndexEqual).str;
					// if ( (a>2)==!(!(false)) ) 이런 경우는 에러로 처리한다.
					if (prevEqual.equals("=") || prevEqual.equals("!")) {
						CompilerStatic.errors.add(new Error(compiler, prevIndexEqual, i, "invalid condition : use !"));								
					}
				}
			}			
		}// for (i=0; i<src.count; i++) {
		
		return true;
	}
	
	
	public void changeSourceAndInputWithConditions() {
		HighArray_CodeString src = data.mBuffer;
		HighArray_CodeString newSrc = new HighArray_CodeString(src.arrayLimit); 
		int i, j;
		boolean checked = checkConditions();
		
		if (checked) return;
		
		for (i=0; i<src.count; i++) {
			CodeString str = src.getItem(i);
			if (CompilerHelper.IsComment(str)) {
				newSrc.add(str);
				continue;
			}
			if (CompilerHelper.IsBlank(str)) {
				newSrc.add(str);
				continue;
			}
			if (str.equals("if") || str.equals("while") || str.equals("for")) {
				boolean found = false;
				int leftPairIndex = CompilerHelper.SkipBlank(data.mBuffer, false, i+1, src.count-1);
				int rightPairIndex = Checker.CheckParenthesis(compiler, "(", ")", leftPairIndex, src.count-1, false);
				int pos = -1;
				for (j=leftPairIndex+1; j<rightPairIndex; j++) {					
					CodeString str2 = src.getItem(j);
					if (CompilerHelper.IsComment(str2)) continue;
					if (CompilerHelper.IsBlank(str2)) continue;
					if (str2.equals("=") || str2.equals("!")) {
						int nextIndexEqual = CompilerHelper.SkipBlank(src, false, j+1, src.count-1);
						if (src.getItem(nextIndexEqual).equals("=")) {
							int trueFalseIndex = CompilerHelper.SkipBlank(src, false, nextIndexEqual+1, src.count-1);
							String trueOrFalse = src.getItem(trueFalseIndex).str;
							// if ( (a>2)==!(!(false)) ) 이런 경우는 에러로 처리한다.
							if (trueOrFalse.equals("false") || trueOrFalse.equals("true")) {
								boolean putsNot = true;
								if (str2.equals("=") && trueOrFalse.equals("true")) {
									// if (a==true)는 !을 넣지 않는다.
									putsNot = false;
								}
								if (str2.equals("!") && trueOrFalse.equals("false")) {
									// if (a!=false)는 !을 넣지 않는다.
									putsNot = false;
								}
								found = true;
								// false의 이전 인덱스
								int prevIndexOfj = CompilerHelper.SkipBlank(src, true, 0, j-1);
								if (src.getItem(prevIndexOfj).equals(")")) {
									// if ( (a>2)==false )
									// for (a=0; (a<2)==false; a++)
									int leftPair = Checker.CheckParenthesis(compiler, "(", ")", 0, prevIndexOfj, true);
									// if (A.f()==false)
									int idIndex = CompilerHelper.SkipBlank(src, true, 0, leftPair-1);
									int fullNameIndex = -1;
									if (CompilerHelper.IsIdentifier(src.getItem(idIndex), compiler)) {
										fullNameIndex = Fullname.getFullNameIndex(compiler, true, leftPair-1, false);
									}
									else {
										fullNameIndex = leftPair;
									}
									if (fullNameIndex!=-1) {
										int k;
										if (pos==-1) {
											for (k=i; k<fullNameIndex; k++) {
												newSrc.add(src.getItem(k));
											}
										}
										else {
											for (k=pos; k<fullNameIndex; k++) {
												newSrc.add(src.getItem(k));
											}
										}
										if (putsNot) {
											// not을 넣는다.
											CodeString not = new CodeString("!", Common_Settings.textColor);
											newSrc.add(not);
										}
										for (k=fullNameIndex; k<=prevIndexOfj; k++) {
											newSrc.add(src.getItem(k));
										}
										pos = trueFalseIndex+1;
										j = trueFalseIndex;
										i = rightPairIndex-1;
										continue;
									}
								}// if (src.getItem(prevIndexOfj).equals(")")) {
								else {
									// if ( a==false )
									int k;
									int fullNameIndex = Fullname.getFullNameIndex(compiler, true, prevIndexOfj, false);
									if (pos==-1) {
										for (k=i; k<fullNameIndex; k++) {
											newSrc.add(src.getItem(k));
										}
									}
									else {
										for (k=pos; k<fullNameIndex; k++) {
											newSrc.add(src.getItem(k));
										}
									}
									if (putsNot) {
										// not을 넣는다.
										CodeString not = new CodeString("!", Common_Settings.textColor);
										newSrc.add(not);
									}
									//newSrc.add(src.getItem(fullNameIndex));
									for (k=fullNameIndex; k<=prevIndexOfj; k++) {
										newSrc.add(src.getItem(k));
									}
									pos = trueFalseIndex+1;
									j = trueFalseIndex;
									i = rightPairIndex-1;
									continue;
								}
							}// if (trueOrFalse.equals("false") || trueOrFalse.equals("true")) {
							else {
								//CompilerStatic.errors.add(new Error(compiler, trueFalseIndex, trueFalseIndex, "invalid condition : invalid false or true"));
							}
						}// if (src.getItem(nextIndexEqual).equals("=")) {
					}// if (str2.equals("=")) {
				}// for (j=leftPairIndex+1; j<rightPairIndex; j++) {
				if (!found) {
					newSrc.add(str);
				}
			}// if (str.equals("if") || str.equals("while") || str.equals("for")) {
			else {
				newSrc.add(str);
			}
		}// for (i=0; i<src.count; i++) {
		data.mBuffer = newSrc;
		
		changeInputWithConditions();
	}
	
	void changeInputWithConditions() {
		HighArray_CodeString mBuffer = data.mBuffer;
		HighArray_CodeChar newInput = new HighArray_CodeChar(compiler.data.strInput.arrayLimit); 
		int i;
		for (i=0; i<mBuffer.count; i++) {
			CodeString str = mBuffer.getItem(i);
			newInput.add(str);
		}
		data.strInput = newInput;
	}
	
	/** 클래스, 함수, 제어구조 등의 블록구조를 스택을 써서 확인한다.
	 * start2()와 start_onlyInterface()에서 호출된다.
	 * @param compiler : CompilerHelper의 loadClassFromSrc_onlyInterface()에서 
	 * compiler.start_onlyInterface(...) 이렇게 호출이 되고  start_onlyInterface()에서
	 * FindAllClassesAndItsMembers2_sub(...)호출을 하면
	 * FindAllClassesAndItsMembers2_sub()내부의 this나 this가 없는 
	 * Compiler클래스의 멤버 사용은 compiler(호출오브젝트)의 멤버사용이므로 없어도 되는 것이다.
	 * start2()에서 호출이 되어도 마찬가지이다.
	 * @param result : 최상위 클래스 리스트
	 * @param coreThreadID 
	 * @param showsLogMessage 
	 * @param resultForListOfAllClasses : 모든 클래스 리스트
	 */
	public void FindAllClassesAndItsMembers2_sub(int startIndex, int endIndex, 
			ArrayListIReset result,  ModeAllOrUpdate modeAllOrUpdateParam,
			boolean allOrPart, FindFunctionParams functionForPart, int coreThreadID, boolean showsLogMessage) {
		// Only All available
		//ModeAllOrUpdate modeAllOrUpdate = ModeAllOrUpdate.All;
		
		HighArray_CodeString src = data.mBuffer;
		int i;
		Stack stack = new Stack();
		Block top = null;
		OldTypeIndex oldTypeIndex = null;
		
				
		// 문장 찾고 넣기에서 대입문
		int startIndexOfAssign=-1, endIndexOfAssign=-1;	
		int startIndexOfIndependentFuncCall=-1, endIndexOfIndependentFuncCall=-1;
		int startIndexOfReturn=-1, endIndexOfReturn=-1;
		int startIndexOfIndependentInc = -1, endIndexOfIndependentInc = -1;
		boolean isAssignOrIndependentFuncCall = false;
		
		String fullnameOfFile = CompilerStatic.getFullname_FromVariousClassPath(2, compiler.data.filename);
		
		for (i=startIndex; i<=endIndex; ) {
			try{				
				if (showsLogMessage) {
					if (i % 1000==0) {
						CommonGUI.showMessage(true, "i="+i+" "+fullnameOfFile);
					}
				}			
				
			CodeString str = src.getItem(i);
			Block currentBlock = (Block) stack.Get();
			
			
			if (CompilerHelper.IsBlank(str) || CompilerHelper.IsComment(str))  {
				i++;
				continue;
			}
			// 배열 초기화문  char[] a = {'a', 'b'};
			else if (str.equals("=")) {
				
				int prevIndex = CompilerHelper.SkipBlank(src, true, 0, i-1);
				if (prevIndex==-1) {
					i++;
					continue;
				}
				prevIndex = Fullname.getFullNameIndex(compiler, true, prevIndex, true);
				int nameIndex;
				CodeString varUseName = src.getItem(prevIndex);
				if (!CompilerHelper.IsIdentifier(varUseName, compiler)) {
					i++;
					continue;
				}
				nameIndex = prevIndex;
				prevIndex = CompilerHelper.SkipBlank(src, true, 0, prevIndex-1);
				if (prevIndex==-1) {
					i++;
					continue;
				}
				int nextIndex = CompilerHelper.SkipBlank(src, false, i+1, src.count-1);
				if (nextIndex==src.count) {
					i++;
					continue;
				}
				CodeString leftPair = src.getItem(nextIndex);
				if (leftPair.equals("{")) {
					int indexRightPair = Checker.CheckParenthesis(compiler, "{", "}", nextIndex, src.count-1, false);
					if (indexRightPair!=-1) {
						int indexOfSemicolon = CompilerHelper.Skip(src, false, ";", nextIndex, src.count-1);
						if (indexOfSemicolon<indexRightPair) {
							CompilerStatic.errors.add(new Error(compiler, nextIndex, indexOfSemicolon, "'}' not exists"));
							compiler.PairErrorExists = true;
							i = indexOfSemicolon+1;
							continue;
						}
						FindArrayInitializerParams arr = new FindArrayInitializerParams(compiler, nameIndex, nextIndex, indexRightPair);
						FindBlockParams blockParams = new FindBlockParams(compiler, nextIndex, indexRightPair);
						arr.findBlockParams = blockParams;
						//mlistOfAllArrayIntializers.add(arr)// 맨처음 배열 초기화문을 등록한다.
						this.putArrayIntializer(arr);// 맨처음 배열 초기화문을 등록한다.
						Block parentBlock = (Block) stack.Get();
						arr.parent = parentBlock; // parent는 클래스나 함수, 제어블록 등이 될수 있다.
						stack.Push(arr);						
						
						
						// 배열초기화를 lValue에 연결한다.
						FindVarUseParams varUseLValue = 
						//		(FindVarUseParams) data.mlistOfAllVarUses.getItem(data.mlistOfAllVarUses.getCount()-1);
							CompilerStatic.getVarUseWithIndex(data.mlistOfAllVarUsesHashed, varUseName.str, nameIndex);
						if (varUseLValue!=null) {
							varUseLValue.arrayInitializer = arr;
							
							// 배열초기화를 대입문에 연결한다.
							if (data.mlistOfAllAssignStatements.count>0) {
								FindAssignStatementParams assignStatement = 
										(FindAssignStatementParams) data.mlistOfAllAssignStatements.getItem(data.mlistOfAllAssignStatements.count-1);
								assignStatement.arrayInitializer = arr;
							}
							else {
								CompilerStatic.errors.add(new Error(compiler, i, i, "Parenthesis is not paired"));
								compiler.PairErrorExists = true;
							}
						}
						
						
						// nextIndex는 { 의 인덱스
						i = nextIndex+1;
						continue;
					}
					else {
						i++;
						continue;
					}
				}
				else {
					i++;
					continue;
				}
			}
			// 배열 초기화문  char[][] a = {{'a', 'a'}, {'b', 'b'}}; 에서 처음 {}안의 중첩된 {'a','a'}를 처리한다.
			else if (str.equals("{") && currentBlock instanceof FindArrayInitializerParams) {
				int indexRightPair = Checker.CheckParenthesis(compiler, "{", "}", i, src.count-1, false);
				if (indexRightPair!=-1) {
					FindArrayInitializerParams arr = new FindArrayInitializerParams(compiler, -1, i, indexRightPair);
					FindBlockParams blockParams = new FindBlockParams(compiler, i, indexRightPair);
					arr.findBlockParams = blockParams;
					// 중첩된 배열초기화는 mlistOfAllArrayIntializers에 등록을 하지 않는다.
					//mlistOfAllArrayIntializers.add(arr);
					
					Block parentBlock = (Block) stack.Get();
					arr.parent = parentBlock; // parent는 FindArrayInitializerParams이다.
					stack.Push(arr);
					
					// 상위 배열초기화문에 등록한다.
					FindArrayInitializerParams parentArr = (FindArrayInitializerParams) parentBlock;
					//parentArr.listOfFindArrayInitializerParams.add(arr)
					this.putArrayInitializerToParent(arr, parentArr);
					i = i+1;
					continue;
				}
				else {
					i++;
					continue;
				}
			}
			else if (str.equals("{")) {
				Block parentBlock = (Block) stack.Get();
				if (parentBlock!=null && parentBlock.findBlockParams!=null && parentBlock.findBlockParams.startIndex()!=i) {
					// fo (int i=0; i<3; i++) {
					// } 이와 같은 에러가 있는 특별한 블록인 경우
					Block errorBlock = new Block();
					this.FindErrorBlock(i, errorBlock);
					errorBlock.parent = parentBlock;
					this.putStatementToParent(errorBlock, parentBlock);
					
					stack.Push(errorBlock);
					
					CompilerStatic.errors.add(new Error(compiler, i, i, "invalid keyword, or invalid parenthesis"));
					compiler.PairErrorExists = true;
					i++;
					continue;
				}
				else {
					i++;
					continue;
				}
			}
			else if (str.equals("?")) {
				int indexOfColon = Checker.CheckParenthesis(compiler, "?", ":", i, src.count-1, false);
				if (indexOfColon!=-1) {
					FindThreeOperandsOperation threeOperandsOperation = new FindThreeOperandsOperation(i, indexOfColon);
					threeOperandsOperation.parent = (Block) stack.Get();
					/*Block parentBlock = stack.Get();
					FindStatementParams lastStatement = null;
					if (parentBlock.listOfStatements.count-1>=0) {
						lastStatement = (FindStatementParams) parentBlock.listOfStatements.getItem(parentBlock.listOfStatements.count-1);
					}
					threeOperandsOperation.parent = lastStatement.parent;*/
					data.mlistOfThreeOperandsOperation.add(threeOperandsOperation);
				}
				i++;
				continue;
			}
			else if (str.equals("new")) {
				//i++;
				//continue;
				Constructor c = new Constructor(compiler);
				c.indexOfNew = IndexForHighArray.indexRelative(c, src, i);
				if (i==21582){
				}
				
				int startIndexNew = i+1;
				int indexTemp = CompilerHelper.SkipBlank(src, false, startIndexNew, src.count-1);
				int endIndexNew = Fullname.getFullNameIndex_OnlyType(compiler,  false, indexTemp, false);
				int leftPairIndex = CompilerHelper.SkipBlank(src, false, endIndexNew+1, src.count-1);
				
				Template t = null;
				// stack = new Stack();에서 템플릿을 등록하고 올바른 endIndexNew을 정한다.
				if (src.getItem(leftPairIndex).equals("<")) {
					int rightPairIndex = Checker.CheckParenthesis(compiler, "<", ">", leftPairIndex, src.count-1, false);
					if (rightPairIndex!=-1) {
						t = TemplateBase.isTemplate(compiler, rightPairIndex);
						if (t!=null) {
							c.template = t;
							c.endIndexExceptPair = IndexForHighArray.indexRelative(c, src, t.indexRightPair());
							//compilerStack.mlistOfAllTemplates.add(t);
							this.putTempate(t);
							int leftPairIndexOfFuncCall = CompilerHelper.SkipBlank(src, false, rightPairIndex+1, src.count-1);
							if (src.getItem(leftPairIndexOfFuncCall).equals("(")) {
								int rightPairIndexOfFuncCall = Checker.CheckParenthesis(compiler, "(", ")", leftPairIndexOfFuncCall, src.count-1, false);
								if (rightPairIndexOfFuncCall!=-1) {
									endIndexNew = rightPairIndexOfFuncCall;
								}
							}
						}
					}
				}//if (src.getItem(leftPairIndex).equals("<")) {
				
				
				c.startIndex = IndexForHighArray.indexRelative(c, src, startIndexNew);
				c.endIndex = IndexForHighArray.indexRelative(c, src, endIndexNew);
				String fullname = Fullname.getFullName(src, c.startIndex(), c.endIndex()).str;
				int dimension = Array.getArrayDimension(compiler, fullname);
				c.dimension = dimension;
				//c.listOfLength = CompilerHelper.getArrayLength(compiler, fullname);
				
				int startIndexNew2 = i+1;		
				c.startIndexExceptPair = IndexForHighArray.indexRelative(c, src, startIndexNew2);
				
				if (t==null) {
					int endIndexNew2 = i+1;
					endIndexNew2 = CompilerHelper.SkipBlank(src, false, endIndexNew2, src.count-1);
					endIndexNew2 = Fullname.getFullNameIndex_OnlyType(compiler,  false, endIndexNew2, true);
					c.endIndexExceptPair = IndexForHighArray.indexRelative(c, src, endIndexNew2);
				}
				
				
				//mlistOfAllConstructor.add(c)
				this.putConstructor(c);
				
				if (i==325) {
				}
				
				int indexOfSeparator = CompilerHelper.SkipBlank(src, false, endIndexNew, src.count-1);
				CodeString separator = src.getItem(indexOfSeparator);
				if (separator.equals("{")) {//setOnTouchLisener(new View.OnTouchListener() {});
					// 이벤트 핸들러 클래스를 찾아야 한다.
					FindClassParams eventClass = new FindClassParams(compiler);
					String handlerName = fullname + "(..){..}";
					compilerStack.FindEventHandlerClass(src, eventClass, c.startIndexExceptPair(), c.endIndexExceptPair(), 
							indexOfSeparator, handlerName);
					if (eventClass.findBlockParams!=null && eventClass.findBlockParams.startIndex()!=-1) {
												
						//mlistOfAllDefinedClasses.add(eventClass)
						this.putFindClassParams(eventClass);
						eventClass.allocateListOfVarUses();
						
						FindClassParams parentClass=null;
						Block curBlock = (Block) stack.Get();
						curBlock = CompilerStatic.getParent(curBlock);
						if (curBlock instanceof FindFunctionParams) {
							FindFunctionParams func = (FindFunctionParams) curBlock;
							parentClass = (FindClassParams) func.parent;
						}
						else if (curBlock instanceof FindClassParams) {
							parentClass = (FindClassParams) curBlock;
						}
						
						if (parentClass!=null) {
							//parentClass.childClasses.add(eventClass)
							this.putClassEnumInterfaceToParent(eventClass, parentClass.childClasses);
							eventClass.parent = parentClass;
						}
						
						stack.Push(eventClass);
						
						//i = eventClass.findBlockParams.startIndex() + 1;
						i++;
						continue;
					}				
					else {
						i++;
						continue;
					}
				}
				else { //일반적인 constructor
					i++;
					continue;
				}
			}
			else if (str.equals("enum")) {
				FindClassParams parentClass=null;
				top = (Block) stack.Get();
				if (top instanceof FindClassParams) {
					parentClass = (FindClassParams)top;
				}
				FindClassParams enumParams = new FindClassParams(compiler);
				FindClass(src, enumParams, i, src.count-1, true, coreThreadID);
				if (enumParams.findBlockParams!=null && enumParams.findBlockParams.startIndex()!=-1) {					
					/*if (stack.len==0) { // 최상위 클래스만 등록
						result.add(enumParams)
					}*/
					this.putClassEnumInterfaceToResult(enumParams, result, stack);
					stack.Push(enumParams);
					//mlistOfAllDefinedClasses.add(enumParams);
					this.putFindClassParams(enumParams);
					
					if (parentClass!=null) {
						//parentClass.childClasses.add(enumParams);
						this.putClassEnumInterfaceToParent(enumParams, parentClass.childClasses);
						enumParams.parent = parentClass;
					}
					i = enumParams.findBlockParams.startIndex() + 1;
					continue;
				}
				else {
					i++;
					continue;
				}
			}
			else if (str.equals("interface")) {
				FindClassParams parentClass=null;
				top = (Block) stack.Get();
				if (top instanceof FindClassParams) {
					parentClass = (FindClassParams)top;
				}
				FindClassParams interfaceParams = new FindClassParams(compiler);
				FindInterface(src, interfaceParams, i, src.count-1, coreThreadID);
				if (interfaceParams.findBlockParams!=null /*&& interfaceParams.findBlockParams.startIndex()!=-1*/) {
					/*if (stack.len==0) { // 최상위 클래스만 등록
						result.add(interfaceParams);
					}*/
					this.putClassEnumInterfaceToResult(interfaceParams, result, stack);
					stack.Push(interfaceParams);
					//mlistOfAllDefinedClasses.add(interfaceParams);
					this.putFindClassParams(interfaceParams);
					interfaceParams.allocateListOfVarUses();
					
					if (parentClass!=null) {
						//parentClass.childClasses.add(interfaceParams);
						this.putClassEnumInterfaceToParent(interfaceParams, parentClass.childClasses);
						interfaceParams.parent = parentClass;
					}
					if (interfaceParams.indexOfExtends()!=-1) {
						i = interfaceParams.indexOfExtends() + 1;
					}
					else {
						if (interfaceParams.findBlockParams.startIndex()==-1) {
							i++;
						}
						else {
							i = interfaceParams.findBlockParams.startIndex() + 1;
						}
					}
					continue;
				}
				else {
					i++;
					continue;
				}
			}
			else if (str.equals("class")) {
				if (i==1025) {
				}
				FindClassParams parentClass=null;
				FindClassParams classParams;
				top = (Block) stack.Get();
				if (top instanceof FindClassParams) {
					parentClass = (FindClassParams)top;
				}
				classParams = new FindClassParams(compiler);
				FindClass(src, classParams, i, src.count-1, false, coreThreadID);
				if (classParams.findBlockParams!=null/* && classParams.findBlockParams.startIndex()!=-1*/) {
					
					if (classParams.findBlockParams.blockName.equals("DocuComment")) {
					}
					
					/*if (stack.len==0) { // 최상위 클래스만 등록
						result.add(classParams);
					}*/
					this.putClassEnumInterfaceToResult(classParams, result, stack);
					stack.Push(classParams);
					//mlistOfAllDefinedClasses.add(classParams);
					this.putFindClassParams(classParams);
					classParams.allocateListOfVarUses();
					
					if (parentClass!=null) {
						//parentClass.childClasses.add(classParams);
						this.putClassEnumInterfaceToParent(classParams, parentClass.childClasses);
						classParams.parent = parentClass;
						
						parentClass.listOfStatements.add(classParams);
					}
					//i = classParams.findBlockParams.startIndex() + 1;
					if (classParams.indexOfExtends()!=-1) {
						i = classParams.indexOfExtends() + 1;
						continue;
					}
					else if (classParams.indexOfImplements()!=-1) {
						i = classParams.indexOfImplements() + 1;
						continue;
					}
					else {
						if (classParams.findBlockParams.startIndex()!=-1) {
							i = classParams.findBlockParams.startIndex() + 1;
						}
						else {
							i++;
						}
						continue;
					}
				}				
				else {
					i++;
					continue;
				}
			}
			/*else if (str.equals("extends")) {
				i++;
				continue;
			}
			else if (str.equals("implements")) {
				i++;
				continue;
			}*/
			else if (str.equals("return") || str.equals("continue") || str.equals("break") || 
					str.equals("throw")) {
				FindSpecialStatementParams specialStatement = compilerStack.FindSpecialStatement(src, i);
				if (specialStatement==null) {
					i++;
					continue;
				}
				
				Block parent = (Block) stack.Get();
				specialStatement.parent = parent;
				// return, continue, break문등의 SpecialStatements일 경우
				//parent.listOfStatements.add(specialStatement)
				this.putStatementToParent(specialStatement, parent);
				//mlistOfSpecialStatement.add(specialStatement)
				this.putFindSpecialStatementParams(specialStatement);
				
				if (str.equals("return")) {
					//this.mlistOfReturn.add(specialStatement);
					startIndexOfReturn = specialStatement.startIndex();
					endIndexOfReturn = specialStatement.endIndex();
				}
				i++;
				continue;
			}
			
			// 변수이름 찾기, 상수일 경우도 포함된 이유는 varUse를 찾기 위해서이다.
			else if (CompilerHelper.IsIdentifier(str, compiler) || CompilerHelper.IsConstant(str) ||
					CompilerHelper.IsDefaultType(str, compiler) /*||
	        		str.equals("return") || str.equals("continue") || str.equals("break")*/)   
			{ // 식별자, 상수, 타입(타입캐스트), 특수문이면
				if (i==92) {
				}
				if (str.equals("return")) {
				}
				else if (str.equals("CustomView_test")) {
				}
				else if (str.equals("Object")) {
				}
				try {
					top = (Block) stack.Get();
				}catch(Exception e) {
				}
				if (i==1365) {
				}
				
				// break문을 만나고 스택의 top이 case문이면 caseBlock.breakExistsWhenCase을 true로 설정한다.
				// 이후에 다음 case문을 만나면 이전 case문의 끝을 정해준다.(이 함수의 case를 참조한다.)
				if (str.equals("break")) {
					FindControlBlockParams caseBlock = null;
					if (top!=null && top instanceof FindControlBlockParams) {
						caseBlock = (FindControlBlockParams) top;
						if (caseBlock.catOfControls!=null && caseBlock.catOfControls.category==CategoryOfControls.Control_case)
							caseBlock.breakExistsWhenCase = true;
					}
				}
				
				
				// 함수 정의문의 함수이름은 continue
				boolean isFunctionDecl = Checker.CheckBody(compiler, src, i, stack);
				if (isFunctionDecl) {
					i++;
					continue;
				}
				
				FindVarParams var = null;
				FindVarUseParams varUse = null;
				ReturnOfFindVarDecl returnOfFindVarDecl;
				returnOfFindVarDecl = compilerStack.FindVarDeclarationsAndVarUses(src, i, oldTypeIndex, coreThreadID);
				if (returnOfFindVarDecl==null) oldTypeIndex = null;
				else {
					oldTypeIndex = returnOfFindVarDecl.oldTypeIndex;
					var = returnOfFindVarDecl.var;
					varUse = returnOfFindVarDecl.varUse;
				}
				
				if (top==null || !(top instanceof Block)) {
					i++;
					continue;
				}
				if (var==null && varUse==null) {
					i++;
					continue;
				}
				
				Block parent = top;
				
				if (var!=null) {
					var.fieldName = src.getItem(var.varNameIndex()).str;
					if (var.varNameIndex()==3167) {
					}
					
					/*boolean varIsDefinedInForLoopParenthesis = false;
					if (compilerStack.varIsDefinedInForLoopParenthesis(var, parent)) {
						varIsDefinedInForLoopParenthesis = true;
						var.isDefinedInPairsOfForLoop = (FindControlBlockParams)parent;
					}*/
					
					// 변수선언을 처음으로 감싸는 함수나 클래스를 변수선언의 parent로 삼는다.
					Block parentBlock = CompilerStatic.getParent(parent);
					/*if (!varIsDefinedInForLoopParenthesis) {
						var.parent = parent;
					}
					else {
						// for루프가 아니라 for루프의 parent에 들어가도록 한다.
						var.parent = parent.parent;
						//var.parent = parent;
					}*/
					var.parent = parent;
					
					if (!Checker.CheckVarNameOrVarUseName(compiler, var.fieldName)) {
						CompilerStatic.errors.add(new Error(compiler, var.varNameIndex(), var.varNameIndex(), 
								"invalid var name : " + var.fieldName));
					}
					
					boolean r = Checker.CheckVarScope(compiler, src, var);
					if (r) {
						var.startIndexOfScope = IndexForHighArray.indexRelative(var, src, var.varNameIndex());
						
						if (parentBlock instanceof FindClassParams) {
							// 변수선언을 처음으로 감싸는 함수나 클래스의 listOfVariableParams에 넣어준다.
							//parentBlock.listOfVariableParams.add(var)
							this.putVarToParent(var, parentBlock);
							//mlistOfAllMemberVarDeclarations.add(var)
							this.putFindVarParams(var, false);
							var.isMemberOrLocal = true;
							// 클래스의 listOfStatements에 문장으로 넣는다.
							parent.listOfStatements.add(var);
							
						}
						else if (parentBlock instanceof FindFunctionParams) {
							// 변수선언을 처음으로 감싸는 함수나 클래스의 listOfVariableParams에 넣어준다.
							//parentBlock.listOfVariableParams.add(var);
							this.putVarToParent(var, parentBlock);
							var.indexOfLocalVarsInFunctionBeforeProcessLocalVars = parentBlock.listOfVariableParams.count-1;
							
							if (parent instanceof FindControlBlockParams || 
									parent instanceof FindSpecialBlockParams) {
								// 2016.10.26 추가
								// 제어블록에도 들어가야 '}' 처리시 endIndexOfScope가 정확해진다.
								/*if (!varIsDefinedInForLoopParenthesis) {
									this.putVarToParent(var, parent);
								}
								else {
									// for루프가 아니라 for루프의 parent에 들어가도록 한다.
									if (!(parent.parent instanceof FindFunctionParams)) {
										// parent.parent가 FindFunctionParams이면 
										// putVarToParent(var, parentBlock);에서 이미 넣어진 것이다.
										this.putVarToParent(var, parent.parent);
									}
								}*/
								this.putVarToParent(var, parent);
							}
							FindFunctionParams func = (FindFunctionParams) parentBlock;
							// 함수 파라미터에 선언된 지역변수선언은 제외한다. 
							if (func.indexOfLeftParenthesis()<=var.varNameIndex() && 
									var.varNameIndex()<=func.indexOfRightParenthesis()) {
								//func.listOfFuncArgs.add(var)
								this.putVarToFunctionArg(var, func);
								//mlistOfAllLocalVarDeclarations.add(var);
								this.putFindVarParams(var, true);
								var.isMemberOrLocal = false;
							}
							else {
								//mlistOfAllLocalVarDeclarations.add(var)
								this.putFindVarParams(var, true);
								var.isMemberOrLocal = false;
								// 함수의 listOfStatements에 문장으로 넣는다. 함수파라미터는 제외한다.
								//parent.listOfStatements.add(var);
								boolean inInParenthesis = false;
								/*if (varIsDefinedInForLoopParenthesis) {
									// for (int j=0; j<3; j++) { 여기에서 int j
									// 이런 경우 int j는 for블록에 들어갔었지만, for의 parent에 넣는다.
									inInParenthesis = true;
									// for루프가 아니라 for루프의 parent에 들어가도록 한다.
									this.putStatementToParent(var, parent.parent);
								}
								else*/ if (parent instanceof FindControlBlockParams) {
									// catch에 선언된 Exception 변수
									FindControlBlockParams controlBlock = (FindControlBlockParams) parent;
									if (controlBlock.indexOfLeftParenthesis()<=var.startIndex() &&
										var.endIndex()<=controlBlock.indexOfRightParenthesis()) {
										inInParenthesis = true;
										// catch에 선언된 선언문을 괄호안에 넣는다.
										controlBlock.listOfStatementsInParenthesis.add(var);
									}
								}
								if (!inInParenthesis) {
									this.putStatementToParent(var, parent);
								}
							}
						}
					}
				}
				
				if (varUse!=null) {					
					// varUse가 enumElement인 경우 FindVarParams로 바꿔서 enum타입에 넣어준다.
					if (top instanceof FindClassParams) {
						FindClassParams parentEnum = (FindClassParams)top;
						if (parentEnum.isEnum) {
							FindVarParams enumElement = new FindVarParams(compiler, varUse.index(), true, parentEnum);
							enumElement.fieldName = src.getItem(varUse.index()).str;
							String typeFullname = data.packageName + "." + Fullname.getFullNameExceptPackageName(src, parentEnum);
							typeFullname = typeFullname.substring(0, typeFullname.length()-1);
							enumElement.typeName = typeFullname;
							enumElement.isMemberOrLocal = true;
							
							// enum 변수에는  accessModifier가 없으므로 다음과 같이 public, static으로 설정한다.
							enumElement.accessModifier = new AccessModifier(compiler, -1, -1);
							enumElement.accessModifier.accessPermission = AccessPermission.Public;
							enumElement.accessModifier.isStatic = true;
							enumElement.accessModifier.isEnum = true;
							enumElement.accessModifier.isFinal = true;
							
							//parentEnum.listOfVariableParams.add(enumElement);
							this.putVarToParent(enumElement, parentEnum);
							// 클래스의 listOfStatements에 문장으로 넣는다.
							//parentEnum.listOfStatements.add(enumElement);
							this.putStatementToParent(enumElement, parentEnum);
							
							int docuIndex = varUse.index()-1;
		                	int indexOfDocuEnd = CompilerHelper.SkipOnlyBlank(src, true, 0, docuIndex); // 공백 스킵
		                	DocuComment docu = 
		                			compilerStack.FindDocuComment(src, /*false, null, findVarParams,*/ 0, indexOfDocuEnd);
		                	enumElement.docuComment = docu;
		                	
							i = varUse.index()+1;
							varUse.isEnumElement = true;
							continue;
						}
					}
					
					 
					Block parentBlock = CompilerStatic.getParent(parent);
					if (parentBlock instanceof FindClassParams) {
						FindClassParams parentClass = (FindClassParams)parentBlock;
						varUse.classToDefineThisVarUse = parentClass;						
						this.putVarUseToClass(varUse, parentClass);
					}
					else if (parentBlock instanceof FindFunctionParams) {
						FindFunctionParams parentFunc = (FindFunctionParams)parentBlock;
						varUse.funcToDefineThisVarUse = parentFunc;
						this.putVarUseToFunction(varUse, parentFunc);						
												
						FindClassParams parentClass = (FindClassParams)parentFunc.parent;
						if (parentClass==null) {
						}
						if (parentClass!=null && !parentClass.isEnum) {							
							// 해당 클래스의 listOfAllVarUses에도 넣어준다.
							varUse.classToDefineThisVarUse = parentClass;
							this.putVarUseToClass(varUse, parentClass);
						}
						
					}//else if
				
				}//if (varUse.index()!=-1)
				
				if (varUse!=null) {
					int indexOfFullname = Fullname.getFullNameIndex(compiler, false, varUse.index(), true);
					if (indexOfFullname!=varUse.index()) {
						// this.countOfPaint++; 에서 varUse가 this일 경우 continue하고
						// countOfPaint가 varUse가 될때 lValue로 삼는다.
						i++;
						continue;
					}
					
					FindIncrementStatementParams inc = compilerStack.findIndependentIncrementStatement_sub(src, varUse, coreThreadID);
					if (inc!=null) {
						//inc.lValue = varUse;
						inc.setLValue(varUse);
						varUse.inc = inc;
					}
					
					Block parentBlock = parent;
					
					// ++i;,i++;와 같은 독립적인 증감문을 찾아서 해당 블록의 listOfStatements에 넣는다.
					FindIncrementStatementParams independentInc = compilerStack.findIndependentIncrementStatement(src, inc, top);
					boolean isIndependent = true;
					if (independentInc!=null) {	
						//inc.lValue = varUse;
						inc.setLValue(varUse);
						varUse.inc = inc;
						
						if (parentBlock instanceof FindControlBlockParams) {
							FindControlBlockParams controlBlock = (FindControlBlockParams) parentBlock;
							if (controlBlock.indexOfLeftParenthesis()<varUse.index() && 
									varUse.index()<controlBlock.indexOfRightParenthesis()) {
								// 제어블록의 괄호안에 있는 listOfStatementsInParenthesis에 넣는다.
								isIndependent = false;
								if (controlBlock.listOfStatementsInParenthesis==null) {
									controlBlock.listOfStatementsInParenthesis = new ArrayListIReset(5);										
								}
								//controlBlock.listOfStatementsInParenthesis.add(independentInc);
								this.putStatementToParenthesisOfParent(independentInc, controlBlock);
								independentInc.parent = controlBlock; 
							}
						}
						// 독립적인 증감문만
						if (isIndependent) {							
							//parentBlock.listOfStatements.add(independentInc);
							this.putStatementToParent(independentInc, parentBlock);
							independentInc.parent = parentBlock;
							startIndexOfIndependentInc = independentInc.startIndex();
							endIndexOfIndependentInc = independentInc.endIndex();
						}
					}//if (independentInc!=null) {	
					
				}//if (varUse.index()!=-1) {
				
				
				if (varUse!=null) {
					if (varUse.index()==316) {
					}
					
					// 변수사용 다음에 '='이 오는 수식을 찾는다. 
					// 그러나 조건문, 반복문의 조건에 할당문이 있을수 있으므로 그것을 제외한다.
					int indexOfEquals = compilerStack.IsLValue(src, varUse); 
					if (indexOfEquals>0) {
						
						
						// 배열초기화문이면 여기에선 제외하고 FindAllClassesAndItsMembers2_sub()의 배열초기화문을 처리할때 넣는다.
						//boolean isArrayIntitializer = isArrayInitializer(src, varUse);
						//if (isArrayIntitializer) continue;
						
						FindAssignStatementParams assignStatement = new FindAssignStatementParams(compiler, -1, -1);
						compilerStack.FindAssignStatement(src, assignStatement, varUse, indexOfEquals, top);
						
						if (assignStatement.found) {
							this.putFindAssignStatementParamsTomlistOfAllAssignStatements(assignStatement);
							
							// a = 1 + f1().f2(); 에서 할당문이므로 f1(), f2()는 건너뛴다. 
							// a = 1 + (a2 = 2); 에서 a2는 건너뛴다.
							if (isAssignOrIndependentFuncCall &&
									startIndexOfAssign<=varUse.index() && varUse.index()<=endIndexOfAssign) {
								assignStatement.isIndependent = false;
							}
							// f1 ( f2() );  여기에서 f2()는 건너뛴다.
							// f (a=3, b); 에서 a는 건너뛴다.
							else if (!isAssignOrIndependentFuncCall &&
									startIndexOfIndependentFuncCall<=varUse.index() && 
									varUse.index()<=endIndexOfIndependentFuncCall) {
								assignStatement.isIndependent = false;
							}
							else if (startIndexOfReturn<=varUse.index() && varUse.index()<=endIndexOfReturn) {
								assignStatement.isIndependent = false;
							}
							Block parentBlock = parent;
							if (parentBlock instanceof FindControlBlockParams) {
								FindControlBlockParams controlBlock = (FindControlBlockParams) parentBlock;
								if (controlBlock.indexOfLeftParenthesis()<varUse.index() && 
										varUse.index()<controlBlock.indexOfRightParenthesis()) {
									// 제어블록의 괄호안에 있는 할당문은 listOfStatementsInParenthesis에 넣는다.
									assignStatement.isIndependent = false;
									if (controlBlock.listOfStatementsInParenthesis==null) {
										controlBlock.listOfStatementsInParenthesis = new ArrayListIReset(5);										
									}
									//controlBlock.listOfStatementsInParenthesis.add(assignStatement)
									this.putStatementToParenthesisOfParent(assignStatement, controlBlock);
									assignStatement.parent = controlBlock;
								}
							}
							// 독립적인 할당문만 리스트에 등록하고 블록에 넣는다.
							if (assignStatement.isIndependent) {
								//mlistOfAllAssignStatements.add(assignStatement)
								this.putFindAssignStatementParams(assignStatement);
								
								startIndexOfAssign = assignStatement.startIndex();
								endIndexOfAssign = assignStatement.endIndex();
								
								assignStatement.found = false;
								
								//parentBlock.listOfStatements.add(assignStatement);
								this.putStatementToParent(assignStatement, parentBlock);
								
								assignStatement.parent = parentBlock;
								
								//inputStatementToSuitableBlock(src, classParams, assignStatement);
								isAssignOrIndependentFuncCall = true;
								
								//compiler.findIncrementStatements(src, assignStatement);
							}
						}//if (assignStatement.found) {
					}//if (indexOfEquals>0) {
					
					else if (!varUse.isForVarOrForFunc) { // 독립적인 함수호출문 찾기
						boolean isIndependent = true;
						
						if (varUse.index()==379) {
						}
						Block curBlock = (Block) stack.Get();
						if (curBlock instanceof FindControlBlockParams) {
							FindControlBlockParams curControlBlock = (FindControlBlockParams) curBlock;
							if (curControlBlock.indexOfLeftParenthesis()<=varUse.index() && 
									varUse.index()<=curControlBlock.indexOfRightParenthesis()) {
								// in condition of contolBlock
								isIndependent = false;
							}
						}
						
						// a = 1 + f1().f2(); 에서 할당문이므로 f1(), f2()는 건너뛴다. 
						if (isAssignOrIndependentFuncCall &&
								startIndexOfAssign<=varUse.index() && varUse.index()<=endIndexOfAssign) {
							isIndependent = false;
						}
						// f1 ( f2() );  여기에서 f2()는 건너뛴다.
						else if (!isAssignOrIndependentFuncCall &&
								startIndexOfIndependentFuncCall<=varUse.index() && varUse.index()<=endIndexOfIndependentFuncCall) {
							isIndependent = false;
						}
						else if (startIndexOfReturn<=varUse.index() && varUse.index()<=endIndexOfReturn) {
							isIndependent = false;
						}
						else if (startIndexOfIndependentInc<=varUse.index() && varUse.index()<=endIndexOfIndependentInc) {
							isIndependent = false;
						}
						if (i==37162) {
						}
						
						if (isIndependent) {
							FindIndependentFuncCallParams independentFuncCall = new FindIndependentFuncCallParams(compiler, -1, -1);
							try {
								compilerStack.FindIndependentFuncCall(src, varUse, independentFuncCall);
							}catch(Exception e) {
								e.printStackTrace();
							}
							
							if (independentFuncCall.found) {
								Block parentBlock = parent;
								if (parentBlock instanceof FindControlBlockParams) {
									FindControlBlockParams controlBlock = (FindControlBlockParams) parentBlock;
									if (controlBlock.indexOfLeftParenthesis()<varUse.index() && 
											varUse.index()<controlBlock.indexOfRightParenthesis()) {
										// 제어블록의 괄호안에 있는 listOfStatementsInParenthesis에 넣는다.
										isIndependent = false;
										if (controlBlock.listOfStatementsInParenthesis==null) {
											controlBlock.listOfStatementsInParenthesis = new ArrayListIReset(5);										
										}
										this.putStatementToParenthesisOfParent(independentFuncCall, controlBlock);
										independentFuncCall.parent = controlBlock;
									}
								}
								// 독립적인 함수호출문만
								if (isIndependent) {							
									startIndexOfIndependentFuncCall = independentFuncCall.startIndex();
									endIndexOfIndependentFuncCall = independentFuncCall.endIndex();
									
									//parentBlock.listOfStatements.add(independentFuncCall);
									this.putStatementToParent(independentFuncCall, parentBlock);
									independentFuncCall.parent = parentBlock;
									//inputStatementToSuitableBlock(src, classParams, independentFuncCall);
									isAssignOrIndependentFuncCall = false;
									
									//compiler.findIncrementStatements(src, independentFuncCall);
								}
							}// if (independentFuncCall.found) {
						}
					}//else if (varUse.isForVarOrForFunc==false) { // 독립적인 함수호출문 찾기
				}//if (varUse.index()!=-1)
				
				
				
				
				if (var!=null) {
					if (src.getItem(var.endIndex()).equals("=")) {
						//for (char c='a'; c<='z'; c++) {
						//char[] arr = {c}; 여기에서 var는 arr이고 endIndex()는 =을 가리킨다.						
						// arr은 배열초기화문장인데 다음 }을 만날때 for블록이 pop될수가 있다.
						// 아래와 같이 i = var.endIndex();을 다음인덱스로 해줘야 배열초기화 처리를 할 수가있다.
						i = var.endIndex();
					}
					else {
						i = var.endIndex() + 1;
					}
					continue;
				}
				i++;
				continue;
			} // else if (IsIdentifier(str)) {
			
			
			
			else if (str.equals("static")) { // static 블럭
				top = (Block) stack.Get();
				FindFunctionParams function = new FindFunctionParams(compiler, -1, -1);
				if (top instanceof FindClassParams) {
					FindClassParams parent = (FindClassParams)top;
					//FindFunction(src, parent, function, i)
					compilerStack.findStaticBlock(src, parent, function, i);
				}
				
				if (function.found) {	// 함수 정의
					function.name = function.findBlockParams.blockName;
					function.returnType = "void";
					
					function.isConstructor = true;
					function.isConstructorThatInitializesStaticFields = true;
					
					//mlistOfAllFunctions.add(function)
					this.putFindFunctionParams(function);
					if (top instanceof FindClassParams) {
						FindClassParams parent = (FindClassParams)top;
						//parent.listOfFunctionParams.add(function)
						this.putFunctionToParent(function, parent);
						
						function.parent = parent;
						parent.listOfConstructor.add(function);
					}
					else {
						CompilerStatic.errors.add(new Error(compiler, i, i, "invalid static block."));
					}
					
					stack.Push(function);
					function.allocateListOfVarUses();
					//i = function.findBlockParams.startIndex() + 1;
					i++;
					continue;
				}
				else { //  함수호출, 수식 등
					i++;
					continue;
				}
				
			}
			
			else if (str.equals("(")) {
				
				top = (Block) stack.Get();
				
				if (!allOrPart && functionForPart!=null) {
					top = functionForPart.parent;
				}
				
				FindFunctionParams function = null;
				int indexID = CompilerHelper.SkipBlank(src, true, 0, i-1);
				
				if (CompilerHelper.IsIdentifier(src.getItem(indexID), compiler)) {
					function = new FindFunctionParams(compiler, -1, -1);
					if (top instanceof FindClassParams) {
						FindClassParams parent = (FindClassParams)top;
						compilerStack.FindFunction(src, parent, function, i, coreThreadID);
					}
					else {
						compilerStack.FindFunction(src, null, function, i, coreThreadID);
					}					
				}
				
				if (function!=null && function.found) {	// 함수 정의
					function.name = src.getItem(function.functionNameIndex()).str;
					function.allocateListOfVarUses();
					
					if (!allOrPart && functionForPart!=null) {						
						function.copyTo(functionForPart);
						function = functionForPart;
					}
					if (!(top instanceof FindClassParams)) {
						// 함수 정의 전에 '}'이 없을 경우						
						CompilerStatic.errors.add(new Error(compiler, indexID, indexID, "Function has to be defined in a class. Parenthesis is not paired."));
						compiler.PairErrorExists = true;
						//return;
					}
					
					
					
					//mlistOfAllFunctions.add(function);
					this.putFindFunctionParams(function);
					if (top instanceof FindClassParams) {						
						FindClassParams parent = (FindClassParams)top;
						//parent.listOfFunctionParams.add(function);
						this.putFunctionToParent(function, parent);
						function.parent = parent;
						
						parent.listOfStatements.add(function);
						
						
						if (parent.isInterface) {
							if (!function.isAbstractMethod) {	
								if (!function.accessModifier.isStatic) {
									CompilerStatic.errors.add(new Error(compiler, function.functionNameIndex(), function.functionNameIndex(), 
		        						"Non-static method in interface must not have body."));
								}
							}
							else {
								if (function.accessModifier.isStatic) {
									//static interface Controllable {
									//  	public static void reset(); -> error
								    // }
									CompilerStatic.errors.add(new Error(compiler, function.functionNameIndex(), function.functionNameIndex(), 
			        						"Static method in interface must have body."));
								}
								else {
									// interface method has abstract keyword.
									function.accessModifier.isAbstract = true;
								}
							}
							if (function.accessModifier.accessPermission!=AccessPermission.Public) {
		        				CompilerStatic.errors.add(new Error(compiler, function.functionNameIndex(), function.functionNameIndex(), 
		        						"interface method must have public keyword."));
		        			}
							
						}
						
						if (function.isAbstractMethod) {        			
		        			if (function.accessModifier.isFinal) {
		        				CompilerStatic.errors.add(new Error(compiler, function.functionNameIndex(), function.functionNameIndex(), 
		        						"Abstract method has an final method."));
		        			}
		        			if (!parent.isInterface && !function.accessModifier.isAbstract && !function.accessModifier.isNative) {  
		        				// abstract method in abstract class
		        				CompilerStatic.errors.add(new Error(compiler, function.functionNameIndex(), function.functionNameIndex(), 
		        						"Abstract method does not have abstract keyword."));
		        			}   
		        		}
						
						FindClassParams parentClass = parent;
						if (function.isAbstractMethod) {
		        			if (!parentClass.isInterface && !parentClass.isEnum && !parentClass.accessModifier.isAbstract ) {
		        				CompilerStatic.errors.add(new Error(compiler, parentClass.classNameIndex(), parentClass.classNameIndex(),
		        						"Class with abstract method must have abstract access modifier"));
		        			} 
						}
	        			
						if (function.isConstructor) {
							parent.listOfConstructor.add(function);
						}
					}
					else {
						CompilerStatic.errors.add(new Error(compiler, function.startIndex(), function.startIndex(), "invalid function"));
					}
					
					//if (!function.isInterfaceMethod) {						
						stack.Push(function);
					//}
					
					//i = function.findBlockParams.startIndex() + 1;
					i++;
					continue;
				}
				else { //  함수호출, 수식 등
					i++;
					continue;
				}
			}
			else if (str.equals("synchronized") || str.equals("try") || str.equals("catch") || str.equals("finally")) {
				if (str.equals("finally")) {
				}
				if (i==10439) {
				}
				top = (Block) stack.Get();
				FindSpecialBlockParams block = new FindSpecialBlockParams(compiler, 0, -1, -1);
				compilerStack.FindSpecialBlock(src, block, i);
				if (block.found) {					
					if (top!=null && !(top instanceof FindClassParams)) {
						Block parent = top;
						//parent.listOfControlBlocks.add(block)
						this.putControlBlockToParent(block, parent);
						//parent.listOfStatements.add(block);
						this.putStatementToParent(block, parent);
						this.putFindControlBlockParams(block);
						/*if (src.getItem(block.nameIndex()).equals("synchronized")) {
							this.putSynchronizedBlockTomlistOfSynchronizedBlocks(block);
						}*/
						block.parent = parent;
						block.indexInListOfControlBlocksOfParent = parent.listOfControlBlocks.count-1;
						if (data.mBuffer.getItem(block.nameIndex()).equals("finally")) {
							data.mlistOfFinally.add(block);
						}
					}
					else {
						CompilerStatic.errors.add(new Error(compiler, i, i, "invalid "+str));
					}
					stack.Push(block);
					
					i = block.nameIndex() + 1;
					continue;
				}
				else { // synchronized 함수 등
					i++;
					continue;
				}
			}
			else if (str.equals("if") || str.equals("while") || str.equals("for") || 
					str.equals("else")  || str.equals("do") || 
					str.equals("switch") || str.equals("case") || str.equals("default")) {
				if (i==335) {
				}
				if (str.equals("case")) {
				}
				top = (Block) stack.Get();
				
				/*if (str.equals("else")) {
					if (top.listOfStatements.count>0) {
						FindStatementParams prevStatement = 
								(FindStatementParams) top.listOfStatements.getItem(top.listOfStatements.count-1);
						if (prevStatement instanceof FindControlBlockParams) {
							FindControlBlockParams controlBlock = (FindControlBlockParams) prevStatement;
							String controlName = controlBlock.getName();
							if (controlName.equals("if") || controlName.equals("else if")) {
								
							}
							else {
								CompilerStatic.errors.add(new Error(compiler, i, i, "invalid else"));
							}
						}
						else {
							CompilerStatic.errors.add(new Error(compiler, i, i, "invalid else"));
						
						}
					}
				}*/
				
				if (str.equals("while")) {
					if (top==null) {
						i++;
						continue;
					}
					if (top.listOfStatements.count>0) {
						FindStatementParams prevStatement = 
								(FindStatementParams) top.listOfStatements.getItem(top.listOfStatements.count-1);
						if (prevStatement instanceof FindControlBlockParams) {
							FindControlBlockParams controlBlock = (FindControlBlockParams) prevStatement;
							if (controlBlock.catOfControls!=null && 
									controlBlock.catOfControls.category==CategoryOfControls.Control_dowhile && 
								controlBlock.startIndex()<i && i<controlBlock.endIndex()) {
								i++;
								continue;
							}
						}
					}
					
				}
				
				FindControlBlockParams control = new FindControlBlockParams(compiler, null, -1, -1);
				compilerStack.FindControlBlock(src, i, control);
				if (control.found) {
					if (str.equals("case") && 
							control.findBlockParams!=null && control.findBlockParams.blockName.equals("2")) {
					}
					if (!control.isBlock) {
						
					}
					if (str.equals("else")) {
					}
					boolean isPreviousCase = false;
					FindControlBlockParams caseBlock = null;					
					if (top!=null && top instanceof FindControlBlockParams) {
						caseBlock = (FindControlBlockParams) top;
						// case문 다음에 case문이 오면 이전 case문을 스택에서 pop해준다.
						if (caseBlock.catOfControls!=null && caseBlock.catOfControls.category==CategoryOfControls.Control_case) {
							if (control.catOfControls!=null && control.catOfControls.category==CategoryOfControls.Control_case) {
								isPreviousCase = true;
							}
						}
					}
					// 다음 case문을 만날 경우는 이전 case문을 스택에서 pop해준다.
					if (isPreviousCase) {
						// 이전 case문의 끝을 정해준다.
						caseBlock.endIndex = IndexForHighArray.indexRelative(caseBlock, src, i-1);
						caseBlock.findBlockParams.endIndex = IndexForHighArray.indexRelative(caseBlock.findBlockParams, src, i-1);
						
						setEndIndexOfBlockAndEndIndexOfScopeOfVarInBlock(src, caseBlock, i);
						stack.Pop(); // 이전 case문을 pop
						top = (Block) stack.Get();
					}
					
					if (top!=null && !(top instanceof FindClassParams)) {
						Block parent = top;
						//parent.listOfControlBlocks.add(control);
						this.putControlBlockToParent(control, parent);
						//parent.listOfStatements.add(control);
						this.putStatementToParent(control, parent);
						control.parent = parent;
						control.indexInListOfControlBlocksOfParent = parent.listOfControlBlocks.count-1;
					}
					else {
						// top이 null이거나 클래스, 인터페이스, enum형 내에 있는 제어구조일 경우
						CompilerStatic.errors.add(new Error(compiler, i, i, "invalid "+str));
						compiler.PairErrorExists = true;
					}
					// case나 default가 아니면
					//if (!(control.catOfControls!=null && control.catOfControls.category==CategoryOfControls.Control_case)) {
						stack.Push(control);
					//}
					
					//mlistOfAllControlBlocks.add(control)
					this.putFindControlBlockParams(control);
					
					
					if (control.catOfControls!=null) {
						if (control.catOfControls.category!=CategoryOfControls.Control_elseif) {
							i = control.nameIndex() + 1;
						}
						else {
							i = control.indexOfLeftParenthesis() + 1;
						}
					}
					continue;
				}//if (control.found) {
				else {
					CompilerStatic.errors.add(new Error(compiler, i, i, "invalid "+str));
					i = control.nameIndex() + 1;
					continue;
				}
			}//else if (str.equals("if") || str.equals("while") || str.equals("for") || 
			//str.equals("else")  || str.equals("do") || 
			//str.equals("switch") || str.equals("case")) {
			
			else if (str.equals(")")) { 
				if (i==903) {
				}
				// 제어구조의 오른쪽 괄호, 제어구조의 조건 안에 있는 문장들에 포함된 증감문들을 찾는다.
				Block block = (Block) stack.Get();
				if (block instanceof FindControlBlockParams) {
					FindControlBlockParams controlBlock = (FindControlBlockParams) block;
					int leftPairIndex = -1;
					CodeString keyword = src.getItem(controlBlock.nameIndex());
					leftPairIndex = Checker.CheckParenthesis(compiler,  "(", ")", 0, i, true);
					if (leftPairIndex==-1) {
						i++;
						continue;
					}
					/*int keywordIndex = CompilerHelper.SkipBlank(src, true, 0, leftPairIndex-1);
					if (keywordIndex==-1) {
						i++;
						continue;
					}*/
					
					if (keyword.equals("for") || keyword.equals("while") || keyword.equals("if") || 
							keyword.equals("switch")) { // else if , do while 포함
						if (controlBlock!=null && controlBlock.listOfStatementsInParenthesis!=null && controlBlock.listOfStatementsInParenthesis.count>0) {
							int j;
							for (j=controlBlock.listOfStatementsInParenthesis.count-1; j>=0; j--) {
								FindStatementParams statement = 
									(FindStatementParams) controlBlock.listOfStatementsInParenthesis.getItem(j);
								if (statement instanceof FindAssignStatementParams ||
										statement instanceof FindIndependentFuncCallParams) {
									compilerStack.findIncrementStatementInStatement(src, statement, coreThreadID);
								}
							}
						}
					}//if (keyword.equals("for") || keyword.equals("while") || keyword.equals("if") || keyword.equals("switch")) { // else if , do while 포함
				}//if (block instanceof FindControlBlockParams) {
				i++;
				continue;
			}//else if (str.equals(")")) { // 제어구조의 오른쪽 괄호
					
			else if (str.equals(";")) {
				Block curBlock = (Block) stack.Get();
				
				FindControlBlockParams controlBlock = null;
				boolean isInParenthesisOfControlBlock = false; 
				if (curBlock instanceof FindControlBlockParams) {
					controlBlock = (FindControlBlockParams) curBlock;
					if (controlBlock.indexOfLeftParenthesis()<i && i<controlBlock.indexOfRightParenthesis()) {
						isInParenthesisOfControlBlock = true;
					}
				}
				
				if (!isInParenthesisOfControlBlock) {
					// 일반적인 경우 ';'을 만나면 문장안에서 증감문들을 찾는다.
					if (curBlock!=null && curBlock.listOfStatements.count>0) {
						FindStatementParams statement = 
							(FindStatementParams) curBlock.listOfStatements.getItem(curBlock.listOfStatements.count-1);
						if (statement instanceof FindAssignStatementParams ||
								statement instanceof FindIndependentFuncCallParams) {
							compilerStack.findIncrementStatementInStatement(src, statement, coreThreadID);
						}
					}
				}
				else {
					// for 루프의 괄호안에서 ';'을 만나면 문장안에서 증감문들을 찾는다.
					if (controlBlock!=null && controlBlock.listOfStatementsInParenthesis!=null && controlBlock.listOfStatementsInParenthesis.count>0) {
						FindStatementParams statement = 
							(FindStatementParams) controlBlock.listOfStatementsInParenthesis.getItem(controlBlock.listOfStatementsInParenthesis.count-1);
						if (statement instanceof FindAssignStatementParams ||
								statement instanceof FindIndependentFuncCallParams) {
							compilerStack.findIncrementStatementInStatement(src, statement, coreThreadID);
						}
					}
				}
				
				
				// 함수가 인터페이스의 메소드 선언이면 스택에서 pop을 해야 한다.
				if (curBlock instanceof FindFunctionParams) {
					FindFunctionParams func = (FindFunctionParams)curBlock;
					if (func.isAbstractMethod) {
						stack.Pop();
						func.endIndex = IndexForHighArray.indexRelative(func, src, i-1 );
						i++;
						continue;
					}
				}
				
				Block top_if = (Block) stack.Get();
				if (top_if instanceof FindControlBlockParams) {
					FindControlBlockParams shortControl = (FindControlBlockParams)top_if;
					if (shortControl.catOfControls!=null && shortControl.getName().equals("if") &&
							!shortControl.isBlock) {
						// while(true) if (1>2) a=2;
						// else a=3; 
						// 이런 경우 else를 에러로 처리한다.
						// ';'을 만났을때 while까지 스택에서 제거되기때문에 
						// 스택에서 제거하기 전에 else가 있는 경우에 에러로 처리한다.
						FindControlBlockParams topShortControl = null;
						Block topBlock = (Block) stack.Get();
						while (true) {							
							if (topBlock instanceof FindControlBlockParams) {								
								FindControlBlockParams shortControl2 = (FindControlBlockParams)topBlock;
								if (!shortControl2.isBlock) {
									topShortControl = shortControl2;
									topBlock = topShortControl.parent;
								}
								else {
									break;
								}
							}
							else {
								break;
							}
						}
						if (topShortControl.getName().equals("while") || topShortControl.getName().equals("for")) {
							int nextIndexOfSemicolon = CompilerHelper.SkipBlank(compiler.data.mBuffer, false, i+1, compiler.data.mBuffer.count-1);
							CodeString elseStr = compiler.data.mBuffer.getItem(nextIndexOfSemicolon);
							if (elseStr.equals("else")) {
								CompilerStatic.errors.add(new Error(compiler, nextIndexOfSemicolon, nextIndexOfSemicolon, "invalid else"));
							}
						}
					}
				}
				// if (a>1) if (a>2) a=0;
				// 위의 경우와 같은 제어단문에 제어단문이 섞여 있을때 위쪽 제어단문의 endIndex()를
				// 정해주고 스택에서 빼줘야 한다.
				boolean isCase = false;
				while (true) {
					Block topBlock = (Block) stack.Get();
					isCase = false;
					if (topBlock instanceof FindControlBlockParams) {
						FindControlBlockParams shortControl = (FindControlBlockParams)topBlock;
						if (shortControl.catOfControls!=null && shortControl.catOfControls.category==CategoryOfControls.Control_else &&
								!shortControl.isBlock) {
						}
						
						if (shortControl.catOfControls!=null && shortControl.catOfControls.category==CategoryOfControls.Control_case) {
							if (!shortControl.isBlock) {
								isCase = true;
								break;
							}
						}
						if (shortControl.catOfControls!=null && shortControl.catOfControls.category==CategoryOfControls.Control_for) {
							// for ( ; ; )에서 괄호안에 있는 ';' 일 경우
							if (shortControl.indexOfLeftParenthesis()<i && i<shortControl.indexOfRightParenthesis()) {
								break;
							}
						}
						if (!shortControl.isBlock && !isCase) {
							Block block = (Block) stack.Pop();
							if (block!=null) {
								block.endIndex = IndexForHighArray.indexRelative(block, src, i);
							}
							//i++;
							continue;
						}
						else { // 제어블록
							break; 
						}
					}
					else { // 함수 등
						break;
					}
				}// while
				i++;
				continue;
			}
			
			else if (str.equals("}")) {
					//Block block = stack.Pop();
				// char[] a = {'a','b}; 이와 같은 배열을 처리할 수 없기 때문에 Block인지를 확인하여
				// Block이 아니면 skip하고 Block일때만 pop한다.
					Block block = (Block) stack.Get();
										
					boolean isEnum = false;
					if (block instanceof FindClassParams) {
						FindClassParams c = (FindClassParams) block;
						if (c.isEnum) isEnum = true;
					}
					
					if (block==null || (!(block instanceof FindArrayInitializerParams) && !isEnum)) {
						// 현재 배열초기화가 아니라 다른 배열초기화에서 왼쪽 괄호가 없을 경우 클래스나 함수 제어구조에 오른쪽 괄호가 잘못 연결이 된다.
						int indexSemicolon = CompilerHelper.SkipBlank(src, false, i+1, src.count-1);
						if (indexSemicolon!=src.count && src.getItem(indexSemicolon).equals(";")) {
							if (block!=null) {
								CompilerStatic.errors.add(new Error(compiler, i, i, 
										"invalid the end of block"));
								compiler.PairErrorExists = true;
							}
							else {
								CompilerStatic.errors.add(new Error(compiler, i, i, "invalid the end of block"));
								compiler.PairErrorExists = true;
							}
							return;
						}
					}
					if (block instanceof FindControlBlockParams) {
						FindControlBlockParams b = (FindControlBlockParams) block;
						if (b.catOfControls!=null && b.catOfControls.category==CategoryOfControls.Control_case) {
						}
					}
					if (block instanceof FindClassParams) {
						if (block.findBlockParams!=null && block.findBlockParams.blockName.equals("Edit")) {
						}
						if (block.findBlockParams!=null && block.findBlockParams.blockName.equals("DocuComment")) {
						}
					}
					
				
					
					// switch() {
					// case 0: a=1;
					// case 1: a=2;
					// }
					boolean isCaseAndSwitchEnds = false;
					if (block instanceof FindControlBlockParams) {
						FindControlBlockParams b = (FindControlBlockParams) block;
						if (b.catOfControls!=null && b.catOfControls.category==CategoryOfControls.Control_case) {
							if (!b.isBlock) { // 괄호없는 case문을 만나면
								isCaseAndSwitchEnds = true;
								Block lastCaseBlock = (Block) stack.Pop(); // case문을 pop
								this.setEndIndexOfBlockAndEndIndexOfScopeOfVarInBlock(src, lastCaseBlock, i);
								
								block = (Block) stack.Pop(); // switch문을 pop				
							}
						}
					}
					
					if (!isCaseAndSwitchEnds) {						
						if (block instanceof Block) {
							// block이 배열초기화문이면 스택에서 block을 빼내고 continue.
							// 배열초기화문은 원래 블록이 아니므로.
							if (block instanceof FindArrayInitializerParams) {						
								block = (Block) stack.Pop();
								i++;
								continue;
							}
							else {
								block = (Block) stack.Pop();
							}
						}
						else { // '}'이 블록이 아니면 continue.
							i++;
							continue;
						}
					}
					
					// block의 endIndex()와 block에서 정의된 변수들의 마지막 scope를 정해준다.
					if (block!=null) {
						setEndIndexOfBlockAndEndIndexOfScopeOfVarInBlock(src, block, i);
					}
					
					if (block!=null && block.findBlockParams!=null) {
						/*FindControlBlockParams controlBlock=null;
						if (block instanceof FindControlBlockParams) {							
							controlBlock = (FindControlBlockParams)block;
						}
						// do_while루프일때는 이미 checkControlBody()에서 정했다.
						if ((block instanceof FindControlBlockParams)==false || 
								controlBlock.catOfControls==null  || // try, catch, finally, synchronized 블록
								(controlBlock.catOfControls!=null && controlBlock.catOfControls.category!=CategoryOfControls.Control_dowhile)) {
							block.findBlockParams.endIndex = IndexForHighArray.indexRelative(block.findBlockParams, src, i);
							block.endIndex = IndexForHighArray.indexRelative(block, src, i );
						}
						int k;
						for (k=0; k<block.listOfVariableParams.count; k++) {
							FindVarParams var = (FindVarParams) block.listOfVariableParams.getItem(k);
							if (var.endIndexOfScope()==-1) {
								var.endIndexOfScope = IndexForHighArray.indexRelative(var, src, block.endIndex()-1);
							}
						}*/
						
						
						// if (a>0) while(a==0) {
						//			int a;
						//			a=0;
						//			} 
						// 위의 경우와 같은 제어단문에 제어복문이 섞여 있을때 제어단문의 endIndex()를
						// 정해주고 스택에서 빼줘야 한다.
						// if 						while
						// 	 if {} 						try{}
						//   else if {} 				catch{}
						//   else {}					finally{}
						
						
						//if (a>0) while(a==0) {
						//	int a;
						//	a=0;
						//}
						while (true) {
							Block topBlock = (Block) stack.Get();
							if (topBlock instanceof FindControlBlockParams) {
								FindControlBlockParams shortControl = (FindControlBlockParams)topBlock;
								if (!shortControl.isBlock) { // 제어단문
									// 현재블록이 if, else if등 또는 try, catch등이고 
									// 상위블록이 제어단문일경우 스택에서 빼면 안된다.
									//while (a>1) 
									//	if (a>2) {} else if (a==1) {} else {}
									// 이와 같은 경우 while을 빼면 안된다.
									if (block  instanceof FindControlBlockParams) {
										FindControlBlockParams danglingBlock = (FindControlBlockParams) block;
										if ((danglingBlock.catOfControls!=null && danglingBlock.catOfControls.category==CategoryOfControls.Control_if) ||
											(danglingBlock.catOfControls!=null && danglingBlock.catOfControls.category==CategoryOfControls.Control_elseif)) {
											int nextIndex = CompilerHelper.SkipBlank(src, false, i+1, src.count-1);
											CodeString next = src.getItem(nextIndex);
											if (next.equals("else")) {
												break;
											}
										}
									}
									if (shortControl.catOfControls!=null && shortControl.catOfControls.category==CategoryOfControls.Control_case) {
										//  case 3: //int
										//	int value = Number.parseInt(varUseName);
										//	if (listOfConstantTableHashed.getData(value+"")!=null) {
										//		return;
										//	}
										//  case 4:

										break;
									}
									if (block  instanceof FindSpecialBlockParams) {
										FindSpecialBlockParams danglingBlock = (FindSpecialBlockParams) block;
										if (danglingBlock.toString().equals("try") || 
												danglingBlock.toString().equals("catch")) {
											int nextIndex = CompilerHelper.SkipBlank(src, false, i+1, src.count-1);
											CodeString next = src.getItem(nextIndex);
											if (next.equals("catch") || next.equals("finally")) {
												break;
											}
										}
									}
									// 제어단문을 스택에서 빼낸다.
									Block sblock = (Block) stack.Pop();
									if (sblock!=null) {
										sblock.endIndex = IndexForHighArray.indexRelative(sblock, src, i );
									}
									//i++;
									continue;
								}//if (shortControl.isBlock==false) { // 제어단문
								else { // 제어블록
									break; 
								}
							}//if (topBlock instanceof FindControlBlockParams) {
							else { // 함수 등
								break;
							}
						}//while (true) {
					}
					else {
						CompilerStatic.errors.add(new Error(compiler, i,i,"invalid '}'"));
					}
			//	}
				i++;
				continue;
			}
			else {
				i++;
			}
			}catch(Exception e) {
				if (Common_Settings.g_printsLog) e.printStackTrace();
				if (Common_Settings.g_printsLog) CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
				
			}
		}//for (i=0; i<src.count; ) {
		
		Checker.checkParenthesis(compiler);
	}
	
	
	/**@param i : "}"을 만나서 호출할 경우에는 "}"의 인덱스, 
	 * case, default를 만났을 경우에는 case, default의 인덱스을 하여 호출한다.*/ 
	void setEndIndexOfBlockAndEndIndexOfScopeOfVarInBlock(HighArray_CodeString src, Block block, int i) {
		FindControlBlockParams controlBlock=null;
		if (block instanceof FindControlBlockParams) {							
			controlBlock = (FindControlBlockParams)block;
		}
		
		String controlName = null;
		if (controlBlock!=null) {
			controlName = controlBlock.getName();
		}
		
		// do_while루프일때는 이미 checkControlBody()에서 정했다.
		if (!(block instanceof FindControlBlockParams) || 
				controlBlock.catOfControls==null  || // try, catch, finally, synchronized 블록
				(controlBlock.catOfControls!=null && controlBlock.catOfControls.category!=CategoryOfControls.Control_dowhile)) 
		{
			if (!(controlName!=null && (controlName.equals("case") || controlName.equals("default")))) {
				if (block.findBlockParams!=null) {
					block.findBlockParams.endIndex = IndexForHighArray.indexRelative(block.findBlockParams, src, i);
				}
				block.endIndex = IndexForHighArray.indexRelative(block, src, i );
			}
			else {
				if (block.findBlockParams!=null) {
					block.findBlockParams.endIndex = IndexForHighArray.indexRelative(block.findBlockParams, src, i-1);
				}
				block.endIndex = IndexForHighArray.indexRelative(block, src, i-1 );
			}
		}
		
		
		int k;
		for (k=0; k<block.listOfVariableParams.count; k++) {
			FindVarParams var = (FindVarParams) block.listOfVariableParams.getItem(k);
			if (var.endIndexOfScope()==-1) {
				var.endIndexOfScope = IndexForHighArray.indexRelative(var, src, i-1);
			}
		}
		/*else {
			// switch일 경우
			int j;
			for (j=0; j<controlBlock.listOfControlBlocks.count; j++) {
				FindControlBlockParams caseOrDefault = (FindControlBlockParams) controlBlock.listOfControlBlocks.getItem(j);				
				int k;
				for (k=0; k<caseOrDefault.listOfVariableParams.count; k++) {
					FindVarParams var = (FindVarParams) caseOrDefault.listOfVariableParams.getItem(k);
					if (var.endIndexOfScope()==-1) {
						var.endIndexOfScope = IndexForHighArray.indexRelative(var, src, i-1);
					}
				}
			}
		}*/
	}
	
	
	
	
	
	/** startIndex : 접근지정자(static, public등) 
	 *  endIndex : block의 끝, 즉 '}' 
	 * @param coreThreadID */
	public void FindClass(HighArray_CodeString src,  
			FindClassParams findClassParams, int startIndex, int endIndex, boolean isEnum, int coreThreadID)
	{
		if (isEnum) {
			FindEnum(src, findClassParams, startIndex, endIndex, coreThreadID);
			findClassParams.isEnum = true;
			return;
		}
        int i;
        for (i = startIndex; i <= endIndex; )
        {        	
        	findClassParams.classIndex = IndexForHighArray.indexRelative(findClassParams, src, 
        			CompilerHelper.Find(src, "class", i, endIndex));

            if (findClassParams.classIndex() == -1) {
            	CompilerStatic.errors.add(new Error(compiler, endIndex, endIndex, "class keyword not exists"));
            	return;
            }

            // 공백 스킵                
            i = CompilerHelper.SkipBlank(src, false, findClassParams.classIndex() + 1, endIndex);
            if (i==endIndex+1) break;
            
            CodeString str = src.getItem(i);

            int indexOfExtendsOrImplementsOrCommaOrLeftPair = -1;
            
            // 클래스 이름 찾기
            if (CompilerHelper.IsIdentifier(str, compiler)  && !CompilerHelper.IsComment(str))   // 식별자 이면
            {            	
                findClassParams.classNameIndex = IndexForHighArray.indexRelative(findClassParams, src, i);

                // 공백 스킵
                i = CompilerHelper.SkipBlank(src, false, i + 1, endIndex);
                if (i==endIndex+1) break;
                
                int indexOfNextOfClassName = i;
                
                Template t = null;
                int leftPairIndex = i;
				// class Stack <T> {} 에서 템플릿을 등록(FindClassParams.template이 정해진다)하고 올바른 endIndexNew을 정한다.
				if (src.getItem(leftPairIndex).equals("<")) {
					int rightPairIndex = Checker.CheckParenthesis(compiler,  "<", ">", leftPairIndex, src.count-1, false);
					if (rightPairIndex!=-1) {
						t = TemplateBase.isTemplate(compiler, rightPairIndex);
						if (t!=null) {
							String typeNameToChange = Fullname.getFullName(src, leftPairIndex+1, rightPairIndex-1).str;
							t.typeNameToChange = typeNameToChange;
							findClassParams.template = t;
							data.mlistOfAllTemplates.add(t);
							indexOfNextOfClassName = CompilerHelper.SkipBlank(src, false, rightPairIndex+1, src.count-1);
						}
					}
				}//if (src.getItem(leftPairIndex).equals("<")) {
				                
               
                CodeString nextOfClassName = src.getItem(indexOfNextOfClassName);
                
                indexOfExtendsOrImplementsOrCommaOrLeftPair = indexOfNextOfClassName;
                
                
                
                if (str.equals("HScrollBar")) {
                }
                
                int indexOfExtendsOrImplementsOrCommaOrLeftPairOld;
                if (nextOfClassName.equals("extends") || nextOfClassName.equals("implements")) {
                	if (nextOfClassName.equals("extends")) {
                		findClassParams.indexOfExtends = IndexForHighArray.indexRelative(findClassParams, src, indexOfNextOfClassName);
                		indexOfExtendsOrImplementsOrCommaOrLeftPair = CompilerHelper.SkipBlank(src, false, indexOfNextOfClassName + 1, endIndex);
                        if (indexOfExtendsOrImplementsOrCommaOrLeftPair==endIndex+1) break;
                       
                        indexOfExtendsOrImplementsOrCommaOrLeftPairOld = indexOfExtendsOrImplementsOrCommaOrLeftPair;
                        int indexOfExtendsOrImplementsOrCommaOrLeftPairMinus1 = Fullname.getFullNameIndex(compiler,  false, indexOfExtendsOrImplementsOrCommaOrLeftPairOld, true);
                        indexOfExtendsOrImplementsOrCommaOrLeftPair = CompilerHelper.SkipBlank(src, false, indexOfExtendsOrImplementsOrCommaOrLeftPairMinus1+1, src.count-1);
                       
                        if (indexOfExtendsOrImplementsOrCommaOrLeftPairOld <= 
                        		indexOfExtendsOrImplementsOrCommaOrLeftPairMinus1) {
                        	try{
                        		// 같은 파일에 정의된 클래스를 상속하는 경우 fullname이 틀릴수 있다.
                        	findClassParams.classNameToExtend = 
                        			Fullname.getFullNameType(compiler, indexOfExtendsOrImplementsOrCommaOrLeftPairOld, indexOfExtendsOrImplementsOrCommaOrLeftPairMinus1, coreThreadID);
                        	}catch(Exception e) {
                        	}
                        	// 상속 클래스의 시작과 끝 인덱스
                        	findClassParams.startIndexOfClassNameToExtend = IndexForHighArray.indexRelative(findClassParams, src, indexOfExtendsOrImplementsOrCommaOrLeftPairOld);
                        	findClassParams.endIndexOfClassNameToExtend = IndexForHighArray.indexRelative(findClassParams, src, indexOfExtendsOrImplementsOrCommaOrLeftPairMinus1);
                        	//템플릿이면 찾아서 등록한다.
                        	Template template = compilerStack.IsType(src, true, findClassParams.endIndexOfClassNameToExtend()).template;
                        	if (template!=null && template.found) {
                        		data.mlistOfAllTemplates.add(template);
                        		findClassParams.templateForExtending = template;
                        	}
                        	CodeString codeStr = src.getItem(indexOfExtendsOrImplementsOrCommaOrLeftPair);
                        	
                        	indexOfNextOfClassName = indexOfExtendsOrImplementsOrCommaOrLeftPair;
                        	
                        	if (codeStr.equals("{")) {
                        		nextOfClassName = codeStr;
                        		//i = indexOfExtendsOrImplementsOrCommaOrLeftPair;
                        	}
                        	else if (codeStr.equals("implements")) {
                        		findClassParams.indexOfImplements = IndexForHighArray.indexRelative(findClassParams, src, indexOfExtendsOrImplementsOrCommaOrLeftPair);
                        		nextOfClassName = new CodeString("implements", Common_Settings.textColor);
                        		
                        		//indexOfExtendsOrImplementsOrCommaOrLeftPair++;
                       
                        	}                        	
                        	else { // '{'이 없을 때
                        		//indexOfExtendsOrImplementsOrCommaOrLeftPair = indexOfNextOfClassName;
                        		CompilerStatic.errors.add(new Error(compiler, indexOfExtendsOrImplementsOrCommaOrLeftPair, 
                        				indexOfExtendsOrImplementsOrCommaOrLeftPair, "invalid extends"));
                        	}
                        	
                        }
                         
                	} // if (nextOfClassName.equals("extends")) {
                	
                	if (nextOfClassName.equals("implements")) {
                		findClassParams.indexOfImplements = IndexForHighArray.indexRelative(findClassParams, src, indexOfNextOfClassName);
                		
                		int indexOfExtendsOrImplementsOrCommaOrLeftPairMinus1;
                		if (findClassParams.classNameToExtend==null) {
                			indexOfExtendsOrImplementsOrCommaOrLeftPair = indexOfNextOfClassName;
                		}
                		if (indexOfNextOfClassName==1919) {
                		}
                		while (true) {
                			indexOfExtendsOrImplementsOrCommaOrLeftPair = CompilerHelper.SkipBlank(src, false, indexOfExtendsOrImplementsOrCommaOrLeftPair+1, endIndex);
	                        if (indexOfExtendsOrImplementsOrCommaOrLeftPair==endIndex+1) break;
	                        
	                        indexOfExtendsOrImplementsOrCommaOrLeftPairOld = indexOfExtendsOrImplementsOrCommaOrLeftPair;
	                        indexOfExtendsOrImplementsOrCommaOrLeftPairMinus1 = 
	                        		Fullname.getFullNameIndex_OnlyType(compiler,  false, indexOfExtendsOrImplementsOrCommaOrLeftPair, true);
	                        indexOfExtendsOrImplementsOrCommaOrLeftPair = CompilerHelper.SkipBlank(src, false, indexOfExtendsOrImplementsOrCommaOrLeftPairMinus1+1, src.count-1);
	                        
	                        if (indexOfExtendsOrImplementsOrCommaOrLeftPairOld <= 
	                        		indexOfExtendsOrImplementsOrCommaOrLeftPairMinus1) {
	                        	if (findClassParams.interfaceNamesToImplement==null) {
	                        		findClassParams.interfaceNamesToImplement = new ArrayListString(5);
	                        	}
	                        	// 같은 파일에 정의된 클래스를 구현하는 경우 fullname이 틀릴수 있다.
	                        	String fullname = 
	                        			Fullname.getFullNameType(compiler, indexOfExtendsOrImplementsOrCommaOrLeftPairOld, indexOfExtendsOrImplementsOrCommaOrLeftPairMinus1, coreThreadID); 
	                        	findClassParams.interfaceNamesToImplement.add(fullname);
	                        	// 구현인터페이스들의 시작과 끝 인덱스
	                        	if (findClassParams.listOfStartIndexOfInterfaceNamesToImplement==null) {
	                        		findClassParams.listOfStartIndexOfInterfaceNamesToImplement = new ArrayList(2);
	                        		findClassParams.listOfEndIndexOfInterfaceNamesToImplement = new ArrayList(2);
	                        	}
	                        	IndexForHighArray startIndexOfInteface = IndexForHighArray.indexRelative(findClassParams, src, indexOfExtendsOrImplementsOrCommaOrLeftPairOld);
	                        	IndexForHighArray endIndexOfInteface = IndexForHighArray.indexRelative(findClassParams, src, indexOfExtendsOrImplementsOrCommaOrLeftPairMinus1);
	                        	findClassParams.listOfStartIndexOfInterfaceNamesToImplement.add(startIndexOfInteface);
	                        	findClassParams.listOfEndIndexOfInterfaceNamesToImplement.add(endIndexOfInteface);
	                        	//템플릿이면 찾아서 등록한다.
	                        	//Template template = new Template(compiler); 
	                        	Template template = compilerStack.IsType(src, true, indexOfExtendsOrImplementsOrCommaOrLeftPairMinus1).template;
	                        	if (findClassParams.listOfTemplatesForImplementing==null) {
	                        		findClassParams.listOfTemplatesForImplementing = new ArrayListIReset(2);
	                        	}
	                        	if (template!=null && template.found) {
	                        		data.mlistOfAllTemplates.add(template);
	                        		findClassParams.listOfTemplatesForImplementing.add(template);
	                        	}
	                        	CodeString codeStr = src.getItem(indexOfExtendsOrImplementsOrCommaOrLeftPair);
	                        	if (codeStr.equals("{")) {
	                        		//i = indexOfExtendsOrImplementsOrCommaOrLeftPair;
	                        		break;
	                        	}
	                        	else if (codeStr.equals(",")) {
	                        		//indexOfExtendsOrImplementsOrCommaOrLeftPair++;
	                        	}
	                        	else {
	                        		CompilerStatic.errors.add(new Error(compiler, indexOfExtendsOrImplementsOrCommaOrLeftPair, 
	                        				indexOfExtendsOrImplementsOrCommaOrLeftPair, "invalid implements"));
	                        		break;
	                        	}
	                        }
	                        else { // '{'이 없을 때
                            	//i = indexOfNextOfClassName;
	                        	break;
	                        }
                		}//while (true) {
                		
                	}//if (nextOfClassName.equals("implements")) {
                	else if (nextOfClassName.equals("{")) { // extends ClassName { 에서 {
                		
                	}
                	else {// extends ClassName 에서 { 이 없는 경우
                		CompilerStatic.errors.add(new Error(compiler, i,i, "invalid class"));
                	}
                } // if (nextOfClassName.equals("extends") || nextOfClassName.equals("implements")) {
                else {
                	indexOfExtendsOrImplementsOrCommaOrLeftPair = CompilerHelper.SkipBlank(src, false, indexOfNextOfClassName, endIndex);
                }
                i = indexOfExtendsOrImplementsOrCommaOrLeftPair;
                indexOfNextOfClassName = indexOfExtendsOrImplementsOrCommaOrLeftPair;

                int startParenthesis = -1;
                int endParenthesis = -1;
                FindBlockParams findBlockParams = new FindBlockParams(compiler, startParenthesis, endParenthesis);
                     
                CodeString nextOfClassName2 = src.getItem(indexOfNextOfClassName); 
                
                if (!nextOfClassName2.equals("{")) {
                	//startParenthesis = Skip(src, false, "{", indexOfNextOfClassName, endIndex);
                	CompilerStatic.errors.add(new Error(compiler, indexOfNextOfClassName, indexOfNextOfClassName, 
                			"invalid class"));
                	compiler.PairErrorExists = true;
                }
                else {
                	startParenthesis = indexOfNextOfClassName;
                }
                if (startParenthesis==endIndex+1) {
                	CompilerStatic.errors.add(new Error(compiler, endIndex, endIndex, "invalid class."));
                	//return;
                }
                findBlockParams.startIndex = IndexForHighArray.indexRelative(findBlockParams, src, startParenthesis);
                findBlockParams.blockName = src.getItem(findClassParams.classNameIndex()).str;
                ReturnOfFindAccessModifier r = compilerStack.FindAccessModifier(src, 0, findClassParams.classIndex() - 1, findClassParams.accessModifier);
                int k = r.r;
                
                int docuIndex;
            	if (findClassParams.accessModifier.found) docuIndex = k-1;
            	else {
            		docuIndex = findClassParams.classIndex()-1;
            	}
            	int indexOfDocuEnd = CompilerHelper.SkipOnlyBlank(src, true, 0, docuIndex); // 공백 스킵            	
            	DocuComment docu = 
            			compilerStack.FindDocuComment(src, /*true, findFunctionParams, null,*/ 0, indexOfDocuEnd);
            	findClassParams.docuComment = docu;
            	
            	
            	//findClassParams.startIndex = IndexForHighArray.indexRelative(findClassParams, src, k);
            	findClassParams.startIndex = IndexForHighArray.indexRelative(findClassParams, src, 
            			CompilerStatic.getIndexWhickRemoveLeftBlankAndCommentAndAnnotation(src, r));
                findClassParams.endIndex = findBlockParams.endIndex;
                findClassParams.found = true;
                findClassParams.findBlockParams = findBlockParams;
                findClassParams.findBlockParams.blockName = src.getItem(findClassParams.classNameIndex()).str;
                
                if (findClassParams.classNameToExtend==null) {
                	findClassParams.classNameToExtend = "java.lang.Object";
                }
                
                findBlockParams.categoryOfBlock = new CategoryOfBlock(CategoryOfBlock.Class, null);
                findBlockParams.parent = findClassParams;
                data.mlistOfBlocks.add(findBlockParams);
                
                return;

            }
            else
            {
            	CompilerStatic.errors.add(new Error(compiler, i, i, "Identifier not exists behind class keyword."));
            }
        }   // for

      
    }
	
	/** startIndex : 접근지정자(static, public등) 
	 * @param coreThreadID 
	 *   */
	public void FindInterface(HighArray_CodeString src,  
			FindClassParams findInterfaceParams, int startIndex, int endIndex, int coreThreadID)
	{
        int i;
        for (i = startIndex; i <= endIndex; )
        {        	
        	findInterfaceParams.classIndex = IndexForHighArray.indexRelative(findInterfaceParams, src, 
        			CompilerHelper.Find(src, "interface", i, endIndex));

            if (findInterfaceParams.classIndex() == -1) {
            	CompilerStatic.errors.add(new Error(compiler, endIndex, endIndex, "interface keyword not exists"));
            	return;
            }
            
            findInterfaceParams.isInterface = true;

            // 공백 스킵                
            i = CompilerHelper.SkipBlank(src, false, findInterfaceParams.classIndex() + 1, endIndex);
            if (i==endIndex+1) break;
            
            CodeString str = src.getItem(i);

            int indexOfExtendsOrImplementsOrCommaOrLeftPair = -1;
            
            // 클래스 이름 찾기
            if (CompilerHelper.IsIdentifier(str, compiler)  && !CompilerHelper.IsComment(str))   // 식별자 이면
            {            	
                findInterfaceParams.classNameIndex = IndexForHighArray.indexRelative(findInterfaceParams, src, i);

                // 공백 스킵
                i = CompilerHelper.SkipBlank(src, false, i + 1, endIndex);
                if (i==endIndex+1) break;
                
                Template t = null;
                int leftPairIndex = i;
				// class OnListener <T> {} 에서 템플릿을 등록하고 올바른 endIndexNew을 정한다.
				if (src.getItem(leftPairIndex).equals("<")) {
					int rightPairIndex = Checker.CheckParenthesis(compiler, "<", ">", leftPairIndex, src.count-1, false);
					if (rightPairIndex!=-1) {
						t = TemplateBase.isTemplate(compiler, rightPairIndex);
						if (t!=null) {
							String typeNameToChange = Fullname.getFullName(data.mBuffer, leftPairIndex+1, rightPairIndex-1).str;
							t.typeNameToChange = typeNameToChange;
							findInterfaceParams.template = t;
							data.mlistOfAllTemplates.add(t);
						}
					}
				}
				
                
                int indexOfNextOfClassName = i;
                CodeString nextOfClassName = src.getItem(indexOfNextOfClassName);
                
                if (str.equals("HScrollBar")) {
                }
                
                indexOfExtendsOrImplementsOrCommaOrLeftPair = i;
                
                int indexOfExtendsOrImplementsOrCommaOrLeftPairOld;
                if (nextOfClassName.equals("extends")) { 
                	findInterfaceParams.indexOfExtends = IndexForHighArray.indexRelative(findInterfaceParams, src, indexOfNextOfClassName);
            		int indexOfExtendsOrImplementsOrCommaOrLeftPairMinus1;
            		indexOfExtendsOrImplementsOrCommaOrLeftPair = indexOfNextOfClassName;
            		while (true) {
            			indexOfExtendsOrImplementsOrCommaOrLeftPair = CompilerHelper.SkipBlank(src, false, indexOfExtendsOrImplementsOrCommaOrLeftPair+1, endIndex);
                        if (indexOfExtendsOrImplementsOrCommaOrLeftPair==endIndex+1) break;
                        indexOfExtendsOrImplementsOrCommaOrLeftPairOld = indexOfExtendsOrImplementsOrCommaOrLeftPair;
                        indexOfExtendsOrImplementsOrCommaOrLeftPairMinus1 = 
                        		Fullname.getFullNameIndex_OnlyType(compiler,  false, indexOfExtendsOrImplementsOrCommaOrLeftPairOld, true);
                        //indexOfExtendsOrImplementsOrCommaOrLeftPair = indexOfExtendsOrImplementsOrCommaOrLeftPairMinus1+1;
                        indexOfExtendsOrImplementsOrCommaOrLeftPair = CompilerHelper.SkipBlank(src, false, indexOfExtendsOrImplementsOrCommaOrLeftPairMinus1+1, src.count-1);
                        
                        if (indexOfExtendsOrImplementsOrCommaOrLeftPairOld <=
                        		indexOfExtendsOrImplementsOrCommaOrLeftPairMinus1) {
                        	if (findInterfaceParams.interfaceNamesToImplement==null) {
                        		findInterfaceParams.interfaceNamesToImplement = new ArrayListString(5);
                        	}
                        	// 같은 파일에 정의된 클래스를 구현하는 경우 fullname이 틀릴수 있다.
                        	String fullname = Fullname.getFullNameType(compiler, indexOfExtendsOrImplementsOrCommaOrLeftPairOld, 
                        			indexOfExtendsOrImplementsOrCommaOrLeftPairMinus1, coreThreadID); 
                        	findInterfaceParams.interfaceNamesToImplement.add(fullname);
                        	// 구현인터페이스들의 시작과 끝 인덱스
                        	if (findInterfaceParams.listOfStartIndexOfInterfaceNamesToImplement==null) {
                        		findInterfaceParams.listOfStartIndexOfInterfaceNamesToImplement = new ArrayList(2);
                        		findInterfaceParams.listOfEndIndexOfInterfaceNamesToImplement = new ArrayList(2);
                        	}
                        	IndexForHighArray startIndexOfInteface = IndexForHighArray.indexRelative(findInterfaceParams, src, indexOfExtendsOrImplementsOrCommaOrLeftPairOld);
                        	IndexForHighArray endIndexOfInteface = IndexForHighArray.indexRelative(findInterfaceParams, src, indexOfExtendsOrImplementsOrCommaOrLeftPairMinus1);
                        	findInterfaceParams.listOfStartIndexOfInterfaceNamesToImplement.add(startIndexOfInteface);
                        	findInterfaceParams.listOfEndIndexOfInterfaceNamesToImplement.add(endIndexOfInteface);
                        	//템플릿이면 찾아서 등록한다.
                        	//Template template = new Template(compiler); 
                        	Template template = compilerStack.IsType(src, true, indexOfExtendsOrImplementsOrCommaOrLeftPairMinus1).template;
                        	if (findInterfaceParams.listOfTemplatesForImplementing==null) {
                        		findInterfaceParams.listOfTemplatesForImplementing = new ArrayListIReset(2);
                        	}
                        	if (template!=null && template.found) {
                        		data.mlistOfAllTemplates.add(template);
                        		findInterfaceParams.listOfTemplatesForImplementing.add(template);
                        	}
                        	
                        	CodeString codeStr = src.getItem(indexOfExtendsOrImplementsOrCommaOrLeftPair);
                        	indexOfNextOfClassName = indexOfExtendsOrImplementsOrCommaOrLeftPair;
                        	if (codeStr.equals("{")) {
                        		//i = indexOfImplementsOrImplementsOrCommaOrLeftPair;
                        		break;
                        	}
                        	else if (codeStr.equals(",")) {
                        		//indexOfExtendsOrImplementsOrCommaOrLeftPair++;
                        	}
                        	else {
                        		CompilerStatic.errors.add(new Error(compiler, indexOfNextOfClassName, indexOfNextOfClassName, "invalid extends"));
                        		break;
                        		
                        	}
                        }
                        else { // '{'이 없을 때
                        	//i = indexOfNextOfClassName;
                        	break;
                        }
            		}//while (true) {
            		
            	}//if (nextOfClassName.equals("extends")) {  
            	else if (nextOfClassName.equals("{")) {
            		
            	}
            	else {
            		CompilerStatic.errors.add(new Error(compiler, i,i,"invalid interface"));
            	}
                
                
              
                i = indexOfExtendsOrImplementsOrCommaOrLeftPair;

                int startParenthesis = -1;
                int endParenthesis = -1;
                FindBlockParams findBlockParams = new FindBlockParams(compiler, startParenthesis, endParenthesis);
                                
                
                if (!src.getItem(indexOfNextOfClassName).equals("{")) {
                	CompilerStatic.errors.add(new Error(compiler, indexOfNextOfClassName, indexOfNextOfClassName, "invalid interface"));
                	compiler.PairErrorExists = true;
                }
                else {
                	startParenthesis = indexOfNextOfClassName;
                }
                if (startParenthesis==endIndex+1) {
                	CompilerStatic.errors.add(new Error(compiler, endIndex, endIndex, "invalid interface."));
                }
                findBlockParams.startIndex = IndexForHighArray.indexRelative(findBlockParams, src, startParenthesis);
                findBlockParams.blockName = src.getItem(findInterfaceParams.classNameIndex()).str;
                ReturnOfFindAccessModifier r = compilerStack.FindAccessModifier(src, 0, findInterfaceParams.classNameIndex() - 1, findInterfaceParams.accessModifier);
                 
                int k = r.r;
                
                int docuIndex;
            	if (findInterfaceParams.accessModifier.found) docuIndex = k-1;
            	else {
            		docuIndex = findInterfaceParams.classIndex()-1;
            	}
            	int indexOfDocuEnd = CompilerHelper.SkipOnlyBlank(src, true, 0, docuIndex); // 공백 스킵            	
            	DocuComment docu = 
            			compilerStack.FindDocuComment(src, /*true, findFunctionParams, null,*/ 0, indexOfDocuEnd);
            	findInterfaceParams.docuComment = docu;
            	
            	
            	findInterfaceParams.startIndex = IndexForHighArray.indexRelative(findInterfaceParams, src, k);
            	findInterfaceParams.startIndex = IndexForHighArray.indexRelative(findInterfaceParams, src, 
            			CompilerStatic.getIndexWhickRemoveLeftBlankAndCommentAndAnnotation(src, r));
                //findInterfaceParams.endIndex = findBlockParams.endIndex;
                findInterfaceParams.found = true;
                findInterfaceParams.findBlockParams = findBlockParams;
                findInterfaceParams.findBlockParams.blockName = src.getItem(findInterfaceParams.classNameIndex()).str;
                
               
                findBlockParams.categoryOfBlock = new CategoryOfBlock(CategoryOfBlock.Interface, null);
                findBlockParams.parent = findInterfaceParams;
                data.mlistOfBlocks.add(findBlockParams);
                
                return;

            }
            else
            {
            	CompilerStatic.errors.add(new Error(compiler, i, i, "Identifier not exists behind class keyword."));
            }
        }   // for

      
    }
	
	/** startIndex : 접근지정자(static, public등) 
	 *  endIndex : block의 끝, 즉 '}' 
	 * @param coreThreadID */
	public void FindEnum(HighArray_CodeString src,  
			FindClassParams findEnumParams, int startIndex, int endIndex, int coreThreadID)
	{
        int i;
        for (i = startIndex; i <= endIndex; )
        {        	
        	findEnumParams.classIndex = IndexForHighArray.indexRelative(findEnumParams, src, 
        			CompilerHelper.Find(src, "enum", i, endIndex));

            if (findEnumParams.classIndex() == -1) {
            	CompilerStatic.errors.add(new Error(compiler, endIndex, endIndex, "enum keyword not exists"));
            	return;
            }

            // 공백 스킵                
            i = CompilerHelper.SkipBlank(src, false, findEnumParams.classIndex() + 1, endIndex);
            if (i==endIndex+1) break;
            
            CodeString str = src.getItem(i);
            
            
            // 클래스 이름 찾기
            if (CompilerHelper.IsIdentifier(str, compiler)  && !CompilerHelper.IsComment(str))   // 식별자 이면
            {            	
                findEnumParams.classNameIndex = IndexForHighArray.indexRelative(findEnumParams, src, i);

                // 공백 스킵
                i = CompilerHelper.SkipBlank(src, false, i + 1, endIndex);
                if (i==endIndex+1) break;

                               
                int indexOfNextOfEnumName = i;
                src.getItem(indexOfNextOfEnumName);
                
                if (str.equals("HScrollBar")) {
                }
                
               
             
                int startParenthesis = -1;
                int endParenthesis = -1;
                FindBlockParams findBlockParams = new FindBlockParams(compiler, startParenthesis, endParenthesis);
                                
                
                if (!src.getItem(indexOfNextOfEnumName).equals("{")) {
                	CompilerStatic.errors.add(new Error(compiler, endIndex, endIndex, "invalid enum."));
                }
                else {
                	startParenthesis = indexOfNextOfEnumName;
                }
                findBlockParams.startIndex = IndexForHighArray.indexRelative(findBlockParams, src, startParenthesis);
                
                //AccessModifier r = FindAccessModifier(src, 0, findEnumParams.classIndex() - 1, 
                //		findEnumParams.accessModifier);
                ReturnOfFindAccessModifier r = compilerStack.FindAccessModifier(src, 0, findEnumParams.classNameIndex() - 1, findEnumParams.accessModifier);
                int k = r.r;
                
                int docuIndex;
                if (findEnumParams.accessModifier.found) docuIndex = k-1;
            	else {
            		docuIndex = findEnumParams.classIndex()-1;
            	}
            	//int indexOfDocuEnd = SkipOnlyBlank(src, true, 0, docuIndex); // 공백 스킵 
            	int indexOfDocuEnd = CompilerHelper.SkipOnlyBlankAndAnnotationAndRegularComment(data.mBuffer, true, 0, docuIndex); // 공백 스킵
            	DocuComment docu = 
            			compilerStack.FindDocuComment(src, /*true, findFunctionParams, null,*/ 0, indexOfDocuEnd);
            	findEnumParams.docuComment = docu;
            	
            	
            	findEnumParams.startIndex = IndexForHighArray.indexRelative(findEnumParams, src, k);
            	findEnumParams.startIndex = IndexForHighArray.indexRelative(findEnumParams, src, 
            			CompilerStatic.getIndexWhickRemoveLeftBlankAndCommentAndAnnotation(src, r));
                //findEnumParams.endIndex = findBlockParams.endIndex();
                findEnumParams.found = true;
                findEnumParams.findBlockParams = findBlockParams;
                findEnumParams.findBlockParams.blockName = src.getItem(findEnumParams.classNameIndex()).str;
                findEnumParams.classNameToExtend = "java.lang.Enum";
                findEnumParams.classToExtend = Loader.loadClass(compiler, "java.lang.Enum", coreThreadID);
                
                findBlockParams.categoryOfBlock = new CategoryOfBlock(CategoryOfBlock.Enum, null);
                findBlockParams.parent = findEnumParams;
                data.mlistOfBlocks.add(findBlockParams);
                
                return;

            }
            else
            {
            	CompilerStatic.errors.add(new Error(compiler, i, i, "Identifier not exists behind enum keyword."));
            }
        }   // for
    }
	
	
	void FindErrorBlock(int indexOfLeftPair, Block result) {
		int startParenthesis = indexOfLeftPair;
        int endParenthesis = Checker.CheckParenthesis(compiler,  "{", "}", startParenthesis, compiler.data.mBuffer.count-1, false);
        FindBlockParams findBlockParams = new FindBlockParams(compiler, startParenthesis, endParenthesis);
        result.findBlockParams = findBlockParams;
        result.startIndex = IndexForHighArray.indexRelative(result, compiler.data.mBuffer, startParenthesis);
        result.findBlockParams.blockName = "error";
        result.found = true;
        
        findBlockParams.parent = result;
        data.mlistOfBlocks.add(findBlockParams);
        
		
	}
	
	
	/** 모든 타입선언문들에서 타입이름이 short name만을 대상으로 하여
	 * (full name은 findMemberUsesUsingNameSpace()에서 클래스를 로드하므로) 
	 * import된 클래스인지, 파일에서 정의하고 있는 클래스인지, 같은 패키지 클래스인지를 검사하여 
	 * result로 리턴한다. 또한 int, char 등과 같은 타입들도 제외한다.(getFullnameType()을 호출하여) 
	 * Integer, Char, Exception 등과 같은 java.lang안의 클래스들도 여기서 찾아낼수 있다. 
	 * 여기에서 타입이 결정이 안된 클래스들은 다음에서 정해진다. 타입선언시 내부클래스가 있는 경우이다. 
	 * java.lang안의 클래스들이나 같은 패키지내 클래스들이나 import java.util.*에서 타입선언시 내부클래스가 있는 경우이다.
	 * Character.Subset s;과 같은 java.lang안의 내부클래스들은 findMemberUsesUsingNamespace_sub을 거쳐서 confirmTypeName에서 정해진다.
	 * 같은 패키지내 클래스들은 findMemberUsesUsingNamespace_sub에서 정해진다.<br>
	 * 대체적인 풀타입이름이 정해진다. 자신이 정의하는 클래스의 풀네임도 여기서 정해진다.
	 * (FindAllClassesAndItsMembers2_sub()호출이후이므로)
	 * @param src
	 * @param listOfMemberVarDecls : 파일안 모든 멤버변수선언리스트
	 * @param listOfLocalVarDecls : 파일안 모든 지역변수선언리스트
	 * @param result : 배열을 제외한 클래스 풀 이름
	 * @param coreThreadID 
	 */
	public void FindClassesFromTypeDecls(Compiler compiler, ArrayListString result, int coreThreadID) {
		int i, j;
		// 상속클래스이름을 정확한 fullname으로 바꿔준다.
		for (i=0; i<data.mlistOfAllDefinedClasses.count; i++) {			
			FindClassParams c = (FindClassParams) data.mlistOfAllDefinedClasses.getItem(i);
			String fullname;
			if (c.startIndexOfClassNameToExtend()==-1 && c.endIndexOfClassNameToExtend()==-1) {
				if (c.isEnum) {
					fullname = "java.lang.Enum";
				}
				else if (c.isInterface) {
					fullname = "java.lang.Object";
				}
				else {
					fullname = "java.lang.Object";
				}
			}
			else 
				fullname = Fullname.getFullNameType(compiler, c.startIndexOfClassNameToExtend(), c.endIndexOfClassNameToExtend(), coreThreadID);
			c.classNameToExtend = fullname;
		}
		
		//구현인터페이스이름을 정확한 fullname으로 바꿔준다.
		for (i=0; i<data.mlistOfAllDefinedClasses.count; i++) {
			FindClassParams c = (FindClassParams) data.mlistOfAllDefinedClasses.getItem(i);
			if (c.listOfStartIndexOfInterfaceNamesToImplement!=null) {
				for (j=0; j<c.listOfStartIndexOfInterfaceNamesToImplement.count; j++) {					
					IndexForHighArray startIndex = (IndexForHighArray) c.listOfStartIndexOfInterfaceNamesToImplement.getItem(j);
					IndexForHighArray endIndex = (IndexForHighArray) c.listOfEndIndexOfInterfaceNamesToImplement.getItem(j);
					String fullname = Fullname.getFullNameType(compiler, startIndex.index(), endIndex.index(), coreThreadID);
					c.interfaceNamesToImplement.list[j] = fullname;
				}
			}
		}
		
		/*ArrayListIReset listOfTypeCasts = this.mlistOfAllTypeCasts ;
		
		for (i=0; i<listOfTypeCasts.count; i++) {
			TypeCast typecast = (TypeCast) listOfTypeCasts.getItem(i);
			FindVarUseParams varUse = typecast.varUseTypeCasting;
			if (varUse.index()==5973) {
				int a;
				a=0;
				a++;
			}
			if (varUse.varDecl!=null && varUse.varDecl.templateOfClass!=null) {
				typecast.name = "java.lang.Object";
			}
		}*/
		
		int len = data.mlistOfAllMemberVarDeclarations.getCount();
		for (i=0; i<len; i++) {
			FindVarParams var = (FindVarParams) data.mlistOfAllMemberVarDeclarations.getItem(i);
			
			String typeName;
			if (var.isThis) {
				typeName = ((FindClassParams)var.parent).name;
			}
			else if (var.isSuper) {
				typeName = ((FindClassParams)var.parent).classNameToExtend;
			}
			else {
				typeName = Fullname.getFullNameType(compiler, var.typeStartIndex(), var.typeEndIndex(), coreThreadID);
			}
			/*if (var.isTypeNameToChange) {
				// Stack<T>{
				//	T[] data;
				// } 에서 data의 타입 T[]를 java.lang.Object[]로 정한다.
				String type = Fullname.getFullName(compiler.mBuffer, var.typeStartIndex(), var.typeEndIndex()).str;
				int dimension = CompilerHelper.getArrayDimension(compiler, type);
				typeName = CompilerHelper.getArrayType("java.lang.Object", dimension);
			}*/
			var.typeName = typeName;
			if (typeName==null) {
				continue;
			}
			String typeName2 = Array.getArrayElementType(typeName);
			if (!typeName.equals(typeName2)) {
				result.add(typeName2);
			}
			else {
				result.add(typeName);
			}
		}
		
		int len2 = data.mlistOfAllLocalVarDeclarations.getCount();
		for (i=0; i<len2; i++) {
			FindVarParams var = (FindVarParams) data.mlistOfAllLocalVarDeclarations.getItem(i);
			
			String typeName = Fullname.getFullNameType(compiler, var.typeStartIndex(), var.typeEndIndex(), coreThreadID);
			/*if (var.isTypeNameToChange) {
				String type = Fullname.getFullName(compiler.mBuffer, var.typeStartIndex(), var.typeEndIndex()).str;
				int dimension = CompilerHelper.getArrayDimension(compiler, type);					
				typeName = CompilerHelper.getArrayType("java.lang.Object", dimension);
			}*/
			var.typeName = typeName;
			if (typeName==null) {
				continue;
			}
			try{
			String typeName2 = Array.getArrayElementType(typeName);
			if (!typeName.equals(typeName2)) {
				result.add(typeName2);
			}
			else {
				result.add(typeName);
			}
			}catch(Exception e) {
				if (Common_Settings.g_printsLog) e.printStackTrace();
			}
		}
		
		for (i=0; i<data.mlistOfAllFunctions.count; i++) {
			FindFunctionParams func = (FindFunctionParams) data.mlistOfAllFunctions.getItem(i);
			String typeName = Fullname.getFullNameType(compiler, func.returnTypeStartIndex(), func.returnTypeEndIndex(), coreThreadID);
			
			if (func.returnTypeStartIndex()==-1 && func.returnTypeEndIndex()==-1) {
				// 생성자의 경우는 이미 정해져 있다.
				if (func.isConstructor) {
					typeName = func.returnType;
					// 생성자이므로 반환값이 없다. 그러므로 continue;
					// continue;
				}//if (func.isConstructor) {
				else if (func.isStaticBlock) {
					// static 블록이므로 반환값이 없다. 그러므로 continue;
					continue;
				}
			}//if (func.returnTypeStartIndex==-1 && func.returnTypeEndIndex==-1) {
			else {
				func.returnType = typeName;
			}
			if (typeName==null) {
				continue;
			}
			if (CompilerStatic.getShortName(typeName).equals("Pair")) {
			}
			if (typeName.equals("com.gsoft.common.Compiler.CodeString[]")) {
			}
			//result.add(typeName);
			String typeName2 = null;
			try {
			typeName2 = Array.getArrayElementType(typeName);
			}catch(Exception e) {
				if (Common_Settings.g_printsLog) e.printStackTrace();
			}
			
			if (!typeName.equals(typeName2)) {
				result.add(typeName2);
			}
			else {
				result.add(typeName);
			}
		}
		
		/*len = compiler.mlistOfAllTypeCasts.count;
		for (i=0; i<len; i++) {
			TypeCast typeCast = (TypeCast) compiler.mlistOfAllTypeCasts.getItem(i);
			if (var.varNameIndex()==10279) {
				int a;
				a=0;
				a++;
			}
			String typeName;
			if (var.isThis) {
				typeName = ((FindClassParams)var.parent).name;
			}
			else if (var.isSuper) {
				typeName = ((FindClassParams)var.parent).classNameToExtend;
			}
			else {
				typeName = getFullNameType(compiler, var.typeStartIndex(), var.typeEndIndex());
			}
			if (typeName==null) {
				if (var.template!=null) {
					// Stack<T>{
					//	T[] data;
					// } 에서 data의 타입 T[]를 java.lang.Object[]로 정한다.
					String type = compiler.getFullName(compiler.mBuffer, var.typeStartIndex(), var.typeEndIndex()).str;
					int dimension = CompilerHelper.getArrayDimension(compiler, type);					
					typeName = CompilerHelper.getArrayType("java.lang.Object", dimension);
				}
			}
			var.typeName = typeName;
			if (typeName==null) {
				continue;
			}
			String typeName2 = CompilerHelper.getArrayElementType(typeName);
			if (typeName.equals(typeName2)==false) {
				result.add(typeName2);
			}
			else {
				result.add(typeName);
			}
		}*/
		
		for (i=0; i<data.mlistOfAllConstructor.count; i++) {
			if (i==11) {
			}
			Constructor constructor = (Constructor) data.mlistOfAllConstructor.getItem(i);
			if (constructor.indexOfNew()==83450) {
			}
			
			//String typeName = constructor.getType(src, constructor.startIndexExceptPair, constructor.endIndexExceptPair);
			String typeName = Fullname.getFullNameType(compiler, 
					constructor.startIndexExceptPair(), constructor.endIndexExceptPair(), coreThreadID);
			constructor.fullname = typeName;
			if (typeName==null) {
				continue;
			}
			if (CompilerStatic.getShortName(typeName).equals("Pair")) {
			}
			if (typeName.equals("com.gsoft.common.Compiler.CodeString[]")) {
			}
			//result.add(typeName);
			String typeName2 = Array.getArrayElementType(typeName);
			if (!typeName.equals(typeName2)) {
				result.add(typeName2);
			}
			else {
				result.add(typeName);
			}
		}
	}
	
	/**mlistOfAllTemplates.add(template);*/
	void putTempate(Template template) {
		//if (modeAllOrUpdate==ModeAllOrUpdate.All) {
			if (template.indexRightPair()==21587) {
			}
			data.mlistOfAllTemplates.add(template);
		//}
		
	}
	/**mlistOfAllDefinedClasses.add(classParams);*/
	void putFindClassParams(FindClassParams classParams) {
		//if (modeAllOrUpdate==ModeAllOrUpdate.All) {
			data.mlistOfAllDefinedClasses.add(classParams);
		//}
	}
	/**mlistOfAllConstructor.add(constructor);*/
	void putConstructor(Constructor constructor) {
		//if (modeAllOrUpdate==ModeAllOrUpdate.All) {
			data.mlistOfAllConstructor.add(constructor);
		//}
	}
	
	/** var를 mlistOfAllMemberVarDeclarations나 mlistOfAllLocalVarDeclarations에 넣는다.
	 * mlistOfAllMemberVarDeclarations.add(var);<br>
	 * or mlistOfAllLocalVarDeclarations.add(var);*/
	void putFindVarParams(FindVarParams var, boolean isLocal) {
		if (!isLocal) {
			//if (modeAllOrUpdate==ModeAllOrUpdate.All) {
				data.mlistOfAllMemberVarDeclarations.add(var);
			//}
		}
		else {
			//if (modeAllOrUpdate==ModeAllOrUpdate.All) {
				data.mlistOfAllLocalVarDeclarations.add(var);
			//}
		}
	}
	
	/** 독립적인 할당문 뿐만 아니라 모든 할당문, 
	 * 예를들어 a=2+(a=3)+2; 혹은 f(a=2, 3);과 같은 문장에 포함된 대입문들도 대상이 된다. 
	 * 모든 할당문들을 mlistOfAllAssignStatements에 넣는다.<br>
	 * mlistOfAllAssignStatements.add(assignStatement);*/
	void putFindAssignStatementParamsTomlistOfAllAssignStatements(FindAssignStatementParams assignStatement) {
		//if (modeAllOrUpdate==ModeAllOrUpdate.All) {
			
			data.mlistOfAllAssignStatements.add(assignStatement);
		//}
	}
	
	/** 독립적인 할당문만을 mlistOfAssignStatements에 넣는다.<br>
	 * mlistOfAssignStatements.add(assignStatement);*/
	void putFindAssignStatementParams(FindAssignStatementParams assignStatement) {
		//if (modeAllOrUpdate==ModeAllOrUpdate.All) {
			data.mlistOfAssignStatements.add(assignStatement);
		//}
	}
	
	/**	data.mlistOfAllVarUses.add(varUse);<br>
		mlistOfAllVarUsesHashed.input(varUse.originName, varUse);<br>*/
	void putVarUse(FindVarUseParams varUse) {
	//	if (modeAllOrUpdate==ModeAllOrUpdate.All) {
			data.mlistOfAllVarUses.add(varUse);
			data.mlistOfAllVarUsesHashed.input(varUse.originName, varUse);
		//}
	}
	
	/**mlistOfSynchronizedBlocks.add(control);*/
	/*void putSynchronizedBlockTomlistOfSynchronizedBlocks(FindControlBlockParams control) {
		if (modeAllOrUpdate==ModeAllOrUpdate.All) {
			mlistOfSynchronizedBlocks.add(control);
		}
	}*/
	
	/**mlistOfAllControlBlocks.add(control);*/
	void putFindControlBlockParams(FindControlBlockParams control) {
		//if (modeAllOrUpdate==ModeAllOrUpdate.All) {
			data.mlistOfAllControlBlocks.add(control);
		//}
	}
	
	/**mlistOfAllFunctions.add(function);*/
	void putFindFunctionParams(FindFunctionParams function) {
		//if (modeAllOrUpdate==ModeAllOrUpdate.All) {
			data.mlistOfAllFunctions.add(function);
		//}
	}
	/**mlistOfSpecialStatement.add(specialStatement);*/
	void putFindSpecialStatementParams(FindSpecialStatementParams specialStatement) {
		//if (modeAllOrUpdate==ModeAllOrUpdate.All) {
			data.mlistOfSpecialStatement.add(specialStatement);
		//}
	}
	/**mlistOfBlocks.add(findBlockParams);*/
	void putFindBlockParams(FindBlockParams findBlockParams) {		
		//if (modeAllOrUpdate==ModeAllOrUpdate.All) {
			data.mlistOfBlocks.add(findBlockParams);
		//}
	}
	
	/**mlistOfAllArrayIntializers.add(arrayIntializer);*/
	void putArrayIntializer(FindArrayInitializerParams arrayIntializer) {
		//if (modeAllOrUpdate==ModeAllOrUpdate.All) {
			data.mlistOfAllArrayIntializers.add(arrayIntializer);
		//}
	}
	
	/**parent.listOfVariableParams.add(var)*/
	void putVarToParent(FindVarParams var, Block parent) {
		//if (modeAllOrUpdate==ModeAllOrUpdate.All) {
			parent.listOfVariableParams.add(var);
		//}
	}
	/**func.listOfFuncArgs.add(var);*/
	void putVarToFunctionArg(FindVarParams var, FindFunctionParams func) {
		//if (modeAllOrUpdate==ModeAllOrUpdate.All) {
			func.listOfFuncArgs.add(var);
		//}
	}
	/**parent.listOfFindArrayInitializerParams.add(arr);*/
	void putArrayInitializerToParent(FindArrayInitializerParams arr, FindArrayInitializerParams parent) {
		//if (modeAllOrUpdate==ModeAllOrUpdate.All) {
			parent.listOfFindArrayInitializerParams.add(arr);
		//}
	}
	
	/** parentClass.listOfAllVarUses.add(varUse);<br>
		if (varUse.isForVarOrForFunc) parentClass.listOfAllVarUsesForVar.add(varUse);<br>
		else parentClass.listOfAllVarUsesForFunc.add(varUse);<br>*/
	void putVarUseToClass(FindVarUseParams varUse, FindClassParams parentClass) {
		//if (modeAllOrUpdate==ModeAllOrUpdate.All) {
			parentClass.listOfAllVarUses.add(varUse);
			if (varUse.isForVarOrForFunc) parentClass.listOfAllVarUsesForVar.add(varUse);
			else parentClass.listOfAllVarUsesForFunc.add(varUse);
		//}
	}
	
	/** parentFunc.listOfAllVarUses.add(varUse);<br>
		if (varUse.isForVarOrForFunc) parentFunc.listOfAllVarUsesForVar.add(varUse);<br>
		else parentFunc.listOfAllVarUsesForFunc.add(varUse);<br>*/
	void putVarUseToFunction(FindVarUseParams varUse, FindFunctionParams parentFunc) {
		//if (modeAllOrUpdate==ModeAllOrUpdate.All) {
			parentFunc.listOfAllVarUses.add(varUse);
			if (varUse.isForVarOrForFunc) parentFunc.listOfAllVarUsesForVar.add(varUse);
			else parentFunc.listOfAllVarUsesForFunc.add(varUse);
		//}
	}
	/**parent.listOfStatementsInParenthesis.add(statement);*/
	void putStatementToParenthesisOfParent(FindStatementParams statement, FindControlBlockParams parent) {
		//if (modeAllOrUpdate==ModeAllOrUpdate.All) {
			parent.listOfStatementsInParenthesis.add(statement);
		//}
	}
	
	/**parent.listOfStatements.add(statement);*/
	void putStatementToParent(FindStatementParams statement, Block parent) {
		//if (modeAllOrUpdate==ModeAllOrUpdate.All) {
			try {
				if (statement.startIndex()==993) {
				}
			parent.listOfStatements.add(statement);
			}catch(Exception e) {
				if (Common_Settings.g_printsLog) e.printStackTrace();
			}
		//}
	}
	/**parent.listOfControlBlocks.add(block);*/
	void putControlBlockToParent(FindControlBlockParams block, Block parent) {
		//if (modeAllOrUpdate==ModeAllOrUpdate.All) {
			parent.listOfControlBlocks.add(block);
		//}
	}
	
	void putClassEnumInterfaceToResult(FindClassParams classParams, ArrayListIReset result, Stack stack) {
		//if (modeAllOrUpdate==ModeAllOrUpdate.All) {
			if (stack.len==0) { // 최상위 클래스만 등록
				result.add(classParams);
			}
		//}
	}
	/**parent.listOfFunctionParams.add(function);*/
	void putFunctionToParent(FindFunctionParams function, FindClassParams parent) {
		//if (modeAllOrUpdate==ModeAllOrUpdate.All) {
			parent.listOfFunctionParams.add(function);
		//}
	}
	/**parentClass.add(eventClass);*/
	void putClassEnumInterfaceToParent(FindClassParams eventClass, ArrayListIReset parentClass) {
		//if (modeAllOrUpdate==ModeAllOrUpdate.All) {
			parentClass.add(eventClass);
		//}
	}

	public void destroy() {
		
		
	}
	
}
