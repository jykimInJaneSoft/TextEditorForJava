package com.gsoft.common.compiler;

import android.util.Log;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.CommonGUI;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.Compiler_types.FindExpressionParams;
import com.gsoft.common.compiler.Compiler_types.FindFuncCallParam;
import com.gsoft.common.compiler.Compiler_types.FindFunctionParams;
import com.gsoft.common.compiler.Compiler_types.FindVarParams;
import com.gsoft.common.compiler.Compiler_types.FindVarUseParams;
import com.gsoft.common.compiler.Compiler_types_Base.Error;
import com.gsoft.common.util.ArrayListIReset;

import com.gsoft.common.compiler.CodeStringEx;
import com.gsoft.common.compiler.HighArray_CodeString;
import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.PostFixConverter;
import com.gsoft.common.compiler.CompilerStatic;
import com.gsoft.common.compiler.Member;
import com.gsoft.common.compiler.Checker;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.IndexForHighArray;
import com.gsoft.common.compiler.Array;
import com.gsoft.common.compiler.Fullname;
import com.gsoft.common.compiler.Number;
import com.gsoft.common.compiler.TypeCast_Syntax;

public class Expression {
	/**@param compiler : compiler having expression*/
	public static CodeStringEx getTypeOfExpression(Compiler compiler, FindExpressionParams expression, int coreThreadID) {
		FindFuncCallParam funcCall = 
			new FindFuncCallParam(compiler, expression.startIndex(), expression.endIndex());
		CodeStringEx type = getTypeOfExpression(compiler, funcCall, coreThreadID);
		return type;
	}
	
	
	/** 함수호출(또는 배열첨자)의 파라미터 하나를 대상으로 startIndex()와 endIndex 안에서 
	 * 수식(덧셈 등의 변수사용, 함수호출)의 type을 결정한다. 또한 수식을 postfix형식으로 변환한다.
	 * startIndex(), endIndex는 수식의 범위를 말하고 범위안에 포함된다. 
	 * 수식의 범위안에 네임스페이스와 함수, 배열원소등이 포함되어 있어도 된다.
	 * 
	 * 예를들어,
	 * 이 함수호출파라미터(funcCall)는 함수호출varUse의 listOfFuncCallParams의 원소이거나(f(a,b,c)에서 a,b,c), 
	 * 배열원소varUse의 listOfArrayElementParams의 원소이거나(buffer[i][j]에서 i, j),
	 * (타입)(수식)에서 타입VarUse의 TypeCast의 funcCall(FindFuncCallParam) 이거나,
	 * 할당문(FindAssignStatementParams)에서 rValue(FindFuncCallParam)를 말한다.
	 * @param compiler : compiler having expression(funcCall)
	 * @param coreThreadID */
	public static CodeStringEx getTypeOfExpression(Compiler compiler, 
			FindFuncCallParam funcCall, int coreThreadID) {
		HighArray_CodeString src = compiler.data.mBuffer;
		//if (funcCall.typeFullName!=null) return funcCall.typeFullName; 
		try{
		if (funcCall.startIndex()==507) {
		}
		
		if (funcCall.typeFullName!=null) 
			return funcCall.typeFullName;
		
		int indexOfSeparator = compiler.isEventHandlerClass(src, funcCall);
		if (indexOfSeparator!=-1) {
			funcCall.endIndex = IndexForHighArray.indexRelative(funcCall, src, indexOfSeparator-1);
		}
		
		if (funcCall.startIndex()>funcCall.endIndex()) return new CodeStringEx("void");
		
		int endIndexInmListOfAllVarUses;
		int startIndexInmListOfAllVarUses;
		int startIndexInmBuffer;
		
		startIndexInmBuffer = CompilerHelper.SkipBlank(src, false, funcCall.startIndex(), funcCall.endIndex());
		startIndexInmListOfAllVarUses = CompilerStatic.getIndexInmListOfAllVarUses(src, compiler.data.mlistOfAllVarUses, 
				0, startIndexInmBuffer, true);
		endIndexInmListOfAllVarUses = CompilerStatic.getIndexInmListOfAllVarUses(src, compiler.data.mlistOfAllVarUses, 
				startIndexInmListOfAllVarUses, funcCall.endIndex(), false);
		if (endIndexInmListOfAllVarUses!=-1) {
			// 함수호출의 매개변수당 한번씩 recursive call
			try {
			Member.findMemberUsesUsingNamespace_sub(compiler, compiler.data.mlistOfAllVarUses, 
					startIndexInmListOfAllVarUses, endIndexInmListOfAllVarUses, coreThreadID);
			}catch(Exception e) {
				if (Common_Settings.g_printsLog) if (Common_Settings.g_printsLog) e.printStackTrace();
			}
		}
		
		
		Checker.checkParenthesisError(compiler, src, funcCall.startIndex(), funcCall.endIndex());
		
		int i;
		
		
		CodeStringEx[] postfix = null;
		if (funcCall.expression==null || funcCall.expression.postfix==null) {
			FindExpressionParams expression = funcCall.expression;
			if (funcCall.expression==null) {
				expression = new FindExpressionParams(compiler, funcCall.startIndex(), funcCall.endIndex());
			}
			// funcCall.expression이 null이 아니면 다시 생성하지 않는다.
			PostFixConverter converter = new PostFixConverter(compiler, src, expression);
			postfix = converter.Convert();
			expression.postfix = postfix;
			funcCall.expression = expression;
		}
		
		
		//ArrayListString listOfTypes = new ArrayListString(10);
		
		/** 수식 스택*/
		ArrayListIReset listOfTypes = new ArrayListIReset(10);
		
		CodeStringEx type = null;
		if (postfix==null) {
			return null;
		}
		
		// builder = new StringBuilder(); 은 builder, StringBuilder(), = 이렇게 new가 사라진다.
		for (i=0; i<postfix.length; i++) {
			CodeStringEx str = postfix[i];
			
			HighArray_CodeString src2 = new HighArray_CodeString(1);
			src2.add(str);
			
			if (str==null) {
				continue;
			}
			if (str.equals("this.alpha")) {
			}
			if (!CompilerHelper.IsOperator(str) && !str.equals("new") ){
				// 변환된 postfix 수식에서 operand 하나의 타입을 얻는다.
				// k++, a[k++]++일 경우
				if (str.indicesInSrc.getItem(0)==36230) {
				}
				CodeString token = src.getItem(str.indicesInSrc.getItem(0));
				CodeStringEx strType = null;
				ReturnOfgetTypeOfVarUseOrFuncCallOfFullName2_sub returnOfgetTypeOfVarUseOrFuncCallOfFullName2 = null;
				if (!CompilerHelper.IsOperator(token)) {					
					returnOfgetTypeOfVarUseOrFuncCallOfFullName2 = 
							getTypeOfVarUseOrFuncCallOfFullName2(compiler, src, src2, str.indicesInSrc.getItem(0), coreThreadID);
					if (returnOfgetTypeOfVarUseOrFuncCallOfFullName2==null)
						strType = null;
					else strType = returnOfgetTypeOfVarUseOrFuncCallOfFullName2.typeFullName;
					type = strType;
					if (returnOfgetTypeOfVarUseOrFuncCallOfFullName2!=null) {
						if (returnOfgetTypeOfVarUseOrFuncCallOfFullName2.varUse!=null) {
							returnOfgetTypeOfVarUseOrFuncCallOfFullName2.varUse.tokenInPostfix = str;
							FindFunctionParams funcDecl = returnOfgetTypeOfVarUseOrFuncCallOfFullName2.varUse.funcDecl;
							if (funcDecl!=null && funcDecl.isTypeNameToChange) {
								type.isTypeNameToChangeForTemplate = true;
							}
						}
					}
					if (Number.IsNumber2(str)!=0) { // 숫자 상수이면
						type.typeFullName = strType.str;
					}
				}//if (CompilerHelper.IsOperator(token)==false ) {
				else { // ++k, ++a[k++]
					int indexInToken = 2;
					CodeString tokenLast = src.getItem(str.indicesInSrc.getItem(indexInToken));
					if (!CompilerHelper.IsOperator(tokenLast)) {
						returnOfgetTypeOfVarUseOrFuncCallOfFullName2 = 
								getTypeOfVarUseOrFuncCallOfFullName2(compiler, src, src2, str.indicesInSrc.getItem(indexInToken), coreThreadID);
						if (returnOfgetTypeOfVarUseOrFuncCallOfFullName2==null)
							strType = null;
						else strType = returnOfgetTypeOfVarUseOrFuncCallOfFullName2.typeFullName;
						type = strType;
						if (returnOfgetTypeOfVarUseOrFuncCallOfFullName2!=null) {
							if (returnOfgetTypeOfVarUseOrFuncCallOfFullName2.varUse!=null) {
								returnOfgetTypeOfVarUseOrFuncCallOfFullName2.varUse.tokenInPostfix = str;
							}
						}
						if (Number.IsNumber2(str)!=0) { // 숫자 상수이면
							type.typeFullName = strType.str;
						}
					}
				}
				if (type!=null) {
					str.typeFullName = type.str;
					type.operandOrOperator = str;
				}
				
				// 스택에 넣는다.	
				// getTypeOfOperator()에서 str의 typeFullNameAfterOperation의 값이 바뀌게 된다.
				listOfTypes.add(type);
			}
			// 1  2.5f  +  3  +   --> 첫번째 +를 만날시 float가 getTypeOfOperator에서 리턴되고,
			// listOfTypes에는 첫두개의 오퍼랜드가 삭제되어 float가 저장된다. 
			// 3을 만나면 float  int이 되고,
			// 두번째 +를 만나면 마지막이 float int이기 때문에 float가 getTypeOfOperator에서 리턴되고,
			// 최종적으로 listOfTypes에는 두개의 오퍼랜드가 삭제되어 빈상태가 된다.
			// 마지막 float가 수식의 타입으로 리턴된다.
			else if (CompilerHelper.IsOperator(str)) { // 이항 연산자일 경우에만
				if (str.indicesInSrc.count>0 && str.indicesInSrc.list[0]==5398) {
				}
				
				type = getTypeOfOperator(compiler, funcCall, listOfTypes, str, coreThreadID);
				if (type==null) {
					str.typeFullName = null;					
				}
				else {
					// operator의 타입을 정한다.
					str.typeFullName = type.str;					
					type.operandOrOperator = str;
				}
				// 스택에서 오퍼랜드들을 빼고 연산 결과를 넣는다.
				// getTypeOfOperator()에서 str의 typeFullNameAfterOperation의 값이 바뀌게 된다.
				try {
				listOfTypes.add(type);
				}catch(Exception e) {
					if (Common_Settings.g_printsLog) e.printStackTrace();
				}
			}
		}//for (i=0; i<postfix.length; i++) {
		
		// 최종적으로 type 하나가 스택에 남는다.
		// funcCall이 상수값들인 경우 계산된 최종값은 type의 value에 저장되어 있다.
		if (type==null) funcCall.typeFullName = null;
		else funcCall.typeFullName = type;
		
		return type;
		
		
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
			if (Common_Settings.g_printsLog) CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
			String message="";
			for (int m=funcCall.startIndex(); m<=funcCall.endIndex(); m++) {
				message += src.getItem(m);
			}
			Log.e("error", "getTypeOfExpression :" + message);
			CompilerHelper.printMessage(CommonGUI.textViewLogBird, "getTypeOfExpression :" + message);
			return null;
		}
		
		
	}
	
	
	/** full name이든 아니든 startIndex()에서 시작하는 
	 * 변수사용의 type, 혹은 함수의 타입을 리턴한다.
	 * 예를 들어 full name일 경우 hScrollBar.rectForPage.draw(); 여기에서 draw의 리턴타입를 말한다.
	 * a.b().c일 경우 c의 타입을 리턴한다. a.b()일 경우 b의 리턴타입을 리턴한다.
	 * buffer[i+1]일 경우 이것의 타입인 com.gsoft.common.Compiler.CodeString을 리턴한다.
	 * (int)f와 같이 varUse f가 타입캐스트된 경우 변환된 int를 리턴  
	 * full name이 아니면 해당 변수사용 혹은 함수의 타입을 말한다.
	 * 변수사용이 아니면 null을 리턴한다. 
	 * full name이 아니면 패키지이름을 추가한 full name을 리턴한다.
	 * @param coreThreadID 
	 * @return : boolean, 숫자(int, float), void, 문자(String, char), 오브젝트일경우 fullname*/
	public static ReturnOfgetTypeOfVarUseOrFuncCallOfFullName2_sub getTypeOfVarUseOrFuncCallOfFullName(
			Compiler compiler, HighArray_CodeString src, int startIndex, int coreThreadID) {
		if (startIndex==3353) {
		}
		
		
		int endIndexOfFullName;
		//endIndexOfFullName = SkipBlank(src, false, startIndex(), src.count-1);
		endIndexOfFullName = Fullname.getFullNameIndex(compiler, false, startIndex, true);
		if (endIndexOfFullName<startIndex) {
			CompilerStatic.errors.add(new Error(compiler, startIndex, startIndex, "invalid function call : invalid parameter"));
			return null;
		}
		endIndexOfFullName = CompilerHelper.SkipBlank(src, true, 0, endIndexOfFullName);
		if (endIndexOfFullName<0) return null;
		
		return getTypeOfVarUseOrFuncCallOfFullName2_sub(compiler, src, startIndex, endIndexOfFullName, coreThreadID);
		
	}
	
	
	
	public static class ReturnOfgetTypeOfVarUseOrFuncCallOfFullName2_sub {
		public CodeStringEx typeFullName;
		FindVarUseParams varUse;
		ReturnOfgetTypeOfVarUseOrFuncCallOfFullName2_sub(CodeStringEx typeFullName, 
				FindVarUseParams varUse) {
			this.typeFullName = typeFullName;
			this.varUse = varUse;
		}
	}
	
	public static ReturnOfgetTypeOfVarUseOrFuncCallOfFullName2_sub getTypeOfVarUseOrFuncCallOfFullName2_sub(
			Compiler compiler, HighArray_CodeString src, int startIndex, int endIndexOfFullName, int coreThreadID) {
		
		
		String strResult = null;
			
		
		CodeString strOfEndIndexOfFullName = src.getItem(endIndexOfFullName);
		
		if (strOfEndIndexOfFullName.equals("true") || strOfEndIndexOfFullName.equals("false")) {
			strResult = "boolean";
		}
		else if (strOfEndIndexOfFullName.equals("null")) {
			strResult = "null";
		}
		
		else { // 숫자나 인용문(스트링), 인용문자(문자상수)
			int number = Number.IsNumber2(strOfEndIndexOfFullName);
						
			if (number==1) {
				strResult = "char";
			}
			else if (number==2) {
				strResult = "short";
			}
			else if (number==3) {
				strResult = "int";
			}
			else if (number==4) {
				strResult = "long";
			}
			else if (number==5) {
				strResult = "float";
			}
			else if (number==6) {
				strResult = "double";
			}
			else if (number==7) {
				strResult = "byte";
			}
			
			if (strOfEndIndexOfFullName==null || strOfEndIndexOfFullName.equals("")) 
			{
				strResult = "void";
			}
			else if (CompilerHelper.IsConstant(strOfEndIndexOfFullName)) {
				// 문자 상수
				char c = strOfEndIndexOfFullName.charAt(0).c;
				if (c=='"')	{
					strResult = "java.lang.String";
				}
				else if (c=='\'') {
					strResult = "char";
				}
			}
		}
		
		if (strOfEndIndexOfFullName.equals("length")) {
		}
		
		//(Object)(buffer[(int)i+0]+2) 이와 같은 수식 타입캐스트일 경우 뿐만아니라 
		// (FindBlockParams) listOfBlocks.getItem(i) 비수식 타입캐스트도 가능하다.
		if (src.getItem(startIndex).equals("(")) {
			if (startIndex==873) {
			}
			int indexOfRightPair = Checker.CheckParenthesis(compiler,  "(", ")", startIndex, src.count-1, false);
			int indexOfvarUseTypeCast = CompilerHelper.SkipBlank(src, true, 0, indexOfRightPair-1);			
			String varUseNameStr = src.getItem(indexOfvarUseTypeCast).str;
			while (true) {
				if (varUseNameStr.equals("]")) {
					int indexLeftPairArr = Checker.CheckParenthesis(compiler,  "[", "]", 0, indexOfvarUseTypeCast, true);
					indexOfvarUseTypeCast = CompilerHelper.SkipBlank(src, true, 0, indexLeftPairArr-1);			
					varUseNameStr = src.getItem(indexOfvarUseTypeCast).str;
				}
				else break;
			}
			FindVarUseParams varUseTypeCast = 
					CompilerStatic.getVarUseWithIndex(compiler.data.mlistOfAllVarUsesHashed, varUseNameStr, indexOfvarUseTypeCast);
			
			if (varUseTypeCast!=null && varUseTypeCast.typeCast!=null && 
					/*varUseTypeCast.typeCast.affectsExpression &&*/ 
					varUseTypeCast.typeCast.endIndexToAffect()!=-1/* &&
					varUseTypeCast.typeCast.funcCall!=null*/) {
				//CompilerHelper.SkipBlank(src, false, varUseTypeCast.typeCast.endIndexToAffect()+1, src.count-1);
				strResult = varUseTypeCast.typeCast.name;
				
				return new ReturnOfgetTypeOfVarUseOrFuncCallOfFullName2_sub(new CodeStringEx(strResult), null);
				//return new ReturnOfgetTypeOfVarUseOrFuncCallOfFullName2_sub(new CodeStringEx(strResult), varUse);
			}
		}
		
		
		
		String varUseName = src.getItem(endIndexOfFullName).str;
		FindVarUseParams varUse = CompilerStatic.getVarUseWithIndex(compiler.data.mlistOfAllVarUsesHashed, varUseName, endIndexOfFullName);
		
		if (varUse!=null) { // 위와 같은 수식 타입 캐스트가 아닌 경우
						
			if (varUse.isArrayElement) {
				// array 오브젝트 생성
				boolean isConstructor = false;
				int prevIndex = CompilerHelper.SkipBlank(src, true, 0, varUse.index()-1);
				if (prevIndex!=-1) {
					if (src.getItem(prevIndex).equals("new")) {
						isConstructor = true;
					}
					else isConstructor = false;
				}
				if (isConstructor) {	
					// a = new int[10][10]인 경우
					int arrayDimension = Array.getArrayDimension(compiler, varUse.name); 
					if (arrayDimension!=0) {
						String type = Array.getArrayElementType(varUse.name);
						String fullnameType = Fullname.getFullNameType2(compiler, type, varUse.index(), coreThreadID);
						String returnType = Array.getArrayType(fullnameType, arrayDimension);
						
						strResult = returnType;	
						return new ReturnOfgetTypeOfVarUseOrFuncCallOfFullName2_sub(new CodeStringEx(strResult), varUse);
						
					}
				}
				else { // a = new Character.Subset[10][10]에서 varUse는 Subset을 가리킨다.
					if (varUse.memberDecl!=null) {
						String typeName = Fullname.getFullNameType(compiler, startIndex, endIndexOfFullName, coreThreadID);
						int arrayDimension = Array.getArrayDimension(compiler, varUse.name); 
						if (arrayDimension!=0) {
							String returnType = Array.getArrayType(typeName, arrayDimension);
							strResult = returnType;
							return new ReturnOfgetTypeOfVarUseOrFuncCallOfFullName2_sub(new CodeStringEx(strResult), varUse);
						}
					}
				}
				
			}//if (varUse.isArrayElement) {
			if (varUse.varDecl!=null) {
				FindVarParams var = varUse.varDecl; 
				if (var.isThis) { // return this;
					FindClassParams classParams = (FindClassParams) var.parent;
					strResult = classParams.name;					
				}
				else if (var.isSuper) { // return super;
					String typeName = ((FindClassParams)var.parent).classNameToExtend;
					strResult = typeName;					
				}
				
				else if (var.typeName!=null) {
					//String fullname = var.getType(src, var.typeStartIndex(), var.typeEndIndex());
					String fullname = var.typeName;
					if (varUse.isArrayElement) { 
						// buffer[i]와 같은 경우, 타입은 CodeString[]이므로 CodeString을 리턴
						// 	int[][][] arr;		arr[2] = new int[2][0];
						int dimensionOfType = Array.getArrayDimension(compiler, varUse.varDecl.typeName);
						int dimensionOfVarUse = Array.getArrayDimension(compiler, varUse.name);
						int dimension = dimensionOfType - dimensionOfVarUse;
						if (dimension<0) {
							/** String name = "abc";
							    String a = name[0]; 여기에서 varUse는 name이다.*/
							CompilerStatic.errors.add(new Error(compiler, varUse.index(), varUse.index(), "invalid array subsription"));
						}
						String elementType = Array.getArrayElementType(varUse.varDecl.typeName);
						strResult = Array.getArrayType(elementType, dimension);						
					}
					else {
						// mBuffer와 같은 경우, 타입은 CodeString[]이므로 CodeString[]을 리턴
						strResult = fullname;
					}
					
				}
				else { // 외부 라이브러리
					strResult = var.typeName;
				}
			}
			else if (varUse.funcDecl!=null) {
				FindFunctionParams func = varUse.funcDecl;
				if (varUse.isArrayElement) {
					// int[] f() {} 이고 
					// int v = f()[0] + 1;
					// varUse는 f()[0] 이다.
					int dimension1 = Array.getArrayDimension(compiler, varUse.name);
					int dimension2 = Array.getArrayDimension(compiler, func.returnType);
					if (dimension1==dimension2) {
						strResult = Array.getArrayElementType(func.returnType);
						
					}
					else {
						CompilerStatic.errors.add(new Error(compiler, varUse.index(), varUse.index(), "Array dimension is not valid."));
					}
				}
				else {
					strResult = func.returnType;					
				}
			}//else if (varUse.funcDecl!=null) {
			else if (varUse.memberDecl!=null) {
				try {
					FindClassParams c = (FindClassParams) varUse.memberDecl;
					strResult = c.name;
				}catch(Exception e) {
					// 패키지 이름이 Test이고 varUse가 Test일 경우
					if (Common_Settings.g_printsLog) e.printStackTrace();
				}
			}
		}
		if (strResult==null) return null;
		else return new ReturnOfgetTypeOfVarUseOrFuncCallOfFullName2_sub(new CodeStringEx(strResult), varUse);
	}
	
	/**@param src : 원래 소스
	 * @param srcOfPostfix : 포스트픽스상의 하나의 토큰, {토큰}인 개수가 1개인 배열이다.
	 * @param startIndex : 소스상에서의 토큰의 시작 인덱스
	 * @param coreThreadID 
	 * @return : fullname 타입
	 */
	public static ReturnOfgetTypeOfVarUseOrFuncCallOfFullName2_sub getTypeOfVarUseOrFuncCallOfFullName2(
			Compiler compiler, HighArray_CodeString src, HighArray_CodeString srcOfPostfix, int startIndex, int coreThreadID) {
				
		CodeStringEx token = (CodeStringEx)srcOfPostfix.getItem(0);
		if (token.arrayListCodeStringForToken==null) {
			token.arrayListCodeStringForToken = CompilerStatic.toOriginalArrayListCodeString(src, token);
		}
		
		int startIndexForPostfix = CompilerStatic.toPostfixIndex(src, token, startIndex);
		int endIndexOfFullName, endIndexOfFullNameForPostfix;
		//endIndexOfFullNameForPostfix = Fullname.getFullNameIndexWithPostfix(compiler, token.arrayListCodeStringForToken, token, false, startIndexForPostfix);
		
		HighArray_CodeString src_backup = compiler.data.mBuffer;
		compiler.data.mBuffer = token.arrayListCodeStringForToken;
		endIndexOfFullNameForPostfix = Fullname.getFullNameIndex_postfix(compiler, token.arrayListCodeStringForToken, false, startIndexForPostfix, true);
		compiler.data.mBuffer = src_backup;
		
		if (endIndexOfFullNameForPostfix<0) return null;
		
		endIndexOfFullName = CompilerStatic.toSrcIndex(src, token, endIndexOfFullNameForPostfix);
		if (endIndexOfFullName<startIndex) {
			CompilerStatic.errors.add(new Error(compiler, startIndex, startIndex, "invalid function call : invalid parameter"));
			return null;
		}
		endIndexOfFullName = CompilerHelper.SkipBlank(src, true, 0, endIndexOfFullName);
		if (endIndexOfFullName<0) return null;
		
		
		return 
			getTypeOfVarUseOrFuncCallOfFullName2_sub(compiler, src, startIndex, endIndexOfFullName, coreThreadID);
	}
	
	/** 1  2.5f  +  3  +   --> 첫번째 +를 만날시 float가 getTypeOfOperator에서 리턴되고,
	listOfTypes에는 첫두개의 오퍼랜드가 삭제되어 float가 저장된다. 
	3을 만나면 float  int이 되고,
	두번째 +를 만나면 마지막이 float int이기 때문에 float가 getTypeOfOperator에서 리턴되고,
	최종적으로 listOfTypes에는 두개의 오퍼랜드가 삭제되어 빈상태가 된다.
	마지막 float가 수식의 타입으로 리턴된다.
	@param compiler : compiler having operator
	@param listOfTypes : 오퍼랜드만 저장된 스택이다.오퍼레이터는 여기에 없다.
	 * @param coreThreadID */
public static 
	CodeStringEx getTypeOfOperator(Compiler compiler, FindFuncCallParam funcCall, ArrayListIReset listOfTypes, CodeStringEx operator, int coreThreadID) {
		int startIndex = funcCall.startIndex();
		int endIndex = funcCall.endIndex();
		int i;
		
		
		// 일단 이렇게 한다. 연산자가 들어있는 수식의 타입처리
		CodeStringEx oldType = null, curType;
		
		
		try{
		if (listOfTypes.count==1) {
			if (listOfTypes.getItem(listOfTypes.count-1)==null) {
				listOfTypes.count -= 1;
				return new CodeStringEx("null");
			}
			if (listOfTypes.getItem(listOfTypes.count-1).equals("null")) {
				listOfTypes.count -= 1;
				return new CodeStringEx("null");
			}
		}
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
		}
		
		// 단항연산자, int i4 = -((-1)+2) + (~(-1)+(~1)); 
		// 여기에서 -((-1)+2)의 -를 말한다. -1은 어휘분석기에서 하나의 스트링으로 합쳐진다.
		if ((operator.equals("+")  && operator.isPlusOrMinusForOne) || 
			(operator.equals("-") && operator.isPlusOrMinusForOne)) {
			if (listOfTypes.count>0) {
				oldType = (CodeStringEx) listOfTypes.getItem(listOfTypes.count-1);				
				if (oldType==null) {
					CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+"null"));
					listOfTypes.count -= 1;
					return new CodeStringEx("null");
				}
				oldType.operandOrOperator.affectedBy_left = operator;
				oldType.operandOrOperator.affectedBy = operator;
				operator.affectsLeft = oldType.operandOrOperator;
				if (oldType.equals("byte") || oldType.equals("char") || oldType.equals("short") || oldType.equals("int")) {
					//allowsOperator(oldType, null, operator);
				}
				else if (oldType.equals("long")) {
					//allowsOperator(oldType, null, operator);
				}
				else if (oldType.equals("float") || oldType.equals("double")) {
					//allowsOperator(oldType, null, operator);
				}
				else {
					CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType));
					listOfTypes.count -= 1;
					return new CodeStringEx("null");
				}
				// 스택에서 마지막 1개의 오퍼랜드를 빼낸다.
				listOfTypes.count -= 1;
				
			
				return oldType;
			}
		}
		
		if (operator.equals("?")) {
			if (listOfTypes.count>0) {
				oldType = (CodeStringEx) listOfTypes.getItem(listOfTypes.count-1);
				if (oldType==null) {
					CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+"null"));
					listOfTypes.count -= 1;
					return new CodeStringEx("null");
				}
				oldType.operandOrOperator.affectedBy_left = operator;
				oldType.operandOrOperator.affectedBy = operator;
				operator.affectsLeft = oldType.operandOrOperator;
				if (oldType.equals("boolean")) {
				}
				else {
					CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType));
					listOfTypes.count -= 1;
					return new CodeStringEx("null");
				}
				// 스택에서 마지막 1개의 오퍼랜드를 빼낸다.
				listOfTypes.count -= 1;
				
				return oldType;
			}
		}
		
		else if (operator.equals("!")) {
			if (listOfTypes.count>0) {
				oldType = (CodeStringEx) listOfTypes.getItem(listOfTypes.count-1);
				if (oldType==null) {
					CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+"null"));
					listOfTypes.count -= 1;
					return new CodeStringEx("null");
				}
				oldType.operandOrOperator.affectedBy_left = operator;
				oldType.operandOrOperator.affectedBy = operator;
				operator.affectsLeft = oldType.operandOrOperator;
				if (oldType.equals("boolean")) {
				}
				else {
					CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType));
					listOfTypes.count -= 1;
					return new CodeStringEx("null");
				}
				// 스택에서 마지막 1개의 오퍼랜드를 빼낸다.
				listOfTypes.count -= 1;
				
				return oldType;
			}
		}
		
		else if (operator.equals("~")) {
			if (listOfTypes.count>0) {
				oldType = (CodeStringEx) listOfTypes.getItem(listOfTypes.count-1);
				if (oldType==null) {
					CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+"null"));
					listOfTypes.count -= 1;
					return new CodeStringEx("null");
				}
				oldType.operandOrOperator.affectedBy_left = operator;
				oldType.operandOrOperator.affectedBy = operator;
				operator.affectsLeft = oldType.operandOrOperator;
				if (oldType.equals("byte") || oldType.equals("char") || oldType.equals("int") || oldType.equals("short") ||
					oldType.equals("long")) {
					//allowsOperator(oldType, null, operator);
				}
				else { // float, double등은 에러
					CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType));
					listOfTypes.count -= 1;
					return new CodeStringEx("null");
				}
				// 스택에서 마지막 1개의 오퍼랜드를 빼낸다.
				listOfTypes.count -= 1;
				
				return oldType;
			}
		}
		
		if (operator.equals(":")) {
			if (listOfTypes.count>1) {
				oldType = (CodeStringEx) listOfTypes.getItem(listOfTypes.count-2);
				if (oldType==null) {
					CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+"null"));
					listOfTypes.count -= 2;
					return new CodeStringEx("null");
				}
				oldType.operandOrOperator.affectedBy_left = operator;
				oldType.operandOrOperator.affectedBy = operator;
				operator.affectsLeft = oldType.operandOrOperator;
				
				for (i=listOfTypes.count-1; i<listOfTypes.count; i++) {					
					curType = (CodeStringEx) listOfTypes.getItem(i);
					if (curType==null) {
						CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, 
								"invalid expression : ("+operator.str+") "+oldType+", "+"null"));
						listOfTypes.count -= 2;
						return new CodeStringEx("null");
					}
					curType.operandOrOperator.affectedBy_right = operator;
					curType.operandOrOperator.affectedBy = operator;
					operator.affectsRight = curType.operandOrOperator;
					if (oldType.equals("byte") || oldType.equals("char") || oldType.equals("short") || oldType.equals("int")) {
						if (curType.equals("byte") || curType.equals("char") || curType.equals("short") || curType.equals("int")) {
							oldType.setStrAndTypeFullName("int", "int");
						}
						else if (curType.equals("long")) {
							oldType.setStrAndTypeFullName(curType.str, curType.typeFullName);
							oldType.operandOrOperator.typeFullNameAfterOperation = curType.str;
						}
						else if (curType.equals("float") || curType.equals("double")) {
							oldType.setStrAndTypeFullName(curType.str, curType.typeFullName);
							oldType.operandOrOperator.typeFullNameAfterOperation = curType.str;
						}
						else {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						
					}
					
					else if (oldType.equals("long")) {
						if (curType.equals("byte") || curType.equals("char") ||
							curType.equals("short") || curType.equals("int")) {
							// curType을 oldType으로 바꾼다.
							curType.operandOrOperator.typeFullNameAfterOperation = oldType.str;
						}
						else if (curType.equals("long")) {
							 
						}
						else if (curType.equals("float") || curType.equals("double")) {
							// oldType을 curType으로 바꾼다.
							oldType.setStrAndTypeFullName(curType.str, curType.typeFullName);
							oldType.operandOrOperator.typeFullNameAfterOperation = curType.str;
						}
						else {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}
					else if (oldType.equals("float")) {
						if (curType.equals("byte") || curType.equals("char") ||
							curType.equals("short") || curType.equals("int")) {
							// curType을 oldType으로 바꾼다.
							curType.operandOrOperator.typeFullNameAfterOperation = oldType.str;
						}
						else if (curType.equals("long")) {
							// curType을 oldType으로 바꾼다.
							curType.operandOrOperator.typeFullNameAfterOperation = oldType.str;
						}
						else if (curType.equals("float")) {
							
						}
						else if (curType.equals("double")) {
							// oldType을 curType으로 바꾼다.
							oldType.setStrAndTypeFullName(curType.str, curType.typeFullName);
							oldType.operandOrOperator.typeFullNameAfterOperation = curType.str;
						}
						else {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}
					else if (oldType.equals("double")) {
						if (curType.equals("byte") || curType.equals("char") ||
							curType.equals("short") || curType.equals("int") || curType.equals("long") ||
							curType.equals("float")) {
							// curType을 oldType으로 바꾼다.
							curType.operandOrOperator.typeFullNameAfterOperation = oldType.str;
						}
						else if (curType.equals("double")) {
							
						}
						else {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}
					else {
						if (!TypeCast_Syntax.isCompatibleType(compiler, compiler, oldType, curType, 0, null, coreThreadID)) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							
						}
					}
				}//for
				// 스택에서 마지막 3개의 오퍼랜드를 빼낸다.
				listOfTypes.count -= 3;
				
				return oldType;
			}//if (listOfTypes.count>1) {
		}//if (operator.equals(":")) {
		
		// +, -, *, /, %, 는 float-float가 가능하다.boolean-boolean불가능
		else if ((operator.equals("+") && !operator.isPlusOrMinusForOne) || 
			(operator.equals("-") && !operator.isPlusOrMinusForOne) || 
			operator.equals("*") || operator.equals("/") ||	operator.equals("%")) {
			if (listOfTypes.count<=1) {
				CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+"null"));
				listOfTypes.count = 0;
				return new CodeStringEx("null");
			}
			if (listOfTypes.count>1) {
				oldType = (CodeStringEx) listOfTypes.getItem(listOfTypes.count-2);
				if (oldType==null) {
					CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+"null"));
					listOfTypes.count -= 2;
					return new CodeStringEx("null");
				}
				if (operator.indicesInSrc!=null && operator.indicesInSrc.getItem(0)==16896) {
				}
				oldType.operandOrOperator.affectedBy_left = operator;
				oldType.operandOrOperator.affectedBy = operator;
				operator.affectsLeft = oldType.operandOrOperator;
				for (i=listOfTypes.count-1; i<listOfTypes.count; i++) {
					curType = (CodeStringEx) listOfTypes.getItem(i);
					if (curType==null) {
						CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, 
								"invalid expression : ("+operator.str+") "+oldType+", "+"null"));
						listOfTypes.count -= 2;
						return new CodeStringEx("null");
					}
					curType.operandOrOperator.affectedBy_right = operator;
					curType.operandOrOperator.affectedBy = operator;
					operator.affectsRight = curType.operandOrOperator;
					if (oldType.equals("boolean")) {
						if (curType.equals("boolean")) {							
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("java.lang.String")) {
							if (operator.equals("+")) {//'+'연산만 가능
								// 이전 오퍼랜드는 String으로 바뀐다.
								oldType.setStrAndTypeFullName(curType.str, curType.typeFullName);
								oldType.operandOrOperator.typeFullNameAfterOperation = curType.str;
							}
							else {
								CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
								listOfTypes.count -= 2;
								return new CodeStringEx("null");
							}
						}
						else {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}//if (oldType.equals("boolean")) {
					else if (oldType.equals("void")) {
						CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
						listOfTypes.count -= 2;
						return new CodeStringEx("null");
					}
					if (oldType.equals("byte") || oldType.equals("char") || oldType.equals("short") || oldType.equals("int")) {
						if (curType.equals("boolean")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("byte") || curType.equals("char") || curType.equals("short") || curType.equals("int")) {
							oldType.setStrAndTypeFullName("int", "int");
							curType.setStrAndTypeFullName("int", "int");
						}
						else if (curType.equals("long")) {
							// 이전 오퍼랜드는 long으로 바뀐다.
							//allowsOperator(oldType, curType, operator);
							// oldType을 curType으로 바꾼다.
							oldType.setStrAndTypeFullName(curType.str, curType.typeFullName);
							oldType.operandOrOperator.typeFullNameAfterOperation = curType.str;
						}
						else if (curType.equals("float") || curType.equals("double")) {
							// 이전 오퍼랜드는 float나 double으로 바뀐다.
							//allowsOperator(oldType, curType, operator);
							oldType.setStrAndTypeFullName(curType.str, curType.typeFullName);
							oldType.operandOrOperator.typeFullNameAfterOperation = curType.str;
						}
						else if (curType.equals("java.lang.String")) {							
							if (operator.equals("+")) {
								// 이전 오퍼랜드는 String으로 바뀐다.
								oldType.setStrAndTypeFullName(curType.str, curType.typeFullName);
								oldType.operandOrOperator.typeFullNameAfterOperation = curType.str;
							}
							else {
								CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
								listOfTypes.count -= 2;
								return new CodeStringEx("null");
							}
							//return curType;
						}
						else {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}// if (oldType.equals("byte") || oldType.equals("char") || oldType.equals("short") || oldType.equals("int")) {
					else if (oldType.equals("long")) {
						if (curType.equals("boolean")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("byte") || curType.equals("char") || curType.equals("short") || curType.equals("int")) {
							curType.setStrAndTypeFullName(oldType.str, oldType.typeFullName);
							curType.operandOrOperator.typeFullNameAfterOperation = oldType.str;
						}
						else if (curType.equals("long")) {
						}
						else if (curType.equals("float") || curType.equals("double")) {
							// 이전 오퍼랜드는 float나 double으로 바뀐다.
							//allowsOperator(oldType, curType, operator);
							oldType.setStrAndTypeFullName(curType.str, curType.typeFullName);
							oldType.operandOrOperator.typeFullNameAfterOperation = curType.str;
						}
						else if (curType.equals("java.lang.String")) {							
							if (operator.equals("+")) {
								// 이전 오퍼랜드는 String으로 바뀐다.
								oldType.setStrAndTypeFullName(curType.str, curType.typeFullName);
								oldType.operandOrOperator.typeFullNameAfterOperation = curType.str;
							}
							else {
								CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
								listOfTypes.count -= 2;
								return new CodeStringEx("null");
							}
							//return curType;
						}
						else {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}
					
					else if (oldType.equals("float")) {
						if (operator.indicesInSrc!=null && operator.indicesInSrc.getItem(0)==1970) {
						}
						if (curType.equals("boolean")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("byte") || curType.equals("char") || curType.equals("short") || curType.equals("int")) {
							// 현재 오퍼랜드는 float로 바뀐다.
							//allowsOperator(oldType, curType, operator);
							curType.operandOrOperator.typeFullNameAfterOperation = oldType.str;
						}
						else if (curType.equals("long")) {
							// 현재 오퍼랜드는 float로 바뀐다.
							//allowsOperator(oldType, curType, operator);
							curType.operandOrOperator.typeFullNameAfterOperation = oldType.str;
						}
						else if (curType.equals("float")) {
							//allowsOperator(oldType, curType, operator);
						}
						else if (curType.equals("double")) {
							// 이전 오퍼랜드는 double으로 바뀐다.
							//allowsOperator(oldType, curType, operator);
							oldType.setStrAndTypeFullName(curType.str, curType.typeFullName);
							oldType.operandOrOperator.typeFullNameAfterOperation = curType.str;
						}
						else if (curType.equals("java.lang.String")) {
							if (operator.equals("+")) {
								oldType.setStrAndTypeFullName(curType.str, curType.typeFullName);
								oldType.operandOrOperator.typeFullNameAfterOperation = curType.str;
							}
							else {
								CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
								listOfTypes.count -= 2;
								return new CodeStringEx("null");
							}
						}
						else {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}//else if (oldType.equals("float")) {
					else if (oldType.equals("double")) {
						if (curType.equals("boolean")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("byte") || curType.equals("char") || curType.equals("short") || curType.equals("int")) {
							// 현재 오퍼랜드는 double로 바뀐다.
							//allowsOperator(oldType, curType, operator);
							curType.operandOrOperator.typeFullNameAfterOperation = oldType.str;
						}
						else if (curType.equals("long")) {
							// 현재 오퍼랜드는 double로 바뀐다.
							//allowsOperator(oldType, curType, operator);
							curType.operandOrOperator.typeFullNameAfterOperation = oldType.str;
						}
						else if (curType.equals("float")) {
							// 현재 오퍼랜드는 double로 바뀐다.
							//FindVarUseParams v = (FindVarUseParams) listOfVarUses.list[i];
							//v.fullnameTypeCastByOperator = oldType;
							//allowsOperator(oldType, curType, operator);
							curType.operandOrOperator.typeFullNameAfterOperation = oldType.str;
						}
						else if (curType.equals("double")) {
							//allowsOperator(oldType, curType, operator);
						}
						else if (curType.equals("java.lang.String")) {
							if (operator.equals("+")) {
								oldType.setStrAndTypeFullName(curType.str, curType.typeFullName);
								oldType.operandOrOperator.typeFullNameAfterOperation = curType.str;
							}
							else {
								CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
								listOfTypes.count -= 2;
								return new CodeStringEx("null");
							}
						}
						else {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}//else if (oldType.equals("double")) {
					
					else if (oldType.equals("java.lang.String")) {
						if (CompilerHelper.getShortName(curType.str).equals("TextLine")) {
						}
						// 현재 오퍼랜드는 String으로 바뀐다.
						if (operator.equals("+")) {
							if (CompilerHelper.IsDefaultType(curType, compiler)) {
								if (curType.equals("void")) {
									CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
									listOfTypes.count -= 2;
									return new CodeStringEx("null");
								}
								curType.operandOrOperator.typeFullNameAfterOperation = oldType.str;
								listOfTypes.count -= 2;
								return oldType;
							}
							else if (curType.equals("java.lang.String")) {
								listOfTypes.count -= 2;
								return oldType;
							}
							
							else {
								// curType이 String이 아닌 다른 object일 경우
								CodeStringEx fullnameTypeCast1 = new CodeStringEx("java.lang.String");
								CodeStringEx fullnameTarget1 = curType;
								boolean isCompatible1 = 
										TypeCast_Syntax.isCompatibleType(compiler, compiler, fullnameTypeCast1, fullnameTarget1, 1, null, coreThreadID);
								if (isCompatible1) {
									// curType이 java.lang.String의 서브클래스일 경우
									//curType.typeFullNameAfterOperation = oldType.str;
									listOfTypes.count -= 2;
									curType.operandOrOperator.typeFullNameAfterOperation = oldType.str;
									return oldType;
								}
								else {
									// curType의 toString()함수가 호출되어야 한다.
									if (CompilerHelper.toStringFuncExists(compiler, curType.str, coreThreadID)) {
										//curType.typeFullNameAfterOperation = oldType.str;
										listOfTypes.count -= 2;
										curType.operandOrOperator.typeFullNameAfterOperation = oldType.str;
										return oldType;								
									}
									// curType의 toString()함수가 없으면 error를 발생시킨다.
									CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
									listOfTypes.count -= 2;
									return new CodeStringEx("null");
								}
							}
						}//+이면
						else { // +가 아니면
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}//else if (oldType.equals("java.lang.String")) {
					else {//oldType은 java.lang.String이 아닌 object이다.
						if (curType.equals("boolean")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("byte") || curType.equals("char") || curType.equals("short") || curType.equals("int")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("long")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("float") || curType.equals("double")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("java.lang.String")) {
							//return curType;
							CodeStringEx fullnameTypeCast1 = new CodeStringEx("java.lang.String");
							CodeStringEx fullnameTarget1 = oldType;
							boolean isCompatible1 = 
									TypeCast_Syntax.isCompatibleType(compiler, compiler, fullnameTypeCast1, fullnameTarget1, 1, null, coreThreadID);
							if (isCompatible1) {
								// oldType이 String의 서브 클래스일 경우
								if (operator.equals("+")) {
									listOfTypes.count -= 2;
									return curType;
								}
								else {
									CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
									listOfTypes.count -= 2;
									return new CodeStringEx("null");		
								}
							}
							else {
								// oldType의 toString()함수가 호출되어야 한다.
								if (CompilerHelper.toStringFuncExists(compiler, oldType.str, coreThreadID)) {
									//curType.typeFullNameAfterOperation = oldType.str;
									if (operator.equals("+")) {
										listOfTypes.count -= 2;
										return curType;
									}
									else {
										CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
										listOfTypes.count -= 2;
										return new CodeStringEx("null");
									}
								}
								// oldType이 toString()이 없으면								
								CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
								listOfTypes.count -= 2;
								return new CodeStringEx("null");
							}
						}//else if (curType.equals("java.lang.String")) {
						else { // oldType, curType 모두 java.lang.String이 아닌 경우
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}//// oldType, curType 모두 java.lang.String이 아닌 경우
					}//else {//oldType은 java.lang.String이 아닌 object이다.
				} // for (i=1; i<listOfTypes.count; i++) {
				
				// 스택에서 마지막 2개의 오퍼랜드를 빼낸다.
				listOfTypes.count -= 2;
				//listOfVarUses.count -= 2;
				
				return oldType;
			} //if (listOfTypes.count==2) {
		} // if (operator.equals("+") || operator.equals("-") || operator.equals("*") || operator.equals("/") || operator.equals("%") {
		
		// >, <, >=, <= 는 float-float가 가능하다.boolean-boolean불가능
		if (operator.equals(">") || operator.equals("<") || operator.equals(">=") || operator.equals("<=")) {
			if (listOfTypes.count>1) {
				oldType = (CodeStringEx) listOfTypes.getItem(listOfTypes.count-2);
				if (oldType==null) {
					listOfTypes.count -= 2;
					return new CodeStringEx("null");
				}
				oldType.operandOrOperator.affectedBy_left = operator;
				oldType.operandOrOperator.affectedBy = operator;
				operator.affectsLeft = oldType.operandOrOperator;
				for (i=listOfTypes.count-1; i<listOfTypes.count; i++) {
					curType = (CodeStringEx) listOfTypes.getItem(i);
					if (curType==null) {
						listOfTypes.count -= 2;
						return new CodeStringEx("null");
					}
					curType.operandOrOperator.affectedBy_right = operator;
					curType.operandOrOperator.affectedBy = operator;
					operator.affectsRight = curType.operandOrOperator;
					if (oldType.equals("boolean")) {
						if (curType.equals("boolean")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("java.lang.String")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}
					else if (oldType.equals("void")) {
						CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
						listOfTypes.count -= 2;
						return new CodeStringEx("null");
					}
					else if (oldType.equals("byte") || oldType.equals("char") || oldType.equals("short") || oldType.equals("int")) {
						if (curType.equals("boolean")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("byte") || curType.equals("char") || curType.equals("short") || curType.equals("int")) {
							oldType.operandOrOperator.typeFullNameAfterOperation = "int";
							curType.operandOrOperator.typeFullNameAfterOperation = "int";
							oldType.str = "boolean";
						}
						else if (curType.equals("long")) {
							// 바이트코드에서 int 비교밖에 없으므로 oldType, curType 모두 int로 바꾼다.
							oldType.operandOrOperator.typeFullNameAfterOperation = "long";
							oldType.str = "boolean";
						}
						else if (curType.equals("float")) {
							// 바이트코드에서 int 비교밖에 없으므로 oldType, curType 모두 int로 바꾼다.
							oldType.operandOrOperator.typeFullNameAfterOperation = "float";
							oldType.str = "boolean";
						}
						else if (curType.equals("double")) {
							oldType.operandOrOperator.typeFullNameAfterOperation = "double";
							oldType.str = "boolean";
						}
						
						else if (curType.equals("java.lang.String")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}//else if (oldType.equals("byte") || oldType.equals("char") || oldType.equals("short") || oldType.equals("int")) {
					
					else if (oldType.equals("long")) {
						if (curType.equals("boolean")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("byte") || curType.equals("char") || curType.equals("short") || curType.equals("int")) {
							// 바이트코드에서 int 비교밖에 없으므로 oldType, curType 모두 int로 바꾼다.
							curType.operandOrOperator.typeFullNameAfterOperation = "long";
							oldType.str = "boolean";
						}
						else if (curType.equals("long")) {
							oldType.str = "boolean";
						}
						else if (curType.equals("float")) {
							//oldType = new CodeStringEx("boolean");
							oldType.operandOrOperator.typeFullNameAfterOperation = "float";
							oldType.str = "boolean";
						}
						else if (curType.equals("double")) {
							oldType.operandOrOperator.typeFullNameAfterOperation = "double";
							oldType.str = "boolean";
						}
						
						else if (curType.equals("java.lang.String")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}//else if (oldType.equals("long")) {
					else if (oldType.equals("float")) {
						if (curType.equals("boolean")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("byte") || curType.equals("char")|| curType.equals("short") || curType.equals("int")) {
							curType.operandOrOperator.typeFullNameAfterOperation = "float";
							oldType.str = "boolean";
						}
						else if (curType.equals("long")) {
							curType.operandOrOperator.typeFullNameAfterOperation = "float";
							oldType.str = "boolean";
							//oldType = new CodeStringEx("boolean");
						}
						else if (curType.equals("float")) {
							oldType.str = "boolean";
							//oldType = new CodeStringEx("boolean");
						}
						else if (curType.equals("double")) {
							oldType.operandOrOperator.typeFullNameAfterOperation = "double";
							oldType.str = "boolean";
							//oldType = new CodeStringEx("boolean");
						}
						
						else if (curType.equals("java.lang.String")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}//else if (oldType.equals("float")) {
					else if (oldType.equals("double")) {
						if (curType.equals("boolean")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("byte") || curType.equals("char")|| curType.equals("short") || curType.equals("int")) {
							curType.operandOrOperator.typeFullNameAfterOperation = "double";
							oldType.str = "boolean";
						}
						else if (curType.equals("long")) {
							curType.operandOrOperator.typeFullNameAfterOperation = "double";
							oldType.str = "boolean";
						}
						else if (curType.equals("float")) {
							curType.operandOrOperator.typeFullNameAfterOperation = "double";
							oldType.str = "boolean";
							//oldType = new CodeStringEx("boolean");
						}
						else if (curType.equals("double")) {
							oldType.str = "boolean";
							//oldType = new CodeStringEx("boolean");
						}
						
						else if (curType.equals("java.lang.String")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}//else if (oldType.equals("double")) {
					
					else if (oldType.equals("java.lang.String")) {
						// 현재 오퍼랜드는 String으로 바뀐다.
						CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
						listOfTypes.count -= 2;
						return new CodeStringEx("null");
					}
					else {
						if (curType.equals("boolean")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("byte") || curType.equals("char") || curType.equals("short") || curType.equals("int")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("long")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("float") || curType.equals("double")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("java.lang.String")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}
				} // for (i=1; i<listOfTypes.count; i++) {
				
				// 스택에서 마지막 2개의 오퍼랜드를 빼낸다.
				listOfTypes.count -= 2;
				//listOfVarUses.count -= 2;
				
				return oldType;
			} //if (listOfTypes.count==2) {
		} // if (operator.equals("<") || operator.equals(">") || operator.equals("<=") || operator.equals(">=")) {
		
		// ^, <<, >>, |, &, ~(정수만, 단항) 는 정수-정수만 가능하다.
		if (operator.equals("<<") || operator.equals(">>") || operator.equals("<<<") || operator.equals(">>>") ||
			operator.equals("&") || operator.equals("|") || operator.equals("^")) {
			if (operator.equals("|")) {
			}
			if (listOfTypes.count>1) {
				oldType = (CodeStringEx) listOfTypes.getItem(listOfTypes.count-2);
				if (oldType==null) {
					CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+"null"));
					listOfTypes.count -= 2;
					return new CodeStringEx("null");
				}
				oldType.operandOrOperator.affectedBy_left = operator;
				oldType.operandOrOperator.affectedBy = operator;
				operator.affectsLeft = oldType.operandOrOperator;
				for (i=listOfTypes.count-1; i<listOfTypes.count; i++) {
					curType = (CodeStringEx) listOfTypes.getItem(i);
					if (curType==null) {
						CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, 
								"invalid expression : ("+operator.str+") "+oldType+", "+"null"));
						listOfTypes.count -= 2;
						return new CodeStringEx("null");
					}
					curType.operandOrOperator.affectedBy_right = operator;
					curType.operandOrOperator.affectedBy = operator;
					operator.affectsRight = curType.operandOrOperator;
					if (oldType.equals("boolean")) {
						if (curType.equals("boolean")) {							
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("java.lang.String")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}
					else if (oldType.equals("void")) {
						CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
						listOfTypes.count -= 2;
						return new CodeStringEx("null");
					}
					else if (oldType.equals("byte") || oldType.equals("char") || oldType.equals("short") || oldType.equals("int")) {
						if (curType.equals("boolean")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("byte") || curType.equals("char") || curType.equals("short") || curType.equals("int")) {
							oldType.setStrAndTypeFullName("int", "int");							
						}						
						else if (curType.equals("long")) {
							if (!(operator.equals("&") || operator.equals("|") || operator.equals("^"))) {
								// in only shift operator
								// typecasts curType to "int"
								curType.operandOrOperator.typeFullNameAfterOperation = "int";
								// computation result
								oldType.setStrAndTypeFullName("int", "int");
							}
							else {
								// intValue & longValue
								oldType.operandOrOperator.typeFullNameAfterOperation = curType.str;
								// computation result
								oldType.setStrAndTypeFullName(curType.str, curType.str);
							}
							
						}
						else if (curType.equals("float") || curType.equals("double")) {
							// 이전 오퍼랜드는 float나 double으로 바뀐다.
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("java.lang.String")) {
							// 이전 오퍼랜드는 String으로 바뀐다.
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}//else if (oldType.equals("int") || oldType.equals("short") || oldType.equals("long")) {
					else if (oldType.equals("long")) {
						if (curType.equals("boolean")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("byte") || curType.equals("char") || curType.equals("short") || curType.equals("int")) {
							if (!(operator.equals("&") || operator.equals("|") || operator.equals("^"))) {
								// in only shift operator
								// computation result
								oldType.setStrAndTypeFullName("long", "long");
							}
							else {
								// longValue & intValue
								curType.operandOrOperator.typeFullNameAfterOperation = oldType.str;
								// computation result
								oldType.setStrAndTypeFullName("long", "long");
							}
						}
						else if (curType.equals("long")) {
							if (!(operator.equals("&") || operator.equals("|") || operator.equals("^"))) {
								// in only shift operator
								// typecasts curType to "int"
								curType.operandOrOperator.typeFullNameAfterOperation = "int";
								// computation result
								oldType.setStrAndTypeFullName("long", "long");
							}
							else {
								// computation result
								oldType.setStrAndTypeFullName("long", "long");
							}
							
						}
						else if (curType.equals("float") || curType.equals("double")) {
							// 이전 오퍼랜드는 float나 double으로 바뀐다.
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("java.lang.String")) {
							// 이전 오퍼랜드는 String으로 바뀐다.
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}//else if (oldType.equals("long")) {
					else if (oldType.equals("float") || oldType.equals("double")) {
						if (curType.equals("boolean")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("byte") || curType.equals("char") || curType.equals("short") || curType.equals("int")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("long")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("float")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("double")) {
							// 이전 오퍼랜드는 double으로 바뀐다.
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("java.lang.String")) {							
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}//else if (oldType.equals("float") || oldType.equals("double")) {
					
					
					else if (oldType.equals("java.lang.String")) {
						CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
						listOfTypes.count -= 2;
						return new CodeStringEx("null");
					}
					else {
						if (curType.equals("boolean")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("byte") || curType.equals("char") || curType.equals("short") || curType.equals("int") || curType.equals("long")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("float") || curType.equals("double")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("java.lang.String")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}
				} // for (i=1; i<listOfTypes.count; i++) {
				
				// 스택에서 마지막 2개의 오퍼랜드를 빼낸다.
				listOfTypes.count -= 2;
				//listOfVarUses.count -= 2;
				
				return oldType;
			} //if (listOfTypes.count==2) {
		}//if (operator.equals("^") || operator.equals("<<") || operator.equals(">>") || 
		//operator.equals("&") || operator.equals("|")) {
		
		// &&, ||, !(단항) float-float가 불가능하다.boolean-boolean만 가능하다.
		if (operator.equals("&&") || operator.equals("||")) {
			if (listOfTypes.count>1) {
				oldType = (CodeStringEx) listOfTypes.getItem(listOfTypes.count-2);
				if (oldType==null) {
					CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+"null"));
					listOfTypes.count -= 2;
					return new CodeStringEx("null");
				}
				oldType.operandOrOperator.affectedBy_left = operator;
				oldType.operandOrOperator.affectedBy = operator;
				operator.affectsLeft = oldType.operandOrOperator;
				for (i=listOfTypes.count-1; i<listOfTypes.count; i++) {
					curType = (CodeStringEx) listOfTypes.getItem(i);
					if (curType==null) {
						CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, 
								"invalid expression : ("+operator.str+") "+oldType+", "+"null"));
						listOfTypes.count -= 2;
						return new CodeStringEx("null");
					}
					curType.operandOrOperator.affectedBy_right = operator;
					curType.operandOrOperator.affectedBy = operator;
					operator.affectsRight = curType.operandOrOperator;
					if (oldType.equals("boolean")) {
						if (curType.equals("boolean")) {
						}
						else if (curType.equals("java.lang.String")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}
					else if (oldType.equals("void")) {
						CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
						listOfTypes.count -= 2;
						return new CodeStringEx("null");
					}
					else if (oldType.equals("byte") || oldType.equals("char") || oldType.equals("short") || oldType.equals("int") || oldType.equals("long")) {
						if (curType.equals("boolean")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("byte") || curType.equals("char") || curType.equals("short") || curType.equals("int")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("long")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("float") || curType.equals("double")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("java.lang.String")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}
					else if (oldType.equals("float")) {
						if (curType.equals("boolean")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("byte") || curType.equals("char") || curType.equals("short") || curType.equals("int") || curType.equals("long")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("float")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("double")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("java.lang.String")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}
					else if (oldType.equals("double")) {
						if (curType.equals("boolean")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("byte") || curType.equals("char") || curType.equals("short") || curType.equals("int") || curType.equals("long")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("float")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("double")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("java.lang.String")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}
					
					else if (oldType.equals("java.lang.String")) {
						// 현재 오퍼랜드는 String으로 바뀐다.
						CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
						listOfTypes.count -= 2;
						return new CodeStringEx("null");
					}
					else {
						if (curType.equals("boolean")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("byte") || curType.equals("char") || curType.equals("short") || curType.equals("int") || curType.equals("long")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("float") || curType.equals("double")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("java.lang.String")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}
				} // for (i=1; i<listOfTypes.count; i++) {
				
				// 스택에서 마지막 2개의 오퍼랜드를 빼낸다.
				listOfTypes.count -= 2;
				//listOfVarUses.count -= 2;
				
				return oldType;
			} //if (listOfTypes.count==2) {
		}//if (operator.equals("&&") || operator.equals("||")) {
		
		
		if (operator.equals("==") || operator.equals("!=")) {
			if (listOfTypes.count>1) {
				oldType = (CodeStringEx) listOfTypes.getItem(listOfTypes.count-2);
				if (oldType==null) {
					CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+"null"));
					listOfTypes.count -= 2;
					return new CodeStringEx("null");
				}
				oldType.operandOrOperator.affectedBy_left = operator;
				oldType.operandOrOperator.affectedBy = operator;
				operator.affectsLeft = oldType.operandOrOperator;
				for (i=listOfTypes.count-1; i<listOfTypes.count; i++) {
					curType = (CodeStringEx) listOfTypes.getItem(i);
					if (curType==null) {
						CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, 
								"invalid expression : ("+operator.str+") "+oldType+", "+"null"));
						listOfTypes.count -= 2;
						return new CodeStringEx("null");
					}
					curType.operandOrOperator.affectedBy_right = operator;
					curType.operandOrOperator.affectedBy = operator;
					operator.affectsRight = curType.operandOrOperator;
					if (oldType.equals("boolean")) {
						if (curType.equals("boolean")) {
							oldType = new CodeStringEx("boolean");
						}
						else if (curType.equals("java.lang.String")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}
					else if (oldType.equals("void")) {
						CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
						listOfTypes.count -= 2;
						return new CodeStringEx("null");
					}
					else if (oldType.equals("byte") || oldType.equals("char") || oldType.equals("short") || oldType.equals("int")) {
						if (curType.equals("boolean")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("byte") || curType.equals("char") || curType.equals("short") || curType.equals("int")) {
							oldType = new CodeStringEx("boolean");
						}					
						else if (curType.equals("long")) {
							oldType.operandOrOperator.typeFullNameAfterOperation = curType.str;
							oldType = new CodeStringEx("boolean");
						}
						else if (curType.equals("float") || curType.equals("double")) {
							oldType.operandOrOperator.typeFullNameAfterOperation = curType.str;
							oldType = new CodeStringEx("boolean");
						}						
						else if (curType.equals("java.lang.String")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}//else if (oldType.equals("byte") || oldType.equals("char") || oldType.equals("short") || oldType.equals("int")) {
					else if (oldType.equals("long")) {
						if (curType.equals("boolean")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("byte") || curType.equals("char") || curType.equals("short") || curType.equals("int")) {
							// curType은 oldType으로 바뀐다.
							curType.operandOrOperator.typeFullNameAfterOperation = oldType.str;
							oldType = new CodeStringEx("boolean");
						}
						else if (curType.equals("long")) {
							oldType = new CodeStringEx("boolean");
						}
						else if (curType.equals("float") || curType.equals("double")) {
							// oldType은 curType으로 바뀐다.
							oldType.operandOrOperator.typeFullNameAfterOperation = curType.str;
							oldType = new CodeStringEx("boolean");
						}
						else if (curType.equals("java.lang.String")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}//else if (oldType.equals("long")) {
					else if (oldType.equals("float")) {
						if (curType.equals("boolean")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("byte") || curType.equals("char") || curType.equals("short") || curType.equals("int")) {
							curType.operandOrOperator.typeFullNameAfterOperation = oldType.str;
							oldType = new CodeStringEx("boolean");
						}
						else if (curType.equals("long")) {
							curType.operandOrOperator.typeFullNameAfterOperation = oldType.str;
							oldType = new CodeStringEx("boolean");
						}
						else if (curType.equals("float")) {
							oldType = new CodeStringEx("boolean");
						}
						else if (curType.equals("double")) {
							oldType.operandOrOperator.typeFullNameAfterOperation = curType.str;
							oldType = new CodeStringEx("boolean");
						}
						else if (curType.equals("java.lang.String")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}//else if (oldType.equals("float")) {
					else if (oldType.equals("double")) {
						if (curType.equals("boolean")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("byte") || curType.equals("char") || curType.equals("short") || curType.equals("int")) {
							curType.operandOrOperator.typeFullNameAfterOperation = oldType.str;
							oldType = new CodeStringEx("boolean");
						}
						else if (curType.equals("long")) {
							curType.operandOrOperator.typeFullNameAfterOperation = oldType.str;
							oldType = new CodeStringEx("boolean");
						}
						else if (curType.equals("float")) {
							oldType = new CodeStringEx("boolean");
						}
						else if (curType.equals("double")) {
							oldType = new CodeStringEx("boolean");
						}
						else if (curType.equals("java.lang.String")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}//else if (oldType.equals("double")) {
					
					else if (oldType.equals("java.lang.String")) {
						// 현재 오퍼랜드는 String으로 바뀐다.
						//FindVarUseParams v = (FindVarUseParams) listOfVarUses.list[i];
						//v.fullnameTypeCastByOperator = oldType;
						//return oldType;
						if (curType.equals("null")) { // if (str==null) 에서 스택에는 str, "null", ==
							oldType = new CodeStringEx("boolean");
						}
						else if (curType.equals("java.lang.String")) { // if (str1==str2) 에서 스택에는 str1, str2, ==
							oldType = new CodeStringEx("boolean");
						}
						else if (CompilerHelper.IsDefaultType(curType, compiler)) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else { // if (str==obj)
							boolean b = TypeCast_Syntax.isCompatibleType(compiler, compiler, oldType, curType, 0, null, coreThreadID);
							if (!b) {
								CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
								listOfTypes.count -= 2;
								return new CodeStringEx("null");
							}
						}
					}// else if (oldType.equals("java.lang.String")) {
					else {
						if (curType.equals("boolean")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("int") || curType.equals("short") || curType.equals("long")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("float") || curType.equals("double")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("byte") || curType.equals("char")) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("java.lang.String")) {
							boolean b = TypeCast_Syntax.isCompatibleType(compiler, compiler, oldType, curType, 0, null, coreThreadID);
							if (!b) {
								CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
								listOfTypes.count -= 2;
								return new CodeStringEx("null");
							}
							else {
								oldType = new CodeStringEx("boolean");
							}
						}
						else {
							//CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							boolean b = TypeCast_Syntax.isCompatibleType(compiler, compiler, oldType, curType, 0, null, coreThreadID);
							if (!b) {
								CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
								listOfTypes.count -= 2;
								return new CodeStringEx("null");
							}
							else {
								oldType = new CodeStringEx("boolean");
							}
						}
					}
				} // for (i=1; i<listOfTypes.count; i++) {
				
				// 스택에서 마지막 2개의 오퍼랜드를 빼낸다.
				listOfTypes.count -= 2;
				//listOfVarUses.count -= 2;
				
				return oldType;
			} //if (listOfTypes.count==2) {
		}//if (operator.equals("==") || operator.equals("!=")) {
		
		
		else if (operator.equals("instanceof")) {
			if (listOfTypes.count>1) {
				oldType = (CodeStringEx) listOfTypes.getItem(listOfTypes.count-2);
				if (oldType==null) {
					CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+"null"));
					listOfTypes.count -= 2;
					return new CodeStringEx("null");
				}
				oldType.operandOrOperator.affectedBy_left = operator;
				oldType.operandOrOperator.affectedBy = operator;
				operator.affectsLeft = oldType.operandOrOperator;
				for (i=listOfTypes.count-1; i<listOfTypes.count; i++) {
					curType = (CodeStringEx) listOfTypes.getItem(i);
					if (curType==null) {
						CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, 
								"invalid expression : ("+operator.str+") "+oldType+", "+"null"));
						listOfTypes.count -= 2;
						return new CodeStringEx("null");
					}
					curType.operandOrOperator.affectedBy_right = operator;
					curType.operandOrOperator.affectedBy = operator;
					operator.affectsRight = curType.operandOrOperator;
					if (CompilerHelper.IsDefaultType(oldType, compiler)) {
						CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
						listOfTypes.count -= 2;
						return new CodeStringEx("null");
					}
					else {
						//else if (sender instanceof MenuProblemList) 
						boolean b = TypeCast_Syntax.isCompatibleType(compiler, compiler, oldType, curType, 1, null, coreThreadID);
						if (!b) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							oldType = new CodeStringEx("boolean");
						}
					}
				}// for (i=1; i<listOfTypes.count; i++) {
				
				// 스택에서 마지막 2개의 오퍼랜드를 빼낸다.
				listOfTypes.count -= 2;
				//listOfVarUses.count -= 2;
				
				return oldType;
			} //if (listOfTypes.count>1) {
		}//if (operator.equals("instanceof")) {
		
		else if (operator.str.contains("=")) { // =, +=, -= 등
		//else if (CompilerHelper.IsAssignOperator(op1, op2, op3))
			if (operator.indicesInSrc!=null && operator.indicesInSrc.getItem(0)==17591) {
			}
			
			if (operator.count>1) {
				// traverseCompositiveEqualOperator()을 참조한다.
				boolean operatorError = false;
				CodeStringEx op1 = new CodeStringEx(""+operator.str.charAt(0));
				if (op1.equals("<")) {
					
					if (operator.str.length()!=3) operatorError = true;
					else if (operator.str.charAt(1)!='<') operatorError = true;
					if (operatorError) {
						CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, 
								"invalid operator : ("+operator.str+") "));
						listOfTypes.count -= 2;
						return new CodeStringEx("null");
					}
					else {// '<<='
						op1 = new CodeStringEx("<<");
					}
				}
				if (!operatorError) {
					// "<<=", "+=", "-=" 등의 복합 대입연산자의 경우
					CodeStringEx type = getTypeOfOperator(compiler, funcCall, listOfTypes, op1, coreThreadID);
					return type;
				}
			}//if (operator.count>1) {
			//else { // '='
				if (listOfTypes.count>1) {
					oldType = (CodeStringEx) listOfTypes.getItem(listOfTypes.count-2);
					if (oldType==null) {
						CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+"null"));
						listOfTypes.count -= 2;
						return new CodeStringEx("null");
					}
					oldType.operandOrOperator.affectedBy_left = operator;
					oldType.operandOrOperator.affectedBy = operator;
					operator.affectsLeft = oldType.operandOrOperator;
					for (i=listOfTypes.count-1; i<listOfTypes.count; i++) {
						curType = (CodeStringEx) listOfTypes.getItem(i);
						if (curType==null || (curType!=null && curType.equals(""))) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, 
								"invalid expression : ("+operator.str+") "+oldType+", "+"null"));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						curType.operandOrOperator.affectedBy_right = operator;
						curType.operandOrOperator.affectedBy = operator;
						operator.affectsRight = curType.operandOrOperator;
						if (!TypeCast_Syntax.isCompatibleType(compiler, compiler, oldType, curType, 1, null, coreThreadID)) {
							CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, 
									"invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}// for (i=1; i<listOfTypes.count; i++) {
					
					// 스택에서 마지막 2개의 오퍼랜드를 빼낸다.
					listOfTypes.count -= 2;
					//listOfVarUses.count -= 2;
					
					return oldType;
				} //if (listOfTypes.count>1) {
			//}
		}//else if (operator.str.contains("=")) { // =, +=, -= 등
		
		
		CompilerStatic.errors.add(new Error(compiler, startIndex, endIndex, 
				"invalid operator : ("+operator.str+") "));
		return new CodeStringEx("null");
	}//getTypeOfOperator()


/** 숫자 상수에 대해서 실제로 연산을 하여 그 값을 operator의 value에 저장한다. 
 * number1, number2가 숫자상수가 아니면 false를 리턴한다.
 * 계산된 값은 operator의 value에 저장된다. 
 * 그리고 operator의 타입을 설정한다. value가 있으면 value에 맞게 타입을 바꾼다.*/
/*public static 
	boolean allowsOperator(CodeStringEx number1, CodeStringEx number2, CodeStringEx operator) {
		if (number1==null) return false;
		if (number1.str==null) return false;
		
		try {
			// float, double이 아니면
		if (!(number1.str.equals("float") || number1.str.equals("double"))) {
			if ((operator.equals("+")  && operator.isPlusOrMinusForOne) || 
					(operator.equals("-") && operator.isPlusOrMinusForOne)) {
				try {
					Integer.parseInt(number1.value);
					String strValue = operator.str + number1.value;
					int r = Integer.parseInt(strValue);
					operator.value = String.valueOf(r);
					return true;
				}catch(Exception e) {
					return false;
				}
			} // 단항연산자
			else if ((operator.equals("+") && !operator.isPlusOrMinusForOne) || 
					(operator.equals("-") && !operator.isPlusOrMinusForOne) || 
					operator.equals("*") || operator.equals("/") ||	operator.equals("%")) {
				int i1;
				try {
					i1 = Integer.parseInt(number1.value);
				}catch(Exception e) {
					return false;
				}	
				if (operator.equals("+")) {
					try {
						int i2 = Integer.parseInt(number2.value);
						String strValue = String.valueOf(i1+i2);
						int r = Integer.parseInt(strValue);
						operator.value = String.valueOf(r);
						return true;							
					}catch(Exception e) {
						return false;
					}
				}
				else if (operator.equals("-")) {
					try {
						int i2 = Integer.parseInt(number2.value);
						String strValue = String.valueOf(i1-i2);
						int r = Integer.parseInt(strValue);
						operator.value = String.valueOf(r);
						return true;							
					}catch(Exception e) {
						return false;
					}
				}
				else if (operator.equals("*")) {
					try {
						int i2 = Integer.parseInt(number2.value);
						String strValue = String.valueOf(i1*i2);
						int r = Integer.parseInt(strValue);
						operator.value = String.valueOf(r);
						return true;							
					}catch(Exception e) {
						return false;
					}
				}
				else if (operator.equals("/")) {
					try {
						int i2 = Integer.parseInt(number2.value);
						String strValue = String.valueOf(i1/i2);
						int r = Integer.parseInt(strValue);
						operator.value = String.valueOf(r);
						return true;							
					}catch(Exception e) {
						return false;
					}
				}
				
			}//else if ((operator.equals("+") && operator.isPlusOrMinusForOne==false) || 
			//(operator.equals("-") && operator.isPlusOrMinusForOne==false) || 
			//operator.equals("*") || operator.equals("/") ||	operator.equals("%")) {
			else if (operator.equals("^") || 
					operator.equals("<<") || operator.equals(">>") || operator.equals("<<<") || operator.equals(">>>") ||
					operator.equals("&") || operator.equals("|")) {
				int i1;
				try {
					i1 = Integer.parseInt(number1.value);
				}catch(Exception e) {
					return false;
				}	
				if (operator.equals("^")) {
					try {
						int i2 = Integer.parseInt(number2.value);
						String strValue = String.valueOf(i1^i2);
						int r = Integer.parseInt(strValue);
						operator.value = String.valueOf(r);
						return true;							
					}catch(Exception e) {
						return false;
					}
				}
				else if (operator.equals("<<")) {
					try {
						int i2 = Integer.parseInt(number2.value);
						String strValue = String.valueOf(i1<<i2);
						int r = Integer.parseInt(strValue);
						operator.value = String.valueOf(r);
						return true;							
					}catch(Exception e) {
						return false;
					}
				}
				else if (operator.equals(">>")) {
					try {
						int i2 = Integer.parseInt(number2.value);
						String strValue = String.valueOf(i1>>i2);
						int r = Integer.parseInt(strValue);
						operator.value = String.valueOf(r);
						return true;							
					}catch(Exception e) {
						return false;
					}
				}
				else if (operator.equals("&")) {
					try {
						int i2 = Integer.parseInt(number2.value);
						String strValue = String.valueOf(i1&i2);
						int r = Integer.parseInt(strValue);
						operator.value = String.valueOf(r);
						return true;							
					}catch(Exception e) {
						return false;
					}
				}
				else if (operator.equals("|")) {
					try {
						int i2 = Integer.parseInt(number2.value);
						String strValue = String.valueOf(i1|i2);
						int r = Integer.parseInt(strValue);
						operator.value = String.valueOf(r);
						return true;							
					}catch(Exception e) {
						return false;
					}
				}
				
			}//else if (operator.equals("^") || 
			//operator.equals("<<") || operator.equals(">>") || operator.equals("<<<") || operator.equals(">>>") ||
			//operator.equals("&") || operator.equals("|")) {
		}
		else { // float, double
			if ((operator.equals("+")  && operator.isPlusOrMinusForOne) || 
					(operator.equals("-") && operator.isPlusOrMinusForOne)) {
				try {
					Float.parseFloat(number1.value);
					String strValue = operator.str + number1.value;
					float r = Float.parseFloat(strValue);
					operator.value = String.valueOf(r);
					return true;
				}catch(Exception e) {
					return false;
				}
			} // 단항연산자
			else if ((operator.equals("+") && !operator.isPlusOrMinusForOne) || 
					(operator.equals("-") && !operator.isPlusOrMinusForOne) || 
					operator.equals("*") || operator.equals("/") ||	operator.equals("%")) {
				float f1;
				try {
					f1 = Float.parseFloat(number1.value);
				}catch(Exception e) {
					return false;
				}	
				if (operator.equals("+")) {
					try {
						float f2 = Float.parseFloat(number2.value);
						String strValue = String.valueOf(f1+f2);
						operator.value = strValue;
						return true;							
					}catch(Exception e) {
						return false;
					}
				}
				else if (operator.equals("-")) {
					try {
						float f2 = Float.parseFloat(number2.value);
						String strValue = String.valueOf(f1-f2);
						operator.value = strValue;
						return true;							
					}catch(Exception e) {
						return false;
					}
				}
				else if (operator.equals("*")) {
					try {
						float f2 = Float.parseFloat(number2.value);
						String strValue = String.valueOf(f1*f2);
						operator.value = strValue;
						return true;							
					}catch(Exception e) {
						return false;
					}
				}
				else if (operator.equals("/")) {
					try {
						float f2 = Float.parseFloat(number2.value);
						String strValue = String.valueOf(f1/f2);
						operator.value = strValue;
						return true;							
					}catch(Exception e) {
						return false;
					}
				}
				
			}//else if ((operator.equals("+") && operator.isPlusOrMinusForOne==false) || 
			//(operator.equals("-") && operator.isPlusOrMinusForOne==false) || 
			//operator.equals("*") || operator.equals("/") ||	operator.equals("%")) {
			else if (operator.equals("^")) {
				return false;
			}
				
		}
		}finally {
			// value에 따라서 type을 정한다.
			if (operator.value!=null) {
				if (!operator.value.contains(".")) {
					long value = Long.parseLong(operator.value);
					operator.typeFullName = CompilerHelper.getType(value);
				}
				else {
					if (number1!=null && number1.typeFullName!=null && 
							number2!=null && number2.typeFullName!=null) {
						// float, double
						if (number1.typeFullName.equals("double") || number2.typeFullName.equals("double")) {
							operator.typeFullName = "double";
						}
						else {
							operator.typeFullName = "float";
						}
					}
					else {
						operator.typeFullName = "float";
					}
				}
			}
		}
		return false;
	}//allowsOperator()*/
}
