package com.gsoft.common.compiler;

import java.io.File;

import android.graphics.Point;

import com.gsoft.common.Code.CodeStringType;
import com.gsoft.common.CommonGUI;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.FileHelper;
import com.gsoft.common.interfaces.IReset;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.Compiler_types.FindFunctionParams;
import com.gsoft.common.compiler.Compiler_types.FindVarParams;
import com.gsoft.common.compiler.Compiler_types.FindVarUseParams;
import com.gsoft.common.compiler.Compiler_types.Language;
import com.gsoft.common.compiler.Compiler_types.ModeAllOrUpdate;
import com.gsoft.common.compiler.Compiler_types_Base.Comment;
import com.gsoft.common.compiler.Compiler_types_Base.Error;
import com.gsoft.common.compiler.Compiler_types_Base.FindStatementParams;
import com.gsoft.common.compiler.Compiler_types_Special.Constructor;
import com.gsoft.common.compiler.Compiler_types_Special.ErrorList;
import com.gsoft.common.compiler.gui.CurPathText;
import com.gsoft.common.compiler.util.Builder;
import com.gsoft.common.gui.Buttons.Button;
import com.gsoft.common.gui.Control;
import com.gsoft.common.gui.LoggingScrollable;
import com.gsoft.common.util.Array;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListIReset;
import com.gsoft.common.util.ArrayListInt;
import com.gsoft.common.util.HighArray;
import com.gsoft.common.util.HighArray_CodeChar;
import com.gsoft.common.util.hash.Hashtable2_String;
import com.gsoft.common.util.hash.Hashtable2_String.HashItem;
import com.gsoft.common.compiler.EditText_Compiler;
import com.gsoft.common.compiler.CompilerStatic;
import com.gsoft.common.compiler.CompilerData;
import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.InterfaceErrorResolver;

/**증감컴파일러*/
@SuppressWarnings("unused")
public class Update {
	
	
	
	/**주기적으로 루프를 돌면서 사용자가 키를 입력하고 난후 일정시간이 지나면 
	 * Update를 수행하는 스레드
	 * @author kjy
	 *
	 */
	static class ThreadTimer extends Thread {
		boolean exitLoop;
		
		ThreadTimer() {
		}
		public void run() {
			EditText_Compiler editText_compiler = CommonGUI.editText_compiler;			
			while (!exitLoop /*&& editText_compiler.getCompiler()!=null*/) {
				try {
					boolean didUpdate = false;
					QueueItem lastItem = null;
					Compiler compiler = null;
					Point cursorPos = null;
					long keyPressedTime = 0;
					long curTime = 0; 
					long diff = 0;
					boolean keyPressed = false;
					synchronized (Update.listOfQueueItems) {
						if (Update.listOfQueueItems.count>0) {
							keyPressed = true;
							lastItem = (QueueItem) Update.listOfQueueItems.getItem(Update.listOfQueueItems.count-1);
							compiler = lastItem.compiler;
							cursorPos = lastItem.cursorPos;
							keyPressedTime = lastItem.keyPressedTime;
							curTime = System.currentTimeMillis(); 
							diff = curTime - keyPressedTime;
						}// if (Update.listOfQueueItems.count>0) {
					}// synchronized (Update.listOfQueueItems) {	
							//if (diff>1000) {								
								//if (item.allOrPart) {
					if (keyPressed) {
									//Update.isUpdating = true;
									
									Update.updateAllRightNow(0);
									didUpdate = true;
									
									// 업데이트를 하는 도중에도 update(String charA)을 통해서 사용자가 키를 입력할 수 있도록 한다.
									CurPathText.setCurPathTextPlusProjectName(compiler, cursorPos.x, cursorPos.y, 
											editText_compiler.getShowsCurPath());
									if (lastItem.charA.equals(".")) {
										compiler.data.menuClassAndMemberListWhenInputtingDot.filter = "all";
										editText_compiler.inputDot(compiler, "all");
									}
									Control.view.postInvalidate();
									
									//Update.isUpdating = false;
					}
								//}								
							//}
						
					if (didUpdate) {
						String dirName = FileHelper.getDirectory(editText_compiler.getCompiler().data.filename);
						long packageSize = Update.getPackageSize(dirName);
						if (packageSize > 10000) Thread.sleep(4000); // packageSize > 10k
						else Thread.sleep(2000);
					}
					else {
						Thread.sleep(2000);
					}
				} catch (Exception e) {
					if (Common_Settings.g_printsLog) e.printStackTrace();
				}
			}// while (!exitLoop && this.editText_compiler.getCompiler()!=null) {
		}// public void run() {
	}
	
	/** Sums length of files in dir*/
	static long getPackageSize(String dir) {
		ArrayList list = FileHelper.getFileList(dir, false);
		long r = 0;
		for (int i=0; i<list.count; i++) {
			File file = (File)list.getItem(i);
			r += file.length();
		}
		return r;
	}
	
	static ThreadTimer mThreadTimer;
	
	/**Update를 수행하는 ThreadTimer를 생성하고 start()를 실행한다.
	 * 자바파일을 여러개 열어도 Update스레드는 단 하나이다.
	 탭버튼을 눌러 파일을 전환할때나 새로운 자바파일을 열때는
	 즉시 업데이트를 수행한다.
	 * 기존 스레드가 있으면 즉시 업데이트를 수행한다. */
	public static ThreadTimer createThreadTimerAndStart() {
		/*if (mThreadTimer!=null) {
			// 기존 스레드를 종료시킨다.
			mThreadTimer.exitLoop = true;
		}
		mThreadTimer = new ThreadTimer();
		mThreadTimer.start();
		return mThreadTimer;*/
		
		if (mThreadTimer!=null) {
			// coreThreadID 0 : 코어를 하나만 사용한다.
			//Update.updateAllRightNow(0);
			return null;
		}
		mThreadTimer = new ThreadTimer();
		mThreadTimer.start();
		return mThreadTimer;
	}
	
	static class QueueItem {
		public Point cursorPos;
		long keyPressedTime;
		String charA;
		/**changed compiler that user inputs any key on.*/
		Compiler compiler;
		
		QueueItem(Compiler compiler, Point cursorPos, long keyPressedTime, String charA) {
			this.compiler = compiler;
			this.cursorPos = cursorPos;
			this.keyPressedTime = keyPressedTime;
			this.charA = charA;
		}
	}
	
	/**사용자가 자바 파일을 연후 키를 입력하면 Update.update()에서 이 버퍼에 넣어진다.*/
	static ArrayList listOfQueueItems = new ArrayList(10); 
	

	/** QueueItem을 만들어서 큐에 넣는다.*/
	public static void update(String charA) {
		Compiler compiler = CommonGUI.editText_compiler.getCompiler();
		Point cursorPos = CommonGUI.editText_compiler.cursorPos;
		if (compiler!=null) {
			synchronized (listOfQueueItems) {
				listOfQueueItems.add(new QueueItem(compiler, cursorPos, System.currentTimeMillis(), charA));
			}
		}		
	}
	
	static void insertPart(ArrayListIReset src, ArrayListIReset dest) {
		if (src.count==0) return;
		IReset element = src.getItem(0);
		int startIndex=-1;
		if (element instanceof Error) {
			Error error = (Error)element;
			startIndex = error.startIndex();
		}
		else if (element instanceof FindStatementParams) {
			FindStatementParams statement = (FindStatementParams) element;
			startIndex = statement.startIndex();
		}
		else if (element instanceof Constructor) {
			Constructor statement = (Constructor) element;
			startIndex = statement.startIndex();
		}
		int i;
		for (i=0; i<dest.count; i++) {
			IReset element2 = dest.getItem(i);
			int startIndex2=-1;
			if (element2 instanceof Error) {
				Error error = (Error)element2;
				startIndex2 = error.startIndex();
			}
			else if (element2 instanceof FindStatementParams) {
				FindStatementParams statement = (FindStatementParams) element2;
				startIndex2 = statement.startIndex();
			}
			else if (element2 instanceof Constructor) {
				Constructor statement = (Constructor) element2;
				startIndex2 = statement.startIndex();
			}
			if (startIndex2>startIndex) {
				dest.list = Array.InsertNoSpaceError(src, 0, dest, i, src.count);
				break;
			}
		}
		if (i==dest.count) {
			dest.list = Array.InsertNoSpaceError(src, 0, dest, i, src.count);
		}
		dest.count += src.count;
	}
	
	static void insertPart(ArrayList src, ArrayList dest) {
		if (src.count==0) return;
		Object element = src.getItem(0);
		int startIndex=-1;
		if (element instanceof FindVarUseParams) {
			FindVarUseParams varUse = (FindVarUseParams)element;
			startIndex = varUse.index();
		}
		else if (element instanceof HashItem) {
			HashItem hashItem = (HashItem)element;
			if (hashItem.data instanceof FindVarUseParams) {
				FindVarUseParams varUse = (FindVarUseParams)hashItem.data;
				startIndex = varUse.index();
			}
		}
		int i;
		for (i=0; i<dest.count; i++) {
			Object element2 = dest.getItem(i);
			int startIndex2=-1;
			if (element2 instanceof FindVarUseParams) {
				FindVarUseParams varUse = (FindVarUseParams)element2;
				startIndex2 = varUse.index();
			}
			else if (element2 instanceof HashItem) {
				HashItem hashItem = (HashItem)element2;
				if (hashItem.data instanceof FindVarUseParams) {
					FindVarUseParams varUse = (FindVarUseParams)hashItem.data;
					startIndex2 = varUse.index();
				}
			}
			if (startIndex2>startIndex) {
				dest.list = Array.InsertNoSpaceError(src, 0, dest, i, src.count);
				break;
			}
		}
		if (i==dest.count) {
			dest.list = Array.InsertNoSpaceError(src, 0, dest, i, src.count);
		}
		dest.count += src.count;
	}
	
	static void insertPart(ArrayListInt src, ArrayListInt dest) {
		if (src.count==0) return;
		int element = src.getItem(0);
		int startIndex=element;
		int i;
		for (i=0; i<dest.count; i++) {
			int element2 = dest.getItem(i);
			int startIndex2=element2;
			if (startIndex2>startIndex) {
				dest.list = Array.InsertNoSpaceError(src, 0, dest, i, src.count);
				break;
			}
		}
		if (i==dest.count) {
			dest.list = Array.InsertNoSpaceError(src, 0, dest, i, src.count);
		}
		dest.count += src.count;
	}
	
	static void insertPart(HighArray src, HighArray dest) {
		if (src.count==0) return;
		FindVarParams element = (FindVarParams) src.getItem(0);
		int startIndex=-1;
		startIndex = element.startIndex();
		
		int i, j;
		boolean putted = false;
		for (i=0; i<dest.data.count; i++) {
			ArrayList arr = (ArrayList) dest.data.getItem(i);
			for (j=0; j<arr.count; j++) {
				FindVarParams element2 = (FindVarParams) arr.getItem(j);
				int startIndex2=-1;
				startIndex2 = element2.startIndex();
				if (startIndex2>startIndex) {
					ArrayList srcArr = src.toArrayList();
					arr.list = Array.InsertNoSpaceError(srcArr, 0, arr, j, srcArr.count);
					arr.count += srcArr.count;
					putted = true;
					break;
				}
			}
			if (putted) break;
		}
		if (i==dest.data.count) {
			ArrayList arr = null;
			if (i>0) {
				arr = (ArrayList) dest.data.getItem(i-1);
			}
			else {
				arr = new ArrayList(dest.arrayLimit);
				dest.data.add(arr);
			}
			ArrayList srcArr = src.toArrayList();
			arr.list = Array.InsertNoSpaceError(srcArr, 0, arr, arr.count, srcArr.count);
			arr.count += srcArr.count;
		}
		dest.count += src.count;
	}
	
	static void insertPart2(HighArray src, HighArray dest) {
		if (src.count==0) return;
		FindVarUseParams element = (FindVarUseParams) src.getItem(0);
		int startIndex=-1;
		startIndex = element.index();
		
		int i, j;
		boolean putted = false;
		for (i=0; i<dest.data.count; i++) {
			ArrayList arr = (ArrayList) dest.data.getItem(i);
			for (j=0; j<arr.count; j++) {
				FindVarUseParams element2 = (FindVarUseParams) arr.getItem(j);
				int startIndex2=-1;
				startIndex2 = element2.index();
				if (startIndex2>startIndex) {
					ArrayList srcArr = src.toArrayList();
					arr.list = Array.InsertNoSpaceError(srcArr, 0, arr, j, srcArr.count);
					arr.count += srcArr.count;
					putted = true;
					break;
				}
			}
			if (putted) break;
		}
		if (i==dest.data.count) {
			ArrayList arr = null;
			if (i>0) {
				arr = (ArrayList) dest.data.getItem(i-1);
			}
			else {
				arr = new ArrayList(dest.arrayLimit);
				dest.data.add(arr);
			}
			ArrayList srcArr = src.toArrayList();
			arr.list = Array.InsertNoSpaceError(srcArr, 0, arr, arr.count, srcArr.count);
			arr.count += srcArr.count;
		}
		dest.count += src.count;
	}
	
	
	
	static void insertPart(Hashtable2_String src, Hashtable2_String dest) {
		ArrayList listSrc = src.toArray();
		int i;
		for (i=0; i<listSrc.count; i++) {
			HashItem item = (HashItem) listSrc.getItem(i);
			dest.input(item.key, item.data);
		}
		dest.count += src.count;
	}
	
	static void deletePart(ArrayListIReset arr, int startIndexToDelete, int endIndexToDelete) {
		int i;
		ArrayListIReset newArr = new ArrayListIReset(10);
		
		for (i=0; i<arr.count; i++) {
			IReset element = arr.getItem(i);
			int startIndex=-1, endIndex=-1;
			if (element instanceof Error) {
				Error error = (Error)element;
				startIndex = error.startIndex();
				endIndex = error.endIndex();
			}
			else if (element instanceof FindStatementParams) {
				FindStatementParams statement = (FindStatementParams) element;
				startIndex = statement.startIndex();
				endIndex = statement.endIndex();
				if (startIndex==1176) {
					int a;
					a=0;
					a++;
				}
			}
			else if (element instanceof Constructor) {
				Constructor statement = (Constructor) element;
				startIndex = statement.startIndex();
				endIndex = statement.endIndex();
			}
			if (!(startIndexToDelete<=startIndex && endIndex<=endIndexToDelete)) {
				newArr.add(element);
			}
		}
		
		arr.list = newArr.list;
		arr.count = newArr.count;
	}
	
	static void deletePart(ArrayList arr, int startIndexToDelete, int endIndexToDelete) {
		int i;
		ArrayList newArr = new ArrayList(10);
		
		for (i=0; i<arr.count; i++) {
			Object element = (Object) arr.getItem(i);
			int startIndex=-1;
			if (element instanceof FindVarUseParams) {
				FindVarUseParams varUse = (FindVarUseParams)element;
				startIndex = varUse.index();
			}
			else if (element instanceof HashItem) {
				HashItem hashItem = (HashItem)element;
				if (hashItem.data instanceof FindVarUseParams) {
					FindVarUseParams varUse = (FindVarUseParams)hashItem.data;
					startIndex = varUse.index();
				}
			}
			if (!(startIndexToDelete<=startIndex && startIndex<=endIndexToDelete)) {
				newArr.add(element);
			}
		}
		
		arr.list = newArr.list;
		arr.count = newArr.count;
	}
	
	static void deletePart(ArrayListInt arr, int startIndexToDelete, int endIndexToDelete) {
		int i;
		ArrayListInt newArr = new ArrayListInt(10);
		
		for (i=0; i<arr.count; i++) {
			int element = arr.getItem(i);
			if (!(startIndexToDelete<=element && element<=endIndexToDelete)) {
				newArr.add(element);
			}
		}
		
		arr.list = newArr.list;
		arr.count = newArr.count;
	}
	
	static void deletePart(HighArray arr, int startIndexToDelete, int endIndexToDelete) {
		int i;
		HighArray newArr = new HighArray(arr.arrayLimit);
		
		for (i=0; i<arr.count; i++) {
			FindVarParams element = (FindVarParams) arr.getItem(i);
			if (!(startIndexToDelete<=element.startIndex() && element.endIndex()<=endIndexToDelete)) {
				newArr.add(element);
			}
		}
		
		arr.data = newArr.data;
		arr.count = newArr.count;
	}
	
	static void deletePart2(HighArray arr, int startIndexToDelete, int endIndexToDelete) {
		int i;
		HighArray newArr = new HighArray(arr.arrayLimit);
		
		for (i=0; i<arr.count; i++) {
			FindVarUseParams element = (FindVarUseParams) arr.getItem(i);
			int index = element.index();
			if (!(startIndexToDelete<=index && index<=endIndexToDelete)) {
				newArr.add(element);
			}
		}
		
		arr.data = newArr.data;
		arr.count = newArr.count;
	}
	
	
	/**startIndex, endIndex 모두 포함*/
	static void deletePart(Hashtable2_String hashTable, int startIndexToDelete, int endIndexToDelete) {
		int i;
		ArrayList[] references = hashTable.getReferences();
		int count = 0;
		for (i=0; i<references.length; i++) {
			if (references[i]!=null) {
				deletePart(references[i], startIndexToDelete, endIndexToDelete);
				count += references[i].count;
			}
		}
		hashTable.setReferences(references);
		hashTable.count = count;
	}
	
	
	static void deletePart(CompilerData data, FindFunctionParams functionForPart, int startIndex, int endIndex) {
		deletePart(data.mlistOfAllArrayIntializers, startIndex, endIndex);
		deletePart(data.mlistOfAllAssignStatements, startIndex, endIndex);
		deletePart(data.mlistOfAllControlBlocks, startIndex, endIndex);
		deletePart(data.mlistOfAllConstructor, startIndex, endIndex);
		deletePart(data.mlistOfAllDefinedClasses, startIndex, endIndex);
		deletePart(data.mlistOfAllForLoops, startIndex, endIndex);
		//deletePart(data.mlistOfAllFunctions, startIndex, endIndex);
		deletePart(data.mlistOfAllLocalVarDeclarations, startIndex, endIndex);
		deletePart(data.mlistOfAllMemberVarDeclarations, startIndex, endIndex);
		deletePart(data.mlistOfAllTemplates, startIndex, endIndex);
		deletePart(data.mlistOfAllTypeCasts, startIndex, endIndex);
		deletePart2(data.mlistOfAllVarUses, startIndex, endIndex);
		deletePart(data.mlistOfAllVarUsesHashed, startIndex, endIndex);
		deletePart(data.mlistOfAnnotations, startIndex, endIndex);
		deletePart(data.mlistOfBlocks, startIndex, endIndex);
		deletePart(data.mlistOfClass, startIndex, endIndex);
		deletePart(data.mlistOfFinally, startIndex, endIndex);
		deletePart(data.mlistOfFindStatementParams, startIndex, endIndex);
		deletePart(data.mlistOfSpecialStatement, startIndex, endIndex);
		deletePart(data.mlistOfThreeOperandsOperation, startIndex, endIndex);
		deletePart(data.mlistOfNewLines, startIndex, endIndex);
		deletePart(data.mlistOfNewLines, startIndex, endIndex);
		
		
		FindClassParams parentClassForPart = (FindClassParams) functionForPart.parent;
		
		
		deletePart(parentClassForPart.listOfConstructor, startIndex, endIndex);
		deletePart(parentClassForPart.listOfControlBlocks, startIndex, endIndex);
		//deletePart(parentClassForPart.listOfFunctionParams, startIndex, endIndex);
		deletePart(parentClassForPart.listOfSpecialBlocks, startIndex, endIndex);
		deletePart(parentClassForPart.listOfStatements, startIndex, endIndex);
		deletePart(parentClassForPart.listOfVariableParams, startIndex, endIndex);
		deletePart2(parentClassForPart.listOfAllVarUses, startIndex, endIndex);
		deletePart(parentClassForPart.listOfAllVarUsesForFuncHashed, startIndex, endIndex);
		deletePart(parentClassForPart.listOfAllVarUsesForVarHashed, startIndex, endIndex);
		deletePart2(parentClassForPart.listOfAllVarUsesForFunc, startIndex, endIndex);
		deletePart2(parentClassForPart.listOfAllVarUsesForVar, startIndex, endIndex);
		
	}
	
	/**파일 전체를 즉시 update를 한다.
	 * @param coreThreadID */
	public static void updateAllRightNow(int coreThreadID) {
		//LoggingScrollable.longOperation = true;
		InterfaceErrorResolver.update(coreThreadID);		
		//LoggingScrollable.longOperation = false;
		
		CommonGUI.loggingForMessageBox.setHides(true);
		
		//Update.listOfQueueItems.reset();
		if (CompilerStatic.errors.count==0) {
			CommonGUI.editText_compiler.resetButtonProblemsAndProblemsAllColor();
		}
	}
	
	
	
}
