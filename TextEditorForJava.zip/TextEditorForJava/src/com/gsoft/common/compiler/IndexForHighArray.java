package com.gsoft.common.compiler;

import com.gsoft.common.interfaces.IReset;
import com.gsoft.common.compiler.Compiler_types.FindExpressionParams;

import com.gsoft.common.compiler.HighArray_CodeString;

/** HighArray_CodeString내에서 스트링 아이템을 가리키는 (인덱스, 인덱스)쌍이다.*/
public class IndexForHighArray implements IReset {
	/** HighArray_CodeString 내에 있는 array의 번호, 이것은 data의 인덱스이다.*/
	int arrayNumber = -1;
	/** HighArray_CodeString 내에 있는 array의 스트링을 가리키는 인덱스*/
	int offset = -1;
	
	Object owner;
	HighArray_CodeString highArray;
	
	
	public void destroy() {
		arrayNumber = -1;
		offset = -1;
		owner = null;
		highArray = null;
	}
	
	public void reset() {
		arrayNumber = -1;
		offset = -1;
	}
	
	/** 인덱스가 생성될 때 highArray의 dataRelated의 해당 파티션(arrayNumber)에 생성된 인덱스를 넣는다.
	 * @param owner : null이면 dataRelated에 넣지 않는다.*/
	public IndexForHighArray(Object owner, HighArray_CodeString highArray, int arrayNumber, int offset) {
		if (owner instanceof FindExpressionParams && arrayNumber==0 && offset==380) {
		}
		this.arrayNumber = arrayNumber;
		this.offset = offset;
		this.highArray = highArray;
		this.owner = owner;
		
		if (owner!=null) { 
			this.highArray.addToDataRelated(this);
		}
	}
	
	/**상대인덱스(arrayNumber,offset)에서 절대 인덱스를 리턴한다.*/
	public int index() {
		return highArray.index(arrayNumber, offset);
	}
	
	
	/**절대 인덱스에서 상대인덱스(arrayNumber,offset)를 리턴한다.*/
	public static IndexForHighArray indexRelative(Object owner, HighArray_CodeString highArray, int index) {
		if (highArray==null) return null;
		if (index<0) return null;
		return highArray.indexRelative(owner, index);
	}
	
	@SuppressWarnings("rawtypes")
	public String toString() {
		String r = String.valueOf(index()) + "-";
		Class classOfowner = owner.getClass();
		r += classOfowner.getName();
		return r;
	}
}