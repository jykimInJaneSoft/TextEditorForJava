package com.gsoft.common.compiler;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.interfaces.IReset;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.Compiler_types.FindFuncCallParam;
import com.gsoft.common.compiler.Compiler_types.FindVarUseParams;
import com.gsoft.common.compiler.Compiler_types_Base.Error;
import com.gsoft.common.compiler.Compiler_types_Base.ReturnOfIsType;
import com.gsoft.common.compiler.TemplateBase.Template;
import com.gsoft.common.compiler.classloader.Loader;
import com.gsoft.common.util.HighArray;

import com.gsoft.common.compiler.IndexForHighArray;
import com.gsoft.common.compiler.CodeStringEx;
import com.gsoft.common.compiler.TemplateBase;
import com.gsoft.common.compiler.Array;
import com.gsoft.common.compiler.CompilerStatic;
import com.gsoft.common.compiler.Fullname;
import com.gsoft.common.compiler.Checker;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.HighArray_CodeString;
import com.gsoft.common.compiler.Compiler;

/**(타입)id 이와 같은 타입캐스트를 표현한다.*/
@SuppressWarnings("unused")
public class TypeCast_Syntax  implements IReset {
	public String name;
	/**(타입)id 에서 타입의 시작과 끝, 괄호 불포함*/
	IndexForHighArray startIndex;
	/**(타입)id 에서 타입의 시작과 끝, 괄호 불포함*/
	IndexForHighArray endIndex;
	
	/** 타입캐스트문의 괄호 인덱스*/
	IndexForHighArray indexOfLeftPair;
	/** 타입캐스트문의 괄호 인덱스*/
	IndexForHighArray indexOfRightPair;
	
	/**(타입)id 는 false, (타입)(수식)은 true*/
	public boolean affectsExpression;
	
	/**(타입)(수식)일 경우에만 null 이 아님*/
	public FindFuncCallParam funcCall;
	
	/**(타입)id 에서 id 의 시작과 끝, (타입)(수식) 에서 괄호 불포함, (타입)a.b.c 에서 a 를 말한다.*/
	public IndexForHighArray startIndexToAffect;
	/**(타입)id 에서 id 의 시작과 끝, (타입)(수식) 에서 괄호 불포함, (타입)a.b.c 에서 c 를 말한다.*/
	public IndexForHighArray endIndexToAffect;
	
	/** (com.gsoft.common.gui.Buttons.Button)control 여기에서 Button을 말한다.*/
	public FindVarUseParams varUseTypeCasting;
	
	/** (T) data;와 같은 경우 true, 
     * loadClassFromSrc_onlyInterface()의 appleyTypeNameToChangeToTemplateClass()에서 설정한다.*/
	public boolean isTypeNameToChange;
	
	public int startIndexToAffect() {
		if (startIndexToAffect==null) return -1;
		return startIndexToAffect.index();
	}
	
	public int endIndexToAffect() {
		if (endIndexToAffect==null) return -1;
		return endIndexToAffect.index();
	}
	
	public int indexOfLeftPair() {
		if (indexOfLeftPair==null) return -1;
		return indexOfLeftPair.index();
	}
	
	public int indexOfRightPair() {
		if (indexOfRightPair==null) return -1;
		return indexOfRightPair.index();
	}
	
	/**(타입)id 에서 id 의 시작과 끝, (타입)(수식) 에서 id의 mlistOfAllVarUses에서의 시작 인덱스*/
	public int startIndexToAffect_mlistOfAllVarUses;
	/**(타입)id 에서 id 의 시작과 끝, (타입)(수식) 에서 id의 mlistOfAllVarUses에서의 끝 인덱스*/
	public int endIndexToAffect_mlistOfAllVarUses;
	/** 타입캐스트가 템플릿일 경우 null이 아님*/
	public Template template;
	
	Compiler compiler;
	
	
	/** 매개변수 각각은 괄호 불포함*/
	TypeCast_Syntax(Compiler compiler, int startIndex, int endIndex, int startIndexToAffect, int endIndexToAffect) {
		this.compiler = compiler;
		this.startIndex = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, startIndex);
		this.endIndex = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, endIndex);
		this.startIndexToAffect = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, startIndexToAffect);
		this.endIndexToAffect = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, endIndexToAffect);
		
		
	}
	
	
	/** (fullnameTypeCast)fullnameTarget, fullnameTypeCast = fullnameTarget; 
	 * @param isTypeCastOrAssignOrFuncCall : 타입캐스트할경우는 0, 할당시일경우는 1, 함수호출시는 2, 
	 * 2016-07-20 업데이트로 함수호출시에도 할당시와 같은 규칙을 갖는다.<br>
	 * new ProcessBuilder("java", "-jar", "***.jar")와 같은 함수인 경우
		System.out.printf("%d %f", 1, 0.5f)와 같은 함수인 경우인지를 확인한다.
		 @param compiler_fullnameTypeCast : compiler defining fullnameTypeCast
	 * @param compiler_fullnameTarget : compiler defining fullnameTarget
	 * @param coreThreadID */
	public static boolean isCompatibleType_funcArgIsArrayAndFuncCallParamsIsElementTypeList(Compiler compiler_fullnameTypeCast,
			Compiler compiler_fullnameTarget,
			CodeStringEx fullnameTypeCast, CodeStringEx fullnameTarget,
			int isTypeCastOrAssignOrFuncCall,  
			FindFuncCallParam expression/*, boolean isFullnameTargetConstant*/, int coreThreadID) {
		if (fullnameTypeCast.equals("android.view.View") && fullnameTarget.equals("null")) {
			int a;
			a=0;
			a++;
		}
		if (fullnameTypeCast==null || fullnameTarget==null) return false;
		
		if (isTypeCastOrAssignOrFuncCall==2) {
			if (fullnameTypeCast.equals("java.lang.Object")) {
				if (CompilerHelper.IsDefaultType(fullnameTarget.str)) return true;
				return true;
			}
		}
		
		return isCompatibleType(compiler_fullnameTypeCast, compiler_fullnameTarget,
				fullnameTypeCast, fullnameTarget, isTypeCastOrAssignOrFuncCall, expression, coreThreadID);
	}
	
	/** (fullnameTypeCast)fullnameTarget, fullnameTypeCast = fullnameTarget; 
	 * @param isTypeCastOrAssignOrFuncCall : 타입캐스트할경우는 0, 할당시일경우는 1, 함수호출시는 2, 
	 * 2016-07-20 업데이트로 함수호출시에도 할당시와 같은 규칙을 갖는다.
	 * @param compiler_fullnameTypeCast : compiler defining fullnameTypeCast
	 * @param compiler_fullnameTarget : compiler defining fullnameTarget
	 * @param coreThreadID */
	public static boolean isCompatibleType(Compiler compiler_fullnameTypeCast, Compiler compiler_fullnameTarget,  
			CodeStringEx fullnameTypeCast, CodeStringEx fullnameTarget,
			int isTypeCastOrAssignOrFuncCall,  
			FindFuncCallParam expression/*, boolean isFullnameTargetConstant*/, int coreThreadID) {
		if (fullnameTypeCast.equals("android.view.View") && fullnameTarget.equals("null")) {
			int a;
			a=0;
			a++;
		}
		
		
		if (fullnameTypeCast==null || fullnameTarget==null) return false;
	
		
		if (!CompilerHelper.IsDefaultType(fullnameTypeCast.str)) {
			// Object o = null;
			if (fullnameTarget.str.equals("null")) return true;
		}
		
		if (fullnameTarget.equals("")) return false;
		if (fullnameTypeCast.equals(fullnameTarget)) return true;
		if (fullnameTypeCast.equals("java.lang.Object")) {
			if (CompilerHelper.IsDefaultType(fullnameTarget.str)) return false;
			// fullnameTarget is Object type
			return true;
		}
		
		// FindVarUseParams child = compiler.mlistOfAllVarUses.getItem(k);
		// 에서 getItem()은 T getItem()이다.
		if (fullnameTarget.isTypeNameToChangeForTemplate)
			return true;
		
		//String strfullnameTypeCast = fullnameTypeCast.str;
		//String strfullnameTarget = fullnameTarget.str;
		
		
		if (fullnameTarget.equals("byte")) {
			if (fullnameTypeCast.equals("byte")){
				return true;
			}
			// i = c; (int)c
			else if (fullnameTypeCast.equals("char")) {
				if (isTypeCastOrAssignOrFuncCall==0) return true;
				// char c = b; 가능
				else if (isTypeCastOrAssignOrFuncCall==1) return true;
				else return true;
			}
			else if (fullnameTypeCast.equals("int") || fullnameTypeCast.equals("short") ||
				fullnameTypeCast.equals("long")) 
			{
				if (isTypeCastOrAssignOrFuncCall==0) return true;
				else if (isTypeCastOrAssignOrFuncCall==1) {
					//if (expression!=null) expression.typeFullNameByOperator = fullnameTypeCast;
					return true; // i = b; s = b; l = b;
				}
				else {
					// f(100); void f(int i) {} 에서 
					// 100은 byte이므로 함수 f()에 바인딩이 안 되지만 
					// 원래 100은 int여서 함수 f()에 바인딩이 되었기 때문에 허용한다.
					// 그러나 byte b = 0; f(b); 에서는 f()에 바인딩이 되지 않는다.
					//if (isFullnameTargetConstant) return true;
					return true;
				}
			}
			else if (fullnameTypeCast.equals("float") || fullnameTypeCast.equals("double")) {
				if (isTypeCastOrAssignOrFuncCall==0) return true; 
				else if (isTypeCastOrAssignOrFuncCall==1) {
					//if (expression!=null) expression.typeFullNameByOperator = fullnameTypeCast; 
					return true; // f = b;는 가능하다.
				}
				else return true;
			}
			else if (fullnameTypeCast.equals("java.lang.Byte")) {
				if (isTypeCastOrAssignOrFuncCall==0) return false; 
				// java.lang.Byte B = b; 
				else if (isTypeCastOrAssignOrFuncCall==1) return false;
				// f(java.lang.Byte B) 에 f(b) 호출 가능
				else return false;
			}
			else return false;
		}//if (fullnameTarget.equals("byte")) {
		else if (fullnameTarget.equals("char")) {
			if (fullnameTypeCast.equals("byte")){
				if (isTypeCastOrAssignOrFuncCall==0) return true;
				else return false;
			}
			// i = c; (int)c
			else if (fullnameTypeCast.equals("char")) {
				return true;
			}
			else if (fullnameTypeCast.equals("int") || fullnameTypeCast.equals("short") ||
				fullnameTypeCast.equals("long")) 
			{
				if (isTypeCastOrAssignOrFuncCall==0) return true;
				else if (isTypeCastOrAssignOrFuncCall==1) {
					//if (expression!=null) expression.typeFullNameByOperator = fullnameTypeCast;
					return true; // i = c; s = c; l = c;
				}
				else return true;					 
			}
			else if (fullnameTypeCast.equals("float") || fullnameTypeCast.equals("double")) {
				if (isTypeCastOrAssignOrFuncCall==0) return true; 
				else if (isTypeCastOrAssignOrFuncCall==1) {
					//if (expression!=null) expression.typeFullNameByOperator = fullnameTypeCast; 
					return true; // f = c;는 가능하다.
				}
				else return true;
			}
			else if (fullnameTypeCast.equals("java.lang.Char")) {
				if (isTypeCastOrAssignOrFuncCall==0) return false; 
				// java.lang.Char C = c; 
				else if (isTypeCastOrAssignOrFuncCall==1) return false;
				// f(java.lang.Char B) 에 f(c) 호출 가능
				else return false;
			}
			else return false;
		}//if (fullnameTarget.equals("char")) {
		else if (fullnameTarget.equals("int")) {
			if (fullnameTypeCast.equals("byte")/* || fullnameTypeCast.equals("java.lang.Byte")*/) {
				if (isTypeCastOrAssignOrFuncCall==0) return true;
				else {
					return false;
				}
			}
			else if (fullnameTypeCast.equals("char")) {				
				if (isTypeCastOrAssignOrFuncCall==0) return true;
				else {
					return false;
				}
			}
			else if (fullnameTypeCast.equals("short")) {				
				if (isTypeCastOrAssignOrFuncCall==0) return true;
				else {
					return false;
				}
			}
			
			else if (fullnameTypeCast.equals("int")) {
				return true;
			}
			else if (fullnameTypeCast.equals("long")) {
				if (isTypeCastOrAssignOrFuncCall==0) return true;
				else if (isTypeCastOrAssignOrFuncCall==1) {
					//if (expression!=null) expression.typeFullNameByOperator = fullnameTypeCast;
					return true; // l = i;
				}
				else {
					return true;
				}
			}
			else if (fullnameTypeCast.equals("float")) {
				if (isTypeCastOrAssignOrFuncCall==0) return true;
				else if (isTypeCastOrAssignOrFuncCall==1) {
					//if (expression!=null) expression.typeFullNameByOperator = fullnameTypeCast;
					return true; // f = i;
				}
				else return true;
			}
			else if (fullnameTypeCast.equals("double")) {
				if (isTypeCastOrAssignOrFuncCall==0) return true;
				else if (isTypeCastOrAssignOrFuncCall==1) {
					//if (expression!=null) expression.typeFullNameByOperator = fullnameTypeCast;
					return true; // d = i;
				}
				else return true;
			}
			else if (fullnameTypeCast.equals("java.lang.Integer")) {
				if (isTypeCastOrAssignOrFuncCall==0) return false; 
				// java.lang.Integer I = i; 
				else if (isTypeCastOrAssignOrFuncCall==1) return false;
				// f(java.lang.Integer B) 에 f(i) 호출 가능
				else return false;
			}
			else return false;
		}//else if (fullnameTarget.equals("int")) {
		else if (fullnameTarget.equals("short")) {
			if (fullnameTypeCast.equals("byte")) {
				if (isTypeCastOrAssignOrFuncCall==0) return true;
				else if (isTypeCastOrAssignOrFuncCall==1) {
					return false;
				}
				else return false;
			}
			else if (fullnameTypeCast.equals("char")){
				if (isTypeCastOrAssignOrFuncCall==0) return true;
				else {
					if (isTypeCastOrAssignOrFuncCall==1) {
						//char c = s; 은 가능하다.
						// char c = 0x8141;
						return true;	
					}
					else {
						return true;
					}
				}
			}
			else if (fullnameTypeCast.equals("int")) {
				if (isTypeCastOrAssignOrFuncCall==0) return true;
				else if (isTypeCastOrAssignOrFuncCall==1) {
					//if (expression!=null) expression.typeFullNameByOperator = fullnameTypeCast;
					return true; // i = s;
				}
				else {
					return true;
				}
			}
			else if (fullnameTypeCast.equals("short")) {
				return true;
			}
			else if (fullnameTypeCast.equals("long")) {
				if (isTypeCastOrAssignOrFuncCall==0) return true;
				else if (isTypeCastOrAssignOrFuncCall==1) {
					//if (expression!=null) expression.typeFullNameByOperator = fullnameTypeCast;
					return true; // l = s;
				}
				else {
					return true;
				}
			}
			else if (fullnameTypeCast.equals("float")) {
				if (isTypeCastOrAssignOrFuncCall==0) return true;
				else if (isTypeCastOrAssignOrFuncCall==1) {
					//if (expression!=null) expression.typeFullNameByOperator = fullnameTypeCast;
					return true; // f = s;
				}
				else return true;					
			}
			else if (fullnameTypeCast.equals("double")) {
				if (isTypeCastOrAssignOrFuncCall==0) return true;
				else if (isTypeCastOrAssignOrFuncCall==1) {
					//if (expression!=null) expression.typeFullNameByOperator = fullnameTypeCast;
					return true; // d = s;
				}
				else return true;
			}
			else if (fullnameTypeCast.equals("java.lang.Short")) {
				if (isTypeCastOrAssignOrFuncCall==0) return false; 
				// java.lang.Short S = s; 
				else if (isTypeCastOrAssignOrFuncCall==1) return false;
				// f(java.lang.Short S) 에 f(s) 호출 가능
				else return false;
			}
			else return false;
		}//else if (fullnameTarget.equals("short")) {
		else if (fullnameTarget.equals("long")) {
			if (fullnameTypeCast.equals("byte")) {
				if (isTypeCastOrAssignOrFuncCall==0) return true;
				else {
					return false;
				}
			}
			else if (fullnameTypeCast.equals("char")) {
				if (isTypeCastOrAssignOrFuncCall==0) return true;
				else {
					return false;
				}
			}
			else if (fullnameTypeCast.equals("int")) {
				if (isTypeCastOrAssignOrFuncCall==0) return true;
				else {
					return false;
				}
			}
			else if (fullnameTypeCast.equals("short")) {
				if (isTypeCastOrAssignOrFuncCall==0) return true;
				else {
					return false;
				}
			}
			else if (fullnameTypeCast.equals("long")) {
				return true;
			}
			else if (fullnameTypeCast.equals("float")) {
				if (isTypeCastOrAssignOrFuncCall==0) return true;
				else if (isTypeCastOrAssignOrFuncCall==1) {
					//if (expression!=null) expression.typeFullNameByOperator = fullnameTypeCast;
					return true; // f = l;
				}
				else return false;
			}
			else if (fullnameTypeCast.equals("double")) {
				if (isTypeCastOrAssignOrFuncCall==0) return true;
				else if (isTypeCastOrAssignOrFuncCall==1) {
					//if (expression!=null) expression.typeFullNameByOperator = fullnameTypeCast;
					return true; // d = l;
				}
				else return false;
			}
			else if (fullnameTypeCast.equals("java.lang.Long")) {
				if (isTypeCastOrAssignOrFuncCall==0) return false; 
				// java.lang.Long L = l; 
				else if (isTypeCastOrAssignOrFuncCall==1) return false;
				// f(java.lang.Long L) 에 f(l) 호출 가능
				else return false;
			}
			else return false;
		} //else if (fullnameTarget.equals("long")) {
		
		else if (fullnameTarget.equals("float")) {
			if (fullnameTypeCast.equals("float")) {
				return true;					
			}
			else if (fullnameTypeCast.equals("double")) {
				if (isTypeCastOrAssignOrFuncCall==0) return true;
				else if (isTypeCastOrAssignOrFuncCall==1) {
					//if (expression!=null) expression.typeFullNameByOperator = fullnameTypeCast;
					return true; // d = f;
				}
				else return true;
			}
			else if (fullnameTypeCast.equals("byte") || fullnameTypeCast.equals("char")) {
				if (isTypeCastOrAssignOrFuncCall==0) return true;
				else return false;
			}
			else if (fullnameTypeCast.equals("int")) {
				if (isTypeCastOrAssignOrFuncCall==0) return true;
				else return false;
			}
			else if (fullnameTypeCast.equals("short")) {
				if (isTypeCastOrAssignOrFuncCall==0) return true;
				else return false;
			}
			else if (fullnameTypeCast.equals("long")) {
				if (isTypeCastOrAssignOrFuncCall==0) return true;
				else return false;
			}
			else if (fullnameTypeCast.equals("java.lang.Float")) {
				if (isTypeCastOrAssignOrFuncCall==0) return false; 
				// java.lang.Float F = f; 
				else if (isTypeCastOrAssignOrFuncCall==1) return false;
				// f(java.lang.Float F) 에 f(f) 호출 가능
				else return false;
			}
			else return false;
		}//else if (fullnameTarget.equals("float")) {
		else if (fullnameTarget.equals("double")) {
			if (fullnameTypeCast.equals("float")) {
				if (isTypeCastOrAssignOrFuncCall==0) return true;
				else return false;				
			}
			else if (fullnameTypeCast.equals("double")) {
				return true;
			}
			else if (fullnameTypeCast.equals("byte") || fullnameTypeCast.equals("char")) {
				if (isTypeCastOrAssignOrFuncCall==0) return true;
				else return false;
			}
			else if (fullnameTypeCast.equals("int")) {
				if (isTypeCastOrAssignOrFuncCall==0) return true;
				else return false;
			}
			else if (fullnameTypeCast.equals("short")) {
				if (isTypeCastOrAssignOrFuncCall==0) return true;
				else return false;
			}
			else if (fullnameTypeCast.equals("long")) {
				if (isTypeCastOrAssignOrFuncCall==0) return true;
				else return false;
			}
			else if (fullnameTypeCast.equals("java.lang.Double")) {
				if (isTypeCastOrAssignOrFuncCall==0) return false; 
				// java.lang.Double D = d; 
				else if (isTypeCastOrAssignOrFuncCall==1) return false;
				// f(java.lang.Double d) 에 f(d) 호출 가능
				else return false;
			}
			else return false;
		}//else if (fullnameTarget.equals("double")) {
		/*else if (fullnameTarget.equals("java.lang.Byte")) {
			if (isTypeCastOrAssignOrFuncCall==0) return true; 
			// java.lang.Byte B; b = B; 
			else if (isTypeCastOrAssignOrFuncCall==1) return true;
			// f(byte b) 에 f(B) 호출 가능
			else return true;
		}
		else if (fullnameTarget.equals("java.lang.Char")) {
			if (isTypeCastOrAssignOrFuncCall==0) return true; 
			// java.lang.Char C; c = C; 
			else if (isTypeCastOrAssignOrFuncCall==1) return true;
			// f(char c) 에 f(C) 호출 가능
			else return true;
		}
		else if (fullnameTarget.equals("java.lang.Short")) {
			if (isTypeCastOrAssignOrFuncCall==0) return true; 
			// java.lang.Short S; s = S; 
			else if (isTypeCastOrAssignOrFuncCall==1) return true;
			// f(short s) 에 f(S) 호출 가능
			else return true;
		}
		else if (fullnameTarget.equals("java.lang.Integer")) {
			if (isTypeCastOrAssignOrFuncCall==0) return true; 
			// java.lang.Integer I; i = I; 
			else if (isTypeCastOrAssignOrFuncCall==1) return true;
			// f(int i) 에 f(I) 호출 가능
			else return true;
		}
		else if (fullnameTarget.equals("java.lang.Long")) {
			if (isTypeCastOrAssignOrFuncCall==0) return true; 
			// java.lang.Long L; l = L; 
			else if (isTypeCastOrAssignOrFuncCall==1) return true;
			// f(long l) 에 f(L) 호출 가능
			else return true;
		}
		else if (fullnameTarget.equals("java.lang.Float")) {
			if (isTypeCastOrAssignOrFuncCall==0) return true; 
			// java.lang.Float F; f = F; 
			else if (isTypeCastOrAssignOrFuncCall==1) return true;
			// f(float f) 에 f(F) 호출 가능
			else return true;
		}
		else if (fullnameTarget.equals("java.lang.Double")) {
			if (isTypeCastOrAssignOrFuncCall==0) return true; 
			// java.lang.Double D; d = D; 
			else if (isTypeCastOrAssignOrFuncCall==1) return true;
			// f(double d) 에 f(D) 호출 가능
			else return true;
		}*/			
		
		// byte[] arr = null;인것처럼 배열차원이 달라도 할당문 타입검사를 피한다.
		if (fullnameTarget.equals("null") && !CompilerHelper.IsDefaultType(fullnameTypeCast.str)) return true;
		
		
		int dimension1 = Array.getArrayDimension(compiler_fullnameTarget, fullnameTarget.str);
		int dimension2 = Array.getArrayDimension(compiler_fullnameTypeCast, fullnameTypeCast.str);
		
		if (dimension1!=dimension2) return false;
		
					
		String strfullnameTarget = Array.getArrayElementType(fullnameTarget.str);
		String strfullnameTypeCast = Array.getArrayElementType(fullnameTypeCast.str);
		
		if (strfullnameTarget.equals(strfullnameTypeCast)) return true;
		
		/*String typeNameInTemplatePairTarget = CompilerHelper.getTemplateTypeInPair(strfullnameTarget);
		String typeNameInTemplatePairTypeCast = CompilerHelper.getTemplateTypeInPair(strfullnameTypeCast);
		
		// Stack<int> stack = new Stack();에서 int는 허용되지 않는다.
		if (typeNameInTemplatePairTypeCast!=null && 
				CompilerHelper.IsDefaultType(typeNameInTemplatePairTypeCast)) {
			if (fullnameTypeCast.indicesInSrc!=null) {
				CompilerStatic.errors.add(new Error(compiler, fullnameTypeCast.indicesInSrc.getItem(0), 
						fullnameTypeCast.indicesInSrc.getItem(fullnameTypeCast.indicesInSrc.count-1), typeNameInTemplatePairTypeCast));
			}
			return false;
		}
		
		if (typeNameInTemplatePairTarget!=null && 
				CompilerHelper.IsDefaultType(typeNameInTemplatePairTarget)) {
			if (fullnameTarget.indicesInSrc!=null) {
				CompilerStatic.errors.add(new Error(compiler, fullnameTarget.indicesInSrc.getItem(0), 
						fullnameTarget.indicesInSrc.getItem(fullnameTarget.indicesInSrc.count-1), typeNameInTemplatePairTarget));
			}
			return false;
		}*/
		
		
		
		if (TemplateBase.getTemplateTypeInPair(strfullnameTarget)!=null) {
			// strfullnameTarget이 com.gsoft.common.util.generic.HighArray<com.gsoft.common.compiler.Compiler_types.FindVarUseParams>이고
			// strfullnameTypeCast가 com.gsoft.common.util.generic.HighArray이면
			strfullnameTarget = TemplateBase.getTemplateOriginalType(strfullnameTarget); 
		}
		
		if (CompilerStatic.getShortName(strfullnameTarget).equals("EditText_Compiler") &&
				CompilerStatic.getShortName(strfullnameTypeCast).equals("OnTouchListener")	) {
			int a;
			a=0;
			a++;
		}
		
		
		
		FindClassParams typeCast = Loader.loadClass(compiler_fullnameTypeCast, strfullnameTypeCast, coreThreadID);
		
		FindClassParams	target = Loader.loadClass(compiler_fullnameTarget, strfullnameTarget, coreThreadID);
		
		
		
					
		if (typeCast==null || target==null) return false;
		
		if (typeCast==null || target==null || typeCast.name==null || target.name==null) {
			int a;
			a=0;
			a++;
		}
		
		
		
		
		//(Control)rect이나 control=rect는 true를 리턴한다.
		//(RectForPage)c이나  rect=control는 false를 리턴한다.
		if (FindClassParams.isARelation(compiler_fullnameTarget, typeCast, target, coreThreadID)){
			if (isTypeCastOrAssignOrFuncCall==0) { 
				return true;
			}
			else return true; // typeCast = target;
		}
		
		//(Control)rect이나 control=rect는 false를 리턴한다.
		//(RectForPage)c이나  rect=control는 true를 리턴한다.
		if (FindClassParams.isARelation(compiler_fullnameTypeCast, target, typeCast, coreThreadID)){
			if (isTypeCastOrAssignOrFuncCall==0) { // typeCast = target;
				return true;
			}
			else return false;
		}
		
		return false;
	}

	@Override
	public void destroy() {
		
		if (this.funcCall!=null) {
			this.funcCall.destroy();
			this.funcCall = null;
		}
		if (this.template!=null) {
			this.template.destroy();
			this.template = null;
		}
		this.name = null;
	}

	public int startIndex() {
		
		if (startIndex==null) return -1;
		return startIndex.index();
	}
	
	public int endIndex() {
		
		if (endIndex==null) return -1;
		return endIndex.index();
	}
	
	
	/** mlistOfAllVarUses(listOfAllVarUses)에서 모든 타입 캐스트문(TypeCast)을 찾아 
	 * mlistOfAllTypeCasts에 저장한다.
	 * @param coreThreadID */
	public static void findTypeCasts(Compiler compiler, HighArray_CodeString src, HighArray listOfAllVarUses, 
			boolean allOrPart, int startIndex, int endIndex, int coreThreadID) {
		boolean isTypeCast = false;
		TypeCast_Syntax typeCast = null;
		int i;
		int typeIndex;
		CodeString strType = null;
		int len = listOfAllVarUses.getCount();
		for (i=0; i<len; i++) {
			isTypeCast = false;
			FindVarUseParams varUse = (FindVarUseParams) listOfAllVarUses.getItem(i);
			if (varUse.index()==2967) {
				int a;
				a=0;
				a++;
			}
			//CompilerHelper.showMessage(true, "findTypeCasts() varUse.index()="+varUse.index());
			if (allOrPart) {
				if (!(startIndex<=varUse.index() && varUse.index()<=endIndex)) continue;
			}
			
			int nextIndex = CompilerHelper.SkipBlank(src, false, varUse.index()+1, src.count-1);
			CodeString nextStr = src.getItem(nextIndex);
			while (true) {
				if (nextStr.equals("[")) {
					int rightPairIndex = Checker.CheckParenthesis(compiler,  "[", "]", nextIndex, src.count-1, false);
					nextIndex = CompilerHelper.SkipBlank(src, false, rightPairIndex+1, src.count-1);
					nextStr = src.getItem(nextIndex);
				}
				else break;
			}
			if (!nextStr.equals(")")) continue;
			
			typeIndex = Fullname.getFullNameIndex_OnlyType(compiler,  true, varUse.index(), true);
			if (typeIndex==-1) continue;
			typeIndex = CompilerHelper.SkipBlank(src, true, 0, typeIndex-1);
			if (typeIndex==-1) {
				CompilerStatic.errors.add(new Error(compiler, varUse.index(), varUse.index(), "the start of file"));
				continue;
			}
			strType = src.getItem(typeIndex);
			
			if (strType.equals("(")) {
				int prevIndex = CompilerHelper.SkipBlank(src, true, 0, typeIndex-1);
				if (prevIndex>=0 && CompilerHelper.IsIdentifier(src.getItem(prevIndex), compiler)) {
					// "("는 함수호출의 괄호이다.
					continue;
				}
				
				int leftParentOfTypeCast, rightParentOfTypeCast;
				int startIndexToAffect=-1, endIndexToAffect=-1; 
				int startIndexToAffect_mlistOfAllVarUses=-1, endIndexToAffect_mlistOfAllVarUses=-1;
				boolean affectsExpression = false;
				leftParentOfTypeCast = typeIndex;
				
				
				rightParentOfTypeCast = Checker.CheckParenthesis(compiler,  "(", ")", leftParentOfTypeCast, src.count-1, false);
				if (rightParentOfTypeCast!=-1) {
					//Template template = new Template(compiler); 
					//int typeIndex2 = IsType(src, false, leftParentOfTypeCast+1, template);
					ReturnOfIsType  returnOfIsType = compiler.IsType(src, false, leftParentOfTypeCast+1);
					int typeIndex2 = returnOfIsType.index;
					Template template = returnOfIsType.template;
					if (typeIndex2!=-1) {
						int tempRightPair = CompilerHelper.SkipBlank(src, false, typeIndex2+1, src.count-1);
						if (tempRightPair==rightParentOfTypeCast) { // 괄호안은 타입캐스트문
							if (typeIndex2==58728) {
								int a;
								a=0;
								a++;
							}
							//if (isScopeAll) i = 0;에서 typeIndex2는 isScopeAll이고, keyword는 if이다.
							int keywordIndex = CompilerHelper.SkipBlank(src, true, 0, leftParentOfTypeCast-1);
							CodeString keyword = src.getItem(keywordIndex);
							if (CompilerHelper.IsKeyword(keyword, compiler) && !keyword.equals("return")) continue;
							
							int startIndexOfID = CompilerHelper.SkipBlank(src, false, rightParentOfTypeCast+1, src.count-1);
							if (startIndexOfID==7707) {
								int a;
								a=0;
								a++;
							}
							CodeString id = src.getItem(startIndexOfID);
							if (id.equals("buffer")) {
								int a;
								a=0;
								a++;
							}
							if ( CompilerHelper.IsIdentifier(id, compiler) || CompilerHelper.IsConstant(id)) { // (타입)id, (타입)a.b.c+d
								// ((java.lang.Object)buffer[i]).equals("("),   (long)buffer.length
								isTypeCast = true;
								startIndexToAffect = startIndexOfID;
								//endIndexToAffect = startIndexToAffect;
								endIndexToAffect = Fullname.getFullNameIndex(compiler, false, startIndexOfID, true);
								startIndexToAffect_mlistOfAllVarUses = CompilerStatic.getIndexInmListOfAllVarUses(src, 
										compiler.data.mlistOfAllVarUses,	0, startIndexToAffect, true);
								endIndexToAffect_mlistOfAllVarUses = CompilerStatic.getIndexInmListOfAllVarUses(src, 
										compiler.data.mlistOfAllVarUses,	startIndexToAffect_mlistOfAllVarUses, 
										endIndexToAffect, false);
								affectsExpression = false;
								
							}
							else if (id.equals("(")) { // (타입)(수식)
								// ((TextLine)(editRichText.undoBuffer.buffer.getItem(i))).toCharArray()
								// This makes affectsExpression false
								if (startIndexOfID==7707) {
									int a;
									a=0;
									a++;
								}
								isTypeCast = true;
								startIndexToAffect = startIndexOfID;
								endIndexToAffect = Checker.CheckParenthesis(compiler,  "(", ")", startIndexOfID, src.count-1, false);
								int endIndexOfID = endIndexToAffect; 
								if (endIndexToAffect==-1) {
									CompilerStatic.errors.add(new Error(compiler, startIndexOfID, startIndexOfID, "( not paired."));
									continue;
								}
								
								int nextIndexOfendIndexToAffect = CompilerHelper.SkipBlank(src, false, endIndexToAffect+1, src.count-1);
								if (src.getItem(nextIndexOfendIndexToAffect).equals(".")) {
									// (FindControlBlockParams) ((SortItemIReset) arrSortItem.getItem(i)).obj;
									//						startIndexOfID
									endIndexToAffect = Fullname.getFullNameIndex(compiler, false, startIndexOfID, true);	
								}
								else {
									affectsExpression = true;									
									// ((TextLine)(editRichText.undoBuffer.buffer.getItem(i))).toCharArray()
									//		startIndexOfID
									// This makes affectsExpression false
									int startIndexOfFullname = startIndexOfID;
									while (true) {
										startIndexOfFullname = CompilerHelper.SkipBlank(src, false, startIndexOfFullname+1, src.count-1);
										if (!src.getItem(startIndexOfFullname).equals("(")) break;
									}
									endIndexToAffect = Fullname.getFullNameIndex(compiler, false, startIndexOfFullname, true);
									int endIndexOfID2 = endIndexToAffect;
									while (true) {
										endIndexOfID2 = CompilerHelper.SkipBlank(src, false, endIndexOfID2+1, src.count-1);
										CodeString str = src.getItem(endIndexOfID2);
										if (str.equals("(") || str.equals("[")) {
											String end = str.equals("(") ? ")" : "]";
											endIndexOfID2 = Checker.CheckParenthesis(compiler,  str.str, end, endIndexOfID2, src.count-1, false);
										}
										else if (str.equals(")")) {
											if (endIndexOfID==endIndexOfID2) {
												affectsExpression = false;
												break;
											}
										}
										else break;
									}
								}
								
								if (affectsExpression) {
									endIndexToAffect = endIndexOfID;
								}								
								
								startIndexToAffect_mlistOfAllVarUses = CompilerStatic.getIndexInmListOfAllVarUses(src, 
										compiler.data.mlistOfAllVarUses,	0, startIndexToAffect, true);
								endIndexToAffect_mlistOfAllVarUses = CompilerStatic.getIndexInmListOfAllVarUses(src, 
										compiler.data.mlistOfAllVarUses,	startIndexToAffect_mlistOfAllVarUses, 
										endIndexToAffect, false);
								
							}// else if (id.equals("(")) { // (타입)(수식)
							else if (id.equals("-")) {
								int backup_startIndexOfID = startIndexOfID;
								startIndexOfID = CompilerHelper.SkipBlank(src, false, startIndexOfID+1, src.count-1);
								id = src.getItem(startIndexOfID);
								if ( CompilerHelper.IsIdentifier(id, compiler) || CompilerHelper.IsConstant(id)) { // (타입)-num
									isTypeCast = true;
									startIndexToAffect = backup_startIndexOfID;
									//endIndexToAffect = startIndexToAffect;
									endIndexToAffect = Fullname.getFullNameIndex(compiler, false, startIndexOfID, true);
									startIndexToAffect_mlistOfAllVarUses = CompilerStatic.getIndexInmListOfAllVarUses(src, 
											compiler.data.mlistOfAllVarUses,	0, startIndexToAffect, true);
									endIndexToAffect_mlistOfAllVarUses = CompilerStatic.getIndexInmListOfAllVarUses(src, 
											compiler.data.mlistOfAllVarUses,	startIndexToAffect_mlistOfAllVarUses, 
											endIndexToAffect, false);
									affectsExpression = true;
									
								}
								else if (id.equals("(")) { // (타입)(수식)
									isTypeCast = true;
									startIndexToAffect = backup_startIndexOfID;
									endIndexToAffect = Checker.CheckParenthesis(compiler,  "(", ")", startIndexOfID, src.count-1, false);
									if (endIndexToAffect==-1) {
										CompilerStatic.errors.add(new Error(compiler, startIndexOfID, startIndexOfID, "( not paired."));
									}
									//else endIndexToAffect--;
									startIndexToAffect_mlistOfAllVarUses = CompilerStatic.getIndexInmListOfAllVarUses(src, 
											compiler.data.mlistOfAllVarUses,	0, startIndexToAffect, true);
									endIndexToAffect_mlistOfAllVarUses = CompilerStatic.getIndexInmListOfAllVarUses(src, 
											compiler.data.mlistOfAllVarUses,	startIndexToAffect_mlistOfAllVarUses, 
											endIndexToAffect, false);
									affectsExpression = true;
								}
							}
							else {
							}
							if (isTypeCast) {
								typeCast = new TypeCast_Syntax(compiler, leftParentOfTypeCast+1, typeIndex2, 
										startIndexToAffect, endIndexToAffect);
								typeCast.name = Fullname.getFullNameType(compiler, leftParentOfTypeCast+1, typeIndex2, coreThreadID);
								typeCast.startIndexToAffect_mlistOfAllVarUses = startIndexToAffect_mlistOfAllVarUses;
								typeCast.endIndexToAffect_mlistOfAllVarUses = endIndexToAffect_mlistOfAllVarUses;
								typeCast.indexOfLeftPair = IndexForHighArray.indexRelative(typeCast, src, leftParentOfTypeCast);
								typeCast.indexOfRightPair = IndexForHighArray.indexRelative(typeCast, src, rightParentOfTypeCast);
								typeCast.affectsExpression = affectsExpression;
								
								int indexOfVarUseTypeCasting = CompilerHelper.SkipBlank(src, false, leftParentOfTypeCast+1, src.count-1);
								indexOfVarUseTypeCasting = Fullname.getFullNameIndex_OnlyType(compiler, false, indexOfVarUseTypeCasting, true);
								indexOfVarUseTypeCasting = CompilerHelper.SkipBlank(src, true, 0, indexOfVarUseTypeCasting);
								String varUseName = src.getItem(indexOfVarUseTypeCasting).str;
								typeCast.varUseTypeCasting = CompilerStatic.getVarUseWithIndex(compiler.data.mlistOfAllVarUsesHashed, varUseName, indexOfVarUseTypeCasting);
								
								varUse.typeCast = typeCast;
								
								if (!affectsExpression) {
									// (타입)varUse와 같은 비수식 타입캐스트문에서 varUse의 타입캐스트 이후의 타입을 정한다.
									// varUse의 현재 타입을 정하려면 varUse.getCurType()을 호출한다.
									FindVarUseParams varUseTypeCasted = (FindVarUseParams) compiler.data.mlistOfAllVarUses.getItem(endIndexToAffect_mlistOfAllVarUses);
									varUseTypeCasted.typeCastedByVarUse = varUse;
									varUseTypeCasted.fullnameTypeCast = varUse.typeCast.name;
								}
								
								if (template!=null && template.found) {
									compiler.data.mlistOfAllTemplates.add(template);
									typeCast.template = template;
								}								
								compiler.data.mlistOfAllTypeCasts.add(typeCast);
							}
						}//if (tempRightPair==rightParentOfTypeCast) { // 괄호안은 타입캐스트문
						else {
						}
					}//if (typeIndex!=-1) {
					else {
					}
				} // if (rightParentOfTypeCast!=-1) {
				else {
					CompilerStatic.errors.add(new Error(compiler, leftParentOfTypeCast, leftParentOfTypeCast, "( not paired."));
				}
			} // if (strType.equals("(")) {
		} // for (i=0; i<listOfAllVarUses.count; i++) {
	}
	
	/** varUse가 타입캐스트를 해야하는지 확인한다. 타입캐스트를 해야하면 full name 타입을 리턴한다.
	 * (long)buffer.length에서 varUse가 buffer일 경우 타입캐스트를 해서는 안된다.
	 	((java.lang.Object)buffer[i]).equals("(")에서 varUse가 buffer일 경우 타입캐스트를 해야한다.
		(int)i+0 에서 varUse가 i일 경우 타입캐스트를 해야한다.
		(int)(a+(char)b)+c 는 여기에서 해결할 수 없다.
	 * @param coreThreadID */
	public static String mustTypeCast(Compiler compiler, HighArray_CodeString src, FindVarUseParams varUse, int coreThreadID) {
		boolean r = false;
		int i;
		int rightPair;
		// (long)buffer.length에서 varUse가 buffer일 경우 타입캐스트를 해서는 안된다.
		// ((java.lang.Object)buffer[i]).equals("(")에서 varUse가 buffer일 경우 타입캐스트를 해야한다.
		// (int)i+0 에서 varUse가 i일 경우 타입캐스트를 해야한다.
		for (i=varUse.index()+1; i<src.count; i++) {
			CodeString str = src.getItem(i);
			if (CompilerHelper.IsBlank(str) || CompilerHelper.IsComment(str)) continue;
			else if (str.equals("(")) {
				rightPair = Checker.CheckParenthesis(compiler,  "(", ")", i, src.count-1, false);
				if (rightPair!=-1) i = rightPair;
			}
			else if (str.equals("[")) {
				rightPair = Checker.CheckParenthesis(compiler,  "[", "]", i, src.count-1, false);
				if (rightPair!=-1) i = rightPair;
			}
			else if (str.equals(")")) {
				r = true;
				break;
			}
			else if (CompilerHelper.IsOperator(str)) { // 공백과 주석을 제외한 구분자
				r = true;
				break;
			}
			else if (str.equals(";") || str.equals(",")) {
				r = true;
				break;
			}
			else {  // '.'
				break;
			}
		}
		if (!r) return null;
		r = false;
		
		int leftParent, rightParent;
		int typeIndex = -1;
		
		rightParent = CompilerHelper.SkipBlank(src, true, 0, varUse.index()-1);
		
		CodeString str = src.getItem(rightParent);
		
		if (str.equals(")")) {
			leftParent = Checker.CheckParenthesis(compiler,  "(", ")", 0, rightParent, true);
			if (leftParent!=-1) {
				typeIndex = compiler.IsType(src, true, rightParent-1).index;
				if (typeIndex!=-1) {
					int tempLeftPair = CompilerHelper.SkipBlank(src, true, 0, typeIndex-1);
					if (tempLeftPair==leftParent) { // 괄호안은 타입캐스트문
						if ( CompilerHelper.IsIdentifier( src.getItem(varUse.index()), compiler ) ) { // (타입)id
							r = true;
						}
						/*else if (src.getItem(rightParent+1).equals("(")) { // (타입)(수식)
							int rightParent2 = CompilerHelper.CheckParenthesis(src, "(", ")", rightParent+1, src.count-1, false);
							continue;
						}*/
					}
				}
			}
		}
		if (r) {
			return Fullname.getFullNameType(compiler, typeIndex, rightParent-1, coreThreadID);
		}
		return null;
		
	}
}
