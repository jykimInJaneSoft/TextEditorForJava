package com.gsoft.common.compiler;

import android.util.Log;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.CommonGUI;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.interfaces.IReset;
import com.gsoft.common.compiler.Compiler_types_Base.AccessModifier;
import com.gsoft.common.compiler.Compiler_types_Base.Block;
import com.gsoft.common.compiler.Compiler_types_Base.DocuComment;
import com.gsoft.common.compiler.Compiler_types_Base.FindStatementParams;
import com.gsoft.common.compiler.Compiler_types_Special.FindArrayInitializerParams;
import com.gsoft.common.compiler.Compiler_types_Special.FindIncrementStatementParams;
import com.gsoft.common.compiler.Compiler_types_Special.FindSpecialStatementParams;
import com.gsoft.common.compiler.TemplateBase.Template;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.Field_Info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.Method_Info;
import com.gsoft.common.compiler.bytecode.Code_attribute;
import com.gsoft.common.compiler.bytecode.TypeDescriptor;
import com.gsoft.common.compiler.classloader.Loader;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListChar;
import com.gsoft.common.util.ArrayListIReset;
import com.gsoft.common.util.ArrayListString;
import com.gsoft.common.util.HighArray;
import com.gsoft.common.util.hash.Hashtable2_String;

import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.IndexForHighArray;
import com.gsoft.common.compiler.HighArray_CodeString;
import com.gsoft.common.compiler.Fullname;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.Member;
import com.gsoft.common.compiler.Array;
import com.gsoft.common.compiler.CodeStringEx;
import com.gsoft.common.compiler.CompilerStatic;
import com.gsoft.common.compiler.TypeCast_Syntax;
import com.gsoft.common.compiler.Number;

public class Compiler_types  {
	
	
	public enum ModeAllOrUpdate {
		All,
		Update
	}	
	
	public static enum LoadWayOfFindClassParams {
		None,
		ByteCode,
		Start2,
		Start_OnlyInterface
	}
	
	
	/** Flag Name Value Interpretation 
	ACC_PUBLIC 0x0001 Declared public; may be accessed from outside its package. 
	ACC_FINAL 0x0010 Declared final; no subclasses allowed. 
	ACC_SUPER 0x0020 Treat superclass methods specially when invoked by the invokespecial instruction. 
	ACC_INTERFACE 0x0200 Is an interface, not a class. 
	ACC_ABSTRACT 0x0400 Declared abstract; must not be instantiated. 
	ACC_SYNTHETIC 0x1000 Declared synthetic; Not present in the source code. 
	ACC_ANNOTATION 0x2000 Declared as an annotation type. 
	ACC_ENUM 0x4000 Declared as an enum type.*/
	public static class FindClassParams extends Block  implements IReset {
		public LoadWayOfFindClassParams loadWayOfFindClassParams;
		
		/** setOnTouchListener(new View.OnTouchListener() {}); 에서 View.OnTouchListener()는 
		 * 이벤트 핸들러 클래스이므로 true 이다. 일반적인 클래스는 false 이다. */
		public boolean isEventHandlerClass;
		
		
		
		/** isEventHandlerClass이 true 일 때만*/
		IndexForHighArray startIndexOfEventHandlerName = null;
		/** isEventHandlerClass이 true 일 때만*/
		IndexForHighArray endIndexOfEventHandlerName = null;
		
		public int startIndexOfEventHandlerName() {
			if (startIndexOfEventHandlerName==null) return -1;
			return startIndexOfEventHandlerName.index();
		}
		
		public int endIndexOfEventHandlerName() {
			if (endIndexOfEventHandlerName==null) return -1;
			return endIndexOfEventHandlerName.index();
		}
		
		
		/** enum 형일 경우 true*/
		public boolean isEnum;
		
		/** interface 형일 경우 true*/
		public boolean isInterface;
		
		/** full name, 파일에서 정의한 클래스도 외부라이브러리클래스와 동일
		 * (FindAllClassesAndItsMembers2에서 정의)*/
		public String name;
		
		//boolean isPackage;
		
		DocuComment docuComment;
		public AccessModifier accessModifier;
		
        IndexForHighArray classIndex=null;
        public IndexForHighArray classNameIndex=null;
        
        int classIndex() {
        	if (classIndex==null) return -1;
        	return classIndex.index();
        }
        
        public int classNameIndex() {
        	if (classNameIndex==null) return -1;
        	return classNameIndex.index();
        }
        
        public ArrayListIReset listOfFunctionParams = new ArrayListIReset(10);
        
        /**상속을 이미 했으면 true, 아니면 false*/
        public boolean hasInherited;
        public ArrayListIReset listOfVarParamsInherited;
        public ArrayListIReset listOfFunctionParamsInherited;
        
        
        
        /**FindVarUseParams[]*/
        HighArray listOfAllVarUses/* = new ArrayListIReset(200)*/;
    	
    	/**FindVarUseParams[]*/
    	HighArray listOfAllVarUsesForVar/* = new ArrayListIReset(100)*/;
    	
    	
    	
    	/**FindVarUseParams[]*/
    	Hashtable2_String listOfAllVarUsesForVarHashed;
    	
    	 /**FindVarUseParams[]*/
    	HighArray listOfAllVarUsesForFunc/* = new ArrayListIReset(50)*/;
    	Hashtable2_String listOfAllVarUsesForFuncHashed;
        
        /** FindClassParams[]*/
        public ArrayListIReset childClasses;
        
        /** FindEnumParams[]*/
        //ArrayListIReset childEnums;
        
        /** extends 키워드의 인덱스, 없으면 -1*/
        IndexForHighArray indexOfExtends = null;
        /** implements 키워드의 인덱스, 없으면 -1*/
        IndexForHighArray indexOfImplements = null;
       
        /**확장클래스의 풀이름*/
        public String classNameToExtend;
        /**확장클래스이름의 시작과 끝 인덱스*/
        IndexForHighArray startIndexOfClassNameToExtend = null;
        /**확장클래스이름의 시작과 끝 인덱스*/
        IndexForHighArray endIndexOfClassNameToExtend = null;
        
        /**구현인터페이스들의 풀이름들의 리스트, 인터페이스일 경우 확장 인터페이스들의 풀이름 리스트*/
        public ArrayListString interfaceNamesToImplement;
        /**구현인터페이스 이름들의 시작과 끝 인덱스들의 리스트*, 인터페이스일 경우 확장 인터페이스들의 시작과 끝 인덱스들의 리스트,
         * IndexForHighArray[]*/
        ArrayList listOfStartIndexOfInterfaceNamesToImplement;
        /**구현인터페이스 이름들의 시작과 끝 인덱스들의 리스트, 인터페이스일 경우 확장 인터페이스들의 시작과 끝 인덱스들의 리스트
         * IndexForHighArray[]*/
        ArrayList listOfEndIndexOfInterfaceNamesToImplement;
        
        public FindClassParams classToExtend;
        /** FindClassParams[] 상속할 클래스들의 리스트*/
        ArrayListIReset listOfClassesToExtend;
        /**인터페이스일 경우 확장 인터페이스들의 풀이름 리스트*/
        public ArrayList interfacesToImplement;
        
        /** 제어블럭안의 문장들의 리스트, 할당문, 제어문, 함수호출문 등의 순서적 나열*/
		//ArrayListIReset listOfStatements = new ArrayListIReset(10);
		
		/**FindSpecialStatementParams[], return, break 등*/
    	//ArrayListIReset listOfSpecialStatements = new ArrayListIReset(10);
    	
    	/** 현재 클래스가 템플릿일 경우 null이 아니다. class Stack<T> {}에서 <T>를 말한다.*/
    	public Template template;
    	/** 확장클래스가 템플릿일경우 null이 아님*/
		public Template templateForExtending;
		/** 구현인터페이스들이 템플릿일경우 null이 아님, Template[]*/
		public ArrayListIReset listOfTemplatesForImplementing;
		
		/**applyTypeNameToChangeToTemplateClass()에서
		 * typeNameToChange가 적용이 되어 T가 모두 바뀌었을 경우에는 true
		 */
		public boolean appliedInapplyTypeNameToChangeToTemplateClass;

		/** reset()가 호출되면 true로 설정된다.*/
		private boolean disposed;
		
		/** 바이트코드에서 클래스파일을 읽거나 바이트코드를 생성할때
		 *  static 필드들을 초기화하기 위해 컴파일러가 새로 만든 생성자이면 null 이 아니고, 
		 *  그렇지 않으면 null 이다. */
		//FindFunctionParams staticConstructorThatCompilerMakes = null;
		
		
		/** 배열초기화에서 short 범위를 넘어서는 인덱스를 사용하기 위한 지역변수들의 리스트*/ 
		ArrayListIReset listOfLocalVarsForArrayInit = new ArrayListIReset(5);
		
		/** 배열초기화에서 short 범위를 넘어서는 array length를 사용하기 위한 지역변수들의 리스트*/ 
		ArrayListIReset listOfLocalVarsForArrayInit_arrayLength = new ArrayListIReset(5);
		
		/** 생성자 리스트, Compiler.FindAllClassesAndItsMembers2_sub()와 
		 * CompilerHelper.makeStaticDefaultConstructor(), makeNoneStaticDefaultConstructor()에서 넣어진다.
		 */
		public ArrayListIReset listOfConstructor = new ArrayListIReset(5);
		
		
    	
    	/** 클래스, 인터페이스를 찾았을때 호출, FindAllClassesAndItsMembers2_sub() 참조*/
    	void allocateListOfVarUses() {
    		//if (modeAllOrUpdate==ModeAllOrUpdate.All) {
	    		if (listOfAllVarUses==null) listOfAllVarUses = new HighArray(200);
	    		listOfAllVarUses.resizeInc = 200;
	        
	    		if (listOfAllVarUsesForVar==null) listOfAllVarUsesForVar = new HighArray(100);
	        	listOfAllVarUsesForVar.resizeInc = 100;
	        	
	        	if (listOfAllVarUsesForFunc==null) listOfAllVarUsesForFunc = new HighArray(50);
	        	listOfAllVarUsesForFunc.resizeInc = 50;
    		//}
    	}
    	
        
        public FindClassParams(Compiler compiler) {
        	this.compiler = compiler;
			this.startIndex = null;
			this.endIndex = null;
			
        	this.accessModifier = new AccessModifier(compiler, -1, -1);
        	this.childClasses = new ArrayListIReset(10);
        	listOfFunctionParams.resizeInc = 20;
        	listOfVariableParams.resizeInc = 50;
        }
        
        FindClassParams(Compiler compiler, int startIndex,	int endIndex) {
        	this.compiler = compiler;
			this.startIndex = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, startIndex);
			this.endIndex = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, endIndex);
			
        	this.accessModifier = new AccessModifier(compiler, -1, -1);
        	this.childClasses = new ArrayListIReset(10);
        	
        	listOfFunctionParams.resizeInc = 20;
        	listOfVariableParams.resizeInc = 50;
        }
        
        public String toString() {
        	ArrayListChar r = new ArrayListChar(100);
			if (this.accessModifier!=null) {
				r.add(accessModifier.toString());
			}
        	
        	if (isEnum) {
        		//r.add("enum ");
        		r.add(this.name);
        	}
        	else if (isInterface) {
        		//r.add("interface ");
        		r.add(this.name);
        	}
        	else {
        		r.add("class ");
        		r.add(this.name);
        	}
        	
        	if (this.classNameToExtend!=null) {
        		r.add(" extends ");
        		r.add(this.classNameToExtend);
        	}
        	
        	if (this.interfaceNamesToImplement!=null && this.interfaceNamesToImplement.count>0) {
        		int i;
        		r.add(" implements ");
        		r.add(this.interfaceNamesToImplement.getItem(0)); // 맨 처음 이름
        		for (i=1; i<this.interfaceNamesToImplement.count; i++) { // 두번째부터 마지막까지
        			r.add(", ");
        			r.add(this.interfaceNamesToImplement.getItem(i));        			
        		}
        	}
        	return new String(r.getItems());
        }
        
        /** FindFunctionParams[]로 생성자들을 리턴한다.*/
        public ArrayList getConstructors() {
        	int i;
        	ArrayList r = new ArrayList(2);
        	for (i=0; i<this.listOfFunctionParams.count; i++) {
        		FindFunctionParams func = (FindFunctionParams) this.listOfFunctionParams.getItem(i);
        		if (func.isConstructor) r.add(func);
        	}
        	return r;
        }
        
        boolean hasChildClass(String fullName) {
        	if (fullName==null) return false;
        	int i;
        	for (i=0; i<this.childClasses.count; i++) {
        		FindClassParams c = (FindClassParams) childClasses.getItem(i);
        		if (c.name!=null && c.name.equals(fullName)) return true;
        	}
    		return false;
        }
        
        /** listOfVariableParams에서 var와 동일한 변수를 갖고있는지 확인한다.*/
        boolean hasVar(FindVarParams var) {
        	int i;
        	for (i=0; i<listOfVariableParams.count; i++) {
        		FindVarParams v = (FindVarParams) listOfVariableParams.getItem(i);
        		if (v.equals(var)) return true;
        	}
        	return false;
        }
        
        /**현재 클래스가 func를 override하면 그 함수를 리턴한다.*/
        FindFunctionParams hasOverrided(FindFunctionParams func, int coreThreadID) {
        	int i;
        	for (i=0; i<listOfFunctionParams.count; i++) {
        		FindFunctionParams f = (FindFunctionParams) listOfFunctionParams.getItem(i);
        		try {
            		if (f.equals(func, coreThreadID)) 
            			return f;
            		}catch(Exception e) {
            			if (Common_Settings.g_printsLog) e.printStackTrace();
            		}
        	}
        	return null;
        }
        
        
        
        /** listOfFunctionParamsInherited와 listOfFunctionParams에서 func 와 동일한 함수를 갖고있는지 확인한다.
         * func 와 동일한 함수를 리턴한다.
         * findMembersInherited()에서 func가 override되는 지를 알기위해 호출한다.*/
        FindFunctionParams hasFunc(FindFunctionParams func, int coreThreadID) {
        	int i;
        	for (i=0; i<listOfFunctionParamsInherited.count; i++) {
        		FindFunctionParams f = (FindFunctionParams) listOfFunctionParamsInherited.getItem(i);
        		try {
            		if (f.equals(func, coreThreadID)) 
            			return f;
            		}catch(Exception e) {
            			if (Common_Settings.g_printsLog) e.printStackTrace();
            		}
        	}
        	for (i=0; i<listOfFunctionParams.count; i++) {
        		FindFunctionParams f = (FindFunctionParams) listOfFunctionParams.getItem(i);
        		try {
            		if (f.equals(func, coreThreadID)) 
            			return f;
            		}catch(Exception e) {
            			if (Common_Settings.g_printsLog) e.printStackTrace();
            		}
        	}
        	return null;
        }
        
        public FindVarParams getMemberVar(FindVarParams memberVar) {
        	int i;
        	for (i=0; i<this.listOfVariableParams.count; i++) {
        		FindVarParams var = (FindVarParams) this.listOfVariableParams.getItem(i);
        		if (var.equals(memberVar)) return var;
        	}
        	return null;
        }
        
        /** listOfVarParamsInherited에서 var 를 이미 상속했는지 확인한다.*/
        boolean hasVarInheritted(FindVarParams var) {
        	int i;
        	for (i=0; i<listOfVarParamsInherited.count; i++) {
        		FindVarParams v = (FindVarParams) listOfVarParamsInherited.getItem(i);
        		if (v.equals(var)) return true;
        	}
        	return false;
        }
        /** listOfVarParamsInherited에서 fieldName 를 가진 변수를 이미 상속했는지 확인한다.*/
        boolean hasVarInheritted(String fieldName) {
        	int i;
        	for (i=0; i<listOfVarParamsInherited.count; i++) {
        		FindVarParams v = (FindVarParams) listOfVarParamsInherited.getItem(i);
        		if (v.fieldName==null) {
        			continue;
        		}
        		if (v.fieldName.equals(fieldName)) return true;
        	}
        	return false;
        }
        /** listOfFunctionParamsInherited에서 func 를 이미 상속했는지 확인한다.*/
        boolean hasFuncInheritted(FindFunctionParams func) {
        	int i;
        	for (i=0; i<listOfFunctionParamsInherited.count; i++) {
        		FindFunctionParams f = (FindFunctionParams) listOfFunctionParamsInherited.getItem(i);
        		try {
        		if (f.equals(func)) 
        			return true;
        		}catch(Exception e) {
        			if (Common_Settings.g_printsLog) e.printStackTrace();
        		}
        	}
        	return false;
        }
        
        /** 모든 메모리 자원들을 해제한다.
         * 클래스의 메모리가 해제될때 compiler(자바문서파일을 표현)가 사용하는 메모리도 모두 해제된다.*/
        public void destroy() {        	
        	if (this.disposed) return;
        	this.disposed = true;
        	
        	super.destroy();
        	
        	if (this.accessModifier!=null) {
        		this.accessModifier.destroy();
        		this.accessModifier = null;
        	}
        	if (this.childClasses!=null) {
        		this.childClasses.destroy();
        		this.childClasses = null;
        	}
        	if (this.classIndex!=null) {
        		this.classIndex.destroy();
        		this.classIndex = null;
        	}
        	if (this.classNameIndex!=null) {
        		this.classNameIndex.destroy();
        		this.classNameIndex = null;
        	}
        	if (this.classNameToExtend!=null) {
        		this.classNameToExtend = null;
        	}
        	if (this.classToExtend!=null) {
        		this.classToExtend.destroy();
        		this.classToExtend = null;
        	}
        	if (this.docuComment!=null) {
        		this.docuComment.destroy();
        		this.docuComment = null;
        	}
        	if (this.endIndex!=null) {
        		this.endIndex.destroy();
        		this.endIndex = null;
        	}
        	if (this.endIndexOfClassNameToExtend!=null) {
        		this.endIndexOfClassNameToExtend.destroy();
        		this.endIndexOfClassNameToExtend = null;
        	}
        	if (this.endIndexOfEventHandlerName!=null) {
        		this.endIndexOfEventHandlerName.destroy();
        		this.endIndexOfEventHandlerName = null;
        	}
        	if (this.findBlockParams!=null) {
        		this.findBlockParams.destroy();
        		this.findBlockParams = null;
        	}
        	if (this.indexOfExtends!=null) {
        		this.indexOfExtends.destroy();
        		this.indexOfExtends = null;
        	}
        	if (this.indexOfImplements!=null) {
        		this.indexOfImplements.destroy();
        		this.indexOfImplements = null;
        	}
        	if (this.interfaceNamesToImplement!=null) {
        		this.interfaceNamesToImplement.destroy();
        		this.interfaceNamesToImplement = null;
        	}
        	if (this.interfacesToImplement!=null) {
        		this.interfacesToImplement.destroy();
        		this.interfacesToImplement = null;
        	}
        	if (this.listOfAllVarUses!=null) {
        		this.listOfAllVarUses.destroy();
        		this.listOfAllVarUses = null;
        	}        	
        	if (this.listOfAllVarUsesForFunc!=null) {
        		this.listOfAllVarUsesForFunc.destroy();
        		this.listOfAllVarUsesForFunc = null;
        	} 
        	if (this.listOfAllVarUsesForVar!=null) {
        		this.listOfAllVarUsesForVar.destroy();
        		this.listOfAllVarUsesForVar = null;
        	}
        	if (this.listOfAllVarUsesForVarHashed!=null) {
        		this.listOfAllVarUsesForVarHashed.destroy();
        		this.listOfAllVarUsesForVarHashed = null;
        	}
        	if (this.listOfAllVarUsesForFuncHashed!=null) {
        		this.listOfAllVarUsesForFuncHashed.destroy();
        		this.listOfAllVarUsesForFuncHashed = null;
        	}
        	if (this.listOfConstructor!=null) {
        		this.listOfConstructor.destroy();
        		this.listOfConstructor = null;
        	}
        	if (this.listOfClassesToExtend!=null) {
        		this.listOfClassesToExtend.destroy();
        		this.listOfClassesToExtend = null;
        	} 
        	if (this.listOfControlBlocks!=null) {
        		this.listOfControlBlocks.destroy();
        		this.listOfControlBlocks = null;
        	}
        	if (this.listOfEndIndexOfInterfaceNamesToImplement!=null) {
        		this.listOfEndIndexOfInterfaceNamesToImplement.destroy();
        		this.listOfEndIndexOfInterfaceNamesToImplement = null;
        	}
        	if (this.listOfFunctionParams!=null) {
        		this.listOfFunctionParams.destroy();
        		this.listOfFunctionParams = null;
        	}
        	if (this.listOfFunctionParamsInherited!=null) {
        		this.listOfFunctionParamsInherited.destroy();
        		this.listOfFunctionParamsInherited = null;
        	}
        	if (this.listOfLocalVarsForArrayInit!=null) {
        		this.listOfLocalVarsForArrayInit.destroy();
        		this.listOfLocalVarsForArrayInit = null;
        	}
        	if (this.listOfLocalVarsForArrayInit_arrayLength!=null) {
        		this.listOfLocalVarsForArrayInit_arrayLength.destroy();
        		this.listOfLocalVarsForArrayInit_arrayLength = null;
        	}
        	if (this.listOfSpecialBlocks!=null) {
        		this.listOfSpecialBlocks.destroy();
        		this.listOfSpecialBlocks = null;
        	}
        	if (this.listOfStartIndexOfInterfaceNamesToImplement!=null) {
        		this.listOfStartIndexOfInterfaceNamesToImplement.destroy();
        		this.listOfStartIndexOfInterfaceNamesToImplement = null;
        	}
        	if (this.listOfStatements!=null) {
        		this.listOfStatements.destroy();
        		this.listOfStatements = null;
        	}
        	if (this.listOfTemplatesForImplementing!=null) {
        		this.listOfTemplatesForImplementing.destroy();
        		this.listOfTemplatesForImplementing = null;
        	}
        	if (this.listOfVariableParams!=null) {
        		this.listOfVariableParams.destroy();
        		this.listOfVariableParams = null;
        	}
        	if (this.listOfVariableParamsBeforeProcessLocalVars!=null) {
        		this.listOfVariableParamsBeforeProcessLocalVars.destroy();
        		this.listOfVariableParamsBeforeProcessLocalVars = null;
        	}
        	if (this.listOfVarParamsInherited!=null) {
        		this.listOfVarParamsInherited.destroy();
        		this.listOfVarParamsInherited = null;
        	}
        	/*if (this.staticConstructorThatCompilerMakes!=null) {
        		this.staticConstructorThatCompilerMakes.destroy();
        		this.staticConstructorThatCompilerMakes = null;
        	}*/
        	/*if (this.compiler!=null) {
        		this.compiler.destroy();
        		this.compiler = null;
        	}*/
        	
        }
        
        public void changeToTemplate(String typeNameInTemplatePair) {
        	int i;
        	for (i=0; i<this.listOfVariableParams.count; i++) {
        		FindVarParams var = (FindVarParams) listOfVariableParams.getItem(i);
        		if (var.typeName!=null && var.typeName.equals("java.lang.Object")) {
        			var.typeName = typeNameInTemplatePair;
        		}
        	}
        	
        	for (i=0; i<this.listOfFunctionParams.count; i++) {
        		FindFunctionParams func = (FindFunctionParams) listOfFunctionParams.getItem(i);
        		if (func.returnType!=null && func.returnType.equals("java.lang.Object")) {
        			func.returnType = typeNameInTemplatePair;
        		}
        		int j;
        		for (j=0; j<func.listOfFuncArgs.count; j++) {
        			FindVarParams var = (FindVarParams) func.listOfFuncArgs.getItem(j);
            		if (var.typeName!=null && var.typeName.equals("java.lang.Object")) {
            			var.typeName = typeNameInTemplatePair;
            		}
        		}
        	}
        }
        
        /** parent 와 child 관계가  is a 관계인지를 조사한다. 상속관계, Implement관계 모두 조사
         * parent는 OnTouchListener이고, child는 EditText_Compiler일 경우
         * child의 상속클래스를 찾으면서 클래스 이름이 같거나 구현 인터페이스의 이름이 같은지를 확인한다.
         * @param compiler : compiler defining child*/
        public static boolean isARelation(Compiler compiler, FindClassParams parent, FindClassParams child, int coreThreadID) {
                	
        	if (child==null || parent==null) return false;
        	
        	if (child.name.equals(parent.name)) return true;
        	if (parent.name.equals("java.lang.Object")) return true;
        	
        	String strfullnameTypeCast = parent.name;
        	String strfullnameTarget = child.name;
        	String remainder = null;
			String remainder2 = null;
			int indexOfTemplateLeftPair = strfullnameTypeCast.indexOf("<");
			if (indexOfTemplateLeftPair!=-1) {
				remainder = strfullnameTypeCast.substring(indexOfTemplateLeftPair);
				strfullnameTypeCast = strfullnameTypeCast.substring(0, indexOfTemplateLeftPair);				
			}
			
			int indexOfTemplateLeftPair2 = strfullnameTarget.indexOf("<");
			if (indexOfTemplateLeftPair2!=-1) {
				remainder2 = strfullnameTarget.substring(indexOfTemplateLeftPair2);
				strfullnameTarget = strfullnameTarget.substring(0, indexOfTemplateLeftPair2);				
			}
			if (indexOfTemplateLeftPair!=-1 && indexOfTemplateLeftPair2!=-1) {
				// 템플릿 괄호안 타입이름은 일치해야 한다.
				if (!remainder.equals(remainder2)) return false;
				if (strfullnameTypeCast.equals(strfullnameTarget)) return true;
			}
			else if (indexOfTemplateLeftPair!=-1) {
				// Stack<Character.Subset> stack2 = new Stack()
				// 여기에서 stack2의 타입이름은 com.gsoft.common.util.Stack<java.lang.Character.Subset>이고
				// Stack()의 리턴타입은 com.gsoft.common.util.Stack이다.
				if (strfullnameTypeCast.equals(strfullnameTarget)) return true;
			}
			/*else if (indexOfTemplateLeftPair2!=-1) {
				if (strfullnameTypeCast.equals(strfullnameTarget)) return true;
			}*/
			
        	
        	// parent는 OnTouchListener이고, child는 EditText_Compiler일 경우
        	// child의 상속클래스를 찾으면서 클래스 이름이 같거나 구현 인터페이스의 이름이 같은지를 확인한다.
			
			if (!parent.isInterface) {
				boolean r = isARelation_Class(compiler, parent, child, coreThreadID);
				if (r) return true;
			}
			else {
				boolean r = isARelation_Interface(compiler, parent, child);
				if (r) return true;
			}
        	        	
        	return false;
        }

        /**@param compiler : compiler defining child*/
        static boolean isARelation_Class(Compiler compiler, FindClassParams parent, FindClassParams child, int coreThreadID) {
        	String childName;
        	while (true) {
        		childName = child.name;
        		if (childName.equals("java.lang.Object")) break;
        		
    			// 클래스 이름이 같은지를 확인한다.
    			if (childName.equals(parent.name)) return true;
    			    			
    			if (child.classToExtend==null) {
    				child.classToExtend = Loader.loadClass(compiler, child.classNameToExtend, coreThreadID);
    			}
    			child = child.classToExtend;
    			if (child==null) return false;
        	}
        	return false;
        }
        /**@param compiler : compiler defining child*/
        static boolean isARelation_Interface(Compiler compiler, FindClassParams parent, FindClassParams child) {
        	String childName = child.name;
    		if (childName.equals("java.lang.Object")) return false;
    		
			// 클래스 이름이 같은지를 확인한다.
			if (childName.equals(parent.name)) return true;
			    			
			if (child.interfaceNamesToImplement!=null) {            	
            	int i;
            	for (i=0; i<child.interfaceNamesToImplement.count; i++) {
            		String interfaceName = child.interfaceNamesToImplement.getItem(i);
            		if (interfaceName.equals(parent.name)) return true;
            		
            		FindClassParams interfaceChild = null;
            		try {
            		interfaceChild = (FindClassParams) child.interfacesToImplement.getItem(i);
            		}catch(Exception e) {
            			if (Common_Settings.g_printsLog) e.printStackTrace();
            		}
            		
            		boolean r = isARelation_Interface(compiler, parent, interfaceChild);
            		if (r) return true;	            		
            	}
			}
			if (child.classToExtend!=null) {
				boolean r = isARelation_Interface(compiler, parent, child.classToExtend);
        		if (r) return true;
			}
			return false;
        }
        
        
		public int indexOfExtends() {
			
			if (indexOfExtends==null) return -1;
			return indexOfExtends.index();
		}
		
		public int indexOfImplements() {
			
			if (indexOfImplements==null) return -1;
			return indexOfImplements.index();
		}
		
		public int startIndexOfClassNameToExtend() {
			
			if (startIndexOfClassNameToExtend==null) return -1;
			return startIndexOfClassNameToExtend.index();
		}
		
		public int endIndexOfClassNameToExtend() {
			
			if (endIndexOfClassNameToExtend==null) return -1;
			return endIndexOfClassNameToExtend.index();
		}
	}
	
	
	/**Flag Name Value Interpretation
	ACC_PUBLIC 0x0001 Declared public ; may be accessed	from outside its package.
	ACC_PRIVATE 0x0002 Declared private ; accessible only within the defining class.
	ACC_PROTECTED 0x0004 Declared protected ; may be accessed within subclasses.
	ACC_STATIC 0x0008 Declared static .
	ACC_FINAL 0x0010 Declared final ; must not be over-ridden.
	ACC_SYNCHRONIZED 0x0020 Declared synchronized ; invocation is wrapped in a monitor lock.
	ACC_BRIDGE 0x0040 A bridge method, generated by the	compiler.
	ACC_VARARGS 0x0080 Declared with variable number of	arguments.
	ACC_NATIVE 0x0100 Declared native ; implemented in a language other than Java.
	ACC_ABSTRACT 0x0400 Declared abstract ; no implementa-tion is provided.
	ACC_STRICT 0x0800 Declared strictfp ; floating-point mode is FP-strict
	ACC_SYNTHETIC 0x1000 Declared synthetic ; Not present in the source code.*/
	public static class FindFunctionParams  extends Block  implements IReset {
		/**함수가 인터페이스 메서드 선언이면 true, 일반 메서드이면 false, 
		 * 예를들어 interface OnTouchListener의 boolean OnTouch();는 true*/
		public boolean isAbstractMethod;
		
		/**FindClassesFromTypeDecls에서 returnType(fullname)이 정의되고
		 * (자신이 파일내에 정의하는 클래스를 찾기위하여), 생성자의 경우는 findFunction에서 정의된다.
		 * fieldName은 FindAllClassesAndItsMembers2_sub에서 정해진다. 
		 * 외부클래스는 loadClass에서 정해진다.*/
		public String name;
		/**FindClassesFromTypeDecls에서 returnType(fullname)이 정의되고
		 * (자신이 파일내에 정의하는 클래스를 찾기위하여), 생성자의 경우는 findFunction에서 정의된다.
		 * fieldName은 FindAllClassesAndItsMembers2_sub에서 정해진다.  
		 * 외부클래스는 loadClass에서 정해진다.*/
		public String returnType;
		/**외부라이브러리면 필요*/
		//String[] listOfParamTypes;
		DocuComment docuComment;
		public AccessModifier accessModifier;
		
		/** 바이트코드 생성시에 필요*/
		public FindVarParams thisVar;
		
		/** 소스상에서 함수 이름의 인덱스를 말한다. static 초기화블록의 경우는 static 의 인덱스이다.*/
        public IndexForHighArray functionNameIndex=null;
        
        IndexForHighArray returnTypeStartIndex=null;
        IndexForHighArray returnTypeEndIndex=null;
        
        IndexForHighArray indexOfLeftParenthesis=null;
        IndexForHighArray indexOfRightParenthesis=null;
        
        /** 리턴 타입의 findClassParams*/
        //FindClassParams typeClassParams;
        
        /**FindVarParams[], 함수의 매개변수들, 
         * 또한 외부클래스일 경우는 주석과 fieldName이 없으나 자신이 정의한 클래스는 주석과 fieldName이 있다.*/
        public ArrayListIReset listOfFuncArgs = new ArrayListIReset(10); 
		
        /** FindVarParams[], movedFromBlock==true, Refer to LocalVar.processLocalVarsDefinedInBlock()*/
        public ArrayList listOfLocalVarsToInitialize = new ArrayList(5);
		
		/**FindVarUseParams[]*/
        HighArray listOfAllVarUses/* = new ArrayListIReset(50)*/;
    	
    	 /**FindVarUseParams[]*/
    	HighArray listOfAllVarUsesForVar/* = new ArrayListIReset(30)*/;
    	
    	 /**FindVarUseParams[]*/
    	HighArray listOfAllVarUsesForFunc/* = new ArrayListIReset(10)*/;
		
        
        ArrayListString exceptionNamesToThrow;
		public boolean isConstructor;
		
		/** static 초기화 블럭인지 유무, static 블럭은 리턴타입, 함수이름, 인자 등이 없다.*/
		public boolean isStaticBlock;
		
		//Compiler compiler;
		/** 리턴타입이 템플릿일 경우 null 이 아님*/
		public Template template;
		
		/** 바이트코드에서 클래스파일을 읽을때 null 이 아님*/
		public Method_Info method_Info;
		
		/** 바이트코드를 생성할때
		 *  static 필드들을 초기화하기 위해 컴파일러가 새로 만든 생성자이면 true, 
		 *  그렇지 않으면 false */
		public boolean isConstructorThatInitializesStaticFields = false;
		
		
		/** tableswitch가 있으면 stack map attribute를 쓸때  increases_start_pc_OfLocalVarsBySwitch을 true로 설정하고,
		 * localVar테이블을 쓸때 변수의 start_pc를 store 다음 오프셋으로 설정해야 한다.
		 */
		//public boolean increases_start_pc_OfLocalVarsBySwitch;
		
		/** try-catch가 있으면 stack map attribute를 쓸때  increases_start_pc_OfLocalVarsByTry을 true로 설정하고,
		 * localVar테이블을 쓸때 변수의 start_pc를 store 다음 오프셋으로 설정해야 한다.
		 */
		//public boolean increases_start_pc_OfLocalVarsByTry;
		
		
		/** 이 메서드가 상속클래스의 메서드를 override 할 경우 
		 * 상속클래스의 override 된 virtual 메서드,
		 * 다시말해서 상속클래스의 메서드는 virtual 메서드가 되고 
		 * 자식클래스의 메서드는 override 메서드가 된다.*/
		public FindFunctionParams overridedFindFunctionParams;
		
		
		/** 배열초기화에서 short 범위를 넘어서는 인덱스를 사용하기 위한 지역변수들의 리스트*/ 
		ArrayListIReset listOfLocalVarsForArrayInit = new ArrayListIReset(5);
		
		/** 배열초기화에서 short 범위를 넘어서는 array length를 사용하기 위한 지역변수들의 리스트*/ 
		ArrayListIReset listOfLocalVarsForArrayInit_arrayLength = new ArrayListIReset(5);

		public Code_attribute codeAttribute;

		  /** T getData() {}와 같은 경우 true, 
         * loadClassFromSrc_onlyInterface()의 appleyTypeNameToChangeToTemplateClass()에서 설정한다.*/
		public boolean isTypeNameToChange;
		
		FindVarParams getLocalVar(int indexOfLocalVariableTable) {
			int i;
			for (i=0; i<this.listOfVariableParams.count; i++) {
				FindVarParams v = (FindVarParams) this.listOfVariableParams.getItem(i);
				//if (ByteCode_Types.isVarACatchException(compiler, v)) continue;
				
				if (v.indexOfLocalVariableTable==indexOfLocalVariableTable)
					return v;
			}
			return null;
		}
		
		
		
		int returnTypeStartIndex() {
			if (returnTypeStartIndex==null) return -1;
			return returnTypeStartIndex.index();
		}
		int returnTypeEndIndex() {
			if (returnTypeEndIndex==null) return -1;
			return returnTypeEndIndex.index();
		}
		public int indexOfLeftParenthesis() {
			if (indexOfLeftParenthesis==null) return -1;
			return indexOfLeftParenthesis.index();
		}
		public int indexOfRightParenthesis() {
			if (indexOfRightParenthesis==null) return -1;
			return indexOfRightParenthesis.index();
		}
      
        public boolean hasReturnType() {
        	if (returnTypeStartIndex()!=-1 && returnTypeEndIndex()!=-1) return true;
        	//if (this.returnType!=null) return true;
        	return false;
        }
        
        /** 호출시 returnType이 null이 아니면 그것을 리턴, null이면 소스를 뒤져서 returnType을 설정하고 리턴*/
        String getReturnType( int returnTypeStartIndex, int returnTypeEndIndex, int coreThreadID) {
        	if (returnType!=null) return returnType;
        	else {
	       
        		returnType = Fullname.getFullNameType(compiler, returnTypeStartIndex, returnTypeEndIndex, coreThreadID);
	        	//if (returnType==null) returnType = "";
	        	return returnType;
        	}
        }
        
        /**외부라이브러리면 필요*/
        public FindFunctionParams(Compiler compiler, String funcName) {
        	//super(compiler, -1, -1);
        	this.compiler = compiler;
			this.startIndex = null;
			this.endIndex = null;
			
        	this.name = funcName;
        	
        }
        
        public int functionNameIndex() {
        	if (functionNameIndex==null) return -1;
        	return this.functionNameIndex.index();
        }
        
        /** 함수를 찾았을때 호출, FindAllClassesAndItsMembers2_sub() 참조*/
        void allocateListOfVarUses() {
        	//if (modeAllOrUpdate==ModeAllOrUpdate.All) {
	    		listOfAllVarUses = new HighArray(50);
	        
	        	listOfAllVarUsesForVar = new HighArray(30);
	        	
	        	listOfAllVarUsesForFunc = new HighArray(10);
        	//}
    	}
        
        public FindFunctionParams(Compiler compiler, int startIndex, int endIndex) {
        	//super(compiler, startIndex, endIndex);
        	this.compiler = compiler;
			this.startIndex = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, startIndex);
			this.endIndex = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, endIndex);
			
        	this.compiler = compiler;
        	this.accessModifier = new AccessModifier(compiler, -1, -1);
        	this.startIndex = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, startIndex);
        	this.endIndex = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, endIndex);
        	//this.findBlockParams = new FindBlockParams(-1, -1);
        	listOfFuncArgs.resizeInc = 10;
        	listOfVariableParams.resizeInc = 100;
        	
        }
        
        public void copyTo(FindFunctionParams func) {
        	func.accessModifier = this.accessModifier;
        	func.docuComment = this.docuComment;
        	func.endIndex = this.endIndex;
        	func.exceptionNamesToThrow = this.exceptionNamesToThrow;
        	func.findBlockParams = this.findBlockParams;
        	func.found = this.found;
        	func.functionNameIndex = this.functionNameIndex;
        	func.includesInc = this.includesInc;
        	//func.increases_start_pc_OfLocalVarsBySwitch = this.increases_start_pc_OfLocalVarsBySwitch;
        	//func.increases_start_pc_OfLocalVarsByTry = this.increases_start_pc_OfLocalVarsByTry;
        	func.indexOfLeftParenthesis = this.indexOfLeftParenthesis;
        	func.indexOfRightParenthesis = this.indexOfRightParenthesis;
        	func.isConstructor = this.isConstructor;
        	func.isConstructorThatInitializesStaticFields = this.isConstructorThatInitializesStaticFields;
        	func.isFake = this.isFake;
        	func.isAbstractMethod = this.isAbstractMethod;
        	func.isStaticBlock = this.isStaticBlock;
        	func.isTypeNameToChange = this.isTypeNameToChange;
        	func.listOfAllVarUses = this.listOfAllVarUses;
        	func.listOfAllVarUsesForFunc = this.listOfAllVarUsesForFunc;
        	func.listOfAllVarUsesForVar = this.listOfAllVarUsesForVar;
        	func.listOfControlBlocks = this.listOfControlBlocks;
        	func.listOfFuncArgs = this.listOfFuncArgs;
        	func.listOfLocalVarsForArrayInit = this.listOfLocalVarsForArrayInit;
        	func.listOfLocalVarsForArrayInit_arrayLength = this.listOfLocalVarsForArrayInit_arrayLength;
        	func.listOfSpecialBlocks = this.listOfSpecialBlocks;
        	func.listOfStatements = this.listOfStatements;
        	func.listOfVariableParams = this.listOfVariableParams;
        	func.listOfVariableParamsBeforeProcessLocalVars = this.listOfVariableParamsBeforeProcessLocalVars;
        	func.name = this.name;
        	func.overridedFindFunctionParams = this.overridedFindFunctionParams;
        	func.parent = this.parent;
        	func.returnType = this.returnType;
        	func.returnTypeEndIndex = this.returnTypeEndIndex;
        	func.returnTypeStartIndex = this.returnTypeStartIndex;
        	func.startIndex = this.startIndex;
        	func.template = this.template;
        	func.thisVar = this.thisVar;
        }
        
        /** 바이트코드를 생성할 때 호출한다.*/
		public String getMethodInfoStr(int coreThreadID) {
			String typeDescParent = TypeDescriptor.getDescriptorExceptLAndSemicolon((FindClassParams)parent, coreThreadID);
			String typeDesc = TypeDescriptor.getDescriptor(this, coreThreadID);
			
			String methodName = null;
			if (this.isConstructor) {
				if (this.isConstructorThatInitializesStaticFields) methodName = "<clinit>";
				else methodName = "<init>";
			}
			else methodName = this.name;
        	return typeDescParent + "::" + typeDesc + " " + methodName;
		}
		
		 /** 바이트코드를 생성할 때 필요*/
        public String getFunctionStr(int coreThreadID) {
        	String typeDesc = TypeDescriptor.getDescriptor(this, coreThreadID);
        	String methodName = null;
			if (this.isConstructor) {
				if (this.isConstructorThatInitializesStaticFields) methodName = "<clinit>";
				else methodName = "<init>";
			}
			else methodName = this.name;
        	return typeDesc + " " + methodName;
        }
       
        
        public String toString() {
        	ArrayListChar r = new ArrayListChar(100);
        	
        	String message = "";
			if (this.accessModifier!=null) {
				message = accessModifier.toString();
			}
			r.add(message);
			
			String funcName;
			funcName = this.name;
			String returnTypeOfFunc = "";
			if (!(this.isConstructor || this.isStaticBlock))
				returnTypeOfFunc = this.returnType + " ";
			r.add(returnTypeOfFunc);
			
			r.add(funcName);
			
			int k;
			r.add("(");
			for (k=0; k<this.listOfFuncArgs.count; k++) {
				FindVarParams arg = (FindVarParams)this.listOfFuncArgs.getItem(k);
				String typeName = arg.typeName;
				r.add(typeName);
				if (arg.fieldName!=null) {
					r.add(" "+arg.fieldName);
				}
				else {
					r.add(" "+"p"+k);
				}
				if (k!=this.listOfFuncArgs.count-1) {
					r.add(", ");
				}
			}
			r.add(")");
			
			
			//return message + returnTypeOfFunc + funcName + "(" + args + ")";
			return new String(r.getItems());
    	}
        
        boolean hasEqualItemOfFuncArgs(FindVarParams item) {
        	int i;
        	FindVarParams var;
        	for (i=0; i<listOfFuncArgs.count; i++) {
        		var = (FindVarParams)listOfFuncArgs.getItem(i);
        		if (var.equals(item)) return true;
        	}
        	return false;
        }
        

        /**Gets a variable from listOfVariableParamsBeforeProcessLocalVars*/
        public FindVarParams getVar(String fieldName) {
        	int i;
        	if (listOfVariableParamsBeforeProcessLocalVars!=null) {
        		// after processLocalVar()
	        	for (i=0; i<this.listOfVariableParamsBeforeProcessLocalVars.count; i++) {
	        		FindVarParams var = (FindVarParams) this.listOfVariableParamsBeforeProcessLocalVars.getItem(i);
	        		if (var.fieldName.equals(fieldName)) return var;
	        	}
        	}
        	else {
        		// before processLocalVar()
        		for (i=0; i<this.listOfVariableParams.count; i++) {
            		FindVarParams var = (FindVarParams) this.listOfVariableParams.getItem(i);
            		if (var.fieldName.equals(fieldName)) return var;
            	}
        	}
        	return null;
        }
        
        
        public FindVarParams getLocalVar(FindVarParams localVar) {
        	int i;
        	boolean isStatic = this.accessModifier.isStatic;
        	int indexOfLocalVariableTable = 0;
        	if (isStatic) {
        		
        	}
        	else {
        		indexOfLocalVariableTable++;
        	}
        	for (i=0; i<this.listOfVariableParams.count; i++) {
        		FindVarParams var = (FindVarParams) this.listOfVariableParams.getItem(i);
        		var.indexOfLocalVariableTable = indexOfLocalVariableTable;
        		if (var.equals(localVar)) return var;
        		if (var.typeName.equals("long") || var.typeName.equals("double")) {
        			indexOfLocalVariableTable += 2;
        		}
        		else {
        			indexOfLocalVariableTable++;
        		}
        	}
        	return null;
        }
        
        /** 함수 이름이 일치하고 파라미터 하나씩 full name으로 타입이름을 확인한다.
         * @param funcName : varUseName*/
        public boolean equals(FindFunctionParams func, int coreThreadID) {
        	try {
        		String funcName = func.name;
        		ArrayListIReset listOfFuncArgsOfFunc = func.listOfFuncArgs;
        		
	        	if (funcName==null) return false;
	        	//if (listOfFuncCallParams==null) return false;
	        	
	        	String ownFuncName;
	        	ownFuncName = this.name;
	        	try {
	        	if (!ownFuncName.equals(funcName)) return false;
	        	}catch(Exception e) {
	        		if (Common_Settings.g_printsLog) e.printStackTrace();
	        		
	        	}
	        	
	        	if (funcName.equals("add")) {
	        	}
	        	
	        	FindVarParams var;
	        	FindVarParams varOfFunc;
	        	int i;
	        	// 파라미터 개수가 일치하지 않으면 타입검사를 안함
	        	if (this.listOfFuncArgs.count!=listOfFuncArgsOfFunc.count) return false;
	        	
        	
	        	for (i=0; i<listOfFuncArgs.count; i++) {
	        		var = (FindVarParams)listOfFuncArgs.getItem(i);
	        		
	        		try{
	        		var.getType( var.typeStartIndex(), var.typeEndIndex(), coreThreadID);
	        		}catch(Exception e) {
	        			Log.e(e.getMessage(), "func name:"+ownFuncName+", var name:"+var.fieldName);
	        		}
	        		varOfFunc = (FindVarParams)listOfFuncArgsOfFunc.getItem(i);
	        		//if (var.fieldName==null || varOfFunc.fieldName==null) {
	        			// 어떤 클래스를 바이트코드에서 읽으면 fieldName은 null 이다.
	        			if (!var.typeName.equals(varOfFunc.typeName)) return false;
	        		//}
	        		//if (var.equals(varOfFunc)==false) return false;
	        		
	        		
	        	}//for (i=0; i<listOfFuncArgs.count; i++) {
	        	
	        	if (this.isConstructor && func.isConstructor) {
	        		if (this.accessModifier!=null && func.accessModifier!=null) {
		        		if (this.accessModifier.isStatic!=func.accessModifier.isStatic)
		        			return false;
	        		}
	        	}
	        	
	        	return true;
        	}catch(Exception e) {
        		if (Common_Settings.g_printsLog) e.printStackTrace();
        		if (Common_Settings.g_printsLog) CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
        		return false;
        	}
        	
        }
        
        /** 함수 이름이 일치하고 파라미터 하나씩 full name으로 타입이름을 확인하고 또한 is a 관계인지를 확인한다.<br>
         * new ProcessBuilder("java", "-jar", "***.jar")와 같은 함수인 경우<br>
			System.out.printf("%d %f", 1, 0.5f)와 같은 함수인 경우인지를 확인한다.<br>
			String.format("%d", 1);<br>
         * @param compiler : varUse(funcCall)을 갖는 소스 Compiler (this.compiler has func)
         * @param funcName : varUseName
         * @param wayOfCheck : 0이면 타입이름이 완전히 일치해야만 true, 1이면 호환성이 있으면 true*/
        boolean equals(Compiler compiler, String funcName, ArrayListIReset listOfFuncCallParams, FindVarUseParams varUse, int coreThreadID) {
        	try {
	        	if (funcName==null) return false;
	        	if (listOfFuncCallParams==null) return false;
	        		        	
	        	        	
	        	String ownFuncName;
	        	ownFuncName = this.name;
	        	if (!ownFuncName.equals(funcName)) return false;
	        	
	        	
	        	FindVarParams var;
	        	FindFuncCallParam funcCallParam;
	        	int i;
	        	String typeName1 = null; // 함수선언 파라미터의 타입
	        	String typeName2;		// 함수호출 파라미터의 타입
	        	        	
	        		
	        	     // 파라미터 개수가 일치하지 않으면 타입검사를 안함
	        	if (this.listOfFuncArgs.count!=listOfFuncCallParams.count) {
	        		/*if (listOfFuncArgs.count==1) {
		        		
		        	}*/
	        		int argIndexOfArray = 
	        				Member.funcArgIsArrayAndFuncCallParamsIsElementTypeList(compiler, varUse, this, coreThreadID);
	        		if (argIndexOfArray!=-1) {
    					boolean r = this.equals_ArrayArg(compiler, listOfFuncCallParams, argIndexOfArray, coreThreadID);
    					if (!r) return false;
    					else {
    						TempLocalArrayInitializer tempLocalArrayInit = 
    								new TempLocalArrayInitializer(varUse, (FindVarParams)this.listOfFuncArgs.getItem(argIndexOfArray));
    						// compiler having varUse(listOfFuncCallParams)
    						compiler.data.mlistOfTempLocalArrayInitializers.add(tempLocalArrayInit);
    						return true;
    					}
    				}
	        		else {
	        			return false;
	        		}
	        	}//if (this.listOfFuncArgs.count!=listOfFuncCallParams.count) {
	        	
	        	else  {
	        		if ( (varUse!=null && varUse.name.equals("printf") && varUse.parent!=null && varUse.parent.name.equals("out") ) ||
	        				/** System.out.printf(...)*/
		        		 (varUse!=null && varUse.name.equals("ProcessBuilder") ) ||
		        		 /** new ProcessBuilder(...)*/
		        		 (varUse!=null && varUse.name.equals("command") && varUse.parent!=null && varUse.parent.varDecl!=null &&
		        				 varUse.parent.varDecl.typeName.equals("java.lang.ProcessBuilder") ) ||
		        		 /** builder.command(...)*/
		        		 (varUse!=null && varUse.name.equals("format") && varUse.parent!=null && varUse.parent.memberDecl!=null &&
		        				 varUse.parent.name.equals("String") )
		        		 /** String.format(...)*/
		        		)
	        			 
	        		{
		        		// System.out.printf("%d", 111);
		        		// ProcessBuilder("AAA.exe");
		        		int argIndexOfArray = 
		        				Member.funcArgIsArrayAndFuncCallParamsIsElementTypeList(compiler, varUse, this, coreThreadID);
		        		if (argIndexOfArray!=-1) {
	    					boolean r = this.equals_ArrayArg(compiler, listOfFuncCallParams, argIndexOfArray, coreThreadID);
	    					if (!r) return false;
	    					else {
	    						TempLocalArrayInitializer tempLocalArrayInit = 
	    								new TempLocalArrayInitializer(varUse, (FindVarParams)this.listOfFuncArgs.getItem(argIndexOfArray));
	    						// compiler having varUse(listOfFuncCallParams)
	    						compiler.data.mlistOfTempLocalArrayInitializers.add(tempLocalArrayInit);
	    						return true;
	    					}
	    				}
	        		}
	        	}//else  {
	        	
        	
	        	for (i=0; i<listOfFuncArgs.count; i++) {
	        		var = (FindVarParams)listOfFuncArgs.getItem(i);
	        		
	        		try{
	        			typeName1 = var.getType( var.typeStartIndex(), var.typeEndIndex(), coreThreadID);
	        		}catch(Exception e) {
	        			Log.e(e.getMessage(), "func name:"+ownFuncName+", var name:"+var.fieldName);
	        		}
	        		funcCallParam = (FindFuncCallParam)listOfFuncCallParams.getItem(i);
	        		if (funcCallParam==null || funcCallParam.typeFullName==null)
	        			typeName2 = null;
	        		else typeName2 = funcCallParam.typeFullName.str;
	        		
	        		if (typeName2==null) return false;
	        		
	        		     // 함수호출 파라미터가 null인 경우 타입검사를 안함, menu.open(null, false);
	        		if (typeName2.equals("null") && !CompilerHelper.IsDefaultType(typeName1)) {
	        			continue;
	        		}
	        		
	        		if (typeName1==null) {
	        		}
        			boolean isCompatible = 
        					TypeCast_Syntax.isCompatibleType(this.compiler, compiler, new CodeStringEx(typeName1), 
        							new CodeStringEx(typeName2), 2, funcCallParam, coreThreadID);
        			if (!isCompatible) {        				
        				return false;
        			}
	        	}//for (i=0; i<listOfFuncArgs.count; i++) {
	        	
	        	if (this.isConstructor && varUse.name.equals("super")) {
	        		AccessModifier accessModifier = ((FindFunctionParams)varUse.funcToDefineThisVarUse).accessModifier;
	        		if (this.accessModifier!=null && accessModifier!=null) {
		        		if (this.accessModifier.isStatic!=accessModifier.isStatic)
		        			return false;
	        		}
	        	}
	        	
	        	return true;
        	}catch(Exception e) {
        		if (Common_Settings.g_printsLog) e.printStackTrace();
        		if (Common_Settings.g_printsLog) CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
        		return false;
        	}
        	
        }
        /**new ProcessBuilder("java", "-jar", "***.jar")와 같은 함수인 경우<br>
		System.out.printf("%d %f", 1, 0.5f)와 같은 함수인 경우인지를 확인한다.<br>
		String.format("%d", 1);<br>
		@param compiler : compiler having listOfFuncCallParams (this.compiler has func)*/
        boolean equals_ArrayArg(Compiler compiler, ArrayListIReset listOfFuncCallParams, int argIndexOfArray, int coreThreadID) {
        	//HighArray_CodeString src = compiler.data.mBuffer;
        	FindVarParams var = (FindVarParams)listOfFuncArgs.getItem(argIndexOfArray);
    		String typeName1 = var.getType( var.typeStartIndex(), var.typeEndIndex(), coreThreadID);
    		if (typeName1==null) {
    		}
    		if (Array.getArrayDimension(this.compiler, typeName1)!=0) {
    			String elementTypeName = Array.getArrayElementType(typeName1);
    			// ProcessBuilder의 command()함수는 스트링 여러개를 인자로 받는 
    			// java.util.List와 String[]를 파라미터로 갖고있다.
    	  		     // 여기서는 String[]와 일치하는지 확인한다.
    			boolean isEqual = false;
    			int i;
    			for (i=argIndexOfArray; i<listOfFuncCallParams.count; i++) {
    				FindFuncCallParam funcCallParam = (FindFuncCallParam)listOfFuncCallParams.getItem(i);
    				if (funcCallParam.typeFullName==null) return false;
	        		String typeName2 = funcCallParam.typeFullName.str;
	        		// String과 호환되는지 확인한다.
	        		boolean isCompatible = 
	        				TypeCast_Syntax.isCompatibleType_funcArgIsArrayAndFuncCallParamsIsElementTypeList(this.compiler, 
	        						compiler,
	        						new CodeStringEx(elementTypeName), 
	        						new CodeStringEx(typeName2), 2, null, coreThreadID);
        			if (!isCompatible) {
        				break;
        			}
    			}
    			if (i!=0 && i==listOfFuncCallParams.count) {
    				isEqual = true;
    			}
    			if (isEqual) return true;
    		}
    		return false;
        }
             
        
        public boolean isFuncArg(FindVarParams var) {
        	int i;
        	for (i=0; i<this.listOfFuncArgs.count; i++) {
        		FindVarParams arg = (FindVarParams) this.listOfFuncArgs.getItem(i);
        		if (arg==var) return true;
        	}
        	return false;
        }

		@Override
		public void destroy() {
			
			if (this.accessModifier!=null) {
				this.accessModifier.destroy();
				accessModifier = null;
			}
			if (this.docuComment!=null) {
				this.docuComment.destroy();
				docuComment = null;
			}
			if (this.exceptionNamesToThrow!=null) {
				exceptionNamesToThrow.destroy();
				exceptionNamesToThrow = null;
			}
			if (this.findBlockParams!=null) {
				this.findBlockParams.destroy();
				findBlockParams = null;
			}
			if (this.listOfControlBlocks!=null) {
				this.listOfControlBlocks.destroy();
				listOfControlBlocks = null;
			}
			if (this.listOfFuncArgs!=null) {
				this.listOfFuncArgs.destroy();
				listOfFuncArgs = null;
			}
			if (this.listOfAllVarUses!=null) {
				this.listOfAllVarUses.destroy();
				listOfAllVarUses = null;
			}
			if (this.listOfAllVarUsesForFunc!=null) {
				this.listOfAllVarUsesForFunc.destroy();
				listOfAllVarUsesForFunc = null;
			}
			if (this.listOfAllVarUsesForVar!=null) {
				this.listOfAllVarUsesForVar.destroy();
				listOfAllVarUsesForVar = null;
			}
			if (this.listOfSpecialBlocks!=null) {
				this.listOfSpecialBlocks.destroy();
				listOfSpecialBlocks = null;
			}
			if (this.listOfStatements!=null) {
				this.listOfStatements.destroy();
				listOfStatements = null;
			}
			if (this.listOfVariableParams!=null) {
				this.listOfVariableParams.destroy();
				listOfVariableParams = null;
			}
			if (this.template!=null) {
				this.template.destroy();
				template = null;
			}
			if (this.method_Info!=null) {
				this.method_Info.destroy();
				method_Info = null;
			}
			this.name = null;
			this.returnType = null;
			this.parent = null;
			this.compiler = null;
		}
	}
	
	
	
	/**Flag Name 		Value Interpretation 
	 * ACC_PUBLIC 		0x0001 Declared public; may be accessed from outside its package. 
	 * ACC_PRIVATE 		0x0002 Declared private; usable only within the defining class. 
	 * ACC_PROTECTED 	0x0004 Declared protected; may be accessed within subclasses. 
	 * ACC_STATIC 		0x0008 Declared static. 
	 * ACC_FINAL	 	0x0010 Declared final; no further assignment after initialization. 
	 * ACC_VOLATILE 	0x0040 Declared volatile; cannot be cached. 
	 * ACC_TRANSIENT 	0x0080 Declaredtransient; not written or read by a persistent object manager. 
	 * ACC_SYNTHETIC 	0x1000 Declared synthetic; Not present in the source code. 
	 * ACC_ENUM 		0x4000 Declared as an element of an enum.*/
	public static class FindVarParams extends FindStatementParams  implements IReset {
		/**FindClassesFromTypeDecls에서 typeName(fullname)이 정의되고
		 * (자신이 파일내에 정의하는 클래스를 찾기위하여) 
		 * fieldName은 FindAllClassesAndItsMembers2_sub에서 정해진다. 
		 * 외부클래스는 loadClass에서 정해진다. */
		public String typeName;
		/**FindClassesFromTypeDecls에서 typeName(fullname)이 정의되고
		 * (자신이 파일내에 정의하는 클래스를 찾기위하여) 
		 * fieldName은 FindAllClassesAndItsMembers2_sub에서 정해진다. 
		 * enum 변수일 경우는 FindAllClassesAndItsMembers2_sub의 varUse를 다룰때 정의된다. 
		 * 또한 외부클래스일 경우는 fieldName이 없으나 자신이 정의한 클래스는 fieldName이 있다. 
		 * 외부클래스는 loadClass에서 정해진다.*/
		public String fieldName;
		
		DocuComment docuComment;
		public AccessModifier accessModifier;
		//int startIndex = -1;
		//int endIndex = -1;
        //boolean found;
		
		/** 바이트코드 생성시에 필요하다. 지역변수에만 해당, 함수의 listOfVarParams에서의 인덱스, 
		 * 중복되는 변수들을 모두 제거한 이후의 listOfVarParams이다. (compiler.processLocalVars()을 참조)*/
		//public int indexOfLocalVarsInFunction;
		
		/** 바이트코드 생성시에 필요하다. 지역변수에만 해당, 함수의 listOfVarParams에서의 인덱스, 
		 * 중복되는 변수들을 제거하면 원래의 listOfVarParams와 틀린 변수들을 갖게 되므로 
		 * compiler.processLocalVars()을 호출하기 이전(중복되는 변수들을 제거하기 이전)의 
		 * 원래의 listOfVarParams의 변수들을 갖는 백업리스트에서의 인덱스이다.
		 * (compiler.FindAllClassesAndItsMembers2_sub()을 참조)*/
		public int indexOfLocalVarsInFunctionBeforeProcessLocalVars = -1;
        
		/** 바이트코드 생성시에 필요하다. LocalVariableTable에서 지역변수 엔트리의 인덱스, 
		 * (compiler.processLocalVars()을 참조)*/
		public int indexOfLocalVariableTable;
        
		
		
		IndexForHighArray typeStartIndex=null;
		IndexForHighArray typeEndIndex=null;
        /** 변수 타입의 findClassParams*/
        public //FindClassParams typeClassParams;
        
        IndexForHighArray varNameIndex=null;
        /** var가 선언되는 Block, 함수, 제어블록, 클래스등이 될 수 있다.*/
        private HighArray listOfVarUses = new HighArray(10); // class 또는 함수 내에서 변수의 사용
        
        public boolean isMemberOrLocal;
        /** 변수선언시부터*/
        public IndexForHighArray startIndexOfScope = null;
        /** 변수가 선언된 블록의 '}' 바로 전까지*/
        public IndexForHighArray endIndexOfScope = null;
        
        /**바이트 코드 생성시에 지역변수의 라이프타임, code[]에서의 시작 인덱스, 
         * 변수가 정의된 이후에 최초로 값이 저장될 때를 start_pcOfScope로 삼는다.*/
        public int start_pcOfScope = -1;
        /**바이트 코드 생성시에 지역변수의 라이프타임, code[]에서의 끝 인덱스*/
        public int end_pcOfScope = -1;
        
        public int startIndexOfScope() {
        	if (startIndexOfScope==null) return -1;
        	return startIndexOfScope.index();
        }
        
        public int endIndexOfScope() {
        	if (endIndexOfScope==null) return -1;
        	return endIndexOfScope.index();
        }
        
        public boolean isThis;
        //boolean isClass;
        public boolean isSuper;
       
        
        /** enum 변수일 경우 true*/
        boolean isEnumElement;
       
        /** class stack {} 에 붙는 화살표안 괄호안의 템플릿을 말한다.*/
        Template templateOfClass;
        
        /** 타입이 템플릿이면 널이 아님, HighArray listOfAllVarUses; 이와 같은 변수선언을 말한다.
         * FindClassesFromTypeDecls()에서 getFullNameType()을 통해 
         * template.typeName, template.typeNameToChange가 정해진다.*/
        Template template;
        
        /** T data;와 같은 경우 true, 
         * loadClassFromSrc_onlyInterface()의 appleyTypeNameToChangeToTemplateClass()에서 설정한다.*/
        boolean isTypeNameToChange;
        
        //Compiler compiler;
        
        /** 바이트코드에서 클래스파일을 읽을때 null 이 아님*/
		public Field_Info field_Info;
		
		
		
		
		
		/** compiler.processLocalVars(), StackMapTable_attribute(YYY)를 참조한다.
		 *  지역변수일 경우 스코프는 허용되나 중복되는 변수들은 변수 하나만 사용하기 위한 변수,
		 *  중복 변수일 경우 null이 아니며 기억장소를 공유하는 원래의 변수를 가리킨다.
		 *  {int a;}
		 *  {int b;} b가 a를 공유하면 b.sharedVar는 a가 된다. */
		public FindVarParams sharedVar;
				
		/**변수가 어떤 변수에 의해 공유중이면 true이다.
		 * Compiler.findReusableLocalVar_processLocalVars()에서 공유변수를 찾기위해서 사용하는 임시변수이다.
		 */
		public boolean usedInProcessLocalVars;
		
		/** 변수가 어떤 변수에 의해 공유되면 그 변수를 말한다.
		 * Compiler.findReusableLocalVar_processLocalVars()에서 공유변수를 찾기위해서 사용하는 임시변수이다.*/
		public FindVarParams sharedBy;
		
		
		
		
		/** 현재 변수를 처음으로 초기화하는 할당문*/
		public FindAssignStatementParams assignStatementThatInitializeLocalVarFirst;
		
		/**초기화하지 않은 변수*/
		public boolean isNotInitialized;
		
		
		public boolean isNotInitialized() {
			if (this.isFake) {
				return true;
			}
			String varUseName = compiler.data.mBuffer.getItem(this.varNameIndex()).str;
			if (CompilerStatic.getVarUseWithIndex(compiler.data.mlistOfAllVarUsesHashed, varUseName, this.varNameIndex())!=null)
				return false;
			return true;
		}
		
		/**초기화한 블록, 지역변수 초기화 에러를 일으키지 않게하는 블록, assignStatementInitializeLocalVarCertainly() 참조*/
		public Block blockInitializing;
		
		
		
		
		/**변수가 값을 가질 경우 변수의 값, ValueSetter참조*/
		public String value;
		
		/**변수가 값을 가질 경우 변수가 배열이면 갖고있는 값들, ValueSetter참조*/
		public String listOfValues;
		
		
		
		
		/**switch 안에서 선언된 지역변수가 밖으로 빼내졌으면 true, 
		 * LocalVar.processLocalVarsDefinedInSwitch()을 참조한다.*/
		//public boolean movedFromSwitch;
		/**LocalVar.processLocalVarsDefinedInSwitch()에 의해 이동되기 전에 블록, 원래 있던 블록, 선언시 블록*/
		//public Block blockBeforeMovingFromSwitch;
		/**LocalVar.processLocalVarsDefinedInSwitch()에 의해 이동된 후에 블록, switch.parent가 된다.*/
		//public Block blockAfterMovingFromSwitch;
		
		
		/**continue 이후에 선언된 지역변수가 밖으로 빼내졌으면 true, 
		 * LocalVar.processLocalVarsDefinedInContinue()을 참조한다.*/
		//public boolean movedFromContinue;
		/**LocalVar.processLocalVarsDefinedInContinue()에 의해 이동되기 전에 블록, 원래 있던 블록, 선언시 블록*/
		//public Block blockBeforeMovingFromContinue;
		/**LocalVar.processLocalVarsDefinedInContinue()에 의해 이동된 후에 블록, continue.parent가 된다.*/
		//public Block blockAfterMovingFromContinue;
		
		/**forLoop 이후에 선언된 지역변수가 밖으로 빼내졌으면 true, 
		 * LocalVar.processLocalVarsDefinedInForLoop()을 참조한다.*/
		//public boolean movedFromForLoop;
		/**LocalVar.processLocalVarsDefinedInForLoop()에 의해 이동되기 전에 블록, 원래 있던 블록, 선언시 블록*/
		//public Block blockBeforeMovingFromForLoop;
		/**LocalVar.processLocalVarsDefinedInForLoop()에 의해 이동된 후에 블록, forLoop.parent가 된다.*/
		//public Block blockAfterMovingFromForLoop;
		
		/**ifBlock 이후에 선언된 지역변수가 밖으로 빼내졌으면 true, 
		 * LocalVar.processLocalVarsDefinedInIFBlock()을 참조한다.*/
		//public boolean movedFromIFBlock;
		/**LocalVar.processLocalVarsDefinedInIFBlock()에 의해 이동되기 전에 블록, 원래 있던 블록, 선언시 블록*/
		//public Block blockBeforeMovingFromIFBlock;
		/**LocalVar.processLocalVarsDefinedInIFBlock()에 의해 이동된 후에 블록, ifBlock.parent가 된다.*/
		//public Block blockAfterMovingFromIFBlock;
		
		
		/**block 안에 선언된 지역변수가 밖으로 빼내졌으면 true, 
		 * LocalVar.processLocalVarsDefinedInBlock()을 참조한다.*/
		public boolean movedFromBlock;
		/**LocalVar.processLocalVarsDefinedInBlock()에 의해 이동되기 전에 블록, 원래 있던 블록, 선언시 블록*/
		public Block blockBeforeMovingFromBlock;
		/**LocalVar.processLocalVarsDefinedInBlock()에 의해 이동된 후에 블록, 최상위 블록이 된다.*/
		public Block blockAfterMovingFromBlock;
		
		/**변수가 for루프의 괄호안에 정의되어 있으면 null이 아니다*/
		//public FindControlBlockParams isDefinedInPairsOfForLoop;
		
		
		
        
        /** full name으로 리턴, 
         * 호출시 typeName이 null이 아니면 그것을 리턴, null이면 소스를 뒤져서 typeName을 설정하고 리턴*/
        String getType(int typeStartIndex, int typeEndIndex, int coreThreadID) {
        	if (this.typeName!=null) {        		
        		return typeName;
        	}
        	else {
        		//if (typeStartIndex==-1 || typeEndIndex==-1) return "";
        		//this.typeName = compiler.getFullNameType(src, typeStartIndex, typeEndIndex);
        		this.typeName = Fullname.getFullNameType(compiler, typeStartIndex, typeEndIndex, coreThreadID);
        		return typeName;
        	}
        }
        
        public int typeStartIndex() {
        	if (typeStartIndex==null) return -1;
        	return this.typeStartIndex.index();
		}
        
        public int typeEndIndex() {
        	if (typeEndIndex==null) return -1;
        	return this.typeEndIndex.index();
		}

		public int varNameIndex() {
        	if (varNameIndex==null) return -1;
        	return this.varNameIndex.index();
        }
		
		 /**Compiler.findAllMemberVarUsing_sub_sub()와 findAllLocalVarUsing_sub()에서 호출한다.*/
        public void addVarUseToListOfVarUses(FindVarUseParams varUse) {
        	
        	this.listOfVarUses.add(varUse);
        }
        
        public HighArray getListOfVarUses() {
        	return this.listOfVarUses;
        }
        
        /**var에 연결된 모든 varUse들의 varDecl을 null로 만든다.*/
        public void setVarDeclOfAllVarUsesToNull() {
        	
        	int i;
        	for (i=0; i<this.listOfVarUses.count; i++) {
        		FindVarUseParams varUse = (FindVarUseParams) this.listOfVarUses.getItem(i);
        		//if (this.varNameIndex()==varUse.index()) continue;
        		varUse.varDecl = null;
        		//listOfVarUses.count--;
        	}
        	listOfVarUses.reset();
        }
        
        public boolean hasVarUseInListOfVarUses(int varUseIndex) {
        	int i;
        	for (i=0; i<this.listOfVarUses.count; i++) {
        		FindVarUseParams varUse = (FindVarUseParams) this.listOfVarUses.getItem(i);
        		if (varUseIndex==varUse.index()) return true;
        	}
        	return false;
        }
        
        /** class Stack {}에서 클래스가 템플릿일 경우 VarUse들을 쉽게 찾기 위해 가상으로 만든 타입선언이다.
         * fieldName은 templateOfClass.typeNameToChange이 된다.*/
        FindVarParams(Compiler compiler, Template templateOfClass, FindClassParams parent) {
        	//super(compiler, -1, -1);
        	this.compiler = compiler;
			this.startIndex = null;
			this.endIndex = null;
			
        	this.templateOfClass = templateOfClass;
        	this.fieldName = templateOfClass.typeNameToChange;
        	this.parent = parent;
        }
        
        /**함수인자일경우 fieldName에 null을 넣어준다.*/
        public FindVarParams(Compiler compiler, String typename, String fieldName) {
        	//super(compiler, -1, -1);
        	this.compiler = compiler;
			this.startIndex = null;
			this.endIndex = null;
			
        	this.typeName = typename;
        	this.fieldName = fieldName;
        }
        
        public FindVarParams(Compiler compiler, int startIndex, int endIndex) {
        	//super(compiler, startIndex, endIndex);
        	this.compiler = compiler;
			this.startIndex = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, startIndex);
			this.endIndex = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, endIndex);
			
        	accessModifier = null;
        }
        
        public FindVarParams(Compiler compiler, boolean isThis, boolean isClass, boolean isSuper, FindClassParams parentClassParams) {
        	//super(compiler, -1, -1);
        	this.compiler = compiler;
			this.startIndex = null;
			this.endIndex = null;
			
        	this.isThis = isThis;
        	//this.isClass = isClass;
        	this.isSuper = isSuper;
        	this.parent = parentClassParams;
        	this.isMemberOrLocal = true;
        	accessModifier = null;
        	listOfVarUses.resizeInc = 30;
        	this.typeName = parentClassParams.name;
        	if (isSuper) {
        		this.typeName = parentClassParams.classNameToExtend;
        	}
        	
        	if (isThis) this.fieldName = "this";
        	if (isSuper) this.fieldName = "super";
        	if (isClass) {
        		this.fieldName = CompilerStatic.getShortName(parentClassParams.name);
        	}
        	
        }
        
        /** EnumElement를 만들때 호출*/
        FindVarParams(Compiler compiler, int varNameIndex, boolean isEnumElement, FindClassParams parentEnumParams) {
        	//super(compiler, -1, -1);
        	this.compiler = compiler;
			this.startIndex = null;
			this.endIndex = null;
			
        	this.isEnumElement = isEnumElement;
        	this.varNameIndex = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, varNameIndex);
        	this.parent = parentEnumParams;
        	this.startIndex = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, varNameIndex);
        	this.endIndex = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, varNameIndex);
        	accessModifier = null;
        	listOfVarUses.resizeInc = 10;
        }
        
        /** 바이트코드를 생성할 때 필요
         * Refer to TypeDescriptor.getDescriptor(FindVarParams) and TypeDescriptor.getDescriptorExceptLAndSemicolon(FindVarParams)*/
        public String getVarStr(int coreThreadID) {
        	String typeDesc = null;
        	if (!this.isMemberOrLocal) {
        		//typeDesc = TypeDescriptor.getDescriptorExceptLAndSemicolon(this);
        		typeDesc = TypeDescriptor.getDescriptor(this, coreThreadID);
        	}
        	else {
        		typeDesc = TypeDescriptor.getDescriptor(this, coreThreadID);
        	}
        	//String typeDesc = TypeDescriptor.getDescriptorExceptLAndSemicolon(this);
        	return typeDesc + " " + fieldName;
        }
        
        /** 바이트코드를 생성할 때 호출한다.
         * Refer to TypeDescriptor.getDescriptor(FindVarParams) and TypeDescriptor.getDescriptorExceptLAndSemicolon(FindVarParams)*/
		public String getFieldInfoStr(int coreThreadID) {
			FindClassParams c = (FindClassParams)parent;
			if (c.name.equals("android.graphics.Color")) {
			}
			String typeDescParent = TypeDescriptor.getDescriptorExceptLAndSemicolon(c, coreThreadID);
			String typeDesc = TypeDescriptor.getDescriptor(this, coreThreadID);
			
        	return typeDescParent + "::" + typeDesc + " " + fieldName;
		}
        
        
    	public String toString() {
    		ArrayListChar r = new ArrayListChar(50);
    		String message = "";
    		if (this.isMemberOrLocal) {
				if (this.accessModifier!=null) {
					message = accessModifier.toString();
				}
    		}
			r.add(message);
			r.add(typeName);
			r.add(" ");
			if (this.fieldName!=null) {
				r.add(this.fieldName);
			}
			else {
				r.add("null");
			}
			    		
    		//r = message + this.typeName + " " + this.fieldName;
    		return new String(r.getItems());
    	}
        
        
        public boolean equals(FindVarParams var) {
        	
        	if (var.isThis || var.isSuper) return false;
        	if (this.isThis || this.isSuper) return false;
        	
        	if (!this.fieldName.equals(var.fieldName)) return false;
        	
        	if (this.typeName==null) {
        	}
        	if (!this.typeName.equals(var.typeName)) return false;
        	return true;
        }

		@Override
		public void destroy() {
			
			if (this.accessModifier!=null) {
				this.accessModifier.destroy();
				this.accessModifier = null;
			}
			if (this.docuComment!=null) {
				this.docuComment.destroy();
				this.docuComment = null;
			}
			this.fieldName = null;
			
			if (this.listOfVarUses!=null) {
				this.listOfVarUses.destroy();
				this.listOfVarUses = null;
			}
			this.parent = null;
			if (this.template!=null) {
				this.template.destroy();
				this.template = null;
			}
			if (this.templateOfClass!=null) {
				this.templateOfClass.destroy();
				this.templateOfClass = null;
			}
			//this.typeClassParams = null;
			
			if (this.field_Info!=null) {
				this.field_Info.destroy();
				this.field_Info = null;
			}
		}
	}
	
	
	
	
	
	
	
	/** 변수의 사용, 
	 * FindVarParams varDecl(varUse의 해당 변수선언), FindFunctionParams funcDecl(varUse의 해당 함수선언), 
	 * Object memberDecl(varUse의 해당 패키지등),
	 * ArrayListIReset listOfArrayElementParams(buffer[i][j]에서 varUse는 buffer이고 파라미터들은 i,j를 말한다), 
	 * ArrayListIReset listOfFuncCallParams(func(a,b,c)에서 varUse는 func이고 파라미터들은 a,b,c를 말한다),
	 * FindVarUseParams parent(멤버한정연산자(.)에 따른 parent.varUse에 parent);
	 * FindVarUseParams child(멤버한정연산자(.)에 따른 varUse.child에 child),
	 * TypeCast typeCast((int)a에서 int, 현재 varUse가 타입캐스트문일 경우 null이 아님) 등
	 * 중요한 멤버들이 있으므로 주의한다.*/
	public static class FindVarUseParams  implements IReset {
		//static int count;
		//int number;
		/** buffer[i]와 같은 경우 "buffer[i]", buffer(i)와 같은 경우는 "buffer", "i"*/
		public String name;
		/**name과 다르게 원래 이름*/
		public String originName;
		public IndexForHighArray index = null;
		public boolean isLocal;
		/** shared var after processLocalVars()*/
		public FindVarParams varDecl=null;
		/** varDecl이 중복변수가 공유 변수를 가리키는 경우 null이 아니며 공유하기 전 원래 변수를 말한다.
		 * 공유변수의 백업이다.
		 * varDeclBeforeProcessLocalVars이 null이면 varDecl은 중복변수가 아니다. <br>
		 * {int a;}<br>
		 * {int b=3;} <br>
		 * b가 a를 공유하면 varUse b의 varDecl은 a가 되고 
		 * varUse b의 varDeclBeforeProcessLocalVars 는 b가 된다. 
		 */
		public FindVarParams varDeclBeforeProcessLocalVars;
		public FindFunctionParams funcDecl=null;
		
		/** this.varUse 혹은 super.varUse 이런 경우는 true, 아니면 false*/
		public boolean isUsingThisOrSuper;
		
		/** buffer[i]와 같은 경우 true, 아니면 false*/
		public boolean isArrayElement;
		/**FindFuncCallParam[], 처음엔 null, isArrayElement이 true일 경우에만 new*/
		public ArrayListIReset listOfArrayElementParams;
		
		
		/** FindPackageParams 또는 FindClassParams, FindVarParams, FindFunctionParams*/  
		public Object memberDecl;
		
		public boolean isForVarOrForFunc;
		
		/** FindFuncCallParam[], 함수호출파라미터, funcDecl은 null이 아니다.*/
		public ArrayListIReset listOfFuncCallParams;
		
		//boolean isThis;
		///** 개체 자신을 가리키는 포인터*/
		//FindClassParams _this;
		
		/** 멤버한정연산자(.)에 따른 parent.varUse에 parent*/
		public FindVarUseParams parent;
		/** 멤버한정연산자(.)에 따른 varUse.child에 child*/
		public FindVarUseParams child;
		
		boolean isEnumElement;
		
		/** (int)a에서 int, 현재 varUse가 타입캐스트문일 경우 null이 아님*/
		public TypeCast_Syntax typeCast;
		
		/** stack = new Stack<Block>(); 에서 Stack의 varUse는  template이 null이 아니게 된다.*/
		Template template;
		
		/** 이전 타입캐스트문에 의해 타입캐스트될 경우 fullname으로 갖는다.
		 * (타입)varUse 와 같은 비수식 타입캐스트문(affectsExpression==false)에서 타입캐스트 이후의 타입을 정한다.
		 * varUse의 현재 타입은 varUse.getCurType()로 정해진다.
		 * CompilerStack.findTypeCast()를 참조한다.<br>
		 * 수식 타입캐스트는 affectsExpression이 true이고 funcCall은 null이 아니다.
		 * 비수식 타입캐스트는 affectsExpression이 false이고 funcCall은 null이다.*/
		public FindVarUseParams typeCastedByVarUse;
		/** 이전 타입캐스트문에 의해 타입캐스트될 경우 캐스트 이후의 fullname을 갖는다.
		 * (타입)varUse 와 같은 비수식 타입캐스트문(affectsExpression==false)에서 타입캐스트 이후의 타입을 정한다.
		 * varUse의 현재 타입은 varUse.getCurType()로 정해진다.
		 * CompilerStack.findTypeCast()를 참조한다.<br>
		 * 수식 타입캐스트는 affectsExpression이 true이고 funcCall은 null이 아니다.
		 * 비수식 타입캐스트는 affectsExpression이 false이고 funcCall은 null이다.*/
		public String fullnameTypeCast;
		
		/**varUse가 lValue이면 null이 아니다.*/
		public FindFuncCallParam rValue;
		
		/**varUse가 배열초기화문이면 null이 아니다.*/
		public FindArrayInitializerParams arrayInitializer;
		
		/** static함수에서 nonStatic변수를 참조하는가를 쉽게 알기 위해 사용한다.*/
		public FindFunctionParams funcToDefineThisVarUse;
		
		/** static클래스나 static이 아닌 클래스에서 부모클래스의 변수를 어떻게 참조하는가를 쉽게 알기 위해 사용한다.*/
		public FindClassParams classToDefineThisVarUse;
		
		
		
		/** ++i, i++, --i, i--*/
		public FindIncrementStatementParams inc;
		
		/** 현재 varUse가 문자열, 숫자 상수일때 postfix상에서의 token을 갖는다.
		 * ByteCoeGenerator에서 문자열 연결연산자 '+'를 출력할 때(printConstant()) 사용한다.*/
		public CodeStringEx tokenInPostfix;
		
		/** ByteCodeGenerator에서 가상으로 만들어진 것이면 true*/
		public boolean isFake;
		
		/** ByteCodeGenerator에서 
		 * 현재 varUse가 isArrayElement가 true일 경우 traverseArrayElement()에서 xaload를 출력할지 여부를 결정한다.*/
		public boolean prints_xaload = true;
		
		public String toString() {
			return this.name;
		}
		
		public FindVarUseParams(IndexForHighArray index) {
			this.index = index;
		}
		
		public Object clone() {
			FindVarUseParams r = new FindVarUseParams(null);
			r.arrayInitializer = this.arrayInitializer;
			r.child = this.child;
			r.classToDefineThisVarUse = this.classToDefineThisVarUse;
			r.funcDecl = this.funcDecl;
			r.funcToDefineThisVarUse = this.funcToDefineThisVarUse;
			r.index = this.index;
			r.isArrayElement = this.isArrayElement;
			r.isEnumElement = this.isEnumElement;
			r.isForVarOrForFunc = this.isForVarOrForFunc;
			r.isLocal = this.isLocal;
			r.isUsingThisOrSuper = this.isUsingThisOrSuper;
			r.listOfArrayElementParams = this.listOfArrayElementParams;
			r.listOfFuncCallParams = this.listOfFuncCallParams;
			r.memberDecl = this.memberDecl;
			r.name = this.name;
			r.originName = this.originName;
			r.parent = this.parent;
			r.rValue = this.rValue;
			r.template = this.template;
			r.typeCast = this.typeCast;
			r.varDecl = this.varDecl;
			r.inc = this.inc;
			
			return r;
		}
		
		public void destroy() {
			if (this.listOfArrayElementParams!=null) {
				this.listOfArrayElementParams.destroy();
				this.listOfArrayElementParams = null;
			}
			if (this.listOfFuncCallParams!=null) {
				this.listOfFuncCallParams.destroy();
				this.listOfFuncCallParams = null;
			}
			if (this.arrayInitializer!=null) {
				this.arrayInitializer.destroy();
				this.arrayInitializer = null;
			}
			if (this.child!=null) {
				this.child.destroy();
				this.child = null;
			}
			if (this.rValue!=null) {
				this.rValue.destroy();
				this.rValue = null;
			}
			if (this.template!=null) {
				this.template.destroy();
				this.template = null;
			}
			if (this.typeCast!=null) {
				this.typeCast.destroy();
				this.typeCast = null;
			}
			this.classToDefineThisVarUse = null;
			//this.typeCastedByVarUse = null;
			this.funcDecl = null;
			this.varDecl = null;
			this.funcToDefineThisVarUse = null;
			this.memberDecl = null;
			this.name = null;
			this.originName = null;
			this.parent = null;			
					
			if (this.inc!=null) {
				this.inc.destroy();
			}
		}
		
		/** varUse가 공유변수인 경우 varDeclBeforeProcessLocalVars을 리턴하고,
		 * 그렇지 않으면 varDecl을 리턴하여 원래 변수를 리턴한다.
		 * @return
		 */
		public FindVarParams getOriginalVar() {
			if (this.varDeclBeforeProcessLocalVars!=null)
				return this.varDeclBeforeProcessLocalVars;
			else 
				return this.varDecl;
		}
		
		
		/**(타입)varUse 와 같은 비수식 타입캐스트문(affectsExpression==false)에서 현재 varUse의 타입을 정한다.
		 * 타입캐스트 이후에 정해지는 타입은 varUse.fullnameTypeCast로 정해진다.
		 * CompilerStack.findTypeCast()를 참조한다.
		 * 수식 타입캐스트는 affectsExpression이 true이고 funcCall은 null이 아니다.
	 * 비수식 타입캐스트는 affectsExpression이 false이고 funcCall은 null이다.*/
		public String getCurType() {
			if (this.varDecl!=null) {
				return this.varDecl.typeName;
			}
			if (this.memberDecl!=null) {
				if (memberDecl instanceof FindClassParams) {
					FindClassParams c = (FindClassParams) this.memberDecl;
					return c.name;
				}
			}
			if (this.funcDecl!=null) {
				return this.funcDecl.returnType;
			}
			int numberType = Number.IsNumber2(this.originName); 
			boolean isInteger = 
					Number.convertNumberConstantToIntegerInFunctionParameter(this.originName, numberType);
			if (isInteger) return "int";
			else {
				if (numberType!=0) {
					return Number.getNumberString(numberType);
				}
			}
			if (this.originName.charAt(0)=='"')
				return "java.lang.String";
			if (this.originName.charAt(0)=='\'')
				return "char";
			
			return null;
		}
		
		/** String fullnameTypeCast가 FindVarUseParams typeCastedByVarUse으로 바뀌면서
		 * 예전의 fullnameTypeCast을 대체하기 위한 메서드이다.
		 * @param typeCastedByVarUse
		 * @return
		 */
		/*public static String getFullnameTypeCast(FindVarUseParams typeCastedByVarUse) {
			if (typeCastedByVarUse==null) return null;
			if (typeCastedByVarUse.memberDecl!=null) {
				// ByteCodeGenerator에서 사용
				//return typeCastedByVarUse.constant_info.toString();
				if (typeCastedByVarUse.memberDecl instanceof FindClassParams) {
					String typeDesc = TypeDescriptor.getDescriptor((FindClassParams)typeCastedByVarUse.memberDecl);
					return typeDesc;
				}
				else if (CompilerHelper.IsDefaultType(typeCastedByVarUse.name)) {
					String typeDesc = TypeDescriptor.getDescriptor(typeCastedByVarUse.name);
					return typeDesc;
				}
			}
			if (typeCastedByVarUse.typeCast!=null)
				return typeCastedByVarUse.typeCast.name;
			return null;
			
		}*/
		
		
		/** T data; T getData(); varUse가 data와 getData()를 참조하는 경우 
		 * isTypeNameToChange는 true이고 템플릿이므로 true를 리턴한다.
		 * @param varUse
		 * @return
		 */
		public static boolean isDeclTemplate(FindVarUseParams varUse) {
			if (varUse.varDecl!=null) {
				if (varUse.varDecl.isTypeNameToChange) return true;
			}
			if (varUse.funcDecl!=null) {
				if (varUse.funcDecl.isTypeNameToChange) return true;
			}
			return false;
		}

		/** 상대인덱스(arrayNumber,offset)에서 절대 index를 리턴한다.*/
		public int index() {
			
			if (index==null) return -1;
			return this.index.index();
		}
		
		
	}
	
	
	
	/** 함수호출의 파라미터 하나 혹은 배열첨자 하나, 할당문의 rValue, 타입캐스트, 즉 (타입)수식  
	 * 안에 있는 수식을 표현한다.*/
	public static class FindFuncCallParam implements IReset {
		/** 함수호출이름 또는 배열이름*/
		String funcName;
		/** '('는 불포함 */
		public IndexForHighArray startIndex;
		/** ',', ')'는 불포함이지만 주석 또는 공백은 포함될수있다. 구분자의 인덱스-1*/
		public IndexForHighArray endIndex;
		
		/** 함수호출 파라미터, 배열첨자, 타입캐스트의 수식 등의 
		 * getTypeOfExpression에서 처리된 수식의 fullname 타입을 갖는다.*/
		public CodeStringEx typeFullName;
		
			
		/** type이 오브젝트일 경우 FindClassParams*/
		FindClassParams classParams;
		
			
		/** 수식*/
		public FindExpressionParams expression;
		
			
		/** FindFuncCallParam이 들어있는 해당 문서 파일*/
		public Compiler compiler;
		
		/** 수식 타입캐스트에서 타입캐스트하기전 수식의 타입 이름, 
		 * 반면 FindFuncCallParam.typeFullName은 타입캐스트된후의 타입이름이다.*/
		public String typeFullNameBeforeTypeCast;
		
		/**함수호출이 함수에 매핑이 된 이후에 타입캐스트되는 타입이름, 
		 * 함수선언의 파라미터의 타입이름이 된다.*/
		public String typeFullNameAfterFuncCall;
		
		public Object clone() {
			FindFuncCallParam r = new FindFuncCallParam(compiler, -1, -1);
			r.classParams = this.classParams;
			r.compiler = this.compiler;
			r.endIndex = this.endIndex;
			r.expression = this.expression;
			r.funcName = this.funcName;
			r.startIndex = this.startIndex;
			r.typeFullName = this.typeFullName;
			r.typeFullNameBeforeTypeCast = this.typeFullNameBeforeTypeCast;
			return r;
		}
		
		public String toString() {
			int i;
			String r = "";
			HighArray_CodeString mBuffer = compiler.data.mBuffer;
			for (i=startIndex(); i<=endIndex(); i++) {
				CodeString str = mBuffer.getItem(i);
				if (CompilerHelper.IsComment(str)) continue;
				else if (CompilerHelper.IsAnnotation(str)) continue;
				else r += str.str;
			}
			return r;
		}
				
		public FindFuncCallParam(Compiler compiler, int startIndex, int endIndex) {
			this.startIndex = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, startIndex);
			this.endIndex = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, endIndex);
			this.compiler = compiler;
		}
		FindFuncCallParam(Compiler compiler, FindExpressionParams expression) {
			this.startIndex = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, expression.startIndex());
			this.endIndex = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, expression.endIndex());
			this.expression = expression;
			this.compiler = compiler;
		}
		public void destroy() {
			
			if (this.classParams!=null) {
				this.classParams.destroy();
				this.classParams = null;
			}
			if (this.expression!=null) {
				this.expression.destroy();
				this.expression = null;
			}
			if (this.typeFullName!=null) {
				this.typeFullName.reset();
				this.typeFullName = null;
			}
			this.funcName = null;
		}

		public int startIndex() {
			
			if (startIndex==null) return -1;
			return startIndex.index();
		}

		public int endIndex() {
			
			if (endIndex==null) return -1;
			return endIndex.index();
		}
	}
	
	/** {, }으로 이루어지는 블록을 말한다.*/
	public static class FindBlockParams implements IReset {
		IndexForHighArray startIndex;
		IndexForHighArray endIndex;
		Compiler compiler;
		String blockName;
		CategoryOfBlock categoryOfBlock;
		Block parent;
		
		FindBlockParams(Compiler compiler, int startIndex, int endIndex) {
			this.startIndex = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, startIndex);
			this.endIndex = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, endIndex);
			this.compiler = compiler;
		}

		@Override
		public void destroy() {
			
			this.blockName = null;
			if (this.startIndex!=null) {
				this.startIndex.destroy();
				this.startIndex = null;
			}
			if (this.endIndex!=null) {
				this.endIndex.destroy();
				this.endIndex = null;
			}
			/*if (this.compiler!=null) {
				this.compiler.destroy();
				this.compiler = null;
			}*/
			if (this.categoryOfBlock!=null) {
				this.categoryOfBlock.destroy();
				this.categoryOfBlock = null;
			}
		}

		public int startIndex() {
			
			if (startIndex==null) return -1;
			return startIndex.index();
		}
		
		public int endIndex() {
			
			if (endIndex==null) return -1;
			return endIndex.index();
		}
	}
	
		
	public static class CategoryOfBlock implements IReset {
		CategoryOfControls categoryOfControl;
		/** 0이면 제어블록, 1이면 class, 2이면 funciton, 
		 * 0일때는 categoryOfControl을 확인한다.*/
		int typeOfBlock;
		
		static int ControlBlock = 0;
		static int Class = 1;
		static int Function = 2;
		static int Enum = 3;
		static int Try = 4;
		static int Catch = 5;
		static int Finally = 6;
		static int Synchronized = 7;
		static int Interface = 8;
		
		
		public CategoryOfBlock(int typeOfBlock, CategoryOfControls categoryOfControl) {
			this.typeOfBlock = typeOfBlock;
			if (typeOfBlock==0) {
				this.categoryOfControl = categoryOfControl;
			}
		}
		
		public void destroy() {
			
			if (this.categoryOfControl!=null) {
				this.categoryOfControl.destroy();
				this.categoryOfControl = null;
			}
		}

		public String toString() {
			if (typeOfBlock==0) {
				if (categoryOfControl!=null) {
					return categoryOfControl.toString();
				}
			}
			else if (typeOfBlock==1) {
				return "class";
			}
			else if (typeOfBlock==2) {
				return "function";
			}
			else if (typeOfBlock==3) {
				return "enum";
			}
			else if (typeOfBlock==4) {
				return "try";
			}
			else if (typeOfBlock==5) {
				return "catch";
			}
			else if (typeOfBlock==6) {
				return "finally";
			}
			else if (typeOfBlock==7) {
				return "synchronized";
			}
			else if (typeOfBlock==8) {
				return "interface";
			}
			return null;
		}
	}
	
	public static class CategoryOfControls implements IReset {
		public int category;
		
		public static int Control_if = 1;
		public static int Control_elseif = 2;
		public static int Control_else = 3;
		public static int Control_switch = 4;
		
		public static int Control_for = 5;
		public static int Control_while = 6;
		public static int Control_dowhile = 7;
		
		public static int Control_case = 8;
		
		public CategoryOfControls(int category) {
			this.category = category;
		}
		
		public void destroy() {
			
			
		}

		public String toString() {
			if (category==0) return null;
			if (category==CategoryOfControls.Control_if) return "if";
			else if (category==CategoryOfControls.Control_elseif) return "else if";
			else if (category==CategoryOfControls.Control_else) return "else";
			else if (category==CategoryOfControls.Control_switch) return "switch";
			else if (category==CategoryOfControls.Control_while) return "while";
			else if (category==CategoryOfControls.Control_for) return "for";
			else if (category==CategoryOfControls.Control_dowhile) return "do while";
			else if (category==CategoryOfControls.Control_case) return "case";
			return null;
		}
	}
	
	/** 제어 블럭(if, else, while등)*/
	public static class FindControlBlockParams /*extends FindStatementParams*/  extends Block implements IReset {
		public CategoryOfControls catOfControls;
		
		/**nameIndex==null이면 synchronized안이나 메서드 안에 있는 
		 * 가짜 try-catch블록의 nameIndex이다.
		 * 가짜 try-catch블록이란 try-catch가 없는 메서드내에서 예외를 호출함수로 던져주거나 
		 * try-catch가 없는 synchronized블록에서 예외가 발생할 경우 모니터를 해제하기 위한 것이다.
		 * 현재는 try-catch가 있더라도 가짜 try-catch블록을 만든다.
		 * (그래도 문제가 안되기 때문에)
		 * Compiler.putTryCatchShieldToSynchronized()를 참조한다.*/
		public IndexForHighArray nameIndex=null;
		/** case문의 경우 case 다음 인덱스*/
		IndexForHighArray indexOfLeftParenthesis=null;
        /** case문의 경우 case 다음 ':'의 인덱스*/
		IndexForHighArray indexOfRightParenthesis=null;
		
		/**for루프의 run of for의 바이트코드 offset, HighArrayCharForByteCode.createConstantTableIndex()에서 설정한다.*/
		//public int startPC;
		/**for루프가 chop프레임을 포함할 경우 for루프의 바이트코드 conditionStartPC는 0이 아닌 값을 갖는다.
		 * condition of for의 바이트코드 offset, 
		 * HighArrayCharForByteCode.createConstantTableIndex()에서 설정한다.*/
		//public int conditionStartPC;
		
		/**nameIndex==null이면 synchronized안이나 메서드 안에 있는 
		 * 가짜 try-catch블록의 nameIndex이다.
		 * 가짜 try-catch블록이란 try-catch가 없는 메서드내에서 예외를 호출함수로 던져주거나 
		 * try-catch가 없는 synchronized블록에서 예외가 발생할 경우 모니터를 해제하기 위한 것이다.
		 * 현재는 try-catch가 있더라도 가짜 try-catch블록을 만든다.
		 * (그래도 문제가 안되기 때문에)
		 * Compiler.putTryCatchShieldToSynchronized()를 참조한다.*/
		public int nameIndex() {
			if (nameIndex==null) return -1;
			return nameIndex.index();
		}
		
		public int indexOfLeftParenthesis() {
			if (indexOfLeftParenthesis==null) return -1;
			return indexOfLeftParenthesis.index();
		}
		
		public int indexOfRightParenthesis() {
			if (indexOfRightParenthesis==null) return -1;
			return indexOfRightParenthesis.index();
		}
		
		/**compiler.data.mBuffer.getItem(this.nameIndex())<br>
		 * else if : else if<br>
		 * do while : do_while<br>
		 * try, catch, finally, synchronized의 경우에는 FindSpecialBlockParams.getName()을 호출한다.*/
		public String getName() {
			if (!this.isFake) {
				
				String r=null;
				if (this.catOfControls!=null) {
					if (this.catOfControls.category==CategoryOfControls.Control_elseif) {
						r = "else if";
					}
					else {
						try {
						r = compiler.data.mBuffer.getItem(nameIndex()).str;
						}catch(Exception e) {
							if (Common_Settings.g_printsLog) e.printStackTrace();
						}
						if (r.equals("do")) {
							r = "do_while";
						}
					}
				}
				else {
					r = compiler.data.mBuffer.getItem(nameIndex()).str;
				}
				return r;
			}
			return null;
		}
		
		/**localVar가 제어블록의 ()안에서 정의되었으면 true를 리턴한다.*/
		public boolean isVarDefinedInParenthesis(FindVarParams localVar) {
			if (!localVar.isFake) {
				if (this.indexOfLeftParenthesis()<=localVar.varNameIndex() && 
						localVar.varNameIndex()<=this.indexOfRightParenthesis()) {
					return true;
				}
			}
			else {
				int i;
				for (i=0; i<this.listOfStatementsInParenthesis.count; i++) {
					if (localVar==this.listOfStatementsInParenthesis.getItem(i)) {
						return true;
					}
				}
			}
			
			return false;
		}
		
		/** while(true) if (i==3) continue;에서 while은 중괄호없이 nesting한다.
		 * 여기에서 while과 if의 endIndex는 동일해지므로 새로운 endIndex를 나타내는 
		 * endIndexWhenNestingControlBlockWithoutMiddlePair을 갖는다.*/
		public int endIndexWhenNestingControlBlockWithoutMiddlePair = -1;
        
        public boolean isBlock;
        
        /** case문일때 break문이 존재하는지 유무*/
        boolean breakExistsWhenCase;
		
		
				
		/** 조건문의 수식과 그것의 postfix*/
		public FindFuncCallParam funcCall;
		
	
		
		/** 이 블록이 들어있는 parent 블록의 listOfControlBlocks에서의 인덱스*,
		 * Compiler.FindAllClassesAndItsMembers2_sub()에서 정해진다./ 
		 */
		public int indexInListOfControlBlocksOfParent;
		
		
		public ArrayListIReset listOfStatementsInParenthesis = new ArrayListIReset(3);
		
		/**try, catch의 마지막이 goto로 끝난다면 true*/
		public boolean tryCatchFinallyHasGoTo;
		
		/**continue문에 의해 increment될 경우 null이 아님*/
		public FindSpecialStatementParams specialStatement;
		
		
		/** 제어블록의 괄호안에 있는 문장 리스트*/
		//ArrayListIReset listOfStatementsInParenthesis;
		
		public String toString() {
			int i;			
			HighArray_CodeString mBuffer = compiler.data.mBuffer;
			String r;
			if (this.catOfControls!=null) {
				if (this.catOfControls.category==CategoryOfControls.Control_elseif) {
					r = "else if";
				}
				else {
					r = mBuffer.getItem(nameIndex()).str;
					if (r.equals("do")) {
						r = "do_while";
					}
				}
			}
			else {
				r = mBuffer.getItem(nameIndex()).str;
			}
			if (indexOfLeftParenthesis()!=-1) {
				r += " ";
			}
			
			int start = indexOfLeftParenthesis();
			int end = indexOfRightParenthesis();
			for (i=start; i<=end; i++) {
				CodeString str = mBuffer.getItem(i);
				if (CompilerHelper.IsComment(str)) continue;
				else if (CompilerHelper.IsAnnotation(str)) continue;
				else r += str.str;
			}
			return r;
		}
		
    	
    	FindControlBlockParams(Compiler compiler, CategoryOfControls catOfControls, int startIndex, int endIndex) {
    		/*try {
    		super(compiler, startIndex, endIndex);
    		}catch(Exception e) {
    			
    		}*/
    		this.compiler = compiler;
			this.startIndex = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, startIndex);
			this.endIndex = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, endIndex);
			
			this.catOfControls = catOfControls;
			this.compiler = compiler;
			//this.findBlockParams = new FindBlockParams(-1, -1);
		}
    	
    	public void destroy() {
    		super.destroy();
    		if (this.catOfControls!=null) {
    			this.catOfControls.destroy();
    			this.catOfControls = null;
    		}
    		if (funcCall!=null) {
    			funcCall.destroy();
    			funcCall = null;
    		}
    	}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	/** 할당문, lValue(FindVarUseParams)로 시작하여 할당문을 찾는다.*/
	public static class FindAssignStatementParams extends FindStatementParams  implements IReset 
	{
		/*int startIndex;
		int endIndex;
		boolean found;*/	
		
		/** a = 1 + (a2 = 2);에서 a할당문은 true, a2는 false이다. f (a=3, b);에서 a는 false이다.*/
		boolean isIndependent = true;
		
		
		/** found가 true이고 lValue가 null이면 임시로컬변수에 rValue가 저장되는 것이고(a+1>b+2, 함수호출문에서처럼), 
		 * null이 아니면 lValue가 소스상에서 명시적으로 있는 것이다(a=b처럼).  
		 */
		public FindVarUseParams lValue;
		
		public FindFuncCallParam rValue;
		
		/** 대입연산자를 포함한 수식을 말한다. 
		 * 예를들어 a+=b는 a b +=이 된다. 여기에서 funcCallParam은 a+=b이다.*/
		FindFuncCallParam funcCallParam;
		
		/** 함수호출 파라미터, 배열첨자, 타입캐스트의 수식 등의 
		 * getTypeOfExpression에서 처리된 수식의 fullname 타입을 갖는다.*/
		//String typeFullNameOfRValue;

		/** =, +=, -=, *=, /=등에서 =의 인덱스*/
		public IndexForHighArray indexOfEqual;

		/** =, +=, -=, *=, /=등, CompilerHelper.IsAssignStatement()를 참조한다.*/
		public String operator;
		
		/**할당문의 변수사용 리스트(FindVarUseParams[]), 참고로 수식을 찾을때 활용한다.*/
		//ArrayListIReset listOfVarUses = new ArrayListIReset(1);
		
		/** 할당문이 배열초기화문이면 null이 아니다.*/
		public FindArrayInitializerParams arrayInitializer;
		
		public int indexOfEqual() {
			if (indexOfEqual==null) return -1;
			return indexOfEqual.index();
		}
		
		public String toString() {
			String r = "";
			if (lValue!=null && operator!=null && rValue!=null)
				r += lValue + operator + rValue + "\n";
			if (funcCallParam!=null) r += funcCallParam + "\n";
			//if (arrayInitializer!=null) r += arrayInitializer;
			return r;
		}
		
		
		public FindAssignStatementParams(Compiler compiler, int startIndex, int endIndex) {
			//super(compiler, startIndex, endIndex);
			this.compiler = compiler;
			this.startIndex = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, startIndex);
			this.endIndex = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, endIndex);
		}



		@Override
		public void destroy() {
			
			super.destroy();
			if (this.arrayInitializer!=null) {
				this.arrayInitializer.destroy();
				this.arrayInitializer = null;
			}
			if (this.funcCallParam!=null) {
				this.funcCallParam.destroy();
				this.funcCallParam = null;
			}
			if (this.startIndex!=null) {
				this.startIndex.destroy();
				this.startIndex = null;
			}
			if (this.endIndex!=null) {
				this.endIndex.destroy();
				this.endIndex = null;
			}
			if (this.indexOfEqual!=null) {
				this.indexOfEqual.destroy();
				this.indexOfEqual = null;
			}
			if (this.lValue!=null) {
				this.lValue.destroy();
				this.lValue = null;
			}
			if (this.rValue!=null) {
				this.rValue.destroy();
				this.rValue = null;
			}
			/*if (this.compiler!=null) {
				this.compiler.destroy();
				this.compiler = null;
			}*/
			/*if (this.parent!=null) {
				this.parent.destroy();
				this.parent = null;
			}*/
			//this.typeFullNameOfRValue = null;
		}
	}
	
	
	
	
	
	
	/** 독립적인 함수호출문, startIndex는 공백불포함, endIndex는 ;의 인덱스에서 -1*/
	public static class FindIndependentFuncCallParams extends FindStatementParams
	{
		/*int startIndex;
		int endIndex;
		boolean found;*/
		
		/**할당문의 변수사용 리스트(FindVarUseParams[]), 참고로 수식을 찾을때 활용한다.*/
		ArrayListIReset listOfVarUses = new ArrayListIReset(1);
		
		/** 독립적 함수호출문이 들어있는 해당 문서파일*/
		//Compiler compiler;
		
		public String toString() {
			int i;			
			HighArray_CodeString mBuffer = compiler.data.mBuffer;
			String r = "";
			int start = startIndex();
			int end = endIndex();
			for (i=start; i<=end; i++) {
				CodeString str = mBuffer.getItem(i);
				if (CompilerHelper.IsComment(str)) continue;
				else if (CompilerHelper.IsAnnotation(str)) continue;
				else r += str.str;
			}
			return r;
		}
		
		public FindIndependentFuncCallParams(Compiler compiler, int startIndex, int endIndex) {
			//super(compiler, startIndex, endIndex);
			this.compiler = compiler;
			this.startIndex = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, startIndex);
			this.endIndex = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, endIndex);
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	/** 수식, lValue(FindVarUseParams)로 시작하여 수식을 찾는다.
	 * CodeStringEx[] postfix(postfix로 변환된 수식) 멤버에서 postfix는 listOfVarUses을 가지므로
	 * 수식들이 중첩되더라도 수식의 계층구조를 표현할수있다. 
	 * 예를 들어 수식안에 함수호출이나 배열참조, 타입캐스트((타입)(수식)의 경우처럼) 등이 포함되어있는 경우
	 * 함수호출의 파라미터 리스트, 배열참조의 첨자리스트, 타입캐스트안에 있는 수식을 접근하기 위해 
	 * FindExpressionParams의 멤버인 postfix의 listOfVarUses(FindVarUseParams[])을 활용해서 
	 * 해당 varUse의 listOfArrayElementParams와 listOfFuncCallParams, typeCast에 접근한다.
	 * 또한 listOfArrayElementParams(배열참조)와 listOfFuncCallParams(함수호출)는 FindFuncCallParam[]이므로 
	 * FindFuncCallParam은 FindExpressionParams을 가지고 있고 typeCast 역시 FindExpressionParams을 멤버로
	 * 가지므로 수식의 계층구조에 접근할 수 있다.*/
	public static class FindExpressionParams implements IReset {
		/** 공백불포함*/
		public IndexForHighArray startIndex;
		/** 세미콜론, 콜론 인덱스 - 1*/
		public IndexForHighArray endIndex;
		boolean found;
		
		/**postfix로 변환된 수식*/
		public CodeStringEx[] postfix;
		
		/**수식에 있는 변수참조 리스트(FindVarUseParams[])*/
		//ArrayListIReset listOfVarUses;
		
		/**수식에 있는 변수참조 리스트(FindVarUseParams[])*/
		//ArrayListIReset listOfVarUsesInPostFix;
		
		//CodeString strLValue;
		//CodeString strRValue;
		
		//CodeString strOperater;
		
		/** found가 true이고 lValue가 null이면 임시로컬변수에 rValue가 저장되는 것이고(a+1>b+2, 함수호출문에서처럼), 
		 * null이 아니면 lValue가 소스상에서 명시적으로 있는 것이다(a=b처럼).  
		 */
		public //FindVarUseParams lValue;
		
		Compiler compiler;
		
		public Object clone() {
			FindExpressionParams r = new FindExpressionParams(compiler, -1, -1);
			r.compiler = this.compiler;
			r.endIndex = this.endIndex;
			r.found = this.found;
			r.postfix = this.postfix;
			r.startIndex = this.startIndex;
			return r;
		}
		
		public FindExpressionParams(Compiler compiler, int startIndex, int endIndex) {
			this.compiler = compiler;
			this.startIndex = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, startIndex);
			this.endIndex = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, endIndex);
		}
		
		public int startIndex() {
			if (startIndex==null) return -1;
			return startIndex.index();
		}
		
		public int endIndex() {
			if (endIndex==null) return -1;
			return endIndex.index();
		}
		
		public String toString() {
			int i;
			String r = "";
			if (compiler==null) return r;
			HighArray_CodeString mBuffer = compiler.data.mBuffer;
			for (i=startIndex(); i<=endIndex(); i++) {
				CodeString str = mBuffer.getItem(i);
				if (CompilerHelper.IsComment(str)) continue;
				else if (CompilerHelper.IsAnnotation(str)) continue;
				else r += str.str;
			}
			return r;
		}

		public void destroy() {
			
			if (this.postfix!=null) {
				int i;
				for (i=0; i<this.postfix.length; i++) {
					if (this.postfix[i]!=null) {
						this.postfix[i].reset();
						this.postfix[i] = null;
					}
				}
				this.postfix = null;
			}
		}		
	}
	
	
	
	public static enum Language {
	    	Java,
	    	CSharp,
	    	C,
	    	Html, Class
	}
	
	public static class TempLocalArrayInitializer {
		public FindVarUseParams varUseFuncCall;
		public FindVarParams funcArg;
		TempLocalArrayInitializer(FindVarUseParams varUseFuncCall, FindVarParams funcArg) {
			this.varUseFuncCall = varUseFuncCall;
			this.funcArg = funcArg;
			
		}
	}
	
	
}