package com.gsoft.common.compiler;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.interfaces.IReset;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListCodeString;
import com.gsoft.common.util.HighArray_CodeChar;

import com.gsoft.common.compiler.HighArray_CodeString;
import com.gsoft.common.compiler.IndexForHighArray;


/** 아주 큰 배열을 가변크기(처음 로딩시에는 고정크기 arrayLimit를 갖지만 
 * 수정을 하면 가변크기가 된다.)의 작은 배열 여러개로 나눈 array이다.*/
public class HighArray_CodeString implements IReset {
	int arrayLimit;
	
	/**ArrayListCodeString[]*/
	ArrayList data;
	
	/**data에 있는 array에 관련된 데이터들을 넣는다. 
	 * 즉 소스가 있는 data의 해당 array가 
	 * 바뀌면 변경 되어야 할 인덱스들을 갖는다. data의 count의 크기를 갖는다. 
	 * ArrayList[]*/
	ArrayList dataRelated;
	
	/** data 아이템, ArrayListCodeString[]의 개수를 누적시킨 int[]이다. 
	 * 소스의 수정이 있을때마다 자동으로 바뀐다.*/
	//ArrayListInt dataSumCount;
	
	public int count;

	public String name;
	
	int lengthOfItemOfDataRelated = 100;

	int resizeInc;
	
	/** 소스의 어떤 부분이 제거가 되면(deleteDataRelated()) 이 풀로 
	 * 관계된 IndexForHighArray들이 옮겨진다.*/
	//ArrayList listOfIndexForHighArray;
	
	
	/**CompilerStack과 Compiler사이의 데이터 공유(mBuffer)를 위한 메소드*/
	/*public void setData(HighArray_CodeString other) {
		this.data = other.data;
		this.dataRelated = other.dataRelated;
		//this.dataSumCount = other.dataSumCount;
		this.count = other.count;
		this.name = other.name;
		this.lengthOfItemOfDataRelated = other.lengthOfItemOfDataRelated;
		
	}*/
	
	
	
	/** @param arrayLimit : 작은 배열의 limit*/
	public HighArray_CodeString (int arrayLimit) {
		this.arrayLimit = arrayLimit;
		data = new ArrayList(10);
		dataRelated = new ArrayList(10);
		//dataSumCount = new ArrayListInt(10);
		resizeInc = arrayLimit;
		//listOfIndexForHighArray = new ArrayList(arrayLimit);
	}
	
	/*public int getLastArrayNumber() {
		return data.count-1;
	}
	
	public int getOffset() {
		ArrayListCodeString arr = (ArrayListCodeString) data.getItem(data.count-1);
		return arr.count-1;
	}
	
	public IndexForHighArray getLastIndexForHighArray() {
		IndexForHighArray index = null;
		int arrNum = data.count-1;
		ArrayListCodeString arr = (ArrayListCodeString) data.getItem(data.count-1);
		int offset = arr.count-1;
		index = new IndexForHighArray(this, this, arrNum, offset);
		return index;
	}*/
	
	/** 소스변경이 쉽도록 index를 dataRelated의 해당 array에 등록해준다.
	 * 소스변경이 있으면 소스가 있는 해당 array와 관련된 dataRelated의 해당 array에 등록된
	 * index들을 바꿔준다.*/
	public void addToDataRelated(IndexForHighArray index) {
		if (index==null) return;
		if (index.arrayNumber==-1) return;
		ArrayList arr = (ArrayList) dataRelated.getItem(index.arrayNumber);
		
		arr.add(index);
	}
	
	/** 상대인덱스(arrayNumber,offset)를 절대인덱스로 바꾼다.*/
	public int index(int arrayNumber, int offset) {
		int i;
		int index = 0;
		// 이전 array까지의 개수들의 합
		for (i=0; i<arrayNumber; i++) {
			ArrayListCodeString arr = (ArrayListCodeString) data.getItem(i);
			try {
			index += arr.count;
			}catch(Exception e) {
				e.printStackTrace();
				
			}
		}
		index += offset;
		return index;
	}
	
	public String toString() {
		int i, j;
		CodeString result = new CodeString("", Common_Settings.textColor);
		int dataLen = data.count;
		for (i=0; i<dataLen; i++) {
			ArrayListCodeString arr = (ArrayListCodeString) data.getItem(i);
			int arrLen = arr.count;
			for (j=0; j<arrLen; j++) {					
				CodeString str = arr.getItem(j);
				if (str!=null) {
					result = result.concate(str);
				}					
			}
		}
		return result.str;
	}
	
	public HighArray_CodeChar toHighArray_CodeChar() {
		HighArray_CodeChar text = new HighArray_CodeChar(100);
		int i, j;
		for (i=0; i<this.count; i++) {
			CodeString str = this.getItem(i);
			for (j=0; j<str.count; j++) {
				text.add(str.charAt(j));
			}
		}	
		return text;
	}
	
	/** 절대인덱스 index에 있는 스트링을 str로 바꾼다.*/
	public void setCodeString(int index, CodeString str) {
		IndexForHighArray indexRelative = indexRelative(null, index);
		ArrayListCodeString arr = (ArrayListCodeString) data.getItem(indexRelative.arrayNumber);
		arr.setCodeString(indexRelative.offset, str);
	}
	
	/** 절대인덱스를 상대인덱스(arrayNumber,offset)로 바꾼다.
	 * owner를 null로 하면 dataRelated에 등록되지 않고 조회만 할 수 있다.*/
	public IndexForHighArray indexRelative(Object owner, int index) {
		if (index<0) return null;
		int indexOfData = -1;
		int i;
		int len = 0;   // 현재 array까지의 개수들의 합
		int oldLen = 0;// 이전 array까지의 개수들의 합
		int dataLen = data.count;
		for (i=0; i<dataLen; i++) {
			ArrayListCodeString arr = (ArrayListCodeString) data.getItem(i);
			oldLen = len;
			len += arr.count;
			if (index<len) {
				indexOfData = i;
				break;
			}
		}
		if (index>=len) {
			return null; // ArrayIndexOUtOfBoundsException
		}
		
		int indexInArray = index - oldLen; // offset
		return new IndexForHighArray(owner, this, indexOfData, indexInArray);
	}
	
	
	/** 절대인덱스를 상대인덱스(arrayNumber,offset)로 바꾼다.*/
	public void indexRelative(Object owner, int index, IndexForHighArray result) {
		if (index<0) return;
		int indexOfData = -1;
		int i;
		int len = 0;    // 현재 array까지의 개수들의 합
		int oldLen = 0; // 이전 array까지의 개수들의 합
		int dataLen = data.count;
		for (i=0; i<dataLen; i++) {
			ArrayListCodeString arr = (ArrayListCodeString) data.getItem(i);
			oldLen = len;
			len += arr.count;
			if (index<len) {
				indexOfData = i;
				break;
			}
		}
		if (index>=len) {
			return; // ArrayIndexOUtOfBoundsException
		}
		
		int indexInArray = index - oldLen; // offset
		result.arrayNumber = indexOfData;
		result.offset = indexInArray;
		result.owner = owner;
	}
	
	public void reset() {
		int i;
		for (i=0; i<data.count; i++) {
			ArrayListCodeString list = (ArrayListCodeString) data.getItem(i);
			list.reset2();
		}
		for (i=0; i<dataRelated.count; i++) {
			ArrayList list = (ArrayList) dataRelated.getItem(i);			
			list.reset();
		}
		data.reset();
		this.count = 0;
		//this.listOfIndexForHighArray.reset();
	}
	
	/** 모든 자원을 해제한다.*/
	public void destroy() {
		int j;
		int dataLen = data.list.length;
		for (j=0; j<dataLen; j++) {
			ArrayListCodeString list = (ArrayListCodeString) data.getItem(j);
			//if (list!=null) list.reset();
			if (list!=null) list.destroy();
			list = null;
		}
		data.destroy();
		
		for (j=0; j<this.dataRelated.list.length; j++) {
			ArrayList list = (ArrayList) data.getItem(j);
			//if (list!=null) list.reset();
			if (list!=null) list.destroy();
			list = null;
		}
		this.dataRelated.destroy();
	}
	
	public int getCount() {
		// 마지막 item을 얻는다.
		ArrayListCodeString arrItem = (ArrayListCodeString) data.getItem(data.count-1);
		//int len = arrayLimit * (data.count-1) + arrItem.count;
		int i;
		int dataLen = data.count-1;
		int len = 0;
		for (i=0; i<dataLen; i++) {
			ArrayListCodeString arr = (ArrayListCodeString) data.getItem(i);
			len += arr.count;
		}
		len += arrItem.count;
		return len;
	}
			
	public CodeString getItem(int index) {
		//int indexOfData = index / arrayLimit;
		//int indexInArray = index % arrayLimit;
		
		try {
		IndexForHighArray indexForHighArray = this.indexRelative(null, index);
		
		if (indexForHighArray==null) {
			return null;
		}
		ArrayListCodeString arrItem = (ArrayListCodeString) data.getItem(indexForHighArray.arrayNumber);
		return arrItem.getItem(indexForHighArray.offset);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public void add(CodeString c) {
		if (data.count==0) {
			ArrayListCodeString newItem = new ArrayListCodeString(arrayLimit);
			newItem.resizeInc = this.resizeInc;
			data.add(newItem);
			ArrayList newItemOfDataRelated = new ArrayList(lengthOfItemOfDataRelated);
			newItemOfDataRelated.resizeInc = this.resizeInc;
			dataRelated.add(newItemOfDataRelated);
		}
		
		ArrayListCodeString item;
		
		// 마지막 item을 얻는다.
		ArrayListCodeString arrItem = (ArrayListCodeString) data.getItem(data.count-1);
		if (arrItem.count>=arrayLimit) { // 새로운 item을 생성해서 넣는다.
			ArrayListCodeString newItem = new ArrayListCodeString(arrayLimit);
			newItem.resizeInc = this.resizeInc;
			data.add(newItem);
			item = newItem;
			ArrayList newItemOfDataRelated = new ArrayList(lengthOfItemOfDataRelated);
			newItemOfDataRelated.resizeInc = this.resizeInc;
			dataRelated.add(newItemOfDataRelated);
		}
		else {
			item = arrItem;
		}
		
		item.add(c);
		count++;
	}
	
	/**소스를 [startIndex, endIndex)만큼 지우고 DataRelated에 등록된 IndexForHighArray들을 지운다. <br>
	 * startIndex는 포함, endIndex는 불포함<br>
	 * @param startIndex : HighArray_CodeChar에서의 인덱스
	 * @param endIndex : HighArray_CodeChar에서의 인덱스*/
	public void delete(int startIndex, int endIndex) {
		IndexForHighArray startIndexRelative = this.indexRelative(null, startIndex);
		IndexForHighArray endIndexRelative = this.indexRelative(null, endIndex);
		
		this.deleteDataRelated(startIndex, endIndex);
		
		if (startIndexRelative.arrayNumber==endIndexRelative.arrayNumber) {
			ArrayListCodeString arrItem = (ArrayListCodeString) data.getItem(startIndexRelative.arrayNumber);
			int len = endIndexRelative.offset-startIndexRelative.offset;
			try {
				arrItem.delete(startIndexRelative.offset, len);
				this.count -= len;
			} catch (Exception e) {
				
				e.printStackTrace();
			}
		}
		else {
			ArrayListCodeString arrItem = (ArrayListCodeString) data.getItem(startIndexRelative.arrayNumber);
			int len = arrItem.count-1-startIndexRelative.offset+1;
			try {
				arrItem.delete(startIndexRelative.offset, len);
			} catch (Exception e) {
				
				e.printStackTrace();
			}
			this.count -= len;
			
			int i;
			for (i=startIndexRelative.arrayNumber+1; i<endIndexRelative.arrayNumber; i++) {
				ArrayListCodeString arrItem2 = (ArrayListCodeString) data.getItem(i);
				this.count -= arrItem2.count;
				arrItem2.reset2();				
			}
			arrItem = (ArrayListCodeString) data.getItem(endIndexRelative.arrayNumber);
			len = endIndexRelative.offset;
			try {
				arrItem.delete(0, len);
			} catch (Exception e) {
				
				e.printStackTrace();
			}
			
			this.count -= len;
		}
	}
	
	/**소스의 startIndex에 text를 insert한다.*/
	public void insert(int startIndex, ArrayListCodeString text) {
		IndexForHighArray startIndexRelative = this.indexRelative(null, startIndex);
		ArrayListCodeString arrItem = (ArrayListCodeString) data.getItem(startIndexRelative.arrayNumber);
		arrItem.insert(startIndexRelative.offset, text);
		this.count += text.count;
	}
	
	
	public CodeString[] toArray() {
		if (data.count<=0) {
			return new CodeString[0];
		}
		
		int i, j;
		// 마지막 item을 얻는다.
		//ArrayListCodeString arrItem = (ArrayListCodeString) data.getItem(data.count-1);
		//int len = arrayLimit * (data.count-1) + arrItem.count;
		int len = this.getCount();
		
		CodeString[] r = new CodeString[len];
		int k=0;
		
		for (i=0; i<data.count; i++) {
			ArrayListCodeString item = (ArrayListCodeString) data.getItem(i);
			for (j=0; j<item.count; j++) {
				r[k] =  item.getItem(j);
				k++;
			}
		}			
		return r;
	}
	
	public ArrayListCodeString toArrayListCodeString() {
		if (data.count<=0) {
			return new ArrayListCodeString(0);
		}
		
		int i, j;
		// 마지막 item을 얻는다.
		//ArrayListCodeString arrItem = (ArrayListCodeString) data.getItem(data.count-1);
		//int len = arrayLimit * (data.count-1) + arrItem.count;
		int len = this.getCount();
		
		ArrayListCodeString r = new ArrayListCodeString(len);
	
		for (i=0; i<data.count; i++) {
			ArrayListCodeString item = (ArrayListCodeString) data.getItem(i);
			for (j=0; j<item.count; j++) {
				r.add(item.getItem(j));
			}
		}			
		return r;
	}

	public CodeString[] getItems() {
		
		return this.toArray();
	}

	public CodeString[] substring(int start, int len) {
		HighArray_CodeString r = new HighArray_CodeString(len);
		int i;
		for (i=start; i<start+len; i++) {
			r.add(this.getItem(i));
		}
		return r.getItems();
	}
	
	/** startIndex와 endIndex를 상대인덱스로 고쳐서 그 사이에 있는 인덱스들을 모두 지우고
	 * poolOfIndexForHighArray에 넣는다.
	 * @param startIndex : 절대 인덱스, 소스상 인덱스의 시작
	 * @param endIndex : 절대 인덱스, 소스상 인덱스의 끝
	 */
	/*void deleteDataRelated_undelete(int startIndex, int endIndex) {
		IndexForHighArray start = this.indexRelative(null, startIndex);
		IndexForHighArray end = this.indexRelative(null, endIndex);
		
		listOfIndexForHighArray.count = 0;
		
		if (start.arrayNumber==end.arrayNumber) {
			ArrayList arr = (ArrayList) this.dataRelated.getItem(start.arrayNumber);
			int i;
			for (i=0; i<=arr.count; i++) {
				IndexForHighArray index = (IndexForHighArray) arr.getItem(i);
				if (index!=null && (start.offset<=index.offset && index.offset<=end.offset)) { 
					//index.destroy();
					//index.reset();
					listOfIndexForHighArray.add(index);
					//arr.list[i] = null;
				}
			}			
			//arr.delete(startIndex, end.offset-start.offset+1);
		}
		else {
			
		}
	}*/
	
	/**startIndex 포함, endIndex 불포함*/
	void deleteDataRelated(int startIndex, int endIndex) {
		IndexForHighArray start = this.indexRelative(null, startIndex);
		IndexForHighArray end = this.indexRelative(null, endIndex-1);
		
		try {
		if (start.arrayNumber==end.arrayNumber) {
			ArrayList arr = (ArrayList) this.dataRelated.getItem(start.arrayNumber);
			ArrayList newArr = new ArrayList(arr.count);
			int i;
			for (i=0; i<arr.count; i++) {
				IndexForHighArray index = (IndexForHighArray) arr.getItem(i);
				if (!(start.offset<=index.offset && index.offset<=end.offset)) { 
					newArr.add(index);
				}
			}
			this.dataRelated.list[start.arrayNumber] = newArr;
		}
		else {
			
		}
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
		}
	}
	
	/**[startIndexInOldmBuffer, endIndexInOldmBuffer)에서 DataRelated에 등록된
	 * IndexForHighArray들을 incInmBuffer만큼 증감시킨다.<br>
	 * startIndexInOldmBuffer포함, endIndexInOldmBuffer 불포함*/
	void incrementDataRelated(int startIndexInOldmBuffer, int endIndexInOldmBuffer, int incInmBuffer) {
		IndexForHighArray start = this.indexRelative(null, startIndexInOldmBuffer);
		IndexForHighArray end = this.indexRelative(null, endIndexInOldmBuffer-1);
		
		
		if (start.arrayNumber==end.arrayNumber) {
			ArrayList arr = (ArrayList) this.dataRelated.getItem(start.arrayNumber);
			int i;
			for (i=0; i<arr.count; i++) {
				IndexForHighArray index = (IndexForHighArray) arr.getItem(i);
				
				if (end.offset<index.offset) { 
					index.offset += incInmBuffer;
				}
			}
			
		}
		else {
			
		}
	}


	
}//public static class HighArray_CodeString {