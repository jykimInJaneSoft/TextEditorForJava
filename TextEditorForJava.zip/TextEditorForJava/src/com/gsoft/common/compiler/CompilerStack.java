package com.gsoft.common.compiler;

import java.io.File;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.Code.CodeStringType;
import com.gsoft.common.CommonGUI;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.FileHelper;
import com.gsoft.common.interfaces.IReset;
import com.gsoft.common.compiler.Compiler_types.CategoryOfBlock;
import com.gsoft.common.compiler.Compiler_types.CategoryOfControls;
import com.gsoft.common.compiler.Compiler_types.FindAssignStatementParams;
import com.gsoft.common.compiler.Compiler_types.FindBlockParams;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.Compiler_types.FindControlBlockParams;
import com.gsoft.common.compiler.Compiler_types.FindExpressionParams;
import com.gsoft.common.compiler.Compiler_types.FindFuncCallParam;
import com.gsoft.common.compiler.Compiler_types.FindFunctionParams;
import com.gsoft.common.compiler.Compiler_types.FindIndependentFuncCallParams;
import com.gsoft.common.compiler.Compiler_types.FindVarParams;
import com.gsoft.common.compiler.Compiler_types.FindVarUseParams;
import com.gsoft.common.compiler.Compiler_types.Language;
import com.gsoft.common.compiler.Compiler_types.LoadWayOfFindClassParams;
import com.gsoft.common.compiler.Compiler_types.ModeAllOrUpdate;
import com.gsoft.common.compiler.Compiler_types_Base.AccessModifier;
import com.gsoft.common.compiler.Compiler_types_Base.AccessModifier.AccessPermission;
import com.gsoft.common.compiler.Compiler_types_Base.Annotation;
import com.gsoft.common.compiler.Compiler_types_Base.Block;
import com.gsoft.common.compiler.Compiler_types_Base.DocuComment;
import com.gsoft.common.compiler.Compiler_types_Base.Error;
import com.gsoft.common.compiler.Compiler_types_Base.FindStatementParams;
import com.gsoft.common.compiler.Compiler_types_Base.ImportStatement;
import com.gsoft.common.compiler.Compiler_types_Base.OldTypeIndex;
import com.gsoft.common.compiler.Compiler_types_Base.PackageStatement;
import com.gsoft.common.compiler.Compiler_types_Base.ReturnOfFindVarDecl;
import com.gsoft.common.compiler.Compiler_types_Base.ReturnOfIsArrayType;
import com.gsoft.common.compiler.Compiler_types_Base.ReturnOfIsType;
import com.gsoft.common.compiler.Compiler_types_Special.FindIncrementStatementParams;
import com.gsoft.common.compiler.Compiler_types_Special.FindSpecialBlockParams;
import com.gsoft.common.compiler.Compiler_types_Special.FindSpecialStatementParams;
import com.gsoft.common.compiler.TemplateBase.Template;
import com.gsoft.common.compiler.bytecode.ArrayInitializer;
import com.gsoft.common.compiler.classloader.Loader;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListChar;
import com.gsoft.common.util.ArrayListIReset;
import com.gsoft.common.util.ArrayListString;

import com.gsoft.common.compiler.CompilerData;
import com.gsoft.common.compiler.CompilerCore;
import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.IndexForHighArray;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.HighArray_CodeString;
import com.gsoft.common.compiler.CompilerStatic;
import com.gsoft.common.compiler.Compiler_types_Static;
import com.gsoft.common.compiler.Fullname;
import com.gsoft.common.compiler.Checker;
import com.gsoft.common.compiler.TemplateBase;
import com.gsoft.common.compiler.Array;

@SuppressWarnings("unused")
public class CompilerStack {
	
	public CompilerData data;
	Compiler compiler;
	public CompilerCore core;
	
	CompilerStack(Compiler compiler) {
		this.compiler = compiler;
		data = compiler.data;
		core = new CompilerCore(this);
	}
	
	
	/** 변수선언 외에 변수사용도 찾는다. 
	 * 변수선언의 경우 endIndex는 세미콜론의 인덱스이다.
	 * @param findVarParams : out 
	 * @param index : if (IsIdentifier(cstr) || CompilerHelper.IsConstant(cstr) ||
        		IsDefaultType(cstr))   { // 식별자, 상수, 타입(타입캐스트)의 인덱스
	 * @param oldTypeIndex : int a, b;의 경우처럼 타입선언 b를 찾을때 이전 호출에서 ,로 끝날경우 
	 * int 타입의 인덱스
	 * @param coreThreadID 
	 * @return OldTypeIndex : int a, b;의 경우처럼 타입선언 a를 찾은후 ,로 끝나는 경우 
	 * 다음 호출을 위해서 int 타입의 인덱스를 리턴한다.*/
	ReturnOfFindVarDecl FindVarDeclarationsAndVarUses(HighArray_CodeString src,
			int index, OldTypeIndex oldTypeIndex, int coreThreadID)
	{
		try{
		boolean isCommaPreviously = false;
		if (oldTypeIndex!=null) isCommaPreviously = true;

        
        if (10279<=index && index<=10300) {
        }
        
        if (index==1636) {
        	int a;
        	a=0;
        	a++;
        }
        
        CodeString cstr = src.getItem(index);
        
        if (cstr.equals("toCharArray")) {
        }
       
      
        IndexForHighArray varNameIndex = null;
        IndexForHighArray typeStartIndex = null;
        IndexForHighArray typeEndIndex = null;

        // 변수 이름 찾기
        // cstr이 상수일 경우는 varUse를 찾기 위해서이다.
        //if (IsIdentifier(cstr) || CompilerHelper.IsConstant(cstr) ||
        //		IsDefaultType(cstr))   { // 식별자, 상수, 타입(타입캐스트)이면
        	
        	
        	varNameIndex = IndexForHighArray.indexRelative(null, src, index);
        	int typeIndex = CompilerHelper.SkipBlank(src, true, 0, index - 1);
        	// 다음 줄의 주석을 제거하면 변수선언 = 변수사용 일 때 변수사용의 확인이 안 된다.
        	//if (type==startIndex-1) continue;
        	
        	if (varNameIndex.index()==3331) {
        	}
        	
        	Template template = null;
        	
        	CodeString strType = null;        	
        	if (typeIndex>=0) {
        		strType = src.getItem(typeIndex);
        	}
			if (data.language==Language.C && strType.equals("*")) {
				typeStartIndex = IndexForHighArray.indexRelative(null, src, 
						CompilerHelper.SkipBlank(src, true, 0, typeIndex - 1));
				if (typeStartIndex!=null) {
					if (CompilerHelper.IsIdentifier(src.getItem(typeStartIndex.index()), compiler)) {
						return null;	// 이항연산 id * id
					}
				}
				else {
				}
			}
			else { // 타입이거나 식별자이면 타입으로 인식한다.
				if (typeIndex==1364) {
				}
				
				//findVarParams.typeStartIndex = IsType(src, true, typeIndex);
				if (typeIndex>=0) {
					//template = new Template(compiler);
					//int typeIndex2 = IsType(src, true, typeIndex);
					ReturnOfIsType returnOfIsType = IsType(src, true, typeIndex);
					template = returnOfIsType.template;
					int typeIndex2 = returnOfIsType.index;
					typeStartIndex = IndexForHighArray.indexRelative(null, src, typeIndex2);
					if (template!=null && template.found) {
						//mlistOfAllTemplates.add(template);
						core.putTempate(template);
					}
				}
				
				if (typeStartIndex!=null && typeStartIndex.index()==555) {
				}
				
				if (typeStartIndex==null) {
					if (strType!=null && CompilerHelper.IsIdentifier(strType, compiler)) {
						typeStartIndex = IndexForHighArray.indexRelative(null, src, typeIndex);
					}
					else {
						//continue;
					}
				}
				else {
					// 함수파라미터에서 int a, int b 와 같은 경우 두번째 int는 원래대로 처리
					isCommaPreviously = false;
				}
			}
			
			
			// int a=0, b=1과 같이 varName이 0일 경우는 타입이 아니고 수식이므로 isCommaPreviously = false로 한다.
			if (oldTypeIndex!=null && 
					oldTypeIndex.startIndexOfExpression()<=varNameIndex.index() && 
					varNameIndex.index()<=oldTypeIndex.endIndexOfExpression())
				isCommaPreviously = false;
			
			// 함수파라미터에서 int a, RectForPage b 와 같은 경우 두번째 RectForPage는 리턴
			int nextIndex2 = CompilerHelper.SkipBlank(src, false, varNameIndex.index()+1, src.count-1);
			if (nextIndex2==src.count) return null;
			
			//Character.Subset a;에서 Subset일 경우 strType은 '.'이다. 이때는 리턴을 안하고 varUse로 등록한다.
			// RedoBuffer.Pair p;에서 RedoBuffer나 Pair일 경우 strType이나 next는 '.'이다. 이때는 리턴을 안하고 varUse로 등록한다.
			CodeString next = src.getItem(nextIndex2);
			if ((strType!=null && strType.equals(".")) || next.equals("."))  {
				isCommaPreviously = false;
			}
			else {			
				// Point[] p;에서 Point일 경우 varUse로 등록한다.
				if (next.equals("[")) {
					int rightPair = Checker.CheckParenthesis(compiler,  "[", "]", nextIndex2, src.count-1, false);
					if (rightPair==src.count) return null;
					nextIndex2 = CompilerHelper.SkipBlank(src, false, rightPair+1, src.count-1);
					next = src.getItem(nextIndex2);
				}
				
				// Point p;에서 Point일 경우 varUse로 등록한다.
				if (CompilerHelper.IsIdentifier(next, compiler)) {
					isCommaPreviously = false;
				}
			}
			
			
			//if (strType.equals(",")) isCommaPreviously = false;
			
			//Template template = null;
        	
        	if (typeStartIndex!=null && typeStartIndex.index() != -1 || isCommaPreviously) { // 타입이면
        		// 변수선언으로 인정한다.
        		int k = 0;
        		ReturnOfFindAccessModifier r=null;
        		FindVarParams var;
        		AccessModifier accessModifier;
        		if (isCommaPreviously) {
        			typeStartIndex = oldTypeIndex.startIndex;
        			typeEndIndex = oldTypeIndex.endIndex;
        			accessModifier = oldTypeIndex.accessModifier;
        			template = oldTypeIndex.template;
        			
        			var = new FindVarParams(compiler, -1, -1);
        			var.typeStartIndex = IndexForHighArray.indexRelative(var, src, typeStartIndex.index());
        			var.typeStartIndex.owner = var;
        			var.typeEndIndex = IndexForHighArray.indexRelative(var, src, typeEndIndex.index());
        			var.typeEndIndex.owner = var;
        			var.varNameIndex = IndexForHighArray.indexRelative(var, src, varNameIndex.index());
        			var.varNameIndex.owner = var;
        			var.accessModifier = accessModifier;
        			// HighArray<FindVarParams> list;에서 템플릿
        			var.template = template;
        		}
        		else {
	        		typeEndIndex = IndexForHighArray.indexRelative(null, src, typeIndex);
	        		r = FindAccessModifier(src, 0, typeStartIndex.index() - 1, 
	        				accessModifier = new AccessModifier(compiler, -1, -1));
	        		k = r.r;
	        		
	        		var = new FindVarParams(compiler, -1, -1);
	        		var.typeStartIndex = IndexForHighArray.indexRelative(var, src, typeStartIndex.index());
        			var.typeStartIndex.owner = var;
        			var.typeEndIndex = IndexForHighArray.indexRelative(var, src, typeEndIndex.index());
        			var.typeEndIndex.owner = var;
        			var.varNameIndex = IndexForHighArray.indexRelative(var, src, varNameIndex.index());
        			var.varNameIndex.owner = var;
        			var.accessModifier = accessModifier;
        			// HighArray<FindVarParams> list;에서 템플릿
        			var.template = template;
        		}
        		
        		index = CompilerHelper.SkipBlank(src, false, index+1, src.count-1);
        		if (index!=src.count) {
            		CodeString separator = src.getItem(index);
            		if (CompilerHelper.IsOperator(separator) && !separator.equals("=")) {
            			String typeName = Fullname.getFullNameType(compiler, var.typeStartIndex(), var.typeEndIndex(), coreThreadID);
            			String varName = data.mBuffer.getItem(var.varNameIndex()).str;
            			CompilerStatic.errors.add(new Error(compiler, index, index, "invalid operator("+separator+" in var declaration("+typeName+" "+varName+")"));
            		}
            		if (separator.equals(";") || separator.equals("=") || // 멤버 혹은 지역변수
            				separator.equals(",") || separator.equals(")")) { // 지역변수            			
            			if (cstr.equals("sized")) {
            			}
            			boolean hasAccess = hasAccessModifier(var, null);
            			if (!isCommaPreviously) {
		            		if (hasAccess) var.startIndex = IndexForHighArray.indexRelative(var, src, k);
		        			else var.startIndex = var.typeStartIndex;
		            		var.startIndex = IndexForHighArray.indexRelative(var, src, CompilerStatic.getIndexWhickRemoveLeftBlankAndCommentAndAnnotation(src, r));
            			}
            			else { // int i=0, j=0, k=0에서 j와 k의 startIndex는 varNameIndex()이다.
            				var.startIndex = var.varNameIndex;
            			}
	            		// 변수의 endIndex()를 separator까지로 한다.
	            		var.endIndex = IndexForHighArray.indexRelative(var, src, index );
	            		var.found = true;
	            		//if (template.found) {
	            			var.template = template;
	            		//}
	            		
	            		int docuIndex;
	                	if (hasAccess) docuIndex = k;
	                	else docuIndex = var.typeStartIndex() - 1;
	                	//int indexOfDocuEnd = SkipOnlyBlank(src, true, 0, docuIndex); // 공백 스킵
	                	int indexOfDocuEnd = CompilerHelper.SkipOnlyBlankAndAnnotationAndRegularComment(src, true, 0, docuIndex); // 공백 스킵
	                	
	                	DocuComment docu = 
	                			FindDocuComment(src, /*false, null, findVarParams,*/ 0, indexOfDocuEnd);
	                	var.docuComment = docu; 
	                	
	                	int nextIndexOfExpression = -1;
	                	int startIndexOfExpression = -1;
	            		int endIndexOfExpression = -1;
	            		
	            		FindVarUseParams varUse = null;
	                	if (separator.equals("=")) {	// 변수사용으로도 등록한다. int a = 5;
	                		varUse = new FindVarUseParams(null); 
	                		varUse.index = IndexForHighArray.indexRelative(varUse, src, var.varNameIndex());
	                		varUse.isForVarOrForFunc = true;
	                		varUse.name = src.getItem(varUse.index()).str;
	                		varUse.originName = varUse.name;	                		
	                		//mlistOfAllVarUses.add(varUse);
	                		//mlistOfAllVarUsesHashed.input(varUse);
	                		core.putVarUse(varUse);
	                		
	                		// index는 '='의 인덱스
	                		startIndexOfExpression = CompilerHelper.SkipBlank(src, false, index+1, src.count-1);
	                		nextIndexOfExpression = CompilerHelper.SkipExpression(compiler, false, startIndexOfExpression, src.count-1);
	                		//startIndexOfExpression = index+1;
	                		
	                		if (nextIndexOfExpression!=src.count) {
	                			separator = src.getItem(nextIndexOfExpression);
	                			endIndexOfExpression = nextIndexOfExpression-1;
	                		}
	                	}
	                	
	                	if (separator.equals(",")) { // int a, b 또는 int a=0, b=1;
	                		//OldTypeIndex(Compiler compiler, int startIndex, int endIndex, int startIndexOfExpression, int endIndexOfExpression,
	                		//		Template template, AccessModifier accessModifier)
	                		int nextIndexOfSeperator;
	                		if (nextIndexOfExpression!=-1) {
	                			nextIndexOfSeperator = CompilerHelper.SkipBlank(src, false, nextIndexOfExpression+1, src.count-1);
	                		}
	                		else {
	                			nextIndexOfSeperator = CompilerHelper.SkipBlank(src, false, index+1, src.count-1);
	                		}
	                		int fullNameIndex = Fullname.getFullNameIndex_OnlyType(compiler,  false, nextIndexOfSeperator, true);
	                		int nextIndex = CompilerHelper.SkipBlank(src, false, fullNameIndex+1, src.count-1);
	                		// int a, int b와 같은 함수인자를 제외하면
	                		if (!CompilerHelper.IsIdentifier(src.getItem(nextIndex), compiler)) { 
	                			OldTypeIndex oldTypeIndex2 = new OldTypeIndex(compiler, var.typeStartIndex(), var.typeEndIndex(),
	                    				startIndexOfExpression, endIndexOfExpression, template, var.accessModifier);
	                			return new ReturnOfFindVarDecl(oldTypeIndex2, var, varUse);
	                		}
	                	}
	                	
	                	// separator가 =나 ,이 아닌 ;나 )일 경우는 oldTypeIndex를 null로 리턴
		                //return null;
	                	return new ReturnOfFindVarDecl(null, var, varUse);
            		}
        		} // if (i!=endIndex+1) {
        		
        	} // if (findVarParams.typeStartIndex != -1) { // 타입이면
        	
        	else if (strType==null ||
        			CompilerHelper.IsSeparator(strType) || 
        			strType.equals("new") || strType.equals("else") || 
        			strType.equals("throw") || strType.equals("package") || strType.equals("import") ||
        			strType.equals("throws") ||
        			strType.equals("return") || strType.equals("continue") || strType.equals("break") ||
        			strType.equals("extends") || strType.equals("implements") ||
        			strType.equals("instanceof") || strType.equals("case") ||
        			IsAccessModifier(strType) ) 
        	{ // 변수의 사용, if (findVarParams.typeStartIndex != -1) {
        		
        		CodeString varName = src.getItem(varNameIndex.index());
        		if (varName.equals("long")) {
        			
        		}
        		if (index==384) {
        			int a;
        			a=0;
        			a++;
        		}
        		//if (compiler.IsKeyword(varName)) return null;
        		
        		
        		FindVarUseParams findVarUseParams = new FindVarUseParams(null);
        		findVarUseParams.index = IndexForHighArray.indexRelative(findVarUseParams, src, index);
        		
        		int nextIndex = 
        				this.findVarUseName(src, findVarUseParams, index);
        		
        		if (nextIndex==-1) return null;
        		
        		
        		//mlistOfAllVarUses.add(findVarUseParams);
        		//if (mlistOfAllVarUsesHashed!=null)
        		//	mlistOfAllVarUsesHashed.input(findVarUseParams);
        		findVarUseParams.originName = src.getItem(findVarUseParams.index()).str;
        		core.putVarUse(findVarUseParams);
        		
        		
        		if (strType!=null && strType.equals(".")) {
        			if (varName.equals("changeBounds")) {
            			
            		}
        			
	        		int foundParent = this.findParentOfVarUse(src, typeIndex, findVarUseParams);
	        		if (foundParent==-1) return new ReturnOfFindVarDecl(null, null, findVarUseParams);
	        		else if (foundParent==0) {
	        			
	        		}
        		}  // if (strType.equals(".")) { 
        		
        		boolean isExpressionElement = false;
        		if (oldTypeIndex!=null && oldTypeIndex.hasExpression() &&
    					oldTypeIndex.startIndexOfExpression()<=varNameIndex.index() && 
    					varNameIndex.index()<=oldTypeIndex.endIndexOfExpression())
        			isExpressionElement = true;
        		
        		// int a=0, b=1과 같이 varName이 0일 경우
        		// nextIndex 는 변수이름의 공백등을 제외한 다음 인덱스
        		if (src.getItem(nextIndex).equals(",")) { // 다음이 ,이면 수식의 인덱스들을 초기화
    				if (oldTypeIndex!=null) {
    					oldTypeIndex.startIndexOfExpression = null;
    					oldTypeIndex.endIndexOfExpression = null;
    				}
    			}
        		
        		if (isExpressionElement) {
        			return new ReturnOfFindVarDecl(oldTypeIndex, null, findVarUseParams);
        		}
        		
        		return new ReturnOfFindVarDecl(oldTypeIndex, null, findVarUseParams);
        		
        	} // else if (IsSeparator(strType) || strType.equals("return") || strType.equals("else") || strType.equals("throw"))
       // } // if (IsIdentifier(cstr))   { // 식별자 이면
        
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
			if (Common_Settings.g_printsLog) CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
		}
		return null;
	}
	
	
	int findVarUseName(HighArray_CodeString src, FindVarUseParams findVarUseParams, int index) {
		boolean isVarOrFuncCall = true;
		// index는 변수이름의 인덱스
		int nextIndex = CompilerHelper.SkipBlank(src, false, index+1, src.count-1);
		boolean isArrayElement=false;
		int startIndexArray=-1, endIndexArray=-1;
		
		if (index==21584) {
		}
		
		int nextIndexBackup = nextIndex;
		if (nextIndex!=src.count) {
			
			CodeString string = src.getItem(nextIndex);
			
			if (string.equals("<")) {
				// stack = new Stack<Block>();에서 nextIndex은 템플릿의 왼쪽 <이 된다.
				Template t = TemplateBase.getTemplate(compiler, nextIndex, 0);
				if (t!=null) {
					findVarUseParams.template = t;
					// 위의 예에서 nextIndex는 (의 인덱스가 된다.
					nextIndex = CompilerHelper.SkipBlank(src, false, t.indexRightPair()+1, src.count-1);
					//if (nextIndex==src.count) return null;
					string = src.getItem(nextIndex);
				}
			}
			if (string.equals("[")) {
				// 배열타입선언인지 아니면 배열원소사용인지 확인한다.
				int rightPair = Checker.CheckParenthesis(compiler,  "[", "]", nextIndex, src.count-1, false);
				if (rightPair==-1) return -1;
				startIndexArray = nextIndex;
				
				while(true) {
					nextIndex = CompilerHelper.SkipBlank(src, false, rightPair+1, src.count-1);
					if (nextIndex==src.count) return -1;
					if (!src.getItem(nextIndex).equals("[")) {
						endIndexArray = nextIndex-1;
						break;
					}
					rightPair = Checker.CheckParenthesis(compiler,  "[", "]", nextIndex, src.count-1, false);
					if (rightPair==-1) break;
				}
				// 배열 원소 참조인지 아니면 배열타입선언인지 확인한다.
				isArrayElement = Array.isArrayElement(compiler, startIndexArray, endIndexArray);
				
			}
			else if (string.equals("(")) { // 함수 호출, 함수 정의
				isVarOrFuncCall = false;
				int rightPair = Checker.CheckParenthesis(compiler,  "(", ")", nextIndex, src.count-1, false);
				if (rightPair==-1) {
					
				}
				nextIndex = rightPair;
				nextIndex = CompilerHelper.SkipBlank(src, false, nextIndex+1, src.count-1);
				
				//Class c = (new ScrollBars_test4().toObjectArray())[0].getClass();에서
				// varUse는 toObjectArray이다.
				while (true) {
    				CodeString string2 = src.getItem(nextIndex);
    				if (string2==null) break;
        			if (string2.equals("[")) {
        				// 배열타입선언인지 아니면 배열원소사용인지 확인한다.
        				int rightPair2 = Checker.CheckParenthesis(compiler,  "[", "]", nextIndex, src.count-1, false);
        				if (rightPair2==-1) return -1;
        				startIndexArray = nextIndex;
        				
        				while(true) {
        					nextIndex = CompilerHelper.SkipBlank(src, false, rightPair2+1, src.count-1);
        					if (nextIndex==src.count) return -1;
        					if (!src.getItem(nextIndex).equals("[")) {
        						endIndexArray = nextIndex-1;
        						break;
        					}
        					rightPair2 = Checker.CheckParenthesis(compiler,  "[", "]", nextIndex, src.count-1, false);
        					if (rightPair2==-1) break;
        				}
        				// 배열 원소 참조인지 아니면 배열타입선언인지 확인한다.
        				isArrayElement = Array.isArrayElement(compiler, startIndexArray, endIndexArray);
        				break;
        			}
        			else if (string2.equals("(")) { // 함수 호출, 함수 정의
        				isVarOrFuncCall = false;
        				int rightPair2 = Checker.CheckParenthesis(compiler,  "(", ")", nextIndex, src.count-1, false);
    					if (rightPair2==-1) break;
    					nextIndex = rightPair2;
        			}
        			else if (string2.equals(")")) { // fake 괄호
        				
        			}
        			else {
        				break;
        			}
        			nextIndex = CompilerHelper.SkipBlank(src, false, nextIndex+1, src.count-1);
    			}//while (true) {
			}//else if (string.equals("(")) { // 함수 호출, 함수 정의
			
		}//if (nextIndex!=src.count) {
		
		nextIndex = nextIndexBackup;
		
		            		
		//findVarUseParams.index = IndexForHighArray.indexRelative(findVarUseParams, src, index);
		findVarUseParams.isForVarOrForFunc = isVarOrFuncCall;
		findVarUseParams.isArrayElement = isArrayElement;
		if (!isArrayElement) {
			findVarUseParams.name = src.getItem(findVarUseParams.index()).str;
		}
		else { // varUse가 배열원소일 경우 buffer[i]에서 varUse의 index는 buffer를 가리키고
			// name만 buffer[i]를 갖게된다. 참고로 varUse들은 buffer, [, i, ] 이다.
			int arrIndex;
			findVarUseParams.name = src.getItem(findVarUseParams.index()).str;
			for (arrIndex=startIndexArray; arrIndex<=endIndexArray; arrIndex++) {
				CodeString str = src.getItem(arrIndex);
				if (CompilerHelper.IsBlank(str) || CompilerHelper.IsComment(str)) continue;
				findVarUseParams.name = findVarUseParams.name.concat(str.str);
			}
		}
		return nextIndex;
	}
	
	
	
	
	
	
    public void FindEventHandlerClass(HighArray_CodeString src,  
			FindClassParams findClassParams, int startIndexOfName, int endIndexOfName, 
			int indexOfSeparator, String fullNameOfClass)
	{
		
        int startParenthesis = indexOfSeparator;
        int endParenthesis = -1;
        FindBlockParams findBlockParams = new FindBlockParams(compiler, startParenthesis, endParenthesis);
                        
       
        findBlockParams.startIndex = IndexForHighArray.indexRelative(findBlockParams, src, startParenthesis);
        findBlockParams.blockName = fullNameOfClass;
                   	
        findClassParams.classNameIndex = IndexForHighArray.indexRelative(findClassParams, src, 
        		CompilerHelper.SkipBlank(src, true, 0, endIndexOfName));
    	findClassParams.startIndex = IndexForHighArray.indexRelative(findClassParams, src, startIndexOfName);
    	findClassParams.startIndexOfEventHandlerName = IndexForHighArray.indexRelative(findClassParams, src, startIndexOfName);
    	findClassParams.endIndexOfEventHandlerName = IndexForHighArray.indexRelative(findClassParams, src, endIndexOfName);
        findClassParams.found = true;
        findClassParams.findBlockParams = findBlockParams;
        findClassParams.findBlockParams.blockName = fullNameOfClass;
        
        if (findClassParams.classNameToExtend==null) {
        	findClassParams.classNameToExtend = "java.lang.Object";
        }
        
        if (findClassParams.interfacesToImplement==null) {
        	findClassParams.interfacesToImplement = new ArrayList(1);
        	findClassParams.interfacesToImplement.add(fullNameOfClass);
        }
        
        findBlockParams.categoryOfBlock = new CategoryOfBlock(CategoryOfBlock.Class, null);
        data.mlistOfBlocks.add(findBlockParams);
        
        findClassParams.isEventHandlerClass = true;
        
        return;
    }
	
	
	
	
	
	
	static class ReturnOfFindAccessModifier implements IReset {
		int r;
		/** 0:접근지정자가 아닌 첫번째 인덱스, 1:startIndex-1, 2:다큐주석의 인덱스+1*/
		int type;
		
		/** @param type 0:접근지정자가 아닌 첫번째 인덱스, 1:startIndex-1, 2:다큐주석의 인덱스+1*/
		ReturnOfFindAccessModifier(int r, int type) {
			this.r = r;
			this.type = type;
		}

		@Override
		public void destroy() {
			
			
		}
	}
	
	/** endIndex부터 역순으로 접근지정자들을 찾는다. 
	 * 반환값:0:접근지정자가 아닌 첫번째 인덱스, 또는 1:startIndex-1, 또는 2:다큐주석의 인덱스+1*/
	ReturnOfFindAccessModifier FindAccessModifier(HighArray_CodeString src, int startIndex, int endIndex, AccessModifier accessModifier) {
		if (accessModifier!=null) 
			accessModifier.reset();
		
		int k;
        // 접근지정자
        for (k = endIndex; k >= startIndex; k--)
        {
        	int index = CompilerHelper.SkipOnlyBlank(src, true, startIndex, k);
        	if (index==startIndex-1) {
        		return new ReturnOfFindAccessModifier(index, 1);
        		
        	}
        	k = index;
        	CodeString cstr = src.getItem(index);
        	if (!CompilerHelper.IsDocuComment(cstr)) {
        		if (CompilerHelper.IsRegularComment(cstr)) continue;
        		if (CompilerHelper.IsAnnotation(cstr)) continue;
	        	if (index<0 || !IsAccessModifier(cstr)) {
	        		//break; // 접근지정자가 아닌 인덱스
	        		if (k+1<=endIndex) {
		        		accessModifier.startIndex = IndexForHighArray.indexRelative(accessModifier, src, k+1);
		        		accessModifier.endIndex = IndexForHighArray.indexRelative(accessModifier, src, endIndex);
	        		}
	        		return new ReturnOfFindAccessModifier(k, 0);
	        	}
	        	else {
	        		if (accessModifier==null) {
	        			// 변수나 메서드, 클래스에 붙는 accessModifier는 null일 수 없다.
	        			accessModifier = new AccessModifier(compiler, -1, -1);
	        		}
	        		if (cstr.equals("static")) {
	        			accessModifier.isStatic = true;
	        			accessModifier.found = true;
	        		}
	        		else if (cstr.equals("synchronized")) {
	        			accessModifier.isSynchronized = true;
	        			accessModifier.found = true;
	        		}
	        		else if (cstr.equals("abstract")) {
	        			accessModifier.isAbstract = true;
	        			accessModifier.found = true;
	        		}
	        		else if (cstr.equals("final")) {
	        			accessModifier.isFinal = true;
	        			accessModifier.found = true;
	        		}
	        		else if (cstr.equals("public")) {
	        			accessModifier.accessPermission = AccessModifier.AccessPermission.Public;
	        			accessModifier.found = true;
	        		}
	        		else if (cstr.equals("private")) {
	        			accessModifier.accessPermission = AccessModifier.AccessPermission.Private;
	        			accessModifier.found = true;
	        		}
	        		else if (cstr.equals("protected")) {
	        			accessModifier.accessPermission = AccessModifier.AccessPermission.Protected;
	        			accessModifier.found = true;
	        		}
	        		else if (cstr.equals("default")) {
	        			accessModifier.accessPermission = AccessModifier.AccessPermission.Default;
	        			accessModifier.found = true;
	        		}
	        		else if (cstr.equals("enum")) { // enum class
	        			accessModifier.isEnum = true;
	        			accessModifier.found = true;
	        			accessModifier.isFinal = true;
	        		}
	        		else if (cstr.equals("interface")) { // interface class
	        			accessModifier.isInterface = true;
	        			accessModifier.isAbstract = true;
	        			accessModifier.found = true;
	        		}
	        		else if (cstr.equals("native")) {
	        			//accessModifier.isInterface = true;
	        			//accessModifier.isAbstract = true;
	        			accessModifier.isNative = true;
	        			accessModifier.found = true;
	        		}
	        	}
        	}
        	else {
        		//return k+1;//다큐주석의 인덱스+1
        		return new ReturnOfFindAccessModifier(k+1, 2);
        	}
        }
        //return k;//접근지정자가 아닌 첫번째 인덱스, 또는 startIndex-1
        return new ReturnOfFindAccessModifier(k, 1);
	}
	
	
	
	
	
	/** kewordIndex의 인덱스를 startIndex(), ';'의 인덱스를 endIndex()로 하는 
	 * 할당문을 리턴한다.
	 * result의 kewordIndex를 가지고 완전한 문장을 찾는다.
	 * @param result : in, out*/  
	public FindSpecialStatementParams FindSpecialStatement(HighArray_CodeString src, int keywordIndex) {
		int i1;
		int endIndex = src.count-1;
		
        i1 = CompilerHelper.Skip(src, false, ";", keywordIndex+1, endIndex);
        if (i1==endIndex+1) {
        	String[] stopCharList = {";", ":", ",", "{", "}"};
        	int stopIndex = CompilerHelper.Skip(src, false, stopCharList, keywordIndex+1, endIndex);
        	CompilerStatic.errors.add(new Error(compiler, stopIndex, stopIndex, "invalid statement end"));
        	return null;
        }
     
        
        FindSpecialStatementParams result = new FindSpecialStatementParams(compiler, -1, -1, keywordIndex); 
        result.startIndex = IndexForHighArray.indexRelative(result, src, result.kewordIndex());
        result.endIndex = IndexForHighArray.indexRelative(result, src, i1);
        result.found = true;
        
        return result;
		
	}
	
	/** lValue의 인덱스를 startIndex(), ';'의 인덱스를 endIndex()로 하는 
	 * 할당문을 리턴한다.
	 * @param indexOfEquals : 등호의 인덱스*/  
	public void FindAssignStatement(HighArray_CodeString src, 
			FindAssignStatementParams result, FindVarUseParams lValue, 
			int indexOfEquals, Block curBlock) {
		if (lValue.index()==267) {
			int a;
			a=0;
			a++;
		}

		
		
		String operator = "=";
		int index = CompilerHelper.SkipBlank(src, true, 0, indexOfEquals-1);
		if (CompilerHelper.IsAssignOperator(src.getItem(index))) {
			operator = src.getItem(index) + "=";
		}
		
		
		ArrayInitializer.isArrayInitializer(compiler, lValue);
		
		FindExpressionParams expression = null;
		expression = new FindExpressionParams(compiler, -1, -1);
		FindRValue(src, expression, lValue, indexOfEquals, curBlock);
        if (!expression.found) return;
        
        // 할당문의 시작 인덱스를 찾는다.
        int startIndex;
        if (lValue.parent==null) {
        	// A.B.C.D var = i; 에서 var.index
        	startIndex = Fullname.getFullNameIndex(compiler, true, lValue.index(), true);
        }
        else {
        	// a.b.c.d = i에서 d.index-1
        	startIndex = Fullname.getFullNameIndex(compiler, true, lValue.index(), true);
        }
        if (startIndex<0) {
        	CompilerStatic.errors.add(new Error(compiler, 0, 0, "The start of sentence reachs that of file."));
        	return;
        }
       
        if (startIndex==267) {
        	int a;
        	a=0;
        	a++;
        }
        
        result.startIndex = IndexForHighArray.indexRelative(result, src, startIndex);
       
        // 문장 구분자를 포함한 인덱스를 끝 인덱스로 한다.
        int endIndex = CompilerHelper.SkipBlank(src, false, expression.endIndex()+1, src.count-1);
        
        CodeString strEnd = src.getItem(endIndex);
        
       
        
        result.endIndex = IndexForHighArray.indexRelative(result, src, endIndex);
        result.lValue = lValue;
        result.indexOfEqual = IndexForHighArray.indexRelative(result, src, indexOfEquals);
        result.operator = operator;
        result.rValue = new FindFuncCallParam(compiler, expression);
        result.found = true;
        
        lValue.rValue = result.rValue;
		
	}
	
	
	
	
	
	/**var가 for루프의 괄호안에서 선언되면 true를 리턴한다.
	 * @param parent */
	boolean varIsDefinedInForLoopParenthesis(FindVarParams var, Block parent) {
		if (parent instanceof FindControlBlockParams) {
			FindControlBlockParams controlBlock = (FindControlBlockParams) parent;
			
			if (controlBlock.catOfControls!=null)	{
				if (controlBlock.catOfControls.category==CategoryOfControls.Control_for) {
					if (controlBlock.indexOfLeftParenthesis()<=var.varNameIndex() && 
							var.varNameIndex()<=controlBlock.indexOfRightParenthesis()) {
						return true;
						
					}
				}
			}
		}
		return false;
	}
	
	
	/** isFuncComment가 true이면 함수의 다큐를 찾으므로  findVarParams는 null이고, 
	 * false이면 멤버변수의 다큐를 찾으므로 findFunctionParams는 null이다.
	 * endIndex는 주석의 마지막 인덱스이다. endIndex를 감소시키며 startIndex()까지 찾는다.*/
	DocuComment FindDocuComment(HighArray_CodeString src, 
			/*boolean isFuncComment, FindFunctionParams findFunctionParams, FindVarParams findVarParams,*/ 
			int startIndex, int endIndex) {
		if (endIndex<0) return null;
		
		
		int loop;
    	int startOfDocu=-1, endOfDocu=-1;
    	CodeString item = src.getItem(endIndex);
    	if (item.charAt(0).type==CodeStringType.DocuComment) {
    		endOfDocu = endIndex;
    	}
    	else return null;
    	
    	DocuComment docu = null;
    	for (loop=endIndex-1; loop>=startIndex; loop--) {
    		item = src.getItem(loop); 
    		if (item.charAt(0).type!=CodeStringType.DocuComment) {
    			startOfDocu = loop+1;
    			docu = new DocuComment(src, startOfDocu, endOfDocu);
    			return docu;
    		}
    	}
    	return null;
	}
	
	void FindControlBlock(HighArray_CodeString src, int keywordIndex, 
			FindControlBlockParams result) {
		int i = keywordIndex;
		int startIndex = 0;
		int endIndex = src.count-1;
		result.found = false;
		
		CodeString cstr = src.getItem(i);
		if (i==31493) {
		}
        CategoryOfControls category = null;
        
        if (cstr.equals("if")) category = new CategoryOfControls(CategoryOfControls.Control_if); 
        else if (cstr.equals("else")) {
        	int next = CompilerHelper.SkipBlank(src, false, i+1, endIndex);           
            if (next==endIndex+1) return;
            CodeString strNext = src.getItem(next); 
            if (strNext.equals("if")) {
            	category = new CategoryOfControls(CategoryOfControls.Control_elseif);
            }
            else if (strNext.equals("{")) {
            	category = new CategoryOfControls(CategoryOfControls.Control_else);
            }
            else {	// id, 기타 등등, 단문 else
            	category = new CategoryOfControls(CategoryOfControls.Control_else);
            }
        	
        }
        else if (cstr.equals("for")) category = new CategoryOfControls(CategoryOfControls.Control_for);
        else if (cstr.equals("while"))  {
        	category = new CategoryOfControls(CategoryOfControls.Control_while);
        }
        else if (cstr.equals("switch"))  category = new CategoryOfControls(CategoryOfControls.Control_switch);
        else if (cstr.equals("do"))  {
        	category = new CategoryOfControls(CategoryOfControls.Control_dowhile);
        }
        else if (cstr.equals("case") || cstr.equals("default"))  {
        	category = new CategoryOfControls(CategoryOfControls.Control_case);
        }
        
        if (category!=null) {
        	boolean r = Checker.CheckControlBody(compiler, src, category, result, startIndex, endIndex, i);
        	if (r) {
        		result.catOfControls = category;
        		//result.startIndex() = i;
        		//result.endIndex = result.blockParams.endIndex;
        		//result.found = true;
        		
        		//Log.d(category.toString(), "start:"+result.startIndex()+" end:"+result.endIndex);
        		return;
        	}
        }
		
	}
	
	
	boolean findStaticBlock(HighArray_CodeString src, FindClassParams parent, FindFunctionParams findFunctionParams, int staticIndex) {
		int endIndex = src.count-1;
		int separator = CompilerHelper.SkipBlank(src, false, staticIndex + 1, endIndex); // 공백 스킵
    	int indexOfSeparator=separator;
    	if (separator==endIndex+1) {
    		return false;        		
    	}
    	else {
    		findFunctionParams.functionNameIndex = IndexForHighArray.indexRelative(findFunctionParams, src, staticIndex);
    		
    		//if (showsError==false) return false;
    		CodeString strSeparator = src.getItem(separator);
    		int index=separator;
    		if (strSeparator.equals("throws")) {
        		while (true) {
            		index = CompilerHelper.SkipBlank(src, false, index+1, endIndex);
                    if (index==endIndex+1) break;
                    index = Fullname.getFullNames(compiler, "throws", null, findFunctionParams, index);
                    if (index!=-1) {
                    	CodeString codeStr = src.getItem(index);
                    	if (codeStr.equals("{")) {
                    		break;
                    	}
                    	else if (codeStr.equals(",")) {
                    	} 
                    }
                    else {	// '{'이 없을 때
                    	index = separator;
                    	break;
                    }
        		}
        	}
    		indexOfSeparator = index;
    		
    		strSeparator = src.getItem(indexOfSeparator);
    		if (!strSeparator.equals("{")) {
    			//errors.add(new Error(compiler, indexOfSeparator, indexOfSeparator, "{ not exists"));
    			return false;
    		}
    	}
    	
    	
    	// 반드시 ) 다음에는 { 이다.
    	int startParenthesis = indexOfSeparator;
        int endParenthesis = -1;
        FindBlockParams findBlockParams = new FindBlockParams(compiler, startParenthesis, endParenthesis);
        
       
        if (findBlockParams.startIndex()!=-1/* && findBlockParams.endIndex()!=-1*/) {
        	findFunctionParams.startIndex = IndexForHighArray.indexRelative(findFunctionParams, src, staticIndex);
        	findFunctionParams.found = true;
        	findFunctionParams.isStaticBlock = true;
        	findFunctionParams.findBlockParams = findBlockParams;
        	findFunctionParams.findBlockParams.blockName = "static init block";
        	
        	if (findFunctionParams.accessModifier==null) {
				AccessModifier accessModifier = new AccessModifier(compiler, -1, -1);				
				findFunctionParams.accessModifier = accessModifier;
			}
        	findFunctionParams.accessModifier.accessPermission = AccessModifier.AccessPermission.Public;
        	findFunctionParams.accessModifier.isStatic = true;
        	
        	findBlockParams.categoryOfBlock = new CategoryOfBlock(CategoryOfBlock.Function, null);
        	//mlistOfBlocks.add(findBlockParams);
        	core.putFindBlockParams(findBlockParams);
        	return true;
        }
		return false;
	}
	
	void FindFunction(HighArray_CodeString src, FindClassParams parent, FindFunctionParams findFunctionParams, 
			int indexOfLeftParenthesis, int coreThreadID)
	{
        int i;

        findFunctionParams.returnTypeStartIndex = null;
        findFunctionParams.returnTypeEndIndex = null;
        findFunctionParams.functionNameIndex = null;
        findFunctionParams.found = false;

        if (indexOfLeftParenthesis==-1) return;
        
        i = CompilerHelper.SkipBlank(src, true, 0, indexOfLeftParenthesis - 1);
        if (i==-1) return;
        	
        CodeString cstr = src.getItem(i);
        
        if (indexOfLeftParenthesis==2074) {
        }
        
        if (i==847) {
        }
        
        
        // 함수 이름 찾기
        if (CompilerHelper.IsIdentifier(cstr, compiler))   // 식별자 이면
        {
        	if (cstr.equals("RectForPage")) {
        	}
        	else if (cstr.equals("CheckParenthesis")) {
        	}
            
        	CodeString returnType=null;
        	// i는 functionNameIndex()이다.
        	findFunctionParams.returnTypeEndIndex = IndexForHighArray.indexRelative(findFunctionParams, src, 
        			CompilerHelper.SkipBlank(src, true, 0, i - 1));
        	
        	Template template = null;
        	
        	if (findFunctionParams.returnTypeEndIndex() != -1) {        			
    			returnType = src.getItem(findFunctionParams.returnTypeEndIndex());
    			if (returnType.equals("new")) { // constructor
    				return;
    			}
    			else if (returnType.equals(".")) { // 함수의 이름은 하나의 스트링이고 "."을 포함해서는 안된다.
    				return;
    			}
    			
    			if (data.language==Language.C && returnType.equals("*")) {	// 포인터타입인지 확인
    				int typeIndex = IsType(src, true, findFunctionParams.returnTypeEndIndex()).index;
    				findFunctionParams.returnTypeStartIndex = IndexForHighArray.indexRelative(findFunctionParams, src, 
    						typeIndex);
    			}
    			else {
    				//template = new Template(compiler);
    				ReturnOfIsType returnOfIsType = IsType(src, true, findFunctionParams.returnTypeEndIndex());
    				int typeIndex = returnOfIsType.index;
    				template = returnOfIsType.template;
    				findFunctionParams.returnTypeStartIndex = IndexForHighArray.indexRelative(findFunctionParams, src,    						
    						typeIndex);
    				if (template!=null && template.found) {
    					data.mlistOfAllTemplates.add(template);
    					// HighArray<FindVarParams> getData();에서 템플릿
    					findFunctionParams.template = template;
    				}
    				
    			}
    		}
        	
        	if (findFunctionParams.returnTypeStartIndex()!=-1 && findFunctionParams.returnTypeEndIndex()!=-1) {
        		
        	}
        	else {
        		
        	}
        	
        	boolean r = false;
        	
        	r = Checker.CheckBody(compiler, src, findFunctionParams, 0, src.count-1, i);
        	            	
        	if (r) {
        		
        		
        		if (findFunctionParams.returnTypeEndIndex()!=-1 && 
                    	( CompilerHelper.IsIdentifier(returnType, compiler) || findFunctionParams.returnTypeStartIndex()!=-1 ) )
                    	// 일반함수찾기 : 주석이 아니고 식별자나 타입, 포인터이면
        		{
        			if (findFunctionParams.startIndex()==-1) {
        				if (findFunctionParams.returnTypeStartIndex()!=-1) {
        					findFunctionParams.startIndex = IndexForHighArray.indexRelative(findFunctionParams, src, findFunctionParams.returnTypeStartIndex());
        				}
        			}
        			findFunctionParams.name = src.getItem(findFunctionParams.functionNameIndex()).str;
        			//findFunctionParams.getReturnType(src, 
        			//		findFunctionParams.returnTypeStartIndex, findFunctionParams.returnTypeEndIndex);
        			findFunctionParams.isConstructor = false;
        			if (findFunctionParams.returnTypeStartIndex()!=-1 && findFunctionParams.returnTypeEndIndex()!=-1) {
	        			findFunctionParams.returnType = 
	        				Fullname.getFullNameType(compiler, findFunctionParams.returnTypeStartIndex(), 
	        					findFunctionParams.returnTypeEndIndex(), coreThreadID);
        			}
        			//i = findFunctionParams.endIndex() + 1;
        		}
        		else { // constructor
        			if (findFunctionParams.isAbstractMethod) {
        				CompilerStatic.errors.add(new Error(compiler, findFunctionParams.functionNameIndex(), findFunctionParams.functionNameIndex(), 
        						"Interface has an invalid method."));
        			}
        			findFunctionParams.returnTypeEndIndex = null;
        			String name;
        			if (parent!=null) {
	        			if (parent.classNameIndex()!=-1) {
	        				name = src.getItem(parent.classNameIndex()).str;
	        			}
	        			else {
	        				name = CompilerStatic.getShortName(parent.name);
	        			}
	        			findFunctionParams.isConstructor = true;
	            		if (!cstr.equals(name)) {
	            			CompilerStatic.errors.add(new Error(compiler, findFunctionParams.functionNameIndex(), findFunctionParams.functionNameIndex(), 
	            					"Class name not equals with constructor name."));
	            		}
	            		
	            		findFunctionParams.name = src.getItem(findFunctionParams.functionNameIndex()).str;
	            		if (parent.loadWayOfFindClassParams!=LoadWayOfFindClassParams.ByteCode) {
		            		String fullname = data.packageName + "." + Fullname.getFullNameExceptPackageName(src, parent);
		            		fullname = fullname.substring(0, fullname.length()-1);
		        			findFunctionParams.returnType = fullname;
	            		}
	            		else { // ByteCode에서 읽을 경우
	            			findFunctionParams.returnType = parent.name;
	            		}
        			}       			
        			
        		}
        		findFunctionParams.name = src.getItem(findFunctionParams.functionNameIndex()).str;
        		return;
        	}
            else	// if (r)
            {
            	// 함수 호출
                //i++;
            	i = indexOfLeftParenthesis + 1;
            } // 리턴타입 확인           	
        
        }	// 함수이름찾기
        else
        {
            //i++;
        	i = indexOfLeftParenthesis + 1;
        }   // 구분자
    }
	
	
	
	
	/** varUse 다음에 '=', '+=', '-=', '*=', '/=', '%=' 가 있으면 lValue라고 판단한다. 
	 * @return '='의 인덱스를 리턴, lValue가 아니면 -1을 리턴*/
	public int IsLValue(HighArray_CodeString src, FindVarUseParams varUse) {
		return this.IsLValue(src, varUse.index());
		
	}
	
	
	/** varUse 다음에 '=', '+=', '-=', '*=', '/=', '%=' 가 있으면 lValue라고 판단한다. 
	 * @return '='의 인덱스를 리턴, lValue가 아니면 -1을 리턴*/
	public int IsLValue(HighArray_CodeString src, int indexOfVarUse) {
		if (indexOfVarUse==4875) {
			int a;
			a=0;
			a++;
		}
		int i1, i2;
		int endIndex = src.count-1;
		// 공백 스킵
        i1 = CompilerHelper.SkipBlank(src, false, indexOfVarUse+1, endIndex);           
        if (i1==endIndex+1) return -1;        
        CodeString str1=null;
        try {
        str1 = src.getItem(i1);
        }catch(Exception e) {
        	if (Common_Settings.g_printsLog) e.printStackTrace();
        }
        
        //  공백 스킵
        i2 = CompilerHelper.SkipBlank(src, false, i1+1, endIndex);           
        if (i2==endIndex+1) return -1;
        CodeString str2 = src.getItem(i2);
        
        CodeString id = src.getItem(indexOfVarUse);
        int i;
        if (CompilerHelper.IsIdentifier(id, compiler)) {
        	// a[0][1] = 2;
        	if (str1.equals("[")) {
				for (i=i1; i<src.count; i++) {
					CodeString cstr = src.getItem(i);
					if (CompilerHelper.IsBlank(cstr) || 
							CompilerHelper.IsComment(cstr)) continue;
					else if (cstr.equals("[")) {
						int rightPair = Checker.CheckParenthesis(compiler,  "[", "]", i, src.count-1, false);
						if (rightPair!=-1) {
							i = rightPair;
						}
					}
					else break;
				}
				i1 = i;
				str1 = src.getItem(i1);
				
				i2 = CompilerHelper.SkipBlank(src, false, i1+1, endIndex);           
			    if (i2==endIndex+1) return -1;
			    str2 = src.getItem(i2);
        	}
        	
        	// +=, -=, *=, /=, %=, |=, &= 등인 경우
        	if (CompilerHelper.IsAssignOperator(str1)) {        		
        		// <<=, >>=을 제외한 대입연산자들
        		if (str2.equals("=")) {
        			return i2;
        		}
        	}
        	else if (str1.equals(">")) {
    			if (str2.equals(">")) {
    				int i3 = CompilerHelper.SkipBlank(src, false, i2+1, endIndex);           
           		    if (i3==endIndex+1) return -1;
           		    CodeString str3 = src.getItem(i3);
           		    if (str3.equals("=")) return i3; // ">>="
           		    else return -1;
    			}
    			else  {
    				return -1;
    			}
    		}
    		else if (str1.equals("<")) {
    			if (str2.equals("<")) {
    				int i3 = CompilerHelper.SkipBlank(src, false, i2+1, endIndex);           
   	    		    if (i3==endIndex+1) return -1;
   	    		    CodeString str3 = src.getItem(i3);
   	    		    if (str3.equals("=")) return i3; // "<<="
   	    		    else return -1;
    			}
    			else {
    				return -1;
    			}
    		}
        	// =+, =-, =*, =/등은 에러, a=+1; a=-1;
        	else if (str1.equals("=")) {
        		if (str2.equals("=")) return -1;
        		else if (CompilerHelper.IsOperator(str2)) {
        			if (str2.equals("+") || str2.equals("-") || str2.equals("!")) {
        				// 일단 =뒤의 +,-는 부호 operator로 간주하고 LValue로 리턴한다.
        				return i1;
        			}
        			else {
        				CompilerStatic.errors.add(new Error(compiler, i1,i2,"invalid compostive operator"));
	        			return i1;
        			}
        		}
        		else { // 일반적인 할당문의 =의 인덱스를 리턴한다.
        			return i1;
        		}
        	}
        }//if (IsIdentifier(id)) {
        return -1;
		
	}
	
	
	/** f();   f1().f2();   f().a;-->이것은 error   
	 * f1(f2());     m.f1().f2();    m1.m2.f1().f2();
	 * return f(); 이것은 제외한다.
	 * 이와같은 독립적인 함수호출문장을 찾는다.*/
	public void FindIndependentFuncCall(HighArray_CodeString src, FindVarUseParams varUse, 
			FindIndependentFuncCallParams result) {
		int index;
		index = varUse.index();
		
		String varUseName = src.getItem(index).toString();
		
		if (index==147) {
			int a;
			a=0;
			a++;	
		}
		
		if (varUseName.equals("a")) {
		}
		
		int startIndex=varUse.index();
		int endIndex;
		
		
		int indexOfStart = -1;
		int i;
		for (i=startIndex; i>=0; i--) {
			// if () func();
			// else func(); 등
			// case 3: 의 ':'
			// 대입연산자나 타입이 오면 리턴한다.
			CodeString str = src.getItem(i);
			if ((str.equals(";") || str.equals(":") || str.equals("{") || str.equals("}") || 
					str.equals("else"))) {
				indexOfStart = i;
				break;
			}
			else if (str.equals(")")) {
				int leftPair = Checker.CheckParenthesis(compiler,  "(", ")", 0, i, true);
				if (leftPair==-1) return;
				int keywordIndex = CompilerHelper.SkipBlank(src, true, 0, leftPair-1);
				if (keywordIndex==-1) return;
				
				CodeString keyword = src.getItem(keywordIndex);
				if (keyword.equals("if") || keyword.equals("while") || keyword.equals("for")) {
					indexOfStart = i;
					break;
				}
			}
		}
		
		
		if (indexOfStart==-1) return;
		startIndex = CompilerHelper.SkipBlank(src, false, indexOfStart+1, src.count-1);
		
		CodeString start = src.getItem(startIndex);
		
		if (start.equals("new")) {
			// Skips new in new RFrame(width,height);
			startIndex = CompilerHelper.SkipBlank(src, false, startIndex+1, src.count-1);
		}
		start = src.getItem(startIndex);
		
		if (!(CompilerHelper.IsIdentifier(start, compiler) || start.equals("(") /*|| start.equals("new")*/)) {
			// throw new Exception()
			// return func()			
			return;
		}
		
		endIndex = Fullname.getFullNameIndex(compiler, false, startIndex, false);
		endIndex = CompilerHelper.SkipBlank(src, false, endIndex+1, src.count-1);
		
		//endIndex = CompilerHelper.Skip(src, false, ";", varUse.index(), src.count-1);
		
		if (endIndex>=src.count) {
			CompilerStatic.errors.add(new Error(compiler, varUse.index(), varUse.index(), "invalid statement end"));
			return;
		}
		
		CodeString end = src.getItem(endIndex);
		if (end.equals(";")) {
		}
		else if (end.equals("=")) {
			// In strInput.getItem(i).type = CodeStringType.Text; 
			// end is '='. 
			return;
		}
		else {
			// ';' not exists
			CompilerStatic.errors.add(new Error(compiler, endIndex, endIndex, "invalid statement end"));
			return;
		}
		
		result.startIndex = IndexForHighArray.indexRelative(result, src, startIndex);
		result.endIndex = IndexForHighArray.indexRelative(result, src, endIndex);
		result.found = true;
		
		
	}
	
	/** ++i, i++, --i, i--
	 * i++; 의 경우에 startIndex()는 구분자+1, endIndex()는 ;을 포함하는 인덱스를 갖는다.
	 * @param coreThreadID */
	public FindIncrementStatementParams findIndependentIncrementStatement_sub(HighArray_CodeString src, FindVarUseParams varUse, int coreThreadID) {
		if (varUse.index()==19264) {
		}
		FindIncrementStatementParams r = null;
		int startIndex, endIndex;
		
		startIndex = Fullname.getFullNameIndex(compiler, true, varUse.index(), true);
		if (startIndex<0) {
			return null;
		}
		startIndex = CompilerHelper.SkipBlank(src, true, 0, startIndex-1);
		if (startIndex<0) {
			return null;
		}
		
		
		endIndex = Fullname.getFullNameIndex(compiler, false, varUse.index(), false);
		if (endIndex>src.count-1) {
			return null;
		}
		endIndex = CompilerHelper.SkipBlank(src, false, endIndex+1, src.count-1);
		if (endIndex>src.count-1) {
			return null;
		}
		
		// 여기까지 하면 startIndex()와 endIndex()는 모두 구분자의 인덱스가 된다.
		
		CodeString operator = src.getItem(startIndex);
		if (operator.equals("+")) {
			startIndex = CompilerHelper.SkipBlank(src, true, 0, startIndex-1);
			if (startIndex<0) {
				return null;
			}
			CodeString operator2 = src.getItem(startIndex);
			if (operator2.equals("+")) {
				r = new FindIncrementStatementParams(compiler, startIndex, endIndex-1, coreThreadID);
				r.setLValue(varUse);
				r.type = 0; // ++i
				return r;
			}
		}
		else if (operator.equals("-")) {
			startIndex = CompilerHelper.SkipBlank(src, true, 0, startIndex-1);
			if (startIndex<0) {
				return null;
			}
			CodeString operator2 = src.getItem(startIndex);
			if (operator2.equals("-")) {
				r = new FindIncrementStatementParams(compiler, startIndex, endIndex-1, coreThreadID);
				r.setLValue(varUse);
				r.type = 2; // --i
				return r;
			}
		}
		
		
		startIndex = Fullname.getFullNameIndex(compiler, true, varUse.index(), true);
		if (startIndex<0) {
			return null;
		}
		startIndex = CompilerHelper.SkipBlank(src, true, 0, startIndex-1);
		if (startIndex<0) {
			return null;
		}
		
		
		endIndex = Fullname.getFullNameIndex(compiler, false, varUse.index(), false);
		if (endIndex>src.count-1) {
			return null;
		}
		endIndex = CompilerHelper.SkipBlank(src, false, endIndex+1, src.count-1);
		if (endIndex>src.count-1) {
			return null;
		}
		
		// 여기까지 하면 startIndex()와 endIndex()는 모두 구분자의 인덱스가 된다.
		
		operator = src.getItem(endIndex);
		if (operator.equals("+")) {
			endIndex = CompilerHelper.SkipBlank(src, false, endIndex+1, src.count-1);
			if (endIndex>src.count-1) {
				return null;
			}
			CodeString operator2 = src.getItem(endIndex);
			if (operator2.equals("+")) {
				r = new FindIncrementStatementParams(compiler, startIndex+1, endIndex, coreThreadID);
				//r.setLValue(varUse);
				r.type = 1; // i++
				return r;
			}
		}
		else if (operator.equals("-")) {
			endIndex = CompilerHelper.SkipBlank(src, false, endIndex+1, src.count-1);
			if (endIndex>src.count-1) {
				return null;
			}
			CodeString operator2 = src.getItem(endIndex);
			if (operator2.equals("-")) {
				r = new FindIncrementStatementParams(compiler, startIndex+1, endIndex, coreThreadID);
				//r.setLValue(varUse);
				r.type = 3; // i--
				return r;
			}
		}
		
		return r;
	}
	
	
	/** a=++i + 2;, a=i++;, a=1+--i;, a=i--+2;
	 * i++; 의 경우에 startIndex()는 문장구분자+1, endIndex()는 ;을 포함하는 인덱스를 갖는다.*/
	public FindIncrementStatementParams findIndependentIncrementStatement(HighArray_CodeString src, FindIncrementStatementParams inc, Block curBlock) {		
		if (inc!=null) {
			if (inc.startIndex()==966) {
				int a;
				a=0;
				a++;
			}
			int startIndex = CompilerHelper.SkipBlank(src, true, 0, inc.startIndex()-1);
			int endIndex = CompilerHelper.SkipBlank(src, false, inc.endIndex()+1, src.count-1);
			CodeString start = src.getItem(startIndex);
			CodeString end = src.getItem(endIndex);
			// for (i=srcIndex, k=destIndex; i<srcIndex+len; i++, k++) 에서 i++과 k++는 독립적인 증감문이다.
			// i++의 start는 ;이고 end는 ,이다. k++의 start는 ,이고 end는 )이다.			
			if (start.equals("{") || start.equals("}") || start.equals(";") || start.equals(",") || start.equals("else")) {
				if (end.equals(",") || end.equals(";") || end.equals(")")) {
					inc.startIndex = IndexForHighArray.indexRelative(inc, src, startIndex+1);
					inc.endIndex = IndexForHighArray.indexRelative(inc, src, endIndex);
					return inc;
				}
			}
			// if (cursorPos.x>0) cursorPos.x--;
			if (start.equals(")")) {
				int leftPair = Checker.CheckParenthesis(compiler,  "(", ")", 0, startIndex, true);
				int keywordIndex = CompilerHelper.SkipBlank(src, true, 0, leftPair-1);
				if (CompilerHelper.IsKeyword(src.getItem(keywordIndex), compiler)) {
					if (end.equals(",") || end.equals(";") || end.equals(")")) {
						inc.startIndex = IndexForHighArray.indexRelative(inc, src, startIndex+1);
						inc.endIndex = IndexForHighArray.indexRelative(inc, src, endIndex);
						return inc;
					}
				}
			}
			
			if (curBlock instanceof FindControlBlockParams) {
				FindControlBlockParams controlBlock = (FindControlBlockParams) curBlock;
				if (controlBlock.indexOfLeftParenthesis()<=inc.startIndex() 
						&& inc.endIndex()<=controlBlock.indexOfRightParenthesis()) {
					return inc;
				}
			}
		}
		return null;
	}
	
		
	/**i=++i+1; f(++i);와 같은 증감문을 문장 statement에서 찾아서 varUse에 연결하고 해당 문장의
	 * includesInc를 true로 만든다. 
	 * @param coreThreadID */
	public void findIncrementStatementInStatement(HighArray_CodeString src, FindStatementParams statement, int coreThreadID) {
		int i;
		int startIndexInmBuffer = statement.startIndex();
		int endIndexInmBuffer = statement.endIndex();
		
		if (statement.startIndex()>=387 && statement.startIndex()<389) {
		}
		
		for (i=startIndexInmBuffer; i<=endIndexInmBuffer; i++) {
			CodeString str = src.getItem(i);
			if (str.equals("+") || str.equals("-")) {
				int nextIndex = CompilerHelper.SkipBlank(src, false, i+1, src.count-1);
				if (nextIndex>=src.count) {
					i++;
					continue;
				}
				CodeString next = src.getItem(nextIndex);
				if (next.equals(str.str)) { // ++, --
					int indexID = CompilerHelper.SkipBlank(src, false, nextIndex+1, src.count-1);
					CodeString id = src.getItem(indexID);
					if (CompilerHelper.IsIdentifier(id, compiler)) {
						int leftPair = CompilerHelper.SkipBlank(src, false, indexID+1, src.count-1);
						CodeString leftPairStr = src.getItem(leftPair);
						if (leftPairStr.equals("(")) { // ++i()
							CompilerStatic.errors.add(new Error(compiler, i, leftPair, "invalid "+str+next));
						}
						else {
							if (leftPairStr.equals("[")) {
								// ++a[b[++k+1]]
								// 배열을 붙여도 안 붙여도 된다.
							}
							// ++i, --i
							statement.includesInc = true;						
							FindIncrementStatementParams inc = new FindIncrementStatementParams(compiler, i, indexID, coreThreadID); 
							FindVarUseParams varUse = CompilerStatic.getVarUseWithIndex(data.mlistOfAllVarUsesHashed, id.str, indexID);
							if (varUse!=null) {
								varUse.inc = inc;
								inc.setLValue(varUse);
								if (str.equals("+")) inc.type = 0;
								else inc.type = 2;
							}
						}
					}// ++i, --i
					else {
						// i++, i--
						// i는 첫번째 +의 인덱스
						int indexID2 = CompilerHelper.SkipBlank(src, true, 0, i-1);
						CodeString id2 = src.getItem(indexID2);
						if (CompilerHelper.IsIdentifier(id2, compiler)) { // i++, i--
							statement.includesInc = true;
							FindIncrementStatementParams inc = new FindIncrementStatementParams(compiler, indexID2, nextIndex, coreThreadID); 
							FindVarUseParams varUse = CompilerStatic.getVarUseWithIndex(data.mlistOfAllVarUsesHashed, id2.str, indexID2);
							if (varUse!=null) {
								varUse.inc = inc;
								inc.setLValue(varUse);
								if (str.equals("+")) inc.type = 1;
								else inc.type = 3;
							}
						}
						else if (id2.equals("]")) { // a[k++]++
							int leftPair = Checker.CheckParenthesis(compiler,  "[", "]", 0, indexID2, true);
							int indexID3 = CompilerHelper.SkipBlank(src, true, 0, leftPair-1);
							CodeString id3 = src.getItem(indexID3);
							if (CompilerHelper.IsIdentifier(id3, compiler)) {
								statement.includesInc = true;
								FindIncrementStatementParams inc = new FindIncrementStatementParams(compiler, indexID3, nextIndex, coreThreadID); 
								FindVarUseParams varUse = CompilerStatic.getVarUseWithIndex(data.mlistOfAllVarUsesHashed, id3.str, indexID3);
								if (varUse!=null) {
									varUse.inc = inc;
									inc.setLValue(varUse);
									if (str.equals("+")) inc.type = 1;
									else inc.type = 3;
								}
							}
						}//else if (id2.equals("]")) { // a[k++]++
						else if (id2.equals(")")) {
							int leftPair = Checker.CheckParenthesis(compiler,  "(", ")", 0, indexID2, true);
							int indexID3 = CompilerHelper.SkipBlank(src, true, 0, leftPair-1);
							CodeString id3 = src.getItem(indexID3);
							if (CompilerHelper.IsIdentifier(id3, compiler)) { // a()++
								CompilerStatic.errors.add(new Error(compiler, i, indexID2, "invalid "+str+next));
							}
						}
						else { // 상수++, ++상수
							CompilerStatic.errors.add(new Error(compiler, i, indexID2, "invalid "+str+next));
						}
					} // i++, i--, a[k++]++
				}//if (next.equals(str.str)) {
			}//if (str.equals("+") || str.equals("-")) {
		}//for (i=startIndexInmBuffer; i<=endIndexInmBuffer; i++) {
	
	}
	
	
	/** synchronized, try, catch, finally 등의 블록을 찾는다.
	 * startIndex : 접근지정자(static, public등) 
	 *  endIndex : block의 끝, 즉 '}' */
	public void FindSpecialBlock(HighArray_CodeString src,  
			FindSpecialBlockParams result, int keywordIndex)
	{
		CodeString str = src.getItem(keywordIndex);
		int i;
		int leftPair, rightPair;
		int blockStart;
		if (str.equals("synchronized")) {			
			leftPair = CompilerHelper.SkipBlank(src, false, keywordIndex + 1, src.count-1);
			if (src.getItem(leftPair).equals("(")) {
				result.indexOfLeftParenthesis = IndexForHighArray.indexRelative(result, src, leftPair);
				//rightPair = Skip(src, false, ")", leftPair + 1, src.count-1);
				rightPair =	        		
						Checker.CheckParenthesis(compiler,  "(", ")", result.indexOfLeftParenthesis(), src.count-1, false);
				if (rightPair==-1) {
					CompilerStatic.errors.add( new Error(compiler, rightPair,rightPair,"')' not exist.") );
					return;
				}
				if (src.getItem(rightPair).equals(")")) {
					result.indexOfRightParenthesis = IndexForHighArray.indexRelative(result, src, rightPair);
					blockStart = CompilerHelper.SkipBlank(src, false, rightPair + 1, src.count-1);
					if (src.getItem(blockStart).equals("{")) {
						FindBlockParams blockParams = new FindBlockParams(compiler, blockStart, -1); 
						result.findBlockParams = blockParams;
						result.findBlockParams.categoryOfBlock = new CategoryOfBlock(CategoryOfBlock.Synchronized,null);
						// 조건문을 연결
						result.findBlockParams.blockName = "";
		            	if (result.indexOfLeftParenthesis()!=-1 && result.indexOfRightParenthesis()!=-1) {
			            	ArrayListChar list = new ArrayListChar(50);
			            	for (i=result.indexOfLeftParenthesis(); i<=result.indexOfRightParenthesis(); i++) {
			            		list.add(src.getItem(i).str);
			            	}
			            	result.findBlockParams.blockName = new String(list.getItems());
		            	}
		            	data.mlistOfBlocks.add(blockParams);
						result.startIndex = IndexForHighArray.indexRelative(result, src, keywordIndex);
						result.found = true;
						result.nameIndex = IndexForHighArray.indexRelative(result, src, keywordIndex);
						result.specialBlockType = FindSpecialBlockParams.SpecialBlockType_synchronized;
						result.isBlock = true;
						return;
					}
				}
			}
		}
		else if (str.equals("catch")) {
			leftPair = CompilerHelper.SkipBlank(src, false, keywordIndex + 1, src.count-1);
			if (src.getItem(leftPair).equals("(")) {
				result.indexOfLeftParenthesis = IndexForHighArray.indexRelative(result, src, leftPair);
				//rightPair = Skip(src, false, ")", leftPair + 1, src.count-1);
				rightPair =	        		
						Checker.CheckParenthesis(compiler,  "(", ")", result.indexOfLeftParenthesis(), src.count-1, false);
				if (rightPair==-1) {
					CompilerStatic.errors.add( new Error(compiler, rightPair,rightPair,"')' not exist.") );
					return;
				}
				if (src.getItem(rightPair).equals(")")) {
					result.indexOfRightParenthesis = IndexForHighArray.indexRelative(result, src, rightPair);
					blockStart = CompilerHelper.SkipBlank(src, false, rightPair + 1, src.count-1);
					if (src.getItem(blockStart).equals("{")) {
						FindBlockParams blockParams = new FindBlockParams(compiler, blockStart, -1); 
						result.findBlockParams = blockParams;
						result.findBlockParams.categoryOfBlock = new CategoryOfBlock(CategoryOfBlock.Catch,null);
						
						// 조건문을 연결
						result.findBlockParams.blockName = "";
		            	if (result.indexOfLeftParenthesis()!=-1 && result.indexOfRightParenthesis()!=-1) {
			            	ArrayListChar list = new ArrayListChar(50);
			            	for (i=result.indexOfLeftParenthesis(); i<=result.indexOfRightParenthesis(); i++) {
			            		list.add(src.getItem(i).str);
			            	}
			            	result.findBlockParams.blockName = new String(list.getItems());
		            	}
		            	
		            	data.mlistOfBlocks.add(blockParams);
						result.found = true;
						result.startIndex = IndexForHighArray.indexRelative(result, src, keywordIndex);
						result.nameIndex = IndexForHighArray.indexRelative(result, src, keywordIndex);
						result.specialBlockType = FindSpecialBlockParams.SpecialBlockType_catch;
						result.isBlock = true;
						return;
					}
				}
			}
		}
		else if (str.equals("try") || str.equals("finally")) {
			blockStart = CompilerHelper.SkipBlank(src, false, keywordIndex + 1, src.count-1);
			if (src.getItem(blockStart)!=null && src.getItem(blockStart).equals("{")) {
				FindBlockParams blockParams = new FindBlockParams(compiler, blockStart, -1); 
				result.findBlockParams = blockParams;
				data.mlistOfBlocks.add(blockParams);
				result.found = true;
				result.startIndex = IndexForHighArray.indexRelative(result, src, keywordIndex);
				result.nameIndex = IndexForHighArray.indexRelative(result, src, keywordIndex);
				if (str.equals("try")) {
					result.specialBlockType = FindSpecialBlockParams.SpecialBlockType_try;
					result.findBlockParams.categoryOfBlock = new CategoryOfBlock(CategoryOfBlock.Try,null);
					result.findBlockParams.blockName = "";
				}
				else if (str.equals("finally")) {
					result.specialBlockType = FindSpecialBlockParams.SpecialBlockType_finally;
					result.findBlockParams.categoryOfBlock = new CategoryOfBlock(CategoryOfBlock.Finally,null);
					result.findBlockParams.blockName = "";
				}
				result.isBlock = true;
				return;
			}
			else {
				CompilerStatic.errors.add(new Error(compiler, blockStart, blockStart, "'{' required."));
			}
		}
		
	}
	
	
	
	
	
	
	 /** type이 아니면 -1을 리턴, type이면 index를 리턴, 
     * array이면 역방향일 경우 배열의 시작인덱스를, 순방향일 경우 ]의 인덱스를 리턴
     * 포인터이면 역방향일 경우 타입의 시작인덱스를 리턴
     * @param template : result(out), 템플릿이 중첩될 경우 가장 바깥 템플릿, 즉 parent
     * @param index : isReverse가 true일경우 타입의 endIndex(), isReverse가 false일경우 타입의 startIndex()*/
    public ReturnOfIsType IsType(HighArray_CodeString src, boolean isReverse, int index) {
    	if (index<0) return new ReturnOfIsType(-1, null);
    	
    	if (index==103) {
    		int a;
    		a=0;
    		a++;
    	}
    	
    	if (isReverse && data.language==Language.C && src.getItem(index).equals("*")) {
    		// 일단 타입을 확인하지 않는다.차후에
    		int i = index;
    		while (i>=0) {
	    		i = CompilerHelper.SkipBlank(src, isReverse, 0, i-1);
	    		if (i==-1) return new ReturnOfIsType(-1, null);
	    		CodeString str = src.getItem(i);
	    		if (CompilerHelper.IsIdentifier(str, compiler)) return new ReturnOfIsType(i, null);	    		
	    		else if (str.equals("*")) continue;
	    		else {
	    			return new ReturnOfIsType(-1, null);
	    		}
    		}
    	}
    	
    	ReturnOfIsArrayType isArray = Array.IsArrayType(compiler, isReverse, index); 
    	int indexArrayType = isArray.r;
    	if (!isArray.isTemplateCheck) { // 일반배열이면 리턴
    		if (indexArrayType!=-1) return new ReturnOfIsType(indexArrayType, null);
    	}
    	
    	
    	int indexTemplate = -1;
    	//indexTemplate = isTemplate(src, index);
    	Template template2 = null;
    	if (!isArray.isTemplateCheck) { // 템플릿인지 확인한다.
    		template2 = TemplateBase.isTemplate(compiler,  index);
    	}
    	else { // 템플릿 배열인지 확인한다.
    		template2 = TemplateBase.isTemplate(compiler,  indexArrayType);
    	}
    	if (template2!=null) {
    		template2.found = true;
    		indexTemplate = template2.indexTypeName();    		
    		
    	}
    	if (indexTemplate!=-1) {
    		return new ReturnOfIsType(indexTemplate, template2);
    	}
    	
    	if (!isReverse) {
    		index = CompilerHelper.SkipBlank(src, false, index, src.count-1);
    	}
    	else {
    		index = CompilerHelper.SkipBlank(src, true, 0, index);
    	}
    	    	
    	CodeString c = src.getItem(index);
    	//if (CompilerHelper.IsBlank(c) || CompilerHelper.IsComment(c)) return -1;
    	if (CompilerHelper.IsSeparator(c)) return new ReturnOfIsType(-1, null);
    	if (CompilerHelper.IsKeyword(c, compiler)) return new ReturnOfIsType(-1, null);
    	
    	
    	if (CompilerHelper.IsConstant(c)) return new ReturnOfIsType(-1, null);
    			
    	// int, char 등의 내장 타입인 경우
    	if (CompilerHelper.IsDefaultType(c, compiler)) return new ReturnOfIsType(index, null);
    	
    	// Object, Integer, Char 등
    	//if (IsTypeOfDefaultLibrary(c)) return index;
    	
    	
    	
    	// com.gsoft.common.Rectangle
    	int indexFullName = Fullname.getFullNameIndex_OnlyType(compiler,  isReverse, index, true);
    	if (indexFullName!=-1) {
    		//indexFullName = SkipBlank(src, false, indexFullName, index);
    		return new ReturnOfIsType(indexFullName, null);
    	}
    	
    	
    	if (IsUserDefinedType(c)) return new ReturnOfIsType(index, null);
    	
    	// 일단 타입을 확인하지 않는다.차후에 
    	if (CompilerHelper.IsIdentifier(c, compiler)) return new ReturnOfIsType(index, null);
    	
    	return new ReturnOfIsType(-1, null); 	
    }
    
    
    boolean hasAccessModifier(FindVarParams var, FindFunctionParams func) {
		if (var!=null) {
			if (var.accessModifier!=null) {
				if (var.accessModifier.isFinal) return true;
				if (var.accessModifier.isStatic) return true;
				if (var.accessModifier.accessPermission!=null) return true;
			}
			else {
				return false;
			}
		}
		else if (func!=null) {
			if (func.accessModifier!=null) {
				if (func.accessModifier.isFinal) return true;
				if (func.accessModifier.isStatic) return true;
				if (func.accessModifier.accessPermission!=null) return true;
			}
			else {
				return false;
			}
		}
		return false;
	}
    
	
	
	public boolean IsAccessModifier(CodeString c) {
    	int i;
    	for (i=0; i<data.AccessModifiers.count; i++) {
    		if (c.equals(data.AccessModifiers.getItem(i))) return true;
    	}
    	return false;    	
    }
    public boolean IsAccessModifier(String c) {
    	int i;
    	for (i=0; i<data.AccessModifiers.count; i++) {
    		if (c.equals(data.AccessModifiers.getItem(i))) return true;
    	}
    	return false;    	
    }
    
    
    /** FindVarDeclarationsAndVarUses호출에서 typeIndex가 '.'일 경우 findVarUseParams의 parent를 찾는다. 
	 * 에러가 있으면 -1를 리턴, 못찾으면 0을 리턴, 찾으면 1을 리턴*/
	int findParentOfVarUse(HighArray_CodeString src, int typeIndex, FindVarUseParams findVarUseParams) {
		if (findVarUseParams.index()==392) {
			int a;
			a=0;
			a++;
		}
		int parentIndex =  CompilerHelper.SkipBlank(src, true, 0, typeIndex - 1);
		boolean found = false;
		if (parentIndex!=-1) {
			CodeString parent = src.getItem(parentIndex);
			int m;
			if (parent.equals("]")) { 
				// parent 가 배열원소일 경우, buffer[i].equals()에서 equals의 parent는 buffer이다.
				
				// (new ScrollBars_test4().toObjectArray())[0].getClass();
				int indexParent = parentIndex;
				while (true) {
					int leftPair = Checker.CheckParenthesis(compiler,  "[", "]", 0, indexParent, true);
					if (leftPair==-1) {
						CompilerStatic.errors.add(new Error(compiler, indexParent, indexParent,"] not paired."));
						return -1;
					}
					indexParent = CompilerHelper.SkipBlank(src, true, 0, leftPair-1);
					CodeString prevLeftPair = src.getItem(indexParent);
					if (!prevLeftPair.equals("]")) break;
				}//while (true) {
				CodeString str = src.getItem(indexParent);
				if (str.equals(")")) {
					// f()[0][0].varUse
					int lp = Checker.CheckParenthesis(compiler, "(", ")", 0, indexParent, true);
					if (lp==-1) {
						CompilerStatic.errors.add(new Error(compiler, indexParent, indexParent,") not paired."));
						return -1;
					}
					int idIndex = CompilerHelper.SkipBlank(src, true, 0, lp-1);
					CodeString id = src.getItem(idIndex);
					if (!CompilerHelper.IsIdentifier(id, compiler)) {// fake괄호 제거
					}
					else { // 함수호출, 위에서 toObjectArray
						indexParent = idIndex;
					}
				}
				else {
				}
				for (m=data.mlistOfAllVarUses.getCount()-1; m>=0; m--) {
					FindVarUseParams use = (FindVarUseParams)data.mlistOfAllVarUses.getItem(m);
					if (use.index()==indexParent) {
						findVarUseParams.parent = use;
						use.child = findVarUseParams;
						found = true;
						break;
					}
				}
			}
			else if (!parent.equals(")")) {  // 이전 varUse가 일반변수일 경우
				for (m=data.mlistOfAllVarUses.getCount()-1; m>=0; m--) {
					FindVarUseParams use = (FindVarUseParams)data.mlistOfAllVarUses.getItem(m);
					if (use.index()==parentIndex) {
						findVarUseParams.parent = use;
						use.child = findVarUseParams;
						found = true;
						break;
					}
				}
			}
			else if (parent.equals(")")) {
				int leftPair;
				int backupIndex = parentIndex;
				
				
				int backup1 = backupIndex;
				while ( src.getItem(parentIndex).equals(")") ) {
					leftPair = Checker.CheckParenthesis(compiler,  "(", ")", 0, parentIndex, true);
					if (leftPair!=-1) {
						parentIndex = CompilerHelper.SkipBlank(src, true, 0, leftPair - 1);
						if (parentIndex!=-1) {
							CodeString parent2 = src.getItem(parentIndex);
							if ( CompilerHelper.IsIdentifier( parent2, compiler ) ) { 
								// 이전 varUse가 괄호로 싸여진 함수호출일 경우
    							for (m=data.mlistOfAllVarUses.getCount()-1; m>=0; m--) {
    	        					FindVarUseParams use = (FindVarUseParams)data.mlistOfAllVarUses.getItem(m);
    	        					if (use.index()==parentIndex) {
    	        						findVarUseParams.parent = use;
    	        						use.child = findVarUseParams;
    	        						found = true;
    	        						break;
    	        					}
    	        				}
    							if (found) break;
							}
							else {
								parentIndex = CompilerHelper.SkipBlank(src, true, 0, backup1 - 1);
								backup1 = parentIndex;
							}
						}
						else {
							break;
						}
					} // if (leftPair!=-1) {
					else {
						break;
					}
				} // while(true)*/
							
				if (!found) {
					leftPair = Checker.CheckParenthesis(compiler,  "(", ")", 0, backupIndex, true);
					if (leftPair!=-1) {
						parentIndex = CompilerHelper.SkipBlank(src, true, 0, leftPair - 1);
						if (parentIndex!=-1) {
							CodeString parent2 = src.getItem(parentIndex);
							if ( CompilerHelper.IsIdentifier( parent2, compiler ) ) { 
								// 이전 varUse가 함수호출일 경우
    							for (m=data.mlistOfAllVarUses.getCount()-1; m>=0; m--) {
    	        					FindVarUseParams use = (FindVarUseParams)data.mlistOfAllVarUses.getItem(m);
    	        					if (use.index()==parentIndex) {
    	        						findVarUseParams.parent = use;
    	        						use.child = findVarUseParams;
    	        						found = true;
    	        						break;
    	        					}
    	        				}
							}
						}
					}
				}
				
				if (!found) {
					int backup2 = backupIndex;
					// ((Button)(controls[0])).changeBounds(boundsOfButtonOK);
					while (true) {
						parentIndex = CompilerHelper.SkipBlank(src, true, 0, backup2 - 1);
						if (parentIndex!=-1) {
							CodeString parent2 = src.getItem(parentIndex);
							if ( CompilerHelper.IsIdentifier( parent2, compiler ) ) { 
								// 이전 varUse가 괄호에 싸인 일반변수일 경우
    							for (m=data.mlistOfAllVarUses.getCount()-1; m>=0; m--) {
    	        					FindVarUseParams use = (FindVarUseParams)data.mlistOfAllVarUses.getItem(m);
    	        					if (use.index()==parentIndex) {
    	        						findVarUseParams.parent = use;
    	        						use.child = findVarUseParams;
    	        						found = true;
    	        						break;
    	        					}
    	        				}
    							if (found) break;
							}
							else if (parent2.equals("]")) { 
	        					// 건너뛰기
	        					leftPair = Checker.CheckParenthesis(compiler,  "[", "]", 0, parentIndex, true);
	        					if (leftPair==-1) {
	        						CompilerStatic.errors.add(new Error(compiler, parentIndex,parentIndex,"] not paired."));
	        						return -1;
	        					}
	        					backup2 = leftPair;
	        				}
							else if (parent2.equals(")")) {
								backup2 = parentIndex;
							}
							else {
								CompilerStatic.errors.add(new Error(compiler, parentIndex, parentIndex, "invalid token : "+parent2));
								return -1;
							}
						}
						else { // if (parentIndex==-1) {
							return -1;
						}
					} // while (true) {
				} // if (found==false) {
			} // else if (parent.equals(")")) {
		} // if (parentIndex!=-1) {
		if (found) return 1;
		return 0;
	}
	
	
	
	
	
	/** lValue와 '=' 다음의 인덱스를 startIndex(), ';' 이전의 인덱스를 endIndex()로 하는 수식을 리턴한다.
	 * 배열초기화문일 경우 rValue의 시작과 끝 인덱스는 {, }의 인덱스가 된다.
	 * @param indexOfEquals : '=', '+=', '-=', '*=', '/=', '%='에서 =의 인덱스,
	 * */  
	public void FindRValue(HighArray_CodeString src, FindExpressionParams result, 
			FindVarUseParams lValue, int indexOfEquals, Block curBlock) {
		if (lValue.index()==655) {
		}
		
		int i1 = indexOfEquals;
		int endIndex = src.count-1;
		
        
        // i1는 =의 인덱스
        result.startIndex = IndexForHighArray.indexRelative(result, src, 
        		CompilerHelper.SkipBlank(src, false, i1+1, endIndex));
        
        if (src.getItem(result.startIndex()).equals("{")) { 
        	// 배열초기화문일 경우 rValue의 시작과 끝 인덱스는 {, }의 인덱스가 된다.
        	result.endIndex = IndexForHighArray.indexRelative(result, src,  
        			Checker.CheckParenthesis(compiler,  "{", "}", result.startIndex(), src.count-1, false));
        	result.found = true;
        	return;
        }
        
        FindControlBlockParams curControlBlock = null;
        if (curBlock instanceof FindControlBlockParams) {
        	curControlBlock = (FindControlBlockParams) curBlock;
        }
        int i = result.startIndex();        
        while (i<endIndex) {
        	CodeString str = src.getItem(i);
        	if (CompilerHelper.IsBlank(str) || CompilerHelper.IsComment(str)) {
        		i++;
        	}
        	else if (CompilerHelper.IsIdentifier(str, compiler) || CompilerHelper.IsDefaultType(str, compiler)) {
		        i++;
        	}
        	else if (str.equals("[")) { // 배열원소
	        	int rightPair = 
		        		Checker.CheckParenthesis(compiler,  "[", "]", i, endIndex, false);
	        	if (rightPair==-1) {
	        		i = endIndex;
	        		break;
	        	}
	        	i = rightPair;		        	
	        	i++;
		    }
        	else if (str.equals("(")) { // 함수호출, 타입캐스트
        		int rightPair = 
		        		Checker.CheckParenthesis(compiler,  "(", ")", i, endIndex, false);
        		if (rightPair==-1) {
	        		i = endIndex;
	        		break;
	        	}
	        	i = rightPair;		        	
	        	i++;
        	}	        
	        else if (str.equals(")")) {
	        	if (curControlBlock!=null && curControlBlock.indexOfRightParenthesis()!=-1 && curControlBlock.indexOfRightParenthesis()==i) {
	        		break; // for (j=0; j<3; j+=2) 에서 i는 )을 가리킨다. 	
	        	}
	        	else {
	        		// )의 짝을 찾는다.
	        		int leftPair = 
			        		Checker.CheckParenthesis(compiler,  "(", ")", 0, i, true);
	        		if (leftPair==-1) {
		        		i = 0;
		        		break;
		        	}
	        		if (leftPair<lValue.index()) {
	        			break;
	        		}
	        		i++;
	        	}
	        }
	        else if (str.equals("]")) {
	        	// ]의 짝을 찾는다.
        		int leftPair = 
		        		Checker.CheckParenthesis(compiler,  "[", "]", 0, i, true);
        		if (leftPair==-1) {
	        		i = 0;
	        		break;
	        	}
        		i++;
	        }
	        else if (str.equals(",")) break;
	        else if (str.equals(";")) break;
	        else if (str.equals("{") || str.equals("}")) break;
	        else if (str.equals("if") || str.equals("for") || str.equals("while") || str.equals("do") ||
	        		str.equals("switch") || str.equals("case")  || str.equals("try") || str.equals("catch") || str.equals("finally") ||
	        		str.equals("synchronized")) {
	        //else if (CompilerHelper.IsKeyword(str, compiler)) {
	        	//  int color = C
	            //  if (f==0) return 0;
	        	break;
	        }
	        else {
	        	i++;
	        }
        	
        }
        
        CodeString end = src.getItem(i);
        
        if (i<endIndex && 
        		(end.equals(",") || end.equals(";")  || end.equals(")")) ) {
	        result.found = true;
	        result.endIndex = IndexForHighArray.indexRelative(result, src, i-1);
        }
        else {
        	CompilerStatic.errors.add(new Error(compiler, i, i, "invalid statement end"));
        	result.found = false;
        }
        
       
		
	}
	
    
	
	
	public boolean IsUserDefinedType(CodeString c) {
    	int i;
    	// user-defined type
    	for (i=0; i<data.mlistOfImportedClasses.count; i++) {
    		String typeUserDefined = data.mlistOfImportedClasses.getItem(i);
    		if (!c.toString().contains(".")) {
    			int indexOftypeUserDefined = typeUserDefined.indexOf(c.toString());
    			if (indexOftypeUserDefined==typeUserDefined.length()-c.toString().length()) {
    				return true;
    			}
    		}
    		else {
    			String type = c.toString();
    			if (type.equals(typeUserDefined)) {
    				return true;
    			}
    		}
    	}
    	return false;
    }
	
	
	/** childClass의 parentClass를 찾아 accessPermission을 확인하고 멤버를 상속한다. 
	 * 즉 childClass의 멤버에 추가한다.<br>
	 * //if (childClass.hasInherited) return; 
	 * 이 주석을 풀면 ConnectDialog, Control, ConnectDialog을 Start2상태로 순서대로 읽을때 주석을 제대로 못읽을 수가 있다.
	 * 왜냐하면 ConnectDialog의 parent인 EditableDialog가 hasInherited가 true인 상태여서 Control을 
	 * 다시 읽어 클래스 캐시를 갱신하였더라도 그대로 리턴을 해버려서 
	 * Control이 주석이 없는 바이트코드 상태이고  주석이 있는 Start2상태가 아니기 때문이다.
	 * @param coreThreadID */
	public void FindMembersInherited(FindClassParams childClass, int coreThreadID) {
		if (CompilerStatic.getShortName(childClass.name).equals("ViewEx")) {
			int a;
			a=0;
			a++;
		}
		if (childClass.name.equals("java.lang.Object")/* || childClass.name.equals("java.lang.object")*/) {
			childClass.hasInherited = true;
			return;
		}
		
		// 주석을 풀면 ConnectDialog, Control, ConnectDialog을 Start2상태로 순서대로 읽을때 주석을 제대로 못읽을 수가 있다.
		// 왜냐하면 ConnectDialog의 parent인 EditableDialog가 hasInherited가 true인 상태여서 Control을 
		// 다시 읽어 클래스 캐시를 갱신하였더라도 그대로 리턴을 해버려서 
		// Control이 주석이 없는 바이트코드 상태이고  주석이 있는 Start2상태가 아니기 때문이다.
		if (childClass.hasInherited) return;
		
		childClass.hasInherited = true;
		
		
		String parentClassName;
		int loopCount = 0;
		ArrayListString listOfparentClassName = new ArrayListString(2);
		if (!childClass.isInterface) {
			if (childClass.classNameToExtend==null) {
				childClass.classNameToExtend = "java.lang.Object";
			}
			parentClassName = childClass.classNameToExtend;
			listOfparentClassName.add(parentClassName);
			loopCount = 1;
			if (childClass.interfaceNamesToImplement!=null) {
				loopCount += childClass.interfaceNamesToImplement.count;
				for (int i=0; i<childClass.interfaceNamesToImplement.count; i++) {
					listOfparentClassName.add(
							childClass.interfaceNamesToImplement.getItem(i));
				}
			}
		}
		else {//인터페이스
			if (childClass.classNameToExtend==null) {
				childClass.classNameToExtend = "java.lang.Object";
			}
			if (childClass.interfaceNamesToImplement==null) {
				loopCount = 1;
				listOfparentClassName.add(childClass.classNameToExtend);
			}
			else {
				loopCount = childClass.interfaceNamesToImplement.count + 1;
				listOfparentClassName.add(childClass.classNameToExtend);
				for (int i=0; i<childClass.interfaceNamesToImplement.count; i++) {
					listOfparentClassName.add(
							childClass.interfaceNamesToImplement.getItem(i));
				}
			}
		}
		
		if (childClass.listOfVarParamsInherited==null) {
			childClass.listOfVarParamsInherited = new ArrayListIReset(15);
		}
		else {
			childClass.listOfVarParamsInherited.reset2();
		}
		if (childClass.listOfFunctionParamsInherited==null) {
			childClass.listOfFunctionParamsInherited = new ArrayListIReset(10);
		}
		else {
			childClass.listOfFunctionParamsInherited.reset2();
		}
		
		int k;
		for (k=0; k<loopCount; k++) {
			parentClassName = listOfparentClassName.getItem(k);
			
			// parentClassName이 shortname일수도 있으므로 getFullNameType2()를 써야한다.
			// 왜냐하면 FindAllClassesAndItsMembers2_sub()에서 findClass(), findInterface()의 
			// getFullNameType()호출은 파일 내 정의 클래스들이 아직 읽혀지지 않을수도 있기 때문이다.
			parentClassName = Fullname.getFullNameType2(compiler, parentClassName, childClass.classNameIndex(), coreThreadID);
			childClass.hasInherited = true; 
			
			//while (parentClassName!=null && parentClassName.equals("")==false) {
			if (parentClassName!=null && !parentClassName.equals("")) {
				
				
				// recursive 호출이므로 java.lang.Object클래스부터 상속이 된다.
				if (CompilerHelper.getShortName(parentClassName).equals("Compiler")) {
				}
				// loadClass()함수가 재귀적으로 FindMembersInherited()을 호출하므로
				// 상속관계의 가장 위인 java.lang.Object부터 상속이 된다.
				FindClassParams parentClass = Loader.loadClass(compiler, parentClassName, coreThreadID);
				int i, j=0;
				if (parentClass!=null) {
					
					if (parentClass.name.equals(childClass.classNameToExtend) ||
							/*parentClass.name.equals("java.lang.object") ||*/
							parentClass.name.equals("java.lang.Object")) {
						// parentClass가 class일 경우
						//if (childClass.classToExtend==null) { 
							// 한번 초기화만 가능, 그렇지 않으면 java.lang.Object가 되어버린다.
							childClass.classToExtend = parentClass;
						//}
					}
					else {
						// parentClass가 인터페이스일 경우
						if (childClass.interfacesToImplement==null) {
							childClass.interfacesToImplement = new ArrayList(3);								
						}
						childClass.interfacesToImplement.add(parentClass);
					}
					
					
					// parentClass 에 정의되어 있고 childClass에도 중복해서 정의된 변수도
					// 모두 상속된다.
					ArrayListIReset vars = null;				
					for (j=0; j<2; j++) {
						if (j==0) vars = parentClass.listOfVariableParams;
						else vars = parentClass.listOfVarParamsInherited;
						if (vars==null) continue;
						if (j==1 && parentClass.accessModifier.isInterface) {
							continue;
						}
						
						for (i=0; i<vars.count; i++) {
							FindVarParams var = (FindVarParams) vars.getItem(i);
							
							if (j==1 && parentClass.accessModifier.isInterface && 
									((FindClassParams)var.parent).name.equals("java.lang.Object")) {
								continue;
							}
							
							if (var.isThis || var.isSuper) continue;
							if (var.accessModifier==null) {
								childClass.listOfVarParamsInherited.add(var);
							}
							else {
								// final 멤버도 상속이 된다.
								//if (var.accessModifier.isFinal) continue;
								//if (var.accessModifier.isStatic) continue; // static inherit not allowed
								if (var.accessModifier.accessPermission==null) {
									childClass.listOfVarParamsInherited.add(var);
								}
								if (var.accessModifier.accessPermission!=null && 
									var.accessModifier.accessPermission!=AccessPermission.Private) {
									childClass.listOfVarParamsInherited.add(var);
								}
							}
						}//for (i=0; i<vars.count; i++) {
					}//for (j=0; j<2; j++) {
					
					ArrayListIReset funcs;
					for (j=0; j<2; j++) {
						// 부모클래스의 메서드부터 상속하고 
						// 부모클래스가 상속받은 메서드를 그 다음에 상속한다.
						if (j==0) funcs = parentClass.listOfFunctionParams;
						else funcs = parentClass.listOfFunctionParamsInherited;
						if (funcs==null) continue;
						
						
						for (i=0; i<funcs.count; i++) {
							FindFunctionParams func = (FindFunctionParams) funcs.getItem(i);
							
							if (j==1 && parentClass.accessModifier.isInterface && 
									((FindClassParams)func.parent).name.equals("java.lang.Object")) {
								// 인터페이스를 상속할 경우 인터페이스가 상속한 Object의 멤버들을 컨티뉴한다.
								continue;
							}
							
							if (func.accessModifier==null) {
								childClass.listOfFunctionParamsInherited.add(func);
							}
							else {
								// final 멤버도 상속이 된다.
								//if (func.accessModifier.isFinal) continue;
								//if (func.accessModifier.isStatic) continue; // static inherit not allowed
								
								
								FindFunctionParams funcOfChild = childClass.hasOverrided(func, coreThreadID);
								if (funcOfChild!=null) {
									String parentClassNameOffuncOfChild = ((FindClassParams)funcOfChild.parent).name;
									String parentClassNameOffunc = ((FindClassParams)func.parent).name;
									if (!parentClassNameOffuncOfChild.equals(parentClassNameOffunc)) {
										if (funcOfChild.overridedFindFunctionParams==null) {
											// ColorDialog가 Dialog를 상속하면
											// childClass.listOfFunctionParamsInherited에는 
											// Dialog, Control. Object, OnTouchListener의 순으로
											// 멤버들이 상속이 된다.
											// 따라서 맨 처음에 나오는 하위 클래스의 함수가 override가 되도록 한다.
											funcOfChild.overridedFindFunctionParams = func;
										}
										if (((FindClassParams)func.parent).accessModifier.isInterface) {
											// ColorDialog.onTouchEvent()를 OnTouchListener.onTouchEvent()의 Override로 한다.
											funcOfChild.overridedFindFunctionParams = func;
										}
									}
									else {
										// childClass에서 인터페이스를 구현할 경우 java.lang.Object의 함수들을 여러번 상속할 위험이 있다.
										continue;
									}
								}
								if (func.accessModifier.isAbstract) {
									// 현재 클래스가 클래스이고 추상 메서드를 상속할 경우 childClass는 그 메서드를 구현하고 있어야 한다.
									// 현재 클래스가 인터페이스이면 에러를 발생시키지 않는다.
									FindFunctionParams funcOfChild2 = childClass.hasFunc(func, coreThreadID);
									// 클래스가 인터페이스를 구현할 경우 현재 클래스 뿐만 아니라 부모클래스에서 구현을 해도 된다.
									if (funcOfChild2==null) {
										if (!childClass.accessModifier.isInterface && 
												!childClass.accessModifier.isAbstract) {
											CompilerStatic.errors.add(new Error(childClass.compiler, childClass.classNameIndex(), childClass.classNameIndex(), 
													childClass.name + " class don't have a method " + func.name + "()" + " of " + parentClass.name + 
													". You must implement the abstract method."));
										}
									}
									else {
										// 인터페이스를 구현하는 메소드가 public이 아닐 경우
										if (((FindClassParams)func.parent).accessModifier.isInterface) {
											//if (funcOfChild2.accessModifier.accessPermission!=AccessPermission.Public || 
											//		funcOfChild2.accessModifier.isStatic) {
											if (funcOfChild2.accessModifier.accessPermission==AccessPermission.Private || 
													funcOfChild2.accessModifier.accessPermission==AccessPermission.Default/* ||
														funcOfChild2.accessModifier.isStatic*/) {
												CompilerStatic.errors.add(new Error(childClass.compiler, funcOfChild2.functionNameIndex(), funcOfChild2.functionNameIndex(), 
														"invalid access modifier : illegal access modifier in interface implementor"));
											}
										}
									}
								}
								if (((FindClassParams)func.parent).accessModifier.isInterface && func.accessModifier.isAbstract) {
									// childClass가 인터페이스를 구현할 경우 childClass가 이미 인터페이스를 구현하는지를 체크하였으므로
									// (반드시 인터페이스의 함수를 가져야 하므로) continue한다.
									// ColorDialog는 OnTouchListener를 구현하고, Dialog를 상속하는데 Dialog는 OnTouchListener를 구현한다.
									// 따라서 OnTouchListener의 함수들을 두번 상속을 하게 되므로 continue한다.
									continue;
								}
								if (func.accessModifier.accessPermission==null) {
									childClass.listOfFunctionParamsInherited.add(func);
								}
								if (func.accessModifier.accessPermission!=null && 
									func.accessModifier.accessPermission!=AccessPermission.Private) {
									childClass.listOfFunctionParamsInherited.add(func);
								}
							}
						}//for (i=0; i<funcs.count; i++) {
					}//for (j=0; j<2; j++) {
					
				}//if (parentClass!=null) {
			}//if (parentClassName!=null && parentClassName.equals("")==false) {
		}//for k
		
		
	}


   
	
	 public void setLanguage(Language lang) {
		 data.language = lang;
	    	if (lang==Language.Java) {
	    		CompilerStatic.loadJavaLangPackage();
	    		//TypesOfDefaultLibrary = TypesOfDefaultLibraryOfJava;  
	    		//Keywords = Compiler_types.KeywordsOfJava;
	    		//AccessModifiers = Compiler_types.AccessModifiersOfJava;
	    		data.Types.InsertNoSpaceError(Compiler_types_Static.TypesOfJava, 0, 0, Compiler_types_Static.TypesOfJava.length);
	    		data.TypesOfDefaultLibrary.InsertNoSpaceError(CompilerStatic.TypesOfDefaultLibraryOfJava, 0, 0, CompilerStatic.TypesOfDefaultLibraryOfJava.count);
	    		data.Keywords.InsertNoSpaceError(Compiler_types_Static.KeywordsOfJava, 0, 0, Compiler_types_Static.KeywordsOfJava.length);
	    		data.AccessModifiers.InsertNoSpaceError(Compiler_types_Static.AccessModifiersOfJava, 0, 0, Compiler_types_Static.AccessModifiersOfJava.length);
	    		
	    	}
	    	else if (lang==Language.CSharp) {
	    		//Types = Compiler_types.TypesOfCSharp;
	    		//Keywords = Compiler_types.KeywordsOfCSharp;
	    		//AccessModifiers = Compiler_types.AccessModifiersOfCSharp;
	    		data.Types.InsertNoSpaceError(Compiler_types_Static.TypesOfCSharp, 0, 0, Compiler_types_Static.TypesOfCSharp.length);
	    		data.Keywords.InsertNoSpaceError(Compiler_types_Static.KeywordsOfCSharp, 0, 0, Compiler_types_Static.KeywordsOfCSharp.length);
	    		data.AccessModifiers.InsertNoSpaceError(Compiler_types_Static.AccessModifiersOfCSharp, 0, 0, Compiler_types_Static.AccessModifiersOfCSharp.length);
	    		
	    	}
	    	else if (lang==Language.C) {
	    		//Types = Compiler_types.TypesOfC;
	    		//Keywords = Compiler_types.KeywordsOfC;
	    		//AccessModifiers = Compiler_types.AccessModifiersOfC;
	    		data.Types.InsertNoSpaceError(Compiler_types_Static.TypesOfC, 0, 0, Compiler_types_Static.TypesOfC.length);
	    		data.Keywords.InsertNoSpaceError(Compiler_types_Static.KeywordsOfC, 0, 0, Compiler_types_Static.KeywordsOfC.length);
	    		data.AccessModifiers.InsertNoSpaceError(Compiler_types_Static.AccessModifiersOfC, 0, 0, Compiler_types_Static.AccessModifiersOfC.length);
	    		
	    	}
	    	else if (lang==Language.Html) {
	    		//Types = null;
	    		//Keywords = Compiler_types.KeywordsOfHtml;
	    		//AccessModifiers = null;
	    		data.Keywords.InsertNoSpaceError(Compiler_types_Static.KeywordsOfHtml, 0, 0, Compiler_types_Static.KeywordsOfHtml.length);
	    	}
	 }
	 
	 
	

		
		
		
		/** ','로 구분되는 함수 호출의 파라미터들을 괄호안에서 찾는다.
		 * @param indexOfStartOfSmallBlock : 함수호출의 시작 '('
		 * @param indexOfEndOfSmallBlock : 함수호출의 마지막 ')'
		 * @param varUse : 함수호출의 varUse
		 * @return ArrayListIReset : FindFuncCallParam[], 
		 *   	파라미터가 없을 경우에는 null이 아닌 count가 0인 것을 리턴*/
		public ArrayListIReset findFuncCallParams(HighArray_CodeString src, 
				int indexOfStartOfSmallBlock, int indexOfEndOfSmallBlock, FindVarUseParams varUse) {
			int i;
			ArrayListIReset result = new ArrayListIReset(5);
			result.resizeInc = 10;
			FindFuncCallParam funcCallParam=null;
			
			// characters[i] = new Character((char)0, size);
			// test(test(compiler, compiler.alpha), ((compiler)).Common_Settings.backColor + (2+5)*3);
			// test( compiler, ((new RectForPage(owner, bounds, (Common_Settings.backColor)+((1)-2)*2, isUpOrDown))).a+(2+1+3)*(1+0) );
			for (i=indexOfStartOfSmallBlock+1; i<indexOfEndOfSmallBlock; i++) {
				CodeString str = src.getItem(i);
				if (i==indexOfStartOfSmallBlock+1) {
					int startIndex = CompilerHelper.SkipBlank(src, false, i, indexOfEndOfSmallBlock);
					funcCallParam = new FindFuncCallParam(compiler, startIndex, -1);
					if (varUse!=null) funcCallParam.funcName = src.getItem(varUse.index()).str;
					int newi = findFuncCallParams_sub2(src, startIndex, indexOfEndOfSmallBlock-1);
					if (newi<i) {
						CompilerStatic.errors.add(new Error(compiler, i, i, "invalid empty expression"));
						return null;
					}
					funcCallParam.endIndex = IndexForHighArray.indexRelative(funcCallParam, src, newi);
					result.add(funcCallParam);
					if (newi==indexOfEndOfSmallBlock-1) break;
					i = newi;
				}
				else if (i>indexOfStartOfSmallBlock+1 && str.equals(",")) {
					int startIndex = CompilerHelper.SkipBlank(src, false, i+1, indexOfEndOfSmallBlock);
					funcCallParam = new FindFuncCallParam(compiler, startIndex, -1);
					if (varUse!=null) funcCallParam.funcName = src.getItem(varUse.index()).str;
					int newi = findFuncCallParams_sub2(src, startIndex, indexOfEndOfSmallBlock-1);
					if (newi<i+1) {
						CompilerStatic.errors.add(new Error(compiler, i+1, i+1, "invalid empty expression"));
						return null;
					}
					funcCallParam.endIndex = IndexForHighArray.indexRelative(funcCallParam, src, newi);
					result.add(funcCallParam);
					i = newi;
				}
				/*if (i==indexOfEndOfSmallBlock-1) {
					funcCallParam.endIndex = IndexForHighArray.indexRelative(funcCallParam, src, i);
					result.add(funcCallParam);
				}*/
			}//for (i=indexOfStartOfSmallBlock+1; i<indexOfEndOfSmallBlock; i++) {
			// 파라미터가 없는데도 불구하고 빈 파라미터 하나가 생길수도 있기때문에 그런 파라미터를 제거한다.
			if (result.count==1) {
				boolean isBlank = true;
				for (i=funcCallParam.startIndex(); i<=funcCallParam.endIndex(); i++) {
					CodeString str = src.getItem(i);
					if (CompilerHelper.IsBlank(str) || CompilerHelper.IsComment(str)) continue;
					else {
						isBlank = false;
						break;
					}
				}
				if (isBlank) result.reset2();
			}
			return result;
			
	    	
		}
		
		
		/** findFuncCallParams의 sub로서 영역안에 함수호출이 있으면 
		 * 함수호출을 건너뛴 인덱스를 리턴한다.*/
		int findFuncCallParams_sub(HighArray_CodeString src, int startIndex, int endIndex) {
			int i;
			int indexOfLeftPair, indexOfRightPair;
			
			for (i=startIndex; i<=endIndex; i++) {
				CodeString str = src.getItem(i);
				if (CompilerHelper.IsComment(str) || CompilerHelper.IsBlank(str)) continue;
				if (CompilerHelper.IsIdentifier(str, compiler)) { // 영역안에 함수호출이 있는지 조사
					indexOfLeftPair = CompilerHelper.SkipBlank(src, false, i, endIndex-1);
					if (indexOfLeftPair!=endIndex) {
						CodeString leftPair = src.getItem(indexOfLeftPair);
						if (leftPair.equals("(")) {
							indexOfRightPair = Checker.CheckParenthesis(compiler,  "(", ")", indexOfLeftPair, endIndex-1, false);
							if (indexOfRightPair!=-1) { // 영역안에 함수호출이 있는 경우
								i = indexOfRightPair;
								return i;	// 함수호출을 스킵한 인덱스, )의 인덱스
							}
							else { // 함수호출은 있으나 )이 없는 경우
								return startIndex;
							}
						}
						else { // 식별자는 있으나 (이 없는 경우
							return startIndex;
						}
					}
					else { // 식별자는 있으나 모두 공백이나 주석인 경우
						return startIndex;
					}
				}	
			}
			return startIndex;
		}
		
		/** findFuncCallParams의 sub로서 startIndex()와 endIndex영역안에 함수호출이나 타입캐스트문 혹은 수식 괄호가 있으면 
		 * 그을 건너뛴 인덱스를 리턴한다.
		 * @param endIndex : 함수호출의 )의 인덱스-1
		 * @return ',''s index-1, or endIndex*/
		int findFuncCallParams_sub2(HighArray_CodeString src, int startIndex, int endIndex) {
			int i;
			for (i=startIndex; i<=endIndex; i++) {
				CodeString str = src.getItem(i);
				if (CompilerHelper.IsComment(str) || CompilerHelper.IsBlank(str) ) continue;
				else if (str.equals("(")) {
					int rightPair;
					rightPair = Checker.CheckParenthesis(compiler,  "(", ")", i, endIndex, false);
					if (rightPair==-1) {
						CompilerStatic.errors.add(new Error(compiler, i, i, ") not exists"));
					}
					else i = rightPair;
					//continue;
				}
				else if (str.equals(",")) {
					return i-1;
				}
			}
			return endIndex;
		}
				
		
		/**startIndex, endIndex 모두 포함*/
		public void findAnnotation(HighArray_CodeString src, int startIndex, int endIndex) {
			int i, j;
			int indexAlpha;
			int startIndexOfAnnotation=-1;
			int endIndexOfAnnotation=-1;
			for (i=startIndex; i<=endIndex; i++) {
				CodeString str = src.getItem(i);
				if (CompilerHelper.IsBlank(str) || CompilerHelper.IsComment(str)) continue;
				else if (str.equals("@")) {
					indexAlpha = i;
					j = CompilerHelper.SkipBlank(src, false, i+1, src.count-1);
					if (j==src.count) return;
					
					str = src.getItem(j);
					if (CompilerHelper.IsIdentifier(str, compiler)) {
						startIndexOfAnnotation = i;
						src.getItem(indexAlpha).setType(CodeStringType.Annotation);
						str.setType(CodeStringType.Annotation);
						j = CompilerHelper.SkipBlank(src, false, j+1, src.count-1);
						if (j==src.count) return;
						
						str = src.getItem(j);					
						if (str.equals("(")) {
							int rightPair = Checker.CheckParenthesis(compiler,  "(", ")", j, src.count-1, false);
							if (rightPair!=-1)	{
								int k;
								for (k=j; k<=rightPair; k++) {
									src.getItem(k).setType(CodeStringType.Annotation);
								}
								i = rightPair;
								endIndexOfAnnotation = rightPair;
							}
							else {
								i = src.count;
								// error
							}
						}
						else {
							i = j-1;
							endIndexOfAnnotation = i;
						}
						data.mlistOfAnnotations.add(new Annotation(compiler, startIndexOfAnnotation, endIndexOfAnnotation));
					}
					else {
						i = j - 1;
					}
					
				}//else if (str.equals("@")) {
				
			}//for (i=0; i<src.count; i++) {
			
		}
		
		
		
		/**start2()와 start_onlyInterface()에서 호출된다.
		 * @param compiler : CompilerHelper의 loadClassFromSrc_onlyInterface()에서 
		 * compiler.start_onlyInterface(...) 이렇게 호출이 되고  start_onlyInterface()에서
		 * RegisterPackageName(...)호출을 하면
		 * RegisterPackageName()내부의 this나 this가 없는 
		 * Compiler클래스의 멤버 사용은 compiler(호출오브젝트)의 멤버사용이므로 없어도 되는 것이다.
		 * start2()에서 호출이 되어도 마찬가지이다.
		 * @param src : compiler.mBuffer와 같다.*/
		public void RegisterPackageName(HighArray_CodeString src) {
			int i;
			int indexOfStartOfPackage = -1;
			int indexOfEndOfPackage = -1;
			for (i=0; i<src.count; i++) {
				CodeString str = src.getItem(i);
				if (CompilerHelper.IsBlank(str) || CompilerHelper.IsComment(str)) {
					continue;
				}
				else if (str.equals("package")) {
					indexOfStartOfPackage = i;
					int path = CompilerHelper.SkipBlank(src, false, i+1, src.count-1);
					int j;				
					if (path==src.count) {
						CompilerStatic.errors.add(new Error(compiler, i,i,"Invalid package"));
						compiler.PairErrorExists = true;
						return;
					}
					String type = "";
					for (j=path; j<src.count; j++) {
						CodeString item = src.getItem(j);
						if (CompilerHelper.IsBlank(item) || CompilerHelper.IsComment(item)) {
							i = j;
							continue;
						}
						else if (item.equals(";")) {
							indexOfEndOfPackage = j-1;
							data.mlistOfPackageStatements.add(new PackageStatement(compiler, indexOfStartOfPackage, indexOfEndOfPackage));
							
							//packageName = type;
							data.packageName = type;
							if (data.packageName.equals("") || data.packageName.charAt(data.packageName.length()-1)=='.') {
								CompilerStatic.errors.add(new Error(compiler, i,j,"Invalid package name"));
								compiler.PairErrorExists = true;
							}						
							i = j;
							// for j 종료
							break;
						}
						
						else if (item.equals(".")) {
							type += item;
							i = j;
						}
						else if (CompilerHelper.IsSeparator(item)) {
							CompilerStatic.errors.add(new Error(compiler, j,j,"Invalid package name, invalid separator. : "+item));
							compiler.PairErrorExists = true;
							i = j;
						}
						else if (CompilerHelper.IsIdentifier(item, compiler)){
							type += item;
							int nextIndex = CompilerHelper.SkipBlank(src, false, j+1, src.count-1);
							CodeString next = src.getItem(nextIndex);
							// id 다음에는 .이나 ;이 와야 한다.
							if ( !(next.equals(".") || next.equals(";")) ) {
								CompilerStatic.errors.add(new Error(compiler, nextIndex,nextIndex,"Invalid import, invalid token. : "+next));
								compiler.PairErrorExists = true;
								i = nextIndex;
								break;
							}
							i = j;
						}
						else { // 키워드 등등
							CompilerStatic.errors.add(new Error(compiler, j,j,"Invalid package name, invalid token : "+item));
							compiler.PairErrorExists = true;
							i = j;
							break;
						}
					} //for (j=path; j<src.count; j++) {
					//i = j - 1;
					//i = j;
				} //if (str.equals("package")) {
				else if (str.equals("import") || IsAccessModifier(str) || str.equals("class")) {
					if (data.packageName==null || data.packageName.equals("")) {
						CompilerStatic.errors.add(new Error(compiler, i,i,"Invalid package, ';' not exists."));
						compiler.PairErrorExists = true;
					}
					break;
				}
				else {
					CompilerStatic.errors.add(new Error(compiler, i,i,"Invalid package, invalid token : "+str));
					compiler.PairErrorExists = true;
				}
				
			}// for i
		}
		
		
		
		/**import문에서 들어오는 class들을 mlistOfImportedClasses에 추가한다.
		 * start2()와 start_onlyInterface()에서 호출된다.
		 * @param compiler : CompilerHelper의 loadClassFromSrc_onlyInterface()에서 
		 * compiler.start_onlyInterface(...) 이렇게 호출이 되고  start_onlyInterface()에서
		 * RegisterImportedClasses(...)호출을 하면
		 * RegisterImportedClasses()내부의 this나 this가 없는 
		 * Compiler클래스의 멤버 사용은 compiler(호출오브젝트)의 멤버사용이므로 없어도 되는 것이다.
		 * start2()에서 호출이 되어도 마찬가지이다.
		 * @param src : compiler.mBuffer와 같다.*/
		public void RegisterImportedClasses(HighArray_CodeString src) {
			int i;
			data.mlistOfImportedClasses.destroy();
			String importName = null;
			int indexOfStartOfImport = -1;
			int indexOfEndOfImport = -1;
			
			for (i=0; i<src.count; i++) {
				CodeString str = src.getItem(i);
				if (CompilerHelper.IsBlank(str) || CompilerHelper.IsComment(str)) continue;
				else if (str.equals("package")) {
					int semicolonIndex = CompilerHelper.Skip(src, false, ";", i, src.count-1);
					if (semicolonIndex==src.count) {
						
					}
					i = semicolonIndex;
				}
				else if (str.equals("import")) {
					indexOfStartOfImport = i;
					int path = CompilerHelper.SkipBlank(src, false, i+1, src.count-1);
					int j;				
					if (path==src.count) {
						/*try {
							throw new Exception("Invalid import");
						} catch (Exception e) {
						}*/
						CompilerStatic.errors.add(new Error(compiler, i,i,"Invalid import"));
						compiler.PairErrorExists = true;
						return;
					}
					importName = "";
					for (j=path; j<src.count; j++) {
						CodeString item = src.getItem(j);
						if (CompilerHelper.IsBlank(item) || CompilerHelper.IsComment(item)) {
							i = j;
							continue;
						}
						else if (item.equals(";")) {
							// importName이 빈스트링이거나 .으로 끝나는 경우는 잘못된 것이다.
							if (importName.equals("") || importName.charAt(importName.length()-1)=='.') {
								CompilerStatic.errors.add(new Error(compiler, j-1,j-1,"Invalid import"));
								compiler.PairErrorExists = true;
								i = j;
								break;
							}
							indexOfEndOfImport = j-1;
							data.mlistOfImportStatements.add(new ImportStatement(compiler, indexOfStartOfImport, indexOfEndOfImport));
							data.mlistOfImportedClasses.add(importName);
							i = j;
							break; // for j 종료
						}
						
						else if (item.equals(".")) {
							importName += item;
							i = j;
						}
						else if (item.equals("*")) {
							int nextIndex = CompilerHelper.SkipBlank(src, false, j+1, src.count-1);
							CodeString next = src.getItem(nextIndex);
							// *는 임포트문의 마지막이어야 한다.
							if (!(next.equals(";"))) {
								CompilerStatic.errors.add(new Error(compiler, nextIndex,nextIndex,"Invalid import, invalid star. : "+item));
								compiler.PairErrorExists = true;
								i = nextIndex; //세미콜론 다음부터
								break;
							}
							
							String importNameExceptStar;
							if (importName.charAt(importName.length()-1)=='.') {
								importNameExceptStar = importName.substring(0, importName.length()-1);
							}
							else {
								importNameExceptStar = importName.substring(0, importName.length());
							}
							
							indexOfEndOfImport = nextIndex-1;
							data.mlistOfImportStatements.add(new ImportStatement(compiler, indexOfStartOfImport, indexOfEndOfImport));
							
							data.mlistOfImportedClassesStar.add(importNameExceptStar);
							i = nextIndex; //세미콜론 다음부터
							break;
						}
						else if (CompilerHelper.IsSeparator(item)) {
							CompilerStatic.errors.add(new Error(compiler, j,j,"Invalid import, invalid separator. : "+item));
							compiler.PairErrorExists = true;
							i = j;
							break;
						}
						
						else if (CompilerHelper.IsIdentifier(item, compiler)) {
							int nextIndex = CompilerHelper.SkipBlank(src, false, j+1, src.count-1);
							CodeString next = src.getItem(nextIndex);
							// id 다음에는 .이나 ;이 와야 한다.
							if (!(next.equals(".") || next.equals(";") || next.equals("*"))) {
								CompilerStatic.errors.add(new Error(compiler, nextIndex,nextIndex,"Invalid import, invalid token. : "+next));
								compiler.PairErrorExists = true;
								i = nextIndex;
								break;
							}
							importName += item;
							i = j;
						}
						else { // 키워드 등등
							CompilerStatic.errors.add(new Error(compiler, i,i,"Invalid import, invalid token : "+item));
							compiler.PairErrorExists = true;
							i = j;
							break;
						}
					} //for (j=path; j<src.count; j++) {
					//i = j - 1;
					//i = j;
				} //if (str.equals("import")) {	
				else if (str.equals("class") || IsAccessModifier(str)) {
					if (importName==null || importName.equals("")) {
						//CompilerStatic.errors.add(new Error(compiler, i,i,"Invalid package, ';' not exists."));
					}
					// for i 종료
					break;
				}
				else {
					CompilerStatic.errors.add(new Error(compiler, i,i,"Invalid import, invalid token : "+str));
					compiler.PairErrorExists = true;
				}
				
			}//for (i=0; i<src.count; i++) {
		}
		
		
		
		
		/*public FindClassParams getTypeOfMemberInParentClass(FindVarParams varDecl) {
			String name = varDecl.fieldName;
			FindClassParams parentClass = (FindClassParams) varDecl.parent;
			Compiler compiler = parentClass.compiler;
			Fullname.getFullNameType(compiler, varDecl.typeStartIndex(), varDecl.endIndex)
		}*/
		
		
		
		
		
	    
		
		


	    /**start2()와 start_onlyInterface()에서 호출된다.
	     * @param coreThreadID 
		 * @param compiler : CompilerHelper의 loadClassFromSrc_onlyInterface()에서 
		 * compiler.start_onlyInterface(...) 이렇게 호출이 되고  start_onlyInterface()에서
		 * loadImportStar(...)호출을 하면
		 * loadImportStar()내부의 this나 this가 없는 
		 * Compiler클래스의 멤버 사용은 compiler(호출오브젝트)의 멤버사용이므로 없어도 되는 것이다.
		 * start2()에서 호출이 되어도 마찬가지이다.
		 * @param src : compiler.mBuffer와 같다.*/
	    public void loadImportStar(int coreThreadID) {
	    	//if (TypesOfImportStarOfJava!=null) return;
	    	
	    	//String pathAndroid = Control.pathAndroid.replace('.', File.separatorChar);
	    	int i, j;
	    	for (i=0; i<data.mlistOfImportedClassesStar.count; i++) {
	    		data.TypesOfImportStarOfJava.add( new ArrayListString(20) );
	    		
	    		ArrayListString listNew = (ArrayListString) data.TypesOfImportStarOfJava.list[i]; 
	    		
	    		String origianlImport = data.mlistOfImportedClassesStar.getItem(i) + "." + "*";
	    		
	    		String dir = data.mlistOfImportedClassesStar.getItem(i);
	    		dir = dir.replace('.', File.separatorChar);
	    		
	    		String path; 
	    		
	    		int[] modeArr = null;
	    		if (Common_Settings.g_loadsImportStarInSource) {
	    			modeArr = new int[3];
	    			modeArr[0] = 2; modeArr[1] = 0; modeArr[2] = 3;
	    		}
	    		else {
	    			modeArr = new int[2];
	    			modeArr[0] = 0; modeArr[1] = 3;
	    			File file = CompilerStatic.getAbsPath_FromVariousClassPath(2, dir);
	    			if (file!=null) {
	    				CompilerStatic.errors.add(new Error(compiler, 0, 0, 
	    					"invalid import statement : can't load * in a source. Import each class in a source file. "+origianlImport));
	    			}
	    		}
	    		for (int mode=0; mode<modeArr.length; mode++) {
	    			File file = CompilerStatic.getAbsPath_FromVariousClassPath(modeArr[mode], dir);
	    			if (file==null) continue;
	    			path = file.getAbsolutePath();
	    			
	    			File fileDir = file;
	    			
					if (fileDir.isDirectory()) {
						// import com.gsoft.common.*;에서 dir = com/gsoft/common 이 된다.
						// 이런 경우 소스 패스에서든 클래스 패스에서든 상관이 없다.
			    		File starFile = fileDir;
			    		String[] list = starFile.list();
			    		if (list==null) return;
			    		
			    		for (j=0; j<list.length; j++) {
			    			int indexDollar = list[j].indexOf("$");
			    			// '$'를 포함하지않으면, 즉 내부클래스는 제외
			    			if (indexDollar==-1) {
			    				int indexDot = list[j].indexOf(".");
			    				// 확장자는 제외한다. 따라서 HashTable.class일 경우 HashTable만 listNew에 들어간다.
			    				if (indexDot!=-1) {
			    					String str = list[j].substring(0, indexDot);
			    					listNew.add(str);
			    				}
			    			}
			    		} // for j
					}
					else {
						// fileDir이 파일이면
						if (modeArr[mode]==2) {
							// import com.gsoft.common.compiler.Compiler_types.*;에서 
							// fullname은 com.gsoft.common.compiler.Compiler_types이고 shortName은 CLanguage이다.
							// fullname에서 CLanguage클래스를 찾는다.
							String fullName = data.mlistOfImportedClassesStar.getItem(i);
							Compiler compiler = Loader.loadClassFromSrc_onlyInterfaceForCompiler(fullName, coreThreadID);
							if (compiler==null) continue;
							for (j=0; j<compiler.data.mlistOfAllDefinedClasses.count; j++) {
								FindClassParams child = (FindClassParams) compiler.data.mlistOfAllDefinedClasses.getItem(j);
								if (child.name.contains(fullName) && child.name.length()>fullName.length()) {
									String shortName = CompilerStatic.getShortName(child.name);
									// fullName의 바로 아래 자식 클래스들만 포함한다.
									if (child.name.length()==fullName.length()+1+shortName.length()) {
										listNew.add(shortName);
									}
								}
							}
						}// if (modeArr[mode]==2) {
						else {
							// 소스 패스에서가 아니라 클래스 패스에서
							String shortName = CompilerHelper.getShortName(data.mlistOfImportedClassesStar.getItem(i));
							String dirPath = Loader.getDirectory(path);
							File starFile = new File(dirPath);
							
							String[] list = starFile.list();
				    		if (list==null) return;
				    		
				    		for (j=0; j<list.length; j++) {
				    			String childName = list[j];
				    			int indexDollar = list[j].indexOf("$");				    			
				    			if (childName.contains(shortName) && childName.length()>shortName.length()) {
				    				// childName에서 확장자를 제외한 파일이름을 얻는다.
									String shortNameOfChild = FileHelper.getFilenameExceptExt(FileHelper.getFilename(childName));
									// shortName의 바로 아래 자식 클래스들만 포함한다. 1은 $을 의미한다.
									if (childName.length()==shortName.length()+1+shortNameOfChild.length()) {
										listNew.add(shortNameOfChild);
									}
								}
				    		} // for j
							
						}//if (mode!=2) {
					}// fileDir이 파일이면
	    		} // for mode
				
				
	    	} // for i
	    }





		public void destroy() {
			
			if (this.core!=null) {
				this.core.destroy();
				this.core = null;
			}
		}



}
