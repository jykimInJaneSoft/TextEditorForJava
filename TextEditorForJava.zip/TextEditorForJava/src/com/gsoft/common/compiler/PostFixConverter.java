package com.gsoft.common.compiler;

import android.graphics.Color;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.CommonGUI;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.interfaces.IReset;
import com.gsoft.common.compiler.Compiler_types.FindExpressionParams;
import com.gsoft.common.compiler.Compiler_types.FindVarUseParams;
import com.gsoft.common.compiler.Compiler_types.Language;
import com.gsoft.common.compiler.Compiler_types_Base.GetVarUseWithIndexReturnType;
import com.gsoft.common.compiler.Compiler_types_Base.Error;
import com.gsoft.common.compiler.TemplateBase.Template;
import com.gsoft.common.util.ArrayListCodeString;
import com.gsoft.common.util.ArrayListIReset;
import com.gsoft.common.util.ArrayListInt;
import com.gsoft.common.util.Stack;

import com.gsoft.common.compiler.TypeCast_Syntax;
import com.gsoft.common.compiler.CodeStringEx;
import com.gsoft.common.compiler.HighArray_CodeString;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.Checker;
import com.gsoft.common.compiler.Fullname;
import com.gsoft.common.compiler.StringTokenizer;
import com.gsoft.common.compiler.TemplateBase;
import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.Number;
import com.gsoft.common.compiler.CompilerStatic;


public class PostFixConverter {
	
		
	//String[] input;
	CodeStringEx[] mBuffer;
	CodeStringEx[] output;
	
	HighArray_CodeString srcOld;
	FindExpressionParams expressionOld;
	ArrayListIReset listOfVarUsesOld;
	
	/** 실제 원소 타입은 CodeStringEx이다. constructor참조*/
	HighArray_CodeString src;
	FindExpressionParams expression;
	ArrayListIReset listOfVarUses;
	
	static final int EOB = -1;
	
	/** "!", "~", "+", "-"*/
	String[] operatorsForOne = {"!", "~", "+", "-"};
		
	/** "*", "/", "%"*/
	String[] operatorsMultipliers = {"*", "/", "%"};
	
	/** "+", "-"*/
	String[] operatorsAdders = {"+", "-"};
	
	/** "<<", ">>", "<<<", ">>>"*/
	String[] operatorsShifters = {"<<", ">>", "<<<", ">>>"};
	
	/** "<", ">", "<=", ">="*/
	String[] operatorsRelations = {"<", ">", "<=", ">="};
	
	/** "==", "!="*/
	String[] operatorsEquals = {"==", "!="};
	
	/** instanceof */
	String[] operatorsInstanceof = {"instanceof"};
	
	/** "&", "|", "~"*/
	String[] operatorsBitLogical = {"&", "|", "~", "^"};
	
	/** "&&", "!"*/
	String[] operatorsLogical1 = {"&&", "!"};
	/** "||"*/
	String[] operatorsLogical2 = {"||"};
	
	/** "?", 삼항연산자 ? : 의 "?"을 말한다. */
	String[] operatorsQuestion = {"?"};
	
	/** ":", 삼항연산자 ? : 의 ":"을 말한다. */
	String[] operatorsChoose = {":"};
	
	/** "=", "+=", "-=", "*=", "/=", "%=", "|=", "&=" */
	String[] operatorsAllocater = {"=", "+=", "-=", "*=", "/=", "%=", "~=", "|=", "&=", "^="};
	
	
	ArrayListIReset listOfBlocks = new ArrayListIReset(0);
	ArrayListIReset listOfSmallBlocks = new ArrayListIReset(2);
	ArrayListIReset listOfLargeBlocks = new ArrayListIReset(0);
	private Compiler compiler;
	
	/** 주석, 공백 등이 제거된다.*/
	public PostFixConverter(Compiler compiler, HighArray_CodeString src, FindExpressionParams expression)
	{
		this.compiler = compiler;
		//this.input = input;
		output = null;
				
		
		this.src = src;
		int i;
		this.src = new HighArray_CodeString(expression.endIndex()-expression.startIndex()+1);
		int startIndex = 0;
		ArrayListIReset listOfVarUses = null;
		if (629<=expression.startIndex() && expression.startIndex()<=637) {
		}
		for (i=expression.startIndex(); i<=expression.endIndex(); i++) {
			CodeString strSrc = src.getItem(i);
			if (strSrc.equals("new")) continue;
			
			if (CompilerHelper.IsBlank(strSrc) || CompilerHelper.IsComment(strSrc)) continue;
			
			ArrayListInt indicesInSrc = new ArrayListInt(1);
			indicesInSrc.add(i);
			
			listOfVarUses = new ArrayListIReset(1);
			GetVarUseWithIndexReturnType r = 
				CompilerStatic.getVarUseWithIndex(compiler.data.mlistOfAllVarUses, startIndex, i);			
			if (r!=null) {
				listOfVarUses.add(r.r);
				startIndex = r.indexInlistOfAllVarUses+1;
			}
			else listOfVarUses.add(null);
			CodeStringEx str = new CodeStringEx(strSrc.str, Color.BLACK, indicesInSrc, listOfVarUses);
			str.setType(strSrc.charAt(0).type);
			this.src.add(str);
		}
		
		this.expression = expression;
		this.listOfVarUses = listOfVarUses;
		//mBuffer = input;
		
		
		//Compiler.CheckParenthesisAll(this.src, listOfBlocks, listOfSmallBlocks, listOfLargeBlocks);
	}
	
	static class IndexStartEnd implements IReset {
		int startIndex;
		int endIndex;
		IndexStartEnd(int startIndex, int endIndex) {
			this.startIndex = startIndex;
			this.endIndex = endIndex;
		}
		@Override
		public void destroy() {
			
			
		}
	}
	
	/** startIndex, endIndex는 fullname 인덱스의 시작과 끝 인덱스이고 이 영역밖으로 가짜 괄호들의 인덱스들을 리턴한다.*/
	ArrayListIReset getFakeParenthesis(HighArray_CodeString src, int startIndex, int endIndex) {
		int i;
		ArrayListIReset r = new ArrayListIReset(5);
		for (i=startIndex-1; i>=0; i--) {
			CodeStringEx str = (CodeStringEx) src.getItem(i);
			int inc = startIndex - i;
			if (str.equals("(")) {
				CodeStringEx rightPair = (CodeStringEx) src.getItem(endIndex+inc);
				try {
				if (rightPair.equals(")")) { // fake Parenthesis
					r.add(new IndexStartEnd(i,endIndex+inc));
				}
				else {
					break;
				}
				}catch(Exception e) {
				}
			}
			else {
				break;
			}
		}
		return r;
	}
	
	boolean isTypeCast(CodeStringEx str) {
		ArrayListIReset listOfTypeCasts = compiler.data.mlistOfAllTypeCasts;
		int i;
		int indexOfOriginalSrc = str.indicesInSrc.getItem(0);
		if (indexOfOriginalSrc==2234) {
		}
		for (i=0; i<listOfTypeCasts.count; i++) {
			TypeCast_Syntax typeCast = (TypeCast_Syntax) listOfTypeCasts.getItem(i);
			if (typeCast.startIndex()<=indexOfOriginalSrc && indexOfOriginalSrc<=typeCast.endIndex())
				return true;
		}
		return false;
		
	}
	
	/** 함수호출, 네임스페이스(멤버연산자를 이용한 멤버접근), 변수, 상수 등 토큰 하나에 붙어있는 괄호를 제거한다.
	 * 예를들어 (a.b.c())+3, (a)+2, (a)[0]+2, (a[0])+2 등에 있는 괄호를 제거한다.*/
	void removeFakeParenthesis(HighArray_CodeString src, HighArray_CodeString result) {		
		int i;
		
		// 원래 소스코드상의 Fullname의 시작과 끝 인덱스를 말한다.
		ArrayListIReset indicesOfParenthesis = new ArrayListIReset(10);
				
		for (i=0; i<src.count; i++) {
			CodeStringEx str = (CodeStringEx) src.getItem(i);
			if (str.equals("HighArray")) {
			}
			
			if (CompilerHelper.IsIdentifier(str, compiler) || Number.IsNumber2(str)!=0) {
				if (isTypeCast(str)) continue;
				
				int indexTemp = CompilerHelper.SkipBlank(src, false, i, src.count-1);
				//int fullNameIndex = Fullname.getFullNameIndex(compiler, src, false, indexTemp, false);
				int fullNameIndex = Fullname.getFullNameIndex_includingType_postfix(compiler, src, false, indexTemp);
				if (fullNameIndex==src.count) fullNameIndex = src.count-1;
				fullNameIndex = CompilerHelper.SkipBlank(src, true, 0, fullNameIndex);
				ArrayListIReset r = getFakeParenthesis(src, i, fullNameIndex);
				for (int j=0; j<r.count; j++) {
					indicesOfParenthesis.add(r.getItem(j));
				}
				if (r.count>0) {
					IndexStartEnd last = (IndexStartEnd) r.getItem(r.count-1);
					i = last.endIndex; // 마지막 가짜 괄호의 인덱스
				}
				else {
					i = fullNameIndex;
				}
			}
		}
		
		for (i=0; i<src.count; i++) {
			CodeStringEx str = (CodeStringEx) src.getItem(i);
			if (str.equals("(")) {
				boolean b = exists(indicesOfParenthesis, i, true);
				if (!b) {
					result.add(str);
				}
			}
			else if (str.equals(")")) {
				boolean b = exists(indicesOfParenthesis, i, false);
				if (!b) {
					result.add(str);
				}
			}
			else {
				result.add(str);
			}
		}
	}
	
	boolean exists(ArrayListIReset indices, int targetIndex, boolean leftOrRight) {
		if (leftOrRight) {
			int i;
			for (i=0; i<indices.count; i++) {
				IndexStartEnd index = (IndexStartEnd) indices.getItem(i);
				if (index.startIndex==targetIndex) return true;
			}
		}
		else {
			int i;
			for (i=0; i<indices.count; i++) {
				IndexStartEnd index = (IndexStartEnd) indices.getItem(i);
				if (index.endIndex==targetIndex) return true;
			}	
		}
		return false;
	}
	
		
	/** 풀네임이 하나의 스트링으로 변환된 새로운 스트링 배열을 만든다. 
	 * i++, i--와 같은 경우와 복합연산자(<=, >=, ==, !=)들도 여기서 하나의 스트링으로 합쳐진다.*/
	void ProcessFullnames2(HighArray_CodeString src, HighArray_CodeString result) {
		int i;
		
		// 원래 소스코드상의 Fullname의 시작과 끝 인덱스를 말한다.
		ArrayListIReset indicesOfFullnames = new ArrayListIReset(10);
		
		int startIndex=-1, endIndex=-1;
		boolean isTemplateLeftPairOrOperator = true;
		// 변수사용이나 함수호출의 풀네임의 인덱스를 만든다.
		for (i=0; i<src.count; i++) {
			CodeStringEx str = (CodeStringEx) src.getItem(i);
			if (i==2) {
			}
			if (i==0) {
				startIndex = i;
				//i++;
			}
			
			
			if ( (str.equals("+") && (i+1<src.count && ((CodeStringEx)src.getItem(i+1)).equals("+"))) || 
					(str.equals("-") && (i+1<src.count && ((CodeStringEx)src.getItem(i+1)).equals("-"))) ) {
				int indexId = CompilerHelper.SkipBlank(src, false, i+2, src.count-1);
				
				if (indexId<=src.count-1 && CompilerHelper.IsIdentifier(src.getItem(indexId), compiler)) { // ++i, --i
					if (indexId+1>=src.count ||
							(indexId+1<src.count && (!src.getItem(indexId+1).equals("[") && !src.getItem(indexId+1).equals("(")))) {
						// endIndex는 id의 인덱스
						endIndex = indexId;
						if (startIndex<=endIndex) {
							indicesOfFullnames.add(new IndexStartEnd(startIndex, endIndex));
						}						
						// startIndex는 id의 인덱스+1
						startIndex = endIndex+1;
						// i는 id의 인덱스
						i = startIndex-1;	
					}
					else {
						if (indexId+1<src.count && src.getItem(indexId+1).equals("[")) {
							int rightPair = Checker.CheckParenthesis_postfix(compiler, src, "[", "]", indexId+1, src.count-1, false);
							if (rightPair!=-1) {					
								i = rightPair;
							}
							// a = ++a[b[++k]]; 에서 id가 배열참조 a일 경우
							endIndex = rightPair;
							if (startIndex<=endIndex) {
								indicesOfFullnames.add(new IndexStartEnd(startIndex, endIndex));
							}
							startIndex = endIndex+1;
							i = startIndex-1;
						}
					}
				}//if (indexId<=src.count-1 && compiler.IsIdentifier(src.getItem(indexId))) { // ++i, --i
				else {
					// i는 첫번째 +의 인덱스
					indexId = CompilerHelper.SkipBlank(src, true, 0, i-1);
					if (indexId==-1) {
						return;
					}
					if (CompilerHelper.IsIdentifier(src.getItem(indexId), compiler)) { // i++, i--
						// endIndex는 i++의 두번째 +의 인덱스
						endIndex = i+1;
						if (startIndex<=endIndex)
							indicesOfFullnames.add(new IndexStartEnd(startIndex, endIndex));
						
						// startIndex는 i++의 다음 인덱스
						startIndex = endIndex+1;
						// i는 i++의 두번째 +의 인덱스
						i = startIndex-1;
						
					}
					else if (src.getItem(indexId).equals("]")) {// a[k++]++
						int leftPair = Checker.CheckParenthesis_postfix(compiler, src, "[", "]", 0, indexId, true);
						if (leftPair==-1) {
							return;
						}
						int idIndex = CompilerHelper.SkipBlank(src, true, 0, leftPair-1);
						if (idIndex==-1) {
							return;
						}
						if (CompilerHelper.IsIdentifier(src.getItem(idIndex), compiler)) {
							// i는 첫번째 +의 인덱스
							endIndex = i+1;
							if (startIndex<=endIndex)
								indicesOfFullnames.add(new IndexStartEnd(startIndex, endIndex));
							
							// startIndex는 a[k++]++의 다음 인덱스
							startIndex = endIndex+1;
							// i는 a[k++]++의 두번째 +의 인덱스
							i = startIndex-1;
						}
						
					}//else if (src.getItem(indexId).equals("]")) {// a[k++]++
					else { // -1.0f + +(2.0f) 에서 첫번째 +인 경우
						indicesOfFullnames.add(new IndexStartEnd(i, i)); // 연산자 넣기				
						startIndex = i+1;
					}
				}
			}
			
			else if (str.equals("<") && isTemplateLeftPairOrOperator) {
				Template t = null;
				int rightPairIndex = Checker.CheckParenthesis_postfix(compiler, src, "<", ">", i, src.count-1, false);
				if (rightPairIndex!=-1) {
					t = TemplateBase.isTemplate(compiler,  rightPairIndex);
					if (t!=null) {
						i = rightPairIndex;						
						continue;
					}
				}
				if (t==null) {
					isTemplateLeftPairOrOperator = false;
					i--;
					continue;
					
				}
				
			}
			else if (str.equals("(")) { // 건너뛰기, ((new RectForPage(owner, bounds, backColor, isUpOrDown))).a
				boolean isFuncCall = false;
				int leftPair = i;
				int indexID = CompilerHelper.SkipBlank(src, true, 0, leftPair-1);
				// 템플릿인지를 확인해야 한다. stack = new Stack<Block>();
				if (indexID!=-1 && src.getItem(indexID).equals(">")) {
					Template t = TemplateBase.isTemplate(compiler,  indexID);
					try {
					int leftPairIndexTemplate = t.indexLeftPair();
					if (t!=null) {
						leftPair = leftPairIndexTemplate;
					}
					}catch(Exception e) {
						if (Common_Settings.g_printsLog) e.printStackTrace();
					}
				}
				
				// 템플릿 함수이든 일반함수이든
				indexID = CompilerHelper.SkipBlank(src, true, 0, leftPair-1);
				if (indexID!=-1 && CompilerHelper.IsIdentifier(src.getItem(indexID), compiler)) { 
					// 함수호출, f(a, b).c + 2
					isFuncCall = true;
				}
				
				// ((new RectForPage(owner, bounds, backColor, isUpOrDown))).a
				int rightPair = Checker.CheckParenthesis_postfix(compiler, src, "(", ")", leftPair, src.count-1, false);
				if (rightPair==-1) i = src.count; // error, ) not exist
				else {
					if (isFuncCall) {
						i = rightPair;
						//continue;
					}
					else {
						boolean mustMerge = false;
						int dotIndex = CompilerHelper.SkipBlank(src, false, rightPair+1, src.count-1);
						if (dotIndex!=src.count && src.getItem(dotIndex).equals(".")) { // 건너뛰기
							// ((new RectForPage(owner, bounds, backColor, isUpOrDown))).a
							mustMerge = true;
							i = rightPair;
							continue;
						}
						
						// 타입캐스트문이나 일반수식의 괄호, 단 fake 괄호는 제거된 상태이다.
						if (!mustMerge) { // ( 만 독립적으로 넣는다. 건너뛰지 않는다.
							// 기존 토큰을 넣는다.
							endIndex = i-1;
							if (endIndex>=0 && startIndex<=endIndex)
								indicesOfFullnames.add(new IndexStartEnd(startIndex, endIndex));
							// (을 넣는다.
							startIndex = i;
							endIndex = i;
							if (startIndex<=endIndex)
								indicesOfFullnames.add(new IndexStartEnd(startIndex, endIndex));
							
							startIndex = endIndex+1;
							i = startIndex-1;
							//continue;
						}
						
						// 타입캐스트문이나 일반수식의 괄호, fake 괄호는 제거된 상태이다.
					
						
					}//else if (isFuncCall) {
				}
			}//else if (str.equals("(")) {
			else if (str.equals("[")) {
				int rightPair = Checker.CheckParenthesis_postfix(compiler, src, "[", "]", i, src.count-1, false);
				if (rightPair!=-1) {					
					i = rightPair;
				}
				else { // error, ] not exist
					break;
				}
			}
			else if (str.equals(")") || str.equals("]")) { 
				// ((new RectForPage(owner, bounds, backColor, isUpOrDown))).a+(2+1+3)*(1+0)
				endIndex = i-1;
				if (startIndex<=endIndex)
					indicesOfFullnames.add(new IndexStartEnd(startIndex, endIndex));  // 예제에서 3넣기
				
				indicesOfFullnames.add(new IndexStartEnd(i, i)); // 괄호 넣기
				
				startIndex = i+1;
				//i++;
			}
			
			else if (CompilerHelper.IsOperator(str)) // 이항연산자
			{  // a + b 에서 a 까지, ((new RectForPage(owner, bounds, backColor, isUpOrDown))).a+(2+1+3)*(1+0)
				if (str.equals("<")) {
					isTemplateLeftPairOrOperator = true; // 다시 초기화
				}
				// 기존 토큰을 넣는다.
				endIndex = i-1;
				if (endIndex>=0 && startIndex<=endIndex)
					indicesOfFullnames.add(new IndexStartEnd(startIndex, endIndex));
				
				CodeStringEx next = null;
				if (i+1<src.count) next = (CodeStringEx) src.getItem(i+1);
				if (next!=null && CompilerHelper.IsOperator(next)) { // 복합연산자
					CodeStringEx nextOfNext = null;
					if (i+2<src.count) nextOfNext = (CodeStringEx) src.getItem(i+2);
					
					String operator3 = str + next.str + nextOfNext.str;
					//if (nextOfNext!=null && CompilerHelper.IsOperator(nextOfNext)) { // <<<, >>> 등 연산자가 3개인 경우
					if (operator3.equals("<<<") || operator3.equals(">>>")) {
						// <<<, >>> 인 경우
						if (CompilerHelper.IsCompositiveOperator(str, next, nextOfNext)) {
							indicesOfFullnames.add(new IndexStartEnd(i, i+2)); // 연산자 넣기					
							startIndex = i+3;
							i += 2;
						}
						else {
							// if (true && !false)에서 nextOfNext가 !인 경우
							if (CompilerHelper.IsCompositiveOperator(str, next)) {
								indicesOfFullnames.add(new IndexStartEnd(i, i+1)); // 연산자 넣기					
								startIndex = i+2;
								i++;
							}
							// 연산자가 세개가 연속으로 나오면서 그밖의 경우
							else {
								indicesOfFullnames.add(new IndexStartEnd(i, i)); // 연산자 넣기				
								startIndex = i+1;
							}
						}						
					}//연산자가 3개인 경우
					else { 
						// <=, >=, >>, <<등 연산자가 2개인 경우
						if (CompilerHelper.IsCompositiveOperator(str, next)) {
							indicesOfFullnames.add(new IndexStartEnd(i, i+1)); // 연산자 넣기					
							startIndex = i+2;
							i++;
						}
						//-1.0f + -(2.0f), -1.0f - -(2.0f) 이와 같은경우
						// if (1 & ~2)에서 next 가 ~인 경우
						else {
							indicesOfFullnames.add(new IndexStartEnd(i, i)); // 연산자 넣기				
							startIndex = i+1;
						}
					}
				}//if (next!=null && CompilerHelper.IsOperator(next)) {
				else {		// 연산자가 1개인 경우		
					indicesOfFullnames.add(new IndexStartEnd(i, i)); // 연산자 넣기				
					startIndex = i+1;
				}
				//i++;
			}//else if (CompilerHelper.IsOperator(str))
			else { // '.' 포함 기타 토큰
				//i++;
			}
			
			if (i==src.count-1) {
				endIndex = i;
				if (startIndex<=endIndex)
					indicesOfFullnames.add(new IndexStartEnd(startIndex, endIndex));
				//i++;
			}
			
			
		} // for i
		
		if (src.count>0 && src.getItem(0).equals("\"abc\"")) {
		}
		
		
		// 풀네임이 하나의 스트링으로 변환된 새로운 스트링 배열을 만든다.
		if (indicesOfFullnames.count==1) {
			IndexStartEnd index = (IndexStartEnd)indicesOfFullnames.getItem(0); 
			for (i=0; i<index.startIndex; i++) {
				result.add(src.getItem(i));
			} // for i
			
			ArrayListInt indicesInSrc = ((CodeStringEx)src.getItem(index.startIndex)).indicesInSrc;
			ArrayListIReset listOfVarUses = ((CodeStringEx)src.getItem(index.startIndex)).listOfVarUses;
			CodeStringEx fullname = new CodeStringEx(src.getItem(index.startIndex).str, Color.BLACK, indicesInSrc, listOfVarUses);
			fullname.setType(src.getItem(index.startIndex).charAt(0).type);
			
			for (i=index.startIndex+1; i<=index.endIndex; i++) {
				// str과 인덱스는 일대일 대응한다.
				CodeStringEx str = (CodeStringEx) src.getItem(i);
				fullname = (CodeStringEx) fullname.concate(str, str.indicesInSrc.getItem(0), 
						(FindVarUseParams)str.listOfVarUses.getItem(0));
			} // for i
			result.add(fullname);
			
			for (i=index.endIndex+1; i<=src.count-1; i++) {
				result.add(src.getItem(i));
			} // for i
		}
		else if (indicesOfFullnames.count>1) {
			int j;
			
			// 수식의 처음부터 첫번째 인덱스까지
			IndexStartEnd index = (IndexStartEnd)indicesOfFullnames.getItem(0); 
			for (i=0; i<index.startIndex; i++) {
				result.add(src.getItem(i));
			} // for i
			
			// 인덱스를 하나의 스트링으로 만들고 인덱스의 끝부터 다음 인덱스의 처음까지
			for (j=0; j<indicesOfFullnames.count; j++) {
				IndexStartEnd curIndex = (IndexStartEnd)indicesOfFullnames.getItem(j);
				
				ArrayListInt indicesInSrc = ((CodeStringEx)src.getItem(curIndex.startIndex)).indicesInSrc;
				ArrayListIReset listOfVarUses = ((CodeStringEx)src.getItem(curIndex.startIndex)).listOfVarUses;
				CodeStringEx fullname = new CodeStringEx(src.getItem(curIndex.startIndex).str, Color.BLACK, indicesInSrc, listOfVarUses);
				fullname.setType(src.getItem(curIndex.startIndex).charAt(0).type);
				
				for (i=curIndex.startIndex+1; i<=curIndex.endIndex; i++) {
					CodeStringEx str = (CodeStringEx) src.getItem(i);
					fullname = (CodeStringEx) fullname.concate(str, str.indicesInSrc.getItem(0), 
							(FindVarUseParams)str.listOfVarUses.getItem(0));
				} // for i
				result.add(fullname);
				
				if (j<indicesOfFullnames.count-1) {
					IndexStartEnd next = (IndexStartEnd)indicesOfFullnames.getItem(j+1);
					for (i=curIndex.endIndex+1; i<next.startIndex; i++) {
						result.add(src.getItem(i));
					} // for i
				}				
			}// for j
			
			// 마지막 인덱스부터 수식의 끝까지
			IndexStartEnd last = (IndexStartEnd)indicesOfFullnames.getItem(indicesOfFullnames.count-1);
			for (i=last.endIndex+1; i<=src.count-1; i++) {
				result.add(src.getItem(i));
			} // for i
			
			
			
		} // else if (indicesOfFullnames.count>1) {
		else { //count==0
			for (i=0; i<=src.count-1; i++) {
				result.add(src.getItem(i));
			} // for i
			
		}
	}
	
	
	
	/** @param startIndex : (의 인덱스
	 *  @param endIndex : )의 인덱스
	 * @return 타입의 끝 인덱스를 리턴한다. 타입이 아닌것(상수, 구분자 등)을 만나면 그 인덱스-1을 리턴한다. 
	 */
	int IsType(Compiler compiler, HighArray_CodeString src, int startIndex, int endIndex) {
		int i;
		for (i=startIndex+1; i<endIndex; i++) {
			CodeString str = src.getItem(i);
			if (str.equals("bounds.x")) {
			}
			if (CompilerHelper.IsDefaultType(str, compiler) || CompilerHelper.IsIdentifier(str, compiler)) {
				// charATextLine = (new TextLine(charA, fontSize)); 에서 startIndex가 첫번째 (을 가리키는 경우
				// src는 '(', 'TextLine(charA, fontSize)', ')'이다.
				if (str.str.contains("(")) return i-1;
				else {
					if (str.str.contains(".")) {
						// clipRect.left = (int) (bounds.x); 에서 bounds.x를 가리키고 이것은 스트링 하나이다.
						HighArray_CodeString backupMBuffer = compiler.data.mBuffer;
						compiler.data.mBuffer = null;
						HighArray_CodeString result = new StringTokenizer().ConvertToStringArray2(str, 20, Language.Java);
						//String typeName = compiler.getFullNameType(compiler, 0, result.count-1);
						String typeName = Fullname.getFullName(result, 0, result.count-1).str;
						compiler.data.mBuffer = backupMBuffer;
						if (typeName==null) return i-1;
					}
				}
				// 배열과 템플릿인 경우는 다음에 생각해본다.
				return i;
			}
			else if (CompilerHelper.IsConstant(str)) return i-1;
			else if (CompilerHelper.IsSeparator(str)) return i-1;
			else if (CompilerHelper.IsBlank(str) || CompilerHelper.IsAnnotation(str)) continue;
			
		}
		
		
		return -1;
		
	}
	
	/** (타입)id, (타입)(수식) 와 같은 타입캐스팅이 하나의 스트링으로 변환된 새로운 스트링 배열을 만든다.*/
void ProcessTypecastings2(HighArray_CodeString src, ArrayListCodeString result) {
		
		int i;
		
		// 원래 소스코드상의 Typecasting의 시작과 끝 인덱스를 말한다.
		ArrayListIReset indicesOfTypecastings = new ArrayListIReset(10);
		
		int startIndex=-1, endIndex=-1;
		int leftParent, rightParent;
		for (i=0; i<src.count; ) {
			CodeStringEx str = (CodeStringEx) src.getItem(i);
			if (str.equals("(")) {
			}
			if (str.equals("(")) {
				int prevIndex = CompilerHelper.SkipBlank(src, true, 0, i-1);
				if (prevIndex>=0 && CompilerHelper.IsIdentifier(src.getItem(prevIndex), compiler)) {
					// "("는 함수호출의 괄호이다.
					i++;
					continue;
				}
				leftParent = i;
				
				rightParent = Checker.CheckParenthesis_postfix(compiler, src, "(", ")", leftParent, src.count-1, false);
				if (rightParent!=-1) {
					//int typeIndex = compiler.IsType(src, false, leftParent+1, null);
					int typeIndex = IsType(compiler, src, leftParent, rightParent);
					if (typeIndex!=-1) {
						int tempRightPair = CompilerHelper.SkipBlank(src, false, typeIndex+1, src.count-1);
						if (tempRightPair==rightParent) { // 괄호안은 타입캐스트문
							// RectForPage.test((rectForPageLeft), 3);에서 (rectForPageLeft)을 말한다.
							if (src.count<=rightParent+1) {
								i++;
								continue;
							}
							CodeString id = src.getItem(rightParent+1);
							try {
							if ( CompilerHelper.IsIdentifier( id, compiler ) || CompilerHelper.IsConstant(id)) { // (타입)id
								startIndex = leftParent;
								endIndex = rightParent+1;
								indicesOfTypecastings.add(new IndexStartEnd(startIndex, endIndex));
								i = endIndex+1;
								continue;
							}
							else if (id.equals("(")) { // (타입)(수식)
								int rightParent2 = Checker.CheckParenthesis_postfix(compiler, src, "(", ")", rightParent+1, src.count-1, false);
								startIndex = leftParent;
								endIndex = rightParent2;
								indicesOfTypecastings.add(new IndexStartEnd(startIndex, endIndex));
								i = endIndex+1;
								continue;
							}
							else if (id.equals("-")) {
								
								int backup_idIndex = rightParent+1;
								int leftParent2= backup_idIndex+1;
								id = src.getItem(leftParent2);
								if ( CompilerHelper.IsIdentifier( id, compiler ) || CompilerHelper.IsConstant(id)) { // (타입)-num
									startIndex = leftParent;
									//endIndex = rightParent+1;
									endIndex = Fullname.getFullNameIndex_postfix(compiler, src, false, leftParent2, true);
									indicesOfTypecastings.add(new IndexStartEnd(startIndex, endIndex));
									i = endIndex+1;
									continue;
								}
								else if (id.equals("(")) {// (타입)-(수식)
									int rightParent2 = Checker.CheckParenthesis_postfix(compiler, src, "(", ")", leftParent2, src.count-1, false);
									startIndex = leftParent;
									endIndex = rightParent2;
									indicesOfTypecastings.add(new IndexStartEnd(startIndex, endIndex));
									i = endIndex+1;
									continue;
								}
								else {
									i++;
									continue;
								}
							}
							else {
								i++;
								continue;
							}
							}catch(Exception e1) {
							}
						}//if (tempRightPair==rightParent) { // 괄호안은 타입캐스트문
						else {
							i++;
							continue;
						}
					}//if (typeIndex!=-1) {
					else {
						i++;
						continue;
					}
				} // if (rightParent!=-1) {
				else {
					i++;
					continue;
				}
				
			} // if (str.equals("(")) {
			else {
				i++;
			}
			
		} // for i
		
		
		// 타입캐스팅이 하나의 스트링으로 변환된 새로운 스트링 배열을 만든다.
		if (indicesOfTypecastings.count==1) {
			IndexStartEnd index = (IndexStartEnd)indicesOfTypecastings.getItem(0); 
			for (i=0; i<index.startIndex; i++) {
				result.add(src.getItem(i));
			} // for i
			
			/*ArrayListInt indicesInSrc = ((CodeStringEx)src.getItem(index.startIndex)).indicesInSrc;
			ArrayListIReset listOfVarUses = ((CodeStringEx)src.getItem(index.startIndex)).listOfVarUses;
			CodeStringEx typecasting = new CodeStringEx(src.getItem(index.startIndex).str, Color.BLACK, indicesInSrc, listOfVarUses);
			for (i=index.startIndex+1; i<=index.endIndex; i++) {
				CodeStringEx str = (CodeStringEx) src.getItem(i);
				//typecasting = (CodeStringEx) typecasting.concate(str, str.indicesInSrc.getItem(0), 
				//		(FindVarUseParams)str.listOfVarUses.getItem(0));
				typecasting = typecasting.concate(str);
			} // for i
			result.add(typecasting);*/
			
			
			CodeStringEx typecasting = (CodeStringEx) src.getItem(index.startIndex);
			for (i=index.startIndex+1; i<=index.endIndex; i++) {
				CodeStringEx str = (CodeStringEx) src.getItem(i);
				typecasting = typecasting.concate(str);
			}
			result.add(typecasting);
			
			
			
			for (i=index.endIndex+1; i<=src.count-1; i++) {
				result.add(src.getItem(i));
			} // for i
		}
		else if (indicesOfTypecastings.count>1) {
			int j;
			
			// 수식의 처음부터 첫번째 인덱스까지
			IndexStartEnd index = (IndexStartEnd)indicesOfTypecastings.getItem(0); 
			for (i=0; i<index.startIndex; i++) {
				result.add(src.getItem(i));
			} // for i
			
			// 인덱스를 하나의 스트링으로 만들고 인덱스의 끝부터 다음 인덱스의 처음까지
			for (j=0; j<indicesOfTypecastings.count; j++) {				
				
				IndexStartEnd curIndex = (IndexStartEnd)indicesOfTypecastings.getItem(j);
				CodeStringEx typecasting = (CodeStringEx) src.getItem(curIndex.startIndex);
				for (i=curIndex.startIndex+1; i<=curIndex.endIndex; i++) {
					CodeStringEx str = (CodeStringEx) src.getItem(i);
					typecasting = typecasting.concate(str);
				}
				result.add(typecasting);
				
				if (j<indicesOfTypecastings.count-1) {
					IndexStartEnd next = (IndexStartEnd)indicesOfTypecastings.getItem(j+1);
					for (i=curIndex.endIndex+1; i<next.startIndex; i++) {
						result.add(src.getItem(i));
					} // for i
				}				
			}// for j
			
			// 마지막 인덱스부터 수식의 끝까지
			IndexStartEnd last = (IndexStartEnd)indicesOfTypecastings.getItem(indicesOfTypecastings.count-1);
			for (i=last.endIndex+1; i<=src.count-1; i++) {
				result.add(src.getItem(i));
			} // for i
			
			
			
		} // else if (indicesOfTypecastings.count>1) {
		else { //count==0
			for (i=0; i<=src.count-1; i++) {
				result.add(src.getItem(i));
			} // for i
			
		}
	}
	
	
	
	/** arr의 원소의 실제 타입은 CodeStringEx이다.*/
	CodeStringEx[] toConvertExArr(CodeString[] arr) {
		CodeStringEx[] r = new CodeStringEx[arr.length];
		int i;
		for (i=0; i<arr.length; i++) {
			r[i] = (CodeStringEx) arr[i];
		}
		return r;
	}

	
	public CodeStringEx[] Convert()
	{
		if (src.count==1) {
			this.mBuffer = toConvertExArr(src.getItems());
			return this.mBuffer;
		}
		
		HighArray_CodeString result0 = src;
		
		boolean success = Checker.CheckParenthesisAll(compiler, result0, listOfBlocks, listOfSmallBlocks, listOfLargeBlocks);
		if (!success) return null;
		
		HighArray_CodeString result = new HighArray_CodeString(result0.count);
		removeFakeParenthesis(result0, result);
		
		checkRule(result);
		
		HighArray_CodeString result1 = new HighArray_CodeString(result0.count);
		ProcessFullnames2(result, result1);
		
		listOfBlocks.destroy();
		listOfSmallBlocks.destroy();
		listOfLargeBlocks.destroy();
		
		ArrayListCodeString result2 = new ArrayListCodeString(result1.count);
		ProcessTypecastings2(result1, result2);
		
		
		this.mBuffer = toConvertExArr(result2.getItems()); 
		
		//this.mBuffer = result1.getItems();
		
		
		CheckOperatorRule();

		
		CodeStringEx[] tempBuffer = mBuffer;
		//tempBuffer = FindExpression(mBuffer);
		// 2 + 2 * 3	2 + (2 + 2 * 3) * 2			(2)+(2*3)			(2 + (2 + (2*3)) / 2)
		// (-1*2+(2*3)/2)-1
		tempBuffer = ProcessParenthesis(tempBuffer);
		if (tempBuffer==null) return null;
		
		
		
		// 2 + 2 * 3		2 + 2 2 3 *:T +:T @ * 2			2 + 2 3 *:T @		2 2 2 3 *:T +:T 2 /:T +:T @
		tempBuffer = ConvertInfixToPostfix(tempBuffer);
		// 2 2 3 *:T +:T @		2 2 2 3 *:T +:T 2 *:T +:T @			2 2 3 *:T +:T @
		tempBuffer = RemoveFlag(tempBuffer);	// ":T" 제거
		tempBuffer = RemoveSeparator(tempBuffer);	// "@" 제거
		
		
		
		return tempBuffer;
		
	}

	/** Checks 1 2 + 3, a + b c*/ 
	private void checkRule(HighArray_CodeString result) {
		
		int i;
		for (i=0; i<result.count; i++) {
			CodeStringEx cur = (CodeStringEx) result.getItem(i);
			CodeStringEx next = null;
			if (i+1<result.count) {
				next = (CodeStringEx) result.getItem(i+1);			
				if ( (CompilerHelper.IsIdentifier(cur, compiler) || CompilerHelper.IsDefaultType(cur.str) || CompilerHelper.IsConstant(cur)) && 
						(CompilerHelper.IsIdentifier(next, compiler) || CompilerHelper.IsDefaultType(next.str) || CompilerHelper.IsConstant(next)) ) {
					CompilerStatic.errors.add(new Error(compiler, 
							cur.indicesInSrc.getItem(0), next.indicesInSrc.getItem(0), "invalid type declaration or invalid operator"));
				}
			}
		}
	}

	/** (str.toCharArray())[0]; 에서 토큰은 "str.toCharArray()"와 "[0]"이 되므로 이것들을 합쳐야 한다.*/
	CodeStringEx[] removeInvalidArrayElements(CodeStringEx[] tempBuffer) {
		boolean invalidArrayElement = false;
		int i;		
		ArrayListInt arrayElements = new ArrayListInt(5);
		for (i=0; i<tempBuffer.length; i++) {
			if (tempBuffer[i].count>0 && tempBuffer[i].charAt(0).c=='[') {
				arrayElements.add(i);
				invalidArrayElement = true;
			}
		}
		if (invalidArrayElement) {
			for (i=0; i<arrayElements.count; i++) {
				int index = arrayElements.getItem(i);
				tempBuffer[index-1] = tempBuffer[index-1].concate(tempBuffer[index]);
				tempBuffer[index] = null;
			}
			
			CodeStringEx[] buf = new CodeStringEx[tempBuffer.length-arrayElements.count];
			int j=0;
			for (i=0; i<tempBuffer.length; i++) {
				if (tempBuffer[i]!=null) {
					buf[j] = tempBuffer[i];
					j++;
				}
			}
			return buf;
		}
		return tempBuffer;
	}
	
	CodeStringEx[] FindExpression(CodeStringEx[] buffer) {
		CodeStringEx[] tempBuffer;
		int index = Common.Find(buffer,"=",0);
		int oldIndex=0;
		while (index!=PostFixConverter.EOB) {
			oldIndex = index;
			index = Common.Find(buffer,"=",index+1);
		}
		if (Common.Find(buffer,"=",0)!=PostFixConverter.EOB) {
			tempBuffer = Common.Copy(buffer,oldIndex+3, buffer.length-oldIndex-3);
		}
		else {
			tempBuffer = Common.Copy(buffer,0, buffer.length);
		}
		
		int i;
		int pos;
		for (i=0; i<tempBuffer.length; i++) {
			pos = Common.Find(tempBuffer,";",0);
			if (pos!=PostFixConverter.EOB) {
				tempBuffer = Common.Remove(tempBuffer,pos,1);
				if (i>=pos)	i--;
			}
		}

		return tempBuffer;	
	}
	
	/*int[][] CheckParenthesis(ArrayListIReset listOfSmallBlockParams) {
		int[][] r = new int[listOfSmallBlockParams.count][2];
		int i;
		FindSmallBlockParams smallBlock;
		for (i=0; i<listOfSmallBlockParams.count; i++) {
			smallBlock = (FindSmallBlockParams) listOfSmallBlockParams.getItem(i);
			r[i][0] = smallBlock.startIndex;
			r[i][1] = smallBlock.endIndex;
		}
		return r;
	}*/
	
	int[][] CheckParenthesis(CodeStringEx[] buffer)
	{
		Stack stack = new Stack();
		int[][] tempTable = new int[100][2];
		int[][] table = new int[100][2];
		for (int i=0, k=0, j=0; i<buffer.length; i++) {
			if (buffer[i].equals("(")) {
				stack.Push(buffer[i]);
				tempTable[k][0] = i;
				tempTable[k][1] = -1;
				k++;
			}
			else if (buffer[i].equals(")")) {
				if (stack.IsEmpty()) {
					return null;
				}
				stack.Pop();
				k--;
				tempTable[k][1] = i;
				table[j][0] = tempTable[k][0];
				table[j][1] = tempTable[k][1];			
				j++;
			}
			else {
				continue;
			}
		}
		if (!stack.IsEmpty()) {
			return null;
		}
		else
			return table;
	}


	/** 2 + (2 + 2 * 3) * 2   ->   
	 * 2 + 2 2 3 *:T +:T @ * 2   ->   
	 * 2 2 2 3 *:T +:T 2 *:T +:T @
	 * @param buffer
	 * @return
	 */
	CodeStringEx[] ProcessParenthesis(CodeStringEx[] buffer) {
		int[][] parenthesisArray=null;
		try {
			parenthesisArray = CheckParenthesis(buffer);
			if (parenthesisArray==null) return null;
		} catch (Exception e) {
			
			if (Common_Settings.g_printsLog) e.printStackTrace();
			if (Common_Settings.g_printsLog) CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
			return null;
		}
		CodeStringEx[] tempBuffer;
		int srcIndex1, srcIndex2, len;
		for (int i=0; i<parenthesisArray.length; i++) {
			if (parenthesisArray[i][0]==0 && parenthesisArray[i][1]==0)
				break;
			// 괄호 제외 카피
			srcIndex1 = parenthesisArray[i][0] + 1;
			srcIndex2 = parenthesisArray[i][1] - 1;
			len = srcIndex2 - srcIndex1 + 1;
			tempBuffer = Common.Copy(buffer, srcIndex1, len);
			tempBuffer = ConvertInfixToPostfix(tempBuffer);
			//tempBuffer = Common.Insert(tempBuffer, new CodeStringEx("@"), tempBuffer.length);
			// 괄호 포함 제거
			srcIndex1 = parenthesisArray[i][0];
			srcIndex2 = parenthesisArray[i][1];
			len = srcIndex2 - srcIndex1 + 1;
			buffer = Common.Remove(buffer, srcIndex1, len);
			// Postfix를 처음 괄호 위치에 복사
			buffer = Common.Insert(buffer, tempBuffer, srcIndex1);
			// 인덱스 보정
			for (int k=i+1; k<parenthesisArray.length; k++) {
				if (parenthesisArray[k][0]==0 && parenthesisArray[k][1]==0)
					break;
				if (parenthesisArray[k][0]>srcIndex1) {
					parenthesisArray[k][0] -= len-tempBuffer.length;
				}
				if (parenthesisArray[k][1]>srcIndex1) {
					parenthesisArray[k][1] -= len-tempBuffer.length;
				}
			}
		}
		return buffer;
	}
	
	boolean contains(String[] operators, CodeStringEx operator) {
		int i;
		for (i=0; i<operators.length; i++) {
			if (operator.equals(operators[i])) return true;
		}
		return false;
		
	}
	
	/** @param index : int a=-1; 에서 '-'의 인덱스*/
	boolean isPlusOrMinusForOne(int index) {
		CodeString prev = null, next;
		int prevIndex = CompilerHelper.SkipBlank(compiler.data.mBuffer, true, 0, index-1);
		if (prevIndex!=-1) prev = compiler.data.mBuffer.getItem(prevIndex);
		int nextIndex = CompilerHelper.SkipBlank(compiler.data.mBuffer, false, index+1, compiler.data.mBuffer.count-1);
		next = compiler.data.mBuffer.getItem(nextIndex);
		
		boolean isNextOperand = false;
		if (CompilerHelper.IsIdentifier(next, compiler) || Number.IsNumber2(next)!=0) {
			isNextOperand = true;
		}
		else if (next.equals("(")) {
			isNextOperand = true;
		}
		
		if ( prev.equals("return") || 
				((prev.equals("=") || prev.equals("(") || prev.equals("[") || prev.equals("{") || prev.equals(",") || prev.equals(")") || CompilerHelper.IsOperator(prev))) && 
				(isNextOperand)) {
			// prev.equals(")")는 (type)-3과 같은 경우를 위한 것이다.
			if (prev.equals(")")) {
				int rightPairIndex = prevIndex;
				int leftPairIndex = Checker.CheckParenthesis(compiler,  "(", ")", 0, rightPairIndex, true);
				int fullNameStartIndex = CompilerHelper.SkipBlank(compiler.data.mBuffer, false, leftPairIndex+1, compiler.data.mBuffer.count-1);
				int fullNameEndIndex = Fullname.getFullNameIndex_OnlyType_postfix(compiler, compiler.data.mBuffer, false, fullNameStartIndex, true);
				int fullNameNextIndex = CompilerHelper.SkipBlank(compiler.data.mBuffer, false, fullNameEndIndex+1, compiler.data.mBuffer.count-1);
				
				if (fullNameNextIndex==rightPairIndex) {
					int funcCallIndex = CompilerHelper.SkipBlank(compiler.data.mBuffer, true, 0, leftPairIndex-1);
					if (CompilerHelper.IsIdentifier(compiler.data.mBuffer.getItem(funcCallIndex), compiler)) {
						// int a = f() + 2; (여기에서 index는 +를 가리킨다) 와 같은 함수 호출인 경우
						return false;
					}
					// 타입캐스팅이므로 부호로 처리한다.
					if (next.charAt(0).c=='"' || next.charAt(0).c=='\'') {
						// second '+' in "["+(indexOfSubscription)+"]"
						return false; // 이항 연산자
					}
					else {
						return true; // 부호
					}
				}
				else {
					return false;  // 이항 연산자
				}
			}// if (prev.equals(")")) {
			// return -3; 
			// (+3), [+3]
			return true; // 부호
		}
		return false;
	}
	
	/** !, ~, +, -와 같은 일항연산자를 포스트픽스로 바꾼다.*/
	CodeStringEx[] processOperatorForOne(CodeStringEx[] tempBuffer, String[] operators) {
		for (int i=0; i<tempBuffer.length && tempBuffer[i]!=null; i++) {			
			if (contains(operators, tempBuffer[i])) {
				boolean isOperatorForOne = false;
				if (tempBuffer[i].equals("+") || tempBuffer[i].equals("-")) {
					// -(2.0f) 이와 같은 경우는 tempBuffer가 -, 2.0f 이 된다.
					/*if (i-1<0) {
						tempBuffer[i].isPlusOrMinusForOne = true;
						isOperatorForOne = true;
					}
					// -1.0f + -(2.0f)이와 같은 경우는 tempBuffer가 -1.0f, +, -, 2.0f 이 된다.
					else if (i-1>=0 && CompilerHelper.IsOperator(tempBuffer[i-1])) {
						if (!contains(this.operatorsAllocater, tempBuffer[i-1])) {
							tempBuffer[i].isPlusOrMinusForOne = true;
							isOperatorForOne = true;
						}
					}*/
					
					if (this.isPlusOrMinusForOne(tempBuffer[i].indicesInSrc.getItem(0))) {
						tempBuffer[i].isPlusOrMinusForOne = true;
						isOperatorForOne = true;
					}
					
					if (!isOperatorForOne) continue;
				}
				
				int pos;
				if (i+2<tempBuffer.length && tempBuffer[i+2]!=null) {
					if (CompilerHelper.IsOperator(tempBuffer[i+2]))
						pos = PostFixConverter.EOB;
						//pos = i+2;
					else {	// 연산자 뒤에 괄호안 수식이 있을 때
						pos = Common.Find(tempBuffer, "@", i+1);
					}
				}
				else {
					pos = PostFixConverter.EOB;
				}					
				
				ArrayListInt indices = new ArrayListInt(1);
				indices.add(-1);
				ArrayListIReset varUses = new ArrayListIReset(1);
				varUses.add(null);
				// 연산자에 :T연결
				CodeStringEx strT = new CodeStringEx(":T", Color.BLACK, indices, varUses);
				tempBuffer[i] = (CodeStringEx) tempBuffer[i].concate(strT, -1, null);
				if (pos==PostFixConverter.EOB) {
					tempBuffer = Common.Insert(tempBuffer, tempBuffer[i], i+2); // 연산자를 오퍼랜드뒤에 복사
					tempBuffer = Common.Insert(tempBuffer, new CodeStringEx("@",Color.BLACK, indices, varUses), i+3);
					// @를 연산자뒤에 복사
					tempBuffer = Common.Remove(tempBuffer, i, 1); // 연산자가 이동되었으므로 원래 연사자는 제거
					i = i+2;
				}
				else {
					tempBuffer = Common.Insert(tempBuffer, tempBuffer[i], pos);
					tempBuffer = Common.Remove(tempBuffer, i, 1);
					i = pos;
				}
			}
		}
		return tempBuffer;
	}
	
	
	CodeStringEx[] processAllocatorOperator(CodeStringEx[] tempBuffer) {
		for (int i=0; i<tempBuffer.length && tempBuffer[i]!=null; i++) {			
			if (contains(this.operatorsAllocater, tempBuffer[i])) {
				tempBuffer = Common.Insert(tempBuffer, tempBuffer[i], tempBuffer.length);
				tempBuffer = Common.Remove(tempBuffer, i, 1);
				return tempBuffer;
			}
		}
		return tempBuffer;
	}
	
	/** ? 단항연산자를 포스트픽스로 바꾼다. 단순히 삼항연산의 조건문에 달라붙는 @를 제거한다.*/
	CodeStringEx[] processQuestionOperator(CodeStringEx[] tempBuffer) {
		for (int i=0; i<tempBuffer.length && tempBuffer[i]!=null; i++) {			
			if (tempBuffer[i].equals("?")) {
				// 연산자 앞에 괄호안 수식이 있을 때
				if (i-1>=0 && tempBuffer[i-1].equals("@")) {
					tempBuffer = Common.Remove(tempBuffer,i-1,1);
					break;
				}
			}
		}
		return tempBuffer;
	}
	
	/** +, -, *, /와 같은 이항연산자를 포스트픽스로 바꾼다.*/
	CodeStringEx[] processOperator(CodeStringEx[] tempBuffer, String[] operators) {
		for (int i=0; i<tempBuffer.length && tempBuffer[i]!=null; i++) {			
			if (contains(operators, tempBuffer[i])) {
				// 연산자 앞에 괄호안 수식이 있을 때
				if (i-1>=0 && tempBuffer[i-1].equals("@")) {
					tempBuffer = Common.Remove(tempBuffer,i-1,1);
					i = i-1;
				}
				int pos;
				if (i+2<tempBuffer.length && tempBuffer[i+2]!=null) {
					if (CompilerHelper.IsOperator(tempBuffer[i+2])/* && tempBuffer[i+2].equals("?")==false*/) {
						if (tempBuffer[i+2].equals("?")) {
							if (contains(this.operatorsEquals, tempBuffer[i]) || contains(this.operatorsInstanceof, tempBuffer[i]) ||
									contains(this.operatorsLogical1, tempBuffer[i]) || contains(this.operatorsLogical2, tempBuffer[i]) ||
									contains(this.operatorsRelations, tempBuffer[i])) {
								//String s = v!=null ? ", "+"abc" : ", "+"abc"; 에서 i는 !=을 가리킨다.
								// v null != ? 이렇게 된다.
								pos = PostFixConverter.EOB;
							}
							else {
								pos = Common.Find(tempBuffer, "@", i+1);
							}
						}
						else {
							// 1+2+3에서 i=1인 경우
							// 1 2 +:T @ + 3 이 된다.
							// 1 2 +:T 3 +:T @ 
							pos = PostFixConverter.EOB;
						}
					}
					else {	// 연산자 뒤에 괄호안 수식이 있을 때
						pos = Common.Find(tempBuffer, "@", i+1);
					}
				}
				else {
					pos = PostFixConverter.EOB;
				}					
				
				ArrayListInt indices = new ArrayListInt(1);
				indices.add(-1);
				ArrayListIReset varUses = new ArrayListIReset(1);
				varUses.add(null);
				// :T연결
				CodeStringEx strT = new CodeStringEx(":T", Color.BLACK, indices, varUses);
				tempBuffer[i] = (CodeStringEx) tempBuffer[i].concate(strT, -1, null); 
				// 연산자가 +일경우 +:T가 된다.
				if (pos==PostFixConverter.EOB) {
					tempBuffer = Common.Insert(tempBuffer, tempBuffer[i], i+2); 
					// 2.5f % 2일 경우 
					// 2.5f  %:T  2  %:T가 된다.
					tempBuffer = Common.Insert(tempBuffer, new CodeStringEx("@",Color.BLACK, indices, varUses), i+3); 
					// 2.5f  %:T  2  %:T  @
					tempBuffer = Common.Remove(tempBuffer, i, 1);
					// 2.5f  2  %:T  @
					i = i+2;
					// i=1이었으므로  i=3이 된다.
				}
				else {
					tempBuffer = Common.Insert(tempBuffer, tempBuffer[i], pos);
					tempBuffer = Common.Remove(tempBuffer, i, 1);
					i = pos;
				}
			}
		}
		return tempBuffer;
	}

	

	/** 이 함수를 거치면 @가 항상 끝에 하나만 나온다
	 * 2 + (2 + 2 * 3) * 2   -->   
	 * 2 + 2 2 3 *:T +:T @ * 2   -->   
	 * 2 2 2 3 *:T +:T 2 *:T +:T @
	 * @param buffer
	 * @return
	 */
	CodeStringEx[] ConvertInfixToPostfix(CodeStringEx[] tempBuffer) {
		tempBuffer = processOperatorForOne(tempBuffer, operatorsForOne);
		
		//String[] operatorsPower = {"^"};
		//tempBuffer = processOperator(tempBuffer, operatorsPower);
		
		//String[] operatorsMultipliers = {"*", "/", "%"};
		tempBuffer = processOperator(tempBuffer, operatorsMultipliers);
		
		//String[] operatorsShifters = {"<<", ">>", ">>>"};
		tempBuffer = processOperator(tempBuffer, operatorsShifters);
		
		//String[] operatorsBitLogical = {"&", "|", "~", "^"};
		tempBuffer = processOperator(tempBuffer, operatorsBitLogical);
		
		//String[] operatorsAdders = {"+", "-"};
		tempBuffer = processOperator(tempBuffer, operatorsAdders);
		
		
		
		//String[] operatorsRelations = {"<", ">", "<=", ">="};
		tempBuffer = processOperator(tempBuffer, operatorsRelations);
		
		//String[] operatorsInstanceof = {"instanceof"};
		tempBuffer = processOperator(tempBuffer, operatorsInstanceof);
				
		//String[] operatorsEquals = {"==", "!="};
		tempBuffer = processOperator(tempBuffer, operatorsEquals);
		
		
		
		
		
		//String[] operatorsLogical1 = {"&&", "!"};
		tempBuffer = processOperator(tempBuffer, operatorsLogical1);
		
		//String[] operatorsLogical2 = {"||"};
		tempBuffer = processOperator(tempBuffer, operatorsLogical2);
		
		//String[] operatorsQuestion = {"?"};
		tempBuffer = processQuestionOperator(tempBuffer);
		
		//String[] operatorsChoose = {":"};
		tempBuffer = processOperator(tempBuffer, operatorsChoose);
		
		//String[] operatorsAllocater = {"=", "+=", "-=", "*=", "/=", "%=", "|=", "&="};
		//tempBuffer = processOperator(tempBuffer, operatorsAllocater);
		
		//tempBuffer = processAllocatorOperator(tempBuffer);
		
		
		
		tempBuffer = processOperator(tempBuffer, this.operatorsAllocater);
		
		return tempBuffer;
			
	}

	CodeStringEx[] RemoveSeparator(CodeStringEx[] buffer) {
		for (int i=0; i<buffer.length; i++) {
			if (buffer[i]!=null) {
				if (buffer[i].equals("@")) {
					buffer = Common.Remove(buffer, i, 1);
					i = i-1;
				}
			}
		}
		return buffer;
	}

	CodeStringEx[] RemoveFlag(CodeStringEx[] buffer) {
		for (int i=0; i<buffer.length; i++) {
			if (buffer[i]!=null) {
				int indexT = buffer[i].indexOf(":T");
				if (indexT!=-1) {
					buffer[i] = (CodeStringEx) buffer[i].substring(0, indexT);
				}
			}
		}
		return buffer;
	}

			/*boolean IsSeparator(char c)
	        {
	            if (c == '[' || c==']' || c=='{' || c=='}' || c == '(' || c == ')' ||
	                c=='=' || c == ';' || c == ':' || c == ',' || c == '<' || c == '>')
	                return true;
	            return false;
	        }*/

			boolean IsSeparator(char c)
	        {
	            if (c == ';' || c == ':' || c == ',')
	                return true;
	            return false;
	        }

	        boolean IsBlank(char c)
	        {
	            if (c == ' ' || c == '\t' || c == '\r' || c == '\n') return true;
	            return false;
	        }

	        boolean IsBlank(String c)
	        {
	            if (c.equals(" ") || c.equals("\t") || c.equals("\r") || c.equals("\n")) return true;
	            return false;
	        }

	        boolean IsStartParenthesis(char c)
	        {
	            if (c == '(' || c == '{' || c == '[') return true;
	            else return false;
	        }

	        boolean IsEndParenthesis(char c)
	        {
	            if (c == ')' || c == '}' || c == ']') return true;
	            else return false;
	        }

			boolean IsParenthesis(char c) {
				if (IsStartParenthesis(c)) return true;
				if (IsEndParenthesis(c)) return true;
				return false;
			}

			

			/*boolean IsLetterOrDigitOrDot(char c)
			{
				if (char.IsLetterOrDigit(c)) return true;
	            if (c == '.') return true;
	            return false;
			}*/

	/*void ConvertToStringArray() 
	{
				String word;
		        char[] word_wchar = new char[](WordLengthLimit);
		        mBuffer = new String[](StringArrayLimit);
		        int k=0;
		        int i;
	            int countOfmBuffer = 0;

		        for (i=0; i<input.length; i++) {
	                if (IsPlusOrMinus(i))
	                {   // 양이나 음의 부호
	                    word_wchar[k++] = input[i];
	                }
	                if (char.IsDigit(input[i]) || input[i] == '.')
	                {  // 숫자
	                    word_wchar[k++] = input[i];
	                }
	                if (char.IsLetter(input[i]))
	                {  // 변수
	                    word_wchar[k++] = input[i];
	                }

			        if ((input[i]=='+') || (input[i]=='-') || (input[i]=='*') || (input[i]=='/') 
						|| (input[i]=='=') )
					{  // 연산자
	                    if (IsPlusOrMinus(i))
	                    {
	                        // 이미 들어간 부호
	                    }
	                    else
	                    {
	                        if (i > 0 && IsLetterOrDigitOrDot(input[i - 1]))    // 숫자나 변수 넣기
	                        {
	                            word = (new String(word_wchar)).Substring(0, k);
	                            k = 0;
	                            word = word.Trim();
	                            mBuffer[countOfmBuffer++] = word;
	                            word_wchar = new char[](WordLengthLimit);
	                        }
	                        mBuffer[countOfmBuffer++] = "" + input[i];
	                    }
			        }                
			       
			        if (IsSeparator(input[i]) || IsParenthesis(input[i])) {   // Separator, Parenthesis
	                    if (i > 0 && IsLetterOrDigitOrDot(input[i - 1]))    // 숫자나 변수 넣기
	                    {
					        word = (new String(word_wchar)).Substring(0,k);				        
					        word = word.Trim();
					        mBuffer[countOfmBuffer++] = word;
	                        word_wchar = new char[](WordLengthLimit);
	                        k = 0;
				        }
	                    mBuffer[countOfmBuffer++] = "" + input[i];
			        }
			        if (i == input.Length-1) {
	                    if (i > 0 && IsLetterOrDigitOrDot(input[i]))   
	                        // 숫자나 변수로 끝나면 : 구분자가 이미 들어갈 수 있기 때문
	                    {
	                        word = (new String(word_wchar)).Substring(0, k);
	                        word = word.Trim();
	                        mBuffer[countOfmBuffer++] = word;
	                    }
			        }
		        }

				Array.Resize(mBuffer, countOfmBuffer);
	}*/


	void Copy(char[] src, int srcIndex, char[] dest, int destIndex, int len)
	{
		int i;
	    int j = destIndex;
	    for (i = srcIndex; i < srcIndex + len; i++)
	    {
			dest[j++] = src[i];
	    }
	}

	void Copy(String[] src, int srcIndex, String[] dest, int destIndex, int len)
	{
	    int i;
	    int j = destIndex;
	    for (i = srcIndex; i < srcIndex + len; i++)
	    {
	        dest[j++] = src[i];
	    }
	}


	/** 공백, '\n' 등과 주석 등을 제거한다.*/
	void RemoveBlankAndComment(HighArray_CodeString src, ArrayListCodeString result) {
		int i;		 
		for (i = 0; i < src.count; i++)
	    {
			CodeStringEx str = (CodeStringEx) src.getItem(i);
	        if (CompilerHelper.IsBlank(str)) continue;
	        else if (CompilerHelper.IsComment(str)) continue;
	        else {
	        	result.add(str);
	        }
	    }
	}
	
	
	
	/*void CheckLetter()
	{
		int i;
		int len = input.length();
		String letter;
		for (i=0; i<len; ) {
			letter = input[i].ToString();
			if (Common.IsLowAlphabet(input[i]) || Common.IsNumber(letter) || 
				Common.IsOperator(letter) || letter.Equals(this.Separator) || 
				letter.Equals(this.LParenthesis) || letter.Equals(this.RParenthesis) ||
				letter.Equals(".")) {
				i++;			
			}
			else {			
				throw new Exception();
			}
		}
	}*/

	

	void CheckOperatorRule()
	{
		/*try {
			if (mBuffer.length==0 || mBuffer.length==1)
				throw new Exception();
			for (int i=0; i<mBuffer.length && mBuffer[i]!=null; i++) {
				if (CompilerHelper.IsOperator(mBuffer[i])) {
					if (mBuffer[i].equals("=")) {
						if (!Common.IsVarWithoutSign(mBuffer[i-1]))
							throw new Exception();
						if (!Common.IsNumber(mBuffer[i+1]))
							throw new Exception();
						if (!mBuffer[i+2].equals(";"))
							throw new Exception("Separator Not Exists");
					}
					else {
						if (mBuffer[i-1].equals(")") && mBuffer[i+1].equals("("))
							continue;
						if (Common.IsNumber(mBuffer[i-1]) && mBuffer[i+1].equals("("))
							continue;
						if (Common.IsVar(mBuffer[i-1]) && mBuffer[i+1].equals("("))
							continue;
						if (mBuffer[i-1].equals(")") && Common.IsNumber(mBuffer[i+1]))
							continue;
						if (mBuffer[i-1].equals(")") && Common.IsVar(mBuffer[i+1]))
							continue;
						if (!Common.IsNumber(mBuffer[i-1]) && !Common.IsVar(mBuffer[i-1]))
							throw new Exception();				
						if (!Common.IsNumber(mBuffer[i+1]) && !Common.IsVar(mBuffer[i+1]))
							throw new Exception();
					}			
				}
				else if (mBuffer[i].equals(";")) {
					if (!Common.IsVarWithoutSign(mBuffer[i-3]))
						throw new Exception();
					if (!mBuffer[i-2].equals("="))
						throw new Exception();
					if (!Common.IsNumber(mBuffer[i-1]))
						throw new Exception();
				}
			}
		}
		catch (Exception e) {
			throw e;
		}*/
		
		
	}
	
	
	static class Common {

		static CodeStringEx[] Insert(CodeStringEx[] input, CodeStringEx c, int pos) {
			if (input==null || c==null)
				return null;
			CodeStringEx[] result;
			if (pos>=input.length) {
				result = new CodeStringEx[pos+1];
				CopyTo(input, result, 0);
				result[pos] = c;
			}
			else {
				result = new CodeStringEx[input.length+1];
				for (int i=0, k=0; i<input.length; i++) {
					if (i==pos) {
						result[k] = c;
						k++;
						if (input[i]!=null) {
							result[k] = input[i];
							k++;
						}
					}
					else {
						if (input[i]!=null) {
							result[k] = input[i];
							k++;
						}
					}
				}
			}
			
			//if (input)
			//	delete input;
			return result;
		}
		
		static void CopyTo(CodeStringEx[] srcArray, CodeStringEx[] destArray, int pos) {
			int i, j;
			for (i=pos, j=0; i<pos+srcArray.length; i++) {
				destArray[i] = srcArray[j];
				j++;
			}
		}

		static CodeStringEx[] Insert(CodeStringEx[] destArray, CodeStringEx[] srcArray, int pos) {
			if (destArray==null || srcArray==null || pos<0)
				return null;
			CodeStringEx[] result;
			if (pos>=destArray.length) {
				result = new CodeStringEx[pos+srcArray.length];
				CopyTo(destArray, result, 0);
				CopyTo(srcArray, result, pos);
			}
			else {
				result = new CodeStringEx[destArray.length+srcArray.length];
				for (int i=0, k=0; i<destArray.length; i++) {
					if (i==pos) {
						CopyTo(srcArray, result, pos);
						k = k + srcArray.length;
						if (destArray[i]!=null) {
							result[k] = destArray[i];
							k++;
						}
					}
					else {
						if (destArray[i]!=null) {
							result[k] = destArray[i];
							k++;
						}
					}
				}
			}
			
			//if (destArray)
			//	delete destArray;
			return result;

		}


		static int Find(CodeStringEx[] input, String c, int index) {
			if (input==null)
				return PostFixConverter.EOB;
			int i;
			for (i=index; i<input.length && input[i]!=null; i++) {
				if (input[i].equals(c))
					return i;
			}
			return PostFixConverter.EOB;
		}

		/*static int Find(CodeStringEx[][] input, CodeStringEx c, int colIndex) {
			if (input==null)
				return PostFixConverter.EOB;
			if (colIndex>1)
				return PostFixConverter.EOB;
			int i;
			String val = c.Trim();
			for (i=0; i<input.length && input[i][0]!=null; i++) {
				if (Equals(input[i][colIndex],val))
					return i;
			}
			return PostFixConverter.EOB;
		}*/

		static boolean Equals(String str1, String str2) {
			if (str1.length()!=str2.length()) {
				//System.Windows.Forms.MessageBox.Show("str1:"+str1.Length+"  "+"str2:"+str2.Length);
				return false;
			}
			int i;
			for (i=0; i<str1.length(); i++) {
				if (str1.charAt(i)!=str2.charAt(i)) 
					return false;
			}
			return true;
		}

		static CodeStringEx[] Remove(CodeStringEx[] input, int pos, int count) {
			if (input==null)
				return null;
			if (pos+count>input.length)
				return null;
			CodeStringEx[] result = new CodeStringEx[input.length-count];
			for (int i=0, k=0; i<input.length; i++) {
				if (pos<=i && i<=pos+count-1) continue;
				result[k] = input[i];
				k++;
			}
			return result;
		}

		static CodeStringEx[] Copy(CodeStringEx[] srcArray, int srcIndex, int len)
		{
			if (srcArray==null)
				return null;
			if (srcIndex+len>srcArray.length)
				return null;
			if (len<0) {
			}
			CodeStringEx[] result = new CodeStringEx[len];
			for (int i=srcIndex, k=0; i<srcIndex+len && srcArray[i]!=null; i++) {
				result[k] = srcArray[i];
				k++;
			}
			return result;
		}

		/*static boolean IsOperator(String str) {
			if (str==null)
				return false;
			if (str.equals("+") || str.equals("-") || str.equals("*") || 
				str.equals("/") || str.equals("="))
				return true;
			return false;
		}

		static boolean IsNumber(String str) {
			try {
				Single.Parse(str);
				return true;
			}
			catch(Exception) {
				return false;
			}
			
		}

		static boolean IsLowAlphabet(wchar_t ch) {
			if ('a'<=ch && ch<='z')
				return true;
			return false;
		}

		static boolean IsVar(String str) {
			if (str==null)
				return false;
			if (IsOperator(str))
				return false;
			if (str[0]=='\0')
				return false;
			int i;
			if (!IsLowAlphabet(str[0])) {
				if (str[0]=='+' || str[0]=='-') {
					if (!IsLowAlphabet(str[1])) 
						return false;
					for (i=2; i<str.length && str[i]!='\0'; i++) {
						if (char.IsDigit(str[i]) || (IsLowAlphabet(str[i])))
							continue;
						else 
							return false;
					}
					return true;
				}
				else {
					return false;
				}
			}
			else {
				for (i=1; i<str.length && str[i]!='\0'; i++) {
					if (char.IsDigit(str[i]) || (IsLowAlphabet(str[i])))
						continue;
					else 
						return false;
				}
				return true;
			}
		}

		static boolean IsVarWithoutSign(String str) {
			if (str==null)
				return false;
			if (IsOperator(str))
				return false;
			if (str[0]=='\0')
				return false;
			int i;
			if (!IsLowAlphabet(str[0])) {
				return false;
			}
			else {
				for (i=1; i<str.length && str[i]!='\0'; i++) {
					if (char.IsDigit(str[i]) || (IsLowAlphabet(str[i])))
						continue;
					else 
						return false;
				}
				return true;
			}
		}*/
		
	}


}