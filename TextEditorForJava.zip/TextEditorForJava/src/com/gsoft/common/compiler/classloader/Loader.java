package com.gsoft.common.compiler.classloader;

import java.io.File;

import android.util.Log;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.CommonGUI;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.FileHelper;
import com.gsoft.common.IO;
import com.gsoft.common.IO_types.ReturnOfReadString;
import com.gsoft.common.compiler.Array;
import com.gsoft.common.compiler.ClassCache;
import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.CompilerCache;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.CompilerInterface;
import com.gsoft.common.compiler.CompilerStatic;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.Compiler_types.Language;
import com.gsoft.common.compiler.Compiler_types.LoadWayOfFindClassParams;
import com.gsoft.common.compiler.Compiler_types.ModeAllOrUpdate;
import com.gsoft.common.compiler.InterfaceErrorResolver;
import com.gsoft.common.compiler.StringTokenizer;
import com.gsoft.common.compiler.TemplateBase;
import com.gsoft.common.util.ArrayListIReset;
import com.gsoft.common.util.ArrayListString;
import com.gsoft.common.util.HighArray_CodeChar;
import com.gsoft.common.util.HighArray_char;
import com.gsoft.common.util.Util;

import com.gsoft.common.compiler.classloader.ClassLoader;
import com.gsoft.common.compiler.classloader.PathClassLoader;

public class Loader {
	
	static class ItemOfListOfClassesOfLoading {
		String fullname;
		Compiler compiler;
		ItemOfListOfClassesOfLoading(String fullname, Compiler compiler) {
			this.fullname = fullname;
			this.compiler = compiler;
		}
	}
	
	
	
	/** 클래스 로드 리스트, ItemOfListOfClassesOfLoading[]*/
	//public static ArrayList mlistOfLoadClassFromSrc_onlyInterface = new ArrayList(10);
	
	/** inner class를 함께 읽을수도 있고 아닐수도 있다.
	 * compiler.mlistOfAllClasses에 이미 로드된 클래스가 있다면 그것을 리턴하고,
	 * 없다면 그 클래스를 클래스파일에서 로드하고 compiler.mlistOfAllClasses에 등록하고 리턴한다.
	 * 또한 상속까지 한다.(외부 클래스들은 loadClass에서 상속, 파일에서 정의하는 클래스들은 따로 상속을 해야한다.)
	 * 클래스 로드가 실패하면 소스파일에서 로드한다(loadClassFromSrc_onlyInterface 참조). 
	 * 
	 * synchronized : loadClass(), loadXXX() Loader, getFindClassParams(), getFindClassParamsXXX() in ClassCache
	 * @param compiler : 어떤 compiler도 가능하다.
	 * @param fullName : java.lang.String과 같은 이름
	 * @param fullNameIncludingTemplateAndArray : 클래스가 템플릿 클래스일 경우 템플릿 타입 이름을 포함하고 배열도 포함하는 클래스 풀 이름이다.*/
	public /*synchronized*/ static FindClassParams loadClass(Compiler compiler, String fullNameIncludingTemplateAndArray, int coreThreadID) {
		//synchronized (SynchronizedObjects.lockForMultiThreadBuild) {
			String fullName = fullNameIncludingTemplateAndArray;
			if (fullName==null || fullName.equals("") || fullName.equals("null")) return null;
			
						
			String fullNameIncludingTemplateExceptArray = Array.getArrayElementType(fullNameIncludingTemplateAndArray);
			
			
			//클래스가 템플릿 클래스일 경우 템플릿 타입 이름을 포함하고 배열은 포함하지 않은 클래스 풀 이름이다.
			try {
			fullName = fullNameIncludingTemplateExceptArray;
			if (fullName==null || fullName.equals("")) return null;
			}catch(Exception e) {
				if (Common_Settings.g_printsLog) e.printStackTrace();
			}
			
			String typeNameInTemplatePair = null;
			if (fullName.contains("<")) {
				typeNameInTemplatePair = TemplateBase.getTemplateTypeInPair(fullName);
				
				// Stack<int> stack = new Stack();에서 int는 허용되지 않는다.				
				if (typeNameInTemplatePair!=null && 
						CompilerHelper.IsDefaultType(typeNameInTemplatePair)) 
				{
					return null;
				}
			}
			
			
			if (CompilerHelper.IsDefaultType(fullName, compiler)) {
				return null;
			}
			try {
				
				//CommonGUI.editText_compiler.getCompiler().data.listOfBuild1OrPart.addTolistOfBuild1OrPart(fullName);
				
				//if (CompilerHelper.exists(CompilerStatic.mlistOfAllClasses,fullName)==false) {
				// 클래스 캐시를 확인한다.
				FindClassParams classParams = ClassCache.getFindClassParams(CompilerStatic.mlistOfAllClassesHashed[coreThreadID], fullName);
				
				if (classParams==null) { // 캐시에 없으면
					String fullNameExceptTemplate = TemplateBase.getTemplateOriginalType(fullName);
					
					String shortName = CompilerStatic.getShortName(fullNameExceptTemplate);
					if (shortName.equals("HighArray_char")) {
					}
					FindClassParams r = null;
					
					try {
						//if (!startsByJava(fullNameExceptTemplate)) {
						r = Loader.loadClassFromCompilerCache(fullNameExceptTemplate);
						if (r!=null) {
							if (!r.hasInherited) {
								r.compiler.compilerStack.FindMembersInherited(r, coreThreadID);
							}
							return r;
						}
						
							String classPath = Loader.getClassPath(fullNameExceptTemplate);
							if (classPath!=null) {
								r = Loader.loadClass_ClassLoader(compiler, classPath, typeNameInTemplatePair, 
										fullNameIncludingTemplateExceptArray, false, coreThreadID);
								
							}
							if (r!=null) {
								if (!r.hasInherited) {
									r.compiler.compilerStack.FindMembersInherited(r, coreThreadID);
								}
								return r;
							}
							else {
								r = Loader.loadClassFromSrc_onlyInterface(fullName, coreThreadID);
								if (r!=null) {
									if (!r.hasInherited) {
										r.compiler.compilerStack.FindMembersInherited(r, coreThreadID);
									}
									return r;
								}
							}
						//}
					}catch(Exception e) {
						if (Common_Settings.g_printsLog) e.printStackTrace();
						
					}
					
					// 클래스 파일 로드가 이미 실패했다면
					//if (ClassLoader.failedLoadingAlready(fullNameExceptTemplate)) {
					//	return null;
					//}
					
					
					String classPath = null;
					classPath = Loader.getClassPath(fullNameExceptTemplate);
					
					if (classPath==null) return null;
									
					// 클래스 파일을 로드한다.
					// 클래스 파일 로드가 실패하면 실패 리스트(failedLoadingAlready())에 등록한다.
					//PathClassLoader loader = new PathClassLoader(classPath, typeNameInTemplatePair, fullName, false);
					
					
					r = loadClass_ClassLoader(compiler, classPath, typeNameInTemplatePair, 
							fullNameIncludingTemplateExceptArray, false, coreThreadID);
					if (r!=null && !r.hasInherited) {
						r.compiler.compilerStack.FindMembersInherited(r, coreThreadID);
					}
					return r;
					
					
				}
				else { // 캐시에 있으면
					if (!classParams.hasInherited) {
						classParams.compiler.compilerStack.FindMembersInherited(classParams, coreThreadID);
					}
					return classParams;
				}
				
			}catch(Exception e) {
				try{
				Log.e("error", e.getMessage());
				}catch(Exception e2) {}
				//if (Common_Settings.g_printsLog) e.printStackTrace();
				//CompilerHelper.printStackTrace(textViewLogBird, e);
			}
		//}// synchronized (System.out) {
		return null;
	}
	
	static FindClassParams loadClassFromCompilerCache(String fullNameExceptTemplate) {
		/*String fullNameSlash = fullNameExceptTemplate.replace('.', File.separatorChar);
		String path = Common_Settings.pathProjectSrc + File.separator + fullNameSlash;
		String srcPath = Loader.getSourceFilePath(path);
		
		if (srcPath!=null) {*/
			//Compiler compiler = CompilerCache.findCompiler(srcPath);
		Compiler compiler = CompilerCache.findCompilerWithfullClassName(fullNameExceptTemplate);
			if (compiler==null) return null;
			if (!compiler.data.isModified) {
				int i;
				ArrayListIReset list = compiler.data.mlistOfAllDefinedClasses;
				for (i=0; i<list.count; i++) {
					FindClassParams c = (FindClassParams) list.getItem(i);
					if (c.name.equals(fullNameExceptTemplate)) {
						return c;
					}
				}
			}
			else {
				HighArray_CodeChar input = InterfaceErrorResolver.toHighArray_CodeChar(compiler.data.textArray);
				InterfaceErrorResolver.analyzeSyntax_update(compiler, input);
				
				int i;
				ArrayListIReset list = compiler.data.mlistOfAllDefinedClasses;
				for (i=0; i<list.count; i++) {
					FindClassParams c = (FindClassParams) list.getItem(i);
					if (c.name.equals(fullNameExceptTemplate)) {
						return c;
					}
				}
			}
		//}
		return null;
	}
	
	
	public static FindClassParams loadClass_ClassLoader(Compiler compiler, 
			String classPath, String typeNameInTemplatePair, String fullNameIncludingTemplateExceptArray, 
			boolean readsCode, int coreThreadID) {
		//synchronized (SynchronizedObjects.lockForMultiThreadBuild) {
			try {
				if (fullNameIncludingTemplateExceptArray==null || fullNameIncludingTemplateExceptArray.equals("")) return null;
				if (classPath==null) return null;
				
				
				ClassLoader loader = null;
				
				String fullNameExceptTemplate = TemplateBase.getTemplateOriginalType(fullNameIncludingTemplateExceptArray);
				if (fullNameExceptTemplate==null || fullNameExceptTemplate.equals("")) return null;
				
				if (loader==null || loader.classParams==null) {
					loader = new ClassLoader(classPath, typeNameInTemplatePair, fullNameIncludingTemplateExceptArray, false, coreThreadID);
					if (loader!=null && loader.classParams!=null) {
						
						//ClassCache.addClassToClassCache(loader.classParams, coreThreadID);
						ClassCache.putToClassCache(loader.classParams, coreThreadID);
						
						String messagePath = null;
						// prints "YYY class file loaded by the system class loader." message to LogView
						if (classPath.indexOf(Common_Settings.pathAndroid)==0) {
							messagePath = "<gsoft>"+File.separator+classPath.substring(Common_Settings.pathAndroid.length()+1, classPath.length());
						}
						else if (classPath.indexOf(Common_Settings.pathOutput)==0) {
							messagePath = "<output>"+File.separator+classPath.substring(Common_Settings.pathOutput.length()+1, classPath.length());
						}
						else if (classPath.indexOf(Common_Settings.pathOther_Lib)==0) {
							messagePath = "<other_lib>"+File.separator+classPath.substring(Common_Settings.pathOther_Lib.length()+1, classPath.length());
						}
						if (messagePath!=null) {
							CodeString message = new CodeString(messagePath, Common_Settings.docuCommentColor);
							message = message.concate(new CodeString(" loaded ", Common_Settings.textColor));
							message = message.concate(new CodeString("by the system class loader.\n", Common_Settings.commentColor));
							
							CompilerHelper.printMessage(CommonGUI.textViewLogBird, message);
						}
						return loader.classParams;
					}
				}// if (loader==null || loader.classParams==null) {
				
				if (loader==null || loader.classParams==null) {
					//if (!Loader.startsByJava(fullNameExceptTemplate)) {
						try {
							loader = new PathClassLoader(/*new Compiler(),*/ classPath, typeNameInTemplatePair, 
									fullNameIncludingTemplateExceptArray, true, coreThreadID);
							if (loader!=null && loader.classParams!=null) {
								
								//ClassCache.addClassToClassCache(loader.classParams, coreThreadID);
								ClassCache.putToClassCache(loader.classParams, coreThreadID);
								
								// prints "YYY class file loaded." message to LogView
								CodeString message = new CodeString(fullNameExceptTemplate, Common_Settings.funcUseColor);
								message = message.concate(new CodeString(" class file loaded.\n", Common_Settings.textColor));
								CompilerHelper.printMessage(CommonGUI.textViewLogBird, message);
								
								return loader.classParams;
							}
						}catch(Throwable e) {
									
						}
					//}
				}//if (loader==null || loader.classParams==null) {
				
				
				/*
				if (loader!=null && loader.classParams!=null) {					
					boolean found = false;
					int i;
					//if (Common_Settings.settings.usesClassCache) {
						for (i=0; i<CompilerStatic.mlistOfAllClasses[coreThreadID].count; i++) {
							FindClassParams c = (FindClassParams) CompilerStatic.mlistOfAllClasses[coreThreadID].getItem(i);
							if (c==null) continue;
							if (c.name.equals(loader.classParams.name)) {
								found = true;
								break;
							}
						}
						
						if (!found) {
							// 새로 추가한다.
							ClassCache.addClassToClassCache(loader.classParams, coreThreadID);
						}
					//}
					
					return loader.classParams;
				}*/
			}catch(Exception e) {
				if (Common_Settings.g_printsLog) e.printStackTrace();
			}
		//}
		return null;
	}
	
	
	/**fullNameExceptTemplate이 java.lang.String과 같이 java. 혹은 javax.으로 시작하면 true를 리턴한다.*/
	static boolean startsByJava(String fullNameExceptTemplate) {
		
		if (fullNameExceptTemplate.length()>=5 &&
				fullNameExceptTemplate.charAt(0)=='j' && fullNameExceptTemplate.charAt(1)=='a' &&
				fullNameExceptTemplate.charAt(2)=='v' && fullNameExceptTemplate.charAt(3)=='a' &&
				fullNameExceptTemplate.charAt(4)=='.') {
			// java.
			return true;
		}
		if (fullNameExceptTemplate.length()>=6 &&
				fullNameExceptTemplate.charAt(0)=='j' && fullNameExceptTemplate.charAt(1)=='a' &&
				fullNameExceptTemplate.charAt(2)=='v' && fullNameExceptTemplate.charAt(3)=='a' &&
				fullNameExceptTemplate.charAt(4)=='x' && fullNameExceptTemplate.charAt(5)=='.') {
			// javax.
			return true;
		}
		return false;
	}





	static String getClassPath(String fullNameExceptTemplate) {
		String slashedFullName = fullNameExceptTemplate.replace('.', File.separatorChar);
		String classPath = null;
		int k;
		// Control.pathAndroid와 janeSoft/output에서 읽는다.
		int[] arrMode = {0, 1, 3};
		for (k=0; k<arrMode.length; k++) {
			File file = CompilerStatic.getAbsPath_FromVariousClassPath(arrMode[k], slashedFullName);
			if (file==null) continue;
			classPath = file.getAbsolutePath();
			
			if (classPath!=null) break;
		}
		return classPath;
	}
	
		
	
	/** 외부소스파일을 링크하여 인터페이스만 얻을때 호출한다. 
	 * 이럴 경우 main함수 역할을 한다.
	 * loadClassFromSrc_onlyInterface()에서 호출한다.
	 * @param compiler : CompilerHelper의 loadClassFromSrc_onlyInterface()에서 
	 * compiler.start_onlyInterface(...) 이렇게 호출이 되므로 
	 * start_onlyInterface()내부의 this나 this가 없는 
	 * Compiler클래스의 멤버 사용은 compiler(호출오브젝트)의 멤버사용이므로 없어도 되는 것이다.
	 * 
	 * addsNewly가 true일 경우 즉 getSourceFilePath()에서 소스파일을 찾지 못해서
	 * getSourceFilePathAddingComGsoftCommon()으로 소스파일을 찾게 된 경우
	 * fullName에서 com.gsoft.common을 제거한 이름을 새로운 fullName으로 한다.
	 * 즉 새로이 제공된 소스파일에 있는 클래스로 클래스파일을 읽기 실패한 클래스를 대체하게 된다.
	 * fullName이 com.gsoft.common.java.lang.String일 경우 새로운 fullName은 java.lang.String이 된다.
	 *  @param fullNameIncludingTemplateExceptArray : 클래스가 템플릿 클래스일 경우 템플릿 타입 이름을 포함하고 배열은 포함하지 않은 클래스 풀 이름이다.
	 *  */
	public static void start_onlyInterface(Compiler compiler, HighArray_char input, Language lang, 
			String fullNameIncludingTemplateExceptArray, String filename, int coreThreadID) {
		
		//synchronized (SynchronizedObjects.lockForMultiThreadBuild) {
			compiler.data.filename = filename;
			compiler.data.language = lang;
			compiler.data.textFormat = FileHelper.getTextFormat(filename);
			
			String fullname = fullNameIncludingTemplateExceptArray;
			
		
			
			// 클래스가 템플릿 클래스일 경우 템플릿 타입 이름을 포함하고 배열은 포함하지 않은 클래스 풀 이름이다.
			fullname = Array.getArrayElementType(fullname);
			
			String fullname_backup = fullname;
			
			
					
			try {
				
				
				compiler.data.strInput = new HighArray_CodeChar(input, Common_Settings.textColor);
				
				
				compiler.data.mBuffer = new StringTokenizer().ConvertToStringArray2(compiler.data.strInput, 10000, compiler.data.language);
				compiler.data.mBuffer.name = filename;
				
				try {
					compiler.compilerStack.findAnnotation(compiler.data.mBuffer, 0, compiler.data.mBuffer.count-1);
					
					compiler.compilerStack.core.findNewLines(0, compiler.data.mBuffer.count-1);
				}catch(Exception e) {
					if (Common_Settings.g_printsLog) e.printStackTrace();
					if (Common_Settings.g_printsLog) CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
				}
			
				compiler.compilerStack.setLanguage(lang);
			
				//compiler.packageName = "";
				compiler.data.packageName = null;
				compiler.data.mlistOfClass.reset2();
				
				compiler.compilerStack.RegisterPackageName(compiler.data.mBuffer);
			
				
				compiler.compilerStack.RegisterImportedClasses(compiler.data.mBuffer);
				
				compiler.compilerStack.loadImportStar(coreThreadID);
				//FindAllClassesAndItsMembers2(mBuffer, 0, mBuffer.count-1, mlistOfClass, lang);
				
				try {
					//compiler.mlistOfAllVarUsesHashed = new Hashtable2_String(50, 20);
						
					compiler.compilerStack.core.FindAllClassesAndItsMembers2_sub(0, compiler.data.mBuffer.count-1, 
							compiler.data.mlistOfClass, ModeAllOrUpdate.All,
							true, null, coreThreadID, true);
				}catch(Exception e) {
					if (Common_Settings.g_printsLog) e.printStackTrace();
					if (Common_Settings.g_printsLog) CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
				}
				
				for (int i=0; i<compiler.data.mlistOfAllDefinedClasses.count; i++) {
					FindClassParams c = (FindClassParams) compiler.data.mlistOfAllDefinedClasses.getItem(i);
					c.loadWayOfFindClassParams = LoadWayOfFindClassParams.Start_OnlyInterface;
				}
								
				
				compiler.setClassNamesAndCreateConstructors(coreThreadID);
				
				
				/*FindClassParams classParams0 = (FindClassParams) compiler.data.mlistOfClass.getItem(0);
				if (classParams0==null) {
					return;
				}
				String shortName = CompilerHelper.getShortName(classParams0.name);*/
				
				boolean b = compiler.checkFilename(compiler.data.packageName);
				if (!b) return;
				
				ClassCache.setClassCache(compiler, ModeAllOrUpdate.All, coreThreadID);
				
				
				
				/*
				for (int i=0; i<compiler.data.mlistOfAllDefinedClasses.count; i++) {
					FindClassParams c = (FindClassParams) compiler.data.mlistOfAllDefinedClasses.getItem(i);
					c.loadWayOfFindClassParams = LoadWayOfFindClassParams.Start_OnlyInterface;
					if (c.name==null) {
						String fullName2;
						if (!c.isEventHandlerClass) {
							String fullNameExceptPackageName1 = Fullname.getFullNameExceptPackageName(compiler.data.mBuffer, c);
							String fullNameExceptPackageName2 = fullNameExceptPackageName1.substring(0, fullNameExceptPackageName1.length()-1);
							if (compiler.data.packageName!=null) {
								fullName2 = compiler.data.packageName + "." + fullNameExceptPackageName2;
							}
							else {
								fullName2 = fullNameExceptPackageName2;
							}
						}
						else {  // event Handler 클래스
							fullName2 = Fullname.getFullNameType(compiler, c.startIndexOfEventHandlerName(), c.endIndexOfEventHandlerName(), coreThreadID) + 
									"_EventHandler";
						}
						c.name = fullName2;
						if (!(c.isInterface || c.accessModifier.isAbstract)) {
							CompilerHelper.makeNoneStaticDefaultConstructorIfConstructorNotExist(compiler, c);
						}
						
						if (!(c.isInterface)) {
							// static 필드가 있으면 추상클래스도 static 생성자를 만들어야 한다.					
							if (CompilerHelper.requiresStaticConstructor(c)) {
								CompilerHelper.makeStaticDefaultConstructorIfStaticConstructorNotExist(compiler, c);
							}
						}
					}
				}
				
				// fullNameIncludingTemplateExceptArray이 HighArray<FindVarUseParams>일 경우
				// 템플릿 클래스의 typeNameToChange을 적용시켜 바꿔준다.
				
				
				int i, j;		
				try {
				// 외부라이브러리처럼 클래스의 name을 fullname으로 정해준다.
				// mlistOfAllClasses이 static이므로 mlistOfAllDefinedClasses안의 클래스들을 대상으로 한다.
				// 즉, 여러 파일을 load할 경우 src가 달라지는 문제가 발생할 수 있다.
				for (i=0; i<compiler.data.mlistOfAllDefinedClasses.count; i++) {
					FindClassParams c = (FindClassParams) compiler.data.mlistOfAllDefinedClasses.getItem(i);
										
					if (c.name.equals(fullnameExceptTemplate)) {
						if (c.template!=null) {
							if (fullNameIncludingTemplateExceptArray.contains("<")) {
								if (fullNameIncludingTemplateExceptArray.equals("com.gsoft.common.Util.HighArray<java.lang.String>")) {
								}
								c.name = fullNameIncludingTemplateExceptArray;
							}
						}
					}
					
					
					
					if (CompilerStatic.getShortName(c.name).equals("HighArray_char")) {
					}
					// 여기서 mlistOfAllClasses에 넣어준다. 
					// import한 기존 클래스가 아니라 새로 읽어들인 클래스로 바꿔준다.
					boolean found = false;
					//if (Common_Settings.settings.usesClassCache) {
						for (j=0; j<CompilerStatic.mlistOfAllClasses[coreThreadID].count; j++) {
							FindClassParams classParams = (FindClassParams) CompilerStatic.mlistOfAllClasses[coreThreadID].getItem(j);
							if (classParams==null) continue;
							if (classParams.name.equals(c.name)) {
								if (c.template!=null && c.name.equals(fullNameIncludingTemplateExceptArray)) {
									// 캐시에 없는 템플릿 클래스일 경우 캐시에 이름이 중복된 클래스가 있더라도 <>안 타입이 다르게 되므로
									// 대체를 해서는 안되고 새로 넣어야 한다.
									// fullNameIncludingTemplateExceptArray이 HighArray<FindVarUseParams>일때
									// c는 HighArray클래스가 된다.
									found = false;
									break;
								}
								else {
									if (classParams.loadWayOfFindClassParams==null ||
										classParams.loadWayOfFindClassParams==LoadWayOfFindClassParams.None ||
										classParams.loadWayOfFindClassParams==LoadWayOfFindClassParams.ByteCode) {
										// 주석이 나오게 된다.
										ClassCache.replaceClassInClassCache(j, c, coreThreadID);
										found = true;
									}
									else {
										// 캐시에 이미 존재하는 템플릿이 아닌 일반 클래스 또는 원하는 템플릿 클래스가 아닌 <>안 타입이 정해지지않은 템플릿 클래스
										found = true;
										break;
									}
								}
							}
						}//for (j=0; j<mlistOfAllClasses.count; j++) {
						
						
						if (!found) {
							ClassCache.addClassToClassCache(c, coreThreadID);
						}
					//}
				}//for (i=0; i<mlistOfAllDefinedClasses.count; i++) {
				*/
				
				int i;
				
				ArrayListString result = new ArrayListString(50);
				result.resizeInc = 200;
				compiler.compilerStack.core.FindClassesFromTypeDecls(compiler, result, coreThreadID);
				
				for (i=0; i<compiler.data.mlistOfAllDefinedClasses.count; i++) {
					FindClassParams classParams = (FindClassParams) compiler.data.mlistOfAllDefinedClasses.getItem(i);
					if (classParams.template!=null) {
						TemplateBase.applyTypeNameToChangeToTemplateClass(compiler, classParams, classParams.name, (byte)0);
					}
				}
				
				
				for (i=0; i<compiler.data.mlistOfAllDefinedClasses.count; i++) {
					FindClassParams c = (FindClassParams) compiler.data.mlistOfAllDefinedClasses.getItem(i);
					if (c.name.equals(fullNameIncludingTemplateExceptArray)) {
						if (c.template!=null) {
							if (fullNameIncludingTemplateExceptArray.contains("<")) {
								//c.name = fullNameIncludingTemplateExceptArray;
								TemplateBase.applyTypeNameToChangeToTemplateClass(compiler, c, fullNameIncludingTemplateExceptArray, (byte)1);
								//c.appliedInapplyTypeNameToChangeToTemplateClass = true;
							}
						}
					}
				}
				
				if (fullname_backup.contains("FindClassParams")) {
				}
				
				
				// 같은 파일에 정의된 클래스들의 이름이 fullname으로 확실하게 정한 이후에 상속한다.
				/*for (i=0; i<compiler.data.mlistOfAllDefinedClasses.count; i++) {
					FindClassParams c = (FindClassParams) compiler.data.mlistOfAllDefinedClasses.getItem(i);
					// 파일에서 정의하는 클래스만 상속, 외부 클래스들은 loadClass에서 상속한다. 
					if (c.name.contains("FindClassParams")) {
						int a;
						a=0;
						a++;
					}					
					// loadsOnlyIt이 아닌 일반적인 경우
					compiler.FindMembersInherited(c);
				}*/
				
				//defineTypeName_OnlyInterface(compiler, compiler.mBuffer);
				
				
				}catch(Exception e) {
					if (Common_Settings.g_printsLog) e.printStackTrace();
					if (Common_Settings.g_printsLog) CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
				}
				
			
		//}
	}
	
	/** fullName을 가지는 클래스가 캐시에 등록되어 있는지를 먼저 확인하고 없으면
	 * 자바(.java) 소스 파일을 읽어서 클래스와 그것의 필드와 메소드들의 타입을 정하고 클래스 캐시에 등록하고 상속도 하여
	 * 그 클래스의 FindClassParams을 리턴한다.
	 * @param fullClassNameIncludingTemplateExceptArray : 클래스가 템플릿 클래스일 경우 템플릿 타입 이름을 포함하고 배열은 포함하지 않은 클래스 풀 이름이다.
	 * 
	 * @return
	 */
	public static Compiler loadClassFromSrc_onlyInterfaceForCompiler(String fullNameIncludingTemplateExceptArray, int coreThreadID) {
		//synchronized (SynchronizedObjects.lockForMultiThreadBuild) {
			FindClassParams classParams = 
					ClassCache.getFindClassParams(CompilerStatic.mlistOfAllClassesHashed[coreThreadID], fullNameIncludingTemplateExceptArray);
			
			if (classParams==null) {
				
				Compiler compiler = Loader.loadClassFromSrc_onlyInterface_sub(fullNameIncludingTemplateExceptArray, coreThreadID);
				
				
					
				return compiler;
				//FindClassParams r = (FindClassParams) compiler.mlistOfClass.list[0]; 
				//return r;
			}
			else {		// 캐시에 있으면		
				return classParams.compiler;
			}
		//}
	}
	
	
	/** fullName을 가지는 클래스가 캐시에 등록되어 있는지를 먼저 확인하고 없으면
	 * 자바(.java) 소스 파일을 읽어서 클래스와 그것의 필드와 메소드들의 타입을 정하고 클래스 캐시에 등록하고 상속도 하여
	 * 그 클래스의 FindClassParams을 리턴한다.
	 * @param fullClassNameIncludingTemplateExceptArray : 클래스가 템플릿 클래스일 경우 템플릿 타입 이름을 포함하고 배열은 포함하지 않은 클래스 풀 이름이다.
	 * 
	 * @return
	 */
	public static FindClassParams loadClassFromSrc_onlyInterface(String fullNameIncludingTemplateExceptArray, int coreThreadID) {
		//synchronized (SynchronizedObjects.lockForMultiThreadBuild) {
			
			
			
			FindClassParams classParams = ClassCache.getFindClassParams(CompilerStatic.mlistOfAllClassesHashed[coreThreadID], 
					fullNameIncludingTemplateExceptArray);
			
			if (classParams==null) {
				
				Compiler compiler = loadClassFromSrc_onlyInterface_sub(fullNameIncludingTemplateExceptArray, coreThreadID);
				
				if (compiler==null || compiler.data.mlistOfAllDefinedClasses==null) {
					//CompilerHelper.printMessage(CommonGUI.textViewLogBird, "Can't read class "+fullNameIncludingTemplateExceptArray+"\n");
					return null;
				}
				
				int i;
				for (i=0; i<compiler.data.mlistOfAllDefinedClasses.count; i++) {
					FindClassParams c = (FindClassParams) compiler.data.mlistOfAllDefinedClasses.getItem(i);
					if (c.name.equals(fullNameIncludingTemplateExceptArray)) {
						return c;
					}
				}
				
				if (compiler.data.mlistOfAllDefinedClasses.count==1) {
					FindClassParams c = (FindClassParams) compiler.data.mlistOfAllDefinedClasses.getItem(0);
					return c;
				}
					
				return null;
			}
			else {		// 캐시에 있으면
				return classParams;
			}
		//}// synchronized (System.out) {
	}
	
	
	static Compiler loadClassFromSrc_onlyInterface_sub(String fullNameIncludingTemplateExceptArray, int coreThreadID) {
		//synchronized (SynchronizedObjects.lockForMultiThreadBuild) {
			//Compiler cachedCompiler = HavaLoadedAlready(fullNameIncludingTemplateExceptArray);
			//if (cachedCompiler!=null) return cachedCompiler;
			
			com.gsoft.common.compiler.Compiler_types.Language lang = com.gsoft.common.compiler.Compiler_types.Language.Java;
			
			String fullName = fullNameIncludingTemplateExceptArray;
		
			
			//클래스가 템플릿 클래스일 경우 템플릿 타입 이름을 포함하고 배열은 포함하지 않은 클래스 풀 이름이다.
			fullName = Array.getArrayElementType(fullName);
			
			String fullNameExceptTemplate = TemplateBase.getTemplateOriginalType(fullName);
			
			
			
			if (CompilerHelper.IsDefaultType(fullNameExceptTemplate)) {
				return null;
			}
			
			int i;
			Compiler compiler = null;
			
			
			String fullNameSlash = fullNameExceptTemplate.replace('.', File.separatorChar);
			String path = Common_Settings.pathProjectSrc + File.separator + fullNameSlash;
			String srcPath = Loader.getSourceFilePath(path);
			
			if (srcPath==null) {
				CompilerHelper.printMessage(CommonGUI.textViewLogBird, "Can't read a class : " + fullNameExceptTemplate+"\n");
				return null;
			}
			
			compiler = ClassCache.findCompiler(srcPath, coreThreadID);
			
			if (compiler==null) {
				compiler = new CompilerInterface();
			
				Log.e("Trys to read its source file : ", srcPath+"\n");
				CompilerHelper.printMessage(CommonGUI.textViewLogBird, "Trys to read its source file : " + srcPath+"\n");
				
				
				CommonGUI.loggingForMessageBox.setText(true, "loadClassFromSrc_onlyInterface()-"+fullName, false);
				CommonGUI.loggingForMessageBox.setHides(false);
				
							
				ReturnOfReadString input = IO.readString(srcPath);
				
				Loader.start_onlyInterface(compiler, input.result, lang, fullName, srcPath, coreThreadID);
				
				// 리소스를 해제한다.
				//input = null;
			}
			
			
			for (i=0; i<compiler.data.mlistOfAllDefinedClasses.count; i++) {
				FindClassParams c = (FindClassParams) compiler.data.mlistOfAllDefinedClasses.getItem(i);
				if (c.name.equals(fullName)) {
					return compiler;
				}
			}
					
			return null;
		//}
	}
	
	
	/**리턴시에는 ".class"가 붙는다. 
	 * @param classPath : 디렉토리가 포함된 파일이름이므로 확장자가 아닌 
	 * 디렉토리 구분자는 File.separatorChar이므로 확장자 외에 '.'이 있어서는 안된다. 
	 * 내부클래스를 표시하는 '$'이 있을수는 있다. 
	 * */
	public static String fixClassPath(String classPath) {
		classPath = FileHelper.getFilenameExceptExt(classPath);
		
		String path = classPath;
		int separator=0;
		boolean r=false;
		
		while (separator!=-1) {
			separator = indexOf(classPath, separator, File.separatorChar);
			if (separator==-1) {
				path = classPath + ".class";
				r = isFileExist(path);
				break;
			}
			
			path = classPath.substring(0, separator+1);
			
			r = isFileExist(path);
			
			if (r) {
				String remainder=null;
				try {
				remainder = classPath.substring(separator+1, classPath.length());
				
				remainder = remainder.replace(File.separatorChar, '$');
				path = path + remainder + ".class";
				}catch(Exception e) {
					if (Common_Settings.g_printsLog) e.printStackTrace();
					CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
				}
				boolean r2 = isFileExist(path);
				if (r2)	break;
			}
			/*if (r==false) {
				String remainder=null;
				try {
				remainder = classPath.substring(separatorOld+1, classPath.length());
				
				remainder = remainder.replace(File.separatorChar, '$');
				path = classPath.substring(0, separatorOld+1) + remainder + ".class";
				}catch(Exception e) {
					if (Common_Settings.g_printsLog) e.printStackTrace();
					CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
				}
				r = isFileExist(path);
				break;
			}*/
			
			separator++;
		}
		if (r)  return path;
		else return null;
	}
	
	
	/**jarFilePath에서 classPath라는 파일이나 디렉토리를 찾아 경로를 수정하여 리턴한다.
	 * 리턴시에는 ".class"가 붙는다. 
	 * @param classPath : 디렉토리가 포함된 파일이름이므로 확장자가 아닌 
	 * 디렉토리 구분자는 File.separatorChar이므로 확장자 외에 '.'이 있어서는 안된다. 
	 * 내부클래스를 표시하는 '$'이 있을수는 있다. ".class"가 붙어도 되고 안 붙어도 안된다.
	 * */
	public static String fixClassPath(String jarFilePath, String classPath) {
		classPath = FileHelper.getFilenameExceptExt(classPath);
		
		String path = classPath;
		int separator=0;
		boolean r=false;
		
		while (separator!=-1) {
			separator = indexOf(classPath, separator, File.separatorChar);
			if (separator==-1) {
				path = classPath + ".class";
				r = isFileExist(jarFilePath, path);
				break;
			}
			
			path = classPath.substring(0, separator+1);
			
			r = isFileExist(jarFilePath, path);
			
			if (r) {
				
				String remainder=null;
				try {
				remainder = classPath.substring(separator+1, classPath.length());
				
				remainder = remainder.replace(File.separatorChar, '$');
				path = path + remainder + ".class";
				}catch(Exception e) {
					if (Common_Settings.g_printsLog) e.printStackTrace();
					CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
				}
				boolean r2 = isFileExist(jarFilePath, path);
				if (r2)	{
					break;
				}
			}
			/*if (r==null) {
				String remainder=null;
				try {
				remainder = classPath.substring(separatorOld+1, classPath.length());
				
				remainder = remainder.replace(File.separatorChar, '$');
				path = classPath.substring(0, separatorOld+1) + remainder + ".class";
				}catch(Exception e) {
					if (Common_Settings.g_printsLog) e.printStackTrace();
					CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
				}
				r = isFileExist(jarFilePath, path);
				break;
			}*/
			
			separator++;
		}
		if (r)  return path;
		else return null;
	}
	
	/** /mnt/sdcard/project_src/com/gsoft/common/gui/control/container에서 
	 * 소스파일부분은 /mnt/sdcard/project_src/com/gsoft/common/gui/control이다. 
	 * path에서 뒤에 확장자는 붙이지 않는다.*/ 
	public static String getSourceFilePath(String path) {
		// /mnt/sdcard/project_src/com/gsoft/common/gui를 얻는다.
		
		if (path.contains("android\\view\\View")) {
		}
		String dir = getDirectory(path);
		if (dir==null) return null;
		int indexStart = dir.length()+1; ///mnt/sdcard/project_src/com/gsoft/common/gui/의 길이
		int indexSrcFile = path.indexOf(File.separator, indexStart);
		String r;
		if (indexSrcFile!=-1) {			
			r = path.substring(0, indexSrcFile);
			//  /mnt/sdcard/project_src/com/gsoft/common/gui/control
		}
		else {
			r = path;
		}
		
		String rIncludeingJava = r + ".java";
		
		if (isFileExist(rIncludeingJava)) {
			return r + ".java"; 
		}
		// /mnt/sdcard/project/com/gsoft/common/Encoding/EncodingFormatException.java는 존재하지 않는다.
		
		int separator = r.length();
		String javaPath, javaPathExceptExt;
		// 만약에 /mnt/sdcard/project/com/gsoft/common/Encoding/EncodingFormatException/InnerClass2가
		// /mnt/sdcard/project/com/gsoft/common/Encoding.java라는 소스 파일이 있다면 
		// 루프를 통해서 그 소스파일이 존재하는지를 확인해야 한다.
		while (true) {
			separator = indexOf(r, separator-1, File.separatorChar, true);
			if (separator==-1) return null;
			javaPathExceptExt = r.substring(0, separator);
			javaPath = javaPathExceptExt + ".java";
			
			if (isFileExist(javaPath)) {
				return javaPathExceptExt + ".java"; 
			}
			
		}
	}
	
	
	
	
	/** /mnt/sdcard/gsoft/com/gsoft/common/Util에서 디렉토리부분은 /mnt/sdcard/gsoft/com/gsoft/common이다.*/ 
	public static String getDirectory(String path) {
		String originalPath = new String(path);
		int separator=0;
		int separatorOld=0;
		boolean r=false;
		
		r = isDirectory(path);
		if (r) {
			return path;
		}
		
		while (separator!=-1) {
			separator = indexOf(originalPath, separator, File.separatorChar);
			if (separator==-1) {
				r = isDirectory(originalPath);
				if (r) return originalPath;
				else {
					String dir = originalPath.substring(0, separatorOld);
					return dir;
				}
			}
			path = originalPath.substring(0, separator+1);
			r = isDirectory(path);
			if (r) {
				separatorOld = separator;
			}
			else {
				String dir = originalPath.substring(0, separatorOld);
				return dir;
			}
			separator++;
		}
		return null;
	}
	
	/** com.gsoft.common.gui.Control.Container(내부클래스)를 com.gsoft.common.gui.Control로 리턴한다.
	 * CompilerHelper.setJavaClassPathIfNotExists()에서 등록되는 클래스패스에서
	 * Class.forName(fullname) 호출은 원하는 클래스를 찾을 수 있다.*/
	public static String fixFullName(String fullname) {
		int index = fullname.length();
		int startIndex = index-1;
		while (true) {
			try {
				Class.forName(fullname);
				return fullname;
			} catch (ClassNotFoundException e) {
				
				index = indexOf(fullname, startIndex, '.', true);
				if (index==-1) return null;
				fullname = fullname.substring(0, index);
				startIndex = index-1;
				if (fullname==null || fullname.equals("")) return null;
			} 
		}
	}
	
	/** str의 디렉토리구분자는 File.separatorChar이다.*/
	static boolean isFile(String str) {
		File file = new File(str);
		if (file.isFile()) return true;
		return false;
	}
	
	
	
	
	/** str의 디렉토리구분자는 File.separatorChar이다.*/
	static boolean isDirectory(String str) {
		File file = new File(str);
		if (file.isDirectory()) return true;
		return false;
	}
	
	static boolean isFileExist(String path) {
		File file = new File(path);
		if (file.exists()) return true;
		else return false;
		
	}
	
	
	
	/** jarFile에서 path라는 파일을 찾는다.*/
	static boolean isFileExist(String jarFilePath, String path) {		
		String jarFilePathExceptExt = FileHelper.getFilenameExceptExt(jarFilePath);
		String pathExceptExt = FileHelper.getFilenameExceptExt(path);
		
		if (jarFilePathExceptExt.contains(pathExceptExt)) return true;
		
		String curDirOfPath = path.substring(0, jarFilePathExceptExt.length());
		if (!jarFilePathExceptExt.equals(curDirOfPath)) return false;
		
		if (path.length()>jarFilePathExceptExt.length() && 
				path.charAt(jarFilePathExceptExt.length())=='$') return false;
		
		if (path.length()==jarFilePathExceptExt.length()+1 && 
				path.substring(0, jarFilePathExceptExt.length()).equals(jarFilePathExceptExt))
			return true;
		
		String relativeFileName = path.substring(jarFilePathExceptExt.length()+1, path.length());
		
		if (relativeFileName.equals("com\\gsoft\\")) {
		}
		
		
		return Util.JarFile.exists(jarFilePath, relativeFileName);
		
	}
	
	static int indexOf(String str, int startIndex, char c) {
		int i;
		for (i=startIndex; i<str.length(); i++) {
			if (str.charAt(i)==c) {
				return i;
			}
		}
		return -1;
	}
	
	/** str을 역방향으로 startIndex부터 시작하여 c를 찾아 그 인덱스를 리턴한다. str의 처음까지 검색해서 못 찾으면 -1을 리턴한다.*/
	static int indexOf(String str, int startIndex, char c, boolean reverse) {
		if (reverse) {
			int i;
			for (i=startIndex; i>=0; i--) {
				if (str.charAt(i)==c) {
					return i;
				}
			}
			return -1;
		}
		return -1;
	}
	
	/**전에 로드를 한 적이 있다면 다시 로드하지 않는다. 
	 * loadClassFromSrc_onlyInterface_sub()에서 클래스 로드 리스트에 등록한다.
	 * @param fullname : 풀 경로 클래스 이름*/
	/*public static Compiler HavaLoadedAlready(String fullname) {
		int i;
		// 전에 로드를 실패한 적이 있다면 다시 로드하지 않는다.
		for (i=0; i<mlistOfLoadClassFromSrc_onlyInterface.count; i++) {
			ItemOfListOfClassesOfLoading item = 
					(ItemOfListOfClassesOfLoading) mlistOfLoadClassFromSrc_onlyInterface.getItem(i);
			if (item.fullname.equals(fullname))
				return item.compiler;
		}
		return null;
	}*/
}
