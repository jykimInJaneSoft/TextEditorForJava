package com.gsoft.common.compiler.classloader;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import android.util.Log;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.CommonGUI;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.FileHelper;
import com.gsoft.common.IO;
import com.gsoft.common.interfaces.IReset;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.CompilerInterface;
import com.gsoft.common.compiler.CompilerStatic;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.Compiler_types.FindFunctionParams;
import com.gsoft.common.compiler.Compiler_types.FindVarParams;
import com.gsoft.common.compiler.Compiler_types.Language;
import com.gsoft.common.compiler.Compiler_types.LoadWayOfFindClassParams;
import com.gsoft.common.compiler.HighArray_CodeString;
import com.gsoft.common.compiler.StringTokenizer;
import com.gsoft.common.compiler.bytecode.ByteCode_Helper;
import com.gsoft.common.compiler.bytecode.ByteCode_Types;
import com.gsoft.common.compiler.bytecode.ByteCode_Types.ByteCodeInstruction;
import com.gsoft.common.compiler.bytecode.ByteCode_Types.ClassFieldMethod;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.Attribute_Info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_Class_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_Double_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_Field_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_Float_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_Integer_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_InterfaceMethod_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_Long_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_Method_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_NameAndTypeDesc_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_String_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.CONSTANT_Utf8_info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.Class_Info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.Field_Info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.Method_Info;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.Verification_Type_info;
import com.gsoft.common.compiler.bytecode.Code_attribute;
import com.gsoft.common.compiler.bytecode.InstructionSet;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListIReset;
import com.gsoft.common.util.ArrayListString;
import com.gsoft.common.util.HighArray_CodeChar;
import com.gsoft.common.util.Util.BufferByte;
import com.gsoft.common.util.hash.Hashtable2_Object;

import com.gsoft.common.compiler.classloader.ClassLoader;
import com.gsoft.common.compiler.classloader.Loader;

public class PathClassLoader extends ClassLoader implements IReset {
	
	
	String absFilename;
	
	ArrayList constantTable;	
	
	short accessFlags;	
	
	
	short[] interfaces;
	Attribute_Info[] attributes_info;
	
	
	private boolean loadsInnerClass = false;

	Field_Info[] fields_info;
	Method_Info[] methods_info;
	

	/** code array 와 Code_Attribute의 속성 
	 * 즉, LineNumberTable, LocalVariableTable, StackMapTable들을 
	 * 읽으면 true, 그렇지 않으면 false
	 */
	public boolean readsCode = false;

	public HighArray_CodeString mBuffer;

	/** big-endian 을 디폴트로 한다.*/
	private boolean IsLittleEndian = false;

	private int coreThreadID;
	
	
	
		
	
	
	/** 해시테이블을 생성해서 instructionSet 을 테이블에 넣는다. 한번만 초기화 가능*/
	static {
		ByteCode_Types.hashTableInstructionSet = new Hashtable2_Object(100, 5);
		int i;
		for (i=0; i<InstructionSet.instructionSet.length; i++) {
			try {
			ByteCodeInstruction instruction = InstructionSet.instructionSet[i];
			ByteCode_Types.hashTableInstructionSet.input(instruction.opcodeHexa, instruction);
			}catch(Throwable e) {
				if (Common_Settings.g_printsLog) e.printStackTrace();
			}
		}
	}
	
	
	
	/** class 와 field, method 와 code array 를 출력하는 스트링을 리턴한다. 
	 * 그리고 mBuffer를 만든다.*/
	public HighArray_CodeChar getText() {
		try {
			HighArray_CodeChar r = new HighArray_CodeChar(1000);
						
		r.add(new CodeString(classParams.toString() + " {\n", Common_Settings.textColor));
		
		
		r.add(new CodeString(ByteCode_Helper.getConstantTableTypesAndContents(constantTable), Common_Settings.commentColor));
		
		
		int i, j;
		for (i=0; i<classParams.listOfVariableParams.count; i++) {
			FindVarParams var = (FindVarParams) classParams.listOfVariableParams.getItem(i);
			r.add(new CodeString("\t" + var.toString() + ";\n", Common_Settings.textColor));
		}
		for (i=0; i<classParams.listOfFunctionParams.count; i++) {
			CommonGUI.showMessage(true, "i : "+i);
			//Thread.sleep(1000);
			if (i==46) {
			}
			FindFunctionParams func = (FindFunctionParams) classParams.listOfFunctionParams.getItem(i);
			if (func.isConstructor) {
			}
			if (func.accessModifier.isAbstract) {
				r.add(new CodeString("\t" + func.toString() + ";\n", Common_Settings.textColor));
				continue;
			}
			r.add(new CodeString("\t" + func.toString() + " {\n", Common_Settings.textColor));
				
			// code 를 출력한다.
			Code_attribute codeAttribute = null;
			if (func.method_Info!=null) {
				for (j=0; j<func.method_Info.attributes_count; j++) {
					if (func.name.equals("main")) {
					}
					Attribute_Info attribute = func.method_Info.attributes[j];
					if (attribute.codeAttribute!=null) {
						codeAttribute = attribute.codeAttribute;
						break;
					}
				}
				try {
					if (codeAttribute!=null) {
						HighArray_CodeChar code = codeAttribute.toCodeString(this.constantTable, IsLittleEndian );
						r.add(code);
					}
				}catch(Exception e) {
					if (Common_Settings.g_printsLog) e.printStackTrace();
				}
			}
			else {
			}
			r.add(new CodeString("\t" + "}\n", Common_Settings.textColor));
		}//for (i=0; i<classParams.listOfFunctionParams.count; i++) {
		// 클래스의 블록 끝
		r.add(new CodeString("}\n", Common_Settings.textColor));
		
		
		//return r;
		
		//CodeChar[] codeChars = r.toArray();
		//CodeString ret = new CodeString(codeChars, codeChars.length);
		mBuffer = new StringTokenizer().ConvertToStringArray2(r, 1000, Language.Java);
		
		//compiler.reset();
		//compiler = null;
		return r;
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
			return null;
		}
	}
	
	
	
	void loadInnerClass(int coreThreadID) throws Exception {
		listOfInnerClasses = new ArrayListIReset(5);
		int i, j;
		for (i=0; i<attributes_info.length; i++) {
			if (attributes_info[i].innerClassesAttribute!=null) {
				Class_Info[] innerClasses = attributes_info[i].innerClassesAttribute.classes;
				for (j=0; j<innerClasses.length; j++) {
					String innerClassName = innerClasses[j].innerClassName;
					String innerClassName2 = innerClassName.replace('/', '.');
					innerClassName2 = innerClassName2.replace('$', '.');
					if (innerClassName2.equals(this.name)) continue;
					
					
					FindClassParams classParams = Loader.loadClass(compiler, innerClassName2, coreThreadID);
					if (classParams!=null)
						listOfInnerClasses.add(classParams);
					
					
					
					
				} // for (j=0; j<innerClasses.length; j++) {
				break;
			} // if (attributes_info[i].innerClassesAttribute!=null) {
			
		}
	}
	
	
	
	/** 클래스 파일을 로드한다. 로드가 실패하면  listOfClassesToFailLoading에 등록되어
	 * boolean failedLoadingAlready(String classPath) 이 함수를 통해 이미 로드가 실패했는지를 확인한다.
	 * @param compiler : 클래스파일을 표현하는 문서 compiler, 
	 * 		클래스파일을 읽기전에 새로운 compiler를 생성해서 호출해야 한다.
	 * @param classPath : 디렉토리상 풀 경로, 확장자 포함*/
	public PathClassLoader(String classPath, String typeNameInTemplatePair, String fullNameIncludingTemplateExceptArray, boolean readsCode, int coreThreadID) {
		super();
		
		if (classPath==null) return;
		
		this.compiler = new CompilerInterface();
		this.compiler.compilerStack.setLanguage(Language.Java);
		//this.compiler = compiler;
		this.compiler.data.filename = classPath;
		FileInputStream stream=null;
		BufferedInputStream bis=null;
		absFilename=null;
		this.typeNameInTemplatePair = typeNameInTemplatePair;
		this.fullNameIncludingTemplateExceptArray = fullNameIncludingTemplateExceptArray;
		this.name = fullNameIncludingTemplateExceptArray;
		this.readsCode = readsCode;
		this.coreThreadID = coreThreadID;
		boolean r = false;
				
		try {
			absFilename = classPath;
			String shortName = FileHelper.getFilename(absFilename);
			if (shortName.equals("interfaces$Listener.class")) {
			}
			stream = new FileInputStream(absFilename);
			//int bufferSize = (int) (FileHelper.getFileSize(absFilename)*IO.DefaultBufferSizeParam);
			bis = new BufferedInputStream(stream/*, bufferSize*/);
			
			readClassFile(bis);
			
			r= true;
		} catch (Throwable sfe) {
			Log.e("can't load class file", classPath);
			CompilerHelper.printMessage(CommonGUI.textViewLogBird, "Can't load class file : " + classPath+ " reason : " + sfe.getMessage()+"\n");
			r = false;
		} 
		finally {
			//IO.IsLittleEndian = true;
			FileHelper.close(bis);
			FileHelper.close(stream);
			if (!r) {
				if (absFilename!=null) {
					//File file = new File(absFilename);
					//file.delete();
				}
			}
		}
	}
	
	
	
	/** inner class는 outer class에서 읽는다.
	 * @throws Exception */
	void readClassFile(InputStream is) throws Exception {
		try {
		// magic number
				
		
		int i;
		byte[] bufMagicNumber = new byte[4];
		
		// CAFEBABE : [-54, -2, -70, -66], 
		is.read(bufMagicNumber);
		
		
		//boolean isLittleEndian = IO.IsLittleEndian;
		//boolean IsLittleEndian = false; // big-endian
		
		short[] bufVersion = new short[2];
		bufVersion[0] = IO.readShort(is, IsLittleEndian);
		bufVersion[1] = IO.readShort(is, IsLittleEndian);
		
		// constant table 을 읽는다.
		short countOfConstantPool = IO.readShort(is, IsLittleEndian);
		byte[] tag = new byte[1];
		
		
		
		ArrayList nameAndTypeDescs = new ArrayList(5);
		
		
		// countOfConstantPool의 값은 constantTable의 엔트리 개수보다 1개 더 많다.
		// constantTable의 인덱스는 0보다 크고(1이상) countOfConstantPool보다 작다(countOfConstantPool-1).
		
		/*ClassFile { 
			u4 magic; // 0xCAFEBABE
			u2 minor_version; 
			u2 major_version; 
			u2 constant_pool_count; //constant_pool의 엔트리수보다 하나 더 많다.
			cp_info constant_pool[constant_pool_count-1]; //constant_pool의 인덱스는 0보다 크고 constant_pool_count보다 하나 작다.
			u2 access_flags; 
			u2 this_class; // CONSTANT_Class_info을 가르키는 constant_pool의 인덱스
			u2 super_class; 
			u2 interfaces_count; 
			u2 interfaces[interfaces_count]; 
			u2 fields_count; 
			field_info fields[fields_count]; 
			u2 methods_count; 
			method_info methods[methods_count]; 
			u2 attributes_count; 
			attribute_info attributes[attributes_count]; 
		}*/
		
		/*cp_info { 
			u1 tag; //Constant pool tags
			u1 info[]; //태그값에 따라 다양하다.
		}*/

		constantTable = new ArrayList(countOfConstantPool);
		
		constantTable.add(new Integer(0)); // constant table 인덱스가 1부터 시작하기 때문이다.
		
		constantTable.count = countOfConstantPool;
		
		Verification_Type_info.constantTable = constantTable; 
		
		
		/*Constant pool tags
		 * Constant Type Value
		  CONSTANT_Class 	7 
		CONSTANT_Fieldref 	9 
		CONSTANT_Methodref 	10 
		CONSTANT_InterfaceMethodref 11 
		CONSTANT_String 	8 
		CONSTANT_Integer 	3 
		CONSTANT_Float	 	4 
		CONSTANT_Long 		5 
		CONSTANT_Double 	6 
		CONSTANT_NameAndType 12 
		CONSTANT_Utf8 		1
		*/
		
			//i = 2; // constant table 인덱스가 1부터 시작하기 때문이다.
		// countOfConstantPool의 값은 constantTable의 엔트리 개수보다 1개 더 많다.
		// constantTable의 인덱스는 0보다 크고 countOfConstantPool보다 작다.
			for (i=1; i<countOfConstantPool; i++) {
				try {
					
					
					is.read(tag);
						
					if (tag[0]==0) {
						//break;
						throw new IOException(this.absFilename + " load error" + " (invalid tag : "+tag[0] + 
							" countOfConstantPool :" + countOfConstantPool + " i :"+i+")");
					}
					
					switch(tag[0]) {
					case 1: // CONSTANT_Utf8_info
						/*CONSTANT_Utf8_info {
							u1 tag; 
							u2 length; // 바이트수
							u1 bytes[length]; //utf-8,  not null-terminated
						}*/
						short numOfBytes = IO.readShort(is, IsLittleEndian);
						byte[] strBuf = new byte[numOfBytes];
						is.read(strBuf);
						BufferByte bufferbyte = new BufferByte(strBuf);
						String str = IO.readStringUTF8(null, bufferbyte).getItems();
						CONSTANT_Utf8_info utf8Info = new CONSTANT_Utf8_info(tag[0], numOfBytes, str);
						constantTable.setItem(i, utf8Info);
						break;
					case 3: // integer
						/*CONSTANT_Integer_info { 
							u1 tag; 
							u4 bytes; // big-endian (high byte first) order
						}*/
						//boolean backupEndian = IO.IsLittleEndian;
						//IO.IsLittleEndian = false;
						int number = IO.readInt(is, IsLittleEndian);
						CONSTANT_Integer_info integerInfo = new CONSTANT_Integer_info(tag[0], number);
						constantTable.setItem(i, integerInfo);
						break;
					case 4: // float
						/*CONSTANT_Float_info { 
							u1 tag; 
							u4 bytes; //IEEE 754 floating point single format
						}*/
						float fNumber = IO.readFloat(is, IsLittleEndian);
						CONSTANT_Float_info floatInfo = new CONSTANT_Float_info(tag[0], fNumber);
						constantTable.setItem(i, floatInfo);
						break;
					case 5: // long
						/*CONSTANT_Long_info { 
							u1 tag; 
							u4 high_bytes; //8bytes
							u4 low_bytes; 
						}*/
						long lNumber = IO.readLong(is, IsLittleEndian);
						CONSTANT_Long_info longInfo = new CONSTANT_Long_info(tag[0], lNumber);
						constantTable.setItem(i, longInfo);
						
						/*All 8-byte constants take up two entries in the constant_pool table of the class
						file. If a CONSTANT_Long_info or CONSTANT_Double_info structure is the item
						in the constant_pool table at index n , then the next usable item in the pool is
						located at index n + 2 . The constant_pool index n + 1 must be valid but is
						considered unusable.*/
						i++;
						break;
					case 6: // double
						/*CONSTANT_Double_info { 
							u1 tag; 
							u4 high_bytes; //8bytes
							u4 low_bytes; 
						}*/
						double dNumber = IO.readDouble(is, IsLittleEndian);
						CONSTANT_Double_info doubleInfo = new CONSTANT_Double_info(tag[0], dNumber);
						constantTable.setItem(i, doubleInfo);
						
						/*All 8-byte constants take up two entries in the constant_pool table of the class
						file. If a CONSTANT_Long_info or CONSTANT_Double_info structure is the item
						in the constant_pool table at index n , then the next usable item in the pool is
						located at index n + 2 . The constant_pool index n + 1 must be valid but is
						considered unusable.*/
						i++;
						break;			
					case 7: // class reference : full name 스트링을 가르키는 인덱스
						/*CONSTANT_Class_info { 
							u1 tag; //CONSTANT_Class (7)
							u2 name_index; // CONSTANT_Utf8_info를 가르키는 constantTable의 인덱스
						}*/
						short classRef = IO.readShort(is, IsLittleEndian);
						CONSTANT_Class_info classInfo = new CONSTANT_Class_info(tag[0], classRef, this.constantTable);
						constantTable.setItem(i, classInfo); //CONSTANT_Class_info의 name_index가 들어간다.
						break;
					case 8: // string reference
						/*CONSTANT_String_info { 
							u1 tag;
							u2 string_index;
						}*/
	
						short stringRef = IO.readShort(is, IsLittleEndian);
						CONSTANT_String_info stringInfo = new CONSTANT_String_info(tag[0], stringRef, this.constantTable);
						constantTable.setItem(i, stringInfo);//CONSTANT_String_info의 string_index가 들어간다.
						break;
					case 9: // field reference
						/*CONSTANT_Fieldref_info { 
							u1 tag; // CONSTANT_Fieldref (9). 
							u2 class_index; // CONSTANT_Class_info을 가르키는 constantTable의 인덱스
							u2 name_and_type_index; //CONSTANT_NameAndType_info 을 가르키는 constantTable의 인덱스
						}*/
						short classRef0 = IO.readShort(is, IsLittleEndian);
						short nameTypeDescRef0 = IO.readShort(is, IsLittleEndian);
						CONSTANT_Field_info field = new CONSTANT_Field_info(classRef0, nameTypeDescRef0, this.constantTable, this);
						//CONSTANT_Fieldref_info의 class_index와 name_and_type_index을 갖는 Field가 들어간다.
						constantTable.setItem(i, field);
						
						break;
					case 10: // method reference
						/*CONSTANT_Methodref_info { 
							u1 tag; //CONSTANT_Methodref (10). 
							u2 class_index; 
							u2 name_and_type_index; 
						}*/
						short classRef1 = IO.readShort(is, IsLittleEndian);
						short nameTypeDescRef1 = IO.readShort(is, IsLittleEndian);
						CONSTANT_Method_info method = new CONSTANT_Method_info(classRef1, nameTypeDescRef1, this.constantTable, this);
						//CONSTANT_Methodref_info의 class_index와 name_and_type_index을 갖는 Method가 들어간다.
						constantTable.setItem(i, method);
						break;
					case 11: // interface method reference
						/*CONSTANT_InterfaceMethodref_info { 
							u1 tag; // CONSTANT_InterfaceMethodref (11)
							u2 class_index; 
							u2 name_and_type_index; 
						}*/
	
						short classRef2 = IO.readShort(is, IsLittleEndian);
						short nameTypeDescRef2 = IO.readShort(is, IsLittleEndian);
						CONSTANT_InterfaceMethod_info interfaceMethod = new CONSTANT_InterfaceMethod_info(
								this, this.constantTable, classRef2, nameTypeDescRef2);
						constantTable.setItem(i, interfaceMethod);
						break;
						
					case 12: // name and type descriptor
						/*CONSTANT_NameAndType_info { 
							u1 tag; 
							u2 name_index; //CONSTANT_Utf8_info을 가르키는 constantTable의 인덱스
							u2 descriptor_index; //CONSTANT_Utf8_info을 가르키는 constantTable의 인덱스
						}*/
	
						short nameRef = IO.readShort(is, IsLittleEndian);
						short typeDesc = IO.readShort(is, IsLittleEndian);
						CONSTANT_NameAndTypeDesc_info nameAndTypeDesc = new CONSTANT_NameAndTypeDesc_info(nameRef, typeDesc, this.constantTable);
						nameAndTypeDescs.add(nameAndTypeDesc);
						constantTable.setItem(i, nameAndTypeDesc);
						break;
					
					}
				}catch (Exception e) {
					if (Common_Settings.g_printsLog) e.printStackTrace();
					CompilerHelper.printMessage(CommonGUI.textViewLogBird, e.getMessage()+" in "+i +" of constant table");
					throw e;
				}
			} //for (i=1; i<countOfConstantPool; i++) {
			
		// SimpleTest2 의 Constant_ pool 아이템 갯수
		// 클래스 1개 : Constant_Class_info 1개 + Constant_utf8_info 1개 = 2
		// 필드 0개 : 0 * (Constant_utf8_info(name+type) 2개) = 0
		// 메서드 4개 : 4 * (Constant_utf8_info(name+type) 2개) = 8
		// 정수 상수 : 0
		// 스트링 상수 : 0
		// 지역변수 5개 : 5 * Constant_utf8_info 2개 = 10
		// 필드 참조 0개 : 0 * (Constant_Field_info 1개 + (Constant_Class_info 1개 + Constant_utf8_info 1개) + Constant_NameAndTypeDesc_info 1개 + (Constant_utf8_info 2개))
		//				= 0 * 6 = 0
		// 메서드 참조 4개 : 0 * (Constant_Method_info 1개 + (Constant_Class_info 1개 + Constant_utf8_info 1개) + Constant_NameAndTypeDesc_info 1개 + (Constant_utf8_info 2개))
		//				= 4 * 6 = 24
		// this : 1
		// Method와 Code Attribute : "Code", "LineNumberTable", "LocalVariableTable"
		//					= 3
		// Attribute : "SourceFile"(2개), "InnerClasses"(3개)
			
			
			// 디버그용
			/* CONSTANT_Class_info--com/gsoft/texteditor14/SimpleTest1$SimpleTest2  
			CONSTANT_Utf8_info--com/gsoft/texteditor14/SimpleTest1$SimpleTest2  
			
			// 디폴트 생성자에서 상속클래스 Object의 static 생성자(<init>)을 호출
			CONSTANT_Class_info--java/lang/Object  
			CONSTANT_Utf8_info--java/lang/Object  
			CONSTANT_Utf8_info--<init>  
			CONSTANT_Utf8_info--()V 			  
			CONSTANT_Method_info--java/lang/Object.Object()  
			CONSTANT_NameAndTypeDesc_info--<init>:()V 
			
			
			// 메서드와 Code Attribute 이름 3개
			CONSTANT_Utf8_info--Code 
			CONSTANT_Utf8_info--LineNumberTable  
			CONSTANT_Utf8_info--LocalVariableTable 
			
			// this 와 this 의 타입
			CONSTANT_Utf8_info--this  
			CONSTANT_Utf8_info--Lcom/gsoft/texteditor14/SimpleTest1$SimpleTest2; 
			
			
			// int test(int arg1, int arg2) 의 시그너쳐와 아규먼트의 타입과 이름
			CONSTANT_Utf8_info--test  
			CONSTANT_Utf8_info--(II)I  
			CONSTANT_Utf8_info--I  
			CONSTANT_Utf8_info--arg1 			
			CONSTANT_Utf8_info--arg2 
			
			// 중복성이 제거된 지역변수 이름과 타입			
			CONSTANT_Utf8_info--r 
			
			
			// int test2(Integer arg1, int arg2) 의 시그너쳐와 아규먼트의 타입과 이름
			CONSTANT_Utf8_info--test2  
			CONSTANT_Utf8_info--(Ljava/lang/Integer;I)I 
			CONSTANT_Utf8_info--Ljava/lang/Integer; 
			
			 
			// arg1.intValue() 메서드 참조(호출)
			CONSTANT_Method_info--int java/lang/Integer.intValue()  
			CONSTANT_Class_info--java/lang/Integer  
			CONSTANT_Utf8_info--java/lang/Integer  
			CONSTANT_NameAndTypeDesc_info--intValue:()I  
			CONSTANT_Utf8_info--intValue  
			CONSTANT_Utf8_info--()I 
			
			 
			// int test(String[] args) 의 시그너쳐와 아규먼트의 타입과 이름			
			CONSTANT_Utf8_info--([Ljava/lang/String;)I 
			CONSTANT_Utf8_info--[Ljava/lang/String; 
			CONSTANT_Utf8_info--args
			
			
			
			
			
			// SimpleTest2 test = new SimpleTest2();
			// 지역변수 SimpleTest2 test 도 중복이므로 생략
			// SimpleTest2()의 CONSTANT_Class_info와 메서드 이름과 type에 관한 CONSTANT_Utf8_info 생략
			CONSTANT_Method_info--com/gsoft/texteditor14/SimpleTest1$SimpleTest2.SimpleTest2() 
			
			 
			 // test(1, 2) 와 test(11, 300) this 메서드 참조(호출)
			 // CONSTANT_Class_info와 메서드 이름과 type에 관한 CONSTANT_Utf8_info 생략
			CONSTANT_Method_info--int com/gsoft/texteditor14/SimpleTest1$SimpleTest2.test(int, int)  
			CONSTANT_NameAndTypeDesc_info--test:(II)I
			
			  
			  
			
			
			// 중복성이 제거된 지역변수 이름과 타입
			CONSTANT_Utf8_info--r2
			
			 
			// SourceFile Attribute
			CONSTANT_Utf8_info--SourceFile  
			CONSTANT_Utf8_info--SimpleTest1.java  
			
			// InnerClasses Attribute
			CONSTANT_Utf8_info--InnerClasses  
			CONSTANT_Class_info--com/gsoft/texteditor14/SimpleTest1  
			CONSTANT_Utf8_info--com/gsoft/texteditor14/SimpleTest1  
			CONSTANT_Utf8_info--SimpleTest2  */
			
		
		
				accessFlags = IO.readShort(is, IsLittleEndian);
			//}
			accessModifier = ByteCode_Types.toAccessModifier(accessFlags, ClassFieldMethod.Class);
			
			// CONSTANT_Class_info을 가르키는 constant_pool의 인덱스
			/*CONSTANT_Class_info { 
				u1 tag; 
				u2 name_index; 
			}*/
			short thisRef = IO.readShort(is, IsLittleEndian);
			if (0<thisRef && thisRef<constantTable.count) {
				int thisClassRef = ((CONSTANT_Class_info)constantTable.getItem(thisRef)).name_index;
				
				this.name = ((CONSTANT_Utf8_info) constantTable.getItem(thisClassRef)).str;
				this.name = this.name.replace('/', '.');
				this.name = this.name.replace('$', '.');
				//this.name = toFullTypeName(this.name);
				if (this.fullNameIncludingTemplateExceptArray==null) {
					this.fullNameIncludingTemplateExceptArray = this.name;
				}
				
			}
			
			// CONSTANT_Class_info을 가르키는 constant_pool의 인덱스
			/*CONSTANT_Class_info { 
				u1 tag; 
				u2 name_index; 
			}*/
			short superRef = IO.readShort(is, IsLittleEndian);
			if (0<superRef && superRef<constantTable.count) {
				int superClassRef = ((CONSTANT_Class_info)constantTable.getItem(superRef)).name_index;
				
				this.superName = ((CONSTANT_Utf8_info) constantTable.getItem(superClassRef)).str;
				this.superName = this.superName.replace('/', '.');
				this.superName = this.superName.replace('$', '.');
				//this.superName = toFullTypeName(this.superName);
				
			}
			
			short interfaces_count = IO.readShort(is, IsLittleEndian);
			interfaces = new short[interfaces_count];
			for (i=0; i<interfaces_count; i++) {
				interfaces[i] = IO.readShort(is, IsLittleEndian);
				try {
					int ref = ((CONSTANT_Class_info) constantTable.getItem(interfaces[i])).name_index;
					String name = ((CONSTANT_Utf8_info) constantTable.getItem(ref)).str;
					
					name = name.replace('/', '.');
					name = name.replace('$', '.');
					//name = toFullTypeName(name);
					this.interfaceNames.add( name );
				}catch (Exception e) {					
					if (Common_Settings.g_printsLog) e.printStackTrace();
					CompilerHelper.printMessage(CommonGUI.textViewLogBird, e.getMessage()+" in "+i +" of interfaces");
					throw e;
				}
			}
			
			/*field_info { 
				u2 access_flags; 
				u2 name_index; //CONSTANT_Utf8_info을 가르키는 constantTable의 인덱스
				u2 descriptor_index; //CONSTANT_Utf8_info을 가르키는 constantTable의 인덱스
				u2 attributes_count; 
				attribute_info attributes[attributes_count];
			}*/

			short fields_count = IO.readShort(is, IsLittleEndian);
			fields_info = new Field_Info[fields_count];
			for (i=0; i<fields_count; i++) {
				try {
					fields_info[i] = Field_Info.read(this, is, this.constantTable, IsLittleEndian);
				}catch (Exception e) {
					if (Common_Settings.g_printsLog) e.printStackTrace();
					CompilerHelper.printMessage(CommonGUI.textViewLogBird, e.getMessage()+" in "+i +" of fields");
					throw e;
				}
			}
			
			short methods_count = IO.readShort(is, IsLittleEndian);
			methods_info = new Method_Info[methods_count];
			String className = CompilerStatic.getShortName(this.name);
			if (className==null) {
			}
			for (i=0; i<methods_count; i++) {
				try {
					
					methods_info[i] = Method_Info.read(this, is, this.constantTable, IsLittleEndian );
				}catch (Exception e) {
					if (Common_Settings.g_printsLog) e.printStackTrace();
					CompilerHelper.printMessage(CommonGUI.textViewLogBird, e.getMessage()+" in "+i +" of methods");
					throw e;
				}
				
				if (methods_info[i]!=null && methods_info[i].name!=null && methods_info[i].name.equals("getClass")) {
				}
			}
			
			//  the attributes table of a ClassFile structure
			short attributes_count = IO.readShort(is, IsLittleEndian);
			attributes_info = new Attribute_Info[attributes_count];
			for (i=0; i<attributes_count; i++) {
				try {
					attributes_info[i] = Attribute_Info.read(this, is, this.constantTable, IsLittleEndian);
				}catch (Exception e) {
					if (Common_Settings.g_printsLog) e.printStackTrace();
					CompilerHelper.printMessage(CommonGUI.textViewLogBird, e.getMessage()+" in "+i +" of attributes_info");
					throw e;
				}
			}
			
			//innerclasses_info = InnerClasses_attribute.read(is, this.constantTable);
			
			if (loadsInnerClass ) {
				loadInnerClass(coreThreadID);
			}
			
			classParams = toFindClassParams();
		
		
		
		//IO.IsLittleEndian = isLittleEndian;
		
		
		
		
		}catch (Exception e) {
			throw e;
		}
		
	}
	
	
	
	public static String toFullTypeName(String descriptorClassName) {
		if (descriptorClassName.charAt(0)=='L' && descriptorClassName.charAt(descriptorClassName.length()-1)==';') {
			descriptorClassName = descriptorClassName.substring(1, descriptorClassName.length()-1);
			descriptorClassName = descriptorClassName.replace('/', '.');
			descriptorClassName = descriptorClassName.replace('$', '.');
		}		
		return descriptorClassName;
	}
	
	FindClassParams toFindClassParams() throws Exception {
		try {
		FindClassParams c = new FindClassParams(this.compiler);
		
		
		if (this.name!=null) c.name = this.name;
		//else c.name = (String) constantTable.getItem(2);
		if (this.superName!=null) c.classNameToExtend = this.superName;
		//else c.classNameToExtend = (String) constantTable.getItem(4);
		
		if (c.name!=null) {
			c.name = toFullTypeName(c.name);
		}
		// 클래스가 템플릿 클래스일 경우 템플릿 이름을 포함하는 풀 타입 이름이다.
		if (fullNameIncludingTemplateExceptArray!=null) {
			c.name = fullNameIncludingTemplateExceptArray;
		}
		
		if (c.classNameToExtend!=null) {
			c.classNameToExtend = toFullTypeName(c.classNameToExtend);
		}
				
		int i;
		if (c.interfaceNamesToImplement==null) {
			c.interfaceNamesToImplement = new ArrayListString(5);
		}
		for (i=0; i<this.interfaceNames.count; i++) {
			String name = this.interfaceNames.getItem(i);
			name = toFullTypeName(name);
			c.interfaceNamesToImplement.add(name);
		}
		
		ArrayListIReset listOfVars = new ArrayListIReset(fields_info.length);
		for (i=0; i<fields_info.length; i++) {
			FindVarParams var = Field_Info.toFindVarParams(compiler, fields_info[i], typeNameInTemplatePair, true);
			if (var.fieldName.equals("list")) {
			}
			var.parent = c;
			var.isMemberOrLocal = true;
			listOfVars.add(var);
			
		}
		ArrayListIReset listOfFuncs = new ArrayListIReset(methods_info.length);
		for (i=0; i<methods_info.length; i++) {
			FindFunctionParams func = Method_Info.toFindFunctionParams(compiler, this, 
					methods_info[i], typeNameInTemplatePair, true, this.name, true);
			if (func.name.equals("Control")) {
			}
			func.parent = c;
			listOfFuncs.add(func);
		}
		
		
		c.listOfVariableParams = listOfVars;
		c.listOfFunctionParams = listOfFuncs;
		
		c.childClasses = this.listOfInnerClasses;
		
		c.loadWayOfFindClassParams = LoadWayOfFindClassParams.ByteCode;
		
		c.accessModifier = this.accessModifier;
		c.isInterface = this.accessModifier.isInterface;
		
		if (CompilerStatic.getShortName(c.name).equals("Dialog")) {
		}
		
	
		//CompilerHelper.makeNoneStaticDefaultConstructorIfNoneStaticDefaultConstructorNotExist(compiler, c);
		
		// 인터페이스나 추상클래스이면 디폴트 생성자를 만들지 않는다. 인스턴스를 만들 수 없기 때문이다.
		if (!(this.accessModifier.isInterface || this.accessModifier.isAbstract)) {			
			CompilerHelper.makeNoneStaticDefaultConstructorIfConstructorNotExist(compiler, c);
		}
		
		//if (CompilerHelper.requiresStaticConstructor(c)) {
			//CompilerHelper.makeStaticDefaultConstructorIfStaticConstructorNotExist(compiler, c);
		//}
		
		this.classParams = c;
		return c;
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
			throw e;
		}
	}
	
	

	@Override
	public void destroy() {
		
		this.absFilename = null;
		if (this.accessModifier!=null) {
			this.accessModifier.destroy();
			this.accessModifier = null;
		}
		if (this.attributes_info!=null) {
			int i;
			for (i=0; i<this.attributes_info.length; i++) {
				if (attributes_info[i]!=null) {
					this.attributes_info[i].destroy();
					this.attributes_info[i] = null;
				}
			}
			this.attributes_info = null;
		}
		if (this.classParams!=null) {
			this.classParams.destroy();
			this.classParams = null;
		}
		if (this.compiler!=null) {
			this.compiler.destroy();
			this.compiler = null;
		}
		if (this.constantTable!=null) {
			this.constantTable.destroy();
			this.constantTable = null;
		}
		this.fullNameIncludingTemplateExceptArray = null;
		if (this.fields_info!=null) {
			int i;
			for (i=0; i<this.fields_info.length; i++) {
				this.fields_info[i].destroy();
				this.fields_info[i] = null;
			}
			this.fields_info = null;
		}
		this.interfaces = null;
		if (this.interfaceNames!=null) {
			this.interfaceNames.destroy();
			this.interfaceNames = null;
		}
		if (this.listOfInnerClasses!=null) {
			this.listOfInnerClasses.destroy();
			this.listOfInnerClasses = null;
		}
		if (this.mBuffer!=null) {
			this.mBuffer.destroy();
			this.mBuffer = null;
		}
		if (this.methods_info!=null) {
			int i;
			for (i=0; i<this.methods_info.length; i++) {
				try {
				this.methods_info[i].destroy();
				}catch(Exception e) {
					if (Common_Settings.g_printsLog) e.printStackTrace();
				}
				this.methods_info[i] = null;
			}
			this.methods_info = null;
		}
		this.name = null;
		this.superName = null;
		this.typeNameInTemplatePair = null;
	}
	
		
}