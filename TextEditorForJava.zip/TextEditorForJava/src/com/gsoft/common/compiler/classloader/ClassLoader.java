package com.gsoft.common.compiler.classloader;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

import com.gsoft.common.CommonGUI;
import com.gsoft.common.compiler.Array;
import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.Compiler_types.FindFunctionParams;
import com.gsoft.common.compiler.Compiler_types.FindVarParams;
import com.gsoft.common.compiler.Compiler_types.Language;
import com.gsoft.common.compiler.Compiler_types.LoadWayOfFindClassParams;
import com.gsoft.common.compiler.Compiler_types_Base.AccessModifier;
import com.gsoft.common.compiler.Compiler_types_Base.AccessModifier.AccessPermission;
import com.gsoft.common.compiler.StringTokenizer;
import com.gsoft.common.compiler.TemplateBase;
import com.gsoft.common.compiler.bytecode.ByteCode_Types;
import com.gsoft.common.compiler.bytecode.ByteCode_Types.ClassFieldMethod;
import com.gsoft.common.compiler.bytecode.ByteCode_Types_Info.Field_Info;
import com.gsoft.common.compiler.bytecode.TypeDescriptor;
import com.gsoft.common.util.ArrayListIReset;
import com.gsoft.common.util.ArrayListString;
import com.gsoft.common.util.HighArray;

@SuppressWarnings("rawtypes")
public class ClassLoader /*extends PathClassLoader*/ {
	
	/** 클래스가 템플릿 클래스일 경우 <>안에 있는 바꿔야 할 풀 타입 이름이다.*/
	public String typeNameInTemplatePair;
	/** 클래스가 템플릿 클래스일 경우 템플릿 타입 이름을 포함하고 배열은 포함하지 않은 클래스 풀 이름이다.*/
	public String fullNameIncludingTemplateExceptArray;
	
	public Compiler compiler = null;
	
	String name;
	public String superName;	
	public ArrayListString interfaceNames = new ArrayListString(5);
	
	public AccessModifier accessModifier;
	
	/** output, 로드된 클래스*/
	public FindClassParams classParams;
	
	
	
	/** FindClassParams[]*/
	protected ArrayListIReset listOfInnerClasses;
	private String classPath;
	private int coreThreadID;
	
	
	/** 클래스 파일 로드 실패 리스트*/
	//public static ArrayListString listOfClassesToFailLoading = new ArrayListString(10);
	
	
	/**전에 로드를 실패한 적이 있다면 다시 로드하지 않는다. 
	 * PathClassLoader에서 클래스 파일 로드 실패 리스트에 등록한다.
	 * @param classPath : 디렉토리상 풀 경로, 확장자 포함*/
	/*public static boolean failedLoadingAlready(String classPath) {
		int i;
		// 전에 로드를 실패한 적이 있다면 다시 로드하지 않는다.
		for (i=0; i<listOfClassesToFailLoading.count; i++) {
			if (listOfClassesToFailLoading.getItem(i).equals(classPath))
				return true;
		}
		return false;
	}*/

	public ClassLoader(String classPath, String typeNameInTemplatePair, String fullNameIncludingTemplateExceptArray, boolean readsCode, int coreThreadID) {
		//super(fullNameIncludingTemplateExceptArray, fullNameIncludingTemplateExceptArray, fullNameIncludingTemplateExceptArray, readsCode);
		if (classPath==null) return;
		
		this.classPath = classPath;
		this.compiler = new Compiler();
		this.compiler.compilerStack.setLanguage(Language.Java);
		
		this.typeNameInTemplatePair = typeNameInTemplatePair;
		this.fullNameIncludingTemplateExceptArray = fullNameIncludingTemplateExceptArray;
		
		this.name = TemplateBase.getTemplateOriginalType(fullNameIncludingTemplateExceptArray);
		this.coreThreadID = coreThreadID;
		
		
		try {
			this.classParams = this.toFindClassParams();
		}catch(Throwable e) {
			CompilerHelper.printMessage(CommonGUI.textViewLogBird, "can't load class file : " + classPath+"\n");
			//ClassLoader.listOfClassesToFailLoading.add(this.name);
		}
		
	}
	
	protected ClassLoader() {
		
	}
	

	/** converts descriptor to fullname*/ 
	public static String toFullTypeName2(String descriptorClassName) {
		
		if (descriptorClassName.charAt(0)=='[') {
			return Field_Info.getType(descriptorClassName, true);
		}
		else {
			if (descriptorClassName.charAt(0)=='L' && descriptorClassName.charAt(descriptorClassName.length()-1)==';') {
				descriptorClassName = descriptorClassName.substring(1, descriptorClassName.length()-1);
				descriptorClassName = descriptorClassName.replace('/', '.');
				descriptorClassName = descriptorClassName.replace('$', '.');
			}	
			else {
				descriptorClassName = descriptorClassName.replace('/', '.');
				descriptorClassName = descriptorClassName.replace('$', '.');
			}
			return descriptorClassName;
		}
	}
	
	FindVarParams toFindVarParams(Field f) {
		String typeName = f.getType().getName();
		typeName = toFullTypeName2(typeName);
		if (this.typeNameInTemplatePair!=null && typeName.equals("java.lang.Object")) {
			typeName = this.typeNameInTemplatePair;
		}
		String fieldName = CompilerHelper.getShortName(f.getName());
		
		FindVarParams var = new FindVarParams(compiler, typeName, fieldName);
		int modifier = f.getModifiers();
		AccessModifier accessModifier = ByteCode_Types.toAccessModifier((short)modifier, ClassFieldMethod.Field);
		var.accessModifier = accessModifier;
		//var.accessModifier = f.getModifiers();
		return var;
	}
	
	FindFunctionParams toFindFunctionParams(Constructor m) {
		FindFunctionParams func = new FindFunctionParams(compiler, CompilerHelper.getShortName(m.getName()));
		func.returnType = m.getName();
		func.returnType = toFullTypeName2(func.returnType);
		if (this.typeNameInTemplatePair!=null && func.returnType.equals("java.lang.Object")) {
			func.returnType = this.typeNameInTemplatePair;
		}
		
		Class[] parameters = m.getParameterTypes();
		func.listOfFuncArgs = new ArrayListIReset(parameters.length);
		int i;
		for (i=0; i<parameters.length; i++) {
			Class classParameter = parameters[i];
			String typeName = classParameter.getName();
			typeName = toFullTypeName2(typeName);
			if (this.typeNameInTemplatePair!=null && typeName.equals("java.lang.Object")) {
				typeName = this.typeNameInTemplatePair;
			}
			FindVarParams var = new FindVarParams(compiler, typeName, null);
			
			func.listOfFuncArgs.add(var);
		}
		
		int modifier = m.getModifiers();
		AccessModifier accessModifier = ByteCode_Types.toAccessModifier((short)modifier, ClassFieldMethod.Method);
		func.accessModifier = accessModifier;
		
		//if (this.name.equals(func.name)) {
			func.isConstructor = true;
			if (accessModifier.isStatic) {
				func.isConstructorThatInitializesStaticFields = true;
			}
		//}
		return func;
	}
	
	FindFunctionParams toFindFunctionParams(Method m) {
		FindFunctionParams func = new FindFunctionParams(compiler, CompilerHelper.getShortName(m.getName()));
		func.returnType = m.getReturnType().getName();
		func.returnType = toFullTypeName2(func.returnType);
		
		if (this.typeNameInTemplatePair!=null && func.returnType.equals("java.lang.Object")) {
			func.returnType = this.typeNameInTemplatePair;
		}
		
		if (func.name.equals("nextElement")) {
		}
		
		Class[] parameters = m.getParameterTypes();
		func.listOfFuncArgs = new ArrayListIReset(parameters.length);
		int i;
		for (i=0; i<parameters.length; i++) {
			Class classParameter = parameters[i];
			String typeName = classParameter.getName();
			typeName = toFullTypeName2(typeName);
			if (this.typeNameInTemplatePair!=null && typeName.equals("java.lang.Object")) {
				typeName = this.typeNameInTemplatePair;
			}
			FindVarParams var = new FindVarParams(compiler, typeName, null);			
			func.listOfFuncArgs.add(var);
		}
		
		int modifier = m.getModifiers();
		AccessModifier accessModifier = ByteCode_Types.toAccessModifier((short)modifier, ClassFieldMethod.Method);
		func.accessModifier = accessModifier;
		
		/*if (this.name.equals(func.name)) {
			func.isConstructor = true;
			if (accessModifier.isStatic) {
				func.isConstructorThatInitializesStaticFields = true;
			}
		}*/
		return func;
	}
	
	/** childClassName이 com.gsoft.common.gui.EditText.RedoBuffer.Pair이고
	 * parentClassName이 com.gsoft.common.gui.EditText이면 true를 리턴하고
	 * childClassName이 com.gsoft.common.Sizing.SizeF이고
	 * parentClassName이 com.gsoft.common.Sizing.Size이면 false를 리턴한다.
	 * @param childClassName
	 * @param parentClassName
	 * @return
	 */
	boolean belongsTo(String childClassName, String parentClassName) {
		StringTokenizer tokenizer = new StringTokenizer();
		String[] separators = {".", "$"};
		HighArray arr1 = tokenizer.ConvertToStringArray2(childClassName, 20, separators);
		HighArray arr2 = tokenizer.ConvertToStringArray2(parentClassName, 20, separators);
		
		int i;
		for (i=0; i<arr2.count; i++) {
			if (arr2.getItem(i).equals(arr1.getItem(i))) {
				continue;
			}
			else {
				return false;
			}
		}
		return true;
	}
	
	
	Class findClass(String fullname, int coreThreadID) throws Throwable {
		
		Class classOfFullname = null;
		
		String binaryName = TypeDescriptor.toBinaryName(fullname, coreThreadID);
		
		
		if (binaryName!=null) {
			classOfFullname = java.lang.ClassLoader.getSystemClassLoader().loadClass(binaryName);
		}
		
		/*if (classOfFullname==null) {
			String parentClassName = Loader.fixFullName(fullname);
			
			//CompilerHelper.loadClass(null, parentClassName);
			Class classOfParentClass = null;
			try{
			classOfParentClass = Class.forName(parentClassName);
			}catch(Exception e) {
				if (Common_Settings.g_printsLog) e.printStackTrace();
			}
			
			Class tempClass = classOfParentClass;
			boolean found = false;
			
			while (true) {
				Class[] declaredClasses = tempClass.getDeclaredClasses();
				for (i=0; i<declaredClasses.length; i++) {
					String innerClassName = declaredClasses[i].getName();
					innerClassName = innerClassName.replace('$', '.');
					if (this.belongsTo(fullname, innerClassName)) {
						if (fullname.length()!=innerClassName.length()) {
							tempClass = declaredClasses[i];
							break;
						}
						else {
							classOfFullname = declaredClasses[i];
							found = true;
							break;
						}
					}
				}
				if (found) break;
			}//while (true) {
		}//if (classOfFullname==null) {*/
		return classOfFullname;
	}
	
	/**리턴타입의 클래스의 modifiers가 private과 abstract인 리턴타입을 갖는 함수들을 제거한다.
	StringBuilder.append()는 리턴타입이 AbstractStringBuilder, Appendable, StringBuilder 등을 갖는 여러 append() 함수들을 갖는다.
	여기에서 리턴타입이 AbstractStringBuilder, Appendable인 append()함수를 제거하여 StringBuilder에 매핑되도록 한다.
	 * @param coreThreadID */
	public boolean checkReturnType(Compiler compiler, String returnType, int coreThreadID) throws Throwable {
		String typeNameExceptArray = Array.getArrayElementType(returnType);
		String typeNameExceptTemplate = TemplateBase.getTemplateOriginalType(typeNameExceptArray);
		if (CompilerHelper.IsDefaultType(typeNameExceptTemplate)) return true;
		//if (Fullname.checkTypeNameInFileList(compiler, typeNameExceptTemplate)) 
		//	return true;
		
		Class classOfFullname = this.findClass(typeNameExceptTemplate, coreThreadID);
		int modifiers = classOfFullname.getModifiers();
		AccessModifier accessModifier = ByteCode_Types.toAccessModifier((short)modifiers, ClassFieldMethod.Class);
		
		// 리턴타입의 클래스의 modifiers가 private과 abstract인 리턴타입을 갖는 함수들을 제거한다.
		// StringBuilder.append()는 리턴타입이 AbstractStringBuilder, Appendable, StringBuilder 등을 갖는 여러 append() 함수들을 갖는다.
		// 여기에서 리턴타입이 AbstractStringBuilder, Appendable인 append()함수를 제거하여 StringBuilder에 매핑되도록 한다.
		if (accessModifier.accessPermission==AccessPermission.Private/* ||
				accessModifier.accessPermission==AccessPermission.Default*/) return false;
		//if (accessModifier.isAbstract) return false;
		return true;
	}
	
	FindClassParams toFindClassParams() throws Throwable {
		Class classOfFullname = this.findClass(name, coreThreadID);
		if (classOfFullname==null) return null;
		
		
		//this.compiler.data.filename = 
		//		Common_Settings.pathAndroid_Final + File.separator + classOfFullname.getName().replace('.', File.separatorChar) + ".class";
		this.compiler.data.filename = this.classPath;
		
		this.name = classOfFullname.getName();
		this.name = toFullTypeName2(this.name);
		Class classSuperClass = classOfFullname.getSuperclass();
		if (classSuperClass!=null) {
			this.superName = classSuperClass.getName();
			this.superName = toFullTypeName2(this.superName);
		}
		
		int i;
		Class[] interfaces = classOfFullname.getInterfaces();
		for (i=0; i<interfaces.length; i++) {
			String interfaceName = interfaces[i].getName();
			interfaceName = toFullTypeName2(interfaceName);
			this.interfaceNames.add(interfaceName);
		}
		
		FindClassParams c = new FindClassParams(this.compiler);
		
		
		if (this.name!=null) c.name = this.name;
		//else c.name = (String) constantTable.getItem(2);
		if (this.superName!=null) c.classNameToExtend = this.superName;
		//else c.classNameToExtend = (String) constantTable.getItem(4);
		
		if (c.name!=null) {
			c.name = toFullTypeName2(c.name);
		}
		// 클래스가 템플릿 클래스일 경우 템플릿 이름을 포함하는 풀 타입 이름이다.
		if (fullNameIncludingTemplateExceptArray!=null) {
			c.name = fullNameIncludingTemplateExceptArray;
		}
		
		if (c.classNameToExtend!=null) {
			c.classNameToExtend = toFullTypeName2(c.classNameToExtend);
		}
				
		
		if (c.interfaceNamesToImplement==null) {
			c.interfaceNamesToImplement = new ArrayListString(5);
		}
		for (i=0; i<this.interfaceNames.count; i++) {
			String name = this.interfaceNames.getItem(i);
			name = toFullTypeName2(name);
			c.interfaceNamesToImplement.add(name);
		}
		
		
		
		Field[] fields = classOfFullname.getDeclaredFields();
		Method[] methods = classOfFullname.getDeclaredMethods();
		Constructor[] constructors = classOfFullname.getDeclaredConstructors();
		
		ArrayListIReset listOfVars = new ArrayListIReset(fields.length);
		for (i=0; i<fields.length; i++) {
			FindVarParams var = this.toFindVarParams(fields[i]);
			if (var.fieldName.equals("list")) {
			}
			var.parent = c;
			var.isMemberOrLocal = true;
			listOfVars.add(var);
			
		}
		ArrayListIReset listOfFuncs = new ArrayListIReset(constructors.length+methods.length);
		for (i=0; i<constructors.length; i++) {
			FindFunctionParams func = this.toFindFunctionParams(constructors[i]);
			if (func.name.equals("Control")) {
			}
			func.parent = c;
			listOfFuncs.add(func);
		}
		if (this.name.equals("java.lang.StringBuilder")) {
		}
		for (i=0; i<methods.length; i++) {
			FindFunctionParams func = this.toFindFunctionParams(methods[i]);
			if (func.name.equals("append")) {
			}
			if (func.name.equals("entries")) {
			}
			/*if (checkReturnType(compiler, func.returnType)==false) {
				continue;
			}*/
			if (func.name.equals("Control")) {
			}
			func.parent = c;
			listOfFuncs.add(func);
		}
		
		int modifier = classOfFullname.getModifiers();
		AccessModifier accessModifier = ByteCode_Types.toAccessModifier((short)modifier, ClassFieldMethod.Class);
		this.accessModifier = accessModifier;
		
		
		c.listOfVariableParams = listOfVars;
		c.listOfFunctionParams = listOfFuncs;
		
		c.childClasses = this.listOfInnerClasses;
		
		c.loadWayOfFindClassParams = LoadWayOfFindClassParams.ByteCode;
		
		c.accessModifier = this.accessModifier;
		c.isInterface = this.accessModifier.isInterface;
		
		
	
		//CompilerHelper.makeNoneStaticDefaultConstructorIfNoneStaticDefaultConstructorNotExist(compiler, c);
		if (!(c.isInterface || c.accessModifier.isAbstract)) {
			CompilerHelper.makeNoneStaticDefaultConstructorIfConstructorNotExist(compiler, c);
		}
		
		//if (CompilerHelper.requiresStaticConstructor(c)) {
			//CompilerHelper.makeStaticDefaultConstructorIfStaticConstructorNotExist(compiler, c);
		//}
		
		this.classParams = c;
		return c;
	}
	
	/*boolean checkMethod(Method method) {
		if (method.)
	}*/
	
	
}
