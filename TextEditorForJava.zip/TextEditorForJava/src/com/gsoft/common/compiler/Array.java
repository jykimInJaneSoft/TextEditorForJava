package com.gsoft.common.compiler;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.compiler.Compiler_types.FindFuncCallParam;
import com.gsoft.common.compiler.Compiler_types.FindVarUseParams;
import com.gsoft.common.compiler.Compiler_types_Base.Error;
import com.gsoft.common.compiler.Compiler_types_Base.ReturnOfIsArrayType;
import com.gsoft.common.compiler.Compiler_types_Special.FindArrayInitializerParams;
import com.gsoft.common.compiler.bytecode.ByteCodeGeneratorForClass;
import com.gsoft.common.compiler.bytecode.ByteCode_Types;
import com.gsoft.common.compiler.classloader.Loader;
import com.gsoft.common.util.ArrayListIReset;
import com.gsoft.common.util.ArrayListInt;
import com.gsoft.common.util.HighArray;
import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.HighArray_CodeString;
import com.gsoft.common.compiler.CodeStringEx;
import com.gsoft.common.compiler.Checker;
import com.gsoft.common.compiler.IndexForHighArray;
import com.gsoft.common.compiler.CompilerStatic;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.Fullname;
import com.gsoft.common.compiler.Expression;
import com.gsoft.common.compiler.Number;


public class Array {
	/** []로 구분되는 배열원소의 파라미터들을 찾는다. 예를들어 a[i][j+1]에서 'i', 'j+1'각각을 말한다.
	 * @param compiler : compiler having array element
	 * @param curVarUse : a[i][j]에서 varUse 'a'를 말한다.
	 * @param indexOfCurVarUse : listOfAllVarUses 에서 'a'의 인덱스
	 * @return ArrayListIReset : FindFuncCallParam[], FindFuncCallParam의 시작과 끝인덱스에서 '[', ']'는 포함하지 않는다.
	 *   	파라미터가 없을 경우에는 null이 아닌 count가 0인 것을 리턴*/
	public static ArrayListIReset findArrayElementParams(Compiler compiler, FindVarUseParams curVarUse, int indexOfCurVarUse, 
			HighArray listOfAllVarUses) {
		HighArray_CodeString src = compiler.data.mBuffer;
		int i;
		ArrayListIReset result = new ArrayListIReset(5);
		result.resizeInc = 10;
		FindFuncCallParam funcCallParam=null;
		
		int dimensionOfElement = getArrayDimension(compiler, curVarUse.name);
		int countDimension = 0;
		
		for (i=curVarUse.index()+1; i<src.count; i++) {
			CodeString str = src.getItem(i);
			// 배열원소 안에 또다른 배열원소가 있을수 있으므로 [가 있으면 짝이 맞는 ]으로 점프한다.
			if (str.equals("[")) {
				funcCallParam = new FindFuncCallParam(compiler, i+1, -1);
				funcCallParam.funcName = src.getItem(curVarUse.index()).str;
				int rightPair;
				rightPair = Checker.CheckParenthesis(compiler, "[", "]", i, src.count, false);
				if (rightPair==-1) CompilerStatic.errors.add(new Error(compiler, i, i, "] not exists"));
				else {
					i = rightPair;
					funcCallParam.endIndex = IndexForHighArray.indexRelative(funcCallParam, src, i-1);
					result.add(funcCallParam);
					countDimension++;
					if (dimensionOfElement==countDimension) break;
				}
			}
		}
		return result;
	}
	
	
	 /** str이 int[], buffer[i]등일 경우 int, buffer의 인덱스를 리턴한다. 틀린 배열일 경우 -1을 리턴*/
    public static int getArrayNameIndex(Compiler compiler, int index) {
    	HighArray_CodeString src = compiler.data.mBuffer;
		int r = -1;
		int i;
		int leftPair;
		if (index<0) return -1;
		if (!src.getItem(index).equals("]")) return -1;
		for (i=index; i>=0; i--) {
			if (src.getItem(i).equals("]")) {
				leftPair = Checker.CheckParenthesis(compiler, "[", "]", 0, i, true);
				if (leftPair!=-1) {
					i = leftPair;
				}
				else {
					CompilerStatic.errors.add(new Error(compiler, i, i, "] not paired."));
					return -1;
				}
			}
			else break;
		}
		r = i;
		return r;
	}
    
    /** 배열원소인지 아니면 배열타입선언인지 확인한다. 
     * @param startIndexArraySubscription : [의 인덱스
     * @param endIndexArraySubscription : ]의 인덱스 이후 공백이나 주석 포함가능*/
    public static boolean isArrayElement(Compiler compiler, int startIndexArraySubscription, 
    		int endIndexArraySubscription) {
    	for (int i=startIndexArraySubscription; i<=endIndexArraySubscription; i++) {
    		CodeString str = compiler.data.mBuffer.getItem(i);
    		if (CompilerHelper.IsBlank(str) || CompilerHelper.IsComment(str)) continue;
    		else if (CompilerHelper.IsIdentifier(str, compiler) || Number.IsNumber2(str)!=0) return true;
    		else if (CompilerHelper.IsConstant(str)) return true;
    	}
		return false;
    	
    	
    }
    
    /** int[] a;에서 b=a[1];에서 fullnameOfArrayType이 int[]이고 varUse가 a[1]이면 int를 리턴한다.
     * 틀리면 errors에 에러를 출력한다.*/
    public static String getTypeOfArrayElement(Compiler compiler, /*String fullnameOfArrayType,*/ FindVarUseParams varUse) {    	
    	String fullnameOfArrayType = varUse.varDecl.typeName;
    	int dimension1 = getArrayDimension(compiler, fullnameOfArrayType);
    	int dimension2 = getArrayDimension(compiler, varUse.name);
    	if (dimension1!=dimension2) {
    		//CompilerStatic.errors.add(new Error(compiler, varUse.index(), varUse.index(), "Array dimension invalid. : "+fullnameOfArrayType+"-"+varUse.name));
    		String elementType = getArrayElementType(fullnameOfArrayType);
    		return Array.getArrayType(elementType, dimension2);
    	}
    	else {
    		String r = getArrayElementType(fullnameOfArrayType);
    		return r;
    	}
    }
    
    public static int getMaxArrayLengthInCurDepth(FindArrayInitializerParams topArray, 
			FindArrayInitializerParams array) {
    	ArrayListInt listOfLength = topArray.listOfLength;
    	int curDepth = array.depth;
    	return listOfLength.getItem(curDepth);
    	
    }
    
    /** str이 int[], buffer[i]일 경우 차원 1을 리턴한다. 배열이 아니면 0을 리턴
     * @param compiler : compiler having array*/
	public static ArrayListInt getArrayLength(Compiler compiler, String str) {
		int i;
		int leftPair;
		if (str==null) {
		}
		if (str.length()<1) return null;
		if (str.charAt(str.length()-1)!=']') return null;
		
		ArrayListInt listOfLength = new ArrayListInt(3); 
		for (i=str.length()-1; i>=0; i--) {
			if (str.charAt(i)==']') {
				leftPair = Checker.CheckParenthesis(str, "[", "]", 0, i, true);
				if (leftPair!=-1) {
					// 마지막 첨자가 먼저 listOfLength에 들어간다.
					int length = Integer.parseInt(str.substring(leftPair, i));
					listOfLength.add(length);
					i = leftPair;
				}
				else {
					CompilerStatic.errors.add(new Error(compiler, i, i, "] not paired."));
					return null;
				}
			}
			else break;
		}
		ArrayListInt r = new ArrayListInt(listOfLength.count);
		// listOfLength의 첨자 순서와 반대로 넣어서 리턴한다.
		for (i=listOfLength.count-1; i>=0; i--) {
			r.add(listOfLength.getItem(i));
		}
		return r;
	}
	

	/** str이 int[], buffer[i]일 경우 차원 1을 리턴한다. 배열이 아니면 0을 리턴
	 * @param compiler : compiler having array*/
	public static int getArrayDimension(Compiler compiler, String str) {
		int dimensionOfArray = 0;
		int i;
		int leftPair;
		if (str==null) {
		}
		try {
		if (str.length()<1) return 0;
		if (str.charAt(str.length()-1)!=']') return 0;
		for (i=str.length()-1; i>=0; i--) {
			if (str.charAt(i)==']') {
				leftPair = Checker.CheckParenthesis(str, "[", "]", 0, i, true);
				if (leftPair!=-1) {
					i = leftPair;
				}
				else {
					CompilerStatic.errors.add(new Error(compiler, i, i, "] not paired."));
					return 0;
				}
				dimensionOfArray++;
			}
			else break;
		}
		return dimensionOfArray;
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
			return 0;
		}
	}
	
	/** str이 int[]일 경우 첨자를 뺀 원소 타입 int를 리턴한다. str은 타입이름이어야 한다. 
	 * int[10][10]와 같은 배열원소는 int를 리턴한다. str에 주석이나 애노테이션등이 있어서는 안된다.*/
	public static String getArrayElementType(String str) {
		if (str.length()<=0) return null;
		int indexRightPair = str.length()-1;
		int indexLefttPair;
		int typeStartIndex=0, typeEndIndex;
		int index = indexRightPair;
		char c;
		while (true) {
			if (index<0 || index>str.length()-1) {
				return null;
			}
			c = str.charAt(index);
			if (c==']') {
				indexLefttPair = Checker.CheckParenthesis(str, "[", "]", 0, indexRightPair, true);
				if (indexLefttPair==-1) { // error
					return null;
				}
				index = indexLefttPair-1;
				indexRightPair = index;
			}
			else {
				typeEndIndex = index;
				break;
			}
		}
		String type = str.substring(typeStartIndex, typeEndIndex+1);
		return type;
		
		/* while (true) {
			if (str.contains("[]")) {
				str = str.substring(0, str.length()-2); // 마지막 []을 제거
			}
			else break;
		}
		return str;*/
	}
	
	/** str은 타입이름이어야 한다. str이 int이고 dimension이 1일 경우 int[]을 리턴한다.*/
	public static String getArrayType(String str, int dimension) {
		int i;
		String r = str;
		for (i=0; i<dimension; i++) {
			r += "[]";
		}
		return r;
	}
	
	/** isReverse가 true이면 index부터 역으로 배열인지를 확인하고, false이면 index부터 순방향으로 배열인지를
     * 확인한다.
     * @return 배열이 맞으면 역방향일 경우 type시작의 인덱스, 순방향일 경우 ]의 인덱스, 배열이 아니면 -1 
     */
    public static ReturnOfIsArrayType IsArrayType(Compiler compiler, boolean isReverse, int index) {
    	HighArray_CodeString src = compiler.data.mBuffer;
    	if (index<0) return new ReturnOfIsArrayType(false, -1);
    	if (isReverse) {
    		int i = index;
    		
    		if (!src.getItem(i).equals("]")) return new ReturnOfIsArrayType(false, -1);
    		do {
    			int indexLeftPair = Checker.CheckParenthesis(compiler,  "[", "]", 0, i, true);
    			if (indexLeftPair==-1) {
    				//errors.add(new Error(compiler, i, i, "invalid array declaration"));
    				return new ReturnOfIsArrayType(false, -1);
    			}
    			i = CompilerHelper.SkipBlank(src, true, 0, indexLeftPair-1);
    			if (i<=-1) return new ReturnOfIsArrayType(false, -1);
    			if (!src.getItem(i).equals("]")) break;
    		}while(true);
    		
    		// 템플릿 배열일 경우 Template개체를 만들기 위해 현재 인덱스를 리턴해야 한다.
    		if (src.getItem(i).equals(">")) {
    			return new ReturnOfIsArrayType(true, i);
    		}
    		
    		i = CompilerHelper.SkipBlank(src, true, 0, i);
    		
    		src.getItem(i);
    		
    		int fullnameIndex = Fullname.getFullNameIndex_OnlyType(compiler,  true, i, true);
    		
    		return new ReturnOfIsArrayType(false, fullnameIndex);
    	}//if (isReverse) {
    	else {
    		index = CompilerHelper.SkipBlank(src, false, index, src.count-1);
    		
    		src.getItem(index);
    		
    		int fullnameIndex = Fullname.getFullNameIndex_OnlyType(compiler,  false, index, true);
    		if (fullnameIndex==-1) return new ReturnOfIsArrayType(false, -1);
    		index = fullnameIndex;
    		
    		int i = CompilerHelper.SkipBlank(src, false, index+1, src.count-1);
    		if (i>=src.count) return new ReturnOfIsArrayType(false, -1);
    		
    		if (!src.getItem(i).equals("[")) 
    			return new ReturnOfIsArrayType(false, -1);
    		
    		
    		
    		do {
    			int indexRightPair = Checker.CheckParenthesis(compiler, "[", "]", i, src.count-1, false);
    			if (indexRightPair==-1) {
    				//errors.add(new Error(compiler, i, i, "invalid array declaration"));
    				return new ReturnOfIsArrayType(false, -1);
    			}
    			i = CompilerHelper.SkipBlank(src, false, indexRightPair+1, src.count-1);
    			if (i>=src.count || !src.getItem(i).equals("[")) {
    				i = CompilerHelper.SkipBlank(src, true, 0, i-1);
    				return new ReturnOfIsArrayType(false, i);
    			}
    		}while(true);
    		
    		
    		
    	}
    	//return -1;
    	
    }
    
    /** varUse의 listOfArrayElementParams을 찾는다. 즉 varUse가 배열원소일 경우 배열원소 첨자들을 구한다.
	 * 
	 * @param compiler : compiler having array element of varUse
	 * @param varUse : new SizeF[5+1]에서 SizeF, buffer[i].equals("a")에서 buffer 등
	 * @param i : varUse의 listOfAllVarUses에서의 인덱스
	 * @param listOfAllVarUses : 파일안에서 모든 varUse들의 리스트, mlistOfAllVarUses
     * @param coreThreadID 
	 */
    public static void findArraySubscription(Compiler compiler, FindVarUseParams varUse, 
			int i, HighArray listOfAllVarUses, int coreThreadID) {
    	HighArray_CodeString src = compiler.data.mBuffer;
		// 배열 원소일 경우,
		// 배열원소 첨자들을 구하고 첨자 각각의 타입을 결정한다. 또한 첨자 내 수식을 postfix로 바꾸기도 한다.
		if (src.getItem(varUse.index()).equals("buffer")) {
		}
		varUse.listOfArrayElementParams = findArrayElementParams(compiler, varUse, i, listOfAllVarUses);
		int k;
		for (k=0; k<varUse.listOfArrayElementParams.count; k++) {
			FindFuncCallParam params = (FindFuncCallParam) varUse.listOfArrayElementParams.getItem(k);
			if (params.typeFullName==null) {
				CodeStringEx typeNameArrParam = Expression.getTypeOfExpression(compiler, params, coreThreadID);
				if (typeNameArrParam==null || 
					!(typeNameArrParam.equals("byte") || typeNameArrParam.equals("short") ||
					typeNameArrParam.equals("char") || typeNameArrParam.equals("int"))) {
					CompilerStatic.errors.add(new Error(compiler, params.startIndex(), params.endIndex(), 
							"invalid subscription type"));
				}
				params.typeFullName = typeNameArrParam;
			}
			if (params.typeFullName!=null && params.typeFullName.str!=null) {
				params.classParams = Loader.loadClass(compiler, params.typeFullName.str, coreThreadID);
			}
			if (params.classParams==null) {
			}
		}
		
	}
	
		
	/** varUse.isArrayElement의 값은 반드시 true이다, 즉 buffer[i].equals()와 같이 배열원소이다.
	 * @param compiler : compiler having array element
	 * @param i : varUse의 listOfAllVarUses에서의 인덱스
	 * @param coreThreadID 
	 * @return : 배열 원소의 타입*/
	public static String getFullTypeNameOfArrayElement(Compiler compiler, FindVarUseParams varUse, 
			int i, HighArray listOfAllVarUses, boolean isOuterLibrary, int coreThreadID) {
		if (varUse.index()==45813) {
		}
		String typeName, typeNameFull = null;
		// 배열 원소일 경우,
		// 배열원소 첨자들을 구하고 첨자 각각의 타입을 결정한다. 또한 첨자 내 수식을 postfix로 바꾸기도 한다.
		varUse.listOfArrayElementParams = findArrayElementParams(compiler, varUse, i, listOfAllVarUses);
		int k;
		for (k=0; k<varUse.listOfArrayElementParams.count; k++) {
			FindFuncCallParam params = (FindFuncCallParam) varUse.listOfArrayElementParams.getItem(k);
			if (params.typeFullName==null) {
				CodeStringEx typeNameArrParam = Expression.getTypeOfExpression(compiler, params, coreThreadID);
				params.typeFullName = typeNameArrParam;
				continue;
			}			
			params.classParams = Loader.loadClass(compiler, params.typeFullName.str, coreThreadID);
			if (params.classParams==null) {
			}
		}
		
		//배열의 차원을 확인해야 한다. 여기에선 배열 원소의 타입을 구한다.
		// buffer[i].equals()에서 buffer[i]의 타입은 CodeString이다.
		/*if (!isOuterLibrary) {
			typeName =
				varUse.varDecl.getType(varUse.varDecl.typeStartIndex(), varUse.varDecl.typeEndIndex(), coreThreadID);
		}
		else {*/
			typeName = varUse.varDecl.typeName;
		//}
		int dimensionOfType = getArrayDimension(varUse.varDecl.compiler, typeName);
		int dimensionOfElement = getArrayDimension(compiler, varUse.name);
		
		if (dimensionOfType==dimensionOfElement) {
			typeName = getArrayElementType(typeName);
			typeNameFull = typeName;
		}
		else {
			typeNameFull = ByteCode_Types.ArrayFullClassName;
		}
		
		return typeNameFull;
	}
}
