package com.gsoft.common.compiler;

import java.io.File;

import android.graphics.Point;

import com.gsoft.common.Code.CodeChar;
import com.gsoft.common.Code.CodeString;
import com.gsoft.common.Code.CodeStringType;
import com.gsoft.common.CommonGUI;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.FileHelper;
import com.gsoft.common.IO;
import com.gsoft.common.IO_types.ReturnOfReadString;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.Compiler_types.FindFunctionParams;
import com.gsoft.common.compiler.Compiler_types.FindVarParams;
import com.gsoft.common.compiler.Compiler_types.Language;
import com.gsoft.common.compiler.Compiler_types.ModeAllOrUpdate;
import com.gsoft.common.compiler.Compiler_types_Base.Comment;
import com.gsoft.common.compiler.Compiler_types_Base.FindStatementParams;
import com.gsoft.common.compiler.Compiler_types_Special.ErrorList;
import com.gsoft.common.compiler.Update.QueueItem;
import com.gsoft.common.compiler.classloader.Loader;
import com.gsoft.common.compiler.util.Builder;
import com.gsoft.common.gui.Buttons.Button;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListString;
import com.gsoft.common.util.HighArray_CodeChar;
import com.gsoft.common.util.HighArray_char;

import com.gsoft.common.compiler.Fullname;
import com.gsoft.common.compiler.CompilerStatic;
import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.CompilerInterface;
import com.gsoft.common.compiler.StringTokenizer;
import com.gsoft.common.compiler.HighArray_CodeString;
import com.gsoft.common.compiler.CompilerCache;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.CompilerData;
import com.gsoft.common.compiler.Update;
import com.gsoft.common.compiler.ClassCache;

public class InterfaceErrorResolver {
	/** Finds all java files referring modified documents in a project
	 * @param result : File[]
	 * @param coreThreadID 
	 * */
	public static void findJavaFilesReferringModifiedDocumentsInProject(ArrayList updateFileList, ArrayList result, 
			int coreThreadID) {
		if (Common_Settings.projectName.equals("TextEditorForJava")) {
			// When projectName is "TextEditorForJava", don't catch interface error.
			int i;
			for (i=0; i<updateFileList.count; i++) {
				File file = (File) updateFileList.getItem(i);
				result.add(file);
			}
			return;
		}
		
		if (updateFileList==null) return;
		
		ArrayList allJavaFilesInProject = loadPackageNameAndImportClassNameOfAllJavaFilesInProject();
		int i;
		for (i=0; i<updateFileList.count; i++) {
			File file = (File) updateFileList.getItem(i);
			String filePath = file.getAbsolutePath();
			Compiler document = null;
			String fullname = Fullname.toFullname(2, filePath);
			document = Loader.loadClassFromSrc_onlyInterfaceForCompiler(fullname, coreThreadID);
			if (document==null) continue;
			findJavaFilesReferringDocumentInProject_sub(document, result, allJavaFilesInProject);
		}
	}
	
	/**@param fileList : File[] to compile*/
	public static void deleteOldClassFiles(ArrayList fileList) {
		if (Common_Settings.projectName.equals("TextEditorForJava")) {
			// When projectName is "TextEditorForJava", don't catch interface error.
			return;
		}
		int i, j;
		for (i=0; i<fileList.count; i++) {
			File file = (File) fileList.getItem(i);
			String fullname = Fullname.toFullname(2, file.getAbsolutePath());
			// com/gsoft/common/gui/Control
			String slashedFullname = fullname.replace('.', File.separatorChar);
			String filename = FileHelper.getFilename(slashedFullname);
			// com/gsoft/common/gui
			String dir = FileHelper.getDirectory(Common_Settings.pathOutput + File.separator + slashedFullname);
			String[] list = new File(dir).list();
			if (list==null) {
				// .class files not exists in dir
				continue;
			}
			for (j=0; j<list.length; j++) {
				String ext = FileHelper.getExt(list[j]);
				if (ext.equals(".class")) {
					// Control.class, Control$ControlStack.class
					if (list[j].contains(filename+".class") || list[j].contains(filename+"$")) {
						
						String filePath = dir + File.separator + list[j];
						new File(filePath).delete();
					}
				}
			}
		}
	}
	
	/** Finds all java files referring modified documents(import, same package) in a CompilerCache
	 * @param changedCompiler 
	 * @param result : File[]
	 * */
	public static void findJavaFilesReferringModifiedDocumentsInCompilerCache(Compiler changedCompiler, ArrayList result) {
		/*ArrayList modified = CompilerCache.isProjectModified();
		if (modified==null) return;
		int i;
		for (i=0; i<modified.count; i++) {
			Compiler compiler = (Compiler) modified.getItem(i);
			String ext = FileHelper.getExt(compiler.data.filename);
			if (ext.equals(".java")) {
				findJavaFilesReferringDocumentInCompilerCache_sub(compiler, result);
			}
		}*/
		String ext = FileHelper.getExt(changedCompiler.data.filename);
		if (ext.equals(".java")) {
			findJavaFilesReferringDocumentInCompilerCache_sub(changedCompiler, result);
		}
	}
	
	static ArrayList merge(ArrayList original, ArrayList newList) {
		int i, j;
		ArrayList r = new ArrayList(original.count);
		for (i=0; i<original.count; i++) {
			r.add(original.getItem(i));
		}
		for (i=0; i<newList.count; i++) {
			File file = (File) newList.getItem(i);
			boolean exists = false;
			for (j=0; j<original.count; j++) {
				File file2 = (File) original.getItem(i);
				if (file.getAbsolutePath().equals(file2.getAbsolutePath())) {
					exists = true;
					break;
				}
			}
			if (!exists) {
				r.add(file);
			}
		}
		return r;
	}
	
	static class PackageAndImportClassesInFile {
		String filePath;
		String packageName;
		ArrayListString mlistOfImportedClasses;
		ArrayListString mlistOfImportedClassesStar;
	}
	
	/**@return result : PackageAndImportClassesInFile[]*/
	public static ArrayList loadPackageNameAndImportClassNameOfAllJavaFilesInProject() {
		
		ArrayList allJavaFilesInProject = Builder.findAllJavaFilesInProject();
		ArrayList result = new ArrayList(allJavaFilesInProject.count);
		
		Compiler compiler = new Compiler();
		
		compiler.compilerStack.setLanguage(Language.Java);
		
		ErrorList localErrorList = new ErrorList(10);
		ErrorList backupErrors = CompilerStatic.errors; 
		
		CompilerStatic.errors = localErrorList;
		
		int i;
		for (i=0; i<allJavaFilesInProject.count; i++) {
			File file = (File) allJavaFilesInProject.getItem(i);
			String filePath = file.getAbsolutePath();
			
			String filename = FileHelper.getFilename(filePath);
			if (filename.equals("RegisterManager.java")) {
				int a;
				a=0;
				a++;
			}
			
			
			ReturnOfReadString fileContent = IO.readStringUTF8(filePath, 0, "class");
			//HighArray_char strUntilClass = getString_UntilClass(fileContent.result);
			StringTokenizer tokenizer = new StringTokenizer();
			HighArray_CodeString mBuffer = null;
			try {
					mBuffer = tokenizer.ConvertToStringArray2(new CodeString(/*strUntilClass.getItems()*/fileContent.result, Common_Settings.textColor), 100, Language.Java);
			}catch(Exception e) {
				e.printStackTrace();
				
			}
						
			compiler.data.mlistOfPackageStatements.reset2();
			compiler.compilerStack.RegisterPackageName(mBuffer);
			compiler.data.mlistOfImportStatements.reset2();
			compiler.data.mlistOfImportedClasses.reset2();
			//if (Common_Settings.g_loadsImportStarInSource) {
				compiler.data.mlistOfImportedClassesStar.reset2();
			//}
			compiler.compilerStack.RegisterImportedClasses(mBuffer);
			
			
			
			PackageAndImportClassesInFile item = new PackageAndImportClassesInFile();
			item.filePath = filePath;
			item.packageName = compiler.data.packageName;
			item.mlistOfImportedClasses = (ArrayListString) compiler.data.mlistOfImportedClasses.clone();
			if (Common_Settings.g_loadsImportStarInSource) {
				item.mlistOfImportedClassesStar = (ArrayListString) compiler.data.mlistOfImportedClassesStar.clone();
			}
			
			
			
			mBuffer.destroy();
			tokenizer.destroy();
			//strUntilClass.destroy();
			fileContent.destroy();
			
			result.add(item);
		}
		
		CompilerStatic.errors = backupErrors;
		
		return result;
	}
	
	/** Finds all java files referring document  in a project
	 * @param result : File[]
	 * @param allJavaFilesInProject : PackageAndImportClassesInFile[]
	 * */
	public static void findJavaFilesReferringDocumentInProject_sub(Compiler document, ArrayList result, ArrayList allJavaFilesInProject) {
		ArrayList javaFilesInPackage = null;
		if (Common_Settings.g_findsPackageLibrary) {
			javaFilesInPackage = Builder.findAllJavaFilesInPackage(document.data.packageName, false);
		}
		else {
			javaFilesInPackage = new ArrayList(1);
		}
		int i;
		for (i=0; i<javaFilesInPackage.count; i++) {
			File file = (File) javaFilesInPackage.getItem(i);
			String path = file.getAbsolutePath();
			if (!exists(result, path)) {
				result.add(file);
			}
		}
		
		for (i=0; i<allJavaFilesInProject.count; i++) {
			PackageAndImportClassesInFile file = (PackageAndImportClassesInFile) allJavaFilesInProject.getItem(i);
			String filePath = file.filePath;
			// same file
			if (document.data.filename.equals(filePath)) continue;
			
			String filename = FileHelper.getFilename(filePath);
			if (filename.equals("RegisterManager.java")) {
				int a;
				a=0;
				a++;
			}
		
						
			// same package, already putted
			//if (document.data.packageName.equals(file.packageName)) continue;
			if (isImportingDocument(file, document)) {
				if (!exists(result, filePath)) {
					result.add(new File(filePath));
				}
			}
		}
	}
	
	
	public static HighArray_CodeChar toHighArray_CodeChar(CodeString[] textArray) {
		int i;
		HighArray_CodeChar r = new HighArray_CodeChar(100);
		for (i=0; i<textArray.length; i++) {
			//r.add((CodeString)textArray[i].clone());
			r.add(textArray[i]);
		}
		return r;
	}
	
	static boolean exists(ArrayList list, String filePath) {
		int i;
		for (i=0; i<list.count; i++) {
			File file = (File) list.getItem(i);
			if (file.getAbsolutePath().equals(filePath)) return true;
		}
		return false;
	}
	
	/** Finds all java files referring document(import, same package)  in a CompilerCache
	 * @param result : File[]
	 * */
	static void findJavaFilesReferringDocumentInCompilerCache_sub(Compiler document, ArrayList result) {
		try {
			int i;
			
			ArrayList allJavaFilesInCompilerCache = CompilerCache.listOfCompilers;
			
			for (i=0; i<allJavaFilesInCompilerCache.count; i++) {
				Compiler compiler = (Compiler) allJavaFilesInCompilerCache.getItem(i);
				String filePath = null;
				filePath = compiler.data.filename;
				if (filePath==null) {
					continue;
				}
				String ext = FileHelper.getExt(filePath);
				if (!ext.equals(".java")) continue;
				File file = new File(filePath);
				
				boolean haveToPut = false;
				
				// same file
				if (document.data.filename.equals(filePath)) {
					if (!exists(result, filePath)) {
						result.add(file);
					}
					continue;
				}
				
				if (compiler.data.isModified) {
					HighArray_CodeChar strInput = toHighArray_CodeChar(compiler.data.textArray);
					StringTokenizer tokenizer = new StringTokenizer();
					HighArray_CodeString mBuffer = 
							tokenizer.ConvertToStringArray2(strInput.toCodeString(), 100, Language.Java);
					
					compiler.data.mlistOfPackageStatements.reset2();
					compiler.compilerStack.RegisterPackageName(mBuffer);
					compiler.data.mlistOfImportStatements.reset2();
					compiler.data.mlistOfImportedClasses.reset2();
					//if (Common_Settings.g_loadsImportStarInSource) {
						compiler.data.mlistOfImportedClassesStar.reset2();
					//}
					compiler.compilerStack.RegisterImportedClasses(mBuffer);
				}
				
				
				// same package
				if (Common_Settings.g_findsPackageLibrary) {
					if (document.data.packageName.equals(compiler.data.packageName)) {
						haveToPut = true;
					}
				}
				// import
				if (isImportingDocument(compiler, document)) {
					haveToPut = true;
					
				}
				if (haveToPut) {
					if (!exists(result, filePath)) {
						result.add(file);
					}
				}
			}
		}
		catch(Exception e) {
			e.printStackTrace();
			System.out.println("filename:"+document.data.filename);
		}
	}
	
	/** compiler imports document*/
	static boolean isImportingDocument(Compiler compiler, Compiler document) {
		int i, j;
		for (i=0; i<compiler.data.mlistOfImportedClasses.count; i++) {
			String importClassName = compiler.data.mlistOfImportedClasses.getItem(i);
			for (j=0; j<document.data.mlistOfAllDefinedClasses.count; j++) {
				FindClassParams c = (FindClassParams) document.data.mlistOfAllDefinedClasses.getItem(j);
				if (importClassName.equals(c.name)) return true;				
			}
		}		
		if (Common_Settings.g_loadsImportStarInSource) {
			for (i=0; i<compiler.data.mlistOfImportedClassesStar.count; i++) {
				String importClassName = compiler.data.mlistOfImportedClassesStar.getItem(i);
				for (j=0; j<document.data.mlistOfAllDefinedClasses.count; j++) {
					FindClassParams c = (FindClassParams) document.data.mlistOfAllDefinedClasses.getItem(j);
					if (c.name.contains(importClassName)) return true;				
				}
			}
		}
		return false;
	}
	
	/** file imports document*/
	static boolean isImportingDocument(PackageAndImportClassesInFile file, Compiler document) {
		int i, j;
		for (i=0; i<file.mlistOfImportedClasses.count; i++) {
			String importClassName = file.mlistOfImportedClasses.getItem(i);
			for (j=0; j<document.data.mlistOfAllDefinedClasses.count; j++) {
				FindClassParams c = (FindClassParams) document.data.mlistOfAllDefinedClasses.getItem(j);
				if (importClassName.equals(c.name)) return true;				
			}
		}	
		if (Common_Settings.g_loadsImportStarInSource) {
			for (i=0; i<file.mlistOfImportedClassesStar.count; i++) {
				String importClassName = file.mlistOfImportedClassesStar.getItem(i);
				for (j=0; j<document.data.mlistOfAllDefinedClasses.count; j++) {
					FindClassParams c = (FindClassParams) document.data.mlistOfAllDefinedClasses.getItem(j);
					if (c.name.contains(importClassName)) return true;				
				}
			}
		}
		return false;
	}
	
	/** Skips comments, annotation, public, private, protected and class*/
	static HighArray_char getString_UntilClass(HighArray_char fileContent) {
		int i, j;
		HighArray_char r = new HighArray_char(100);
		for (i=0; i<fileContent.count; i++) {
			 if (fileContent.getItem(i) == '/' && 
	            		(i + 1 < fileContent.count && fileContent.getItem(i + 1) == '*'))
	         {    	       	
				 int endComment = -1;              	
				 for (j = i+2; j < fileContent.count; j++)
				 {
					 if (fileContent.getItem(j) == '*' && 
	                			(j + 1 < fileContent.count && fileContent.getItem(j + 1) == '/')) {
	                		endComment = j+1;
	                		break;
					 }	                
				 }
				 if (endComment!=-1) {
					 i = endComment;
					 continue;
				 }	             
	        }
			if (fileContent.getItem(i) == '/' && 
	            		(i + 1 < fileContent.count && fileContent.getItem(i + 1) == '/'))
	        {    	       	
				 int endComment = -1;              	
				 for (j = i+2; j < fileContent.count; j++)
				 {
					 if (fileContent.getItem(j) == '\n') {
	                		endComment = j;
	                		break;
					 }	                
				 }
				 if (endComment!=-1) {
					 i = endComment;
					 continue;
				 }	             
	        }
			if (fileContent.getItem(i) == '@')
	        {    	       	
				 int endComment = -1;              	
				 for (j=i+1; j < fileContent.count; j++)
				 {
					 if (fileContent.getItem(j) == '\n') {
	                		endComment = j;
	                		break;
					 }	                
				 }
				 if (endComment!=-1) {
					 i = endComment;
					 continue;
				 }	             
	        }
			if (i+6<fileContent.count &&
					fileContent.getItem(i)=='p' && fileContent.getItem(i+1)=='u' && fileContent.getItem(i+2)=='b' && 
					fileContent.getItem(i+3)=='l' && fileContent.getItem(i+4)=='i' && fileContent.getItem(i+5)=='c' &&
					CompilerHelper.IsBlank(fileContent.getItem(i+6))) {
					return r;
			}
			if (i+7<fileContent.count &&
					fileContent.getItem(i)=='p' && fileContent.getItem(i+1)=='r' && fileContent.getItem(i+2)=='i' && 
					fileContent.getItem(i+3)=='v' && fileContent.getItem(i+4)=='a' && fileContent.getItem(i+5)=='t' &&
					fileContent.getItem(i+6)=='e' &&
					CompilerHelper.IsBlank(fileContent.getItem(i+7))) {
					return r;
			}
			if (i+9<fileContent.count &&
					fileContent.getItem(i)=='p' && fileContent.getItem(i+1)=='r' && fileContent.getItem(i+2)=='o' && 
					fileContent.getItem(i+3)=='t' && fileContent.getItem(i+4)=='e' && fileContent.getItem(i+5)=='c' &&
					fileContent.getItem(i+6)=='t' && fileContent.getItem(i+7)=='e' && fileContent.getItem(i+8)=='d' &&
					CompilerHelper.IsBlank(fileContent.getItem(i+9))) {
					return r;
			}
			if (0<i-1 && i+5<fileContent.count &&
				CompilerHelper.IsBlank(fileContent.getItem(i-1)) &&
				fileContent.getItem(i)=='c' && fileContent.getItem(i+1)=='l' && fileContent.getItem(i+2)=='a' && 
				fileContent.getItem(i+3)=='s' && fileContent.getItem(i+4)=='s' &&
				CompilerHelper.IsBlank(fileContent.getItem(i+5))) {
				return r;
			}
			r.add(fileContent.getItem(i));
		}
		return r;
	}
	
	static boolean interfaceChanged(QueueItem lastItem) {
		//if (Update.listOfQueueItems.count<=0) return false;
		
		String charA = lastItem.charA;
		if (charA.equals("all")) return true;
		
		//QueueItem lastItem = (QueueItem) Update.listOfQueueItems.getItem(Update.listOfQueueItems.count-1);
		CompilerInterface compilerInterface = (CompilerInterface) lastItem.compiler;
		Point cursorPos = lastItem.cursorPos;
		int indexInmBuffer = CompilerStatic.findWord(compilerInterface, cursorPos.x, cursorPos.y);
		FindStatementParams statement = compilerInterface.findLocation(compilerInterface.data.mlistOfClass, indexInmBuffer);
		if (statement instanceof FindFunctionParams) {
			FindFunctionParams func = (FindFunctionParams) statement;
			if (func.findBlockParams!=null) {
				if (func.findBlockParams.startIndex()<=indexInmBuffer && indexInmBuffer<=func.findBlockParams.endIndex()) {
					return false;
				}
				else return true;
			}
		}
		else if (statement instanceof FindVarParams) {
			FindVarParams var = (FindVarParams) statement;
			if (var.startIndex()<=indexInmBuffer && indexInmBuffer<=var.endIndex()) {
				return true;
			}
			else return false;
		}
		else if (statement instanceof FindClassParams) {
			FindClassParams c = (FindClassParams) statement;
			if (c.findBlockParams!=null) {
				if (c.findBlockParams.startIndex()<=indexInmBuffer && indexInmBuffer<=c.findBlockParams.endIndex()) {
					return false;
				}
				else return true;
			}
		}
		return false;
	}

	/**파일 전체를 즉시 update를 한다. In addition, also updates related files. 
	 * @param coreThreadID */
	public static void update(int coreThreadID) {
		Compiler changedCompiler = null;
		QueueItem lastItem = null;
		if (Update.listOfQueueItems.count>0) {
			lastItem = (QueueItem) Update.listOfQueueItems.getItem(Update.listOfQueueItems.count-1);
			changedCompiler = lastItem.compiler;
			Update.listOfQueueItems.reset();
		}
		else {
			return;
		}
		ArrayList result = new ArrayList(10);
		
		int i;
		if (interfaceChanged(lastItem)) {
			InterfaceErrorResolver.findJavaFilesReferringModifiedDocumentsInCompilerCache(changedCompiler, result);
		}
		else {
			String ext = FileHelper.getExt(changedCompiler.data.filename);
			if (ext.equals(".java")) {
				result.add(new File(changedCompiler.data.filename));
			}
		}
		
		for (i=0; i<result.count; i++) {
			File file = (File) result.getItem(i);
			Compiler compiler = CompilerCache.findCompiler(file.getAbsolutePath());
			ClassCache.deleteClassesHavingCompiler(compiler, coreThreadID);
		}
		
		for (i=0; i<result.count; i++) {
			File file = (File) result.getItem(i);
			String filePath = file.getAbsolutePath();
			CompilerInterface compiler = (CompilerInterface) CompilerCache.findCompiler(filePath);
			if (compiler==null) continue;
						
			if (compiler.data.isModified) {
				HighArray_CodeChar input = null;
				if (CommonGUI.editText_compiler.getCompiler()==compiler) {
					input = InterfaceErrorResolver.toHighArray_CodeChar(CommonGUI.editText_compiler.textArray);
				}
				else {
					input = InterfaceErrorResolver.toHighArray_CodeChar(compiler.data.textArray);
				}
				analyzeSyntax_update(compiler, input);
			}
			else {
				analyzeSyntax_update(compiler, compiler.data.strInput);
			}
			
			
		}
	}
	
	
	
		
	
	public static void analyzeSyntax_update(Compiler compiler, HighArray_CodeChar strInput) {
		
		CompilerData data = compiler.data;
				
		
		CompilerStatic.errors.removeErrors(compiler.data.filename);
		compiler.PairErrorExists = false;
			
		
		StringTokenizer tokenizer = new StringTokenizer();
		
		
		
		int i;
		for (i=0; i<strInput.count; i++) {
			CodeChar c = strInput.getItem(i); 
			c.type = CodeStringType.Text;
			c.setIsErrorChar(false);
		}			
		
		
		HighArray_CodeString mBufferInTokenizer = tokenizer.ConvertToStringArray2(strInput, 10000, data.language);		
		
		
		data.mBuffer = mBufferInTokenizer;
		data.mlistOfComments = tokenizer.mlistOfComments;
		Comment.setCompilerToAllComments(data.mlistOfComments, compiler);
		
				
		data.mlistOfAllArrayIntializers.reset2();
		data.mlistOfAllAssignStatements.reset2();
		data.mlistOfAllControlBlocks.reset2();
		data.mlistOfAllConstructor.reset2();
		data.mlistOfAllDefinedClasses.reset2();
		data.mlistOfAllForLoops.reset2();
		data.mlistOfAllFunctions.reset2();
		data.mlistOfAllLocalVarDeclarations.reset();
		data.mlistOfAllMemberVarDeclarations.reset();
		data.mlistOfAllTemplates.reset2();
		data.mlistOfAllTypeCasts.reset2();
		data.mlistOfAllVarUses.reset();
		data.mlistOfAllVarUsesHashed.reset();
		data.mlistOfAnnotations.reset2();
		data.mlistOfBlocks.reset2();
		data.mlistOfClass.reset2();
		//data.mlistOfComments.reset2();
		data.mlistOfFinally.reset2();
		data.mlistOfFindStatementParams.reset2();			
		data.mlistOfSpecialStatement.reset2();
		data.mlistOfThreeOperandsOperation.reset2();
		data.mlistOfNewLines.reset2();
		
		data.mlistOfImportedClasses.reset2();
		//if (Common_Settings.g_loadsImportStarInSource) {
			data.mlistOfImportedClassesStar.reset2();
		//}
		data.mlistOfImportStatements.reset2();
		data.mlistOfPackages.reset();
		data.mlistOfPackageStatements.reset2();
				
    
		compiler.FindAllClassesAndItsMembers2( 0, data.mBuffer.count-1, data.mlistOfClass, 
				data.language, ModeAllOrUpdate.Update, true, null, 0, true);
		
		data.strOutput = strInput;
		
		CommonGUI.loggingForMessageBox.setHides(true);
		
		
		Button[] list;
		data.menuClassAndMemberList.setContainerClassAndSrc(data.mBuffer, null);
		list = data.menuClassAndMemberList.getMenuListButtons(data.mBuffer, data.mlistOfClass);
	
		
		data.menuClassAndMemberList.setButtons(list);				
		
		//ErrorList ownErrors = CompilerStatic.errors.findErrors(compiler.data.filename);
		//ErrorList.showErrors(ownErrors);
		
		
		
		CompilerCache.update(compiler);
	
	}
}
