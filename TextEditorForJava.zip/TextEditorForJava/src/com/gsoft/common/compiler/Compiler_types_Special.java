package com.gsoft.common.compiler;

import java.io.File;

import android.graphics.Color;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.Code.CodeStringType;
import com.gsoft.common.CommonGUI;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.interfaces.IReset;
import com.gsoft.common.compiler.Compiler_types.FindAssignStatementParams;
import com.gsoft.common.compiler.Compiler_types.FindControlBlockParams;
import com.gsoft.common.compiler.Compiler_types.FindExpressionParams;
import com.gsoft.common.compiler.Compiler_types.FindFuncCallParam;
import com.gsoft.common.compiler.Compiler_types.FindVarUseParams;
import com.gsoft.common.compiler.Compiler_types.Language;
import com.gsoft.common.compiler.Compiler_types_Base.Block;
import com.gsoft.common.compiler.Compiler_types_Base.Error;
import com.gsoft.common.compiler.Compiler_types_Base.FindStatementParams;
import com.gsoft.common.compiler.TemplateBase.Template;
import com.gsoft.common.gui.edittext.EditText;
import com.gsoft.common.util.ArrayListIReset;
import com.gsoft.common.util.ArrayListInt;
import com.gsoft.common.util.HighArray;
import com.gsoft.common.util.hash.Hashtable2_String;

import com.gsoft.common.compiler.HighArray_CodeString;
import com.gsoft.common.compiler.CodeStringEx;
import com.gsoft.common.compiler.Fullname;
import com.gsoft.common.compiler.IndexForHighArray;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.CompilerInterface;
import com.gsoft.common.compiler.Array;
import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.Expression;
import com.gsoft.common.compiler.CompilerStatic;

public class Compiler_types_Special {
	/** 증감문, i++, ++i 등,
	 * i++; 의 경우에 startIndex는 구분자+1, endIndex는 ;을 포함하는 인덱스를 갖는다.*/
	public static class FindIncrementStatementParams extends FindStatementParams  implements IReset 
	{
		/** ++i에서 i, i++에서 i, ++class.var에서 class를 말한다.*/
		public FindVarUseParams lValue;
		/** ++i(0), i++(1), --i(2), i--(3)*/
		public int type;
		private int coreThreadID;
		//Compiler compiler;
		
		public String toString() {
			int i;
			String r = "";
			HighArray_CodeString mBuffer = compiler.data.mBuffer;
			int start = startIndex();
			int end = endIndex();
			for (i=start; i<=end; i++) {
				CodeString str = mBuffer.getItem(i);
				if (CompilerHelper.IsComment(str)) continue;
				else if (CompilerHelper.IsAnnotation(str)) continue;
				else r += str.str;
			}
			return r;
		}
		
		public FindIncrementStatementParams(Compiler compiler, int startIndex, int endIndex, int coreThreadID) {
			//super(compiler, startIndex, endIndex);
			this.compiler = compiler;
			this.startIndex = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, startIndex);
			this.endIndex = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, endIndex);
			this.coreThreadID = coreThreadID;
		}
		
		/** varUse에서 진짜 lValue를 설정한다.*/
		public void setLValue(FindVarUseParams varUse) {
			int indexLValue = Fullname.getFullNameIndex(compiler, false, varUse.index(), true);
			indexLValue = CompilerHelper.SkipBlank(compiler.data.mBuffer, true, 0, indexLValue);
			String varUseName = compiler.data.mBuffer.getItem(indexLValue).str;
			FindVarUseParams lValue = Compiler.getVarUseWithIndex(compiler.data.mlistOfAllVarUsesHashed, varUseName, indexLValue);
			this.lValue = lValue;
		}
		
		/** @param startIndexOfCloneInOriginSrc : 첫번째 호출할때는 -1, 두번째 호출할때는 해당 값
		 * @param listOfAllVarUses : 새로 복제된 listOfAllVarUses*/
		private void setChildVarUses(Compiler newCompiler, FindVarUseParams varUse, int startIndexOfLValueInOriginSrc, HighArray listOfAllVarUses, int startIndexOfCloneInOriginSrc, int startIndexOfmlistOfAllVarUses) {
			if (varUse==null) return;
			int offset;
			if (startIndexOfCloneInOriginSrc==-1) offset = 0;
			else offset = startIndexOfCloneInOriginSrc - startIndexOfLValueInOriginSrc;
			
			// 새로 복제된 listOfAllVarUses에서 인덱스가 일치하는 varUse로 바꿔준다.
			if (varUse.parent!=null) {
				FindVarUseParams parent = varUse.parent;
				int newIndex = parent.index()-startIndexOfLValueInOriginSrc+offset;
				int j;
				int len = listOfAllVarUses.getCount();
				for (j=startIndexOfmlistOfAllVarUses; j<len; j++) {
					FindVarUseParams v = (FindVarUseParams) listOfAllVarUses.getItem(j);
					if (v.index()==newIndex) {
						varUse.parent = v;
						varUse.inc = this;
						break;
					}
				}
			}
			// 새로 복제된 mlistOfAllVarUses에서 인덱스가 일치하는 varUse로 바꿔준다.
			if (varUse.child!=null) {
				FindVarUseParams child = varUse.child;
				int newIndex = child.index()-startIndexOfLValueInOriginSrc+offset;
				int j;
				int len = listOfAllVarUses.getCount();
				for (j=startIndexOfmlistOfAllVarUses; j<len; j++) {
					FindVarUseParams v = (FindVarUseParams) listOfAllVarUses.getItem(j);
					if (v.index()==newIndex) {
						varUse.child = v;
						varUse.child.inc = this;
						break;
					}
				}
			}
			if (varUse.index()==0) {
			}
			if (varUse.listOfArrayElementParams!=null) {
				int i;
				ArrayListIReset list = varUse.listOfArrayElementParams;
				list = (ArrayListIReset)list.clone();
				for (i=0; i<list.count; i++) {
					FindFuncCallParam func = (FindFuncCallParam) list.getItem(i);
					func = (FindFuncCallParam) func.clone();
					func.startIndex = IndexForHighArray.indexRelative(func, compiler.data.mBuffer, func.startIndex() -startIndexOfLValueInOriginSrc+offset);
					func.endIndex = IndexForHighArray.indexRelative(func, compiler.data.mBuffer, func.endIndex() -startIndexOfLValueInOriginSrc+offset);
					func.compiler = newCompiler;
					if (func.expression!=null) {
						func.expression = (FindExpressionParams) func.expression.clone();
						func.expression.compiler = newCompiler;
					}
					
					if (func.expression!=null) {
						func.expression.startIndex = IndexForHighArray.indexRelative(func.expression, compiler.data.mBuffer, func.expression.startIndex()  -startIndexOfLValueInOriginSrc+offset);
						func.expression.endIndex = IndexForHighArray.indexRelative(func.expression, compiler.data.mBuffer, func.expression.endIndex()  -startIndexOfLValueInOriginSrc+offset);
						CodeStringEx[] postfix = new CodeStringEx[func.expression.postfix.length];
						
						for (int j=0; j<postfix.length; j++) {
							postfix[j] = (CodeStringEx) func.expression.postfix[j].clone();
							CodeStringEx token = postfix[j];
							token.indicesInSrc = (ArrayListInt)token.indicesInSrc.clone();
							token.listOfVarUses = (ArrayListIReset)token.listOfVarUses.clone();
							for (int k=0; k<token.indicesInSrc.count; k++) {								
								token.indicesInSrc.list[k] += -startIndexOfLValueInOriginSrc+offset;
								FindVarUseParams v = (FindVarUseParams) token.listOfVarUses.list[k];								
								if (v==null) continue;
								
								// 새로 복제된 mlistOfAllVarUses에서 인덱스가 일치하는 varUse로 바꿔준다.								 
								int newIndex = v.index()-startIndexOfLValueInOriginSrc+offset;
								int len = listOfAllVarUses.getCount();
								for (int m=startIndexOfmlistOfAllVarUses; m<len; m++) {
									FindVarUseParams v3 = (FindVarUseParams) listOfAllVarUses.getItem(m);
									if (v3.index()==newIndex) {
										token.listOfVarUses.list[k] = v3;
										v3.inc = this;
										break;
									}
								}
								
								// 중첩된 varUses들에 대해서 재귀적 호출
								/*FindVarUseParams newVarUse = (FindVarUseParams) token.listOfVarUses.list[k];
								this.setChildVarUses(newCompiler, newVarUse, startIndexOfLValueInOriginSrc, 
										mlistOfAllVarUses, startIndexOfCloneInOriginSrc, startIndexOfmlistOfAllVarUses);*/
							}//for (int k=0; k<token.indicesInSrc.count; k++) {
							
						}//for (int j=0; j<postfix.length; j++) {
						func.expression.postfix = postfix;
					}//if (func.expression!=null) {
					list.list[i] = func;
				}//for (i=0; i<list.count; i++) {
				varUse.listOfArrayElementParams = list;
			}//if (varUse.listOfArrayElementParams!=null) {
			
			if (varUse.index()==0) {
			}
		}
		
		public FindAssignStatementParams toFindAssignStatementParams() {
			if (lValue.index()==19264) {
			}
			HighArray_CodeString newSrc = new HighArray_CodeString(10);
			int startIndexOfLValue, endIndexOfLValue;
			int startIndexOfLValueInOriginSrc, endIndexOfLValueInOriginSrc;
			startIndexOfLValue = Fullname.getFullNameIndex(compiler, true, lValue.index(), true);
			endIndexOfLValue = Fullname.getFullNameIndex(compiler, false, lValue.index(), false);
			
			startIndexOfLValueInOriginSrc = startIndexOfLValue;
			endIndexOfLValueInOriginSrc = endIndexOfLValue;
			
			endIndexOfLValue -= startIndexOfLValue;
			startIndexOfLValue = 0;
			
			int i;
			for (i=startIndexOfLValueInOriginSrc; i<=endIndexOfLValueInOriginSrc; i++) {
				// 인용문, 주석, 상수와 같은 스트링 타입도 이전 소스와 같게 된다. 
				CodeString str = compiler.data.mBuffer.getItem(i);
				newSrc.add(str);
			}
			
			int indexOfEqual = newSrc.count;
			
			newSrc.add(new CodeString("=", Common_Settings.textColor));
			
			int startIndexOfClone = indexOfEqual+1;
			int len = 0;
			for (i=0; i<indexOfEqual; i++) {
				// 인용문, 주석, 상수와 같은 스트링 타입도 이전 소스와 같게 된다.
				CodeString str = newSrc.getItem(i);
				newSrc.add(str);
				len++;
			}
			
			int indexOfPlus = startIndexOfClone+len;			
			CodeString operator = null;
			if (this.type==0 || this.type==1) 
				operator = new CodeString("+", Common_Settings.textColor);
			else
				operator = new CodeString("-", Common_Settings.textColor);
			operator.setType(CodeStringType.Text);
			newSrc.add(operator);
			
			int indexOf1 = indexOfPlus+1;
			CodeString strOne = new CodeString("1", Common_Settings.textColor);
			strOne.setType(CodeStringType.Constant);
			newSrc.add(strOne);
			
			
			Compiler newCompiler = new CompilerInterface();
			newCompiler.data.mBuffer = newSrc;
			newCompiler.data.filename = compiler.data.filename;
			newCompiler.compilerStack.setLanguage(Language.Java);
			if (newCompiler.data.mlistOfAllVarUsesHashed==null) {
				newCompiler.data.mlistOfAllVarUsesHashed = new Hashtable2_String(10, 2);
			}
			
			HighArray mlistOfAllVarUses = new HighArray(10);
			int startIndex = Compiler.getIndexInmListOfAllVarUses(compiler.data.mBuffer, compiler.data.mlistOfAllVarUses, 0, startIndexOfLValueInOriginSrc, true);
			int endIndex =  Compiler.getIndexInmListOfAllVarUses(compiler.data.mBuffer, compiler.data.mlistOfAllVarUses, startIndex, endIndexOfLValueInOriginSrc, false);
			
			
			int newStartIndex = 0;
			int newEndIndex = newSrc.count-1;
			FindAssignStatementParams r = new FindAssignStatementParams(newCompiler, newStartIndex, newEndIndex);
			
			// 2번 넣어준다.
			int indexVarUse;
			for (i=startIndex; i<=endIndex; i++) {
				FindVarUseParams varUse = (FindVarUseParams) compiler.data.mlistOfAllVarUses.getItem(i);
				FindVarUseParams varUse2 = (FindVarUseParams) varUse.clone();
				indexVarUse = varUse2.index();
				indexVarUse -= startIndexOfLValueInOriginSrc;
				indexVarUse = CompilerHelper.SkipBlank(newSrc, false, indexVarUse, newSrc.count-1);
				varUse2.index = IndexForHighArray.indexRelative(varUse2, newSrc, indexVarUse);
				varUse2.inc = this;
				mlistOfAllVarUses.add(varUse2);
			}//for (i=startIndex; i<=endIndex; i++) {
			
			if (lValue.index()==394) {
			}
			
			mlistOfAllVarUses.getCount();
			for (i=0; i<len; i++) {
				FindVarUseParams varUse = (FindVarUseParams) mlistOfAllVarUses.getItem(i);
				this.setChildVarUses(newCompiler, varUse, startIndexOfLValueInOriginSrc, mlistOfAllVarUses, -1, 0);
			}
			
			mlistOfAllVarUses.getCount();
			int k = startIndexOfClone;
			int startIndexOfmlistOfAllVarUses = mlistOfAllVarUses.getCount();
			int indexVarUse2;
			for (i=startIndex; i<=endIndex; i++) {
				FindVarUseParams varUse = (FindVarUseParams) compiler.data.mlistOfAllVarUses.getItem(i);
				FindVarUseParams varUse2 = (FindVarUseParams) varUse.clone();
				indexVarUse2 = varUse2.index();
				indexVarUse2 -= startIndexOfLValueInOriginSrc;
				indexVarUse2 += k;
				indexVarUse2 = CompilerHelper.SkipBlank(newSrc, false, indexVarUse2, newSrc.count-1);
				varUse2.index = IndexForHighArray.indexRelative(varUse2, newSrc, indexVarUse2);
				varUse2.inc = this;
				//k++;
				mlistOfAllVarUses.add(varUse2);			
				
			}
			
			if (lValue.index()==394) {
			}
			
			// 넣어진 varUse들의 parent와 child를 newSrc에서의 varUse로 바꿔준다.
			int len3 = mlistOfAllVarUses.getCount();
			for (i=startIndexOfmlistOfAllVarUses; i<len3; i++) {
				FindVarUseParams varUse = (FindVarUseParams) mlistOfAllVarUses.getItem(i);
				this.setChildVarUses(newCompiler, varUse, startIndexOfLValueInOriginSrc, mlistOfAllVarUses, 
						startIndexOfLValueInOriginSrc+startIndexOfClone, startIndexOfmlistOfAllVarUses);
			}
			
			int index = indexOf1-startIndexOfLValue;			 
			FindVarUseParams varUseOne = new FindVarUseParams(null);
			varUseOne.name = "1";
			varUseOne.originName = "1";
			varUseOne.index = IndexForHighArray.indexRelative(varUseOne, newSrc, index);
			varUseOne.isForVarOrForFunc = true;
			varUseOne.inc = this;
			index = CompilerHelper.SkipBlank(newSrc, false, index, newSrc.count-1);
			mlistOfAllVarUses.add(varUseOne);
			
			
			if (lValue.index()==394) {
			}
			
			
			
			newCompiler.data.mlistOfAllVarUses = mlistOfAllVarUses;
			
			int len4 = mlistOfAllVarUses.getCount();
			for (i=0; i<len4; i++) {
				try{
					if (i==2) {
					}
					FindVarUseParams varUse = (FindVarUseParams)mlistOfAllVarUses.getItem(i);
				newCompiler.data.mlistOfAllVarUsesHashed.input(varUse.originName, varUse);
				}catch(Exception e) {
					if (Common_Settings.g_printsLog) e.printStackTrace();
				}
			}
			
			FindVarUseParams lValue = null;
			for (i=0; i<len4; i++) {
				FindVarUseParams varUse = (FindVarUseParams) mlistOfAllVarUses.getItem(i);
				int indexOfEqual2 = newCompiler.IsLValue(newSrc, varUse);
				if (indexOfEqual2>0) {
					lValue = varUse;
					break;
				}
			}
			
			
			
			
			r.compiler = newCompiler;
			r.indexOfEqual = IndexForHighArray.indexRelative(r, newSrc, indexOfEqual-startIndexOfLValue);
			r.lValue = lValue;			
			r.rValue = new FindFuncCallParam(newCompiler, r.indexOfEqual()+1, newEndIndex);
			r.lValue.rValue = r.rValue;
			
			try {
				r.rValue.typeFullName = Expression.getTypeOfExpression(newCompiler, r.rValue, coreThreadID);
			}catch(Exception e) {
				if (Common_Settings.g_printsLog) e.printStackTrace();
			}
			return r;
			
		}
	}
	
	/** 배열 초기화문*/
	public static class FindArrayInitializerParams extends Block  implements IReset {
		/*int startIndex;
		int endIndex;
		boolean found;*/
		
		/** 배열초기화문의 변수선언*/
		//FindVarParams var;
		
		/** 배열초기화문의 변수(varUse)의 인덱스, int[] a = {1, 2};에서 a의 인덱스를 말한다.*/ 
		IndexForHighArray nameIndex=null;
		/** int[] a = {1, 2};에서 {의 인덱스을 말한다.*/
        IndexForHighArray indexOfLeftParenthesis=null;
        /** int[] a = {1, 2};에서 }의 인덱스을 말한다.*/
        IndexForHighArray indexOfRightParenthesis=null;
        
        /** int[] a = {1, 2};에서 a의 인덱스을 말한다.*/
        public FindVarUseParams varUse;
        
        /** int[] a = {1, 2};에서 int[]을 말한다. Setted in Compiler.findTypesOfExpressionsOfArrayInitializer().*/
        public String typeFullName;
        
        /** int[][] a = {{1}, {2}};에서 dimension은 2이다. 최상위 노드에 있는 값만 정확하다.*/
        public int dimension;
        /** 배열초기화문의 노드의 깊이, 0부터 시작<br>
         * int[][][] colors2 = {<br>
	    		{//a0<br>
		    		{Color.BLACK, Color.WHITE}, //a00<br>
		    		{Color.YELLOW,Color.BLUE, Color.GREEN} //a01<br>
	    		},
	    		 
	    		{//a1<br>
	        	    {Color.YELLOW,Color.BLUE, Color.GREEN} //a11<br>
	        	}
			};//2면 2행 3열<br>
			colors2->a0->a00->Color.BLACK, Color.WHITE <br>
					   ->a01->Color.YELLOW,Color.BLUE, Color.GREEN <br>
			 	   ->a1->a11->Color.YELLOW,Color.BLUE, Color.GREEN <br>
	       깊이   :   0	  1	  2 	<br>
	       모든 노드에 저장된다.*/
        public int depth;
        /** int[][] a = {{1}, {2}};에서 listOfLength은 행(2), 열(1)이다. <br>
         * int[][][] a = {{{1}, {2}},{{1}, {2}}};에서 listOfLength은 면(2), 행(2), 열(1)이다.<br>
         * 최상위 노드에 있는 값만 정확하다.*/
        public ArrayListInt listOfLength;
        /** 배열에서의 인덱스, 배열초기화문의 가장 밑에 있는 수식들의 리스트일 경우는 -1이다.*/
        public int index = -1;
        
        
        public int nameIndex() {
        	if (nameIndex==null) return -1;
        	return nameIndex.index();
        }
        
        public int indexOfLeftParenthesis() {
        	if (indexOfLeftParenthesis==null) return -1;
        	return indexOfLeftParenthesis.index();
        }
        
        public int indexOfRightParenthesis() {
        	if (indexOfRightParenthesis==null) return -1;
        	return indexOfRightParenthesis.index();
        }
        
        /**FindArrayInitializerParams[], 배열안에 수식이 아니라 또다른 배열의 리스트이면 count가 0이 아니다. <br>
         * int[][] arr = {{1,2},{3,4}}; 에서 {1,2},{3,4}를 의미한다.*/
        public ArrayListIReset listOfFindArrayInitializerParams = new ArrayListIReset(10);
        
        /**FindFuncCallParam[], 배열안에 또다른 배열이 아니라 수식들의 리스트이면  count가 0이 아니다.<br>
         * int[][] arr = {{1,2},{3,4}}; 에서 1,2와 3,4를 의미한다.*/
        public ArrayListIReset listOfFindFuncCallParam = new ArrayListIReset(10);
        
        /** 배열초기화문이 들어있는 해당 문서파일*/
        //Compiler compiler;
        
        public String toString() {
			int i;
			String r = "";
			HighArray_CodeString mBuffer = compiler.data.mBuffer;
			
			int start = indexOfLeftParenthesis();
			int end = indexOfRightParenthesis();
			for (i=start; i<=end; i++) {
				CodeString str = mBuffer.getItem(i);
				if (CompilerHelper.IsBlank(str)) continue;
				else if (CompilerHelper.IsComment(str)) continue;
				else r += str.str;
			}
			return r;
		}
        
        
        public FindArrayInitializerParams(Compiler compiler, 
        		int nameIndex, int indexOfLeftParenthesis, int indexOfRightParenthesis) {
        	//super(compiler, -1, -1);
        	this.compiler = compiler;
			this.startIndex = null;
			this.endIndex = null;
			
        	this.nameIndex = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, indexOfLeftParenthesis);
            this.indexOfLeftParenthesis = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, indexOfLeftParenthesis);
            this.indexOfRightParenthesis = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, indexOfRightParenthesis);
            this.compiler = compiler;
        }
        
        /**배열에서 어떤 원소의 차원별 인덱스들을 리턴한다. 
         * 예를들어 int[][] arr = {{1,2,3},{4,5,6},{7,8,9}}; 
         * 여기에서 원소 5의 결과값은 1과 1이 된다. 원소 2는 1과 0이 된다.*/
        public ArrayListInt getIndicesOfParentArrayIncludingOwnIndex(FindArrayInitializerParams array) {
        	ArrayListInt r = new ArrayListInt(5);
        	if (array.index==-1) return r;
        	r.add(array.index);
        	while (array.parent!=null) {
        		if (array.parent instanceof FindArrayInitializerParams){
        			FindArrayInitializerParams parent = (FindArrayInitializerParams) array.parent;
        			if (parent.index==-1) break; // 최상위 노드에선 index가 -1이다.
        			r.add(parent.index);
        			array = (FindArrayInitializerParams) array.parent;
        		}
        		else {
        			break;
        		}        		
        	}
        	return r;
        }

		@Override
		public void destroy() {
			super.destroy();
			
			if (this.indexOfLeftParenthesis!=null) {
				this.indexOfLeftParenthesis.destroy();
				this.indexOfLeftParenthesis = null;
			}
			if (this.indexOfRightParenthesis!=null) {
				this.indexOfRightParenthesis.destroy();
				this.indexOfRightParenthesis = null;
			}
			if (this.nameIndex!=null) {
				this.nameIndex.destroy();
				this.nameIndex = null;
			}
			if (this.findBlockParams!=null) {
				this.findBlockParams.destroy();
				this.findBlockParams = null;
			}
			if (this.listOfFindArrayInitializerParams!=null) {
				this.listOfFindArrayInitializerParams.destroy();
				this.listOfFindArrayInitializerParams = null;
			}
			if (this.listOfFindFuncCallParam!=null) {
				this.listOfFindFuncCallParam.destroy();
				this.listOfFindFuncCallParam = null;
			}
			if (this.listOfLength!=null) {
				this.listOfLength.reset2();
				this.listOfLength = null;
			}
			this.typeFullName = null;
			this.varUse = null;
		}
	}
	
	public static class FindThreeOperandsOperation extends Block {
		/**Compiler.FindAllClassesAndItsMembers2_sub()에서 오브젝트가 생성되어 넣어진다.*/
		public int indexOfQuestion;
		/**Compiler.FindAllClassesAndItsMembers2_sub()에서 오브젝트가 생성되어 넣어진다.*/
		int indexOfColon;
		/** traverseThreeOperandsOperation()에서 넣어진다. 
		 * traverseThreeOperandsOperation()의 파라미터인 funcCall.endIndex()가 된다.*/
		public int indexOfEndOfThreeOperandsOperation;
		public Block parent;
		public int indexOfCondition;
		public int indexOfExitOfRun;
		public int indexOfRunOfThreeOperandsOperation;
		FindThreeOperandsOperation(int indexOfQuestion, int indexOfColon) {
			this.indexOfQuestion = indexOfQuestion;
			this.indexOfColon = indexOfColon; 
		}
		@Override
		public void destroy() {
			
			
		}
	}
	
	
	/** 특별한 블럭(synchronized, try, catch, finally등)
	 * FindControlBlockParams를 상속하므로 제어블록의 일종이다. 
	 * 이것은 문장들을 적절한 제어블록에 넣을때(Compiler.inputStatementToSuitableBlock_caller() 참조)
	 * try, catch 등의 블록도 같이 포함해서 넣기 위한 것이다.
	 * 제어블록이지만 catOfControls는 null이 된다.*/
	public static class FindSpecialBlockParams extends /*Block*/FindControlBlockParams {
		public int specialBlockType;
		/*int startIndex;
		int endIndex;
		boolean found;*/
		
		//IndexForHighArray nameIndex=null;
		
		/**used in fake try-catch(console) or fake try-finally(synchronized)<br>
		 * if controlBlock.isFake is true, this is not null.
		 */
		public String anotherName;
		
		/**bytecode 생성시 필요,<br> 
		 * try, catch, finally가 finally 안에 선언되어 있는 경우 finally가 연결된 try, catch에 복제되기 때문에
	 * try, catch, finally의 startPC와 endPC는 리스트가 되어야 한다.*/
		public ArrayListInt listOfStartPC = new ArrayListInt(2);
		/**bytecode 생성시 필요,<br>
		 * try, catch, finally가 finally 안에 선언되어 있는 경우 finally가 연결된 try, catch에 복제되기 때문에
	 * try, catch, finally의 startPC와 endPC는 리스트가 되어야 한다.*/
		public ArrayListInt listOfEndPC = new ArrayListInt(2);
		
		/** catch나 finally블록에서 연결된 try블록을 말한다.*/
		public FindSpecialBlockParams tryBlockConnected;
        
        public static final int SpecialBlockType_synchronized = 1;
        public static final int SpecialBlockType_try = 2;
        public static final int SpecialBlockType_catch = 3;
        public static final int SpecialBlockType_finally = 4;
        
       /* public void destroy() {
        	super.destroy();
    		if (tryBlockConnected!=null) {
    			tryBlockConnected.destroy();
    			tryBlockConnected = null;
    		}
    	}*/
        
        
        
        /**isFake속성에 관계없이 try, catch, finally, synchronized를 리턴한다.*/
        public String getName() {
        	if (this.specialBlockType==SpecialBlockType_try) {
        		return "try";
        	}
        	else if (this.specialBlockType==SpecialBlockType_catch) {
        		return "catch";
        	}
        	else if (this.specialBlockType==SpecialBlockType_finally) {
        		return "finally";
        	}
        	else if (this.specialBlockType==SpecialBlockType_synchronized) {
        		return "synchronized";
        	}
        	return null;
        }
              
     		
    	
		public FindSpecialBlockParams(Compiler compiler, int specialBlockType, int startIndex, int endIndex) {
			super(compiler, null, startIndex, endIndex);
			this.specialBlockType = specialBlockType;			
			//this.findBlockParams = new FindBlockParams(-1, -1);
		}
		
		public String toString() {
			if (specialBlockType==1) return "synchronized";
			else if (specialBlockType==2) return "try";
			else if (specialBlockType==3) return "catch";
			else if (specialBlockType==4) return "finally";
			return null;
		}
	}
	
	
	/** FindVarDeclarationAndVarUses에서 return, break, continue, throw 문등을 찾고 
	 *  mlistOfSpecialStatements에 넣는다.*/
	public static class FindSpecialStatementParams extends FindStatementParams
	{
		/*int startIndex;
		int endIndex;
		boolean found;*/
		/**return, break, continue, throw의 인덱스, 
		 * kewordIndex==null이면 synchronized안이나 메서드 안에 있는 가짜 try-catch블록에서
		 * catch안에 있는 가짜 throw문이다.
		 * 가짜 try-catch블록이란 try-catch가 없는 메서드내에서 예외를 호출함수로 던져주거나 
		 * try-catch가 없는 synchronized블록에서 예외가 발생할 경우 모니터를 해제하기 위한 것이다.
		 * 현재는 try-catch가 있더라도 가짜 try-catch블록을 만든다.
		 * (그래도 문제가 안되기 때문에)
		 * Compiler.putTryCatchShieldToSynchronized()를 참조한다.*/
		IndexForHighArray kewordIndex = null;
		
		/** 독립적 return, break 문 등이 들어있는 해당 문서파일*/
		//Compiler compiler;
		
		/** return expression; 와 같이 expression의 typeName을 말한다.*/
		public FindFuncCallParam funcCall;
		
		/**return, break, continue, throw의 인덱스, 
		 * kewordIndex==null이면 synchronized안이나 메서드 안에 있는 가짜 try-catch블록에서
		 * catch안에 있는 가짜 throw문이다.
		 * 가짜 try-catch블록이란 try-catch가 없는 메서드내에서 예외를 호출함수로 던져주거나 
		 * try-catch가 없는 synchronized블록에서 예외가 발생할 경우 모니터를 해제하기 위한 것이다.
		 * 현재는 try-catch가 있더라도 가짜 try-catch블록을 만든다.
		 * (그래도 문제가 안되기 때문에)
		 * Compiler.putTryCatchShieldToSynchronized()를 참조한다.*/
		public int kewordIndex() {
			if (kewordIndex==null) return -1;
			return kewordIndex.index();
		}
		
		public String toString() {
			int i;			
			HighArray_CodeString mBuffer = compiler.data.mBuffer;
			String r = "";
			int start = startIndex();
			int end = endIndex();
			for (i=start; i<=end; i++) {
				CodeString str = mBuffer.getItem(i);
				if (CompilerHelper.IsComment(str)) continue;
				else if (CompilerHelper.IsAnnotation(str)) continue;
				else r += str.str;
			}
			return r;
		}
		
		public FindSpecialStatementParams(Compiler compiler, int startIndex, int endIndex, int kewordIndex) {
			//super(compiler, startIndex, endIndex);
			this.compiler = compiler;
			this.startIndex = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, startIndex);
			this.endIndex = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, endIndex);
			this.kewordIndex = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, kewordIndex);
		}
	}
	
	
	/** 생성자를 표현한다.*/
	public static class Constructor implements IReset {
		/** 배열일 경우 배열기호도 포함한다.*/
		String fullname;
		/**new의 시작과 끝, new불포함, 배열이나 함수의 괄호 포함한 인덱스이다.*/
		IndexForHighArray startIndex;
		/**new의 시작과 끝, new불포함, 배열이나 함수의 괄호 포함한 인덱스이다.*/
		IndexForHighArray endIndex;
		/**new의 시작과 끝, new불포함, 배열이나 함수의 괄호 포함하지않은 인덱스이다.*/
		IndexForHighArray startIndexExceptPair;
		/**new의 시작과 끝, new불포함, 배열이나 함수의 괄호 포함하지않은 인덱스이다.*/
		IndexForHighArray endIndexExceptPair;
		IndexForHighArray indexOfNew;
		Compiler compiler;
		public int dimension;
		/** stack=new Stack<Block>();에서 template은 null이 아니다.*/
		public Template template;
		
		//public ArrayListInt listOfLength;
		
		Constructor(Compiler compiler) {
			this.compiler = compiler;
		}
		
		public int startIndex() {
			if (startIndex==null) return -1;
			return startIndex.index();
		}
		
		public int endIndex() {
			if (endIndex==null) return -1;
			return endIndex.index();
		}
		
		public int startIndexExceptPair() {
			if (startIndexExceptPair==null) return -1;
			return startIndexExceptPair.index();
		}
		
		public int endIndexExceptPair() {
			if (endIndexExceptPair==null) return -1;
			return endIndexExceptPair.index();
		}
		
		public int indexOfNew() {
			if (indexOfNew==null) return -1;
			return indexOfNew.index();
		}
		
		/** 호출시 fullname이 null이 아니면 그것을 리턴, null이면 소스를 뒤져서 fullname을 설정하고 리턴
		 * new int[10]; 이면 int[]을 리턴한다.
		 * @param coreThreadID */
        String getType(HighArray_CodeString src, int typeStartIndex, int typeEndIndex, int coreThreadID) {
        	if (fullname!=null) return fullname;
        	else {
	        	/*if (returnTypeStartIndex==-1 || returnTypeEndIndex==-1) {	        		
	        		return "";
	        	}*/
	        	//returnType = compiler.getFullNameType(src, returnTypeStartIndex, returnTypeEndIndex);
        		fullname = Fullname.getFullNameType(compiler, typeStartIndex, typeEndIndex, coreThreadID);
        		fullname = Array.getArrayType(fullname, dimension);
	        	//if (returnType==null) returnType = "";
	        	return fullname;
        	}
        }

		@Override
		public void destroy() {
			
			this.fullname = null;
			if (this.startIndex!=null) {
				this.startIndex.destroy();
				this.startIndex = null;
			}
			if (this.endIndex!=null) {
				this.endIndex.destroy();
				this.endIndex = null;
			}
			if (this.startIndexExceptPair!=null) {
				this.startIndexExceptPair.destroy();
				this.startIndexExceptPair = null;
			}
			if (this.endIndexExceptPair!=null) {
				this.endIndexExceptPair.destroy();
				this.endIndexExceptPair = null;
			}
			if (this.indexOfNew!=null) {
				this.indexOfNew.destroy();
				this.indexOfNew = null;
			}
			/*if (this.compiler!=null) {
				this.compiler.destroy();
				this.compiler = null;
			}*/
			if (this.template!=null) {
				this.template.destroy();
				this.template = null;
			}
		}
	}
	
	
	public static class ErrorList extends ArrayListIReset {

		public ErrorList(int initMaxLength) {
			super(initMaxLength);
			
		}
		
		/**When deleting or renaming any files in a project, then remove errors
		 * Refer to Builder.build(fileList)*/
		public ErrorList removeErrorsInFileThatDoesNotExist() {
			int i;
			ErrorList newList = new ErrorList(this.count); 
			for (i=0; i<this.count; i++) {
				Error error = (Error) this.getItem(i);
				String filename = error.compiler.data.filename;
				File file = new File(filename);
				if (file.exists()) {
					newList.addForcely(error);
				}
			}
			return newList;
		}
		
		public ErrorList removeErrorsOutSideOfProject(String projectNamePath) {
			int i;
			ErrorList newList = new ErrorList(this.count); 
			for (i=0; i<this.count; i++) {
				Error error = (Error) this.getItem(i);
				String filename = error.compiler.data.filename.toString();				
				if (filename.contains(projectNamePath)) {
					newList.addForcely(error);
				}
			}
			return newList;
		}
		
		/**filename을 갖는 에러들을 모두 제거한다.*/
		public void removeErrors(String filename) {
			int i;
			ErrorList newList = new ErrorList(this.count); 
			for (i=0; i<this.count; i++) {
				Error error = (Error) this.getItem(i);
				if (!error.compiler.data.filename.equals(filename)) {
					newList.addForcely(error);
				}
			}
			this.list = newList.list;
			this.count = newList.count;
		}
		
		/**filename을 갖는 에러들만 리턴한다.*/
		public ErrorList findErrors(String filename) {
			int i;
			ErrorList newList = new ErrorList(this.count); 
			for (i=0; i<this.count; i++) {
				Error error = (Error) this.getItem(i);
				if (error.compiler.data.filename.equals(filename)) {
					newList.addForcely(error);
				}
			}
			return newList;
		}
		
		@Override
		/** 괄호 에러가 존재하면 에러를 추가시키지 못한다.*/
		synchronized public void add(IReset e) {			
			Error error = (Error) e;
			//if (error.compiler.PairErrorExists) return;
			
			super.add(e);			
			
			this.setIsErrorString(error);
			
			CommonGUI.editText_compiler.buttonProblems.setBackColor(Color.RED);
			CommonGUI.editText_compiler.buttonProblemsAll.setBackColor(Color.RED);
		}
		
		void setIsErrorString(Error error) {
			int startIndex = error.startIndex();
			int endIndex = error.endIndex();
			if (startIndex==-1 || endIndex==-1) return;
			int i;
			HighArray_CodeString src = error.compiler.data.mBuffer;
			if (src==null) return;
			for (i=startIndex; i<=endIndex; i++) {
				CodeString str = src.getItem(i);
				str.setIsErrorString(true);
			}
		}
		
		/** Refer to add()*/
		synchronized public void addForcely(IReset e) {
			Error error = (Error) e;
			
			super.add(e);
			
			this.setIsErrorString(error);
			
			CommonGUI.editText_compiler.buttonProblems.setBackColor(Color.RED);
			CommonGUI.editText_compiler.buttonProblemsAll.setBackColor(Color.RED);
		}
		
		/**에러들을 invalid var use이 앞에 나오도록 정렬한다.*/
		/*public void sort() {
			ArrayListIReset newList = new ArrayListIReset(this.count);
			int i;
			for (i=0; i<this.count; i++) {
				Error error = (Error) this.list[i];
				if (error.msg.contains("invalid var use")) {
					newList.add(error);
				}
			}
			for (i=0; i<this.count; i++) {
				Error error = (Error) this.list[i];
				if (!error.msg.contains("invalid var use")) {
					newList.add(error);
				}
			}
			this.list = newList.list;
			this.count = newList.count;
		}*/
		
		
		
		/** 에러들을 정렬해서 menuProblemList_EditText에 설정한다.*/
		public static void showErrors(ErrorList ownErrors) {
			
			//ownErrors.sort();
			EditText[] problemList = CompilerStatic.menuProblemList_EditText.getMenuListEditTexts(ownErrors);
			CompilerStatic.menuProblemList_EditText.setEditTexts(problemList);
		}
		
	}
	
	
	/** (, )으로 이루어지는 작은 블록을 말한다.*/
	public static class FindSmallBlockParams  implements IReset {
		IndexForHighArray startIndex;
		IndexForHighArray endIndex;
		Compiler compiler;
		
		FindSmallBlockParams(Compiler compiler, int startIndex, int endIndex) {
			this.startIndex = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, startIndex);
			this.endIndex = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, endIndex);
			this.compiler = compiler;
		}

		@Override
		public void destroy() {
			
			
		}

		public int startIndex() {
			
			if (startIndex==null) return -1;
			return startIndex.index();
		}
		
		public int endIndex() {
			
			if (endIndex==null) return -1;
			return endIndex.index();
		}
	}
	
	/** [, ]으로 이루어지는 배열 블록을 말한다.*/
	public static class FindLargeBlockParams  implements IReset {
		IndexForHighArray startIndex;
		IndexForHighArray endIndex;
		Compiler compiler;
		
		FindLargeBlockParams(Compiler compiler, int startIndex, int endIndex) {
			this.startIndex = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, startIndex);
			this.endIndex = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, endIndex);
			this.compiler = compiler;
		}

		public int startIndex() {
			
			if (startIndex==null) return -1;
			return startIndex.index();
		}
		
		public int endIndex() {
			
			if (endIndex==null) return -1;
			return endIndex.index();
		}
		
		@Override
		public void destroy() {
			
			
		}
	}

	
}
