package com.gsoft.common.compiler;

import java.io.File;

import android.graphics.Point;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.FileHelper;
import com.gsoft.common.interfaces.IReset;
import com.gsoft.common.compiler.ClassCache.ClassCacheList;
import com.gsoft.common.compiler.CompilerStack.ReturnOfFindAccessModifier;
import com.gsoft.common.compiler.Compiler_types.CategoryOfControls;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.Compiler_types.FindControlBlockParams;
import com.gsoft.common.compiler.Compiler_types.FindFunctionParams;
import com.gsoft.common.compiler.Compiler_types.FindVarParams;
import com.gsoft.common.compiler.Compiler_types.FindVarUseParams;
import com.gsoft.common.compiler.Compiler_types_Base.Block;
import com.gsoft.common.compiler.Compiler_types_Base.FindStatementParams;
import com.gsoft.common.compiler.Compiler_types_Base.GetVarUseWithIndexReturnType;
import com.gsoft.common.compiler.Compiler_types_Special.ErrorList;
import com.gsoft.common.compiler.Compiler_types_Special.FindSpecialBlockParams;
import com.gsoft.common.compiler.Compiler_types_Special.FindSpecialStatementParams;
import com.gsoft.common.compiler.classloader.Loader;
import com.gsoft.common.compiler.gui.MenuProblemList_EditText;
import com.gsoft.common.gui.TextView;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListCodeString;
import com.gsoft.common.util.ArrayListIReset;
import com.gsoft.common.util.ArrayListInt;
import com.gsoft.common.util.ArrayListString;
import com.gsoft.common.util.HighArray;
import com.gsoft.common.util.hash.Hashtable2_FindClassParams;
import com.gsoft.common.util.hash.Hashtable2_String;

import com.gsoft.common.compiler.CodeStringEx;
import com.gsoft.common.compiler.HighArray_CodeString;
import com.gsoft.common.compiler.ClassCache;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.Compiler;

public class CompilerStatic {
	
	
	public static ErrorList errors = new ErrorList(30);
	
	/**FindClassParams[], 
	 * 현재 소스파일에서 정의된 클래스나 import된 클래스, 이 소스파일에서
	 * 읽어들인 클래스들이 등록된 클래스들의 집합, 
	 * 나중에 현재 소스파일이 아니라 전체 프로젝트 단위의 클래스집합으로 바꿀것이다.*/
	public static ClassCacheList[] mlistOfAllClasses;
	/** mlistOfAllClasses의 해시리스트*/
	public static Hashtable2_FindClassParams[] mlistOfAllClassesHashed;
	
	
	
	static {
		ClassCache.makeClassCachesForMultiCore(1);
	}
	
	
	/** CompilerHelper.loadClassFromSrc_onlyInterface()에서 이미 로드를 시도했지만 실패한 소스파일의 리스트*/
	//public static ArrayListString mlistOfLoadClassFromSrc_onlyInterface_failed = new ArrayListString(10);
	
	
	
	/** java.lang 패키지내에 있는 loadJavaLangPackage()에서 읽어들인다.*/
	static ArrayListString TypesOfDefaultLibraryOfJava = new ArrayListString(1);
	
	/** compiler마다 공유이므로 static이어야하나 현재는 tab문제와 src연결문제로 non-static,
	 * 다중문서를 열기 위해서는 Compiler클래스들의 리스트를 갖고 있으면 된다.*/
	public static MenuProblemList_EditText menuProblemList_EditText;
	
	/** LogBird를 위한 textView*/
	static TextView textViewLogBird;
	
	/** 수식트리, byteCodes를 위한 textView*/
	public static TextView textViewExpressionTreeAndMessage;
	
	
	
	/**CompilerHelper.loadClassFromSrc_onlyInterface()에서 이미 로드한 소스파일인지를 확인한다.*/
	/*static boolean AlreadyLoadedClassFromSrc_onlyInterface_failed(String srcPath) {
		int i;
		for (i=0; i<mlistOfLoadClassFromSrc_onlyInterface_failed.count; i++) {
			String path = mlistOfLoadClassFromSrc_onlyInterface_failed.getItem(i);
			if (path.equals(srcPath)) {
				return true;
			}
		}
		return false;
	}*/
	
	public static void loadJavaLangPackage() {
    	if (TypesOfDefaultLibraryOfJava!=null && TypesOfDefaultLibraryOfJava.count!=0) return;
    	
    	File javaLangFile = new File(Common_Settings.pathAndroid+File.separator+"java"+File.separator+"lang");
		String[] list = javaLangFile.list();
		ArrayListString listNew = new ArrayListString(50); 
		int i;
		if (list==null) {
			return;
		}
		for (i=0; i<list.length; i++) {
			int indexDollar = list[i].indexOf("$");
			if (indexDollar==-1) {
				int indexDot = list[i].indexOf(".");
				if (indexDot!=-1) {
					String str = list[i].substring(0, indexDot);
					listNew.add(str);
				}
			}
			else { // $가 있는경우, 즉 내부클래스인 경우
				// Character$Subset.class인 경우 item에는 Character, Subset순으로 들어간다.
				/*ArrayListString item = new ArrayListString(2);
				String filename = FileHelper.getFilename(list[i]);
				String token;
				do {
					int indexDollar2 = filename.indexOf("$");
					if (indexDollar2==-1) {
						item.add(filename);
						break;
					}
					else {
						token = filename.substring(0, indexDollar2);
						item.add(token);
						filename = filename.substring(indexDollar2+1, filename.length());
					}
				}while(true);*/
				
				
				int indexDot = list[i].indexOf(".");
				String name = list[i].replace('$', '.');
				if (indexDot!=-1) {
					String str = name.substring(0, indexDot);
					listNew.add(str);
				}
				
				//TypesOfDefaultLibraryOfJava2.add(item);
			}
		}
		TypesOfDefaultLibraryOfJava.setData(listNew);
    }
	
	
	
	/**mode가 0이면 Control.pathAndroid로부터, 
	 * mode가 1이면 Control.pathJaneSoft/output로부터
	 * mode가 2이면 Control.pathProjectSrc로부터 
	 * mode가 3이면 Control.pathOther_Lib로부터 그 아래에 있는 파일들의 리스트를 얻는다.
	 * 존재하지 않는 파일이나 디렉토리이면 null을 리턴한다.
	 * Compiler.loadLibraries2()에서 호출한다.*/
	public static ArrayList getAbsPath_FromVariousClassPath(int mode) {
		File parentFile = null;
		if (mode==0 || mode==1 || mode==2) {
			if (mode==0) {
				if (Common_Settings.pathAndroid==null) return null;
				parentFile = new File(Common_Settings.pathAndroid);
			}
			else if (mode==1) {
				if (Common_Settings.pathOutput==null) return null;
				parentFile = new File(Common_Settings.pathOutput);
			}
			else if (mode==2) {
				if (Common_Settings.pathProjectSrc==null) return null;
				parentFile = new File(Common_Settings.pathProjectSrc);
			}
			
			String[] list = parentFile.list();
			if (list==null) return null;
			ArrayList r = new ArrayList(list.length);
			int i;
			for (i=0; i<list.length; i++) {
				File packageFile = new File(parentFile.getAbsolutePath() + File.separator + list[i]);
				if (packageFile.isDirectory()) {
					 r.add(packageFile);
				}
			}
			return r;
		}
		else if (mode==3) {
			int i;
			ArrayList r = new ArrayList(Common_Settings.listOfOtherLibs.count);
			for (i=0; i<Common_Settings.listOfOtherLibs.count; i++) {
				String jarFileName = Common_Settings.listOfOtherLibs.getItem(i);
				parentFile = new File(jarFileName);
				
				String[] list = parentFile.list();
				if (list==null) continue;
				int j;
				for (j=0; j<list.length; j++) {
					String filename = list[j].toLowerCase();
					// META_INFO 폴더는 제외한다.
					if (filename.contains("meta")) continue;
					File packageFile = new File(parentFile.getAbsolutePath() + File.separator + list[j]);
					if (packageFile.isDirectory()) {
						 r.add(packageFile);
					}
				}
				
			}
			return r;
		}
		return null;
	}
	
	
	
	/**mode가 0이면 Control.pathAndroid로부터, 
	 * mode가 1이면 Control.pathJaneSoft/output로부터
	 * mode가 2이면 Control.pathProjectSrc로부터 fullnamePath을 연결하여 절대 path를 얻는다.
	 * mode가 3이면 Control.pathOther_Lib로부터 fullnamePath을 연결하여 절대 path를 얻는다.
	 * 존재하지 않는 파일이나 디렉토리이면 null을 리턴한다.
	 * @param slashedFullname : slashedFullname이 파일일 경우 확장자는 .class이거나 .java이어야 한다.
	 * 확장자는 붙여도 되고 안 붙여도 된다. com/gsoft/common/IO 과 같은 이름이어야 한다.*/
	public static File getAbsPath_FromVariousClassPath(int mode, String slashedFullname) {
		slashedFullname = FileHelper.getFilenameExceptExt(slashedFullname);
		File parentFile = null;
		if (mode==0) {
			parentFile = new File(Common_Settings.pathAndroid+File.separator+slashedFullname);
			if (FileHelper.isDirectory(parentFile.getAbsolutePath())) return parentFile;		
			File parentFile2 = new File(parentFile.getAbsolutePath()+".class");
			if (!parentFile2.exists()) {
				String classPath = FileHelper.getFilenameExceptExt(parentFile2.getAbsolutePath());
				String path = Loader.fixClassPath(classPath);
				if (path==null) return null;
				return new File(path);
			}
			return parentFile2;
		}
		else if (mode==1) {
			parentFile = new File(Common_Settings.pathOutput+File.separator+slashedFullname);
			if (FileHelper.isDirectory(parentFile.getAbsolutePath())) return parentFile;			
			File parentFile2 = new File(parentFile.getAbsolutePath()+".class");
			if (!parentFile2.exists()) {
				String classPath = FileHelper.getFilenameExceptExt(parentFile2.getAbsolutePath());
				String path = Loader.fixClassPath(classPath);
				if (path==null) return null;
				return new File(path);
			}
			return parentFile2;
		}
		else if (mode==2) {
			parentFile = new File(Common_Settings.pathProjectSrc+File.separator+slashedFullname);
			if (FileHelper.isDirectory(parentFile.getAbsolutePath())) return parentFile;			
			File parentFile2 = new File(parentFile.getAbsolutePath()+".java");
			if (!parentFile2.exists()) {
				String javaPath = FileHelper.getFilenameExceptExt(parentFile2.getAbsolutePath());
				String path = Loader.getSourceFilePath(javaPath);
				if (path==null) return null;
				return new File(path);
			}
			return parentFile2;
		}
		else if (mode==3) {
			int i;
			for (i=0; i<Common_Settings.listOfOtherLibs.count; i++) {
				String jarFileName = Common_Settings.listOfOtherLibs.getItem(i);
				parentFile = new File(jarFileName+File.separator+slashedFullname);
				if (FileHelper.isDirectory(parentFile.getAbsolutePath())) return parentFile;			
				File parentFile2 = new File(parentFile.getAbsolutePath()+".class");
				if (!parentFile2.exists()) {
					String classPath = FileHelper.getFilenameExceptExt(parentFile2.getAbsolutePath());
					String path = Loader.fixClassPath(classPath);
					if (path==null) continue;
					return new File(path);
				}
				return parentFile2;
			}
		}
		
		return null;
	}
	
	
	/**mode가 0이면 Control.pathAndroid로부터, 
	 * mode가 1이면 Control.pathJaneSoft/output로부터
	 * mode가 2이면 Control.pathProjectSrc로부터 fullname를 얻는다.
	 * mode가 3이면 Control.pathOther_Lib로부터 fullname를 얻는다.
	 * 존재하지 않는 파일이나 디렉토리이면 null을 리턴한다.
	 * @param classFilePath : 확장자는 .class이거나 .java이어야 한다.*/
	public static String getFullname_FromVariousClassPath(int mode, String classFilePath) {
		if (mode==0) {
			String dir = Common_Settings.pathAndroid + File.separator;
			if (classFilePath.contains(dir)) {
				int dirLen = dir.length();
				String r = classFilePath.substring(dirLen, classFilePath.length());
				int indexClass = r.indexOf(".class");
				if (indexClass!=-1) {
					r = r.substring(0, indexClass);
				}
				// 바이트코드를 만드는 것이므로 '/'으로 바꿔준다.
				r = r.replace('\\', '/');
				String fullname = r.replace('/', '.');
				fullname = fullname.replace('$', '.');
				//if (fullname.equals(originalFullName)) {
					return fullname;
				//}
			}
		}
		else if (mode==1) {
			String dir = Common_Settings.pathOutput + File.separator;
			if (classFilePath.contains(dir)) {
				int dirLen = dir.length();
				String r = classFilePath.substring(dirLen, classFilePath.length());
				int indexClass = r.indexOf(".class");
				if (indexClass!=-1) {
					r = r.substring(0, indexClass);
				}
				// 바이트코드를 만드는 것이므로 '/'으로 바꿔준다.
				r = r.replace('\\', '/');
				String fullname = r.replace('/', '.');
				fullname = fullname.replace('$', '.');
				//if (fullname.equals(originalFullName)) {
					return fullname;
				//}
			}
		}
		else if (mode==2) {
			String dir = Common_Settings.pathProjectSrc + File.separator;
			if (classFilePath.contains(dir)) {
				int dirLen = dir.length();
				String r = classFilePath.substring(dirLen, classFilePath.length());
				int indexClass = r.indexOf(".java");
				if (indexClass!=-1) {
					r = r.substring(0, indexClass);
				}
				// 바이트코드를 만드는 것이므로 '/'으로 바꿔준다.
				r = r.replace('\\', '/');
				String fullname = r.replace('/', '.');
				fullname = fullname.replace('$', '.');
				//if (fullname.equals(originalFullName)) {
					return fullname;
				//}
			}
			
		}
		else if (mode==3) {
			int i;
			for (i=0; i<Common_Settings.listOfOtherLibs.count; i++) {
				String jarFileName = Common_Settings.listOfOtherLibs.getItem(i);
				//String dirOfJarFile = FileHelper.getDirectory(jarFileName);
				String dir = jarFileName + File.separator;
				if (classFilePath.contains(dir)) {
					int dirLen = dir.length();
					String r = classFilePath.substring(dirLen, classFilePath.length());
					int indexClass = r.indexOf(".class");
					if (indexClass!=-1) {
						r = r.substring(0, indexClass);
					}
					// 바이트코드를 만드는 것이므로 '/'으로 바꿔준다.
					r = r.replace('\\', '/');
					String fullname = r.replace('/', '.');
					fullname = fullname.replace('$', '.');
					//if (fullname.equals(originalFullName)) {
						return fullname;
					//}
				}
			}
		}
		
		return null;
	}
	
	/**mode가 0이면 Control.pathAndroid로부터, 
	 * mode가 1이면 Control.pathJaneSoft/output로부터
	 * mode가 2이면 Control.pathProjectSrc로부터 slashedFullname를 얻는다.
	 * mode가 3이면 Control.pathOther_Lib로부터 slashedFullname를 얻는다.
	 * 존재하지 않는 파일이나 디렉토리이면 null을 리턴한다.
	 * @param classFilePath : slashedFullname이 파일일 경우 확장자는 .class이거나 .java이어야 한다.*/
	public static String getSlashedFullname_FromVariousClassPath(int mode, String classFilePath, String originalFullName) {
		if (mode==0) {
			String dir = Common_Settings.pathAndroid + File.separator;
			int dirLen = dir.length();
			String r = classFilePath.substring(dirLen, classFilePath.length());
			int indexClass = r.indexOf(".class");
			if (indexClass!=-1) {
				r = r.substring(0, indexClass);
			}
			// 바이트코드를 만드는 것이므로 '/'으로 바꿔준다.
			r = r.replace('\\', '/');
			String fullname = r.replace('/', '.');
			fullname = fullname.replace('$', '.');
			if (fullname.equals(originalFullName)) {
				return r;
			}
		}
		else if (mode==1) {
			String dir = Common_Settings.pathOutput + File.separator;
			int dirLen = dir.length();
			String r = classFilePath.substring(dirLen, classFilePath.length());
			int indexClass = r.indexOf(".class");
			if (indexClass!=-1) {
				r = r.substring(0, indexClass);
			}
			// 바이트코드를 만드는 것이므로 '/'으로 바꿔준다.
			r = r.replace('\\', '/');
			String fullname = r.replace('/', '.');
			fullname = fullname.replace('$', '.');
			if (fullname.equals(originalFullName)) {
				return r;
			}
		}
		else if (mode==2) {
			return null;
		}
		else if (mode==3) {
			int i;
			for (i=0; i<Common_Settings.listOfOtherLibs.count; i++) {
				String jarFileName = Common_Settings.listOfOtherLibs.getItem(i);
				String dir = jarFileName + File.separator;
				int dirLen = dir.length();
				String r = classFilePath.substring(dirLen, classFilePath.length());
				int indexClass = r.indexOf(".class");
				if (indexClass!=-1) {
					r = r.substring(0, indexClass);
				}
				// 바이트코드를 만드는 것이므로 '/'으로 바꿔준다.
				r = r.replace('\\', '/');
				String fullname = r.replace('/', '.');
				fullname = fullname.replace('$', '.');
				if (fullname.equals(originalFullName)) {
					return r;
				}
			}
		}
		
		return null;
	}

	
	/** mlistOfAllVarUses에서 시작인덱스(startIindexInmListOfAllVarUses)에서부터 검색을 시작하여 
	 * indexInmBuffer을 만날 때까지 mlistOfAllVarUses의 마지막 인덱스를 리턴한다. 못찾으면 -1을 리턴
	 * @param isStartOrEnd : true일때, 즉 start일때는 varUse.index()>=indexInmBuffer 조건이 최초로 성립할때이고,
	 * false일때, 즉 end일때는 varUse.index()==indexInmBuffer시는 현재varUse의 인덱스, 
	 * 그렇지않으면 이전varUse의 인덱스를 리턴한다.*/
	public static int getIndexInmListOfAllVarUses(HighArray_CodeString src, HighArray mlistOfAllVarUses, 
			int startIindexInmListOfAllVarUses, 
			int indexInmBuffer, boolean isStartOrEnd) {
		int i;
		FindVarUseParams varUse = null;
		int len = mlistOfAllVarUses.getCount();
		for (i=startIindexInmListOfAllVarUses; i<len; i++) {
			varUse = (FindVarUseParams) mlistOfAllVarUses.getItem(i);
			if (varUse.index()>=indexInmBuffer) break;
		}
		if (i<len) {
			if (isStartOrEnd) return i;
			else {
				if (i==startIindexInmListOfAllVarUses) return i;
				else if (varUse.index()==indexInmBuffer) return i;
				return i-1;
			}
		}
		else if (i==len) {
			//indexInmBuffer이 mlistOfAllVarUses내의 마지막 varUse의 인덱스보다 큰 경우
			if (isStartOrEnd) return i-1;
			else return i-1;
		}
		
		return -1;
	}
	
	
	/** listOfAllVarUses에서 시작인덱스(startIindexInListOfAllVarUses)에서부터 검색을 시작하여 
	 * indexInBuffer을 만날 때까지 listOfAllVarUses의 마지막 인덱스를 리턴한다. 
	 * 못찾으면 listOfAllVarUses.count을 리턴
	 * @param isStartOrEnd : true일때, 즉 start일때는 varUse.index()>=indexInBuffer 조건이 최초로 성립할때이고,
	 * false일때, 즉 end일때는 varUse.index()==indexInBuffer시는 현재varUse의 인덱스, 
	 * 그렇지않으면 이전varUse의 인덱스를 리턴한다.*/
	public static int getIndexInmListOfAllVarUses2(HighArray listOfAllVarUses, 
			int startIindexInListOfAllVarUses, 
			int indexInBuffer, boolean isStartOrEnd) {
		int i;
		FindVarUseParams varUse = null;
		int len = listOfAllVarUses.getCount();
		for (i=startIindexInListOfAllVarUses; i<len; i++) {
			varUse = (FindVarUseParams) listOfAllVarUses.getItem(i);
			if (varUse==null) continue;
			if (varUse.index()>=indexInBuffer) break;
		}
		if (i<len) {
			if (isStartOrEnd) return i;
			else {
				if (i==startIindexInListOfAllVarUses) return i;
				else if (varUse.index()==indexInBuffer) return i;
				return i-1;
			}
		}
		
		return i;
	}
	
	
	/** listOfAllVarUses에서 시작인덱스(startIindexInListOfAllVarUses)에서부터 검색을 시작하여 
	 * indexInBuffer을 만날 때까지 listOfAllVarUses의 마지막 인덱스를 리턴한다. 
	 * 못찾으면 listOfAllVarUses.count을 리턴
	 * @param isStartOrEnd : true일때, 즉 start일때는 varUse.index()>=indexInBuffer 조건이 최초로 성립할때이고,
	 * false일때, 즉 end일때는 varUse.index()==indexInBuffer시는 현재varUse의 인덱스, 
	 * 그렇지않으면 즉 varUse.index()>indexInBuffer일 때는 이전varUse의 인덱스를 리턴한다.*/
	public static int getIndexInmListOfAllVarUses2(ArrayListIReset listOfAllVarUses, 
			int startIindexInListOfAllVarUses, 
			int indexInBuffer, boolean isStartOrEnd) {
		int i;
		FindVarUseParams varUse = null;
		for (i=startIindexInListOfAllVarUses; i<listOfAllVarUses.count; i++) {
			varUse = (FindVarUseParams) listOfAllVarUses.getItem(i);
			if (varUse==null) continue;
			if (varUse.index()>=indexInBuffer) break;
		}
		if (i<listOfAllVarUses.count) {
			if (isStartOrEnd) return i;
			else {
				if (i==startIindexInListOfAllVarUses) return i;
				else if (varUse.index()==indexInBuffer) return i;
				return i-1;
			}
		}
		
		return i;
	}
	
	/** mlistOfAllVarUses에서 시작인덱스(0)에서부터 검색을 시작하여 
	 * varUse의 mlistOfAllVarUses에서의 인덱스를 리턴한다.
	 */
	public static int getIndexInmListOfAllVarUses(HighArray_CodeString src, ArrayListIReset mlistOfAllVarUses, FindVarUseParams varUse) {
		int i;
		for (i=0; i<mlistOfAllVarUses.count; i++) {
			FindVarUseParams v = (FindVarUseParams) mlistOfAllVarUses.getItem(i);
			if (v.index()==varUse.index()) return i;
		}
		return -1;
	}
	
	
	/** index부터 검색하여 다큐주석이 아닌 일반주석, 애노테이션을 제거한 인덱스를 리턴한다.*/
	public static int getIndexWhickRemoveLeftBlankAndCommentAndAnnotation(HighArray_CodeString src, ReturnOfFindAccessModifier r) {
		int i;
		int index;
		index = r.r;
		if (index<0) return index;
		if (r.type==0) {
			index = r.r+1;
		}
		for (i=index; i<src.count; i++) {
			CodeString str=null;
			try{
			str = src.getItem(i);
			}catch(Exception e) {
				if (Common_Settings.g_printsLog) e.printStackTrace();
			}
			if (CompilerHelper.IsRegularComment(str)) continue;
			else if (CompilerHelper.IsAnnotation(str)) continue;
			else if (CompilerHelper.IsBlank(str)) continue;
			else return i;
		}
		return index;
	}
	
	/** block을 처음으로 감싸는 클래스나 함수를 얻는다. 
	 * 예를들어 제어블럭에서 getParent를 호출하면 이 블럭을 처음으로 감싸는 함수를 얻는다.*/
	public static Block getParent(Block block) {
		while (true) {
			if (block instanceof FindFunctionParams) return block;
			if (block instanceof FindClassParams) return block;
			if (block!=null) {
				block = block.parent;
			}
			else {
				return null;
			}
		}
	}
	
	/** block을 처음으로 감싸는 반복 블록을 얻는다. 
	 * 예를들어 continue, break에서 getParentIterationBlock를 호출하면 
	 * 이 블럭을 처음으로 감싸는 반복블록(for, while, dowhile)를 얻는다.*/
	public static Block getParentIterationBlock(Block block) {
		while (true) {
			if (block instanceof FindControlBlockParams) {
				FindControlBlockParams control = (FindControlBlockParams) block;
				if (control.catOfControls!=null) {
					if (control.catOfControls.category==CategoryOfControls.Control_for) 
						return control;
					if (control.catOfControls.category==CategoryOfControls.Control_while) 
						return control;
					if (control.catOfControls.category==CategoryOfControls.Control_dowhile) 
						return control;
					if (control.catOfControls.category==CategoryOfControls.Control_switch) 
						return control;
				}
			}
			if (block!=null) {
				block = block.parent;
			}
			else {
				return null;
			}
		}
	}
	
	/** fullName에 템플릿에 배열기호가 포함될경우 
	 * shortName은 템플릿, 배열기호를 포함한 마지막 '.', '/', '\\', '$' 이후 이름을 리턴한다.
	 * '.', '/', '\\', '$'  이 없으면 원래 fullName을 리턴한다.
	 * @param fullName
	 * @return
	 */
	public static String getShortName(String fullName) {		
		if (fullName==null) return null;
		int indexOfTemplate = fullName.indexOf('<');
		if (indexOfTemplate!=-1) {
			fullName = fullName.substring(0, indexOfTemplate);
		}
		int i;
		for (i=fullName.length()-1; i>=0; i--) {
			char c = fullName.charAt(i); 
			if (c=='.') break;
			else if (c=='/') break;
			else if (c=='\\') break;
			else if (c=='$') break;
		}
		return fullName.substring(i+1, fullName.length());
	}
	
	/** mlistOfAllVarUses의 해시리스트에서 varUseName과 indexOfVarUseInMBuffer으로 해당 varUse를 검색한다.
	 * @return : varUse가 검색되지않으면 null을 리턴, 그렇지 않으면 varUse 리턴 */
	public static FindVarUseParams getVarUseWithIndex(Hashtable2_String hashListOfAllVarUses, String varUseName, int indexOfVarUseInMBuffer) {
		int i;
		//FindVarUseParams varUse = hashListOfAllVarUses.getData(varUseName, indexOfVarUseInMBuffer);
		ArrayList listOfVarUses = (ArrayList) hashListOfAllVarUses.getData(varUseName, true);
		if (listOfVarUses==null) return null;
		try {
		for (i=0; i<listOfVarUses.count; i++) {
			FindVarUseParams varUse = (FindVarUseParams) listOfVarUses.getItem(i);
			if (varUse.index()==indexOfVarUseInMBuffer)
				return varUse;
		}
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
		}
		return null;
	}
	
	/** @param startIndex() : listOfAllVarUses 상에서 검색 시작 인덱스*/
	public static GetVarUseWithIndexReturnType getVarUseWithIndex(HighArray listOfAllVarUses, int startIndex, int indexOfVarUseInMBuffer) {
		int i;
		int len = listOfAllVarUses.getCount();
		for (i=startIndex; i<len; i++) {
			FindVarUseParams varUse = (FindVarUseParams)listOfAllVarUses.getItem(i);
			if (varUse.index()==indexOfVarUseInMBuffer) {
				return new GetVarUseWithIndexReturnType(varUse, i);
			}
			else if (varUse.index()>indexOfVarUseInMBuffer) return null;
		}
		return null;
	}
	
	
	
	
	public static ArrayList FindByNameInHashtable(HighArray_CodeString src, Hashtable2_String hashtable, String name) {
		if (name.equals("textArray")) {
		}
		if (hashtable==null) return null;
		ArrayList r = (ArrayList) hashtable.getData(name, true);
		return r;
		
	}
	
	public static void FindByName(HighArray_CodeString src, ArrayListIReset listOfVarUses, String name, ArrayListIReset result) {
		int i;
		int n = listOfVarUses.count;
		int l = 0;
		int h = listOfVarUses.count-1;
		i = l + n/2;
		//CodeString str = src.getItem(i)
		boolean found = false;
		if (name.equals("VScrollBarWidthScale")) {
		}
		int r;
		while (l<=h) {
			FindVarUseParams varUse = (FindVarUseParams) listOfVarUses.getItem(i);
			String str = src.getItem(varUse.index()).str;
			r = name.compareTo(str);
			if (r==0) {
				//result.add(varUse);
				found = true;
				break;
			}
			else if (r<0) {
				h = i-1;
			}
			else {
				l = i+1;
			}
			i = l + (h-l+1)/2;
				
		}
		
		int k;		
		if (found) {
			int start=i, end=i;
			for (k=i; k>=0; k--) {
				FindVarUseParams varUse = (FindVarUseParams) listOfVarUses.getItem(k);
				String str = src.getItem(varUse.index()).str;
				if (!str.equals(name)) {
					start = k+1;
					break;
				}
			}
			
			for (k=i; k<listOfVarUses.count; k++) {
				FindVarUseParams varUse = (FindVarUseParams) listOfVarUses.getItem(k);
				String str = src.getItem(varUse.index()).str;
				if (!str.equals(name)) {
					end = k-1;
					break;
				}
			}
			
			for (k=start; k<=end; k++) {
				FindVarUseParams varUse = (FindVarUseParams) listOfVarUses.getItem(k);
				result.add(varUse);
			}
		}
		
	}
	
	/** statement가 가짜 try-catch블록의 try이면 true를 리턴한다.*/
	public static boolean isTry_CatchShield(FindStatementParams statement) {
		if (statement instanceof FindSpecialBlockParams) {
			FindSpecialBlockParams block = (FindSpecialBlockParams) statement;
			if (block.nameIndex==null && 
				block.specialBlockType==FindSpecialBlockParams.SpecialBlockType_try) {
				// 가짜 try-catch블록
				return block.isFake;
			}
		}
		return false;
		
	}
	
	
	
	
	/** synchronized안이나 메서드 안에서 가짜 try-catch블록을 만든다.
	가짜 try-catch블록이란 try-catch가 없는 메서드내에서 예외를 호출함수로 던져주거나 
	try-catch가 없는 synchronized블록에서 예외가 발생할 경우 모니터를 해제하기 위한 것이다.
	현재는 try-catch가 있더라도 가짜 try-catch블록을 만든다.
	(그래도 문제가 안되기 때문에)
	이 경우 Try와 Catch블록은 FindControlBlockParams.nameIndex==null이 되고 
	 * throw문은 FindSpecialStatementParams.kewordIndex==null이 된다.
	 * 이 메서드의 내용을 참조한다.*/
	public static void putTryCatchShieldToSynchronizedOrFunction(Compiler compiler, Block synchronizedOrFunction) {
		
		
		if (synchronizedOrFunction instanceof FindSpecialBlockParams) {
			FindSpecialBlockParams specialBlock = (FindSpecialBlockParams) synchronizedOrFunction;
			if (specialBlock.nameIndex()==201) {
			}
		}
		else if (synchronizedOrFunction instanceof FindFunctionParams) {
			FindFunctionParams func = (FindFunctionParams) synchronizedOrFunction;
			if (func.functionNameIndex()==28) {
			}
		}
		ArrayListIReset originalControlBlocks = synchronizedOrFunction.listOfControlBlocks;
		ArrayListIReset originalSpecialBlocks = synchronizedOrFunction.listOfSpecialBlocks;
		ArrayListIReset originalStatements = synchronizedOrFunction.listOfStatements;
		
		FindSpecialBlockParams tryBlock = new FindSpecialBlockParams(compiler, 
				FindSpecialBlockParams.SpecialBlockType_try, 
				synchronizedOrFunction.startIndex()+1, synchronizedOrFunction.endIndex()-1);
		tryBlock.parent = synchronizedOrFunction;
		tryBlock.isFake = true;
		
		int i;
		for (i=0; i<originalControlBlocks.count; i++) {
			FindStatementParams statement = (FindStatementParams) originalControlBlocks.getItem(i);
			statement.parent = tryBlock;
			tryBlock.listOfControlBlocks.add(statement);
		}
		originalControlBlocks.count = 0;
		
		for (i=0; i<originalSpecialBlocks.count; i++) {
			FindStatementParams statement = (FindStatementParams) originalSpecialBlocks.getItem(i);
			statement.parent = tryBlock;
			tryBlock.listOfSpecialBlocks.add(statement);
		}
		originalSpecialBlocks.count = 0;
		
		for (i=0; i<originalStatements.count; i++) {
			FindStatementParams statement = (FindStatementParams) originalStatements.getItem(i);
			statement.parent = tryBlock;
			tryBlock.listOfStatements.add(originalStatements.getItem(i));
		}
		originalStatements.count = 0;
		
		
		FindSpecialBlockParams catchBlock = new FindSpecialBlockParams(compiler, 
				FindSpecialBlockParams.SpecialBlockType_catch, 
				synchronizedOrFunction.startIndex()+1, synchronizedOrFunction.endIndex()-1);
		catchBlock.parent = synchronizedOrFunction;
		catchBlock.isFake = true;
		
		FindVarParams var = new FindVarParams(compiler, -1, -1);
		var.typeName = "java.lang.Exception";
		var.fieldName = "e";
		var.isMemberOrLocal = false;
		var.isFake = true;
		catchBlock.listOfStatementsInParenthesis.add(var);
		catchBlock.listOfVariableParams.add(var);
		
		FindSpecialStatementParams throwStatement = new FindSpecialStatementParams(compiler, 
				catchBlock.startIndex()+1, catchBlock.endIndex()-1, -1);
		throwStatement.parent = catchBlock;
		throwStatement.isFake = true;
		catchBlock.listOfStatements.add(throwStatement);
		
		Block function = CompilerStatic.getParent(catchBlock);
		function.listOfVariableParams.add(var);
		
		
		tryBlock.indexInListOfControlBlocksOfParent = 0;
		synchronizedOrFunction.listOfControlBlocks.add(tryBlock);
		synchronizedOrFunction.listOfStatements.add(tryBlock);
		
		catchBlock.indexInListOfControlBlocksOfParent = 1;
		synchronizedOrFunction.listOfControlBlocks.add(catchBlock);
		synchronizedOrFunction.listOfStatements.add(catchBlock);
		
		 
	}
	
	
	
	
	/** parent와 child간에 parent관계가 있는지 조사한다.*/
	public static boolean isParent_processLocalVars(Block parent, Block child) {
		if (parent==null) return false;
		while (true) {
			if (child==null) return false/*break*/;
			if (child==parent) return true;
			if (child!=null) {
				child = child.parent;
			}
		}
		
		/*parent = parent_backup;
		child = child_backup;
		if (child==null) return false;
		while (true) {
			if (parent==null) return false;
			if (parent==child) return true;
			if (parent!=null) {
				parent = parent.parent;
			}
		}*/
	}
	
	
	/** input(FindStatementParams[])를 입력, result(FindStatementParams[])를 출력으로
	 * 하여 문장들의 startIndex()를 기준으로 문장들을 정렬한다.
	 */
	public static void SortByIndex(ArrayListIReset input, ArrayListIReset result) {
		if (input.count<=0) return;
		int i, j;
		int indexMin=0;
		FindStatementParams minStatement = (FindStatementParams)input.getItem(0);
		int min = minStatement.startIndex();
		FindStatementParams statement = null;
		
		for (j=0; j<input.count; j++) {
			statement = (FindStatementParams)input.getItem(j);
			result.add(statement);			
		}
		
		for (j=0; j<result.count; j++) {
			// 가정한 최소값
			minStatement = (FindStatementParams)result.getItem(j);
			min = minStatement.startIndex();
			indexMin = j;
			
			for (i=j; i<result.count; i++) { // 구간에서 실제 최소값 찾기
				statement = (FindStatementParams)result.getItem(i);
				int cur = statement.startIndex();
				if (min > cur) {
					minStatement = statement;
					min = cur;
					indexMin = i;
				}
			}
			
			// 가정한 최소값과 실제 최소값의 자리를 바꾸기
			if (j!=indexMin) {
				IReset temp = result.list[j];
				result.list[j] = result.list[indexMin];
				result.list[indexMin] = temp;
				
			}
			
		}
		
		
	}
	
	public static void SortByName(HighArray_CodeString src, ArrayListIReset input, ArrayListIReset result) {
		int i, j;
		int indexMin=0;
		FindVarUseParams minVarUse = (FindVarUseParams)input.getItem(0);
		String min = src.getItem(minVarUse.index()).str;
		FindVarUseParams varUse = null;
		
		for (j=0; j<input.count; j++) {
			varUse = (FindVarUseParams)input.getItem(j);
			result.add(varUse);			
		}
		
		for (j=0; j<result.count; j++) {
			// 가정한 최소값
			minVarUse = (FindVarUseParams)result.getItem(j);
			min = src.getItem(minVarUse.index()).str;
			indexMin = j;
			
			for (i=j; i<result.count; i++) { // 구간에서 실제 최소값 찾기
				varUse = (FindVarUseParams)result.getItem(i);
				String str = src.getItem(varUse.index()).str;
				if (min.compareTo(str)>0) {
					minVarUse = varUse;
					min = str;
					indexMin = i;
				}
			}
			
			// 가정한 최소값과 실제 최소값의 자리를 바꾸기
			if (j!=indexMin) {
				IReset temp = result.list[j];
				result.list[j] = result.list[indexMin];
				result.list[indexMin] = temp;
				
			}
			
		}
		
		// 테스트 코드
		for (j=0; j<result.count; j++) {
			varUse = (FindVarUseParams)result.getItem(j);
			String str = src.getItem(varUse.index()).str;
			if (str.equals("VScrollBarWidthScale")) {
			}
		}
	}
	
	
	public static ArrayListCodeString toArrayListCodeString(CodeStringEx[] arr) {
		ArrayListCodeString r = new ArrayListCodeString(arr.length);
		for (int i=0; i<r.count; i++) {
			r.add(arr[i]);
		}
		return r;
	}
	
	/** 포스트픽스로 변환된 하나의 토큰을 원래의 일련의 스트링(원래의 소스상의 인덱스를 갖기위해 타입은 CodeStringEx를 갖는다)으로 변환한다.*/
	public static HighArray_CodeString toOriginalArrayListCodeString(HighArray_CodeString src, CodeStringEx token) {
		int count = token.indicesInSrc.count;
		HighArray_CodeString r = new HighArray_CodeString(count);
		int i;
		for (i=0; i<count; i++) {
			ArrayListInt indicesOfSrc = new ArrayListInt(1);
			indicesOfSrc.add(token.indicesInSrc.getItem(i));
			String str = src.getItem(token.indicesInSrc.getItem(i)).str;
			CodeStringEx string = new CodeStringEx(str, Common_Settings.textColor, indicesOfSrc, null);
			r.add(string);
		}
		return r;
	}
	
	
	/** 포스트픽스로 변환된 하나의 토큰에서 indexOfPostfix을 원래 소스상의 인덱스로 변환한다.
	 * @param indexOfPostfix : 포스트픽스로 변환된 하나의 토큰에서의 인덱스*/
	public static int  toSrcIndex(HighArray_CodeString src, CodeStringEx token, int indexOfPostfix) {
		if (token.arrayListCodeStringForToken.count<=indexOfPostfix) {
			int indexOfLast = token.indicesInSrc.getItem(token.indicesInSrc.count-1);
			return indexOfLast;
		}
		else {
			try {
			CodeStringEx strInToken = 
					(CodeStringEx) token.arrayListCodeStringForToken.getItem(indexOfPostfix);			
			return strInToken.indicesInSrc.getItem(0);
			}catch(Exception e) {
				if (Common_Settings.g_printsLog) e.printStackTrace();
			}
			return -1;
		}
	}
	
	/** 포스트픽스로 변환된 하나의 토큰에서 소스상의 인덱스를 포스트픽스의 토큰상의 인덱스로 변환한다.
	 * @param indexOfSrc : 소스에서의 인덱스*/
	public static int  toPostfixIndex(HighArray_CodeString src, CodeStringEx token, int indexOfSrc) {
		int i;
		for (i=0; i<token.indicesInSrc.count; i++) {
			int index = token.indicesInSrc.getItem(i);
			if (index==indexOfSrc) return i;
		}
		return -1;
	}
	
	/** parent와 child간에 parent관계가 있는지 조사한다.*/
	public static boolean isParent(Block parent, Block child/*, Block limit*/) {
		if (parent==null) return false;
		if (parent==child) return true; // 같은 레벨의 경우
		while (true) {
			if (child==null) return false;
			if (child==parent) return true;
			if (child!=null) {
				child = child.parent;
			}
		}
	}
	
	

	/** 에디터내에서의 cursorPos를 가지고 mBuffer의 인덱스를 찾는다.*/
	public static int findWord(Compiler compiler, int cursorPosX, int cursorPosY) {
		try {
		HighArray_CodeString mBuffer = compiler.data.mBuffer;
		if (mBuffer==null) return -1;
			
		int indexOfStartInmBuffer = CompilerStatic.getIndexOfStartInmBuffer(compiler, cursorPosY);
		if (indexOfStartInmBuffer>=mBuffer.count) {
			return mBuffer.count-1;
		}
		
		int len=0;
		int i;
		for (i=indexOfStartInmBuffer; i<mBuffer.count; i++) {
			CodeString str = mBuffer.getItem(i);
			if (str.equals("\r")) {
				continue;
			}
			len += str.length();
			// cursorPosX(index)+1 : index를 길이로 바꾼다.
			if (cursorPosX <= len-1) {
				break;
			}
		}
		
		return i;
		}catch(Exception e) {
			return -1;
		}
	}
	
	
	
	/** 에디터내에서의 cursorPosY를 가지고 그 라인의 마지막 스트링의 mBuffer의 인덱스를 찾는다.*/
	public static int findLastWord(Compiler compiler, int cursorPosY) {
		try {
		HighArray_CodeString mBuffer = compiler.data.mBuffer;
		if (mBuffer==null) return -1;
			
		int indexOfStartInmBuffer = CompilerStatic.getIndexOfStartInmBuffer(compiler, cursorPosY);
		if (indexOfStartInmBuffer>=mBuffer.count) {
			return mBuffer.count-1;
		}
				
		int i;
		for (i=indexOfStartInmBuffer; i<mBuffer.count; i++) {
			CodeString str = mBuffer.getItem(i);
			if (str.equals("\n")) {
				return i;
			}			
		}
		
		return mBuffer.count-1;
		}catch(Exception e) {
			return -1;
		}
	}
	
	
	/** 에디터내에서의 cursorPosY를 가지고 현재 라인의 mBuffer에서의 시작과 끝 인덱스를 찾는다.*/
	public static Point findStartIndexAndEndIndexOfCurLine(Compiler compiler, int cursorPosY) {		
		int i=0;
		int j = 0;
		HighArray_CodeString mBuffer = compiler.data.mBuffer;
		if (mBuffer==null) return null;
		int lineNumber=0;
		if (lineNumber!=cursorPosY) {
			for (i=0; i<mBuffer.count; i++) {
				CodeString str = mBuffer.getItem(i);
				if (str.equals("\n")) {
					lineNumber++;
					if (lineNumber==cursorPosY) {
						break;
					}
				}
			}
		}
		
		if (i>=mBuffer.count) {
			return null;
		}
		int startIndex = i+1;
		int endIndex;
		for (j=startIndex; j<mBuffer.count; j++) {
			CodeString str = mBuffer.getItem(j);
			if (str.equals("\n")) {
				break;
			}
		}
		
		// 파일의 끝일 경우
		if (j>=mBuffer.count) endIndex = mBuffer.count-1;
		else endIndex = j-1; // 현재 라인의 끝 인덱스
				
		return new Point(startIndex, endIndex);
	}
	
	/** 에디터내에서의 cursorPos를 가지고 mBuffer에서의 라인(;)인덱스를 리턴한다.*/
	public static Point findLineOfCode(Compiler compiler, int cursorPosX, int cursorPosY) {
		//if (scrollMode==ScrollMode.VScroll) return -1;
		
		int i=0;
		HighArray_CodeString mBuffer = compiler.data.mBuffer;
		int startIndex=-1, endIndex=-1;
		int lineIndex=-1;
		
		int lineNumber=0;
		if (lineNumber!=cursorPosY) {
			for (i=0; i<mBuffer.count; i++) {
				if (mBuffer.getItem(i).equals("\n")) {
					lineNumber++;
					if (lineNumber==cursorPosY) {
						lineIndex = i;
						//startIndex = i;
						break;	
					}
				}
			}
		}
		
		startIndex = CompilerHelper.Skip(mBuffer, true, ";", 0, lineIndex);
		if (startIndex==-1) startIndex=0;
		endIndex = CompilerHelper.Skip(mBuffer, false, ";", lineIndex, mBuffer.count-1);
		if (endIndex==-1) endIndex=mBuffer.count-1;
				
		return new Point(startIndex, endIndex);
	}
	
	/**indexInmBuffer를 처음으로 감싸는 클래스를 찾는다.
	 * 처음 호출시에는 최상위 클래스*/
	public static FindClassParams findParentClass(FindClassParams curClass, int indexInmBuffer) {
		int i;
		for (i=0; i<curClass.childClasses.count; i++) {
			FindClassParams child = (FindClassParams) curClass.childClasses.getItem(i);
			FindClassParams r = findParentClass(child, indexInmBuffer);
			if (r!=null) return r;
		}
		if (curClass.startIndex()<indexInmBuffer && indexInmBuffer<curClass.endIndex()) {
			return curClass;
		}
		return null;
	}
	
	/** Returns a cursorPosY of indexInmBuffer in compiler, or -1 if indexInmBuffer is -1.*/
	public static int getCursorPosYInSrc(Compiler compiler, int indexInmBuffer) {
		if (indexInmBuffer<0) return -1;
		int i;
		ArrayListInt mlistOfNewLines = compiler.data.mlistOfNewLines;
		for (i=0; i<mlistOfNewLines.count; i++) {
			int index = mlistOfNewLines.getItem(i);
			if (indexInmBuffer < index)
				return i;
		}
		return mlistOfNewLines.count;
	}
	
	public static Point getCursorPosInSrc(Compiler compiler, int indexInmBuffer) {
		int i;
		int index = -1;
		ArrayListInt mlistOfNewLines = compiler.data.mlistOfNewLines;
		for (i=0; i<mlistOfNewLines.count; i++) {
			index = mlistOfNewLines.getItem(i);
			if (indexInmBuffer < index)
				break;
		}
		int prevNewLineIndex = 0;
		if (i>0) {
			prevNewLineIndex = mlistOfNewLines.getItem(i-1);
		}
		
		int m;
		int x=0;
		for (m=prevNewLineIndex+1; m<indexInmBuffer; m++) {
			x += compiler.data.mBuffer.getItem(m).length();
		}
		
		return new Point(x, i);
	}
	
	/**cursorPosY의 mBuffer(src)에서의 시작 인덱스를 얻는다.*/
	public static int getIndexOfStartInmBuffer(Compiler compiler, int cursorPosY) {
		int i=0;
		HighArray_CodeString mBuffer = compiler.data.mBuffer;
		if (mBuffer==null) return -1;
		
		if (cursorPosY==0) {
			i = 0;
		}
		else {
			i = compiler.data.mlistOfNewLines.getItem(cursorPosY-1);			
		}
		
		int indexOfStartInmBuffer;
		if (i>=mBuffer.count) {
			return -1;
		}
		if (mBuffer.getItem(i).equals("\n"))
			indexOfStartInmBuffer = i+1;
		else
			indexOfStartInmBuffer = i;
		return indexOfStartInmBuffer;
	}
	
	/**cursorPosX, cursorPosY가 가르키는 mBuffer에서의 스트링을 얻고 
	 * 그 스트링에서의 인덱스를 얻는다.*/
	public static int getIndexOfLastStringInmBuffer(Compiler compiler, int cursorPosX, int cursorPosY) {
		HighArray_CodeString mBuffer = compiler.data.mBuffer;
		if (mBuffer==null) return -1;
			
		int indexOfStartInmBuffer = CompilerStatic.getIndexOfStartInmBuffer(compiler, cursorPosY);
		if (indexOfStartInmBuffer>=mBuffer.count) {
			return mBuffer.count-1;
		}
		
		int len=0;
		int i;
		for (i=indexOfStartInmBuffer; i<mBuffer.count; i++) {
			CodeString str = mBuffer.getItem(i);
			if (str.equals("\r")) {
				continue;
			}
			len += str.length();
			// cursorPosX(index)+1 : index를 길이로 바꾼다.
			if (cursorPosX <= len-1) {
				int oldLen = len-str.length();
				return cursorPosX-oldLen;
			}
		}
		
		return i;
	}
	
	
	public static int getIndexOfStrInput(HighArray_CodeString src, int indexInmBuffer) {
		int i;
		int r = 0;
		for (i=0; i<indexInmBuffer; i++) {
			r += src.getItem(i).count;
		}
		return r;
	}
	
	public static int getIndexOfmBuffer(HighArray_CodeString src, int indexOfStrInput) {
		int i;
		int r = 0;
		for (i=0; i<src.count; i++) {
			CodeString str = src.getItem(i);
			r += str.count;
			if (r>indexOfStrInput) return i;
		}
		return -1;
	}
	
	
	/**Finds recursively. <br> 
	 *        C			<br>
	 *     C1       C2		<br>
	 *  C3   C4   C5		<br>
	 * @param classParams : 처음 호출시에는 most-top class가 된다.
	 * @param r : 결과 FindClassParams[]
	 */
	public static void findMainFunc(FindClassParams classParams, ArrayList r) {
		int j;
		// 자식 클래스부터 찾는다.
		ArrayListIReset listOfChildClasses = classParams.childClasses;
		if (listOfChildClasses!=null) {
			for (j=0; j<listOfChildClasses.count; j++) {
				FindClassParams child = (FindClassParams) listOfChildClasses.getItem(j);
				findMainFunc(child, r);
			}
		}
		
		ArrayListIReset listOfFuncs = classParams.listOfFunctionParams;
		for (j=0; j<listOfFuncs.count; j++) {
			FindFunctionParams func = (FindFunctionParams) listOfFuncs.getItem(j);
			if (func.name.equals("main")) {
				r.add(classParams);
				break;
			}
		}
	}
	
}
