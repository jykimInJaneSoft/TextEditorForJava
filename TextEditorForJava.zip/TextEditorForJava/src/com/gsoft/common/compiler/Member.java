package com.gsoft.common.compiler;

import java.io.File;

import android.util.Log;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.CommonGUI;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.FileHelper;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.Compiler_types.FindFuncCallParam;
import com.gsoft.common.compiler.Compiler_types.FindFunctionParams;
import com.gsoft.common.compiler.Compiler_types.FindVarParams;
import com.gsoft.common.compiler.Compiler_types.FindVarUseParams;
import com.gsoft.common.compiler.Compiler_types.LoadWayOfFindClassParams;
import com.gsoft.common.compiler.Compiler_types_Base.AccessModifier;
import com.gsoft.common.compiler.Compiler_types_Base.AccessModifier.AccessPermission;
import com.gsoft.common.compiler.Compiler_types_Base.Error;
import com.gsoft.common.compiler.Compiler_types_Base.FindPackageParams;
import com.gsoft.common.compiler.Compiler_types_Base.ImportStatement;
import com.gsoft.common.compiler.Expression.ReturnOfgetTypeOfVarUseOrFuncCallOfFullName2_sub;
import com.gsoft.common.compiler.bytecode.ByteCode_Types;
import com.gsoft.common.compiler.classloader.Loader;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListIReset;
import com.gsoft.common.util.HighArray;

import com.gsoft.common.compiler.HighArray_CodeString;
import com.gsoft.common.compiler.CompilerData;
import com.gsoft.common.compiler.Array;
import com.gsoft.common.compiler.Fullname;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.TypeCast_Syntax;
import com.gsoft.common.compiler.CodeStringEx;
import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.CompilerStatic;
import com.gsoft.common.compiler.Checker;
import com.gsoft.common.compiler.Expression;
import com.gsoft.common.compiler.Number;

@SuppressWarnings("unused")
public class Member {
	
	/** this.varUse, super.varUse 일 경우
	 * 해당 클래스내에(상속된 멤버변수포함) varUse라는 멤버변수가 있으면 리턴한다. 
	 * @param compiler : compiler having varUse
	 * @param src : src having varUse*/
	public static FindVarParams getMemberVarInSrc(Compiler compiler, HighArray_CodeString src, 
			FindClassParams classParam, FindVarUseParams varUse, int coreThreadID) {
		if (classParam.loadWayOfFindClassParams==LoadWayOfFindClassParams.ByteCode) {
			classParam = Loader.loadClassFromSrc_onlyInterface(classParam.name, coreThreadID);
		}
		return Member.getMemberVar(compiler, src, classParam, varUse);
	}
	
	/** this.varUse, super.varUse 일 경우
	 * 해당 클래스내에(상속된 멤버변수포함) varUse라는 멤버변수가 있으면 리턴한다. 
	 * @param compiler : compiler having varUse
	 * @param src : src having varUse*/
	public static FindVarParams getMemberVar(Compiler compiler, HighArray_CodeString src, 
			FindClassParams classParam, FindVarUseParams varUse) {
		if (varUse==null) return null;
		if (classParam==null) {
			return null;
		}
		int loopCount = 0;
		ArrayListIReset listOfAllVarDeclarations=null;
		int j;
		
		String childVarUseName = src.getItem(varUse.index()).toString();
				
		for (; loopCount<2; loopCount++) {
			if (loopCount==0) listOfAllVarDeclarations = classParam.listOfVariableParams;
			else listOfAllVarDeclarations = classParam.listOfVarParamsInherited;
			if (listOfAllVarDeclarations==null) continue;
			
			
			for (j=0; j<listOfAllVarDeclarations.count; j++) {
				FindVarParams varParams = (FindVarParams)listOfAllVarDeclarations.getItem(j);
				if (varParams.parent instanceof FindFunctionParams) continue;	// 지역변수
				
				String varName = varParams.fieldName;
				try {
				if (varName.equals(childVarUseName)) {
					if (varUse.index()==3620) {
						int a;
						a=0;
						a++;
					}
					
					findAllMemberVarUsing_sub_sub(compiler, varUse, varParams);
					if (varUse.varDecl!=null) return varParams;
				} // if
				}catch(Exception e) {
				}
			} // for (j=0; j<listOfAllVarDeclarations.count; j++) {
		} // for (; loopCount<2; loopCount++) {
		return null;	
	}
	
	/**@param compiler : compiler having varUse*/
	static void findAllMemberVarUsing_sub_sub(Compiler compiler, FindVarUseParams varUse, FindVarParams var) {
		CompilerData data = compiler.data;
		String varUseName = varUse.name;
		FindClassParams classThatDefinesVar = (FindClassParams) var.parent;
		FindClassParams classThatDefinesVarUse = varUse.classToDefineThisVarUse;
		
		varUse.varDecl = var;
		
		if (varUse.parent==null) { // varName 
			boolean isStaticFunc = false;
			FindFunctionParams func = varUse.funcToDefineThisVarUse;
			if (func!=null && func.accessModifier!=null && func.accessModifier.isStatic)
				isStaticFunc = true;
			if (isStaticFunc) { // 변수사용이 사용된 장소가 함수이고 static함수일 경우
				if (var.accessModifier!=null && var.accessModifier.isStatic) {
					// static 함수내에서 static 멤버변수 참조
					//varUse.varDecl = var;
					if (!classThatDefinesVar.name.equals(classThatDefinesVarUse.name)) {
						if (var.accessModifier.accessPermission==AccessPermission.Private) {
							CompilerStatic.errors.add(new Error(compiler, varUse.index(), varUse.index(), "invalid access : "+var));
						}
					}
				}
				else {
					String varFullName = ((FindClassParams)var.parent).name + "." + var.fieldName;
					// static 함수내에서는 상속클래스나 내포하는 클래스, 자신의 클래스의 static 멤버만 접근 가능하다.
					CompilerStatic.errors.add(new Error(compiler, varUse.index(), varUse.index(), varFullName + " is not static."));
				}
			}
			else {// 인스턴스 함수내에서 변수 참조
				if (var.accessModifier!=null && !var.accessModifier.isStatic) {
					varUse.isUsingThisOrSuper = true;
				}
				//varUse.varDecl = var;
				if (!classThatDefinesVar.name.equals(classThatDefinesVarUse.name)) {
					if (var.accessModifier.accessPermission==AccessPermission.Private) {
						CompilerStatic.errors.add(new Error(compiler, varUse.index(), varUse.index(), "invalid access : "+var));
					}
				}
			}
		}//if (varUse.parent==null) { // varName 
		else {
			//if (varUse.parent.isThis) { // this.varName
			if (data.mBuffer.getItem(varUse.parent.index()).equals("this")) { // this.varName
				if (varUse.parent.parent!=null) {
					CompilerStatic.errors.add(new Error(compiler, varUse.parent.parent.index(),varUse.parent.parent.index(),"invalid this."));
				}
				else {
					if (data.mBuffer.getItem(varUse.index()).equals("this") || data.mBuffer.getItem(varUse.index()).equals("super")) {
						// this.this, this.super
						CompilerStatic.errors.add(new Error(compiler, varUse.index(), varUse.index(), 
								"invalid "+data.mBuffer.getItem(varUse.index())));
					}
					if (var.accessModifier!=null && var.accessModifier.isStatic) {
						String parentShortName = CompilerHelper.getShortName(((FindClassParams)var.parent).name);
						CompilerStatic.errors.add(new Error(compiler, varUse.index(), varUse.index(), 
							varUseName + " is a static member variable. So use the "+parentShortName));
					}
					else {
						varUse.isUsingThisOrSuper = true;
						//varUse.varDecl = var;
						if (!classThatDefinesVar.name.equals(classThatDefinesVarUse.name)) {
							if (var.accessModifier.accessPermission==AccessPermission.Private) {
								CompilerStatic.errors.add(new Error(compiler, varUse.index(), varUse.index(), "invalid access : "+var));
							}
						}
					}
				}
			}
			else if (data.mBuffer.getItem(varUse.parent.index()).equals("super")) { // super.varName
				String classNameDefiningVar = ((FindClassParams)var.parent).name;
				String classNameDefiningVarUse = varUse.classToDefineThisVarUse.name;
				
				FindVarUseParams parentOfSuper = varUse.parent.parent;
				if (parentOfSuper!=null) {
					// super 앞에는 다른 토큰이 있어서는 안된다.
					CompilerStatic.errors.add(new Error(compiler, parentOfSuper.index(), parentOfSuper.index(), "invalid super."));
				}
				else {
					if (data.mBuffer.getItem(varUse.index()).equals("this") || data.mBuffer.getItem(varUse.index()).equals("super")) {
						// super.this, super.super
						CompilerStatic.errors.add(new Error(compiler, varUse.index(), varUse.index(), 
								"invalid "+data.mBuffer.getItem(varUse.index())));
					}
					
					if (classNameDefiningVar.equals(classNameDefiningVarUse)) {
						// 동일 클래스내 함수호출이지만 super키워드가 있으므로 매핑이 안되고 continue;
						CompilerStatic.errors.add(new Error(compiler, varUse.parent.index(), varUse.parent.index(), "invalid super. Use this."));
					}
					else {
						if (var.accessModifier!=null && var.accessModifier.isStatic) {
							//CompilerStatic.errors.add(new Error(this, varUse.index(), varUse.index(), varUseName + " is static."));
							String parentShortName = CompilerHelper.getShortName(((FindClassParams)var.parent).name);
							CompilerStatic.errors.add(new Error(compiler, varUse.index(), varUse.index(), 
								varUseName + " is a static member variable. So use the "+parentShortName+", not super."));
						}
						else {
							varUse.isUsingThisOrSuper = true;
							//varUse.varDecl = var;
							if (var.accessModifier.accessPermission==AccessPermission.Private) {
								CompilerStatic.errors.add(new Error(compiler, varUse.index(), varUse.index(), "invalid access : "+var));
							}
						}
					}
				}
			}
			else {	// varUse.parent가 널이 아니고 this, super가 아닌경우
				if (data.mBuffer.getItem(varUse.index()).equals("this") || data.mBuffer.getItem(varUse.index()).equals("super")) {
					// obj.this, obj.super
					CompilerStatic.errors.add(new Error(compiler, varUse.index(), varUse.index(), 
							"invalid "+data.mBuffer.getItem(varUse.index())));
				}
				
				//varUse.varDecl = var;
				if (!classThatDefinesVar.name.equals(classThatDefinesVarUse.name)) {
					if (var.accessModifier.accessPermission==AccessPermission.Private) {
						// class AAA {
						//	private int a;
						//	void main() {
						//		AAA aaa = new AAA();
						//		int b = aaa.a;
						//	}
						// classThatDefinesVar(int a)=AAA, classThatDefinesVarUse(aaa.a에서 a)=AAA, private접근이 아니다
						
						// class BBB {
						//	int c = aaa.a;
						// classThatDefinesVar(int a)=AAA, classThatDefinesVarUse(aaa.a에서 a)=BBB, private접근이다
						CompilerStatic.errors.add(new Error(compiler, varUse.index(), varUse.index(), "invalid access : "+var));
					}
				}
				//if (!classThatDefinesVar.name.equals(classThatDefinesVarUse.name)) {
					if (var.accessModifier.isStatic) {
						FindVarUseParams parentVarUse = varUse.parent;
						if (parentVarUse.memberDecl==null) {
							// static변수를 static이 아닌 방식으로 접근
							CompilerStatic.errors.add(new Error(compiler, varUse.index(), varUse.index(), 
									"invalid access : "+var+ " is static"));
						}
					}
					else {
						FindVarUseParams parentVarUse = varUse.parent;
						if (parentVarUse.varDecl==null && parentVarUse.funcDecl==null ) {
							if (parentVarUse.memberDecl!=null) {
								// static이 아닌 변수를 static 방식으로 접근
								CompilerStatic.errors.add(new Error(compiler, varUse.index(), varUse.index(), 
										"invalid access : "+var+ " is not static"));
							}
						}
					}
				//}
			} // else { varUse.parent가 널이 아니고 this, super가 아닌경우
		}//else if (varUse.parent!=null) {  
	}
	
	
	/**func1(func2()); 에서 func1, func2 모두 멤버함수이고 func1이 func2로 앞서는 경우를 해결할수있다.
	 *  @param compiler : compiler having varUse
	 * @param src : src having varUse*/
	public static FindFunctionParams getMemberFunction(Compiler compiler, FindVarUseParams varUse, int coreThreadID) {
		FindClassParams classToDefineThisVarUse = varUse.classToDefineThisVarUse;
		
		
		FindFunctionParams func = 
				getFunction(compiler, classToDefineThisVarUse, varUse, coreThreadID);
		if (func!=null) return func;
		return null;		
	}
	
	/**@param compiler : varUse(funcCall)을 갖는 소스 Compiler
	 * @return
	 */
	public static ArrayList getFunctionList(Compiler compiler, FindClassParams classParam, 
			FindVarUseParams varUse, int coreThreadID) {
		HighArray_CodeString src = compiler.data.mBuffer;
		
		if (varUse==null) return null;
		if (classParam==null) return null;
		
		int loopCount=0;
		ArrayListIReset listOfFuncDeclarations = null;
		int index, indexOfNext = -1;
		int indexOfStartOfSmallBlock, indexOfEndOfSmallBlock;
		ArrayListIReset listOfFuncCallParams=null;
		int j;
		
		String varUseName = varUse.originName;
		if (varUseName.equals("null")) {
		}
		
		if (varUse.index()==2156) {
		}
		
		
		if (!varUse.isFake) {
			index = varUse.index();
			indexOfNext = CompilerHelper.SkipBlank(src, false, index+1, src.count-1);
			if (indexOfNext!=src.count) {
				if (varUse.template==null) {
					if (!src.getItem(indexOfNext).equals("(")) 
						return null;
				}
				else {
					indexOfNext = CompilerHelper.SkipBlank(src, false, varUse.template.indexRightPair()+1, src.count-1);
					// new HighArray<String>(initMaxLengthOfArray)에서 HighArray<java.lang.String>이 된다. 
					varUseName += "<"+varUse.template.typeNameToChange+">"; 
				}
			}
			
			// 함수호출의 VarUse를 모아놓은 리스트에 넣는다. 수식에 들어가는 함수호출을 찾기 쉽게 하기 위함이다.
			//mlistOfVarUsesOfFunctionCalls.add(varUse);		
			
			indexOfStartOfSmallBlock = indexOfNext;				
			indexOfEndOfSmallBlock = Checker.CheckParenthesis(compiler,  "(", ")", indexOfStartOfSmallBlock, src.count-1, false);
			if (indexOfEndOfSmallBlock==-1) {
				CompilerStatic.errors.add(new Error(compiler, indexOfStartOfSmallBlock, indexOfStartOfSmallBlock, "not pair"));
			}
			else {
				if (varUse.listOfFuncCallParams==null) {
					listOfFuncCallParams = compiler.compilerStack.findFuncCallParams(src, 
							indexOfStartOfSmallBlock, indexOfEndOfSmallBlock, varUse);
					// 함수호출 파라미터의 타입을 listOfFuncCallParams의 각각에 넣어줘야 한다.				
					boolean success = compiler.setParamsTypeOfListOfFuncCallParams(src, listOfFuncCallParams, coreThreadID);
					if (success) {
						varUse.listOfFuncCallParams = listOfFuncCallParams;
					}
				}
				else {
					listOfFuncCallParams = varUse.listOfFuncCallParams;
				}
			
			}
		}//if (varUse.isFake==false) {
		else { // 가짜 super();
			listOfFuncCallParams = varUse.listOfFuncCallParams;
		}
		
		if (varUseName.equals("super")) {
			// super(xxx);
			varUseName = CompilerStatic.getShortName(classParam.classNameToExtend);
		}
		
		loopCount=0;
		
		ArrayList listResult = new ArrayList(5);
		
		if (varUse.name.equals("super")) {
			loopCount=1;
		}
		if (varUse.parent!=null && varUse.parent.name.equals("super")) {
			// super.func()에서 varUse는 func이다.
			// 부모클래스에서 먼저 찾아야 하므로 현재 클래스의 부모클래스의 메서드부터 찾도록 정의한다.
			loopCount=1;
		}	
		
		// 첫번째는 자신이 정의한 함수부터
		// 두번째는 상속한 함수를 대상으로 한다.
		for (; loopCount<2; loopCount++) {
			if (loopCount==0) listOfFuncDeclarations = classParam.listOfFunctionParams;
			else listOfFuncDeclarations = classParam.listOfFunctionParamsInherited;
			if (listOfFuncDeclarations==null) continue;
			
			
			for (j=0; j<listOfFuncDeclarations.count; j++) {
				FindFunctionParams funcParams = (FindFunctionParams)listOfFuncDeclarations.getItem(j);
				
				String funcName = funcParams.name;
				
				// 함수이름부터 일치하는지 검사한다.
				if (!funcName.equals(varUseName)) continue;
								
				if (varUse.index()==85) {
					int a;
					a=0;
					a++;
				}
				
				if (funcParams.equals(compiler, varUseName, listOfFuncCallParams, varUse, coreThreadID)) { 
					// 매개변수 검사를 하였음.
					if (varUse.index()==8397) {
						int a;
						a=0;
						a++;
					}
					
					listResult.add(funcParams);
					
					
				} // if
			} // for (j=0; j<listOfFuncDeclarations.count; j++) {
			
		} // for (; loopCount<2; loopCount++) {
		return listResult;
	}
	
	/** new ProcessBuilder("java", "-jar", "***.jar")와 같은 함수인 경우<br>
		System.out.printf("%d %f", 1, 0.5f)와 같은 함수인 경우인지를 확인한다.
		@param compiler : varUse(funcCall)을 갖는 소스 Compiler
	 * @param varUse : varUse(funcCall)
	 * @param func : func to compare with varUse*/
	public static int funcArgIsArrayAndFuncCallParamsIsElementTypeList(Compiler compiler, FindVarUseParams varUse,
			FindFunctionParams func, int coreThreadID) {
		String typeName = null;
		if (varUse.index()==1983) {
			int a;
			a=0;
			a++;
		}
		int i;
		ArrayListIReset listOfFuncArgs = func.listOfFuncArgs;
		ArrayListIReset listOfFuncCallParams = varUse.listOfFuncCallParams;
		
		if (listOfFuncArgs.count>listOfFuncCallParams.count) return -1;
		
		String typeName1 = null;
		String typeName2;
		for (i=0; i<listOfFuncArgs.count; i++) {
			FindVarParams var = (FindVarParams)listOfFuncArgs.getItem(i);
    		
    		try{
    			typeName1 = var.getType( var.typeStartIndex(), var.typeEndIndex(), coreThreadID);
    		}catch(Exception e) {
    			e.printStackTrace();
    		}
    		FindFuncCallParam funcCallParam = (FindFuncCallParam)listOfFuncCallParams.getItem(i);
    		if (funcCallParam==null || funcCallParam.typeFullName==null)
    			typeName2 = null;
    		else typeName2 = funcCallParam.typeFullName.str;
    		
    		if (typeName2==null) return -1;
    		
    		     // 함수호출 파라미터가 null인 경우 타입검사를 안함, menu.open(null, false);
    		if (typeName2.equals("null") && !CompilerHelper.IsDefaultType(typeName1)) {
    			continue;
    		}
    		
    		if (typeName1==null) {
    		}
			boolean isCompatible = 
					TypeCast_Syntax.isCompatibleType(func.compiler, compiler, new CodeStringEx(typeName1), 
							new CodeStringEx(typeName2), 2, funcCallParam, coreThreadID);
			if (!isCompatible) {
				if (Array.getArrayDimension(func.compiler, typeName1)!=0) {
					boolean r = func.equals_ArrayArg(compiler, listOfFuncCallParams, i, coreThreadID);
					if (r) return i;
				}
				return -1;
			}
    	}//for (i=0; i<listOfFuncArgs.count; i++) {
		return -1;
	
	}
	
	/** 해당 클래스내에(상속된 멤버함수포함) varUse라는 멤버함수가 있으면 리턴한다. 
	 * varUse가 함수호출일 경우 파라미터가 네임스페이스가 있는 함수일 수도 있으므로 
	 * 파라미터부터 타입 검사(다시 파라미터가 함수호출일 수도 있으므로 recursive call)를 한 후에 
	 * 함수호출의 선언을 결정한다. 
	 * @param compiler : varUse(funcCall)을 갖는 소스 Compiler
	 * @param indexInmListOfAllVarUses : varUse의 mListOfAllVarUses에서의 인덱스*/
	public static FindFunctionParams getFunctionInSrc(Compiler compiler, FindClassParams classParam, 
			FindVarUseParams varUse, int coreThreadID) {
		if (classParam.loadWayOfFindClassParams==LoadWayOfFindClassParams.ByteCode) {
			classParam = Loader.loadClassFromSrc_onlyInterface(classParam.name, coreThreadID);
		}
		return Member.getFunction(compiler, classParam, varUse, coreThreadID);
	}
	
	public static  ArrayList getAllFunctionsHavingFuncName(Compiler compiler, FindClassParams classParam, 
			FindVarUseParams varUse, int coreThreadID) {
		String varUseName = varUse.name;
		if (varUseName.equals("super")) {
			// super(xxx);
			varUseName = CompilerStatic.getShortName(classParam.classNameToExtend);
		}
		
		int loopCount=0;
		
		ArrayList listResult = new ArrayList(5);
		
		if (varUse.name.equals("super")) {
			loopCount=1;
		}
		if (varUse.parent!=null && varUse.parent.name.equals("super")) {
			// super.func()에서 varUse는 func이다.
			// 부모클래스에서 먼저 찾아야 하므로 현재 클래스의 부모클래스의 메서드부터 찾도록 정의한다.
			loopCount=1;
		}	
		ArrayListIReset listOfFuncDeclarations = null;
		// 첫번째는 자신이 정의한 함수부터
		// 두번째는 상속한 함수를 대상으로 한다.
		for (; loopCount<2; loopCount++) {
			if (loopCount==0) listOfFuncDeclarations = classParam.listOfFunctionParams;
			else listOfFuncDeclarations = classParam.listOfFunctionParamsInherited;
			if (listOfFuncDeclarations==null) continue;
			
			
			for (int j=0; j<listOfFuncDeclarations.count; j++) {
				FindFunctionParams funcParams = (FindFunctionParams)listOfFuncDeclarations.getItem(j);
				
				String funcName = funcParams.name;
				
				// 함수이름부터 일치하는지 검사한다.
				if (!funcName.equals(varUseName)) continue;
				listResult.add(funcParams);
			}
		}
		return listResult;
	}
	
	
	/** 해당 클래스내에(상속된 멤버함수포함) varUse라는 멤버함수가 있으면 리턴한다. 
	 * varUse가 함수호출일 경우 파라미터가 네임스페이스가 있는 함수일 수도 있으므로 
	 * 파라미터부터 타입 검사(다시 파라미터가 함수호출일 수도 있으므로 recursive call)를 한 후에 
	 * 함수호출의 선언을 결정한다.
	 * @param compiler : varUse(funcCall)을 갖는 소스 Compiler 
	 * @param indexInmListOfAllVarUses : varUse의 mListOfAllVarUses에서의 인덱스*/
	public static FindFunctionParams getFunction(Compiler compiler, FindClassParams classParam, 
			FindVarUseParams varUse, int coreThreadID) {
		FindFunctionParams r = getFunction_sub(compiler, classParam, varUse, coreThreadID);
		if (r==null) return null;
		findMemberFunctionCall_sub_sub(compiler, varUse, r);
		
		if (!varUse.isForVarOrForFunc && varUse.listOfFuncCallParams!=null) {
			int argIndexOfArray = funcArgIsArrayAndFuncCallParamsIsElementTypeList(compiler, varUse, r, coreThreadID);
			int i;
			if (argIndexOfArray==-1) {
				for (i=0; i<varUse.listOfFuncCallParams.count; i++) {
					FindFuncCallParam funcCallParam = (FindFuncCallParam) varUse.listOfFuncCallParams.getItem(i);
					funcCallParam.typeFullNameAfterFuncCall = ((FindVarParams)r.listOfFuncArgs.getItem(i)).typeName;
				}
			}
			else {
				// new ProcessBuilder("java", "-jar", "***.jar")와 같은 함수인 경우
				// System.out.printf("%d %f", 1, 0.5f)와 같은 함수인 경우
				FindVarParams arg = (FindVarParams) r.listOfFuncArgs.getItem(argIndexOfArray);
				String elementTypeName = Array.getArrayElementType(arg.typeName);
				for (i=argIndexOfArray; i<varUse.listOfFuncCallParams.count; i++) {
					FindFuncCallParam funcCallParam = (FindFuncCallParam) varUse.listOfFuncCallParams.getItem(i);
					funcCallParam.typeFullNameAfterFuncCall = elementTypeName;
				}
			}
		}
		if (varUse.funcDecl!=null && varUse.funcDecl.isConstructor && !varUse.name.equals("super")) { 
			// class NewWindowListener extends WindowAdapter {
			// NewWindowListener() {
			//		super();
			// }
			// WindowAdapter is abstract class. 
			// super() not makes an error.
			
			// abstract class Person2 extends Person {
			// }
    		// Person2 p = new Person2();
			// Person2() makes an error.

			AccessModifier accessModifier = ((FindClassParams)varUse.funcDecl.parent).accessModifier;
			if (accessModifier!=null && (accessModifier.isAbstract || 
					accessModifier.isInterface || accessModifier.isEnum)) {
				CompilerStatic.errors.add(new Error(compiler, varUse.index(), varUse.index(), 
						"Can't initiate "+accessModifier+" class."));								
			}							
		}
		return r;
	}
	
	/** 해당 클래스내에(상속된 멤버함수포함) varUse라는 멤버함수가 있으면 리턴한다. 
	 * varUse가 함수호출일 경우 파라미터가 네임스페이스가 있는 함수일 수도 있으므로 
	 * 파라미터부터 타입 검사(다시 파라미터가 함수호출일 수도 있으므로 recursive call)를 한 후에 
	 * 함수호출의 선언을 결정한다. 
	 * @param compiler : varUse(funcCall)을 갖는 소스 Compiler
	 * @param indexInmListOfAllVarUses : varUse의 mListOfAllVarUses에서의 인덱스*/
	public static FindFunctionParams getFunction_sub(Compiler compiler, FindClassParams classParam, 
			FindVarUseParams varUse, int coreThreadID) {
		if (varUse.index()==1449) {
		}
		
		if (classParam==null) return null;
		if (varUse==null) return null;
		
		ArrayList listResult = Member.getFunctionList(compiler, classParam, varUse, coreThreadID);
		if (listResult==null) return null;
		
		if (varUse.index()==2810) {
			int a;
			a=0;
			a++;
		}
		
		
		FindFunctionParams result = null;
		
		int i, j;
		
		if (listResult.count==0) {
			return null;
		}
		else if (listResult.count==1) {
			result = (FindFunctionParams) listResult.getItem(0);
		}
		else { // 2개 이상이 매핑될 경우
			if (varUse.index()==214) {
			}
			if (compiler.hasConstant(varUse)) {				
				for (i=0; i<varUse.listOfFuncCallParams.count; i++) {
					FindFuncCallParam funcCall = (FindFuncCallParam) varUse.listOfFuncCallParams.getItem(i);					
					//int numberType = Number.IsNumber2(
					//		Fullname.getFullName(src, funcCall.startIndex(), funcCall.endIndex()));
					int numberType = Number.getNumberType(funcCall.typeFullName.str);
					if (numberType!=0) {
						listResult = getFilteredFunctionList(listResult, i, numberType);
						if (listResult==null) return null;
					}
					else {
						// 숫자상수가 아닌 경우
					}
				}
				
				if (varUse.index()==214) {
				}
				
				
				ArrayList newResult = new ArrayList(listResult.count);
				for (i=0; i<listResult.count; i++) {
					FindFunctionParams func = (FindFunctionParams) listResult.getItem(i);
					if (func.listOfFuncArgs.count!=varUse.listOfFuncCallParams.count)
						continue;
					boolean hasSameTypeName = true;					
					for (j=0; j<func.listOfFuncArgs.count; j++) {
						FindVarParams var = (FindVarParams) func.listOfFuncArgs.getItem(j);
						FindFuncCallParam funcCall = (FindFuncCallParam) varUse.listOfFuncCallParams.getItem(j);
						// Array.Delete(list, i, 1);에서 list의 타입은 Control이다. 그러므로 첫번째 Delete()에 매핑되어야 한다. 
						// public static Control[] Delete(Control[] src, int srcIndex, int len) {}
						// public static Object[] Delete(Object[] src, int srcIndex, int len) {}
						//if (funcCall.typeFullName.equals("null")) continue;
						if (!funcCall.typeFullName.equals(var.typeName)) {
							hasSameTypeName = false;
							//break;
						}
						if (!hasSameTypeName) {
							CodeStringEx funcCallTypeName = funcCall.typeFullName;
							if (funcCall.typeFullName.equals("byte") || funcCall.typeFullName.equals("short") || 
									funcCall.typeFullName.equals("char") || funcCall.typeFullName.equals("boolean")) {
								funcCallTypeName = new CodeStringEx("int");
							}
							if (!funcCallTypeName.equals(var.typeName)) {
								hasSameTypeName = false;
								break;
							}
						}
					}
					if (hasSameTypeName) {
						newResult.add(func);
					}
				}// for (i=0; i<listResult.count; i++) {
				
				
				if (newResult.count>=1) {
					return getFunction_SameParamTypes(compiler, classParam, varUse, newResult);
				}
				
				for (i=0; i<listResult.count; i++) {
					FindFunctionParams func = (FindFunctionParams) listResult.getItem(i);
					boolean arrayPassed = true;
					for (j=0; j<func.listOfFuncArgs.count; j++) {
						FindVarParams var = (FindVarParams) func.listOfFuncArgs.getItem(j);
						FindFuncCallParam funcCall = (FindFuncCallParam) varUse.listOfFuncCallParams.getItem(j);
						// funcCall.typeFullName : Object[], var.typeName : Object
						if (Array.getArrayDimension(compiler, funcCall.typeFullName.str)!=Array.getArrayDimension(compiler, var.typeName)) {
							arrayPassed = false;
							break;
						}
					}
					if (arrayPassed) return func;
				}
				
				if (result==null) { // default
					result = (FindFunctionParams) listResult.getItem(0);
				}
					
			}//함수 호출에 숫자상수를 포함할 경우
			else {
				// 정확한 타입이름들을 갖는 함수를 리턴한다.
				
				ArrayList newResult = new ArrayList(listResult.count);
				for (i=0; i<listResult.count; i++) {
					FindFunctionParams func = (FindFunctionParams) listResult.getItem(i);
					if (func.listOfFuncArgs.count!=varUse.listOfFuncCallParams.count)
						continue;
					boolean hasSameTypeName = true;					
					for (j=0; j<func.listOfFuncArgs.count; j++) {
						FindVarParams var = (FindVarParams) func.listOfFuncArgs.getItem(j);
						FindFuncCallParam funcCall = (FindFuncCallParam) varUse.listOfFuncCallParams.getItem(j);
						//if (funcCall.typeFullName.equals("null")) continue;
						if (!funcCall.typeFullName.equals(var.typeName)) {
							hasSameTypeName = false;
							//break;
						}
						if (!hasSameTypeName) {
							CodeStringEx funcCallTypeName = funcCall.typeFullName;
							if (funcCall.typeFullName.equals("byte") || funcCall.typeFullName.equals("short") || 
									funcCall.typeFullName.equals("char") || funcCall.typeFullName.equals("boolean")) {
								funcCallTypeName = new CodeStringEx("int");
							}
							if (!funcCallTypeName.equals(var.typeName)) {
								hasSameTypeName = false;
								break;
							}
						}
					}
					if (hasSameTypeName) {
						//return func;
						newResult.add(func);
					}
				}
				
				if (varUse.index()==368) {
					int a;
					a=0;
					a++;
				}
				
				if (newResult.count>=1) {
					return getFunction_SameParamTypes(compiler, classParam, varUse, newResult);
				}
				
								
				
				for (i=0; i<listResult.count; i++) {
					FindFunctionParams func = (FindFunctionParams) listResult.getItem(i);
					boolean arrayPassed = true;
					for (j=0; j<func.listOfFuncArgs.count; j++) {
						FindVarParams var = (FindVarParams) func.listOfFuncArgs.getItem(j);
						FindFuncCallParam funcCall = (FindFuncCallParam) varUse.listOfFuncCallParams.getItem(j);
						// funcCall.typeFullName : Object[], var.typeName : Object
						if (Array.getArrayDimension(compiler, funcCall.typeFullName.str)!=Array.getArrayDimension(compiler, var.typeName)) {
							arrayPassed = false;
							break;
						}
					}
					if (arrayPassed) return func;
				}
				
				if (result==null) { // default
					result = (FindFunctionParams) listResult.getItem(0);
				}
			}//함수 호출에 상수를 포함하지 않을 경우
			
			
		}// 2개 이상이 매핑될 경우
		
		
		return result;
	}
	
	/**StringBuffer buf = new StringBuffer(5);<br>
		buf = buf.append(num).append('\t');<br>
		return buf.append(name).append('\t'); <br>
		buf.append(name)은 
		AbstractStringBuilder StringBuffer.append(String str)과<br>
		StringBuffer StringBuffer.append(String str),<br>
		Appendable StringBuffer.append(String str) 등 파라미터 타입은 같지만<br>
			리턴타입이 여러가지인 메소들을 갖는다.
		*/
	static FindFunctionParams getFunction_SameParamTypes(Compiler compiler, FindClassParams classParam, FindVarUseParams varUse, ArrayList newResult) {
		if (newResult.count==1) return (FindFunctionParams)newResult.getItem(0);
		else if (newResult.count>=2) {
			// hasReturnType이 true는 buf.append(name).append('\t').append(tot) 이와 같은 경우
			// 여기에서 varUse는 append
			boolean hasReturnType = false;
			int indexAND = Fullname.hasAND(compiler, false, varUse.index(), true);
			if (varUse.index()!=indexAND) hasReturnType = true;
			int endIndexFullName = Fullname.getFullNameIndex(compiler, false, varUse.index(), false);
			int operatorIndex = CompilerHelper.SkipBlank(compiler.data.mBuffer, false, endIndexFullName+1, compiler.data.mBuffer.count-1);
			CodeString operator = compiler.data.mBuffer.getItem(operatorIndex); 
			if (CompilerHelper.IsOperator(operator)) hasReturnType = true;
			
			int startIndexFullName = Fullname.getFullNameIndex(compiler, true, varUse.index(), false);
			int newOrOperatorIndex = CompilerHelper.SkipBlank(compiler.data.mBuffer, true, 0, startIndexFullName+1);
			CodeString newOrOperator = compiler.data.mBuffer.getItem(newOrOperatorIndex); 
			boolean isConstructor = false;
			if (compiler.data.mBuffer.getItem(newOrOperatorIndex).equals("new")) isConstructor = true;
			if (CompilerHelper.IsOperator(newOrOperator)) hasReturnType = true;
			
			int i;
			if (hasReturnType) {
				for (i=0; i<newResult.count; i++) {
					FindFunctionParams func = (FindFunctionParams) newResult.getItem(i);
					if (func.isConstructor && isConstructor) return func;
					if (func.returnType.equals(classParam.name)) return func;							
				}
			}
			else {
				for (i=0; i<newResult.count; i++) {
					FindFunctionParams func = (FindFunctionParams) newResult.getItem(i);
					if (func.isConstructor && isConstructor) return func;
					//if (func.returnType.equals(classParam.name)) return func;	
				}
			}
			return (FindFunctionParams)newResult.getItem(0);
		}
		return null;
	}
	
	
	/** 해당 클래스내에(상속된 멤버함수포함) varUse라는 멤버함수가 있으면 리턴한다. 
	 * varUse가 함수호출일 경우 파라미터가 네임스페이스가 있는 함수일 수도 있으므로 
	 * 파라미터부터 타입 검사(다시 파라미터가 함수호출일 수도 있으므로 recursive call)를 한 후에 
	 * 함수호출의 선언을 결정한다. 
	 * @param compiler : varUse(funcCall)을 갖는 소스 Compiler
	 * @param indexInmListOfAllVarUses : varUse의 mListOfAllVarUses에서의 인덱스*/
	public static FindFunctionParams getFunction_sub_backup(Compiler compiler, FindClassParams classParam, 
			FindVarUseParams varUse, int coreThreadID) {
		if (varUse.index()==1449) {
		}
		
		if (classParam==null) return null;
		if (varUse==null) return null;
		
		ArrayList listResult = Member.getFunctionList(compiler, classParam, varUse, coreThreadID);
		if (listResult==null) return null;
		
		if (varUse.index()==2810) {
			int a;
			a=0;
			a++;
		}
		
		
		FindFunctionParams result = null;
		
		int i, j;
		
		if (listResult.count==0) {
			return null;
		}
		else if (listResult.count==1) {
			result = (FindFunctionParams) listResult.getItem(0);
		}
		else { // 2개 이상이 매핑될 경우
			if (varUse.index()==214) {
			}
			if (compiler.hasConstant(varUse)) {				
				for (i=0; i<varUse.listOfFuncCallParams.count; i++) {
					FindFuncCallParam funcCall = (FindFuncCallParam) varUse.listOfFuncCallParams.getItem(i);					
					//int numberType = Number.IsNumber2(
					//		Fullname.getFullName(src, funcCall.startIndex(), funcCall.endIndex()));
					int numberType = Number.getNumberType(funcCall.typeFullName.str);
					if (numberType!=0) {
						listResult = getFilteredFunctionList(listResult, i, numberType);
						if (listResult==null) return null;
					}
					else {
						// 숫자상수가 아닌 경우
					}
				}
				
				if (varUse.index()==214) {
				}
				
				
				ArrayList newResult = new ArrayList(listResult.count);
				for (i=0; i<listResult.count; i++) {
					FindFunctionParams func = (FindFunctionParams) listResult.getItem(i);
					if (func.listOfFuncArgs.count!=varUse.listOfFuncCallParams.count)
						continue;
					boolean hasSameTypeName = true;					
					for (j=0; j<func.listOfFuncArgs.count; j++) {
						FindVarParams var = (FindVarParams) func.listOfFuncArgs.getItem(j);
						FindFuncCallParam funcCall = (FindFuncCallParam) varUse.listOfFuncCallParams.getItem(j);
						// Array.Delete(list, i, 1);에서 list의 타입은 Control이다. 그러므로 첫번째 Delete()에 매핑되어야 한다. 
						// public static Control[] Delete(Control[] src, int srcIndex, int len) {}
						// public static Object[] Delete(Object[] src, int srcIndex, int len) {}
						//if (funcCall.typeFullName.equals("null")) continue;
						if (!funcCall.typeFullName.equals(var.typeName)) {
							hasSameTypeName = false;
							break;
						}
					}
					if (hasSameTypeName) {
						newResult.add(func);
					}
				}// for (i=0; i<listResult.count; i++) {
				
				
				if (newResult.count==1) return (FindFunctionParams)newResult.getItem(0);
				else if (newResult.count>=2) {
					boolean hasReturnType = false;
					int indexAND = Fullname.hasAND(compiler, false, varUse.index(), true);
					if (varUse.index()!=indexAND) hasReturnType = true;
					int endIndexFullName = Fullname.getFullNameIndex(compiler, false, varUse.index(), false);
					int operatorIndex = CompilerHelper.SkipBlank(compiler.data.mBuffer, false, endIndexFullName+1, compiler.data.mBuffer.count-1);
					CodeString operator = compiler.data.mBuffer.getItem(operatorIndex); 
					if (CompilerHelper.IsOperator(operator)) hasReturnType = true;
					
					int startIndexFullName = Fullname.getFullNameIndex(compiler, true, varUse.index(), false);
					operatorIndex = CompilerHelper.SkipBlank(compiler.data.mBuffer, true, 0, startIndexFullName+1);
					operator = compiler.data.mBuffer.getItem(operatorIndex); 
					if (CompilerHelper.IsOperator(operator)) hasReturnType = true;
					
					if (hasReturnType) {
						String parentName = CompilerHelper.getShortName(classParam.name);
						for (i=0; i<newResult.count; i++) {
							FindFunctionParams func = (FindFunctionParams) newResult.getItem(i);
							if (func.isConstructor) return func;
							if (func.returnType.equals(classParam.name)) return func;							
						}
					}
					return (FindFunctionParams)newResult.getItem(0);
				}
				
				for (i=0; i<listResult.count; i++) {
					FindFunctionParams func = (FindFunctionParams) listResult.getItem(i);
					boolean arrayPassed = true;
					for (j=0; j<func.listOfFuncArgs.count; j++) {
						FindVarParams var = (FindVarParams) func.listOfFuncArgs.getItem(j);
						FindFuncCallParam funcCall = (FindFuncCallParam) varUse.listOfFuncCallParams.getItem(j);
						// funcCall.typeFullName : Object[], var.typeName : Object
						if (Array.getArrayDimension(compiler, funcCall.typeFullName.str)!=Array.getArrayDimension(compiler, var.typeName)) {
							arrayPassed = false;
							break;
						}
					}
					if (arrayPassed) return func;
				}
				
				if (result==null) { // default
					result = (FindFunctionParams) listResult.getItem(0);
				}
					
			}//함수 호출에 숫자상수를 포함할 경우
			else {
				// 정확한 타입이름들을 갖는 함수를 리턴한다.
				
				ArrayList newResult = new ArrayList(listResult.count);
				for (i=0; i<listResult.count; i++) {
					FindFunctionParams func = (FindFunctionParams) listResult.getItem(i);
					if (func.listOfFuncArgs.count!=varUse.listOfFuncCallParams.count)
						continue;
					boolean hasSameTypeName = true;					
					for (j=0; j<func.listOfFuncArgs.count; j++) {
						FindVarParams var = (FindVarParams) func.listOfFuncArgs.getItem(j);
						FindFuncCallParam funcCall = (FindFuncCallParam) varUse.listOfFuncCallParams.getItem(j);
						//if (funcCall.typeFullName.equals("null")) continue;
						if (!funcCall.typeFullName.equals(var.typeName)) {
							hasSameTypeName = false;
							break;
						}
					}
					if (hasSameTypeName) {
						//return func;
						newResult.add(func);
					}
				}
				
				if (varUse.index()==368) {
					int a;
					a=0;
					a++;
				}
				
				if (newResult.count==1) return (FindFunctionParams)newResult.getItem(0);
				else if (newResult.count>=2) {
					boolean hasReturnType = false;
					int indexAND = Fullname.hasAND(compiler, false, varUse.index(), true);
					if (varUse.index()!=indexAND) hasReturnType = true;
					int endIndexFullName = Fullname.getFullNameIndex(compiler, false, varUse.index(), false);
					int operatorIndex = CompilerHelper.SkipBlank(compiler.data.mBuffer, false, endIndexFullName+1, compiler.data.mBuffer.count-1);
					CodeString operator = compiler.data.mBuffer.getItem(operatorIndex); 
					if (CompilerHelper.IsOperator(operator)) hasReturnType = true;
					
					int startIndexFullName = Fullname.getFullNameIndex(compiler, true, varUse.index(), false);
					int newOrOperatorIndex = CompilerHelper.SkipBlank(compiler.data.mBuffer, true, 0, startIndexFullName+1);
					CodeString newOrOperator = compiler.data.mBuffer.getItem(newOrOperatorIndex); 
					boolean isConstructor = false;
					if (compiler.data.mBuffer.getItem(newOrOperatorIndex).equals("new")) isConstructor = true;
					if (CompilerHelper.IsOperator(newOrOperator)) hasReturnType = true;
					
					if (hasReturnType) {
						for (i=0; i<newResult.count; i++) {
							FindFunctionParams func = (FindFunctionParams) newResult.getItem(i);
							if (func.isConstructor && isConstructor) return func;
							if (func.returnType.equals(classParam.name)) return func;							
						}
					}
					else {
						for (i=0; i<newResult.count; i++) {
							FindFunctionParams func = (FindFunctionParams) newResult.getItem(i);
							if (func.isConstructor && isConstructor) return func;
							//if (func.returnType.equals(classParam.name)) return func;	
						}
					}
					return (FindFunctionParams)newResult.getItem(0);
				}
				
				for (i=0; i<listResult.count; i++) {
					FindFunctionParams func = (FindFunctionParams) listResult.getItem(i);
					if (func.listOfFuncArgs.count!=varUse.listOfFuncCallParams.count)
						continue;
					boolean hasSameTypeName = true;					
					for (j=0; j<func.listOfFuncArgs.count; j++) {
						FindVarParams var = (FindVarParams) func.listOfFuncArgs.getItem(j);
						FindFuncCallParam funcCall = (FindFuncCallParam) varUse.listOfFuncCallParams.getItem(j);
						CodeStringEx funcCallTypeName = funcCall.typeFullName;
						if (funcCall.typeFullName.equals("byte") || funcCall.typeFullName.equals("short") || 
								funcCall.typeFullName.equals("char") || funcCall.typeFullName.equals("boolean")) {
							funcCallTypeName = new CodeStringEx("int");
						}
						if (!funcCallTypeName.equals(var.typeName)) {
							hasSameTypeName = false;
							break;
						}
					}
					if (hasSameTypeName) {
						return func;
					}
				}
				
				
				
				for (i=0; i<listResult.count; i++) {
					FindFunctionParams func = (FindFunctionParams) listResult.getItem(i);
					boolean arrayPassed = true;
					for (j=0; j<func.listOfFuncArgs.count; j++) {
						FindVarParams var = (FindVarParams) func.listOfFuncArgs.getItem(j);
						FindFuncCallParam funcCall = (FindFuncCallParam) varUse.listOfFuncCallParams.getItem(j);
						// funcCall.typeFullName : Object[], var.typeName : Object
						if (Array.getArrayDimension(compiler, funcCall.typeFullName.str)!=Array.getArrayDimension(compiler, var.typeName)) {
							arrayPassed = false;
							break;
						}
					}
					if (arrayPassed) return func;
				}
				
				if (result==null) { // default
					result = (FindFunctionParams) listResult.getItem(0);
				}
			}//함수 호출에 상수를 포함하지 않을 경우
			
			
		}// 2개 이상이 매핑될 경우
		
		/*if (result!=null) {
			findMemberFunctionCall_sub_sub(compiler, varUse, result);
		}*/
		
		return result;
	}
	
	
	
	static void findMemberFunctionCall_sub_sub(Compiler compiler, FindVarUseParams varUse, FindFunctionParams func) {
		String varUseName = varUse.name;
		if (varUse.index()==538) {
			int a;
			a=0;
			a++;
			
		}
		
		varUse.funcDecl = func;
		
		FindClassParams classThatDefinesFunc = (FindClassParams) func.parent;
		FindClassParams classThatDefinesVarUse = varUse.classToDefineThisVarUse;
		
		if (classThatDefinesFunc==null) return;
		if (classThatDefinesVarUse==null) return;
		
		// method()
		if (varUse.parent==null) { 
			boolean isStaticFunc = false;
			FindFunctionParams parentFunc = varUse.funcToDefineThisVarUse;
			if (parentFunc!=null && parentFunc.accessModifier!=null && parentFunc.accessModifier.isStatic)
				isStaticFunc = true;
			if (isStaticFunc) { // 변수사용이 사용된 장소가 함수이고 static함수일 경우
				if (func.accessModifier!=null && func.accessModifier.isStatic) {
					// static 함수내에서 다른 static 함수를 호출
					//varUse.funcDecl = func;
					
					if (!classThatDefinesFunc.name.equals(classThatDefinesVarUse.name)) {
						if (func.accessModifier.accessPermission==AccessPermission.Private) {
							CompilerStatic.errors.add(new Error(compiler, varUse.index(), varUse.index(), "invalid access : "+func));
						}
					}					
				}
				else {
					//varUse.funcDecl = func;
					// static 함수내에서는 상속클래스나 내포하는 클래스, 자신의 클래스의 static 멤버만 접근 가능하다.
					if (!func.isConstructor) {
						// Character클래스내에서 static인 read()함수내에서 Character()생성자를 호출한 경우
						String funcFullName = ((FindClassParams)func.parent).name + "." + func.name;
						CompilerStatic.errors.add(new Error(compiler, varUse.index(), varUse.index(), funcFullName + "() is not static."));
					}
				}
			}//static 함수
			else {//일반 인스턴스함수
				if (varUse.name.equals("super")) {
					if (parentFunc.isConstructor) {
						// 자식클래스의 not-static 생성자에서 부모클래스의 not-static 생성자 호출
						if (func.accessModifier!=null && !func.accessModifier.isStatic) {
							//varUse.funcDecl = func;
							if (!classThatDefinesFunc.name.equals(classThatDefinesVarUse.name)) {
								if (func.accessModifier.accessPermission==AccessPermission.Private) {
									CompilerStatic.errors.add(new Error(compiler, varUse.index(), varUse.index(), "invalid access : "+func));
								}
							}
							else {
								CompilerStatic.errors.add(new Error(compiler, varUse.index(), varUse.index(), "invalid super()"));
							}
						}
						else {
							if (func.accessModifier!=null && func.accessModifier.isStatic) {
								CompilerStatic.errors.add(new Error(compiler, varUse.index(), varUse.index(), "invalid super()"));
							}
						}
					}
					else {
						CompilerStatic.errors.add(new Error(compiler, varUse.index(), varUse.index(), "invalid super()"));
					}
				}//if (varUse.name.equals("super")) {
				else {
					if (func.accessModifier!=null && !func.accessModifier.isStatic) {
						if (!func.isConstructor) {
							varUse.isUsingThisOrSuper = true;
						}
					}
					//varUse.funcDecl = func;
					if (!classThatDefinesFunc.name.equals(classThatDefinesVarUse.name)) {
						if (func.accessModifier.accessPermission==AccessPermission.Private) {
							CompilerStatic.errors.add(new Error(compiler, varUse.index(), varUse.index(), "invalid access : "+func));
						}
					}
				}
			}							
			
		}//if (varUse.parent==null) {
		else { 
			// this.method()
			//if (varUse.parent.isThis) {	// this를 이용한 동일 클래스내 멤버함수 호출
			if (compiler.data.mBuffer.getItem(varUse.parent.index())==null) {
				int a;
				a=0;
				a++;
			}
			if (compiler.data.mBuffer.getItem(varUse.parent.index()).equals("this")) {	// this를 이용한 동일 클래스내 멤버함수 호출
				FindVarUseParams parentOfThis = varUse.parent.parent;
				if (parentOfThis!=null) {
					// this 앞에는 다른 토큰이 있어서는 안된다.
					CompilerStatic.errors.add(new Error(compiler, parentOfThis.index(), parentOfThis.index(), "invalid this."));
				}
				else {
					if (func.accessModifier!=null && func.accessModifier.isStatic) {
						//errors.add(new Error(this, varUse.index(), varUse.index(), varUseName + "() is static."));
						String parentShortName = CompilerHelper.getShortName(((FindClassParams)func.parent).name);
						CompilerStatic.errors.add(new Error(compiler, varUse.index(), varUse.index(), 
							varUseName + "() is a static member function. So use the "+parentShortName+", not super."));
					}
					else {
						varUse.isUsingThisOrSuper = true;
						//varUse.funcDecl = func;
						if (!classThatDefinesFunc.name.equals(classThatDefinesVarUse.name)) {
							if (func.accessModifier.accessPermission==AccessPermission.Private) {
								CompilerStatic.errors.add(new Error(compiler, varUse.index(), varUse.index(), "invalid access : "+func));
							}
						}
					}
				}
			}
			// super.method();
			else if (compiler.data.mBuffer.getItem(varUse.parent.index()).equals("super")) {	// super를 이용한 상속 클래스내 멤버함수 호출
				FindClassParams classParams = (FindClassParams) func.parent;
				
				String classNameDefiningFunc = classParams.name;
				String classNameDefiningVarUse = varUse.classToDefineThisVarUse.name;
				
				FindVarUseParams parentOfSuper = varUse.parent.parent;
				if (parentOfSuper!=null) {
					// super 앞에는 다른 토큰이 있어서는 안된다.
					CompilerStatic.errors.add(new Error(compiler, parentOfSuper.index(), parentOfSuper.index(), "invalid super."));
				}
				else {
					if (classNameDefiningFunc.equals(classNameDefiningVarUse)) {
						// 동일 클래스내 함수호출이지만 super키워드가 있으므로 continue;
						CompilerStatic.errors.add(new Error(compiler, varUse.parent.index(), varUse.parent.index(), "invalid super. Use this."));
					}
					else {
						if (func.accessModifier!=null && func.accessModifier.isStatic) {
							//CompilerStatic.errors.add(new Error(this, varUse.index(), varUse.index(), varUseName + "() is static."));
							String parentShortName = CompilerHelper.getShortName(((FindClassParams)func.parent).name);
							CompilerStatic.errors.add(new Error(compiler, varUse.index(), varUse.index(), 
								varUseName + "() is a static member function. So use the "+parentShortName+", not super."));
						}
						else {
							varUse.isUsingThisOrSuper = true;
							//varUse.funcDecl = func;
							if (!classThatDefinesFunc.name.equals(classThatDefinesVarUse.name)) {
								if (func.accessModifier.accessPermission==AccessPermission.Private) {
									CompilerStatic.errors.add(new Error(compiler, varUse.index(), varUse.index(), "invalid access : "+func));
								}
							}
						}
					}
				}
			}//else if (src.getItem(varUse.parent.index).equals("super"))
			else {
				//varUse.funcDecl = func;
				
				if (!classThatDefinesFunc.name.equals(classThatDefinesVarUse.name)) {
					if (func.accessModifier.accessPermission==AccessPermission.Private) {
						// class AAA {
						//	private int a() {}
						//	void main() {
						//		AAA aaa = new AAA();
						//		int b = aaa.a();
						//	}
						// classThatDefinesVar(int a)=AAA, classThatDefinesVarUse(aaa.a()에서 a)=AAA, private접근이 아니다
						
						// class BBB {
						//	int c = aaa.a();
						// classThatDefinesVar(int a)=AAA, classThatDefinesVarUse(aaa.a()에서 a)=BBB, private접근이다
						CompilerStatic.errors.add(new Error(compiler, varUse.index(), varUse.index(), "invalid access : "+func));
					}
				}
				//if (!classThatDefinesFunc.name.equals(classThatDefinesVarUse.name)) {					
					if (func.accessModifier.isStatic) {
						FindVarUseParams parentVarUse = varUse.parent;
						if (parentVarUse.memberDecl==null) {
							// static함수를 static이 아닌 방식으로 접근
							CompilerStatic.errors.add(new Error(compiler, varUse.index(), varUse.index(), 
									"invalid access : "+func+ " is static"));
						}
					}
					else {
						FindVarUseParams parentVarUse = varUse.parent;
						if (parentVarUse.varDecl==null && parentVarUse.funcDecl==null ) {
							if (!func.isConstructor && parentVarUse.memberDecl!=null) {
								// static이 아닌 함수를 static 방식으로 접근
								CompilerStatic.errors.add(new Error(compiler, varUse.index(), varUse.index(), 
										"invalid access : "+func+ " is not static"));
							}
						}
					}
				//}
			}
			
			
			
		} //if (varUse.parent!=null)
	}
	
	
	/** 해당 클래스내에(상속된 멤버함수포함) varUse라는 멤버함수가 있으면 리턴한다. 
	 * varUse가 함수호출일 경우 파라미터가 네임스페이스가 있는 함수일 수도 있으므로 
	 * 파라미터부터 타입 검사(다시 파라미터가 함수호출일 수도 있으므로 recursive call)를 한 후에 
	 * 함수호출의 선언을 결정한다. 
	 * @param compiler : varUse(funcCall)을 갖는 소스 Compiler
	 * @param indexInmListOfAllVarUses : varUse의 mListOfAllVarUses에서의 인덱스
	 * @param coreThreadID */
	public static FindFunctionParams getFunctionCheckingReturn(Compiler compiler, FindClassParams classParam, 
			FindVarUseParams varUse, int indexInmListOfAllVarUses, int coreThreadID) {
		HighArray_CodeString src = compiler.data.mBuffer;
		if (varUse==null) return null;
		
		int loopCount=0;
		ArrayListIReset listOfFuncDeclarations = null;
		int index, indexOfNext = -1;
		int indexOfStartOfSmallBlock, indexOfEndOfSmallBlock;
		ArrayListIReset listOfFuncCallParams=null;
		int i, j;
		
		String varUseName = varUse.originName;
		if (varUseName.equals("null")) {
		}
		
		if (varUse.index()==25233) {
		}
		
		
		if (!varUse.isFake) {
			index = varUse.index();
			indexOfNext = CompilerHelper.SkipBlank(src, false, index+1, src.count-1);
			if (indexOfNext!=src.count) {
				if (varUse.template==null) {
					if (!src.getItem(indexOfNext).equals("(")) 
						return null;
				}
				else {
					indexOfNext = CompilerHelper.SkipBlank(src, false, varUse.template.indexRightPair()+1, src.count-1);
				}
			}
			
			// 함수호출의 VarUse를 모아놓은 리스트에 넣는다. 수식에 들어가는 함수호출을 찾기 쉽게 하기 위함이다.
			//mlistOfVarUsesOfFunctionCalls.add(varUse);		
			
			indexOfStartOfSmallBlock = indexOfNext;				
			indexOfEndOfSmallBlock = Checker.CheckParenthesis(compiler,  "(", ")", indexOfStartOfSmallBlock, src.count-1, false);
			if (indexOfEndOfSmallBlock==-1) {
				CompilerStatic.errors.add(new Error(compiler, indexOfStartOfSmallBlock, indexOfStartOfSmallBlock, "not pair"));
			}
			else {
				if (varUse.listOfFuncCallParams==null) {
					listOfFuncCallParams = compiler.compilerStack.findFuncCallParams(src, 
							indexOfStartOfSmallBlock, indexOfEndOfSmallBlock, varUse);
					// 함수호출 파라미터의 타입을 listOfFuncCallParams의 각각에 넣어줘야 한다.				
					boolean success = compiler.setParamsTypeOfListOfFuncCallParams(src, listOfFuncCallParams, coreThreadID);
					if (success) {
						varUse.listOfFuncCallParams = listOfFuncCallParams;
					}
				}
				else {
					listOfFuncCallParams = varUse.listOfFuncCallParams;
				}
			
			}
		}//if (varUse.isFake==false) {
		else { // 가짜 super();
			listOfFuncCallParams = varUse.listOfFuncCallParams;
		}
		
		if (varUseName.equals("super")) {
			// super(xxx);
			varUseName = CompilerStatic.getShortName(classParam.classNameToExtend);
		}
		
		loopCount=0;
		
		ArrayList listResult = new ArrayList(5);
		
		if (varUse.name.equals("super")) {
			loopCount=1;
		}
		if (varUse.parent!=null && varUse.parent.name.equals("super")) {
			// super.func()에서 varUse는 func이다.
			// 부모클래스에서 먼저 찾아야 하므로 현재 클래스의 부모클래스의 메서드부터 찾도록 정의한다.
			loopCount=1;
		}	
		
		// 첫번째는 자신이 정의한 함수부터
		// 두번째는 상속한 함수를 대상으로 한다.
		//String varUseName = varUse.originName;
		for (; loopCount<2; loopCount++) {
			try {
			if (loopCount==0) listOfFuncDeclarations = classParam.listOfFunctionParams;
			else listOfFuncDeclarations = classParam.listOfFunctionParamsInherited;
			if (listOfFuncDeclarations==null) continue;
			}catch(Exception e) {
				if (Common_Settings.g_printsLog) e.printStackTrace();
			}
			
			
			for (j=0; j<listOfFuncDeclarations.count; j++) {
				FindFunctionParams funcParams = (FindFunctionParams)listOfFuncDeclarations.getItem(j);
				
				String funcName = funcParams.name;
				
				// 함수이름부터 일치하는지 검사한다.
				if (!funcName.equals(varUseName)) continue;
				
				// 파라미터 개수가 일치하지 않으면 타입검사를 안함
				//if (funcParams.listOfFuncArgs.count!=listOfFuncCallParams.count) continue;
				
				if (varUse.index()==3180) {
				}
				if (varUse.isFake && varUse.name.equals("super")) {
				}
				
				if (funcParams.equals(compiler, varUseName, listOfFuncCallParams, varUse, coreThreadID)) { 
					// 매개변수 검사를 하였음.
					if (varUse.index()==538) {
					}
					FindVarUseParams parentOfVarUse = varUse.parent;
					if (varUse.name.equals("super")) {
						// 자식클래스의 생성자에서 부모클래스의 생성자 호출, super(xxx);
						findMemberFunctionCall_sub_sub(compiler, varUse, funcParams);
						if (varUse.funcDecl!=null) return funcParams;
						continue;
					}
					else {
						// YYY = new File(); 여기에서 varUse는 File, 
						// 이것은 동일클래스나 부모클래스의 멤버함수 호출이 될 수 없다.
						// method();
						// this.method(); super.method();
						if (!funcParams.isConstructor && 
								(parentOfVarUse==null || 
								(parentOfVarUse.name.equals("this") || parentOfVarUse.name.equals("super"))) ) {							
							// 동일 클래스내 멤버함수나 부모클래스의 멤버함수 호출
							findMemberFunctionCall_sub_sub(compiler, varUse, funcParams);
							if (varUse.funcDecl!=null) return funcParams;
							continue;
							//return null;
						}
					}
					
					if (varUse.name.equals("super")) {
						
						CompilerStatic.errors.add(new Error(compiler, varUse.index(), varUse.index(), "invalid super"));
					}
					else {
						//return funcParams;
						// 리턴을 하지 않고 같은 함수를 계속 찾는다.
						listResult.add(funcParams);
					}						
				} // if
			} // for (j=0; j<listOfFuncDeclarations.count; j++) {
			
		} // for (; loopCount<2; loopCount++) {
		
		if (varUse.index()==3224) {
		}
		
		if (listResult.count==0) {
			return null;
		}
		else if (listResult.count==1) {
			return (FindFunctionParams) listResult.getItem(0);
		}
		else { // 2개 이상이 매핑될 경우
			//ArrayList listOfNewResult = null;
			
			if (varUse.index()==709) {
			}
			if (compiler.hasConstant(varUse)) {
				/*FindFunctionParams oldFunc = (FindFunctionParams) listResult.getItem(0);
				String parentClassNameOld = ((FindClassParams)oldFunc.parent).name;
				for (i=1; i<listResult.count; i++) {
					FindFunctionParams func = (FindFunctionParams) listResult.getItem(i);
					String parentClassName = ((FindClassParams)func.parent).name;
					if (parentClassNameOld.equals(parentClassName)==false)
						return oldFunc; // 함수 오버라이딩
					else { // 함수 오버로딩
						break;
					}
				}*/
				
				for (i=0; i<varUse.listOfFuncCallParams.count; i++) {
					FindFuncCallParam funcCall = (FindFuncCallParam) varUse.listOfFuncCallParams.getItem(i);					
					int numberType = Number.IsNumber2(
							Fullname.getFullName(src, funcCall.startIndex(), funcCall.endIndex()));
					if (numberType!=0) {
						listResult = getFilteredFunctionList(listResult, i, numberType);
						if (listResult==null) return null;
					}
					else {
						// 숫자상수가 아닌 경우
					}
				}
				
				
					
			}//함수 호출에 숫자상수를 포함할 경우
			else {
				// 정확한 타입이름들을 갖는 함수를 리턴한다.
				/*listOfNewResult = new ArrayList(listResult.count);
				
				for (i=0; i<listResult.count; i++) {
					FindFunctionParams func = (FindFunctionParams) listResult.getItem(i);
					if (func.listOfFuncArgs.count!=varUse.listOfFuncCallParams.count)
						continue;
					boolean hasSameTypeName = true;					
					for (j=0; j<func.listOfFuncArgs.count; j++) {
						FindVarParams var = (FindVarParams) func.listOfFuncArgs.getItem(j);
						FindFuncCallParam funcCall = (FindFuncCallParam) varUse.listOfFuncCallParams.getItem(j);
						if (funcCall.typeFullName.equals("null")) continue;
						if (funcCall.typeFullName.equals(var.typeName)==false) {
							hasSameTypeName = false;
							break;
						}
					}
					if (hasSameTypeName) {
						//return func;
						listOfNewResult.add(func);
					}
				}*/
				
				
			}//함수 호출에 상수를 포함하지 않을 경우
			
			if (listResult.count==0) {
				return null;
			}
			else if (listResult.count==1) {
				return (FindFunctionParams) listResult.getItem(0);
			}
			else {
				// void인지 아니면 non-void인지를 확인해서 정확한 함수를 리턴한다.
				
				/*boolean requiresReturn = false;
				int fullNameIndex1 = this.getFullNameIndex5(src, true, varUse.index());
				int opIndex = this.SkipBlank(src, true, 0, fullNameIndex1-1);				
				if (CompilerHelper.IsOperator(src.getItem(opIndex))) {
					requiresReturn = true;
				}
				int fullNameIndex2 = this.getFullNameIndex5(src, false, varUse.index());
				opIndex = this.SkipBlank(src, false, fullNameIndex2+1, src.count-1);				
				if (CompilerHelper.IsOperator(src.getItem(opIndex))) {
					requiresReturn = true;
				}*/
				for (i=0; i<listResult.count; i++) {
					FindFunctionParams func = (FindFunctionParams) listResult.getItem(i);
					if (func.returnType!=null && !func.returnType.equals("void")) return func;
				}
			}
		}// 2개 이상이 매핑될 경우
		
		
		return null;
	}
	
	/** getFunction()에서 srcFuncList가 여러개의 함수들을 갖고 있고, 
	 * 즉 함수호출이 여러 개의 함수에 매핑이 되고
	 *  함수호출파라미터들 중에 숫자상수를 포함할 경우 getFunction()에서 호출한다.
	 * @param srcFuncList
	 * @param indexArgs : 함수호출 파라미터들 중에 몇 번째 파라미터인가
	 * @param numberType : Number.IsNumber2()의 리턴값, 숫자상수,  숫자가 아니면 0을 리턴, char이면 1, short이면 2,
	 * integer이면 3을 리턴, long이면 4를, float이면 5를, double이면 6를 리턴한다. 
	 * byte이면 7을 리턴한다.
	 * @return
	 */
	public static ArrayList getFilteredFunctionList(ArrayList srcFuncList, int indexArgs, int numberType) {
		ArrayList r = new ArrayList(srcFuncList.count); 
		switch (numberType) {
		case 7: 
		case 1:
		case 2:
		case 3:
		case 4: 
		{
			int i;
			for (i=0; i<srcFuncList.count; i++) {
				FindFunctionParams func = (FindFunctionParams) srcFuncList.getItem(i);
				FindVarParams var = (FindVarParams) func.listOfFuncArgs.getItem(indexArgs);
				String typeName = var.typeName;
				if (!(typeName.equals("float") || typeName.equals("double"))) {
					r.add(func);
				}
			}
			return r;
		}
		case 5:
		case 6:
		{
			int i;
			for (i=0; i<srcFuncList.count; i++) {
				FindFunctionParams func = (FindFunctionParams) srcFuncList.getItem(i);
				FindVarParams var = (FindVarParams) func.listOfFuncArgs.getItem(indexArgs);
				String typeName = var.typeName;
				if (typeName.equals("float") || typeName.equals("double")) {
					r.add(func);
				}
			}
			return r;
		}
		case 0:
		{
			return null;
		}
			
		}
		return null;
	}
	
	
	/** 꼭대기(com.gsoft.common의 com)에 있는 FindPackageParams를 리턴한다.*/
	public static Object findChildMember2(Compiler compiler, String elementName) {
		int i;
		ArrayList mlistOfPackages = compiler.data.mlistOfPackages;
		for (i=0; i<mlistOfPackages.count; i++) {
			String name = ((FindPackageParams)mlistOfPackages.getItem(i)).packageName;
			if (elementName.equals(name)) {
				return mlistOfPackages.getItem(i);
			}
		}
		return null;
	}
	
	/** 패키지나 클래스, 즉 parent의 멤버를 이름(elementName)으로 찾는다.
	 * @param  elementName : 찾아야할 멤버 이름
	 * @param parent : FindPackageParams, FindClassParams
	 * @return Object : 멤버들, FindPackageParams, FindClassParams, FindVarParams, FindFunctionParams*/
	/*public static Object findChildMember_Package(Compiler compiler, HighArray_CodeString src, FindVarUseParams childVarUse, Object parent, int indexInmListOfAllVarUses) {
		int i;
		
		String elementName = childVarUse.originName;
		if (parent instanceof FindPackageParams) {
			FindPackageParams p = (FindPackageParams)parent;
			// Control.pathAndroid에서 디렉토리나 .class 파일을 찾는다.
			for (i=0; i<p.listOfChildrenNames.length; i++) {
				String childName = p.listOfChildrenNames[i];
				String name = FileHelper.getFilenameExceptExt(childName);
				if (elementName.equals(name)) {
					if (childVarUse.index()==62) {
						int a;
						a=0;
						a++;
					}
					String parentFullName =  
							((FindPackageParams) parent).getFullName(1);
					String ownFullName = parentFullName + File.separator + childName;
					int[] arrMode = {2, 0, 3};
					int k;
					for (k=0; k<arrMode.length; k++) {
						// Control.pathAndroid와 janeSoft/pathProjectSrc에서 읽는다.
						File file = null;
						file = CompilerStatic.getAbsPath_FromVariousClassPath(arrMode[k], ownFullName);
						if (file==null) continue;
						if (file.isDirectory()) { // 디렉토리이면 패키지를 생성하고 리턴
							String[] listOfChildrenNames = file.list();					
							FindPackageParams packageChild = new FindPackageParams(childName, parentFullName, listOfChildrenNames); 
							return packageChild;
						}
						else { // 디렉토리가 아닌 파일, .class, .java 파일일 경우 클래스를 읽어들인다.
							String ext = FileHelper.getExt(ownFullName);
							//if (ext.equals(".class") || ownFullName.contains("$")==false) {
								String fullClassName = ownFullName.replace(File.separatorChar, '.');
								if (ext.equals("")==false) {
									fullClassName = FileHelper.getFilenameExceptExt(fullClassName);
								}
								FindClassParams classParams = Loader.loadClass(compiler, fullClassName);
								
								return classParams;
							//}
						}
					}
				} //if
			} // for
		}
		return null;
	}*/
	
	
	
	/** 패키지나 클래스, 즉 parent의 멤버를 이름(elementName)으로 찾는다.
	 * @param  elementName : 찾아야할 멤버 이름
	 * @param parent : FindPackageParams, FindClassParams
	 * @param coreThreadID 
	 * @return Object : 멤버들, FindPackageParams, FindClassParams, FindVarParams, FindFunctionParams*/
	public static Object findChildMember_Package(Compiler compiler, FindVarUseParams childVarUse, Object parent, int indexInmListOfAllVarUses, int coreThreadID) {
		HighArray_CodeString src = compiler.data.mBuffer;
		
		if (parent instanceof FindPackageParams) {
			FindPackageParams p = (FindPackageParams)parent;
			// Control.pathAndroid에서 디렉토리나 .class 파일을 찾는다.
			String parentFullName = p.getFullName(1);
			String childName = childVarUse.originName;
			String ownFullName = parentFullName + File.separator + childName;
			int[] arrMode = {2, 0, 3};
			int k;
			for (k=0; k<arrMode.length; k++) {
				// Control.pathAndroid와 janeSoft/pathProjectSrc에서 읽는다.
				File file = null;
				file = CompilerStatic.getAbsPath_FromVariousClassPath(arrMode[k], ownFullName);
				if (file==null) continue;
				if (file.isDirectory()) { // 디렉토리이면 패키지를 생성하고 리턴
					String[] listOfChildrenNames = file.list();					
					FindPackageParams packageChild = new FindPackageParams(compiler, childName, parentFullName); 
					return packageChild;
				}
				else { // 디렉토리가 아닌 파일, .class, .java 파일일 경우 클래스를 읽어들인다.
					String ext = FileHelper.getExt(ownFullName);
					//if (ext.equals(".class") || ownFullName.contains("$")==false) {
						String fullClassName = ownFullName.replace(File.separatorChar, '.');
						if (!ext.equals("")) {
							fullClassName = FileHelper.getFilenameExceptExt(fullClassName);
						}
						FindClassParams classParams = Loader.loadClass(compiler, fullClassName, coreThreadID);
						
						return classParams;
					//}
				}
			}
			// 프로젝트 소스(Control.pathProjectSrc)에서도 찾아본다.
			/*String parentFullName =  
					((FindPackageParams) parent).getFullName(1);
			String fullName = parentFullName + File.separator + elementName;
			fullName = fullName.replace(File.separatorChar, '.');
			FindClassParams classParams = Loader.loadClass(compiler, fullName);			
			return classParams;*/
		}
		else if (parent instanceof FindClassParams) {
			if (childVarUse.isForVarOrForFunc) {
				FindClassParams classParam = (FindClassParams)parent;
				boolean isInnerClassIn = 
						CompilerHelper.hasInnerClass(compiler, classParam.name, childVarUse.originName, true, coreThreadID);
				if (isInnerClassIn) {
					String typeNameFull = classParam.name + "." + childVarUse.originName;
					childVarUse.memberDecl = Loader.loadClass(compiler, typeNameFull, coreThreadID);
					return childVarUse.memberDecl;
				}
			}
		}
		return null;
	}
	
		
	
	/** 패키지나 클래스, 즉 parent의 멤버를 이름(elementName)으로 찾는다.
	 * @param  elementName : 찾아야할 멤버 이름
	 * @param parent : FindPackageParams, FindClassParams
	 * @return Object : 멤버들, FindPackageParams, FindClassParams, FindVarParams, FindFunctionParams*/
	/*public static Object findChildMember_sub2(Compiler compiler, HighArray_CodeString src, FindVarUseParams childVarUse, Object parent, int indexInmListOfAllVarUses) {
		int i;
		String elementName = childVarUse.originName;
		if (parent instanceof FindPackageParams) {
			FindPackageParams p = (FindPackageParams)parent;
			// Control.pathAndroid에서 디렉토리나 .class 파일을 찾는다.
			for (i=0; i<p.listOfChildrenNames.length; i++) {
				String childName = p.listOfChildrenNames[i];
				if (childName.equals("gsoft")) {
				}
				String name = FileHelper.getFilenameExceptExt(childName);
				if (elementName.equals(name)) {
					String parentFullName =  
							((FindPackageParams) parent).getFullName(1);
					String ownFullName = parentFullName + File.separator + childName;
					int k;
					for (k=0; k<4; k++) {
						File file = null;
						file = CompilerStatic.getAbsPath_FromVariousClassPath(k, ownFullName);
						if (file==null) continue;
						if (file.isDirectory()) { // 디렉토리이면 패키지를 생성하고 리턴
							String[] listOfChildrenNames = file.list();					
							FindPackageParams packageChild = new FindPackageParams(childName, parentFullName, listOfChildrenNames); 
							return packageChild;
						}
						else { // 디렉토리가 아닌 파일, .class파일일 경우 클래스를 읽어들인다.
							String ext = FileHelper.getExt(ownFullName);
							if (ext.equals(".class") || ownFullName.contains("$")==false) {
								String fullClassName = ownFullName.replace(File.separatorChar, '.');
								fullClassName = FileHelper.getFilenameExceptExt(fullClassName);
								FindClassParams classParams = Loader.loadClass(compiler, fullClassName);
								
								return classParams;
							}
						}
					}
				} //if
			} // for
			// 프로젝트 소스(Control.pathProjectSrc)에서도 찾아본다.
			String parentFullName =  
					((FindPackageParams) parent).getFullName(1);
			String fullName = parentFullName + File.separator + elementName;
			fullName = fullName.replace(File.separatorChar, '.');
			FindClassParams classParams = Loader.loadClass(compiler, fullName);			
			return classParams;
		}// if (parent instanceof FindPackageParams) {
		else if (parent instanceof FindClassParams) {
			FindClassParams p = (FindClassParams)parent;
			// 한 클래스의 모든 내부 클래스를 읽는게 아니라 필요한 내부 클래스만 읽는다.
			if (p.childClasses==null) {
				boolean hasInnerClass = 
						CompilerHelper.hasInnerClass(compiler, p.name, elementName, true);
				if (hasInnerClass) {
					String typeNameFull = p.name + "." + elementName;
					FindClassParams child = Loader.loadClass(compiler, typeNameFull);
					return child;
				}
			}
			else if (p.childClasses!=null) {
				for (i=0; i<p.childClasses.count; i++) {
					FindClassParams child = (FindClassParams)p.childClasses.getItem(i);
					String name = CompilerStatic.getShortName(child.name);
					if (elementName.equals(name)) {
						return child;
					}
				}
			}
			if (p.listOfVariableParams!=null) {
				for (i=0; i<p.listOfVariableParams.count; i++) {
					FindVarParams child = (FindVarParams)p.listOfVariableParams.getItem(i);
					String name = CompilerStatic.getShortName(child.fieldName);
					if (elementName.equals(name)) {
						return child;
					}
				}
			}
			if (p.listOfVarParamsInherited!=null) {
				for (i=0; i<p.listOfVarParamsInherited.count; i++) {
					FindVarParams child = (FindVarParams)p.listOfVarParamsInherited.getItem(i);
					String name = CompilerStatic.getShortName(child.fieldName);
					if (elementName.equals(name)) {
						return child;
					}
				}
			}
			if (p.listOfFunctionParams!=null) {
				for (i=0; i<p.listOfFunctionParams.count; i++) {
					try{
					FindFunctionParams child = (FindFunctionParams)p.listOfFunctionParams.getItem(i);
					String name = CompilerStatic.getShortName(child.name);
					if (elementName.equals(name)) {
						
						child = getFunction(compiler, src, p, childVarUse, indexInmListOfAllVarUses);
						
						return child;
					}
					}catch(Exception e) {
					}
				}
			}
			if (p.listOfFunctionParamsInherited!=null) {
				for (i=0; i<p.listOfFunctionParamsInherited.count; i++) {
					try{
					FindFunctionParams child = (FindFunctionParams)p.listOfFunctionParamsInherited.getItem(i);
					String name = CompilerStatic.getShortName(child.name);
					if (elementName.equals(name)) {
						
						child = getFunction(compiler, src, p, childVarUse, indexInmListOfAllVarUses);
						
						return child;
					}
					}catch(Exception e) {
					}
				}
			}
		}
		
		return null;
	}*/
	
	
	
	
	/** varUse가 com, android, java와 같은 꼭대기에 있는 이름일 경우 varUse의 memberDecl에 연결한다.
	 * loadLibrary2()에서 Control.pathAndroid와 janeSoft/pathProjectSrc의 디렉토리구조를 
	 * FindPackageParams으로 만들어 mlistOfPackages에 등록하는 것을 참조한다.*/ 
	public static void findMemberUsesUsingNamespace_library2(Compiler compiler, FindVarUseParams varUse) {
		HighArray_CodeString src = compiler.data.mBuffer;
		int j, index;
		ArrayList mlistOfPackages = compiler.data.mlistOfPackages;
		// 이 파일에서 정의되지 않은 패키지(FindPackageParams)의
		// 타입을 정의한다.
		if (mlistOfPackages !=null) {
			index = varUse.index();
			String varUseName = src.getItem(index).toString();
			
			if (varUseName.equals("com")) {
			}
			
			if (varUse.parent!=null) return;
			
			for (j=0; j<mlistOfPackages.count; j++) {
				String packageName = ((FindPackageParams)mlistOfPackages.getItem(j)).packageName;
				if (varUseName.equals("Subset")) {
				}
				if (varUseName.equals(packageName)) {
					//String[] children = findChildPackages(src, Control.pathAndroid+File.separator+packageName); 
					//varUse.memberDecl = new FindPackageParams(packageName, "", children);
					varUse.memberDecl = findChildMember2(compiler, packageName);
					break;
				}
			}
		}
	}
	
	/**
	 * 모든 import에 있는 varUse들의 memberDecl을 결정한다.
		class이후에 있는 varUse들은 Members.findMemberUsesUsingNamespace()을 호출한다.<br>
		import java.util.***;<br>
		class AAA {<br>
		   int java;<br>
		   void aaa() {<br>
		       java = 0;<br>
		   }<br>
		}<br>
		import문에 있는 java가 AAA.java에 매핑되는 것을 방지한다.
	 * @param compiler
	 * @param coreThreadID
	 */
	public static void findMemberUsesUsingNamespace_OnlyImport(Compiler compiler, int coreThreadID) {
		HighArray_CodeString src = compiler.data.mBuffer;
		HighArray mlistOfAllVarUses = compiler.data.mlistOfAllVarUses;
		
		if (compiler.data.mlistOfImportStatements.count<=0) return;
		
		int startIndex, endIndex;
		startIndex = 0;
		endIndex = ((ImportStatement)compiler.data.mlistOfImportStatements.getItem(compiler.data.mlistOfImportStatements.count-1)).endIndex();
		
		int endIndexInmListOfAllVarUses;
		int startIndexInmListOfAllVarUses;
		int startIndexInmBuffer;
		
		startIndexInmBuffer = CompilerHelper.SkipBlank(src, false, startIndex, endIndex);
		
		startIndexInmListOfAllVarUses = CompilerStatic.getIndexInmListOfAllVarUses(src, mlistOfAllVarUses , 
				0, startIndexInmBuffer, true);
		endIndexInmListOfAllVarUses = CompilerStatic.getIndexInmListOfAllVarUses(src, mlistOfAllVarUses, 
				startIndexInmListOfAllVarUses, endIndex, false);
		
		int i;
		for (i=startIndexInmListOfAllVarUses; i<=endIndexInmListOfAllVarUses; i++) {
							
			FindVarUseParams varUse = (FindVarUseParams)mlistOfAllVarUses.getItem(i);
			if (varUse.varDecl==null && varUse.funcDecl==null && varUse.memberDecl==null) {
				findMemberUsesUsingNamespace_library2(compiler, varUse);
			}
			FindVarUseParams child = varUse.child;
			
			// 이 파일에서 정의되지 않은 외부 라이브러리
			// (android.graphics.Paint, com.gsoft.common와 같은)의 
			// 패키지(FindPackageParams)와 클래스와 그 멤버변수의 타입을 정의한다.
			if (varUse.memberDecl!=null) {
				if (varUse.child!=null) {
					if (child.memberDecl==null) {
						if (child.index()==35) {
							int a;
							a=0;
							a++;
						}
						// 이 함수의 마지막부분 boolean isInnerClassIn = 
						// CompilerHelper.hasInnerClass(classParam.name, varUse.child.originName, true);에서 
						// 미리 memberDecl이 정해질 수 있다.
						//child.memberDecl = this.findChildMember_sub2(src, child, varUse.memberDecl, i+1);
						child.memberDecl = findChildMember_Package(compiler, child, varUse.memberDecl, i+1, coreThreadID);
						if (child.memberDecl!=null) {
							if (child.memberDecl instanceof FindVarParams) {
								child.varDecl = (FindVarParams) child.memberDecl;
								child.memberDecl = null;
							}
							// static 함수일 경우는 여기에서 처리하지 않고 다음으로 넘긴다.
							else if (child.memberDecl instanceof FindFunctionParams) {
								child.funcDecl = (FindFunctionParams) child.memberDecl;
								child.memberDecl = null;
							}
							// ClipBoardX = new com.gsoft.DataTransfer.ClipBoardX(); 에서
							// varUse는 DataTransfer이고 child는 ClipBoardX이다. 
							// 이런 경우는 이 함수의 가장 아랫부분에서 정의한다.
							// static class
							else if (child.memberDecl instanceof FindClassParams) {
								if (!child.isForVarOrForFunc) {
									FindClassParams classP = (FindClassParams) child.memberDecl;
									child.funcDecl = getFunction(compiler, classP, varUse.child, coreThreadID);
									child.memberDecl = null;
								}
							}
							continue;
						}
					}//if (child.memberDecl==null) {
				}
			}//if (varUse.memberDecl!=null) {
		}// for
	}
	
	
	/** class이후에 있는 외부에서 멤버를 이용한 변수(배열원소포함)나 함수의 타입을 결정한다. a.b.c나 a.b.c()등과 같이, 
	 * 또한 타입캐스트문도 여기에서 해결한다. getTypeOfExpression()등에서 호출
	 * 모든 import에 있는 varUse들은 Members.findMemberUsesUsingNamespace_OnlyImport()을 호출한다.
	 * @param compiler : compiler checking member uses
	 * @param startIndex() :  src에서의 검색 시작 인덱스
	 * @param endIndex() :  src에서의 검색 끝 인덱스 
	 * @param coreThreadID */ 
	public static void findMemberUsesUsingNamespace(Compiler compiler, 
			int startIndex, int endIndex, int coreThreadID) {
		HighArray_CodeString src = compiler.data.mBuffer;
		HighArray mlistOfAllVarUses = compiler.data.mlistOfAllVarUses;
		
		int endIndexInmListOfAllVarUses;
		int startIndexInmListOfAllVarUses;
		int startIndexInmBuffer;
		
		startIndexInmBuffer = CompilerHelper.SkipBlank(src, false, startIndex, endIndex);
		
		startIndexInmListOfAllVarUses = CompilerStatic.getIndexInmListOfAllVarUses(src, mlistOfAllVarUses , 
				0, startIndexInmBuffer, true);
		endIndexInmListOfAllVarUses = CompilerStatic.getIndexInmListOfAllVarUses(src, mlistOfAllVarUses, 
				startIndexInmListOfAllVarUses, endIndex, false);
		if (endIndexInmListOfAllVarUses!=-1) {
			// 함수호출의 매개변수당 한번씩 recursive call
			findMemberUsesUsingNamespace_sub(compiler, mlistOfAllVarUses, 
				startIndexInmListOfAllVarUses, endIndexInmListOfAllVarUses, coreThreadID);
		}
	}
	
	/** class이후에 있는 외부에서 멤버를 이용한 변수(배열원소포함)나 함수의 타입을 결정한다. a.b.c나 a.b.c()등과 같이, 
	 * 모든 import에 있는 varUse들은 Members.findMemberUsesUsingNamespace_OnlyImport()을 호출한다.
	 * 또한 타입캐스트문도 여기에서 해결한다. getTypeOfExpression()등에서 호출한다.
	 * 타입선언시 내부클래스가 있는 경우에 fullname타입 결정과 클래스로드를 한다. 
	 *	타입선언시 shortname만 있는 경우는 getFullNameType, getFullNameType2에서 모두 찾는다.
	 *	예를들어 java.lang패키지에 있는 클래스 Character.Subset s;에서 Characterd와 Subset는 여기서 로드된다. 
	 * 또한 같은 패키지내 클래스와 import java.util.*;와 같이 *를 섞어서 import하는 경우에 내부클래스가 있는 경우 여기서 해야 한다. 
	 * @param compiler : compiler checking member uses
	 * @param listOfAllVarUses : mlistOfAllVarUses
	 * @param startIndex :  mlistOfAllVarUses에서의 검색 시작 인덱스
	 * @param endIndex :  mlistOfAllVarUses에서의 검색 끝 인덱스 
	 * @param coreThreadID */ 
	public static void findMemberUsesUsingNamespace_sub(Compiler compiler, HighArray listOfAllVarUses, 
			int startIndex, int endIndex, int coreThreadID) 
	{
		HighArray_CodeString src = compiler.data.mBuffer;
		int i;
		int index, prevIndex;
		boolean isConstructor = false;
		FindVarUseParams child;
		TypeCast_Syntax typeCast=null;
		int endIndexToTypeCast=-1;
		
		
		//String shortNameOfFile = FileHelper.getFilename(compiler.data.filename);
		
		for (i=startIndex; i<=endIndex; i++) {
			try {
				/*CommonGUI.showMessage(true, "i="+i+" "+shortNameOfFile+"-findMemberUsesUsingNamespace_sub()");
				//Thread.sleep(1000);
				if (shortNameOfFile.equals("ControlBlock.java") && i==1486) {
					int a;
					a=0;
					a++;
				}*/
				
			FindVarUseParams varUse = (FindVarUseParams)listOfAllVarUses.getItem(i);
			
			
			index = varUse.index();
			String varUseName = null;
			if (index==-1) { // 증감문에서 가짜 lValue, rValue일 경우
				varUseName = varUse.originName;
			}
			else { // 일반적인 경우
				varUseName = src.getItem(index).toString();
			}
			
			//if (CompilerHelper.IsDefaultType(varUseName)) continue;
			if (i==313) {
				int a;
				a=0;
				a++;
			}
			
			if (index==114) {
				int a;
				a=0;
				a++;
			}
			
			if (varUse.child!=null && varUse.child.index()==3040) {
				int a;
				a=0;
				a++;
			}
			
			
			
			
			
						
			if (varUse.typeCast!=null) {
				typeCast = varUse.typeCast; 
				endIndexToTypeCast = varUse.typeCast.endIndexToAffect_mlistOfAllVarUses;
				
				// (int)( 2+(int)1 ) 이와같은 (타입)(수식)일 경우
				if (typeCast.affectsExpression) {
					if (typeCast.funcCall==null) {
						FindFuncCallParam funcCall = new FindFuncCallParam(compiler, typeCast.startIndexToAffect(), typeCast.endIndexToAffect());
						funcCall.funcName = typeCast.name;
						// getTypeOfExpression에서 findMemberUsesUsingNamespace_sub을 다시 recursive call해서 
						// 타입캐스트 (int)1의 타입을 결정하고 2+(int)1의 타입을 결정한 후 funcCall에 넣는다.
						CodeStringEx type = Expression.getTypeOfExpression(compiler, funcCall, coreThreadID);
						
						boolean isDeclTemplate = FindVarUseParams.isDeclTemplate((FindVarUseParams)compiler.data.mlistOfAllVarUses.getItem(endIndexToTypeCast));
						
						if (!isDeclTemplate && 
								!TypeCast_Syntax.isCompatibleType(compiler, compiler, 
										new CodeStringEx(funcCall.funcName), type, 0, funcCall, coreThreadID)) {
							CompilerStatic.errors.add(new Error(compiler, typeCast.startIndex(), typeCast.startIndex(), 
									"invalid type cast. : " + funcCall.funcName + "-" + type));
						}
						else {
							funcCall.typeFullNameBeforeTypeCast = type.str;
							funcCall.typeFullName = new CodeStringEx(typeCast.name);
							typeCast.funcCall = funcCall;
						}						
					}
					// 타입캐스트를 해결하였으므로 초기화
					typeCast = null;
				}				
			}
			
			
			int indexFullName = Fullname.getFullNameIndex_OnlyType(compiler,  true, index-1, true);
			prevIndex = CompilerHelper.SkipBlank(src, true, 0, indexFullName-1);
			if (0<=prevIndex) {
				if (src.getItem(prevIndex).equals("new")) {
					isConstructor = true;
				}
				else isConstructor = false;
			}
			
			
			
			child = varUse.child;
			
			// child가 이미 정해진 경우는 continue
			if (child!=null && (child.varDecl!=null || child.funcDecl!=null)) continue;
							
			
			
			String typeName;
			String typeNameFull = null;
			FindClassParams classParam=null;
			boolean isThisOrSuper = false;
			
			// 멤버변수나 멤버함수의 varUse로 가정한다.
			if (varUse.parent==null || (src.getItem(varUse.parent.index()).equals("this") || src.getItem(varUse.parent.index()).equals("super")))
				isThisOrSuper = true;
			
			// varUse는 this, super
			if ((varUseName.equals("this") || varUseName.equals("super")) && 
					varUse.isForVarOrForFunc && varUse.varDecl==null) {
				if (varUseName.equals("super")) {
				}
				FindVarParams var = 
						getMemberVar(compiler, src, varUse.classToDefineThisVarUse, varUse); 
				varUse.varDecl = var;
			}
			
			// 동일클래스의 멤버변수, varUse의 parent는 null이거나 this, super이어야 한다.
			else if (!isConstructor && isThisOrSuper && varUse.varDecl==null && varUse.isForVarOrForFunc &&
					!CompilerHelper.IsDefaultType(varUseName)) {
				if (varUse.index()==7564) {
				}
				if (varUse.classToDefineThisVarUse!=null) {
					FindVarParams var = 
							getMemberVar(compiler, src, varUse.classToDefineThisVarUse, varUse); 
					varUse.varDecl = var;
				}
			}
			
			// super(a,b);이와 같은 경우.
			else if ((varUseName.equals("super") && !varUse.isForVarOrForFunc) && varUse.funcDecl==null) {
				if (varUse.index()==10136) {
				}
				classParam = varUse.classToDefineThisVarUse/*.classToExtend*/;
				if (classParam==null) continue;
				varUse.funcDecl = getFunction(compiler, classParam, varUse, coreThreadID);
			}
			
			// 동일클래스의 멤버함수, varUse의 parent는 this, super이어야 한다.
			// func1(func2()); 에서 func1, func2 모두 멤버함수이고 func1이 func2로 앞서는 경우를 해결할수있다.
			else if (!isConstructor && isThisOrSuper && varUse.funcDecl==null && !varUse.isForVarOrForFunc) {
				if (varUse.index()==5555) {
				}
				varUse.funcDecl = getMemberFunction(compiler, varUse, coreThreadID);
			}
			
			
			
			else if (varUse.memberDecl!=null) {
				if (varUse.memberDecl instanceof FindClassParams) {					
					classParam = (FindClassParams) varUse.memberDecl;
					typeNameFull = classParam.name;
					if (varUse.isArrayElement) {
						if (varUse.listOfArrayElementParams==null) {
							Array.findArraySubscription(compiler, varUse, i, listOfAllVarUses, coreThreadID);
						}
					}
				}
			}
			
			// a = new int[5+1]; b = new String[5+1]; 에서 int와 String
			else if (isConstructor && varUse.varDecl==null && varUse.isArrayElement && varUse.funcDecl==null) {
				if (varUse.listOfArrayElementParams==null) {
					Array.findArraySubscription(compiler, varUse, i, listOfAllVarUses, coreThreadID);
				}
				// 타입검사는 findTypeOfAssignments()에서 처리
			}
			
			else if (isConstructor && !varUse.isForVarOrForFunc && varUse.funcDecl==null) 
			{ // 외부 라이브러리의 생성자 호출 등
				// varUse가 상수이면 continue;
				if (CompilerHelper.IsConstant(src.getItem(index))) continue;
				typeName = varUseName;
				if (varUse.index()==297) {
					int a;
					a=0;
					a++;
				}
				int startIndexOfFullName = Fullname.getFullNameIndex_OnlyType(compiler,  true, varUse.index(), true);
				int endIndexOfFullName = Fullname.getFullNameIndex_OnlyType(compiler,  false, varUse.index(), true);
				typeNameFull = Fullname.getFullNameType(compiler, startIndexOfFullName, endIndexOfFullName, coreThreadID);
				
				classParam = Loader.loadClass(compiler, typeNameFull, coreThreadID);			
				if (classParam==null) continue;
				
				varUse.funcDecl = getFunction(compiler, classParam, varUse, coreThreadID);				
			}
			
			
			// com, android, java와 같은 꼭대기 이름을 memberDecl에 연결한다.
			if (varUse.varDecl==null && varUse.funcDecl==null && varUse.memberDecl==null) {
				findMemberUsesUsingNamespace_library2(compiler, varUse);
			}
			
			// 이 파일에서 정의되지 않은 외부 라이브러리
			// (android.graphics.Paint, com.gsoft.common와 같은)의 
			// 패키지(FindPackageParams)와 클래스와 그 멤버변수의 타입을 정의한다.
			if (varUse.memberDecl!=null) {
				if (varUse.child!=null) {
					if (child.memberDecl==null) {
						// 이 함수의 마지막부분 boolean isInnerClassIn = 
						// CompilerHelper.hasInnerClass(classParam.name, varUse.child.originName, true);에서 
						// 미리 memberDecl이 정해질 수 있다.
						//child.memberDecl = this.findChildMember_sub2(src, child, varUse.memberDecl, i+1);
						child.memberDecl = findChildMember_Package(compiler, child, varUse.memberDecl, i+1, coreThreadID);
						if (child.memberDecl!=null) {
							if (child.memberDecl instanceof FindVarParams) {
								child.varDecl = (FindVarParams) child.memberDecl;
								child.memberDecl = null;
							}
							// static 함수일 경우는 여기에서 처리하지 않고 다음으로 넘긴다.
							else if (child.memberDecl instanceof FindFunctionParams) {
								child.funcDecl = (FindFunctionParams) child.memberDecl;
								child.memberDecl = null;
							}
							// ClipBoardX = new com.gsoft.DataTransfer.ClipBoardX(); 에서
							// varUse는 DataTransfer이고 child는 ClipBoardX이다. 
							// 이런 경우는 이 함수의 가장 아랫부분에서 정의한다.
							// static class
							else if (child.memberDecl instanceof FindClassParams) {
								if (!child.isForVarOrForFunc) {
									FindClassParams classP = (FindClassParams) child.memberDecl;
									child.funcDecl = getFunction(compiler, classP, varUse.child, coreThreadID);
									child.memberDecl = null;
								}
							}
							continue;
						}
					}//if (child.memberDecl==null) {
				}
			}//if (varUse.memberDecl!=null) {
			
			// child가 이미 정해진 경우는 continue
			if (varUse.child!=null && varUse.child.memberDecl!=null) continue;
			
			
			// varUse의 변수 타입, 함수의 리턴 타입에 따라 클래스를 로드한다.
			// varUse.varDecl이 널이 아니고 child가 있는 
			// 변수사용의 타입인 클래스의 멤버선언리스트
			if (varUse.varDecl!=null) { // varUse가 변수인경우
				
				if (varUse.index()==384) {
					int a;
					a=0;
					a++;
				}
				
				if (varUse.varDecl.typeName!=null) { 
					if (!varUse.isArrayElement) {
						typeName = varUse.varDecl.typeName;
						if (Array.getArrayDimension(compiler, typeName)!=0) { 
							// 타입이 배열일 경우, buffer.length에서 buffer의 타입
							typeName = ByteCode_Types.ArrayFullClassName;
							typeNameFull = typeName;
							classParam = Loader.loadClass(compiler, typeNameFull, coreThreadID);
						}
						else {							
							//typeNameFull = Fullname.getFullNameType2(this, typeName, varUse.varDecl.typeStartIndex());
							typeNameFull = varUse.varDecl.typeName;
							classParam = Loader.loadClass(compiler, typeNameFull, coreThreadID);
							if (varUse.varDecl.isTypeNameToChange) {
								// T item; item.toString();에서 item을 java.lang.Object로 연결한다.
								typeNameFull = "java.lang.Object";
							}
						}
					}
					else {
						// ((Button)(controls[0])).changeBounds(boundsOfButtonOK); 
						// 여기에서 controls가 배열원소이므로 이것의 타입인 Control을 구한다.
						typeNameFull = Array.getFullTypeNameOfArrayElement(compiler, varUse, i, listOfAllVarUses, true, coreThreadID);
						classParam = Loader.loadClass(compiler, typeNameFull, coreThreadID);
					}
				}	
			} // else if (varUse.varDecl!=null) { // varUse가 변수인경우
			else if (varUse.funcDecl!=null) {// varUse가 함수인경우
				if (varUse.funcDecl.returnType!=null) {
					typeNameFull = varUse.funcDecl.returnType;
				}
				
				if (varUse.isArrayElement) {
					// varUse가 함수호출이자 배열원소인 경우
					// char c = first.toCharArray()[0]; 아니면
					//Class c = (new ScrollBars_test4().toObjectArray())[0].getClass(); 에서
					//varUse는 toObjectArray이다.
					if (varUse.listOfArrayElementParams==null) {
						Array.findArraySubscription(compiler, varUse, i, listOfAllVarUses, coreThreadID);
					}
					int dimension1 = Array.getArrayDimension(compiler, varUse.name);
					int dimension2 = Array.getArrayDimension(compiler, typeNameFull);
					if (dimension1==dimension2) {
						typeNameFull = Array.getArrayElementType(typeNameFull);
					}
					else {
						typeNameFull = null;
						CompilerStatic.errors.add(new Error(compiler, varUse.index(), varUse.index(), "Array dimension is invalid."));
					}
				}
				else {
					
				}
				classParam = Loader.loadClass(compiler, typeNameFull, coreThreadID);			
			}
			
			// 타입선언시 내부클래스가 있는 경우에 fullname타입 결정과 클래스로드를 한다. 
			//	타입선언시 shortname만 있는 경우는 getFullNameType, getFullNameType2에서 모두 찾는다.
			//	예를들어 java.lang패키지에 있는 클래스 Character.Subset s;에서 Character는 여기서 로드된다. 
			// 또한 같은 패키지내 클래스와 import java.util.*;와 같이 *를 섞어서 import하는 경우에 내부클래스가 있는 경우 여기서 해야 한다.
			if (varUse.parent==null && varUse.varDecl==null && varUse.funcDecl==null && varUse.memberDecl==null && 
					!CompilerHelper.IsConstant(varUseName) && varUse.isForVarOrForFunc) {
				if (varUse.index()==1635) {
				}
				
				typeNameFull = Fullname.getFullNameType2(compiler, varUseName, varUse.index(), coreThreadID);
				
				// Enumeration<java.util.jar.JarEntry> e; 에서 varUse는 Enumeration이다.
				// typeNameFull은 java.util.Enumeration이다.
				if (typeNameFull!=null) {
					// varUse가 타입일 경우에만 수행된다.
					int next = CompilerHelper.SkipBlank(src, false, varUse.index()+1, src.count-1);
					if (src.getItem(next).equals("<")) {
						// 타입이 템플릿일 경우에만 수행된다.
						// Enumeration<java.util.jar.JarEntry> e; 에서 varUse는 Enumeration이다.
						int typeStartIndex = Fullname.getFullNameIndex_OnlyType(compiler,  true, varUse.index(), true);
						int typeEndIndex = Fullname.getFullNameIndex_OnlyType(compiler,  false, varUse.index(), true);
						typeNameFull = Fullname.getFullNameType(compiler, typeStartIndex, typeEndIndex, coreThreadID);
						// typeNameFull은 java.util.Enumeration<java.util.jar.JarEntry>이다.
					}
				}
				
				classParam = Loader.loadClass(compiler, typeNameFull, coreThreadID);
				
				if (varUseName.equals("Subset")) {
				}
				varUse.memberDecl = classParam;
				// s = new String[10]; 에서 String은 여기에서 타입이 정해지기때문에 다시 처리
				// i = new int[10]; 에서 int는 클래스가 없기 때문에 다시 처리하지 않는다.
				if (varUse.isArrayElement) {
					if (!CompilerHelper.IsDefaultType(src.getItem(varUse.index()), compiler) && classParam!=null) {
						if (varUse.child!=null) {
							i--;
							continue;
						}
					}
				}
			}//if (varUse.parent==null && varUse.varDecl==null && varUse.funcDecl==null && varUse.memberDecl==null) {
			
			if (varUse.parent==null && varUse.varDecl==null && varUse.funcDecl==null && varUse.memberDecl==null && 
					CompilerHelper.IsConstant(varUseName) && varUse.child!=null) {
				if (varUse.index()==1635) {
				}
				
				int numberType = Number.IsNumber2(varUseName);
				typeNameFull = null;
				if (numberType==5) {
					typeNameFull = "java.lang.Float";
				}
				else if (numberType==6) {
					typeNameFull = "java.lang.Double";
				}
				else if (numberType==0) {
					if (varUseName.charAt(0)=='"') {
						typeNameFull = "java.lang.String";
					}
					else {
						typeNameFull = "java.lang.Character";
					}
				}
				else {
					typeNameFull = "java.lang.Integer";
				}
				
				if (typeNameFull!=null) {
					classParam = Loader.loadClass(compiler, typeNameFull, coreThreadID);	
				}
			}
			
			if (typeCast!=null && typeCast.indexOfLeftPair()==20396) {
				int a;
				a=0;
				a++;
			}
			
			// 타입캐스트인데 (타입캐스트)(수식)이 아닌 경우, 
			// ((java.lang.Object)buffer[i]).equals("("), (int)a
			// (long)buffer.length
			if (i==endIndexToTypeCast && (typeCast!=null && !typeCast.affectsExpression)) {
				// RectForPage p = (RectForPage)c; 여기서 c는 Control인데 varUse는 c 일때이다.
				if (typeCast.name!=null) {
					if (endIndexToTypeCast==10516) {
					}
					if (typeNameFull==null) {
						ReturnOfgetTypeOfVarUseOrFuncCallOfFullName2_sub typeFull = 
								Expression.getTypeOfVarUseOrFuncCallOfFullName(compiler, src, varUse.index(), coreThreadID);
						try {
							if (typeFull==null || typeFull.typeFullName==null) continue;
						typeNameFull = typeFull.typeFullName.str;
						}catch(Exception e) {
							if (Common_Settings.g_printsLog) e.printStackTrace();
						}
					}
					//boolean isDeclTemplate = FindVarUseParams.isDeclTemplate(compiler.mlistOfAllVarUses.getItem(endIndexToTypeCast));
					boolean isTypeCastTemplate = typeCast.isTypeNameToChange;
					if (typeCast.varUseTypeCasting.varDecl!=null && typeCast.varUseTypeCasting.varDecl.templateOfClass!=null) {
					}
					
					boolean isReturnTypeTemplate = false;
					if (varUse.funcDecl!=null) {
						// (IReset)this.getItem(i) 에서 varUse는 getItem이고 T getItem()이다.
						isReturnTypeTemplate = varUse.funcDecl.isTypeNameToChange;
					}
					
					if (!isTypeCastTemplate && !isReturnTypeTemplate && 
							!TypeCast_Syntax.isCompatibleType(compiler, compiler, new CodeStringEx(typeCast.name), new CodeStringEx(typeNameFull), 0, null, coreThreadID)) {
						CompilerStatic.errors.add(new Error(compiler, typeCast.startIndex(), typeCast.startIndex(), 
								"invalid type cast. : " + typeCast.name + "-" + typeNameFull));
					}
					else {
						typeNameFull = typeCast.name;
						classParam = Loader.loadClass(compiler, typeNameFull, coreThreadID);
					}
				}
				// 타입캐스트를 해결하였으므로 초기화
				typeCast = null;
			}
			
			
			if (typeNameFull!=null && classParam==null) {
				classParam = Loader.loadClass(compiler, typeNameFull, coreThreadID);
			}
			
			
			if (classParam==null) continue;
			
			// varUse의 로드된 클래스 멤버중에서 child의 변수타입이나 함수타입을 결정한다.
			// com.gsoft.common.ViewEx.moveFilesToSDCard()와 같은 경우는 이 함수의 위 부분에서 처리하고
			// ViewEx.moveFilesToSDCard()와 같은 경우는 여기에서 처리한다.
			if (child!=null) {
				if (child.memberDecl!=null || child.varDecl!=null || child.funcDecl!=null) continue;
				
				int o;
				if (child.index()-varUse.index()+1>3) {
					for (o=child.index()-1; o>varUse.index(); o--) {
						CodeString str = src.getItem(o);
						if (str.equals(")")) {
							int indexOfLeftPair = Checker.CheckParenthesis(compiler,  "(", ")", 0, o, true);
							int indexOfFuncCall = CompilerHelper.SkipBlank(src, true, 0, indexOfLeftPair-1);
							FindVarUseParams varUseFuncCall = CompilerStatic.getVarUseWithIndex(compiler.data.mlistOfAllVarUsesHashed, 
									src.getItem(indexOfFuncCall).str, indexOfFuncCall);
							// typeIndex = compiler.IsType(src, true, rightParent-1).index;
							// varUseFuncCall is IsType.(X)
							if (varUseFuncCall==null) {
								int fullNameIndex_start = Fullname.getFullNameIndex(compiler, true, varUse.index(), false);
								int prevIndexOfFullNameIndex = CompilerHelper.SkipBlank(src, true, 0, fullNameIndex_start-1);
								CodeString prevStr = src.getItem(prevIndexOfFullNameIndex);
								if (CompilerHelper.IsOperator(src.getItem(prevIndexOfFullNameIndex))) {									
									// int len = (str1+str2).length() (O)
									// Here, this makes '+' an error.
									int errorIndex = prevIndexOfFullNameIndex;
									CompilerStatic.errors.add(new Error(compiler, errorIndex, errorIndex, "invalid operator in member operator '.'"));
								}
							}							
						}
					}
				}// if (child.index()-varUse.index()+1>3) {
				if (child.isForVarOrForFunc) {
					if (child.index()==83) {
						int a;
						a=0;
						a++;
					}
					
					child.varDecl = getMemberVar(compiler, src, classParam, child);
					if (child.varDecl==null) {
						if (varUse.memberDecl==null) continue;
						
						
						
						boolean isInnerClassIn = 
								CompilerHelper.hasInnerClass(compiler, classParam.name, child.originName, true, coreThreadID);
						if (!isInnerClassIn) continue;
						typeNameFull = classParam.name + "." + child.originName;
						child.memberDecl = Loader.loadClass(compiler, typeNameFull, coreThreadID);
					}
				}
				else {
					// 내부클래스의 생성자 호출 이외의 경우
					child.funcDecl = getFunction(compiler, classParam, child, coreThreadID);
					if (child.funcDecl!=null) continue;
					
					// 내부클래스의 생성자 호출인지 확인한다.
					// pair = new UndoBuffer.Pair();에서 child는 Pair이다.
					if (CompilerHelper.IsConstant(src.getItem(child.index()))) continue;
					typeName = child.originName;
					typeNameFull = classParam.name + "." + typeName;
					
					
					// CustomView 에서 owner는 타입이 CustomView 일때
					// Point p = owner.getLocation(); 에서
					// varUse는 owner이고 varUse의 child는 getLocation()이다.
					// getLocation()는 java.awt.Component의 멤버함수인데
					// java.awt.Component를 읽을수 없으므로 위 getFunction()에서
					// getLocation()을 찾을 수 없다. 
					// 그래서 여기서 필요없는 loadClass()를 하지 않도록 
					// 내부클래스의 생성자 호출인지 확인한다.
					if (varUse.memberDecl==null) continue;
					
					// pair = new UndoBuffer.Pair();에서 child는 Pair이다.
					// Pair클래스를 찾는다.
					boolean isInnerClassIn = 
							CompilerHelper.hasInnerClass(compiler, classParam.name, child.originName, true, coreThreadID);
					if (!isInnerClassIn) continue;
					
					classParam = Loader.loadClass(compiler, typeNameFull, coreThreadID);					
					if (classParam==null) continue;
					
					// pair = new UndoBuffer.Pair();에서 child는 Pair이다.
					// Pair클래스의 생성자 Pair()을 찾는다.
					child.funcDecl = getFunction(compiler, classParam, child, coreThreadID);
				}// if (!child.isForVarOrForFunc) {
				
			}// if (child!=null) {
			
			//if (found) continue;
			}catch(Exception e) {
				if (Common_Settings.g_printsLog) e.printStackTrace();
				if (Common_Settings.g_printsLog) CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
			}
		}//for (i=0; i<listOfAllVarUses.count; i++) {
	}
	
	
	/** 해당클래스에서 lValue에 해당하는 변수선언 var를 찾는다.*/
	public static FindVarParams getVarDecl(HighArray_CodeString src, FindClassParams classParams, FindVarUseParams lValue) {
		int i, j;
		// 먼저 지역변수인지 검사
		for (i=0; i<classParams.listOfFunctionParams.count; i++) {
			FindFunctionParams func = (FindFunctionParams) classParams.listOfFunctionParams.getItem(i);
			if (func.startIndex()<lValue.index() && lValue.index()<func.endIndex()) {
				for (j=0; j<func.listOfVariableParams.count; j++) {
					FindVarParams var = (FindVarParams) func.listOfVariableParams.getItem(j);
					if (var.varNameIndex()==-1) continue;
					if (src.getItem(var.varNameIndex()).equals(src.getItem(lValue.index())))
						return var;
				}				
			}
			else if (lValue.index()<func.startIndex()) break;
		}
		// 멤버변수인지 검사
		for (i=0; i<classParams.listOfVariableParams.count; i++) {
			FindVarParams var = (FindVarParams) classParams.listOfVariableParams.getItem(i);
			if (var.varNameIndex()==-1) continue;
			if (src.getItem(var.varNameIndex()).equals(src.getItem(lValue.index())))
				return var;
		}
		return null;
		
	}
	
	
}
