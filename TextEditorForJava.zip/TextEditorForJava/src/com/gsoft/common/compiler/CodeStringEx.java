package com.gsoft.common.compiler;

import com.gsoft.common.Code.CodeChar;
import com.gsoft.common.Code.CodeString;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.interfaces.IReset;
import com.gsoft.common.compiler.Compiler_types.FindVarUseParams;
import com.gsoft.common.util.ArrayListIReset;
import com.gsoft.common.util.ArrayListInt;

import com.gsoft.common.compiler.HighArray_CodeString;

/** ArrayListIReset listOfVarUses(구분자이면 null, 변수나 함수호출이면 해당 varUse를 참조한다) 멤버를 갖는다. */
public class CodeStringEx extends CodeString implements IReset {
	/** 소스상에서의 인덱스*/
	public ArrayListInt indicesInSrc;
	/** 구분자이면 null, 변수나 함수호출이면 해당 varUse를 참조한다.*/
	public ArrayListIReset listOfVarUses;
	/** 토큰의 fullname 타입, getTypeOfVarUseOrFuncCallOfFullName에서 정해진다.*/
	public String typeFullName;
	
	/** +, -가 일항연산자인 경우 이항연산자와 구분하기 위해 사용된다. 
	 * 일항연산자이면 true, 아니면 false 이다. processOperatorForOne()에서 정해진다.
	 */
	public boolean isPlusOrMinusForOne;
	
	/** 값을 말한다. byte b = 1+127; 에서 1, 127은 value를 갖게 되며, 
	 * CompilerHelper.getTypeOfOperator()의 allowsOperator()에서 연산결과의 타입을 갖게된다.*/
	//String value;
	
	/** this.backColor의 경우 'this', '.', 'backColor'가 된다.*/
	HighArray_CodeString arrayListCodeStringForToken;
	
	/** 묵시적 타입캐스팅, CompilerHelper.getTypeOfOperator()에서 정해진다.
	 * 예를들어 f = i + f;에서 i는 float로 타입캐스트된다.
	 * 여기에서 i의 typeFullName은 int가 되고 typeFullNameAfterOperation은 float가 된다.
	 * int i = i1 + i2 + f; 에서 i1과 i2의 덧셈결과는 int가 되고 f를 더할 때 i1과 i2의 덧셈결과는
		float로 타입캐스트되어야 한다. 이때는 첫번째 '+"의 typeFullNameAfterOperation이 float가 된다.
		그러기 위해서 operand나 operator에 있는 typeFullNameAfterOperation에 연산시 바뀌는
		타입을 저장한다.*/
	public String typeFullNameAfterOperation;
	
	public boolean isTypeNameToChangeForTemplate; 
	
	/**typeFullNameAfterOperation이 null이면 typeFullName, 
	 * 그렇지 않으면 typeFullNameAfterOperation을 리턴하여 오퍼랜드나 오퍼레이터의 실제 타입을 얻는다.
	 * @return
	 */
	public String getTypeFullNameOrTypeFullNameAfterOperation() {
		if (this.typeFullNameAfterOperation==null) {
			return this.typeFullName;
		}
		return this.typeFullNameAfterOperation;
	}
	
	/** 묵시적 타입 캐스트를 위해 필요하다. i2f, i2d, f2i등
	 * Compiler.getTypeOfExpression(), CompilerHelper.getTypeOfOperator()에서 사용한다.
	 * int i = i1 + i2 + f; 에서 i1과 i2의 덧셈결과는 int가 되고 f를 더할 때 i1과 i2의 덧셈결과는
		float로 타입캐스트되어야 한다. 이때는 첫번째 '+"의 typeFullNameAfterOperation이 float가 된다.
		그러기 위해서 operand나 operator에 있는 typeFullNameAfterOperation에 연산시 바뀌는
		타입을 저장한다. 수식스택에 타입을 넣을때 원래의 operand나 operator를 갖게된다.*/
	public CodeStringEx operandOrOperator;
	
	/** i = i1+2; 에서 i1의 affectedBy_left는 '+'이다.
	 * if (i1+2>3 && i2<2) 에서 '+'의 affectedBy_left는 '>'이다. 
	 * '>'의 affectedBy_left는 '&&'이다.*/
	public CodeStringEx affectedBy_left;
	
	/** i = i1+2; 에서 2의 affectedBy_right는 '+'이다.
	 * if (i1+2>3 && i2<2) 에서 3의 affectedBy_right는 '>'이다. 
	 * '<'의 affectedBy_right는 '&&'이다.*/
	public CodeStringEx affectedBy_right;
	
	/** left, right 이든 상관없이 영향받을 경우*/
	public CodeStringEx affectedBy;
	
	/**왼쪽 오퍼랜드*/
	public CodeStringEx affectsLeft;
	/**오른쪽 오퍼랜드*/
	public CodeStringEx affectsRight;
	
	/** 바이트코드출력시에 조건문에서 어떤 조건에서 OR위치로 점프해야할때 해당 OR위치에 
	 *  OR주석을 출력한다. 
	 */
	public boolean printsORComment;
	
	/** 바이트코드출력시에 조건문에서 어떤 조건에서 AND위치로 점프해야할때 해당 AND위치에 
	 *  AND주석을 출력한다. 
	 */
	public boolean printsANDComment;
	
	/** 바이트코드출력시에 조건문에서 어떤 조건에서 NOT위치로 점프해야할때 해당 NOT위치에 
	 *  NOT주석을 출력한다. 
	 */
	public boolean printsNOTComment;
	
	/** 바이트코드 생성시에 if**에서 브랜치할 OR 이후의 토큰*/
	public CodeStringEx tokenAfterOR;
	/** 바이트코드 생성시에 if**에서 브랜치할 AND 이후의 토큰*/
	public CodeStringEx tokenAfterAND;
	/** 바이트코드 생성시에 if**에서 브랜치할 NOT 이후의 토큰*/
	CodeStringEx tokenAfterNOT;
	
	/** 바이트코드 생성시에 if**에서 브랜치한 후 스택에 넣을 값이 iconst 1이면 true, 
	 * 그렇지 않으면 false*/
	public boolean trueOrFalse;
	
	
	
	public CodeStringEx(CodeChar[] text, int len, ArrayListInt indicesInSrc, ArrayListIReset listOfVarUses) {
		super(text, len);
		
		this.indicesInSrc = indicesInSrc;
		this.listOfVarUses = listOfVarUses;
	}
	
	public CodeStringEx(String str, int textColor, ArrayListInt indicesInSrc, ArrayListIReset listOfVarUses) {
		super(str, textColor);
		this.indicesInSrc = indicesInSrc;
		this.listOfVarUses = listOfVarUses;
	}
	
	public CodeStringEx(String str) {
		
		super(str, Common_Settings.textColor);
	}
	
	public Object clone() {
		CodeStringEx r = new CodeStringEx(str);
		r.affectedBy = this.affectedBy;
		r.affectedBy_left = this.affectedBy_left;
		r.affectedBy_right = this.affectedBy_right;
		r.affectsLeft = this.affectsLeft;
		r.affectsRight = this.affectsRight;
		r.arrayListCodeStringForToken = this.arrayListCodeStringForToken;
		r.count = this.count;
		r.indicesInSrc = this.indicesInSrc;
		r.isPlusOrMinusForOne = this.isPlusOrMinusForOne;
		int i;
		r.listCodeChar = new CodeChar[this.count];
		for (i=0; i<this.count; i++) {
			r.listCodeChar[i] = (CodeChar) this.listCodeChar[i].clone();
		}
		//r.listCodeChar = this.listCodeChar.clone();
		r.listOfVarUses = this.listOfVarUses;
		r.operandOrOperator = this.operandOrOperator;
		r.printsANDComment = this.printsANDComment;
		r.printsNOTComment = this.printsNOTComment;
		r.printsORComment = this.printsORComment;
		r.str = this.str;
		r.tokenAfterAND = this.tokenAfterAND;
		r.tokenAfterNOT = this.tokenAfterNOT;
		r.tokenAfterOR = this.tokenAfterOR;
		r.trueOrFalse = this.trueOrFalse;
		r.typeFullName = this.typeFullName;
		r.typeFullNameAfterOperation = this.typeFullNameAfterOperation;
		//r.value = this.value;
		//r.operatorAfterNOTOperation = this.operatorAfterNOTOperation;
		return r;
				
	}
	
	/**listCodeChar을 제외하고 str과 typeFullName을  바꾼다.*/
	public void setStrAndTypeFullName(String str, String typeFullName) {
		this.str = str;
		
		this.typeFullName = typeFullName;
	}
	
	public String toString() {
		
		return this.str;
	}
	
	/** indexInSrc는 a = a.concate(b)에서 a 의 indexInSrc에 b 의 indexInSrc(-1이 아닌경우에만)이 추가된다.*/
	public CodeStringEx concate(CodeStringEx str) {
		CodeString temp;
		temp = super.concate(str);
		CodeStringEx r;
		ArrayListInt p = this.indicesInSrc;
		ArrayListIReset v = this.listOfVarUses;
		
		int i;
		ArrayListInt p2 = str.indicesInSrc;
		ArrayListIReset v2 = str.listOfVarUses;
		for (i=0; i<p2.count; i++) {
			p.add(p2.getItem(i));
		}
		for (i=0; i<v2.count; i++) {
			v.add(v2.getItem(i));
		}
		r = new CodeStringEx(temp.listCodeChar, temp.count, p, v);
		if (this.count>0) {
			r.setType(this.listCodeChar[0].type);
		}
		if (this.isPlusOrMinusForOne) {
			r.isPlusOrMinusForOne = true;
		}
		return r;
	}

	/** indexInSrc는 a = a.concate(b)에서 a 의 indexInSrc에 b 의 indexInSrc(-1이 아닌경우에만)이 추가된다.*/
	public CodeString concate(CodeString str, int indexInSrc, FindVarUseParams varUse) {
		CodeString temp;
		temp = super.concate(str);
		CodeStringEx r;
		ArrayListInt p = this.indicesInSrc;
		ArrayListIReset v = this.listOfVarUses;
		if (indexInSrc!=-1) {				
			p.add(indexInSrc);
			v.add(varUse);
		}
		r = new CodeStringEx(temp.listCodeChar, temp.count, p, v);
		if (this.isPlusOrMinusForOne) {
			r.isPlusOrMinusForOne = true;
		}
		if (this.count>0) {
			r.setType(this.listCodeChar[0].type);
		}
		return r;
	}
	
	/** indexInSrc는 a = a.substring(s, e)에서 a의 indexInSrc이 된다.*/
	public CodeString substring(int start, int end) {
		CodeString temp;
		temp = super.substring(start, end);
		CodeStringEx r;
		r = new CodeStringEx(temp.listCodeChar, temp.count, this.indicesInSrc, this.listOfVarUses);
		if (this.isPlusOrMinusForOne) {
			r.isPlusOrMinusForOne = true;
		}
		if (this.count>0) {
			r.setType(this.listCodeChar[0].type);
		}
		return r;
	}

	public void reset() {
		
		if (this.indicesInSrc!=null) {
			this.indicesInSrc.reset2();
			this.indicesInSrc = null;
		}
		if (this.arrayListCodeStringForToken!=null) {
			this.arrayListCodeStringForToken.destroy();
			this.arrayListCodeStringForToken = null;
		}
		if (this.listCodeChar!=null) {
			int i;
			for (i=0; i<this.listCodeChar.length; i++) {
				this.listCodeChar[i] = null;
			}
			this.listCodeChar = null;
		}
		if (this.listOfVarUses!=null) {
			this.listOfVarUses.destroy();
			this.listOfVarUses = null;
		}
		this.str = null;
		this.typeFullName = null;
	}
	
	
}
