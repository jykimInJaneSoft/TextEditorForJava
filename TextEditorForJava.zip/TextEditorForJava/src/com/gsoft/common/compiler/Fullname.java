package com.gsoft.common.compiler;

import java.io.File;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.Compiler_types.FindFunctionParams;
import com.gsoft.common.compiler.Compiler_types_Base.Error;
import com.gsoft.common.compiler.TemplateBase.Template;
import com.gsoft.common.util.ArrayListCodeString;
import com.gsoft.common.util.ArrayListIReset;
import com.gsoft.common.util.ArrayListInt;
import com.gsoft.common.util.ArrayListString;
import com.gsoft.common.FileHelper;

import com.gsoft.common.compiler.HighArray_CodeString;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.Array;
import com.gsoft.common.compiler.TemplateBase;
import com.gsoft.common.compiler.Checker;
import com.gsoft.common.compiler.CompilerStatic;
import com.gsoft.common.compiler.ClassCache;
import com.gsoft.common.compiler.Compiler;


public class Fullname {
	
	/**mode가 0이면 Control.pathAndroid로부터, 
	 * mode가 1이면 Control.pathJaneSoft/output로부터
	 * mode가 2이면 Control.pathProjectSrc로부터 fullname를 얻는다.
	 * mode가 3이면 Control.pathOther_Lib로부터 fullname를 얻는다.
	 * 존재하지 않는 파일이나 디렉토리이면 null을 리턴한다.
	 * @param filePath : 확장자는 .class이거나 .java이어야 한다.*/
	public static String toFullname(int mode, String filePath) {
		
		return CompilerStatic.getFullname_FromVariousClassPath(mode, filePath);
	}
	
	
	
	/** startIndex()부터 '.'이 아닌 구분자(공백, ';', ','등)를 만날 때까지 full name을 리턴한다.
	 * startIndex()가 공백과 같은 구분자이면 빈스트링을 리턴한다.*/
	public static ArrayListCodeString getFullName(Compiler compiler, int startIndex) {
		HighArray_CodeString src = compiler.data.mBuffer;
		int j;
		ArrayListCodeString type = new ArrayListCodeString(10);
		for (j=startIndex; j<src.count; j++) {
			CodeString item = src.getItem(j);
			if (CompilerHelper.IsBlank(item) || CompilerHelper.IsComment(item)) continue;
			else if (item.equals(".")) {
				int prevIndex = CompilerHelper.SkipBlank(src, true, startIndex, j-1);
				if (prevIndex==startIndex-1) break;
				CodeString prev = src.getItem(prevIndex);
				// . 이전에는 id가 와야 한다.
				if ( !(CompilerHelper.IsIdentifier(prev, compiler)) ) {
					CompilerStatic.errors.add(new Error(compiler, prevIndex,prevIndex,"Invalid identifier, invalid token. : "+prev));
					break;
				}
				int nextIndex = CompilerHelper.SkipBlank(src, false, j+1, src.count-1);
				if (nextIndex==src.count) break;
				CodeString next = src.getItem(nextIndex);
				// . 다음에는 id가 와야 한다.
				if ( !(CompilerHelper.IsIdentifier(next, compiler)) ) {
					CompilerStatic.errors.add(new Error(compiler, nextIndex,nextIndex,"Invalid identifier, invalid token. : "+next));
					break;
				}
				type.add(item);
			}			
			else if (CompilerHelper.IsSeparator(item)) { // .이 아닌 구분자이면
				break;
			}
			else if (CompilerHelper.IsKeyword(item, compiler)) { // .이 아닌 키워드이면
				CompilerStatic.errors.add(new Error(compiler, j,j,"Invalid identifier, invalid token : "+item));
				break;
			}
			else { // id
				type.add(item);
			}
			
		}
		return type;
	}
	
	
	public static String getFullNameType3(Compiler compiler, String name, ArrayListIReset listOfAllClasses) {
		if (name==null) {
			return null;
		}
		if (listOfAllClasses==null) return null;
		
		if (CompilerHelper.IsDefaultType(name, compiler)) {
			return name;
		}
		if (!name.contains(".")) {
			int i;
			for (i=0; i<listOfAllClasses.count; i++) {
				FindClassParams c = (FindClassParams) listOfAllClasses.getItem(i);
				if (CompilerHelper.getShortName(c.name).equals(name)) return c.name;
			}
			return null;
		}
		else {
			int i;
			for (i=0; i<listOfAllClasses.count; i++) {
				FindClassParams c = (FindClassParams) listOfAllClasses.getItem(i);
				if (c.name.equals(name)) return c.name;
			}
			return null;
		}
	}
	
	
	/** name으로 클래스 찾기, getFullNameType()과 다른 점은 getFullNameType()은 타입에 배열이나 템틀릿기호가 붙을수 있는데,  
	 * getFullNameType2는 배열이나 템플릿기호가 없는 순수한 클래스이름이다.
	 * full name이 아니고 import라이브러리타입, 라이브러리 타입(Object, Class, Integer등)도 아니면 
	 * 패키지 이름을 붙인 full name을 리턴한다.
	 * full name이 아니고 내장타입(int, char등), 라이브러리 타입이면 그대로 리턴한다.
	 * @param name : short이름 full이름 구분 안 함
	 * @param indexOfSrc : name의 소스에서의 index, 비슷하게 정해주면 된다.
	 * @return : 1. int, char등 기본타입, 2. import클래스의 full이름, 
	 * 3. 동일 패키지내 클래스의 풀이름, 4. 자신이 정의하는 클래스*/
	public static String getFullNameType2(Compiler compiler, String name, int indexOfSrc, int coreThreadID) {
		if (name==null) {
			return null;
		}		
		
		
		if (CompilerHelper.IsDefaultType(name, compiler)) {
			return name;
		}
		if (!name.contains(".")) {
						
			String typeNameFull = null;
			String varUseName = name;
			if (typeNameFull==null) {
				typeNameFull = Fullname.getTypeOfImportLibrary(compiler, varUseName);
			}
			
			// import com.gsoft.common.Util.*; Stack<Character.Subset> s;에서 Stack을 결정한다.
			if (typeNameFull==null) {
				typeNameFull = Fullname.getTypeOfImportStar(compiler, varUseName);
			}
			
			if (typeNameFull==null) {
				FindClassParams c = Fullname.getTypeOfDefinedClass(compiler, varUseName, indexOfSrc);
				if (c!=null) {
					typeNameFull = c.name;
				}
			}
			
			// com.gsoft.common.gui패키지에서 LangDialog를 import하지않고 
			// LangDialog d = new LangDialog()에서 LangDialog를 결정한다.
			if (Common_Settings.g_findsPackageLibrary) {
				if (typeNameFull==null) {
					typeNameFull = Fullname.getTypeOfPackageLibrary(compiler, varUseName);
				}
			}
			
			// java.lang패키지를 import하지 않고 Thread.sleep(1000); 에서 Thread를 결정한다.
			if (typeNameFull==null) {
				if (Fullname.IsTypeOfDefaultLibrary(compiler, varUseName)) {
					typeNameFull = "java.lang." + varUseName;
				}
				
			}
			return typeNameFull;
		}
		else {
			if (checkTypeNameInFileList(compiler, name, coreThreadID)) {
				return name;
			}
		}
		return null;
		
	}
	
	
	
	
	
	/** full name 하나를 검색한다. 에러도 넣어준다.
	 * extends일 경우는 implements나 {의 인덱스를 리턴,
	 * implements 일 경우는 ,나 {의 인덱스를 리턴 
	 * @param extendsOrImplementsOrThrows = "extends", "implements", "throws"
	 * @param classParams = "extends", "implements"일 경우 null이 아님 
	 * @param functionParams = "throws"일 경우 null이 아님
	 * @param startIndex()
	 */
	static int getFullNames(Compiler compiler, String extendsOrImplementsOrThrows,
			FindClassParams classParams, FindFunctionParams functionParams, 
			int startIndex) {
		HighArray_CodeString src = compiler.data.mBuffer;
		int index = CompilerHelper.SkipBlank(src, false, startIndex, src.count-1);
        if (index==src.count) {
        	return -1;
        }
		if (extendsOrImplementsOrThrows.equals("extends")) {
			ArrayListCodeString fullName = getFullName(compiler, index);
			String strFullName = convertFullNameToString(fullName);
	        classParams.classNameToExtend = strFullName;
	        
	        index += fullName.count;
	        index = CompilerHelper.SkipBlank(src, false, index, src.count-1);
	        if (index==src.count) {
	        	return index;
	        }
	        
	        CodeString cstr = src.getItem(index);
	        if (cstr.equals("implements")) {
	        	return index;
	        }
	        else if (cstr.equals("{")){
	        	return index;	        	
	        }
	        else {
	        	CompilerStatic.errors.add(new Error(compiler, index, index, "invalid extends"));
	        	return -1;
	        }
		}
		else if (extendsOrImplementsOrThrows.equals("implements")) {
			ArrayListCodeString fullName = getFullName(compiler, index);
			String strFullName = convertFullNameToString(fullName);
			if (classParams.interfaceNamesToImplement==null) {
				classParams.interfaceNamesToImplement = new ArrayListString(2);
				classParams.interfaceNamesToImplement.add(strFullName);
			}
			else {
				classParams.interfaceNamesToImplement.add(strFullName);
			}
	        
	        index += fullName.count;
	        index = CompilerHelper.SkipBlank(src, false, index, src.count-1);
	        if (index==src.count) {
	        	return index;
	        }
	        
	        CodeString cstr = src.getItem(index);
	        if (cstr.equals(",")) {
	        	return index;
	        }
	        else if (cstr.equals("{")){
	        	return index;	        	
	        }
	        else {
	        	CompilerStatic.errors.add(new Error(compiler, index, index, "invalid implements"));
	        	return -1;
	        }
		}
		else if (extendsOrImplementsOrThrows.equals("throws")) {
			ArrayListCodeString fullName = getFullName(compiler, index);
			String strFullName = convertFullNameToString(fullName);
			if (functionParams.exceptionNamesToThrow==null) {
				functionParams.exceptionNamesToThrow = new ArrayListString(2);
				functionParams.exceptionNamesToThrow.add(strFullName);
			}
			else {
				functionParams.exceptionNamesToThrow.add(strFullName);
			}
	        
	        index += fullName.count;
	        index = CompilerHelper.SkipBlank(src, false, index, src.count-1);
	        if (index==src.count) {
	        	return index;
	        }
	        
	        CodeString cstr = src.getItem(index);
	        if (cstr.equals(",")) {
	        	return index;
	        }
	        else if (cstr.equals("{")){
	        	return index;	        	
	        }
	        else {
	        	CompilerStatic.errors.add(new Error(compiler, index, index, "invalid throws in function"));
	        	return -1;
	        }
		}
		return -1;
	}
	
	
	/** 주의사항 : 자신이 정의하는 클래스만 가능하다. 다시말해 외부클래스에는 적용할수없다.
	 * 해당 클래스의 full name을 얻을때 호출한다. 리턴값에 "."이 뒤에 붙는것을 주의한다.
	 * 완벽한 full name을 얻기 위해 리턴값에서 packageName + "." 을 앞에 붙인다. */
	public static String getFullNameExceptPackageName(HighArray_CodeString src, FindClassParams findClassParams) {
		if (findClassParams==null) return null;
		if (findClassParams.classNameIndex()==-1) return null;
		String className = "";
		FindClassParams classParams = findClassParams;
		while (classParams!=null) {
			if (classParams.classNameIndex()==-1) { // C의 경우는 -1이다.
				break;
			}
			className = src.getItem(classParams.classNameIndex()).toString() + "." + className;
			classParams = (FindClassParams) classParams.parent;
		}
		return className;
	}
	
	
	
	
	
	
	/** FindVarParams.getType(), FindFunctionParams.getReturnType()에서 호출된다. 
	 * 위 함수들에서는 typeName, returnType멤버의 캐시를 이용하므로  
	 * typeName, returnType이 정확한 풀이름을 갖고있을때는
	 * getFullNameType()을 이용하지 말고 var.getType()과 func.getReturnType()을 이용해야 한다.
	 * 
	 * FindClass()함수에서 이 함수를 호출하면 아직 mListOfAllDefinedClass에 파일에 정의된 클래스들이 모두 등록되지 않은 상태이므로
	 * 같은 파일에 정의된 클래스를 상속하는 경우나 인터페이스를 구현하는 경우 fullname이 틀릴수 있다. 
	 * 또한 같은 파일에 정의된 클래스의 이름이 확실하게 fullname으로 정해진 이후에 호출되어야 한다. 
     * FindAllClassesAndItsMembers2_sub()을 호출한 이후 클래스 이름을 fullname으로 정하고 클래스 캐시에 등록한 이후를 말한다.
     * (FindAllClassesAndItsMembers2()와 start_onlyInterface()함수를 참조한다.)
	 * 따라서 FindAllClassesAndItsMembers2_sub()을 호출한 이후에 getFullNameType()을 호출해야 한다.
	 * 예를들어 FindClassesFromTypeDecls()는 FindAllClassesAndItsMembers2_sub()을 호출한 이후에 호출된다.
	 * 
	 * 
	   
	 * 
	 * 변수타입의 full name을 얻을때 호출한다. 
	 * 단순히 startIndex(), endIndex()사이의 공백, 주석을 제외한 문자열을 연결한다.
	 * 
	 * 연결한 스트링의 첫번째 부분으로
	 * full name이 아니고 import라이브러리타입, 라이브러리 타입(Object, Class, Integer등)도 아니면 
	 * 패키지 이름을 붙인 full name을 리턴한다.
	 * full name이 아니고 내장타입(int, char등), 라이브러리 타입이면 그대로 리턴한다.
	 * @param compiler : compiler의 mBuffer와 startIndex(), endIndex()가 일치해야 한다. 
	 * 즉 startIndex(), endIndex()는 올바른 소스 파일에서의 인덱스여야 한다.
	 * @param src
	 * @param startIndex() : 포함
	 * @param endIndex() : 포함, int getFullNameIndex(HighArray_CodeString src, int startIndex)을 통해 알아낸다.
	 * @return : full name, 내장타입(int, char등), import라이브러리타입, 자바라이브러리타입(Object, Class, Integer등)
	 */
	public static String getFullNameType(Compiler compiler, int startIndex, int endIndex, int coreThreadID) {
		//HighArray_CodeString src = compiler.mBuffer;
		if (startIndex==-1 || endIndex==-1) return null;
		if (startIndex==899) {
		}
		HighArray_CodeString src = compiler.data.mBuffer;
		int i;
		String str = "";
		int indexOfHead=startIndex; // fullname에서 첫번째 부분의 인덱스
		boolean isHead = true;
		for (i=startIndex; i<=endIndex; i++) {
			try{
			CodeString s = src.getItem(i);
			if (CompilerHelper.IsBlank(s) || CompilerHelper.IsComment(s)) {
				continue;
			}
			else if (s.equals(".")) {
				str += s.str;
				isHead = false;
			}
			else if (CompilerHelper.IsIdentifier(s, compiler)) {
				str += s.str;
				if (isHead) {
					indexOfHead = i;
					isHead = false;
				}
			}
			else {//배열, 템플릿 기호등
				str += s.str;
			}
			}catch(Exception e) {	
			}
		}
		if (str.equals("java.lang.String")) {
		}
		if (str.contains("RedoBuffer")) {
		}
		boolean isArray = false;
		int dimensionOfArray = 0;
		
		dimensionOfArray = Array.getArrayDimension(compiler, str);
		if (dimensionOfArray!=0) {
			isArray = true;
			str = str.substring(0, str.length()-2*dimensionOfArray);
		}
		
		// 템플릿이나 템플릿 배열일 경우, 예를들어 Stack<String> s; 혹은 Stack<String>[] s;
		boolean isTemplate = false;
		int indexTemplateLeftPair = str.indexOf("<");
		int indexTemplateRightPair = -1;
		Template template = null;
		String typeNameToChange = null;
		
		String strTemplate = "";
		if (indexTemplateLeftPair!=-1) {			
			int indexTemplateLeftPairInmBuffer = CompilerHelper.Skip(src, false, "<", startIndex, endIndex);
			int indexTemplateRightPairInmBuffer = 
					Checker.CheckParenthesis(compiler,  "<", ">", indexTemplateLeftPairInmBuffer, endIndex, false);
			
			indexTemplateRightPair = 
				Checker.CheckParenthesis(str, "<", ">", indexTemplateLeftPair, str.length()-1, false);
			isTemplate = true;
			if (indexTemplateRightPair!=-1) {
				// Stack<Object>에서 <Object>부분을 말한다. 
				//strTemplate = str.substring(indexTemplateLeftPair, indexTemplateRightPair+1);
				typeNameToChange = 
						getFullNameType(compiler, indexTemplateLeftPairInmBuffer+1, indexTemplateRightPairInmBuffer-1, coreThreadID);
				strTemplate = 
						"<"+typeNameToChange+">";
				// 위에서 Stack부분
				str = str.substring(0, indexTemplateLeftPair);
				
				int s = CompilerHelper.SkipBlank(src, false, indexTemplateLeftPairInmBuffer, indexTemplateRightPairInmBuffer);
				int e = CompilerHelper.SkipBlank(src, true, indexTemplateLeftPairInmBuffer, indexTemplateRightPairInmBuffer);
				
				template = TemplateBase.getMostSuitableTemplate(compiler.data.mlistOfAllTemplates, s, e);
				if (template!=null) {
					template.typeName = str;
					template.typeNameToChange = typeNameToChange;
				}
				
			}
		}
		
		if (str.equals("Enumeration")) {
		}
		
		if (startIndex==899) {
		}
		
		// str이 short name이 아닌 full name일 경우 fullname을 찾는다.
		String fullNameType = getFullNameType2(compiler, str, indexOfHead, coreThreadID);
		if (fullNameType!=null) {
			// "."을 포함하면 뒤에서 아니면 여기에서 fullname을 결정하여 리턴한다.
			if (!str.contains(".")) {
				if (!isArray) {
					if (isTemplate) {
						if (template==null) {
						}
						template.typeName = fullNameType;
						template.typeNameToChange = typeNameToChange;
						return fullNameType + strTemplate;					
					}
					// 템플릿이 아니면
					return fullNameType;
				}
				else {
					if (isTemplate) {
						template.typeName = fullNameType;
						template.typeNameToChange = typeNameToChange;
						String fullNameIncludingTemplate = fullNameType + strTemplate;
						return Array.getArrayType(fullNameIncludingTemplate, dimensionOfArray);
					}
					// 템플릿이 아니면
					return Array.getArrayType(fullNameType, dimensionOfArray);
				}
			}
		}
		
		
		String remainder=null;
		
		int indexOfDot = str.indexOf('.');
		if (indexOfDot!=-1) {
			// Compiler_types.Language lang;에서 str은 Compiler_types이고 remainder는 Language이다.
			remainder = str.substring(indexOfDot+1, str.length());
			str = str.substring(0, indexOfDot);
		}		
		
		if (CompilerHelper.IsDefaultType(str, compiler)) {
			if (!isArray) {
				if (isTemplate) {
					return null;					
				}
				// 템플릿이 아니면
				if (remainder==null) return str;
				else {
					return null;
				}
			}
			else {
				if (isTemplate) {
					return null;
				}
				// 템플릿이 아니면
				if (remainder==null) return Array.getArrayType(str, dimensionOfArray);
				else {
					return null;
				}
			}
		}
		
		// import java.lang.Character; Character.Subset s; 에서 
		// str은 Character이고 remainder는 Subset이다.
			String importedLibrary = Fullname.getTypeOfImportLibrary(compiler, str);
			if (importedLibrary!=null) {
				if (!isArray) {
					if (isTemplate) {
						if (template!=null) {
							if (remainder==null) template.typeName = importedLibrary;
							else template.typeName = importedLibrary + "." + remainder;
							template.typeNameToChange = typeNameToChange;
						}
						if (remainder==null) {
							return importedLibrary+strTemplate;
							/*boolean exists = this.checkTypeNameInFileList(compiler, importedLibrary);
							if (exists) {
								return importedLibrary + strTemplate;
							}
							else return null;*/
						}
						else {
							String name = importedLibrary + "." + remainder;
							//boolean exists = this.checkTypeNameInFileList(compiler, name);
							//if (exists) {
								return name + strTemplate;
							//}
							//else return null;
						}
					}
					if (remainder==null) {
						return importedLibrary;
						/*boolean exists = this.checkTypeNameInFileList(compiler, importedLibrary);
						if (exists) {
							return importedLibrary;
						}
						else return null;*/
					}
					else {
						//boolean exists = this.checkTypeNameInFileList(compiler, name);
						//if (exists) {
							return importedLibrary + "." + remainder;
						//}
						//else return null;
					}
				}
				else {
					if (isTemplate) {
						if (template!=null) {
							if (remainder==null) template.typeName = importedLibrary;
							else template.typeName = importedLibrary+"."+remainder;
							template.typeNameToChange = typeNameToChange;
						}
						if (remainder==null) {
							return Array.getArrayType(importedLibrary+strTemplate, dimensionOfArray);
							/*boolean exists = this.checkTypeNameInFileList(compiler, importedLibrary);
							if (exists) {
								return Array.getArrayType(importedLibrary+strTemplate, dimensionOfArray);
							}
							else return null;*/
						}
						else {
							String name = importedLibrary + "." + remainder;
							//boolean exists = this.checkTypeNameInFileList(compiler, name);
							//if (exists) {
								return Array.getArrayType(name+strTemplate, dimensionOfArray);
							//}
							//else return null;
						}
					}
					if (remainder==null) {
						return Array.getArrayType(importedLibrary, dimensionOfArray);
						/*boolean exists = this.checkTypeNameInFileList(compiler, importedLibrary);
						if (exists) {
							return Array.getArrayType(importedLibrary, dimensionOfArray);
						}
						else return null;*/
					}
					else {
						String name = importedLibrary + "." + remainder;
						//boolean exists = this.checkTypeNameInFileList(compiler, name);
						//if (exists) {
							return Array.getArrayType(name, dimensionOfArray);
						//}
						//else return null;
					}
				}
			}
		//}
			
			String starClass = Fullname.getTypeOfImportStar(compiler, str);
			if (starClass!=null) {
				if (!isArray) {
					if (isTemplate) {
						if (template!=null) {
							if (remainder==null) template.typeName = starClass;
							else template.typeName = starClass+"."+remainder;
							template.typeNameToChange = typeNameToChange;
						}
						if (remainder==null) {
							return starClass+strTemplate;
							/*boolean exists = this.checkTypeNameInFileList(compiler, starClass);
							if (exists) {
								return starClass+strTemplate;
							}
							else return null;*/
						}
						else  {
							String name = starClass + "." + remainder;
							//boolean exists = this.checkTypeNameInFileList(compiler, name);
							//if (exists) {
								return name+strTemplate;
							//}
							//else return null;
						}
					}
					if (remainder==null) {
						return starClass;
						/*boolean exists = this.checkTypeNameInFileList(compiler, starClass);
						if (exists) {
							return starClass;
						}
						else return null;*/
					}
					else  {
						String name = starClass + "." + remainder;
						//boolean exists = this.checkTypeNameInFileList(compiler, name);
						//if (exists) {
							return name;
						//}
						//else return null;
					}
				}
				else {
					if (isTemplate) {
						if (template!=null) {
							if (remainder==null) template.typeName = starClass;
							else  template.typeName = starClass+"."+remainder;
							template.typeNameToChange = typeNameToChange;
						}
						if (remainder==null) {
							return Array.getArrayType(starClass+strTemplate, dimensionOfArray);
							/*boolean exists = this.checkTypeNameInFileList(compiler, starClass);
							if (exists) {
								return Array.getArrayType(starClass+strTemplate, dimensionOfArray);
							}
							else return null;*/
						}
						else {
							String name = starClass + "." + remainder;
							//boolean exists = this.checkTypeNameInFileList(compiler, name);
							//if (exists) {
								return Array.getArrayType(name+strTemplate, dimensionOfArray);
							//}
							//else return null;
						}
					}
					if (remainder==null) {
						return Array.getArrayType(starClass, dimensionOfArray);
						/*boolean exists = this.checkTypeNameInFileList(compiler, starClass);
						if (exists) {
							return Array.getArrayType(starClass, dimensionOfArray);
						}
						else return null;*/
					}
					else  {
						String name = starClass + "." + remainder;
						//boolean exists = this.checkTypeNameInFileList(compiler, name);
						//if (exists) {
							return Array.getArrayType(name, dimensionOfArray);
						//}
						//else return null;
					}
				}
			}
			
			FindClassParams classParams = Fullname.getTypeOfDefinedClass(compiler, str, indexOfHead);
			if (classParams!=null) {
				String fullname = classParams.name;
				if (!isArray) {
					if (isTemplate) { 
						if (template!=null) {
							if (remainder==null) template.typeName = fullname;
							else template.typeName = fullname+"."+remainder;
							template.typeNameToChange = typeNameToChange;
						}
						if (remainder==null) {
							return fullname+strTemplate;							
						}
						else  {
							String name = fullname + "." + remainder;
								return name+strTemplate;
						}
					}
					if (remainder==null) {
						return fullname;
					}
					else {
						String name = fullname + "." + remainder;
							return name;
					}
				}
				else {
					if (isTemplate) {
						if (template!=null) {
							if (remainder==null) template.typeName = fullname;
							else  template.typeName = fullname+"."+remainder;
							template.typeNameToChange = typeNameToChange;
						}
						if (remainder==null) {
							return Array.getArrayType(fullname+strTemplate, dimensionOfArray);							
						}
						else {
							String name = fullname + "." + remainder;
								return Array.getArrayType(name+strTemplate, dimensionOfArray);
						}
					}
					if (remainder==null) {
						return Array.getArrayType(fullname, dimensionOfArray);
					}
					else {
						String name = fullname + "." + remainder;
							return Array.getArrayType(name, dimensionOfArray);
					}
				}
			}
		
			if (Common_Settings.g_findsPackageLibrary) {
				String packageClass = Fullname.getTypeOfPackageLibrary(compiler, str);
				if (packageClass!=null) {
					if (!isArray) {
						if (isTemplate) {
							if (template!=null) {
								if (remainder==null) template.typeName = packageClass;
								else template.typeName = packageClass+"."+remainder;
								template.typeNameToChange = typeNameToChange;
							}
							if (remainder==null) {
								return packageClass+strTemplate;
							}
							else {
								String name = packageClass + "." + remainder;
									return name+strTemplate;
							}
						}
						if (remainder==null) {
							return packageClass;
						}
						else  {
							String name = packageClass + "." + remainder;
								return name;
						}
					}
					else {
						if (isTemplate) {
							if (template!=null) {
								if (remainder==null) template.typeName = packageClass;
								else  template.typeName = packageClass+"."+remainder;
								template.typeNameToChange = typeNameToChange;
							}
							if (remainder==null) {
								return Array.getArrayType(packageClass+strTemplate, dimensionOfArray);
							}
							else {
								String name = packageClass + "." + remainder;
									return Array.getArrayType(name+strTemplate, dimensionOfArray);
							}
						}
						if (remainder==null) {
							return Array.getArrayType(packageClass, dimensionOfArray);
						}
						else {
							String name = packageClass + "." + remainder;
								return Array.getArrayType(name, dimensionOfArray);
						}
					}
				}
			}// if (Common_Settings.g_findsPackageLibrary) {
		
		
				
		//if (str.contains(".")==false) {
			if (Fullname.IsTypeOfDefaultLibrary(compiler, str)) {
				if (!isArray) {
					if (isTemplate) {
						if (template!=null) {
							if (remainder==null) template.typeName = "java.lang."+str;
							else template.typeName = "java.lang."+str+"."+remainder;
							template.typeNameToChange = typeNameToChange;
						}
						if (remainder==null) {
							return "java.lang."+str+strTemplate;
							/*boolean exists = this.checkTypeNameInFileList(compiler, "java.lang."+str);
							if (exists) {
								return "java.lang."+str+strTemplate;
							}
							else return null;*/
						}
						else  {
							String name = "java.lang."+str + "." + remainder;
							//boolean exists = this.checkTypeNameInFileList(compiler, name);
							//if (exists) {
								return name+strTemplate;
							//}
							//else return null;
						}
					}
					if (remainder==null) {
						return "java.lang."+str;
						/*boolean exists = this.checkTypeNameInFileList(compiler, "java.lang."+str);
						if (exists) {
							return "java.lang."+str;
						}
						else return null;*/
					}
					else  {
						String name = "java.lang."+str + "." + remainder;
						//boolean exists = this.checkTypeNameInFileList(compiler, name);
						//if (exists) {
							return name;
						//}
						//else return null;
					}
				}
				else {
					if (isTemplate) {
						if (template!=null) {
							if (remainder==null) template.typeName = "java.lang."+str;
							else  template.typeName = "java.lang."+str+"."+remainder;
							template.typeNameToChange = typeNameToChange;
						}
						if (remainder==null) {
							return Array.getArrayType("java.lang."+str+strTemplate, dimensionOfArray);
							/*boolean exists = this.checkTypeNameInFileList(compiler, "java.lang."+str);
							if (exists) {
								return Array.getArrayType("java.lang."+str+strTemplate, dimensionOfArray);
							}
							else return null;*/
						}
						else  {
							String name = "java.lang."+str + "." + remainder;
							//boolean exists = this.checkTypeNameInFileList(compiler, name);
							//if (exists) {
								return Array.getArrayType(name+strTemplate, dimensionOfArray);
							//}
							//else return null;
						}
					}
					if (remainder==null) {
						return Array.getArrayType("java.lang."+str, dimensionOfArray);
						/*boolean exists = this.checkTypeNameInFileList(compiler, "java.lang."+str);
						if (exists) {
							return Array.getArrayType("java.lang."+str, dimensionOfArray);
						}
						else return null;*/
					}
					else {
						String name = "java.lang."+str + "." + remainder;
						//boolean exists = this.checkTypeNameInFileList(compiler, name);
						//if (exists) {
							return Array.getArrayType(name, dimensionOfArray);
						//}
						//else return null;
					}
				}
			}
		
		
		if (!isArray) {
			if (isTemplate) {
				if (template!=null) {
					if (remainder==null) template.typeName = str;
					else template.typeName = str+"."+remainder;
					template.typeNameToChange = typeNameToChange;
				}
				if (remainder==null) {
					return str+strTemplate;
					/*boolean exists = this.checkTypeNameInFileList(compiler, str);
					if (exists) {
						return str+strTemplate;
					}
					else return null;*/
				}
				else {
					String name = str + "." + remainder;
					//boolean exists = this.checkTypeNameInFileList(compiler, name);
					//if (exists) {
						return name+strTemplate;
					//}
					//else return null;
				}
			}
			if (remainder==null) {
				return str;
				/*boolean exists = this.checkTypeNameInFileList(compiler, str);
				if (exists) {
					return str;
				}
				else return null;*/
			}
			else {
				String name = str + "." + remainder;
				//boolean exists = this.checkTypeNameInFileList(compiler, name);
				//if (exists) {
					return name;
				//}
				//else return null;
			}
		}
		else {
			if (isTemplate) {
				if (template!=null) {
					if (remainder==null) template.typeName = str;
					else template.typeName = str+"."+remainder;
					template.typeNameToChange = typeNameToChange;
				}
				if (remainder==null) {
					return Array.getArrayType(str+strTemplate, dimensionOfArray);
					/*boolean exists = this.checkTypeNameInFileList(compiler, str);
					if (exists) {
						return Array.getArrayType(str+strTemplate, dimensionOfArray);
					}
					else return null;*/
				}
				else {
					String name = str + "." + remainder;
					//boolean exists = this.checkTypeNameInFileList(compiler, name);
					//if (exists) {
						return Array.getArrayType(name+strTemplate, dimensionOfArray);
					//}
					//else return null;
				}
			}
			if (remainder==null) {
				//boolean exists = this.checkTypeNameInFileList(compiler, str);
				//if (exists) {
					return Array.getArrayType(str, dimensionOfArray);
				//}
				//else return null;
			}
			else  {
				String name = str + "." + remainder;
				//boolean exists = this.checkTypeNameInFileList(compiler, name);
				//if (exists) {
					return Array.getArrayType(name, dimensionOfArray);
				//}
				//else return null;
			}
		}
		
		/*int indexOfDot = str.indexOf('.');
		if (indexOfDot!=-1) {
			// java.util.jar.JarFile
			// FindClassParams fullNameClass = CompilerHelper.loadClass(compiler, str);
			// if (fullNameClass!=null) {
			boolean exists = this.checkTypeNameInFileList(compiler, oldFullName);
			if (exists) {
				if (isArray==false) {
					if (isTemplate) {
						if (template!=null) {
							template.typeName = str;
							template.typeNameToChange = typeNameToChange;
						}
						return str+strTemplate;
					}
					return str;
				}
				else {
					if (isTemplate) {
						if (template!=null) {
							template.typeName = str;
							template.typeNameToChange = typeNameToChange;
						}
						return Array.getArrayType(str+strTemplate, dimensionOfArray);
					}
					return Array.getArrayType(str, dimensionOfArray);
				}
			}
		}*/
			
		
		//return null;
	}
	
	/** startIndex()부터 endIndex()까지 공백, 주석 등을 제외하여 각 스트링을 연결한 결과 스트링을 리턴한다.*/
	public static CodeString getFullName(HighArray_CodeString src, int startIndex, int endIndex) {
		int j;
		CodeString r = new CodeString("", Common_Settings.textColor);
		for (j=startIndex; j<=endIndex; j++) {
			CodeString item = src.getItem(j);
			if (CompilerHelper.IsBlank(item) || CompilerHelper.IsComment(item)) continue;
			else r = r.concate(item);
		}
		return r;
	}
	
	
	/** blank가 separator역할을 하면 -1을 리턴하고 
	 * 그렇지않고 "."과 함께 연결된 역할을 하면 "."의 인덱스를 리턴한다.
	 * fullName내에 "]"와 ")"같은 배열이나 함수호출이 올 수 있다.*/
	static int processBlankInGetFullNameIndex(Compiler compiler, boolean isReverse, int indexOfBlank, boolean includesTypeCast) {
		HighArray_CodeString src = compiler.data.mBuffer;
		int j = indexOfBlank;
		if (!isReverse) {
			int prevIndex = CompilerHelper.SkipBlank(src, true, 0, j);
			CodeString prev = src.getItem(prevIndex);
			if (CompilerHelper.IsIdentifier(prev, compiler) || prev.equals("]")  || prev.equals(")")) {
				int nextIndex = CompilerHelper.SkipBlank(src, false, j, src.count-1);
				CodeString next = src.getItem(nextIndex);
				if (next.equals(".")) {
					j = nextIndex;
					return j;
				}
				else if (includesTypeCast && prev.equals(")") && CompilerHelper.IsIdentifier(next, compiler)) {
					// 타입 캐스트이다. (타입)공백 id, j는 공백의 인덱스
					if (Fullname.isTypeCast(compiler, prevIndex, true)) {
						j = nextIndex;
					}
					else {
						return -1;
					}
				}
				else {//fullname의 끝
					return -1;
				}
			}
			else if (prev.equals(".")) {
				int nextIndex = CompilerHelper.SkipBlank(src, false, j, src.count-1);
				if (CompilerHelper.IsIdentifier(src.getItem(nextIndex), compiler)) {
					j = nextIndex;
					return j;
				}
				else {//fullname의 끝
					return -1;
				}
			}
		}//if (isReverse==false) {
		else {
			int nextIndex = CompilerHelper.SkipBlank(src, false, j, src.count-1);
			CodeString next = src.getItem(nextIndex);
			if (CompilerHelper.IsIdentifier(next, compiler)) {
				int prevIndex = CompilerHelper.SkipBlank(src, true, 0, j);
				CodeString prev = src.getItem(prevIndex); 
				if (prev.equals(".")) {
					j = prevIndex;
					return j;
				}
				else if (includesTypeCast && prev.equals(")")) {
					// 타입 캐스트이다. (타입)공백 id, j는 공백의 인덱스
					if (Fullname.isTypeCast(compiler, prevIndex, true)) {
						int leftPair = Checker.CheckParenthesis(compiler,  "(", ")", 0, prevIndex, true);
						if (leftPair==-1) j = 0;
						else j = leftPair;
						return j;
					}
					else {
						return -1;
					}
				}
				else { //fullname의 끝
					return -1;
				}
			}
			else if (next.equals(".")) {
				int prevIndex = CompilerHelper.SkipBlank(src, true, 0, j);
				CodeString prev = src.getItem(prevIndex);
				if (CompilerHelper.IsIdentifier(prev, compiler) || prev.equals("]") || prev.equals(")")) {
					j = prevIndex;
					return j;
				}
				else {//fullname의 끝
					return -1;
				}
			}
		}//if (isReverse) {
		return -1;
	}
	
	
	/** isReverse가 false일때는 index는 '('의 인덱스이고
	 * isReverse가 true일때는 index는 ')'의 인덱스이다.
	 * id()과 같은 함수호출임을 검증한다.*/
	public static boolean isFuncCall(Compiler compiler, int index, boolean isReverse) {
		if (index==18373) {
		}
		if (!isReverse) {
			
			// index는 (의 인덱스
			if (!compiler.data.mBuffer.getItem(index).equals("(")) return false;
			
			int idIndex = CompilerHelper.SkipBlank(compiler.data.mBuffer, true, 0, index-1);
			
			if (!CompilerHelper.IsIdentifier(compiler.data.mBuffer.getItem(idIndex), compiler)) {
				return false;
			}
			
			
			int rightPairIndex = Checker.CheckParenthesis(compiler,  "(", ")", index, compiler.data.mBuffer.count-1, false);
			CodeString rightPair = compiler.data.mBuffer.getItem(rightPairIndex);
			if (rightPair==null) {
				return false;
			}
			if (!rightPair.equals(")")) return false;
			
			return true;
		}
		else {
			
			// index는 )의 인덱스
			CodeString rightPair = compiler.data.mBuffer.getItem(index);
			if (!rightPair.equals(")")) return false;
			int leftPairIndex = Checker.CheckParenthesis(compiler, "(", ")", 0, index, true);
			int idIndex = CompilerHelper.SkipBlank(compiler.data.mBuffer, true, 0, leftPairIndex-1);
			
			if (CompilerHelper.IsIdentifier(compiler.data.mBuffer.getItem(idIndex), compiler)) {
				return true;
			}
			return false;
		}
	}
	
	
	/** isReverse가 false일때는 index는 '('의 인덱스이고
	 * isReverse가 true일때는 index는 ')'의 인덱스이다.
	 * (타입)과 같은 타입캐스트임을 검증한다.
	 * @param compiler
	 *  @param src : compiler.mBuffer일 수도 있고 compiler.mBuffer가 아닌 새로운 src일 수도 있으므로 주의해야 한다. postfix, FindIncrementParams
	 * @param index
	 * @param isReverse
	 * @return
	 */
	public static boolean isTypeCast_postfix(Compiler compiler, HighArray_CodeString src, int index, boolean isReverse) {
		if (index==751 || index==753) {
		}
		if (!isReverse) {
			int leftPairIndex = index;
			int rightPairIndex = Checker.CheckParenthesis_postfix(compiler, src, "(", ")", leftPairIndex, src.count-1, false);
			
			int keywordIndex = CompilerHelper.SkipBlank(src, true, 0, index-1);
			if (keywordIndex>=0) {
				CodeString keyword = src.getItem(keywordIndex);			
				// if (true) c=0;
				if (CompilerHelper.IsKeyword(keyword, compiler)) {
					// keyword의 예외, return, throw
					// return (T)arrItem.getItem(indexInArray);
					// return, throw가 아닌 keyword
					if (!keyword.equals("return") && !keyword.equals("throw")) {
						return false;
					}
				}
			}
			
			CodeString leftPair = src.getItem(index);
			if (!leftPair.equals("(")) return false;
			
			
			index = CompilerHelper.SkipBlank(src, false, index+1, src.count-1);
			// (a.b.c.d)에서 index는 a의 인덱스, rightPairIndex는 )의 인덱스, leftPairIndex는 (의 인덱스
			int typeEndIndex = Fullname.getFullNameIndex_OnlyType_postfix(compiler, src, false, index, true);
			if (typeEndIndex==-1) return false;
			typeEndIndex = CompilerHelper.SkipBlank(src, false, typeEndIndex+1, src.count-1);
			
			if (rightPairIndex!=typeEndIndex) return false;
			
			CodeString rightPair = src.getItem(typeEndIndex);
			
			if (rightPair.equals(")")) {
				return true;
			}
			return false;
		}
		else {
			int rightPairIndex = index;
			int leftPairIndex = Checker.CheckParenthesis(compiler,  "(", ")", 0, rightPairIndex, true);
			
			CodeString rightPair = src.getItem(index);
			if (!rightPair.equals(")")) return false;
			
			index = CompilerHelper.SkipBlank(src, true, 0, index-1);
			// (a.b.c.d)에서 index는 d의 인덱스, rightPairIndex는 )의 인덱스, leftPairIndex는 (의 인덱스
			int typeIndex = Fullname.getFullNameIndex_OnlyType_postfix(compiler, src, true, index, true);
			if (typeIndex==-1) return false;
			typeIndex = CompilerHelper.SkipBlank(src, true, 0, typeIndex-1);
			
			if (leftPairIndex!=typeIndex) return false;
			
			CodeString leftPair = src.getItem(typeIndex);
			
			if (leftPair.equals("(")) {				
				int keywordIndex = CompilerHelper.SkipBlank(src, true, 0, typeIndex-1);
				if (keywordIndex>=0) {
					CodeString keyword = src.getItem(keywordIndex);				
					// if (true) c=0;
					if (CompilerHelper.IsKeyword(keyword, compiler)) {
						// keyword의 예외, return, throw
						// return (T)arrItem.getItem(indexInArray);
						if (!keyword.equals("return") && !keyword.equals("throw")) {
							return false;
						}
					}
				}
				
				return true;
			}
			return false;
		}
	}
	
	
	/** isReverse가 false일때는 index는 '('의 인덱스이고
	 * isReverse가 true일때는 index는 ')'의 인덱스이다.
	 * (타입)과 같은 타입캐스트임을 검증한다.
	 * @param compiler
	 * @param index
	 * @param isReverse
	 * @return
	 */
	public static boolean isTypeCast(Compiler compiler, int index, boolean isReverse) {
		return isTypeCast_postfix(compiler, compiler.data.mBuffer, index, isReverse);
	}
	
	
	/** blank가 separator역할을 하면 -1을 리턴하고 
	 * 그렇지않고 "."과 함께 연결된 역할을 하면 "."의 인덱스를 리턴한다.
	 * fullName내에 "]"와 ")"같은 배열이나 함수호출이 올 수 없다.*/
	static int processBlankInGetFullNameIndex_OnlyType(Compiler compiler, boolean isReverse, int indexOfBlank) {
		HighArray_CodeString src = compiler.data.mBuffer;
		int j = indexOfBlank;
		if (!isReverse) {
			int prevIndex = CompilerHelper.SkipBlank(src, true, 0, j);
			CodeString prev = src.getItem(prevIndex);
			if (CompilerHelper.IsIdentifier(prev, compiler)) {
				int nextIndex = CompilerHelper.SkipBlank(src, false, j, src.count-1);
				if (src.getItem(nextIndex).equals(".")) {
					j = nextIndex;
					return j;
				}
				else {//fullname의 끝
					return -1;
				}
			}
			else if (prev.equals(".")) {
				int nextIndex = CompilerHelper.SkipBlank(src, false, j, src.count-1);
				if (CompilerHelper.IsIdentifier(src.getItem(nextIndex), compiler)) {
					j = nextIndex;
					return j;
				}
				else {//fullname의 끝
					return -1;
				}
			}
			else {
				// "]", ")"와 같은 배열이나 함수호출이 오면 리턴
				return -1;
			}
		}//if (isReverse==false) {
		else {
			int nextIndex = CompilerHelper.SkipBlank(src, false, j, src.count-1);
			CodeString next = src.getItem(nextIndex);
			if (CompilerHelper.IsIdentifier(next, compiler)) {
				int prevIndex = CompilerHelper.SkipBlank(src, true, 0, j);
				if (src.getItem(prevIndex).equals(".")) {
					j = prevIndex;
					return j;
				}
				else { //fullname의 끝
					return -1;
				}
			}
			else if (next.equals(".")) {
				int prevIndex = CompilerHelper.SkipBlank(src, true, 0, j);
				CodeString prev = src.getItem(prevIndex);
				if (CompilerHelper.IsIdentifier(prev, compiler)) {
					j = prevIndex;
					return j;
				}
				else {//fullname의 끝, "]", ")"와 같은 배열이나 함수호출이 오면 리턴
					return -1;
				}
			}
		}//if (isReverse) {
		return -1;
	}
	
	/**isReverser가 false일때는 []에서 ]의 인덱스를 리턴하고, [].a에서 .의 인덱스를 리턴한다.
	 * isReverser가 true일때는 startIndex가 ]일때 a[]에서 a의 인덱스를 리턴하고, a.b[]에서 .의 인덱스를 리턴한다.
	 * @param src : compiler.mBuffer일 수도 있고 compiler.mBuffer가 아닌 새로운 src일 수도 있으므로 주의해야 한다.*/
	static int hasAND_sub(Compiler compiler,  boolean isReverse, int startIndex) {
		
		return hasAND_sub_postfix(compiler, compiler.data.mBuffer, isReverse, startIndex);
	}
	
	/**isReverser가 false일때는 []에서 ]의 인덱스를 리턴하고, [].a에서 .의 인덱스를 리턴한다.
	 * isReverser가 true일때는 startIndex가 ]일때 a[]에서 a의 인덱스를 리턴하고, a.b[]에서 .의 인덱스를 리턴한다.
	 *  @param src : compiler.mBuffer일 수도 있고 compiler.mBuffer가 아닌 새로운 src일 수도 있으므로 주의해야 한다. postfix, FindIncrementParams*/
	static int hasAND_sub_postfix(Compiler compiler, HighArray_CodeString src, boolean isReverse, int startIndex) {
		try {
			if (!isReverse) {
				CodeString next = src.getItem(startIndex);
				int indexNext = startIndex;
				int rightPair;
				while (true) {
					if (next.equals("[")) {
						rightPair = Checker.CheckParenthesis_postfix(compiler, src, "[", "]", indexNext, src.count-1, false);
						if (rightPair==-1) {
							int indexPrev = CompilerHelper.SkipBlank(src, true, 0, indexNext-1);
							return indexPrev;
						}
						indexNext = CompilerHelper.SkipBlank(src, false, rightPair+1, src.count-1);
						if (indexNext==src.count) {
							int indexPrev = CompilerHelper.SkipBlank(src, true, 0, indexNext-1);
							return indexPrev;
						}
						next = src.getItem(indexNext);
					}
					else if (next.equals(".")) return indexNext;
					else {						
						int indexPrev = CompilerHelper.SkipBlank(src, true, 0, indexNext-1);
						return indexPrev;
					}
				}
			}
			else {
				CodeString prev = src.getItem(startIndex);
				int indexPrev = startIndex;
				int leftPair;
				while (true) {
					if (prev.equals("]")) {
						leftPair = Checker.CheckParenthesis_postfix(compiler, src, "[", "]", 0, indexPrev, true);
						if (leftPair==-1) {
							int indexNext = CompilerHelper.SkipBlank(src, false, indexPrev+1, src.count-1);
							return indexNext;
						}
						indexPrev = CompilerHelper.SkipBlank(src, true, 0, leftPair-1);
						prev = src.getItem(indexPrev);
						if (CompilerHelper.IsIdentifier(prev, compiler)) {
							indexPrev = CompilerHelper.SkipBlank(src, true, 0, indexPrev-1);
							prev = src.getItem(indexPrev);
						}
					}
					else if (prev.equals(".")) return indexPrev;
					else {
						int indexNext = CompilerHelper.SkipBlank(src, false, indexPrev+1, src.count-1);
						return indexNext;
					}
				}
			}
		}
		catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
			System.out.println("filename:"+compiler.data.filename+" startIndex:"+startIndex+" isReverse:"+isReverse);
			return -1;
		}
	}
	
	
	/** a()[].b, a.b, a().b, a[].b 에서 a일때 '.'의 인덱스를 리턴한다. <br>
	 * '.'이 없으면 returnsIDIndex에 따라 returnsIDIndex이 false이면 
	 * 토큰의 가장 끝 인덱스(토큰의 가장 끝 인덱스(
	 * if (isReverse==false) 공백이 구분자일때는 공백-SkipBlank(), 구분자의 인덱스-SkipBlank()
	 * if (isReverse==true) 공백이 구분자일때는 공백+SkipBlank(), 구분자의 인덱스+SkipBlank())를 리턴한다.
	 * a()[], a, a(), a[] 에서 ], a, ), ]의 인덱스를 리턴한다.
	 * true이면 a()[], a, a(), a[] 에서 a, a, a, a의 인덱스를 리턴한다.<br>
	 * isReverse가 true일때는 returnsIDIndex는 true가 기본이다.
	 *  @param src : compiler.mBuffer일 수도 있고 compiler.mBuffer가 아닌 새로운 src일 수도 있으므로 주의해야 한다. postfix, FindIncrementParams*/
	public static int hasAND_postfix(Compiler compiler, HighArray_CodeString src, boolean isReverse, int startIndex, boolean returnsIDIndex) {
		try {
			if (!isReverse) {
				CodeString startStr = src.getItem(startIndex);
				if (CompilerHelper.IsIdentifier(startStr, compiler)) {
					int indexNext = CompilerHelper.SkipBlank(src, false, startIndex+1, src.count-1);
					if (indexNext==src.count) { 
						// Postfix의 src의 끝부분에서, Expression.getTypeOfVarUseOrFuncCall()을 참조한다.
						int indexPrev = CompilerHelper.SkipBlank(src, true, 0, indexNext-1);
						return indexPrev;
					}
					CodeString next = src.getItem(indexNext);
					if (next.equals(".")) return indexNext;
					else if (next.equals("(")) {
						int rightPair = Checker.CheckParenthesis_postfix(compiler, src, "(", ")", indexNext, src.count-1, false);
						if (rightPair==-1) {
							int indexPrev = CompilerHelper.SkipBlank(src, true, 0, indexNext-1);
							return indexPrev;
						}
						indexNext = CompilerHelper.SkipBlank(src, false, rightPair+1, src.count-1);
						if (indexNext==src.count) {
							// Postfix의 src의 끝부분에서, Expression.getTypeOfVarUseOrFuncCall()을 참조한다.
							int indexPrev = CompilerHelper.SkipBlank(src, true, 0, indexNext-1);
							return indexPrev;
						}
						next = src.getItem(indexNext);
						
						int r = hasAND_sub_postfix(compiler, src, isReverse, indexNext);						
						if (src.getItem(r).equals(".")) {
							return r;
						}
						else {
							if (returnsIDIndex) {
								return startIndex;
							}
							else {
								return r;
							}
						}
					}
					else if (next.equals("[")) {
						int r = hasAND_sub_postfix(compiler, src, isReverse, indexNext);						
						if (src.getItem(r).equals(".")) {
							return r;
						}
						else {
							if (returnsIDIndex) {
								return startIndex;
							}
							else {
								return r;
							}
						}
					}
				}// if (CompilerHelper.IsIdentifier(startStr, compiler)) {
				else if (startStr.equals("(")) {
					// (new RectForPage(owner, bounds, Common_Settings.backColor, isUpOrDown)).a
					int rightPair = Checker.CheckParenthesis_postfix(compiler, src, "(", ")", startIndex, src.count-1, false);
					if (rightPair==-1) {
						int indexPrev = CompilerHelper.SkipBlank(src, true, 0, startIndex-1);
						return indexPrev;
					}
					int indexNext = CompilerHelper.SkipBlank(src, false, rightPair+1, src.count-1);
					if (indexNext==src.count) {
						// Postfix의 src의 끝부분에서, Expression.getTypeOfVarUseOrFuncCall()을 참조한다.
						int indexPrev = CompilerHelper.SkipBlank(src, true, 0, indexNext-1);
						return indexPrev;
					}
					
					if (Fullname.isTypeCast_postfix(compiler, src, startIndex, isReverse)) {						
						if (!(src.getItem(indexNext).equals("-") || src.getItem(indexNext).equals("+"))) {
							// (java.lang.Object)builder.append("abc")
							indexNext = Fullname.getFullNameIndex_postfix(compiler, src, isReverse, indexNext, returnsIDIndex);
						}
						else {
							// (java.lang.Object)-a
							indexNext = CompilerHelper.SkipBlank(src, false, indexNext+1, src.count-1);
							if (indexNext==src.count) {
								// Postfix의 src의 끝부분에서, Expression.getTypeOfVarUseOrFuncCall()을 참조한다.
								int indexPrev = CompilerHelper.SkipBlank(src, true, 0, indexNext-1);
								return indexPrev;
							}
							indexNext = Fullname.getFullNameIndex_postfix(compiler, src, isReverse, indexNext, returnsIDIndex);
						}
						return indexNext;
					}
					int r = hasAND_sub_postfix(compiler, src, isReverse, indexNext);
					if (src.getItem(r).equals(".")) {
						return r;
					}
					else {
						if (returnsIDIndex) {
							return startIndex;
						}
						else {
							return r;
						}
					}
				}//else if (startStr.equals("(")) {
			}// if (isReverse==false) {
			else {
				CodeString start = src.getItem(startIndex);
				
				if (start.equals("]")) {
					int indexPrev = startIndex;
					int r = hasAND_sub_postfix(compiler, src, isReverse, indexPrev);
					if (src.getItem(r).equals(".")) {
						return r;
					}
					else {
						if (returnsIDIndex) {
							return r;
						}
						else {
							return startIndex;
						}
					}
				}
				else if (start.equals(")")) {
				
					int indexPrev = startIndex;
					CodeString prev = src.getItem(indexPrev);
					int leftPair = Checker.CheckParenthesis_postfix(compiler, src, "(", ")", 0, indexPrev, true);
					if (leftPair==-1) {
						int indexNext = CompilerHelper.SkipBlank(src, false, indexPrev+1, src.count-1);						
						return indexNext;
					}
					indexPrev = CompilerHelper.SkipBlank(src, true, 0, leftPair-1);
					prev = src.getItem(indexPrev);
					
					if (CompilerHelper.IsIdentifier(prev, compiler)) {
						indexPrev = CompilerHelper.SkipBlank(src, true, 0, indexPrev-1);
						prev = src.getItem(indexPrev);
					}
					int r = hasAND_sub_postfix(compiler, src, isReverse, indexPrev);
					if (src.getItem(r).equals(".")) {
						return r;
					}
					else {
						if (returnsIDIndex) {
							return r;
						}
						else {
							return startIndex;
						}
					}
				}//else if (start.equals(")")) {
				else if (CompilerHelper.IsIdentifier(start, compiler)) {
					int indexPrev = startIndex;
					indexPrev = CompilerHelper.SkipBlank(src, true, 0, indexPrev-1);
					CodeString prev = src.getItem(indexPrev);
					if (prev!=null) {
						if (prev.equals(".")) return indexPrev;
						else {		
							if (prev.equals(")")) {
								if (Fullname.isTypeCast_postfix(compiler, compiler.data.mBuffer, indexPrev, isReverse)) {
									// (T)id
									int leftPair = Checker.CheckParenthesis_postfix(compiler, src, "(", ")", 0, indexPrev, true);
									indexPrev = CompilerHelper.SkipBlank(src, true, 0, leftPair-1);
									prev = src.getItem(indexPrev);
									// a.(T)id 에서 .의 인덱스를 리턴
									if (prev.equals(".")) return indexPrev;
									// return (T)id에서 indexPrev는 return을 가리킨다.
								}
							}//if (prev.equals(")")) {
							else if (prev.equals("-") || prev.equals("+")) {
								int indexPrev2 = CompilerHelper.SkipBlank(src, true, 0, indexPrev-1);
								if (compiler.data.mBuffer.getItem(indexPrev2).equals(")") && 
										Fullname.isTypeCast_postfix(compiler, compiler.data.mBuffer, indexPrev2, isReverse)) {
									// (T)-id
									int leftPair = Checker.CheckParenthesis_postfix(compiler, src, "(", ")", 0, indexPrev2, true);									
									indexPrev = CompilerHelper.SkipBlank(src, true, 0, leftPair-1);
									prev = src.getItem(indexPrev);
									// a.(T)id 에서 .의 인덱스를 리턴
									if (prev.equals(".")) return indexPrev;
									// return (T)id에서 indexPrev는 return을 가리킨다.
								}
							}//else if (prev.equals("-") || prev.equals("+")) {
							int indexNext = CompilerHelper.SkipBlank(src, false, indexPrev+1, src.count-1);						
							return indexNext;
						}
					}
				}
			}
	
			return startIndex;
		}
		catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
			System.out.println("filename:"+compiler.data.filename+" startIndex:"+startIndex+" isReverse:"+isReverse);
			return -1;
		}
	}
	
	
	/** a()[].b, a.b, a().b, a[].b 에서 a일때 '.'의 인덱스를 리턴한다. 
	 * '.'이 없으면 토큰의 가장 끝 인덱스(
	 * if (isReverse==false) 공백이 구분자일때는 공백-SkipBlank(), 구분자의 인덱스-SkipBlank()
	 * if (isReverse==true) 공백이 구분자일때는 공백+SkipBlank(), 구분자의 인덱스+SkipBlank())를 리턴한다.
	 * a()[], a, a(), a[] 에서 ], a, ), ]의 인덱스를 리턴한다.*/
	public static int hasAND(Compiler compiler, boolean isReverse, int startIndex, boolean returnsIDIndex) {
		HighArray_CodeString src = compiler.data.mBuffer;
		return hasAND_postfix(compiler, src, isReverse, startIndex, returnsIDIndex);
	}
	
	/**CompilerStack.IsType()에서 Array.isArrayType()을 따로 호출하기 때문에 []은 없다.
	 * @param src : compiler.mBuffer일 수도 있고 compiler.mBuffer가 아닌 새로운 src일 수도 있으므로 주의해야 한다.*/
	public static int hasAND_OnlyType(Compiler compiler, 
			boolean isReverse, int startIndex, boolean includesTemplate) {
		return hasAND_OnlyType_postfix(compiler, compiler.data.mBuffer, isReverse, startIndex, includesTemplate);
	}
	
	/**CompilerStack.IsType()에서 Array.isArrayType()을 따로 호출하기 때문에 []은 없다.
	 *  @param src : compiler.mBuffer일 수도 있고 compiler.mBuffer가 아닌 새로운 src일 수도 있으므로 주의해야 한다. postfix, FindIncrementParams*/
	public static int hasAND_OnlyType_postfix(Compiler compiler, HighArray_CodeString src, 
			boolean isReverse, int startIndex, boolean includesTemplate) {
		try {
			if (!isReverse) {
				CodeString startStr = src.getItem(startIndex);
				if (CompilerHelper.IsIdentifier(startStr, compiler) || CompilerHelper.IsDefaultType(startStr, compiler)) {
					int indexNext = CompilerHelper.SkipBlank(src, false, startIndex+1, src.count-1);
					if (indexNext==src.count) { 
						// Postfix의 src의 끝부분에서, Expression.getTypeOfVarUseOrFuncCall()을 참조한다.
						int indexPrev = CompilerHelper.SkipBlank(src, true, 0, indexNext-1);
						return indexPrev;
					}
					CodeString next = src.getItem(indexNext);
					if (next.equals(".")) return indexNext;
					else if (next.equals("<")) {
						if (includesTemplate) {
							int rightPair = Checker.CheckParenthesis_postfix(compiler, src, "<", ">", indexNext, src.count-1, false);					
							if (rightPair!=-1) {
								Template t = TemplateBase.isTemplate(compiler,  rightPair);
								if (t==null) { 
									return startIndex;// id의 인덱스
								}
							}
							else {
								return startIndex;// id의 인덱스
							}
							// 템플릿일 경우
							indexNext = CompilerHelper.SkipBlank(src, false, rightPair+1, src.count-1);
							next = src.getItem(indexNext);
							return rightPair;
						}
						else {
							return startIndex;
						}
					}
					else {
						return startIndex;
					}			
				}// if (CompilerHelper.IsIdentifier(startStr, compiler)) {
				else {
					return startIndex;
				}
			}// if (isReverse==false) {
			else {
				CodeString start = src.getItem(startIndex);
				if (CompilerHelper.IsIdentifier(start, compiler) || CompilerHelper.IsDefaultType(start, compiler)) {
					int indexPrev = startIndex;
					if (startIndex==0) return startIndex;
					indexPrev = CompilerHelper.SkipBlank(src, true, 0, indexPrev-1);
					CodeString prev = src.getItem(indexPrev);
				
					if (prev.equals(".")) return indexPrev;
					else {						
						int indexNext = CompilerHelper.SkipBlank(src, false, indexPrev+1, src.count-1);						
						return indexNext;
					}
				}
				else if (start.equals(">")) {
					if (includesTemplate) {
						int leftPair = Checker.CheckParenthesis_postfix(compiler, src, "<", ">", 0, startIndex, true);
						if (leftPair!=-1) {
							Template t = TemplateBase.isTemplate(compiler,  startIndex);
							if (t==null) {
								int indexNext = CompilerHelper.SkipBlank(src, false, startIndex+1, src.count-1);						
								return indexNext;
							}
						}
						else {
							int indexNext = CompilerHelper.SkipBlank(src, false, startIndex+1, src.count-1);						
							return indexNext;
						}
						// 템플릿일 경우
						int indexPrev = CompilerHelper.SkipBlank(src, true, 0, leftPair-1);
						CodeString prev = src.getItem(indexPrev);
						if (CompilerHelper.IsIdentifier(prev, compiler)) {
							indexPrev = CompilerHelper.SkipBlank(src, true, 0, indexPrev-1);
							prev = src.getItem(indexPrev);
							if (prev.equals(".")) return indexPrev;
							else {						
								int indexNext = CompilerHelper.SkipBlank(src, false, indexPrev+1, src.count-1);						
								return indexNext;
							}
						}
					}
					else {
						int indexNext = CompilerHelper.SkipBlank(src, false, startIndex+1, src.count-1);						
						return indexNext;
					}
				}// else if (start.equals(">")) {
				else {
					// ']' 등
					//return -1;
					int indexNext = CompilerHelper.SkipBlank(src, false, startIndex+1, src.count-1);						
					return indexNext;
				}
			}
			return startIndex;
		}
		catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
			System.out.println("filename:"+compiler.data.filename+" startIndex:"+startIndex+" isReverse:"+isReverse);
			return -1;
		}
	}
	
	 
	/** a()[].b, a.b, a().b, a[].b 에서 a일때 '.'의 인덱스를 리턴한다. <br>
	 * '.'이 없으면 returnsIDIndex에 따라 returnsIDIndex이 false이면 
	 * 토큰의 가장 끝 인덱스(
	 * if (isReverse==false) 공백이 구분자일때는 공백-SkipBlank(), 구분자의 인덱스-SkipBlank()
	 * if (isReverse==true) 공백이 구분자일때는 공백+SkipBlank(), 구분자의 인덱스+SkipBlank())를 리턴한다.
	 * a()[], a, a(), a[] 에서 ], a, ), ]의 인덱스를 리턴한다.
	 * true이면 a()[], a, a(), a[] 에서 a, a, a, a의 인덱스를 리턴한다.<br>
	 * isReverse가 true일때는 returnsIDIndex는 true가 기본이다.
	 *  @param src : compiler.mBuffer일 수도 있고 compiler.mBuffer가 아닌 새로운 src일 수도 있으므로 주의해야 한다. postfix, FindIncrementParams*/
	public static int getFullNameIndex_postfix(Compiler compiler, HighArray_CodeString src, boolean isReverse, int startIndex, boolean returnsIDIndex) {
		int i;		
		if (!isReverse) {
			for (i=startIndex; i<src.count; ) {
				int indexAND = hasAND_postfix(compiler, src, isReverse, i, returnsIDIndex);
				//if (indexAND==-1) return i+1;
				//if (indexAND==src.count) return indexAND;
				CodeString next = src.getItem(indexAND);
				
				if (next.equals(".")) {
					i = CompilerHelper.SkipBlank(src, false, indexAND+1, src.count-1);
					// 다음 토큰으로 이어진다.
				}
				else {
					if (returnsIDIndex) {
						// a(), b.a[], b.a()[] 에서 a의 인덱스, Expression.getTypeOfVarUseOrFuncCallOfFullName()에서 호출
						return i;
					}
					else {
						// 구분자-1, 공백-1, a(), a[], a()[] 에서 ), ], ]의 인덱스
						return indexAND;
					}
				}
			}
		}// if (isReverse==false) {
		else {
			// isReverse가 true일때는 returnsIDIndex는 true가 기본이다.
			returnsIDIndex = true;
			for (i=startIndex; i>=0; ) {
				int indexAND = hasAND_postfix(compiler, src, isReverse, i, returnsIDIndex);
				//if (indexAND==-1) return i-1;
				CodeString prev = src.getItem(indexAND);
				if (prev.equals(".")) {
					i = CompilerHelper.SkipBlank(src, true, 0, indexAND-1);
					// 이전 토큰으로 이어진다.
				}
				else {
					if (returnsIDIndex) {
						// 구분자+1, 공백+1, a(), a[], a()[] 에서 a의 인덱스	, 					
						return indexAND;						
					}
					else {
						// a(), a[], a()[] 에서 ), ], ]의 인덱스
						return i;
					}
				}
			}
		}
		return startIndex;
	}
	
	public static int getFullNameIndex(Compiler compiler, boolean isReverse, int startIndex, boolean returnsIDIndex) {
		HighArray_CodeString src = compiler.data.mBuffer;
		return getFullNameIndex_postfix(compiler, src, isReverse, startIndex, returnsIDIndex);
	}
	
	/**a.b[].c().d와 같은 것 뿐만 아니라 A.B.C.D<template>과 같은 타입도 가능하다. 
	 * @param src : compiler.mBuffer일 수도 있고 compiler.mBuffer가 아닌 새로운 src일 수도 있으므로 주의해야 한다.*/
	public static int getFullNameIndex_includingType(Compiler compiler,  boolean isReverse, int startIndex) {
		
		return getFullNameIndex_includingType_postfix(compiler, compiler.data.mBuffer, isReverse, startIndex);
	}
	
	/**a.b[].c().d와 같은 것 뿐만 아니라 A.B.C.D<template>과 같은 타입도 가능하다. 
	 * @param src : compiler.mBuffer일 수도 있고 compiler.mBuffer가 아닌 새로운 src일 수도 있으므로 주의해야 한다. postfix, FindIncrementParams*/
	public static int getFullNameIndex_includingType_postfix(Compiler compiler, HighArray_CodeString src, boolean isReverse, int startIndex) {
		
		if (!isReverse) {
			int index = Fullname.getFullNameIndex_postfix(compiler, src, isReverse, startIndex, false);
			int indexNext = CompilerHelper.SkipBlank(src, false, index+1, src.count-1);
			if (indexNext>=src.count) {
				return index;
			}
			CodeString next = src.getItem(indexNext);
			if (next.equals("<")) {
				int rightPair = Checker.CheckParenthesis_postfix(compiler, src, "<", ">", indexNext, src.count-1, false);					
				if (rightPair!=-1) {
					Template t = TemplateBase.isTemplate(compiler,  rightPair);
					if (t==null) { 
						return index;
					}
				}
				else {
					return index;
				}
				// 템플릿일 경우
				indexNext = CompilerHelper.SkipBlank(src, false, rightPair+1, src.count-1);
				if (indexNext==src.count) {
					return rightPair;
				}
				next = src.getItem(indexNext);
				return rightPair;
			}
			else {
				return index;
			}
		}
		else {
			CodeString start = src.getItem(startIndex);
			if (start.equals(">")) {
				int leftPair = Checker.CheckParenthesis_postfix(compiler, src, "<", ">", 0, startIndex, true);
				if (leftPair!=-1) {
					Template t = TemplateBase.isTemplate(compiler,  startIndex);
					if (t==null) {
						int indexNext = CompilerHelper.SkipBlank(src, false, startIndex+1, src.count-1);
						return indexNext;
					}
				}
				else {
					int indexNext = CompilerHelper.SkipBlank(src, false, startIndex+1, src.count-1);						
					return indexNext;
				}
				// 템플릿일 경우
				int indexPrev = CompilerHelper.SkipBlank(src, true, 0, leftPair-1);
				return Fullname.getFullNameIndex_postfix(compiler, src, isReverse, indexPrev, false);
			}// else if (start.equals(">")) {
			else {
				return Fullname.getFullNameIndex_postfix(compiler, src, isReverse, startIndex, false);
			}
		}
	}
	
	/** a[0].b에서 isReverse가 true이고 startIndex가 b를 가리킬때 무한루프가 발생하므로 이때는 -1을 리턴한다.
	 * CompilerStack.IsType()에서 Array.isArrayType()을 따로 호출하기 때문에 []은 없다.
	 * @param src : compiler.mBuffer일 수도 있고 compiler.mBuffer가 아닌 새로운 src일 수도 있으므로 주의해야 한다.*/
	public static int getFullNameIndex_OnlyType(Compiler compiler, boolean isReverse, int startIndex, boolean includesTemplate) {
		return getFullNameIndex_OnlyType_postfix(compiler, compiler.data.mBuffer, isReverse, startIndex, includesTemplate);
	}
	
	/** a[0].b에서 isReverse가 true이고 startIndex가 b를 가리킬때 무한루프가 발생하므로 이때는 -1을 리턴한다.
	 * CompilerStack.IsType()에서 Array.isArrayType()을 따로 호출하기 때문에 []은 없다.
	 * @param src : compiler.mBuffer일 수도 있고 compiler.mBuffer가 아닌 새로운 src일 수도 있으므로 주의해야 한다.*/
	public static int getFullNameIndex_OnlyType_postfix(Compiler compiler, HighArray_CodeString src, boolean isReverse, 
			int startIndex, boolean includesTemplate) {
		int i;
		
		if (!isReverse) {
			for (i=startIndex; i<src.count; ) {
				int indexAND = hasAND_OnlyType_postfix(compiler, src, isReverse, i, includesTemplate);
				CodeString next = src.getItem(indexAND);
				if (next.equals(".")) {	
					int oldI = i;
					i = CompilerHelper.SkipBlank(src, false, indexAND+1, src.count-1);
					if (i==oldI) { // 무한루프
						return -1;
					}
					// 다음 토큰으로 이어진다.
				}
				else {
					return indexAND;
				}
			}
		}// if (isReverse==false) {
		else {
			for (i=startIndex; i>=0; ) {
				int indexAND = hasAND_OnlyType_postfix(compiler, src, isReverse, i, includesTemplate);
				if (indexAND==-1) return -1;
				CodeString prev = src.getItem(indexAND);
				if (prev.equals(".")) {
					int oldI = i;
					i = CompilerHelper.SkipBlank(src, true, 0, indexAND-1);
					if (i==oldI) { // 무한루프
						return -1;
					}
					// 이전 토큰으로 이어진다.
				}
				else {
					return indexAND;
				}
			}
		}
		return startIndex;
	}
	
	
		
	
	
	
	
	static String convertFullNameToString(ArrayListCodeString fullName) {
		int i;
		CodeString r = new CodeString("", Common_Settings.textColor);
		for (i=0; i<fullName.count; i++) {
			CodeString cs = fullName.getItem(i);
			r = r.concate(cs);
		}
		return r.str;
	}
	
	
	/** 클래스캐시를 확인하고 없으면 클래스 파일리스트를 검색해서 정확한 fullname인지를 확인한다.
	 * 정확한 fullname이면 true를 리턴하고 그렇지 않으면 false를 리턴한다. 
	 * 소스 파일 리스트에서도 확인한다. 파일리스트에 없으면 실제로 로드를 해본다(로드를 안해볼수도 있으므로 주의한다).*/
	public static boolean checkTypeNameInFileList(Compiler compiler, String fullname, int coreThreadID) {
		if (fullname==null) return false;
		
		if (fullname.equals("Compiler_types.Language")) {
		}
		
		// 배열과 템플릿을 제외한 풀 이름
		fullname = Array.getArrayElementType(fullname);
		fullname = TemplateBase.getTemplateOriginalType(fullname);
		
		if (fullname==null) return false;
		
		if (CompilerHelper.IsDefaultType(fullname, compiler)) return true;
		
		// 클래스 캐시를 확인한다.
		FindClassParams classParamsCashed = 
				ClassCache.getFindClassParams(CompilerStatic.mlistOfAllClassesHashed[coreThreadID], fullname);
		if (classParamsCashed!=null) return true;
		
		String slashedFullname = fullname.replace('.', File.separatorChar);
		
		
		
		int k;
		int[] arrMode = {0, 1, 2, 3};
		for (k=0; k<arrMode.length; k++) {			
			//String classPath = null;
			File file = CompilerStatic.getAbsPath_FromVariousClassPath(arrMode[k], slashedFullname);
			if (file==null) continue;
			return true;
			/*classPath = file.getAbsolutePath();
			
			String fixedClassPath = Loader.fixClassPath(classPath);
			if (fixedClassPath!=null) {
				return true;
			}*/
		}
		
		// 소스파일에서 로드를 시도한다.
		/*FindClassParams classParams = Loader.loadClassFromSrc_onlyInterface(fullname);
		if (classParams!=null) {
			return true;
		}
		return false;*/
		
		
		return false;
		
	}
	
	
	/** 같은 파일에 정의된 클래스의 이름이 확실하게 fullname으로 정해진 이후에 호출되어야 한다. 
     * FindAllClassesAndItsMembers2_sub()을 호출한 이후 클래스 이름을 fullname으로 정하고 클래스 캐시에 등록한 이후를 말한다.
     * (FindAllClassesAndItsMembers2()와 start_onlyInterface()함수를 참조한다.)
     * short이름일 경우 mlistOfAllDefinedClass에 중복된 클래스를 검색하면 null을 리턴한다. 
     * 예를들어 com.gsoft.common.EditText.UndoBuffer.Pair와 com.gsoft.common.EditText.RedoBuffer.Pair가 중복되고
     * c가 Pair이면 null을 리턴한다.*/
    public static  FindClassParams getTypeOfDefinedClass(Compiler compiler, String c) {
    	if (c.equals("Pair")) {
    	}
    	ArrayListIReset mlistOfAllDefinedClasses = compiler.data.mlistOfAllDefinedClasses;
    	if (!c.contains(".")) {
	    	int i;
	    	if (mlistOfAllDefinedClasses==null) return null;
	    	ArrayListInt listOfIndices = new ArrayListInt(2);
	    	for (i=0; i<mlistOfAllDefinedClasses.count; i++) {
	    		FindClassParams classP = (FindClassParams) mlistOfAllDefinedClasses.getItem(i);
	    		if (classP.name==null) continue;
	    		String name = CompilerStatic.getShortName(classP.name);
	    		if (name.equals(c)) {
	    			//if (classP.startIndex()<indexOfSrc && indexOfSrc<classP.endIndex()) {
	    				listOfIndices.add(i);
	    			//}
	    		}
	    	}
	    	if (listOfIndices.count==1) {
	    		return (FindClassParams) mlistOfAllDefinedClasses.getItem(listOfIndices.getItem(0));
	    	}
	    	else if (listOfIndices.count>1) { // 이름이 같은 클래스들이 여러개 있는 경우
	    		return null;
	    	}//else if (listOfIndices.count>1) { // 이름이 같은 클래스들이 여러개 있는 경우
	    	else {
	    		return null;
	    	}
	    	
    	}
    	else {
    		int i;
    		if (mlistOfAllDefinedClasses==null) return null;
	    	for (i=0; i<mlistOfAllDefinedClasses.count; i++) {
	    		FindClassParams classP = (FindClassParams) mlistOfAllDefinedClasses.getItem(i);
	    		if (classP.name==null) continue;
	    		String name = classP.name;
	    		if (name.equals(c)) return classP;
	    	}
	    	return null;
    		
    	}
    }
    
    /** 같은 파일에 정의된 클래스의 이름이 확실하게 fullname으로 정해진 이후에 호출되어야 한다. 
     * FindAllClassesAndItsMembers2_sub()을 호출한 이후 클래스 이름을 fullname으로 정하고 클래스 캐시에 등록한 이후를 말한다.
     * (FindAllClassesAndItsMembers2()와 start_onlyInterface()함수를 참조한다.)<br>
     * @param indexOfSrc : c가 short name일 경우에만 의미가 있다. c의 소스상에서의 인덱스, 비슷하게 정해주면 된다.*/
    public static FindClassParams getTypeOfDefinedClass_backup(Compiler compiler, String c, int indexOfSrc) {
    	if (indexOfSrc==4810) {
    	}
    	
    	
    	if (!c.contains(".")) {
    		ArrayListIReset mlistOfAllDefinedClasses = compiler.data.mlistOfAllDefinedClasses;
        	
    		int i;
	    	if (mlistOfAllDefinedClasses==null) return null;
	    	ArrayListInt listOfIndices = new ArrayListInt(2);
	    	for (i=0; i<mlistOfAllDefinedClasses.count; i++) {
	    		FindClassParams classP = (FindClassParams) mlistOfAllDefinedClasses.getItem(i);
	    		if (classP.name==null) continue;
	    		String name = CompilerStatic.getShortName(classP.name);
	    		if (name.equals(c)) {
	    			//if (classP.startIndex()<indexOfSrc && indexOfSrc<classP.endIndex()) {
	    				listOfIndices.add(i);
	    			//}
	    		}
	    	}
	    	if (listOfIndices.count==1) {
	    		return (FindClassParams) mlistOfAllDefinedClasses.getItem(listOfIndices.getItem(0));
	    	}
	    	else if (listOfIndices.count>1) { // 이름이 같은 클래스들이 여러개 있는 경우
	    		ArrayListIReset mlistOfClass = compiler.data.mlistOfClass;
		    	for (i=0; i<mlistOfClass.count; i++) {
		    		FindClassParams classP = (FindClassParams) mlistOfClass.getItem(i);
		    		String shortName = CompilerHelper.getShortName(classP.name);
		    		if (shortName.equals(c)) return classP;
		    	}
	    	}
	    	return null;
	    	
    	}//if (c.contains(".")==false) {
    	else {
    		ArrayListIReset mlistOfAllDefinedClasses = compiler.data.mlistOfAllDefinedClasses;
    		int i;
    		if (mlistOfAllDefinedClasses==null) return null;
	    	for (i=0; i<mlistOfAllDefinedClasses.count; i++) {
	    		FindClassParams classP = (FindClassParams) mlistOfAllDefinedClasses.getItem(i);
	    		if (classP.name==null) continue;
	    		String name = classP.name;
	    		if (name.equals(c)) return classP;
	    	}
	    	return null;
    		
    	}
    }
    
    /** 같은 파일에 정의된 클래스의 이름이 확실하게 fullname으로 정해진 이후에 호출되어야 한다. 
     * FindAllClassesAndItsMembers2_sub()을 호출한 이후 클래스 이름을 fullname으로 정하고 클래스 캐시에 등록한 이후를 말한다.
     * (FindAllClassesAndItsMembers2()와 start_onlyInterface()함수를 참조한다.)<br>
     * short이름일 경우 mlistOfAllDefinedClass에 중복된 클래스를 검색하면 클래스 내부에서 사용되는 경우에는 가장 안쪽 클래스를 리턴하고,
     * 클래스 외부에서 사용되는 경우에는 클래스가 정의된 이후와  indexOfSrc의 거리를 따져서 가장 가까운 거리의 클래스를 리턴한다.
     * 예를들어 com.gsoft.common.EditText.UndoBuffer.Pair가 정의되고 Pair가 사용되면 UndoBuffer.Pair를
     * com.gsoft.common.EditText.RedoBuffer.Pair가 가 정의되고 Pair가 사용되면 RedoBuffer.Pair를 리턴한다.
     * 
     * @param indexOfSrc : c가 short name일 경우에만 의미가 있다. c의 소스상에서의 인덱스, 비슷하게 정해주면 된다.*/
    public static FindClassParams getTypeOfDefinedClass(Compiler compiler, String c, int indexOfSrc) {
    	if (indexOfSrc==1323) {
    	}
    	ArrayListIReset mlistOfAllDefinedClasses = compiler.data.mlistOfAllDefinedClasses;
    	
    	if (!c.contains(".")) {
	    	int i;
	    	if (mlistOfAllDefinedClasses==null) return null;
	    	ArrayListInt listOfIndices = new ArrayListInt(2);
	    	for (i=0; i<mlistOfAllDefinedClasses.count; i++) {
	    		FindClassParams classP = (FindClassParams) mlistOfAllDefinedClasses.getItem(i);
	    		if (classP.name==null) continue;
	    		String name = CompilerStatic.getShortName(classP.name);
	    		if (name.equals(c)) {
	    			//if (classP.startIndex()<indexOfSrc && indexOfSrc<classP.endIndex()) {
	    				listOfIndices.add(i);
	    			//}
	    		}
	    	}
	    	if (listOfIndices.count==1) {
	    		return (FindClassParams) mlistOfAllDefinedClasses.getItem(listOfIndices.getItem(0));
	    	}
	    	else if (listOfIndices.count>1) { // 이름이 같은 클래스들이 여러개 있는 경우
	    		if (indexOfSrc==-1) 
	    			return (FindClassParams) mlistOfAllDefinedClasses.getItem(listOfIndices.getItem(0));
	    		
	    		ArrayListInt listOfIndices2 = new ArrayListInt(1); //클래스 내부에서 사용되는 경우
	    		ArrayListInt listOfLength2 = new ArrayListInt(1);
	    		ArrayListInt listOfIndices3 = new ArrayListInt(1); //클래스가 정의된 이후에서 사용되는 경우
	    		ArrayListInt listOfLength3 = new ArrayListInt(1); // 클래스가 정의된 이후와 indexOfSrc이 떨어진 거리
	    		int index;
		    	for (i=0; i<listOfIndices.count; i++) {
		    		index = listOfIndices.getItem(i);
		    		FindClassParams classP = (FindClassParams) mlistOfAllDefinedClasses.getItem(index);
		    		if (classP.name==null) continue;
		    		if (classP.startIndex()<indexOfSrc && indexOfSrc<classP.endIndex()) {
		    			//클래스 내부에서 사용되는 경우
		    			listOfIndices2.add(index);
	    				listOfLength2.add(classP.endIndex()-classP.startIndex()+1);
		    		}
		    		else if (indexOfSrc>classP.endIndex()) {
		    			// 클래스가 정의된 이후에서 사용되는 경우
		    			listOfIndices3.add(index);
		    			listOfLength3.add(indexOfSrc-classP.endIndex()+1);
		    		}
		    	}
		    	if (listOfIndices2.count==1) {//이름이 같은 클래스들이 서로 포함하지 않는경우
		    		return (FindClassParams) mlistOfAllDefinedClasses.getItem(listOfIndices2.getItem(0));
		    	}
		    	else if (listOfIndices2.count>1) {//이름이 같은 클래스들이 서로 포함하는경우
		    		int len;
		    		int minLen = listOfLength2.getItem(0);
		    		int indexOfMinLen = 0;
		    		for (i=1; i<listOfLength2.count; i++) {
			    		len = listOfLength2.getItem(i);
			    		if (minLen>len) {
			    			minLen = len;
			    			indexOfMinLen = i;
			    		}
		    		}
		    		return (FindClassParams) mlistOfAllDefinedClasses.getItem(listOfIndices2.getItem(indexOfMinLen));
		    	}
		    	else {// 이름이 같은 클래스들이 여러개 있으나 그 클래스들내에서 사용되지 않는 경우	
		    		if (listOfLength3.count>0) {
			    		int len;
			    		int minLen = listOfLength3.getItem(0);
			    		int indexOfMinLen = 0;
			    		// 클래스가 정의된 이후의 인덱스와 indexOfSrc의 인덱스들의 저장된 listOfLength3에서 최소값을 찾는다.
			    		for (i=1; i<listOfLength3.count; i++) {
			    			len = listOfLength3.getItem(i);
				    		if (minLen>len) {
				    			minLen = len;
				    			indexOfMinLen = i;
				    		}
			    		}
			    		return (FindClassParams) mlistOfAllDefinedClasses.getItem(listOfIndices3.getItem(indexOfMinLen));
		    		}
		    		else {
		    			// Pair가 사용되고 그 이후에 UndoBuffer.Pair, RedoBuffer.Pair가 정의되면 null을 리턴한다.
		    			return null;
		    		}
		    	}
	    	}//else if (listOfIndices.count>1) { // 이름이 같은 클래스들이 여러개 있는 경우
	    	else {
	    		// shortname을 가진 클래스가 없는 경우
	    		return null;
	    	}
	    	
    	}//if (c.contains(".")==false) {
    	else {
    		int i;
    		if (mlistOfAllDefinedClasses==null) return null;
	    	for (i=0; i<mlistOfAllDefinedClasses.count; i++) {
	    		FindClassParams classP = (FindClassParams) mlistOfAllDefinedClasses.getItem(i);
	    		if (classP.name==null) continue;
	    		String name = classP.name;
	    		if (name.equals(c)) return classP;
	    	}
	    	return null;
    		
    	}
    }
    
    
    /** java.lang 패키지안의 클래스를 검색한다.
     * @param c : */
    public static boolean IsTypeOfDefaultLibrary(Compiler compiler, String c) {
    	ArrayListString TypesOfDefaultLibrary = compiler.data.TypesOfDefaultLibrary;
    	if (!c.contains(".")) { // short name
	    	int i;
	    	if (TypesOfDefaultLibrary==null) return false;
	    	for (i=0; i<TypesOfDefaultLibrary.count; i++) {
	    		if (c.equals(TypesOfDefaultLibrary.getItem(i))) return true;
	    	}
	    	return false;
    	}
    	else { // full name
    		int i;
	    	if (TypesOfDefaultLibrary==null) return false;
	    	for (i=0; i<TypesOfDefaultLibrary.count; i++) {
	    		if (c.equals("java.lang."+TypesOfDefaultLibrary.getItem(i))) return true;
	    	}
	    	return false;
    		
    	}
    }
    
    
    public static boolean IsTypeOfImportStar(Compiler compiler, CodeString c) {
    	int i, j;
    	ArrayListIReset TypesOfImportStarOfJava = compiler.data.TypesOfImportStarOfJava;
    	if (TypesOfImportStarOfJava==null) return false;
    	
    	for (i=0; i<TypesOfImportStarOfJava.count; i++) {
    		ArrayListString types = (ArrayListString) TypesOfImportStarOfJava.getItem(i);
    		for (j=0; j<types.count; j++) {
    			if (c.equals(types.list[i])) return true;
    		}
    	}
    	return false;
    }
    
    /** Integer, Char, Float등 java.lang패키지에 있는 클래스들
     * @param c : short이든 full이름이든 상관안함, 예를들어 Integer나 java.lang.Integer등
     * @return
     */
    public static boolean IsTypeOfDefaultLibrary(Compiler compiler, CodeString c) {
    	ArrayListString TypesOfDefaultLibrary = compiler.data.TypesOfDefaultLibrary;
    	if (!c.str.contains(".")) { // short name
	    	int i;
	    	if (TypesOfDefaultLibrary==null) return false;
	    	for (i=0; i<TypesOfDefaultLibrary.count; i++) {
	    		if (c.equals(TypesOfDefaultLibrary.getItem(i))) return true;
	    	}
	    	return false;
    	}
    	else {
    		int i;
	    	if (TypesOfDefaultLibrary==null) return false;
	    	for (i=0; i<TypesOfDefaultLibrary.count; i++) {
	    		if (c.equals("java.lang."+TypesOfDefaultLibrary.getItem(i))) return true;
	    	}
	    	return false;
    		
    	}
    }
    
    public static boolean IsTypeOfDefinedClass(Compiler compiler, String c) {
    	ArrayListIReset mlistOfAllDefinedClasses = compiler.data.mlistOfAllDefinedClasses;
    	if (!c.contains(".")) {
	    	int i;
	    	if (mlistOfAllDefinedClasses==null) return false;
	    	for (i=0; i<mlistOfAllDefinedClasses.count; i++) {
	    		FindClassParams classP = (FindClassParams) mlistOfAllDefinedClasses.getItem(i);
	    		String name = CompilerStatic.getShortName(classP.name);
	    		if (name.equals(c)) return true;
	    	}
	    	return false;
    	}
    	else {
    		int i;
    		if (mlistOfAllDefinedClasses==null) return false;
	    	for (i=0; i<mlistOfAllDefinedClasses.count; i++) {
	    		FindClassParams classP = (FindClassParams) mlistOfAllDefinedClasses.getItem(i);
	    		String name = classP.name;
	    		if (name.equals(c)) return true;
	    	}
	    	return false;
    		
    	}
    }
    
    /** import com.gsoft.common.Util.*; Stack<Character.Subset> s;에서 Stack을 결정한다.<br>
	 * com.gsoft.common.compiler.Compiler_types.*; CLanguage language;에서 CLanguage를 결정한다.*/
    public static String getTypeOfImportStar(Compiler compiler, String shortName) {
    	if (shortName.equals("java")) {
    	}
    	ArrayListIReset TypesOfImportStarOfJava = compiler.data.TypesOfImportStarOfJava;
    	int i, j;
    	if (TypesOfImportStarOfJava==null) return null;
    	
    	for (i=0; i<TypesOfImportStarOfJava.count; i++) {
    		ArrayListString types = (ArrayListString) TypesOfImportStarOfJava.getItem(i);
    		for (j=0; j<types.count; j++) {
    			if (shortName.equals(types.list[j])) {
    				String path = compiler.data.mlistOfImportedClassesStar.list[i]+"."+types.list[j];
    				return path;
    			}
    		}
    	}
    	return null;
    }
    
    /** shortName으로 같은 패키지내 클래스들에서 검색하여 
     * 일치하는 일반 namespace와 같은(a.b.c 등) full name을 리턴한다.*/
    public static String getTypeOfPackageLibrary(Compiler compiler, String shortName) {
    	ArrayListString mListOfFileOfSamePackage = compiler.data.mListOfFileOfSamePackage;
    	if (compiler.data.packageName==null) return null;
    	if (mListOfFileOfSamePackage.count==0) {
    		File file = new File(Common_Settings.pathProjectSrc+File.separator+compiler.data.packageName.replace('.', File.separatorChar));
    		String[] fileList = file.list();
    		int j;
    		if (fileList==null) return null;
    		for (j=0; j<fileList.length; j++) {
    			mListOfFileOfSamePackage.add(fileList[j]);
    		}
    	}
    	if (mListOfFileOfSamePackage.count==0) return null;
    	int i;
    	for (i=0; i<mListOfFileOfSamePackage.count; i++) {
    		String ext = FileHelper.getExt(mListOfFileOfSamePackage.getItem(i));
    		if (ext.equals(".zip")) continue; // com/gsoft/common/java.zip은 continue
    		String str = FileHelper.getFilenameExceptExt(mListOfFileOfSamePackage.getItem(i));
    		if (str.equals(shortName)) {
    			return compiler.data.packageName + "." + shortName;
    		}
    	}
    	return null;
    	
    }
    
    /** name(shortName, fullName둘다 가능)으로 import문들에서 검색하여 일치하는 full name을 리턴한다.*/
    public static String getTypeOfImportLibrary(Compiler compiler, String name) {
    	int i;
    	ArrayListString mlistOfImportedClasses = compiler.data.mlistOfImportedClasses;
    	if (!name.contains(".")) {
	    	for (i=0; i<mlistOfImportedClasses.count; i++) {
	    		String importedLibrary = mlistOfImportedClasses.getItem(i);
	    		String shortName = CompilerStatic.getShortName(importedLibrary);
	    		if (shortName.equals(name)) return importedLibrary;
	    	}
    	}
    	else {
    		for (i=0; i<mlistOfImportedClasses.count; i++) {
	    		String importedLibrary = mlistOfImportedClasses.getItem(i);
	    		if (importedLibrary.equals(name)) return importedLibrary;	    		
    		}
    	}
    	return null;
    	
    }
}
