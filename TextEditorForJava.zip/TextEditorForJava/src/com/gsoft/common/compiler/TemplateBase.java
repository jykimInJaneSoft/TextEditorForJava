package com.gsoft.common.compiler;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.interfaces.IReset;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.Compiler_types.FindFunctionParams;
import com.gsoft.common.compiler.Compiler_types.FindVarParams;
import com.gsoft.common.compiler.Compiler_types.FindVarUseParams;
import com.gsoft.common.compiler.Compiler_types_Base.Block;
import com.gsoft.common.compiler.Compiler_types_Base.ReturnOfIsType;
import com.gsoft.common.util.ArrayListIReset;

import com.gsoft.common.compiler.IndexForHighArray;
import com.gsoft.common.compiler.TypeCast_Syntax;
import com.gsoft.common.compiler.HighArray_CodeString;
import com.gsoft.common.compiler.Fullname;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.Array;
import com.gsoft.common.compiler.Checker;
import com.gsoft.common.compiler.Compiler;

public class TemplateBase {
	public static class Template  implements IReset {
		/** 템플릿 타입이름의 인덱스, com.gsoft.common.util.Stack'<'java.lang.String'>' s;에서 com의 인덱스이다.*/
		IndexForHighArray indexTypeName;
		String typeName;
		/** <의 인덱스*/
		IndexForHighArray indexLeftPair;
		/** >의 인덱스*/
		IndexForHighArray indexRightPair;
		/** 괄호안에 있는 바꿔야할 타입의 인덱스, com.gsoft.common.util.Stack'<'java.lang.String'>' s;에서 java의 인덱스이다.*/
		IndexForHighArray indexTypeNameToChange;
		public String typeNameToChange;
		
		int indexTypeName() {
			if (indexTypeName==null) return -1;
			return indexTypeName.index();
		}
		
		int indexLeftPair() {
			if (indexLeftPair==null) return -1;
			return indexLeftPair.index();
		}
		
		int indexRightPair() {
			if (indexRightPair==null) return -1;
			return indexRightPair.index();
		}
		
		int indexTypeNameToChange() {
			if (indexTypeNameToChange==null) return -1;
			return indexTypeNameToChange.index();
		}
		
		Template child;
		
		boolean found;
		//public Template parent;
		
		Compiler compiler;
		
		/** @param indexTypeName : 템플릿 타입이름의 인덱스, 
		 * com.gsoft.common.util.Stack'<'java.lang.String'>' s;에서 com의 인덱스이다.
		* @param indexLeftPair : <의 인덱스
		* @param indexRightPair : >의 인덱스
		* @param indexTypeNameToChange : 괄호안에 있는 바꿔야할 타입의 인덱스, 
		* com.gsoft.common.util.Stack'<'java.lang.String'>' s;에서 java의 인덱스이다.*/
		Template(Compiler compiler, int indexTypeName, int indexLeftPair, 
				int indexRightPair, int indexTypeNameToChange) {
			this.compiler = compiler;
			this.indexTypeName = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, indexTypeName);
			this.indexLeftPair = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, indexLeftPair);
			this.indexRightPair = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, indexRightPair);
			this.indexTypeNameToChange = IndexForHighArray.indexRelative(this, compiler.data.mBuffer, indexTypeNameToChange);
		}
		
		Template(Compiler compiler) {
			this.compiler = compiler;
			this.indexTypeName = null;
			this.indexLeftPair = null;
			this.indexRightPair = null;
			this.indexTypeNameToChange = null;
		}
		
		/**template을 this로 카피한다*/
		void copy(Template template) {
			this.indexTypeName = template.indexTypeName;
			this.indexLeftPair = template.indexLeftPair;
			this.indexRightPair = template.indexRightPair;
			this.indexTypeNameToChange = template.indexTypeNameToChange;
			this.child = template.child;
			this.typeName = template.typeName;
			this.typeNameToChange = template.typeNameToChange;
		}

		@Override
		public void destroy() {
			
			if (this.child!=null) {
				this.child.destroy();
				this.child = null;
			}
			if (this.typeName!=null) this.typeName = null;
			if (this.typeNameToChange!=null) this.typeNameToChange = null;
		}
		
		
	}
	
	/** 템플릿이 중첩될 경우 가장 알맞은 템플릿에 fullClassName을 준다.*/
	boolean modifyTemplateName(Template template, String fullClassName, int indexVarUse) {
		if (template==null) return false;
		
		
		// 템플릿이 중첩될 경우 가장 알맞은 템플릿에 fullClassName을 준다.
		if (template.child!=null) {
			boolean r = modifyTemplateName( template.child, fullClassName, indexVarUse);
			if (r) return r;
		}
		
		if (template.indexTypeName()<=indexVarUse && indexVarUse<=template.indexLeftPair()) {				
			template.typeName = fullClassName;
			return true;
		}
		else if (template.indexTypeNameToChange()<=indexVarUse) {
			template.typeNameToChange = fullClassName;
			return true;
		}
		
		return false;
	}
	
	/** template으로부터 fullname을 얻는다. 
	 * 템플릿이 중첩되더라도 자식 템플릿을 포함하여 fullname을 얻는다.
	 * FindClassesFromTypeDecls(), confirmTypeName()에서 var.getType()이나 func.getReturnType()을 통해서
	 * getFullNameType()이 호출되어 Template의 typeName과 typeNameToChange의 풀이름이 설정된다.
	 * Template의 typeName과 typeNameToChange의 풀이름이 정확하지 않을때는 
	 * (예를들어, Stack<Character.Subset> s;와 같은 경우) 
	 * modifyTemplateName()를 통해서 올바른 풀이름으로 변경된다.*/
	String getFullNameFromTemplate(HighArray_CodeString src, Template template) {
		if (template==null) return null;
		
		String r = template.typeName;
		String child = null;
		if (template.child!=null) {
			child = getFullNameFromTemplate(src, template.child);
		}
		
		if (child!=null) {
			r += "<" + child + ">";
		}
		else {
			r += "<" + template.typeNameToChange + ">";
		}
		return r;
		
	}
	/** class Stack<T> {<br>
	 * 		T Data;<br>
	 *  	void push(T data) {<br>
	 *  	}<br>
	 * }<br>
	 * 에서 변수 Data와 data는 getFullNameType()에서 null을 리턴하므로
	 * 그것의 템플릿 타입이름인 T를 리턴한다.
	 * @param var
	 * @return
	 */
	public static String isTemplateType(Compiler compiler, FindVarParams var) {
		Object parent = var.parent;
		String typeName = Fullname.getFullName(compiler.data.mBuffer, var.typeStartIndex(), var.typeEndIndex()).str;
		
		while(true) {
			if (parent==null) return null;
			if (parent instanceof FindClassParams) {
				FindClassParams c = (FindClassParams) parent;
				if (c.template!=null) {
					if (c.template.typeNameToChange!=null) {
						if (c.template.typeNameToChange.equals(typeName)) {
							return typeName;
						}
					}
				}
				parent = c.parent;
			}
			else if (parent instanceof FindFunctionParams) {
				FindFunctionParams f = (FindFunctionParams) parent;
				parent = f.parent;
			}
			else {
				parent = ((Block)parent).parent;
			}
		}
	}
	
	
	/** class Stack<T> {<br>
	 * 		T Data;<br>
	 *  	void push(T data) {<br>
	 *  	}<br>
	 * }<br>
	 * 에서 변수 Data와 data는 getFullNameType()에서 null을 리턴하므로
	 * 그것의 템플릿 타입이름인 T를 리턴한다.
	 * @param var
	 * @return
	 */
	public static String isTemplateType(Compiler compiler, FindFunctionParams func) {
		
		Block parent = func.parent;
		String typeName = Fullname.getFullName(compiler.data.mBuffer, func.returnTypeStartIndex(), func.returnTypeEndIndex()).str;
		while(true) {
			if (parent==null) return null;
			if (parent instanceof FindClassParams) {
				FindClassParams c = (FindClassParams) parent;
				if (c.template!=null) {
					if (c.template.typeNameToChange!=null) {
						if (c.template.typeNameToChange.equals(typeName)) {
							return typeName;
						}
					}
				}
				parent = c.parent;
			}
			else if (parent instanceof FindFunctionParams) {
				FindFunctionParams f = (FindFunctionParams) parent;
				parent = f.parent;
			}
			else {
				parent = parent.parent;
			}
		}
	}
	
	/** index부터 시작하여 역방향으로 검사하여 타입이름의 시작인덱스를 리턴한다. 중첩된 템플릿을 검사하기 위하여 재귀적 호출을 한다.
     * @return : 중첩된 템플릿일 경우 가장 바깥 템플릿*/
	public static  Template isTemplate(Compiler compiler, int index) {
		HighArray_CodeString src = compiler.data.mBuffer;
    	
    	
    	if (index<0) return null;
    	
    	
    	CodeString strIndex = src.getItem(index);
    	if (!strIndex.equals(">")) return null;
    	int indexLeftPair = Checker.CheckParenthesis(compiler,  "<", ">", 0, index, true);
    	if (indexLeftPair==-1) {
    		return null;
    	}
    	
    	
    	
    	//String str = Fullname.getFullName(src, indexLeftPair, index).str;
    	
    	int indexFullname = CompilerHelper.SkipBlank(src, false, indexLeftPair+1, index);
    	indexFullname = Fullname.getFullNameIndex_OnlyType(compiler,  false, indexFullname, true);
    	indexFullname = CompilerHelper.SkipBlank(src, false, indexFullname+1, index);
    	
    	if (indexFullname!=index) {
    		return null;
    	}
    	
    	
    	// HighArray<FindVarParams>에서 index는 >의 인덱스
    	//중첩된 템플릿을 검사하기 위하여 재귀적 호출을 한다.
    	//Template childTemplate = new Template(this);
    	//int startIndexOfType1 = IsType(src, true, index-1, childTemplate);
    	ReturnOfIsType returnOfIsType = compiler.IsType(src, true, index-1);
    	
    	Template childTemplate = returnOfIsType.template;
    	int startIndexOfType1 = returnOfIsType.index;
    	if (startIndexOfType1==-1) return null;
    	
    	startIndexOfType1 = CompilerHelper.SkipBlank(src, false, startIndexOfType1, index-1);
    	if (startIndexOfType1==index) return null;
    	
    	int startIndexOfType2 = CompilerHelper.SkipBlank(src, false, indexLeftPair+1, index-1);
    	if (startIndexOfType2==index) return null;
    	
    	//if (startIndexOfType1!=startIndexOfType2) return null;
    	
    	int indexTypeName = indexLeftPair-1;
    	indexTypeName = CompilerHelper.SkipBlank(src, true, 0, indexTypeName);
    	indexTypeName = Fullname.getFullNameIndex_OnlyType(compiler,  true, indexTypeName, true);
    	indexTypeName = CompilerHelper.SkipBlank(src, false, indexTypeName, indexLeftPair-1);
    	if (indexTypeName==indexLeftPair) return null;
    	
    	if (indexTypeName<indexLeftPair && indexLeftPair<startIndexOfType1 && startIndexOfType1<index) {    	
	    	if (childTemplate!=null && childTemplate.found) {
	    		Template r = new Template(compiler, indexTypeName, indexLeftPair, index, startIndexOfType1);
	    		r.child = childTemplate;
	    		//childTemplate.parent = r;
	    		return r;
	    	}
	    	else {
	    		Template r = new Template(compiler, indexTypeName, indexLeftPair, index, startIndexOfType1);
	    		//mlistOfAllTemplates.add(r);
	    		return r;
	    	}
    	}
    	return null;
    }
    
	/** 템플릿이 중첩될 경우 가장 알맞은 템플릿을 리턴한다.*/
	public static  Template getMostSuitableTemplate(ArrayListIReset listOfTemplates, int startIndex, int endIndex) {
		int i;
		for (i=0; i<listOfTemplates.count; i++) {
			Template t = (Template) listOfTemplates.getItem(i);
			Template r = getMostSuitableTemplate_sub(t, startIndex, endIndex);
			if (r!=null) return r;
		}
		return null;
	}
	
	/** 템플릿이 중첩될 경우 가장 알맞은 템플릿을 리턴한다.*/
	public static Template getMostSuitableTemplate_sub(Template template, int startIndex, int endIndex) {
		if (template==null) return null;
		
		// 템플릿이 중첩될 경우 가장 알맞은 템플릿을 리턴한다.
		if (template.child!=null) {
			Template t = getMostSuitableTemplate_sub(template.child, startIndex, endIndex);
			if (t!=null) return t;
		}
		
		if (template.indexTypeName()<=startIndex && endIndex<=template.indexRightPair()) {
			return template;
		}
		return null;
	}
	
	/** class Stack<T> {}인 템플릿 클래스일 경우 이 클래스를 CompilerHelper.loadClassFromSrc_onlyInterface()으로
	 * 읽어야 한다면(바이트코드를 읽지않고 바이트코드는 PathClassLoader클래스에서 템플릿을 처리한다.) 템플릿 타입을 처리하기 위해
	 * 이 함수를 호출해야 한다. 예를 들어  Stack<Block> stack;에서 Stack<Block>을 만나면 loadClass()가 호출이 되는데
	 * 바이트코드가 error가 날경우 loadClassFromSrc_onlyInterface()에서 호출을 해야 한다.
	 * @param compiler
	 * @param classParams : class Stack<T> {}인 템플릿 클래스
	 * @param fullNameIncludingTemplate : Stack<Block> stack; 에서 com.gsoft.common.Util.Stack<com.gsoft.common.Compiler_types.Block>이다.
	 * @param mode : 0(T의 isTypeToChange를 true로 설정한다.), 1(T를 typeNameInTemplatePair으로 바꿔준다), 
	 * 2(T를 java.lang.Object로 바꿔준다)
	 */
	public static void applyTypeNameToChangeToTemplateClass(Compiler compiler, FindClassParams classParams, 
			String fullNameIncludingTemplate, byte mode) {
		
		if (classParams==null) return;
		if (classParams.template==null) return;
		
		
		// class Stack<T> {}인 템플릿 클래스일 경우 typeNameToChange는 T이다.
		String typeNameToChange = classParams.template.typeNameToChange;
		
		// Stack<Block> stack; 에서 typeNameInTemplatePair는 com.gsoft.common.Compiler_types.Block이 된다.
		String typeNameInTemplatePair = TemplateBase.getTemplateTypeInPair(fullNameIncludingTemplate);
		
		
		classParams.name = fullNameIncludingTemplate;
		
		ArrayListIReset listOfTypeCasts = compiler.data.mlistOfAllTypeCasts ;
		
		int i;
		for (i=0; i<listOfTypeCasts.count; i++) {
			TypeCast_Syntax typecast = (TypeCast_Syntax) listOfTypeCasts.getItem(i);
			if (classParams.startIndex()<typecast.startIndex() && typecast.endIndex()<classParams.endIndex()) {
				
				if (typecast.name.equals(typeNameToChange)) {
					int dimension = Array.getArrayDimension(compiler, typecast.name);
					switch(mode) {
					case 0: typecast.isTypeNameToChange = true; break; 
					case 1: 
						typecast.isTypeNameToChange = true;
						typecast.name = Array.getArrayType(typeNameInTemplatePair, dimension); break;
					case 2: 
						typecast.isTypeNameToChange = true; 
						typecast.name = Array.getArrayType("java.lang.Object", dimension); break;
					}
				}
			}
		}
		
		
		// class Stack<T>의 내부 클래스에 대해 호출
		for (i=0; i<classParams.childClasses.count; i++) {
			FindClassParams child = (FindClassParams) classParams.childClasses.getItem(i);
			applyTypeNameToChangeToTemplateClass_sub(compiler, child, typeNameToChange, typeNameInTemplatePair, mode);
		}
		
		// 현재 클래스에 대해 호출
		applyTypeNameToChangeToTemplateClass_sub(compiler, classParams, typeNameToChange, typeNameInTemplatePair, mode);
		
		classParams.appliedInapplyTypeNameToChangeToTemplateClass = true;
		
	}//void applyTypeNameToChangeToTemplateClass()
	
	
	/** applyTypeNameToChangeToTemplateClass()의 sub이다.
	 * @param compiler : 현재 ***.java의 compiler
	 * @param classParams : 해당 클래스, 재귀적 호출
	 * @param typeNameToChange : class Stack {}이 템플릿 클래스 T일 경우 typeNameToChange는 T이다.
	 * @param typeNameInTemplatePair : Stack<Block> stack; 에서 typeNameInTemplatePair는 com.gsoft.common.Compiler_types.Block이 된다.
	 * 
	 *  @param mode : 0(T의 isTypeToChange를 true로 설정한다.), 1(T를 typeNameInTemplatePair으로 바꿔준다), 
	 * 2(T를 java.lang.Object로 바꿔준다)
	 */
	public static void applyTypeNameToChangeToTemplateClass_sub(Compiler compiler, FindClassParams classParams,
			String typeNameToChange, String typeNameInTemplatePair, byte mode) {
		ArrayListIReset listOfMemberVars = classParams.listOfVariableParams;
		ArrayListIReset listOfFuncs = classParams.listOfFunctionParams;
		int i, j;		
		
		for (j=0; j<listOfMemberVars.count; j++) {
			FindVarParams var = (FindVarParams) listOfMemberVars.getItem(j);
			
			try {
			String typeName = Array.getArrayElementType(var.typeName);				
			if (typeName!=null && typeName.equals(typeNameToChange)) {
				int dimension = Array.getArrayDimension(compiler, var.typeName);
				switch(mode) {
				case 0: var.isTypeNameToChange = true; break; 
				case 1: 
					var.isTypeNameToChange = true;
					var.typeName = Array.getArrayType(typeNameInTemplatePair, dimension); break;
				case 2: 
					var.isTypeNameToChange = true; 
					var.typeName = Array.getArrayType("java.lang.Object", dimension); break;
				}
			}
			}catch(Exception e) {
				if (Common_Settings.g_printsLog) e.printStackTrace();
			}
		}
		
		for (j=0; j<listOfFuncs.count; j++) {
			FindFunctionParams func = (FindFunctionParams) listOfFuncs.getItem(j);
			/*if (func.returnType!=null && func.returnType.equals(typeNameToChange)) {
				func.returnType = typeNameInTemplatePair;
			}*/
			
			
			if (func.isConstructor) {
				if (mode==0) {
					func.isTypeNameToChange = true;
				}
				else if (mode==1) {
					func.name = CompilerHelper.getShortName(classParams.name) + "<" + typeNameInTemplatePair + ">";
					func.returnType = classParams.name + "<" + typeNameInTemplatePair + ">";
				}
				else {
					//func.name = CompilerHelper.getShortName(classParams.name);
				}
			}
			
			String typeName = Array.getArrayElementType(func.returnType);				
			if (typeName!=null && typeName.equals(typeNameToChange)) {
				int dimension = Array.getArrayDimension(compiler, func.returnType);
				switch(mode) {
				case 0: func.isTypeNameToChange = true; break;
				case 1: 
					func.isTypeNameToChange = true;
					func.returnType = Array.getArrayType(typeNameInTemplatePair, dimension); break;
				case 2: 
					func.isTypeNameToChange = true;
					func.returnType = Array.getArrayType("java.lang.Object", dimension); break;
				}
			}
			
			ArrayListIReset listOfFuncArgs = func.listOfFuncArgs;
			for (i=0; i<listOfFuncArgs.count; i++) {
				FindVarParams var = (FindVarParams) listOfFuncArgs.getItem(i);
				if (var.isThis || var.isSuper) continue;
				String typeName2 = Array.getArrayElementType(var.typeName);				
				if (typeName2!=null && typeName2.equals(typeNameToChange)) {
					int dimension = Array.getArrayDimension(compiler, var.typeName);
					switch(mode) {
					case 0: var.isTypeNameToChange = true; break; 
					case 1: 
						var.isTypeNameToChange = true;
						var.typeName = Array.getArrayType(typeNameInTemplatePair, dimension); break;
					case 2: 
						var.isTypeNameToChange = true; 
						var.typeName = Array.getArrayType("java.lang.Object", dimension); break;
					}
				}
			}
			
			ArrayListIReset listOfLocalVars = func.listOfVariableParams;
			for (i=0; i<listOfLocalVars.count; i++) {
				FindVarParams var = (FindVarParams) listOfLocalVars.getItem(i);
				if (var.isThis || var.isSuper) continue;
				String typeName2 = Array.getArrayElementType(var.typeName);				
				if (typeName2!=null && typeName2.equals(typeNameToChange)) {
					int dimension = Array.getArrayDimension(compiler, var.typeName);
					switch(mode) {
					case 0: var.isTypeNameToChange = true; break; 
					case 1: 
						var.isTypeNameToChange = true;
						var.typeName = Array.getArrayType(typeNameInTemplatePair, dimension); break;
					case 2: 
						var.isTypeNameToChange = true; 
						var.typeName = Array.getArrayType("java.lang.Object", dimension); break;
					}
				}
			}
		}//for (i=0; i<listOfFuncs.count; i++) {
	}
	
	
	
	/** 파일에서 정의하는 클래스가 템플릿일 경우 가상의 변수선언을 만들어서 findTemplateVarUses()을
	 * 호출하여 클래스안의 변수선언들, 함수선언들에서 varUse들을 찾아서 가상의 변수선언에 연결한다. 
	 * 예를들어 class Stack {}이 템플릿 T일 경우 클래스안의 T들을 찾는다.
	 * @param src
	 */
	public static void findAllVarUsingOfTemplate(Compiler compiler, HighArray_CodeString src) {
		int i;
		for (i=0; i<compiler.data.mlistOfAllDefinedClasses.count; i++) {
			FindClassParams c = (FindClassParams) compiler.data.mlistOfAllDefinedClasses.getItem(i);
			if (c.template!=null) {
				FindVarParams var = new FindVarParams(compiler, c.template, c);
				findTemplateVarUses(compiler, src, c, var);
			}
		}
	}
	
	/** findTemplateVarUses_sub()의 재귀적 호출*/
	public static void findTemplateVarUses(Compiler compiler, HighArray_CodeString src, FindClassParams classParams, FindVarParams templateVar) {
		int i;
		ArrayListIReset listOfChildClasses = classParams.childClasses;
		for (i=0; i<listOfChildClasses.count; i++) {
			FindClassParams child = (FindClassParams) listOfChildClasses.getItem(i);
			findTemplateVarUses_sub(compiler, src, child, templateVar);
		}
		findTemplateVarUses_sub(compiler, src, classParams, templateVar);
	}
	
	/** class Stack {}에서 Stack이 템플릿클래스이면 템플릿 변수를 만들어서
	 *  클래스의 변수선언들, 함수선언들의 타입들에 있는 varUse들의 varDecl을 템플릿 변수에 연결시킨다.
	 * @param src
	 * @param classParams : 해당 클래스
	 * @param templateVar : 템플릿 변수(FindVarParams.templateOfClass가 null이 아니다.)
	 */
	public static void findTemplateVarUses_sub(Compiler compiler, HighArray_CodeString src, FindClassParams classParams, FindVarParams templateVar) {
		ArrayListIReset listOfMemberVars = classParams.listOfVariableParams;
		ArrayListIReset listOfFuncs = classParams.listOfFunctionParams;
		int i, j, k;
		int typeStartIndex, typeEndIndex;
		int endIndexInmListOfAllVarUses;
		int startIndexInmListOfAllVarUses;
		
		ArrayListIReset listOfTypeCasts = compiler.data.mlistOfAllTypeCasts;
		for (i=0; i<listOfTypeCasts.count; i++) {
			TypeCast_Syntax typecast = (TypeCast_Syntax) listOfTypeCasts.getItem(i);
			if (classParams.startIndex()<typecast.startIndex() && typecast.endIndex()<classParams.endIndex()) {
				FindVarUseParams varUse = typecast.varUseTypeCasting;
				if (varUse.originName.equals(templateVar.fieldName)) {
					varUse.varDecl = templateVar;
				}
			}
		}//for (i=0; i<listOfTypeCasts.count; i++) {
		
		
		for (i=0; i<listOfMemberVars.count; i++) {
			FindVarParams var = (FindVarParams) listOfMemberVars.getItem(i);
			if (var.isThis || var.isSuper) continue;
			typeStartIndex = var.typeStartIndex();
			typeEndIndex = var.typeEndIndex();
						
			startIndexInmListOfAllVarUses = Compiler.getIndexInmListOfAllVarUses(src, classParams.listOfAllVarUsesForVar, 
					0, typeStartIndex, true);
			endIndexInmListOfAllVarUses = Compiler.getIndexInmListOfAllVarUses(src, classParams.listOfAllVarUsesForVar, 
					startIndexInmListOfAllVarUses, typeEndIndex, false);
			
			for (j=startIndexInmListOfAllVarUses; j<=endIndexInmListOfAllVarUses; j++) {
				FindVarUseParams varUse = (FindVarUseParams) classParams.listOfAllVarUsesForVar.getItem(j);
				if (varUse.originName.equals(templateVar.fieldName)) {
					varUse.varDecl = templateVar;
				}
			}
		}//for (i=0; i<listOfMemberVars.count; i++) {
		
		
		
		for (k=0; k<listOfFuncs.count; k++) {
			FindFunctionParams func = (FindFunctionParams) listOfFuncs.getItem(k);
			
			
			typeStartIndex = func.returnTypeStartIndex();
			typeEndIndex = func.returnTypeEndIndex();
			if (typeStartIndex!=-1 && typeEndIndex!=-1) {							
				startIndexInmListOfAllVarUses = Compiler.getIndexInmListOfAllVarUses(src, compiler.data.mlistOfAllVarUses, 
						0, typeStartIndex, true);
				endIndexInmListOfAllVarUses = Compiler.getIndexInmListOfAllVarUses(src, compiler.data.mlistOfAllVarUses, 
						startIndexInmListOfAllVarUses, typeEndIndex, false);
				
				for (j=startIndexInmListOfAllVarUses; j<=endIndexInmListOfAllVarUses; j++) {
					FindVarUseParams varUse = (FindVarUseParams) compiler.data.mlistOfAllVarUses.getItem(j);
					if (varUse.originName.equals(templateVar.fieldName)) {
						varUse.varDecl = templateVar;
					}
				}
			}
			
			ArrayListIReset listOfFuncArgs = func.listOfFuncArgs;
			for (i=0; i<listOfFuncArgs.count; i++) {
				FindVarParams var = (FindVarParams) listOfFuncArgs.getItem(i);
				if (var.isThis || var.isSuper) continue;
				typeStartIndex = var.typeStartIndex();
				typeEndIndex = var.typeEndIndex();
							
				startIndexInmListOfAllVarUses = Compiler.getIndexInmListOfAllVarUses(src, func.listOfAllVarUsesForVar, 
						0, typeStartIndex, true);
				endIndexInmListOfAllVarUses = Compiler.getIndexInmListOfAllVarUses(src, func.listOfAllVarUsesForVar, 
						startIndexInmListOfAllVarUses, typeEndIndex, false);
				
				for (j=startIndexInmListOfAllVarUses; j<=endIndexInmListOfAllVarUses; j++) {
					FindVarUseParams varUse = (FindVarUseParams) func.listOfAllVarUsesForVar.getItem(j);
					if (varUse.originName.equals(templateVar.fieldName)) {
						varUse.varDecl = templateVar;
					}
				}
			}//for (i=0; i<listOfFuncArgs.count; i++) {
			
			ArrayListIReset listOfLocalVars = func.listOfVariableParams;
			for (i=0; i<listOfLocalVars.count; i++) {
				FindVarParams var = (FindVarParams) listOfLocalVars.getItem(i);
				if (var.isThis || var.isSuper) continue;
				typeStartIndex = var.typeStartIndex();
				typeEndIndex = var.typeEndIndex();
							
				startIndexInmListOfAllVarUses = Compiler.getIndexInmListOfAllVarUses(src, func.listOfAllVarUsesForVar, 
						0, typeStartIndex, true);
				endIndexInmListOfAllVarUses = Compiler.getIndexInmListOfAllVarUses(src, func.listOfAllVarUsesForVar, 
						startIndexInmListOfAllVarUses, typeEndIndex, false);
				
				for (j=startIndexInmListOfAllVarUses; j<=endIndexInmListOfAllVarUses; j++) {
					FindVarUseParams varUse = (FindVarUseParams) func.listOfAllVarUsesForVar.getItem(j);
					if (varUse.originName.equals(templateVar.fieldName)) {
						varUse.varDecl = templateVar;
					}
				}
			}//for (i=0; i<listOfFuncArgs.count; i++) {
		}//for (k=0; k<listOfFuncs.count; k++) {
	}
		
	
	/** mlistOfAllTemplates에서 leftPair로 템플릿을 찾아 리턴한다. rightPair는 아무 값이나 넣어도 된다.*/
	public static Template getTemplate(Compiler compiler, int leftPair, int rightPair) {
		ArrayListIReset list = compiler.data.mlistOfAllTemplates;
		int i;
		for (i=0; i<list.count; i++) {
			Template t = (Template) list.getItem(i);
			if (t.indexLeftPair()==leftPair/* && t.indexRightPair==rightPair*/)
				return t;
		}
		return null;
	}
	
	/** fullname이 템플릿이면 템플릿 괄호 안에 있는 타입을 리턴한다. 템플릿이 아니면 null을 리턴한다.*/
	public static String getTemplateTypeInPair(String fullname) {
		int indexTemplateLeftPair = fullname.indexOf("<");
		
		String r = null;
		if (indexTemplateLeftPair!=-1) {			
			int indexTemplateRightPair = 
					Checker.CheckParenthesis(fullname, "<", ">", 
							indexTemplateLeftPair, fullname.length()-1, false);
			if (indexTemplateRightPair==-1) return null;
			else {
				r = fullname.substring(indexTemplateLeftPair+1, indexTemplateRightPair);
				return r;
			}
		}
		return null;
	}
	
	/** fullname이 템플릿이면 템플릿을 제거한 원래 타입이름을 리턴한다.템플릿이 아니면 원래 이름을 리턴한다.*/
	public static String getTemplateOriginalType(String fullname) {
		if (fullname==null) {
			return null;
		}
		int indexTemplateLeftPair = fullname.indexOf("<");
		
		String r = null;
		if (indexTemplateLeftPair!=-1) {
			r = fullname.substring(0, indexTemplateLeftPair);
			return r;
		}
		return fullname;
	}
	
	public static String getTemplateType(String typeName, String templateStr) {
		String r = typeName + templateStr;
		return r;
	}
	
	
}
