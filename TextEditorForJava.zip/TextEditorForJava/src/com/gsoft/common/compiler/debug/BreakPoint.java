package com.gsoft.common.compiler.debug;

import android.graphics.Point;

import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.CompilerCache;
import com.gsoft.common.compiler.CompilerStatic;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.bytecode.TypeDescriptor;
import com.gsoft.common.compiler.util.Builder.RunOrDebug;
import com.gsoft.common.util.Array;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListInt;
import com.gsoft.common.util.Sort;
import com.gsoft.dependent.ClassFileRunner;

public class BreakPoint {
	public String fullClassName;
	public int lineNumber;
	public boolean isUsed = true;
	
	/**BreakPoint[], temporary breakpoints, not user-defined*/
	public static ArrayList listOfoldBreakPointForStepOver = new ArrayList(30);
	/**temporary breakpoints, not user-defined*/
	public static BreakPoint oldBreakPointForStepOver;
	
	/** Debug시에 이동한 화살표가 그려지는 라인, drawLineLocation()을 참조한다.*/
	public static BreakPoint lineNumberShowingArrow = null;
	
	
	
	public BreakPoint(String fullClassName, int oldBreakPointForStepOver) {
		this.fullClassName = fullClassName;
		this.lineNumber = oldBreakPointForStepOver;
	}
	
	public static String removeAllBreakpoints(RunOrDebug runOrDebug) {
		if (runOrDebug!=RunOrDebug.Debug) {
			// null, run mode
			int i;
			for (i=0; i<CompilerCache.listOfCompilers.count; i++) {
				Compiler compiler = (Compiler) CompilerCache.listOfCompilers.getItem(i);
				compiler.data.listOfBreakPoints.reset2();
			}
		}
		else {
			String listOfClears = getAllBreakpoints(false);
			int i;
			for (i=0; i<CompilerCache.listOfCompilers.count; i++) {
				Compiler compiler = (Compiler) CompilerCache.listOfCompilers.getItem(i);
				compiler.data.listOfBreakPoints.reset2();
			}			
			return listOfClears;
		}
		return null;
	}
	
	public static void resetAllLineNumbersShowingArrow() {
		int i;
		for (i=0; i<CompilerCache.listOfCompilers.count; i++) {
			Compiler compilerLocal = (Compiler) CompilerCache.listOfCompilers.getItem(i);
			compilerLocal.data.lineNumberShowingArrow = null;
		}
		lineNumberShowingArrow = null;
	}
	
	public static String getAllBreakpoints(boolean stopOrClear) {
		int i, j;
		String r = "";
		// Apply all breakpoints in all java files to debug mode
		for (j=0; j<CompilerCache.listOfCompilers.count; j++) {
			Compiler compilerLocal = (Compiler) CompilerCache.listOfCompilers.getItem(j);
			ArrayListInt listOfBreakPoints = null;
			if (compilerLocal!=null) {
				listOfBreakPoints = compilerLocal.data.listOfBreakPoints;
			}
			
			int countOfBreakPoints = 0;
			for (i=0; i<listOfBreakPoints.count; i++) {
				int lineNumber = listOfBreakPoints.getItem(i);
				if (lineNumber==-1) continue;
				countOfBreakPoints++;
			}
			
			if (countOfBreakPoints>0) {
				listOfBreakPoints.list = Array.Resize(listOfBreakPoints.list, listOfBreakPoints.count);
				Sort.sort(listOfBreakPoints.list);
				
				for (i=0; i<listOfBreakPoints.count; i++) {
					int lineNumber = listOfBreakPoints.getItem(i);
					if (lineNumber==-1) continue;
					for (int q=0; q<compilerLocal.data.mlistOfClass.count; q++) {
						FindClassParams topMostClass = (FindClassParams) compilerLocal.data.mlistOfClass.getItem(q);
						int indexInmBuffer = CompilerStatic.getIndexOfStartInmBuffer(compilerLocal, lineNumber-1);
						FindClassParams parentClass = CompilerStatic.findParentClass(topMostClass, indexInmBuffer);
						if (parentClass==null) continue;
						String binaryName = TypeDescriptor.toBinaryName(parentClass.name, 0);
						
						if (stopOrClear) {
							r += "stop at " + binaryName + ":" + lineNumber + "\r\n";
						}
						else {
							r += "clear " + binaryName + ":" + lineNumber + "\r\n";
						}
						break;
					}
				}
			}
		}// for j
		return r;
	}
	
	public static void clearBreakPointsForStepOver() {
		int i;
		ClassFileRunner.resetDebugCommand();
		//if (oldCountOflistOfoldBreakPointForStepOver==listOfoldBreakPointForStepOver.count) return;
		//oldCountOflistOfoldBreakPointForStepOver = listOfoldBreakPointForStepOver.count;
		
		for (i=0; i<listOfoldBreakPointForStepOver.count; i++) {
			BreakPoint oldBreakPoint =  (BreakPoint) listOfoldBreakPointForStepOver.getItem(i);
			if (oldBreakPoint!=null && oldBreakPoint.isUsed && isUserDefinedBreakPoint(oldBreakPoint)==-1) {
				Compiler compilerLocal = CompilerCache.findCompilerWithfullClassName(oldBreakPoint.fullClassName);
				for (int q=0; q<compilerLocal.data.mlistOfClass.count; q++) {
					FindClassParams topMostClass = (FindClassParams) compilerLocal.data.mlistOfClass.getItem(q);
					int indexInmBuffer = CompilerStatic.getIndexOfStartInmBuffer(compilerLocal, oldBreakPoint.lineNumber-1);
					FindClassParams parentClass = CompilerStatic.findParentClass(topMostClass, indexInmBuffer);
					if (parentClass==null) continue;
					String binaryName = TypeDescriptor.toBinaryName(parentClass.name, 0);
					
					ClassFileRunner.addToDebugCommand("clear " +binaryName + ":" + oldBreakPoint.lineNumber + "\r\n");
					oldBreakPoint.isUsed = false;
					break;
				}
			}
		}
		oldBreakPointForStepOver = null;
	}
	
	public static void toggleBreakPointForStepOver(Compiler compiler, int nextLineNumber) {
		FindClassParams parentClass = null;
		for (int q=0; q<compiler.data.mlistOfClass.count; q++) {
			FindClassParams topMostClass = (FindClassParams) compiler.data.mlistOfClass.getItem(q);
			int indexInmBuffer = CompilerStatic.getIndexOfStartInmBuffer(compiler, nextLineNumber-1);
			parentClass = CompilerStatic.findParentClass(topMostClass, indexInmBuffer);
			if (parentClass==null) continue;
			String binaryName = TypeDescriptor.toBinaryName(parentClass.name, 0);
			
			ClassFileRunner.addToDebugCommand("stop at " + binaryName + ":" + nextLineNumber + "\r\n");
			break;
		}
		
		oldBreakPointForStepOver = new BreakPoint(parentClass.name, nextLineNumber);
		listOfoldBreakPointForStepOver.add(oldBreakPointForStepOver);
	}
	
	public static int isUserDefinedBreakPoint(BreakPoint lineNumber) {
		Compiler compilerLocal = CompilerCache.findCompilerWithfullClassName(lineNumber.fullClassName);
		ArrayListInt listOfBreakPoints = null;
		if (compilerLocal!=null) {
			listOfBreakPoints = compilerLocal.data.listOfBreakPoints;
		}
		int i;
		for (i=0; i<listOfBreakPoints.count; i++) {
			int lineNumber2 = listOfBreakPoints.getItem(i);
			if (lineNumber2==lineNumber.lineNumber) {							
				return i;
			}
		}
		return -1;
	}
	
	public static int isUserDefinedBreakPoint(Compiler compiler, int lineNumber) {
		ArrayListInt listOfBreakPoints = null;
		if (compiler!=null) {
			listOfBreakPoints = compiler.data.listOfBreakPoints;
		}
		int i;
		for (i=0; i<listOfBreakPoints.count; i++) {
			int lineNumber2 = listOfBreakPoints.getItem(i);
			if (lineNumber2==lineNumber) {							
				return i;
			}
		}
		return -1;
	}
	
	public static void toggleBreakPoint(Compiler compiler, Point cursorPos) {
		int lineNumber = cursorPos.y + 1;
		
		FindClassParams parentClass = null;
		for (int q=0; q<compiler.data.mlistOfClass.count; q++) {
			FindClassParams topMostClass = (FindClassParams) compiler.data.mlistOfClass.getItem(q);
			int indexInmBuffer = CompilerStatic.getIndexOfStartInmBuffer(compiler, lineNumber-1);
			parentClass = CompilerStatic.findParentClass(topMostClass, indexInmBuffer);		
			
			if (parentClass==null) continue;
			break;
		}
		
		String binaryName = TypeDescriptor.toBinaryName(parentClass.name, 0);
		
		// Breakpoint를 이미 있으면 지우고 없으면 추가한다.
		int indexInlistOfBreakPoints = isUserDefinedBreakPoint(compiler, lineNumber);
		if (indexInlistOfBreakPoints==-1) {
			// Breakpoint를추가한다.
			compiler.data.listOfBreakPoints.add(lineNumber);
			ClassFileRunner.replaceDebugCommand("stop at "+binaryName + ":" + lineNumber + "\r\n");
		}
		else {
			// Breakpoint를 지운다.
			compiler.data.listOfBreakPoints.list[indexInlistOfBreakPoints] = -1;
			ClassFileRunner.replaceDebugCommand("clear "+binaryName + ":" + lineNumber + "\r\n");
		}
	}
	
	
	/** Debug시에 이동한 라인을 설정한다.*/
	public static void setLineNumberShowingArrow(String fullClassName, int lineNumber) {
		if (lineNumberShowingArrow==null) {
			lineNumberShowingArrow = new BreakPoint(null, -1);
		}
		lineNumberShowingArrow.fullClassName = fullClassName;
		lineNumberShowingArrow.lineNumber = lineNumber;
	}
	
	
	
}
