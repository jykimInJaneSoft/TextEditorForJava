package com.gsoft.common.compiler.debug;

import java.io.File;

import com.gsoft.common.Code.CodeChar;
import com.gsoft.common.Code.CodeString;
import com.gsoft.common.CommonGUI;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.Events.MotionEvent;
import com.gsoft.common.FileHelper;
import com.gsoft.common.Sizing.Rectangle;
import com.gsoft.common.compiler.ClassCache;
import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.CompilerInterface;
import com.gsoft.common.compiler.CompilerStatic;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.Compiler_types.FindControlBlockParams;
import com.gsoft.common.compiler.Compiler_types.FindVarParams;
import com.gsoft.common.compiler.Compiler_types.FindVarUseParams;
import com.gsoft.common.compiler.Compiler_types.LoadWayOfFindClassParams;
import com.gsoft.common.compiler.Compiler_types_Base.Block;
import com.gsoft.common.compiler.Compiler_types_Base.FindStatementParams;
import com.gsoft.common.compiler.Compiler_types_Special.FindSpecialStatementParams;
import com.gsoft.common.compiler.Fullname;
import com.gsoft.common.compiler.Number;
import com.gsoft.common.compiler.util.Builder;
import com.gsoft.common.gui.TextView;
import com.gsoft.common.gui.edittext.Edit.ScrollMode;
import com.gsoft.common.util.HighArray;
import com.gsoft.dependent.ClassFileRunner;

import com.gsoft.common.compiler.debug.BreakPoint;

public class DebugView extends TextView {

	public DebugView(boolean hasToolbarAndMenuFontSize,
			boolean isDockingOfToolbarFlexiable, Object owner, String name,
			Rectangle paramBounds, float fontSize, boolean isSingleLine,
			CodeString text, ScrollMode scrollMode, int backColor) {
		super(hasToolbarAndMenuFontSize, isDockingOfToolbarFlexiable, owner, name,
				paramBounds, fontSize, isSingleLine, text, scrollMode, backColor);
		
	}
	
	
	/**DebugView창에 var의 값을 출력한다. When user clicks a local var in editText_compiler.*/
	public void callDebugCommand(FindVarParams var) {
		if (var!=null) {
			if (!var.isMemberOrLocal) {
				// local var
				if (CompilerHelper.IsDefaultType(var.typeName)) {
					ClassFileRunner.inputPrintDebugCommand(var.fieldName);
				}
				else {
					ClassFileRunner.inputDumpDebugCommand(var.fieldName);	
				}				
			}
		}
	}
	
	/**DebugView창에 varUse의 값을 출력한다. When user clicks a var use in editText_compiler. */
	public void callDebugCommand(FindVarUseParams varUse) {
		FindVarParams var = varUse.varDecl;
		Compiler compiler = CommonGUI.editText_compiler.getCompiler();
		
		if (var!=null) {
			if (!var.isMemberOrLocal) {
				// local var
				if (CompilerHelper.IsDefaultType(var.typeName)) {
					ClassFileRunner.inputPrintDebugCommand(var.fieldName);
				}
				else {
					ClassFileRunner.inputDumpDebugCommand(var.fieldName);	
				}				
			}
			else {
				// member var
				int fullNameStartIndex = Fullname.getFullNameIndex(compiler, true, varUse.index(), false);
				fullNameStartIndex = CompilerHelper.SkipBlank(compiler.data.mBuffer, false, fullNameStartIndex, compiler.data.mBuffer.count-1);
				String varUseName = compiler.data.mBuffer.getItem(fullNameStartIndex).str;
				FindVarUseParams varUseOfFirst = 
						CompilerStatic.getVarUseWithIndex(compiler.data.mlistOfAllVarUsesHashed, varUseName, fullNameStartIndex);
				
				//int fullNameEndIndex = Fullname.getFullNameIndex(this, false, varUse.index(), false);
				//fullNameEndIndex = CompilerHelper.SkipBlank(this.data.mBuffer, true, 0, fullNameEndIndex);
				
				String fullNameOfFirst = "";
				String fullName = null;
				
				String fullNameOfRemaniders = Fullname.getFullName(compiler.data.mBuffer, fullNameStartIndex, varUse.index()).str;
				
				if (varUseOfFirst.varDecl!=null) {
					if (!varUseOfFirst.varDecl.isMemberOrLocal) {
						fullName = fullNameOfRemaniders;
					}
					else {
						if (varUseOfFirst.varDecl.accessModifier.isStatic) {
							String parentClassName = ((FindClassParams)varUseOfFirst.varDecl.parent).name;
							fullNameOfFirst = parentClassName;						
						}
						else {
							fullNameOfFirst = "this";
						}
						if (fullNameOfRemaniders.equals("this")) {
							fullName = fullNameOfRemaniders;
						}
						else if (fullNameOfRemaniders.equals("super")) {
							// Changes super to this.
							fullName = "this";
						}
						else {
							int indexOfThis = fullNameOfRemaniders.indexOf("this.");
							if (indexOfThis==-1) {
								fullName = fullNameOfFirst + "." + fullNameOfRemaniders;
							}
							else {
								// fullNameOfRemaniders has this.
								fullName = fullNameOfRemaniders;
							}
						}
					}
				}
				else if (varUseOfFirst.funcDecl!=null) {
					if (varUseOfFirst.funcDecl.accessModifier.isStatic) {
						String parentClassName = ((FindClassParams)varUseOfFirst.funcDecl.parent).name;
						fullNameOfFirst = parentClassName;						
					}
					else {
						fullNameOfFirst = "this";
					}
					int indexOfThis = fullNameOfRemaniders.indexOf("this.");
					if (indexOfThis==-1) {
						fullName = fullNameOfFirst + "." + fullNameOfRemaniders;
					}
					else {
						// fullNameOfRemaniders has this.
						fullName = fullNameOfRemaniders;
					}
				}
				else if (varUseOfFirst.memberDecl!=null) {	
					if (varUseOfFirst.memberDecl instanceof FindClassParams) {
						// java.lang.System at System.out
						String parentClassName = ((FindClassParams)varUseOfFirst.memberDecl).name;
						// java.lang
						String fullNameTypeOfFirst = FileHelper.getFilenameExceptExt(parentClassName);
						fullNameOfFirst = fullNameTypeOfFirst;	
						fullName = fullNameOfFirst + "." + fullNameOfRemaniders;
					}
					else {
						// com.gsoft.common.Events.MotionEvent.ActionDoubleClicked
						fullName = fullNameOfRemaniders;
					}
				}				
				
				if (CompilerHelper.IsDefaultType(var.typeName)) {
					ClassFileRunner.inputPrintDebugCommand(fullName);
				}
				else {
					ClassFileRunner.inputDumpDebugCommand(fullName);
				}
				
			}
			
			
		}// if (var!=null) {
		else if (varUse.memberDecl!=null) {
			if (varUse.memberDecl instanceof FindClassParams) {
				// java.lang.System at System
				// com.gsoft.hardware.HardwareKeyboard
				String className = ((FindClassParams)varUse.memberDecl).name;
				String fullName = className;
				ClassFileRunner.inputDumpDebugCommand(fullName);
			}
		}
	}
	
	
	String getLine() {
		return this.textArray[this.cursorPos.y].str;
	}
	
	/**main[1]  com.gsoft.common.gui.Control.activity = {<br>
	    android.app$Activity.context: instance of android.content$Context(id=1030)<br>
	    android.app$Activity.window: instance of android.view$Window(id=1031)<br>
	}<br>
	Gets com.gsoft.common.gui.Control.activity*/
	String getVarFullName() {
		int i;
		for (i=cursorPos.y-1; i>=0; i--) {
			String line = textArray[i].str;
			int indexOfEqualAndLeftPair = line.indexOf(" = {"); 
			if (indexOfEqualAndLeftPair!=-1) {
				String varFullName = line.substring(0, indexOfEqualAndLeftPair);
				int indexOfBlank = varFullName.indexOf(" ");
				if (indexOfBlank!=-1) {
					varFullName = varFullName.substring(indexOfBlank+1, varFullName.length());
					varFullName = varFullName.trim();
					return varFullName;
				}
			}
		}
		return null;
	}
	
	public static HighArray lineBuf = new HighArray(100);
	
	
	public boolean isArrayLine(int cursorPosY) {
		String curLine = this.textArray[cursorPosY].str;
		if (curLine.contains(", [")) {
			return true;
		}
		return false;
	}
	
	/** main[1]  arr = {<br>
		instance of com.gsoft.texteditor14.MainActivity(id=1030), "JAVA", instance of com.gsoft.common.util.Util$ControlStack(id=1032)<br>
	}<br>
	posY is a first line of array. Returns index of the last line. 
	If not arry, returns -1
	*/
	public int isArray(int posY) {
		if (posY>=0) {
			String curLine = this.textArray[posY].str;
			if (!curLine.contains(" = {")) {
				return -1;
			}
		}
		int rY = posY+1;
		String line = this.textArray[rY].str;
		int indexOfComma = line.indexOf(", ");
		
		if (indexOfComma!=-1) {
			while (true) {
				line = this.textArray[rY].str;
				indexOfComma = line.indexOf(", ");
						
				if (indexOfComma!=-1) {
					if (rY+1<this.numOfLines) {
						String nextLine = this.textArray[rY+1].str;
						if (nextLine.equals("}\n") || nextLine.contains("null\n")) {
							return rY+1;
						}
						rY++;
						continue;
					}					
					return rY;
				}
				return rY;				
			}
		}
		return -1;
	}
	
	public static class RuturnOfinputSubscriptionToArray {
		public CodeString newLine;
		public int countOfComma;
	}
	
	
	/**
	 * @param startOfArray : included
	 * @param endOfArray : included
	 */
	public int inputSubscriptionToArray(int startOfArray, int endOfArray) {
		/** main[1]  arr = {
		instance of com.gsoft.texteditor14.MainActivity(id=1030), "JAVA", instance of com.gsoft.common.util.Util$ControlStack(id=1032)
			}
		*/
		
		lineBuf.reset();
		
		int i, j;
		for (j=startOfArray; j<=endOfArray; j++) {
			CodeString line = this.textArray[j];
			// except array head and tail
			if (line.str.contains(", ")) {
				for (i=0; i<line.length(); i++) {
					CodeChar c = line.charAt(i);
					//if (c.c=='\n' || c.c=='\r') continue;
					lineBuf.add(c);
				}
			}
		}
		
		
		HighArray newArray = new HighArray(100);
	
		// array head
		CodeString arrayHead = this.textArray[startOfArray]; 
		if (!arrayHead.str.contains(", ")) {
			for (i=0; i<arrayHead.count; i++) {
				newArray.add(arrayHead.charAt(i));
			}
		}
			
		CodeString subscription = new CodeString("["+0+"]", Common_Settings.keywordColor);		
		newArray.add(subscription.listCodeChar);
		
		int indexOfSubscription = 1;
		
		boolean inputedNewLine = false;
		
		// array body
		for (i=0; i<lineBuf.count; i++) {
			CodeChar c = (CodeChar) lineBuf.getItem(i);			
			if (c.c==',' &&  (i+1<lineBuf.count && ((CodeChar)lineBuf.getItem(i+1)).c!=',') ) {
				if (indexOfSubscription % 10 == 0) {
					if (!inputedNewLine) {
						newArray.add(c); // ','
						newArray.add(new CodeChar('\n', Common_Settings.textColor));
						i = i-1;
						inputedNewLine = true;
						continue;
					}
					inputedNewLine = false;
				}
				else {
					newArray.add(c); // ','
					newArray.add(lineBuf.getItem(i+1)); // space
				}
				
				subscription = new CodeString("["+(indexOfSubscription)+"]", Common_Settings.keywordColor);	
				newArray.add(subscription.listCodeChar);
				
				indexOfSubscription++;
			}
			else {
				newArray.add(c);
			}
		}
		
		// array tail
		CodeString arrayTail = this.textArray[endOfArray]; 
		if (arrayTail.str.contains(", ")) {
			newArray.add(new CodeChar('\n', Common_Settings.textColor));
			CodeString newArrayTail = new CodeString("}\n", Common_Settings.textColor);
			int k;
			for (k=0; k<newArrayTail.count; k++) {
				newArray.add(newArrayTail.charAt(k));
			}
		}
		else if (arrayTail.str.contains("null")) {
			int k;
			for (k=0; k<arrayTail.count; k++) {
				newArray.add(arrayTail.charAt(k));
			}
			newArray.add(new CodeChar('\n', Common_Settings.textColor));
			
			CodeString newArrayTail = new CodeString("}\n", Common_Settings.textColor);
			for (k=0; k<newArrayTail.count; k++) {
				newArray.add(newArrayTail.charAt(k));
			}
		}
		else if (arrayTail.str.contains("}")) {
			int k;
			for (k=0; k<arrayTail.count; k++) {
				newArray.add(arrayTail.charAt(k));
			}
		}
		
		
		CodeChar[] r = new CodeChar[newArray.count];
		int k;
		for (k=0; k<r.length; k++) {
			r[k] = (CodeChar) newArray.getItem(k);
		}
		
		CodeString newArrayHeadBodyTail = new CodeString(r, r.length);
		int numOfLinesToDelete = endOfArray-startOfArray+1;
		
		this.setTextMultiLineBoth(startOfArray, newArrayHeadBodyTail, numOfLinesToDelete);
		
		int numOfLinesAdded = this.getNumOfNewLineChar(newArrayHeadBodyTail) + 1;
		if (newArrayHeadBodyTail.charAt(newArrayHeadBodyTail.count-1).c=='\n') {
			numOfLinesAdded--;
		}
		return numOfLinesAdded;
	}
	
	
	/** makes temporary breakpoints and jumps there*/
	public void stepOver(Compiler compiler) {
		BreakPoint.clearBreakPointsForStepOver();
		
		
		int nextLineNumber = -1;
		BreakPoint curDebugLineNubmer = BreakPoint.lineNumberShowingArrow;
		int indexInmBuffer = CompilerStatic.getIndexOfStartInmBuffer(compiler, curDebugLineNubmer.lineNumber-1);
		indexInmBuffer = CompilerHelper.SkipBlank(compiler.data.mBuffer, false, indexInmBuffer, compiler.data.mBuffer.count-1);
		
		FindStatementParams curStatement = null;
		for (int q=0; q<compiler.data.mlistOfClass.count; q++) {
			FindClassParams topMostClass = (FindClassParams) compiler.data.mlistOfClass.getItem(q);
			
			curStatement = ((CompilerInterface)compiler).findStatement_main_debuging( topMostClass, indexInmBuffer);
			if (curStatement==null) continue;
			break;
		}
		if (curStatement instanceof FindControlBlockParams) {
			FindControlBlockParams controlBlock = (FindControlBlockParams) curStatement;
			if (compiler.data.mBuffer.getItem(indexInmBuffer).equals("}")) {
				// end index of control block
				ClassFileRunner.addToDebugCommand("step\r\n");
				return;
			}
			if (controlBlock.listOfStatements.count>0) {
				// Breakpoints is two. One is first statement of control block. Two is next statement of control block.
				int nextLineNumber_innerBlock;
				nextLineNumber_innerBlock = this.findNextStatement(compiler, controlBlock, -1);
				BreakPoint.toggleBreakPointForStepOver(compiler, nextLineNumber_innerBlock);
			}
		}
		
		if (curStatement!=null) {
			if (curStatement instanceof FindSpecialStatementParams) {
				FindSpecialStatementParams specialStatement = (FindSpecialStatementParams) curStatement;
				CodeString keyword = compiler.data.mBuffer.getItem(specialStatement.kewordIndex()); 
				if (keyword.equals("return")) {
					// converts "step over" to "step up"
					ClassFileRunner.addToDebugCommand("step up\r\n");
					return;
				}
				else if (keyword.equals("continue") || keyword.equals("break")) {						
					ClassFileRunner.addToDebugCommand("step\r\n");
					return;
				}
			}
			Block parentBlock = curStatement.parent;
			int indexInlistOfStatements = parentBlock.findStatement(curStatement);
			if (indexInlistOfStatements!=-1) {
				nextLineNumber = this.findNextStatement(compiler, parentBlock, indexInlistOfStatements);
			}
		}
		
		if (nextLineNumber!=-1) {
			//BreakPoint.clearBreakPointsForStepOver();
			BreakPoint.toggleBreakPointForStepOver(compiler, nextLineNumber);
			ClassFileRunner.addToDebugCommand("resume\r\n");
		}
		else {
			//BreakPoint.clearBreakPointsForStepOver();
			ClassFileRunner.addToDebugCommand("step\r\n");
		}
	}
	
	

	/** 
	 * @param compiler : current document
	 * @param parentBlock : parent block
	 * @param indexInlistOfStatements : current statement
	 * @return
	 */
	int findNextStatement(Compiler compiler, Block parentBlock, int indexInlistOfStatements) {
		int nextLineNumber = -1;
		if (indexInlistOfStatements+1<parentBlock.listOfStatements.count) {
			FindStatementParams nextStatement =  (FindStatementParams) parentBlock.listOfStatements.getItem(indexInlistOfStatements+1);
			
			while (true) {
				// When nextStatement is try or else
				if (nextStatement instanceof FindControlBlockParams) {
					FindControlBlockParams nextControlBlock = (FindControlBlockParams) nextStatement;
					String nextControlBlockName = nextControlBlock.getName(); 
					if (nextControlBlockName.equals("try")) {
						if (nextControlBlock.listOfStatements.count>0) {
							// first statement in try
							nextStatement = (FindStatementParams) nextControlBlock.listOfStatements.getItem(0);
							continue;
						}
						else {
							// end index of block
							nextLineNumber = CompilerStatic.getCursorPosYInSrc(compiler, nextControlBlock.endIndex()) + 1;
							if (nextLineNumber==0) nextLineNumber = -1;
							return nextLineNumber;
						}
					}
					else if (nextControlBlockName.equals("else")) {
						if (nextControlBlock.listOfStatements.count>0) {
							// first statement in else
							nextStatement = (FindStatementParams) nextControlBlock.listOfStatements.getItem(0);
							continue;
						}
						else {
							// move to next statement of else
							if (indexInlistOfStatements+2<parentBlock.listOfStatements.count) {
								nextStatement =  (FindStatementParams) parentBlock.listOfStatements.getItem(indexInlistOfStatements+2);
							}
							else {
								// end index of block
								if (this.isElse(compiler, parentBlock)) {
									return this.findNextStatementOfElse(compiler, parentBlock);
								}
								nextLineNumber = CompilerStatic.getCursorPosYInSrc(compiler, parentBlock.endIndex()) + 1;
								if (nextLineNumber==0) nextLineNumber = -1;
								return nextLineNumber;
							}
						}
					}
					else {
						break;
					}
				}// if (nextStatement instanceof FindControlBlockParams) {
				else {
					break;
				}
			}// while(true)
			
			if (nextStatement!=null) {
				nextLineNumber = CompilerStatic.getCursorPosYInSrc(compiler, nextStatement.startIndex()) + 1;
			}
		}
		else {
			// last statement in parentBlock
			if (this.isElse(compiler, parentBlock)) {
				return this.findNextStatementOfElse(compiler, parentBlock);
			}
			nextLineNumber = CompilerStatic.getCursorPosYInSrc(compiler, parentBlock.endIndex()) + 1;
			if (nextLineNumber==0) nextLineNumber = -1;
		}
		return nextLineNumber;
		
		
	}
	
	
	boolean isElse(Compiler compiler, Block block) {
		if (block instanceof FindControlBlockParams) {
			FindControlBlockParams c = (FindControlBlockParams) block;
			if (c.getName().equals("else")) return true;
		}
		return false;
	}
	
	int findNextStatementOfElse(Compiler compiler, Block elseBlock) {
		Block parentBlock = elseBlock.parent;
		int indexInlistOfStatements = parentBlock.findStatement(elseBlock);
		int nextLineNumber = this.findNextStatement(compiler, parentBlock, indexInlistOfStatements);
		return nextLineNumber;
	}
	
	public void onTouchEvent(Object sender, MotionEvent e) {
		super.onTouchEvent(sender, e);
		
		if (sender==this) {
			if (e.actionCode!=MotionEvent.ActionDown) {
				return;
			}
			
			String line = this.getLine();
			int indexOfInstanceOf = line.indexOf(": instance of");
			int indexOfdotAndJava = line.indexOf(".java:");
			
			if (this.isArrayLine(this.cursorPos.y)) {
				/** main[1]  arr = {
						instance of com.gsoft.texteditor14.MainActivity(id=1030), "JAVA", instance of com.gsoft.common.util.Util$ControlStack(id=1032)
					}
				*/

				
				int i, j;
				int startIndexOfSubscription = 0;
				int endIndexOfSubscription = 0;
				CodeString curLine = this.textArray[this.cursorPos.y];
				
				if (this.cursorPos.x>=curLine.length()) return;
				
				for (i=this.cursorPos.x; i>=0; i--) {
					char c = curLine.charAt(i).c;
					if (c==',') {
						break;
					}
				}
				
				if (i==-1) {
					// ',' not exists
					i = 0;
				}
				
				for (j=i; j<curLine.length(); j++) {
					char c = curLine.charAt(j).c;
					if (c=='[') {
						startIndexOfSubscription = j;
					}
					else if (c==']') {
						endIndexOfSubscription = j;
						break;
					}
				}
				int resultIndex = -1;
				if (endIndexOfSubscription!=0 &&
						startIndexOfSubscription < endIndexOfSubscription) {
					resultIndex = Number.parseIntAfterErasingComma(
						curLine.substring(startIndexOfSubscription+1, endIndexOfSubscription).str);
					
					// arr
					String arrFullName = this.getVarFullName();
					// arr[count]
					String varFullName = arrFullName + "["+resultIndex+"]";
					ClassFileRunner.inputDumpDebugCommand(varFullName);
					
					return;
				}
				
			
			
			}// if (indexOfComma!=-1) {
			else {
				if (indexOfInstanceOf!=-1) {
					// variable value
					/**main[1]  com.gsoft.common.gui.Control.activity = {
						    android.app$Activity.context: instance of android.content$Context(id=1030)
						    android.app$Activity.window: instance of android.view$Window(id=1031)
					}*/
	
					String varFullName = this.getVarFullName();
					String varName = line.substring(0, indexOfInstanceOf);
					varName = varName.trim();
					varName = varName.replace('$', '.');
					// gets context in android.app$Activity.context
					String shortName = CompilerHelper.getShortName(varName);
					// com.gsoft.common.gui.Control.activity + "." + context
					varFullName = varFullName+"."+shortName;
					ClassFileRunner.inputDumpDebugCommand(varFullName);
					
					return;
					
				}//if (indexOfInstanceOf!=-1) {
				else if (indexOfdotAndJava!=-1) {
					this.open(false);
					
					// location in where
					
					// Gets com.gsoft.texteditor14.MainActivity.main 
					// in "main[1]   [1] com.gsoft.texteditor14.MainActivity.main (MainActivity.java:46)"
					int indexOfLeftPair = line.indexOf("(");
					String loc = line.substring(0, indexOfLeftPair);
					int indexOfRightPair = loc.indexOf("]");
					loc = loc.substring(indexOfRightPair+1, loc.length());
					indexOfRightPair = loc.indexOf("]");
					if (indexOfRightPair!=-1) {
						// "main[1]   [1] com.gsoft.texteditor14.MainActivity.main (MainActivity.java:46)"
						loc = loc.substring(indexOfRightPair+1, loc.length());
					}
					loc = loc.trim();
					
					// Gets MainActivity.java:46
					indexOfLeftPair = line.indexOf("(");
					indexOfRightPair = line.indexOf(")");
					String fileNameAndLineNumber = line.substring(indexOfLeftPair+1, indexOfRightPair);
					fileNameAndLineNumber = fileNameAndLineNumber.trim();
					
					int indexOfColon = fileNameAndLineNumber.indexOf(":");
					String fileName = fileNameAndLineNumber.substring(0, indexOfColon);
					String strLineNumber = fileNameAndLineNumber.substring(indexOfColon+1, fileNameAndLineNumber.length());
					int lineNumber = Number.parseIntAfterErasingComma(strLineNumber);
					
					String fileNameExceptExt = FileHelper.getFilenameExceptExt(fileName);
					int indexOffileNameExceptExt = loc.indexOf(fileNameExceptExt);
					int endIndex = indexOffileNameExceptExt + fileNameExceptExt.length();
					String fullClassName = loc.substring(0, endIndex);
					
					
					FindClassParams classParams = 
							ClassCache.getFindClassParams(CompilerStatic.mlistOfAllClassesHashed[0], null, fullClassName, 0);
					
					FindClassParams classInSrc = null;
					if (classParams!=null && classParams.loadWayOfFindClassParams==LoadWayOfFindClassParams.Start2) {				
						classInSrc = classParams;
					}
					else {
						String slashedFullname = fullClassName.replace('.', File.separatorChar);
						File srcFile = CompilerStatic.getAbsPath_FromVariousClassPath(2, slashedFullname);
						if (srcFile!=null) {
							classInSrc = Builder.start2_usingCache(srcFile.getAbsolutePath(), fullClassName, 0);
						}
					}
					//if (classInSrc!=null) {
						CommonGUI.editText_compiler.moveToLineNumber(classInSrc, lineNumber, true, fullClassName, false);
					//}
						return;
				}// else if (indexOfdotAndJava!=-1) {
			}
		}//if (sender==this) {
		
	}
	
	
	
}
