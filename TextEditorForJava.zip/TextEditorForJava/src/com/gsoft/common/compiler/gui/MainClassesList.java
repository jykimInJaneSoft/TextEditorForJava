package com.gsoft.common.compiler.gui;

import android.graphics.Canvas;
import android.graphics.Color;

import com.gsoft.common.Code.CodeChar;
import com.gsoft.common.Code.CodeString;
import com.gsoft.common.CommonGUI;
import com.gsoft.common.Events.MotionEvent;
import com.gsoft.common.Sizing.Rectangle;
import com.gsoft.common.Sizing.Size;
import com.gsoft.common.Sizing.SizeF;
import com.gsoft.common.interfaces.OnTouchListener;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.HighArray_CodeString;
import com.gsoft.common.gui.Buttons.Button;
import com.gsoft.common.gui.Buttons.ButtonGroup;
import com.gsoft.common.gui.Control.Container;
import com.gsoft.common.gui.MenuWithScrollBar;
import com.gsoft.common.gui.Pool.PoolOfButton;
import com.gsoft.common.gui.edittext.Edit.ScrollMode;

public class MainClassesList extends Container implements OnTouchListener 
{
	MenuWithScrollBar menuMainClassesList;
	private PoolOfButton poolOfFileListButtons;
	Size buttonSize;
	public int countOfNewLineChars;
	
	//Compiler compiler;
	
	public MainClassesList(/*Compiler compiler,*/ Rectangle bounds, Size buttonSize) {
		//this.compiler = compiler;
		this.bounds = bounds;
		this.buttonSize = buttonSize;
		createMenuList();
		createPoolOfFileListButtons();
	}
	
	public void setBackColor(int backColor) {
		menuMainClassesList.setBackColor(backColor);
	}
	
	/** 영역만 잡아주고 menuClassAndMemberList 내용(Button[])은 나중에 createAndSetFileListButtons를
	 * 통해 넣어준다. 
	 * @param dir
	 * @param curDir
	 * @param category
	 */
	private void createMenuList() {
		if (menuMainClassesList==null) {
			menuMainClassesList = new MenuWithScrollBar(this, bounds, 
					buttonSize, 
					ScrollMode.VScroll);
			menuMainClassesList.setBackColor(backColor);
			menuMainClassesList.setOnTouchListener(this); // MenuWithScrollbar의 listener				
		}
	}
	
	/** FileListButtons 의 Pool을 활용하여 디렉토리를 바꿀 때마다 버튼들을 생성하지 않고 메모리를 절약한다.
	 * 즉 디렉토리를 바꾸면 버튼들을 새로 만드는 것이 아니라 pool에서 가져와서 버튼의 속성만 바꿔준다.
	 * (createFileListButtons참조)*/
	void createPoolOfFileListButtons() {
		if (poolOfFileListButtons==null) {
			poolOfFileListButtons = new PoolOfButton(50, buttonSize);
		}
	}
	
	/*void setSrcAndErrors(HighArray_CodeString src, ArrayListIReset mainClasses) {
	}*/
	
	/** mainClasses를 Button[]으로 리턴한다.
	 * @param namesOfMainClasses : String[]*/
	public Button[] getMenuListButtons(String[] namesOfMainClasses) {
		if (namesOfMainClasses==null) return null;
		
		int buttonCount = namesOfMainClasses.length + 1;
					
		int i;
		int buttonWidth = menuMainClassesList.originButtonWidth;
		int buttonHeight = menuMainClassesList.originButtonHeight;
		if (poolOfFileListButtons.list.capacity < buttonCount) {
			poolOfFileListButtons.setCapacity(buttonCount, buttonSize);
		}
		
		Button[] buttons = new Button[buttonCount];
		
		int color;
		
		String textOfButton0;
		if (namesOfMainClasses.length==0) {
			textOfButton0 = "No main classes";
		}
		else {
			textOfButton0 = "Back";
		}
		
		color = Color.BLUE;
		buttons[0] = (Button) poolOfFileListButtons.getItem(0);
		buttons[0].name = textOfButton0;
		buttons[0].bounds.x = 0;
		buttons[0].bounds.y = 0;
		buttons[0].bounds.width = buttonWidth;
		buttons[0].bounds.height = buttonHeight;
		buttons[0].setText(buttons[0].name);
		buttons[0].setBackColor(color);
		
		int buttonIndex = 1; 
		for (i=0; i<namesOfMainClasses.length; i++, buttonIndex++) {
			color = Color.BLUE;
			buttons[buttonIndex] = (Button) poolOfFileListButtons.getItem(buttonIndex);
			String name = namesOfMainClasses[i];
			buttons[buttonIndex].name = Integer.toString(i); // mainClasses에서의 index
			buttons[buttonIndex].bounds.x = 0;
			buttons[buttonIndex].bounds.y = 0;
			buttons[buttonIndex].bounds.width = buttonWidth;
			buttons[buttonIndex].bounds.height = buttonHeight;
			buttons[buttonIndex].setText(name);
			buttons[buttonIndex].setBackColor(color);
		}
		
		ButtonGroup group = new ButtonGroup(null, buttons);
		for (i=0; i<buttonCount; i++) {
			buttons[i].setGroup(group, i);
		}
		
		return buttons;
		
	}
	
			
	@Override
    public boolean onTouch(MotionEvent event, SizeF scaleFactor) {
    	boolean r=false;
    	if (event.actionCode==MotionEvent.ActionDown) {
	    	r = super.onTouch(event, scaleFactor);
	    	if (!r) {
	    		open(false);	// 영역에 상관없이 닫힌다.
	    		return true;
	    	}
	    	
	    	if (menuMainClassesList!=null) {
	    		r = menuMainClassesList.onTouch(event, null);
	    		if (r) return true;
	    	}
	    	return true;
    	}
    	else 
    		return false;
    }
	
	/** src에서 nameIndex까지의 "\n"의 개수를 센다. 
	 * 주석안의 "\n"은 세고 인용부호안의 "\n"은 세지 않는다.*/
	int getCountOfNewLineChars(HighArray_CodeString src2, int nameIndex) {
		int i;
		int count = 0;
		for (i=0; i<nameIndex; i++) {
			CodeString str = src2.getItem(i);
			CodeChar c = str.charAt(0);
			if (c.c=='\n') count++;
		}
		return count;
	}

	/** listOfClass가 1보다 큰 경우(즉 파일하나에 중첩되지 않은 클래스가 여러 개 있으면, 루트라 이름붙인다.)
	 * 루트에서는  parentClassParams=null, curClassParams=null이다. 
	 * 1인 경우는 parentClassParams=첫번째 클래스, curClassParams=첫번째클래스이다.*/
	@Override		
	public void onTouchEvent(Object sender, MotionEvent e) {
		
		try {
		if (sender instanceof MenuWithScrollBar) {
			MenuWithScrollBar menu = (MenuWithScrollBar)sender;
			String nameOfButton = menu.selectedButtonName;
			if (nameOfButton==null) return;
			if (nameOfButton.equals("Back") || nameOfButton.equals("No error")) {					
				setHides(true);
			}
			else {
				if (menu.selectedButton==null) return;
				//compiler.data.menuClassAndMemberList.open(false);
				
				Button selectedButton = menu.selectedButton;
				callTouchListener(selectedButton, null);
				
				/*int indexOfErrors = Integer.parseInt(selectedButton.name);
				int index = ((Error)Compiler.mainClasses.getItem(indexOfErrors)).startIndex();
				countOfNewLineChars = getCountOfNewLineChars(compiler.data.mBuffer, index);
				
				// call listener
				callTouchListener(this, null);*/
			}
		}
		}catch(Exception e1) {
			e1.printStackTrace();
			CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e1);
		}
		
	}
	
			
	@Override
	public void draw(Canvas canvas) {
		menuMainClassesList.draw(canvas);
	}

	public void setButtons(Button[] list) {
		
		menuMainClassesList.setButtons(list);
	}
	
}
