package com.gsoft.common.compiler.gui;

import android.graphics.Canvas;
import android.graphics.Color;

import com.gsoft.common.Events.MotionEvent;
import com.gsoft.common.CommonGUI;
import com.gsoft.common.FileHelper;
import com.gsoft.common.Sizing.Rectangle;
import com.gsoft.common.Sizing.SizeF;
import com.gsoft.common.interfaces.OnTouchListener;
import com.gsoft.common.gui.Buttons.Button;
import com.gsoft.common.gui.Control;
import com.gsoft.common.gui.Control.Container;
import com.gsoft.common.util.ArrayList;

public class MDITabList extends Container  implements OnTouchListener {
	ArrayList tabButtonList = new ArrayList(10);
	ArrayList closeButtonList = new ArrayList(10);
	float scaleOfTabButtonX = /*0.1f*/0.25f;
	
	int widthOfTabButton;
	int widthOfCloseButton;
	
	int hScrollPos;
	int numOfTabButtonsPerPage;
	
	Button buttonToLeft;
	Button buttonToRight;
	
	/**스크롤 되었을 경우 event의 좌표를 바꾼다.*/
	MotionEvent scrolledEvent = new MotionEvent(com.gsoft.common.Events.MotionEvent.ActionDown, 0, 0);
	
	public MDITabList(Rectangle bounds) {
		this.bounds = bounds;
		
		Rectangle boundsButton = new Rectangle(bounds.x, bounds.y, bounds.height, bounds.height);
		buttonToLeft = new Button(this, "<=", "<=", Color.BLUE, boundsButton , 
	         		false, 255, false, 0.0f, null, Color.LTGRAY);
		buttonToLeft.setIsOpen(false);
		buttonToLeft.setOnTouchListener(this);
		
		boundsButton = new Rectangle(bounds.right()-bounds.height, bounds.y, bounds.height, bounds.height);
		buttonToRight = new Button(this, "=>", "=>", Color.BLUE, boundsButton , 
	         		false, 255, false, 0.0f, null, Color.LTGRAY);
		buttonToRight.setIsOpen(false);
		buttonToRight.setOnTouchListener(this);
		
		
		widthOfTabButton = (int) (Control.view.getWidth()*this.scaleOfTabButtonX);
		this.widthOfCloseButton = bounds.height;
		
		numOfTabButtonsPerPage = (bounds.width-this.buttonToLeft.bounds.width-this.buttonToRight.bounds.width) 
				/ (widthOfTabButton+widthOfCloseButton);
		
		
	}
	
	public void changeBounds(Rectangle bounds) {
		this.bounds = bounds;
		numOfTabButtonsPerPage = (bounds.width-this.buttonToLeft.bounds.width-this.buttonToRight.bounds.width) 
				/ (widthOfTabButton+widthOfCloseButton);
		buttonToRight.bounds.x = bounds.right()-bounds.height;
		
		this.showOrHideButtonToLeftAndToRight();
	}
	
	
	/**selectedButton을 선택 상태로 만든다.*/
	void focusTab(Button selectedButton) {
		int i;
		for (i=0; i<this.tabButtonList.count; i++) {
			Button tabButton = (Button) this.tabButtonList.getItem(i);
			tabButton.Select(false);
		}
		selectedButton.Select(true);
		
		int indexOfSelectedButton = this.findTab((String)selectedButton.addedInfo);
				
		if (this.hScrollPos<=indexOfSelectedButton && indexOfSelectedButton<this.hScrollPos+this.numOfTabButtonsPerPage) {
			return;
		}
		else {			
			// selectedButton이 가장 오른쪽에 보이도록 hScrollPos를 바꾼다.
			this.hScrollPos = indexOfSelectedButton-this.numOfTabButtonsPerPage+1;
			if (this.hScrollPos<0) this.hScrollPos = 0;
			this.showOrHideButtonToLeftAndToRight();
		}
	}
	
	/**이미 열려있는 문서인지를 확인한다.*/
	public int findTab(String filePath) {
		int i;
		for (i=0; i<this.tabButtonList.count; i++) {
			Button tabButton = (Button) this.tabButtonList.getItem(i);
			String filePathOfTabButton = (String) tabButton.addedInfo;
			if (filePath.equals(filePathOfTabButton)) {
				return i;
			}
		}
		return -1;
	}
	
	public void setModifiedSymbol(String filePath, boolean trueOrFalse) {
		int i;
		for (i=0; i<this.tabButtonList.count; i++) {
			Button tabButton = (Button) this.tabButtonList.getItem(i);
			String filePathOfTabButton = (String) tabButton.addedInfo;
			if (filePath.equals(filePathOfTabButton)) {
				String filename = FileHelper.getFilename(filePathOfTabButton);
				if (trueOrFalse) {
					tabButton.setText("* "+filename);
				}
				else {
					tabButton.setText(filename);
				}
			}
		}
	}
	
	/**이미 열려있는 문서를 열 경우에는 focusTab()을 실행하고
	 * 새로운 문서를 열 경우에만 TabButton을 추가하고 focusTab()을 실행한다.
	 * @param filePath
	 */
	public void addTabButtonAndFocusTabIfNotExist(String filePath) {
		Button tabButton = null;
		int buttonIndex = this.findTab(filePath);
		if (buttonIndex!=-1) {
			tabButton = (Button) this.tabButtonList.getItem(buttonIndex);
		}
		
		if (tabButton!=null) {
			focusTab(tabButton);
			return;
		}
		addTabButtonAndFocusTab(filePath);
	}
	
	/**탭버튼이 닫힐 경우 오른쪽에 있는 탭버튼들을 정렬을 한다.*/
	public void changeBoundsOfButtons(int startIndex) {
		int i;
		int x;
		for (i=startIndex; i<this.tabButtonList.count; i++) {
			// tabButton 만들고 넣기
			if (i>0) {
				Button rightMostButton = (Button) closeButtonList.getItem(i-1);
				x = rightMostButton.bounds.right();
			}
			else {
				x = this.buttonToLeft.bounds.right();
			}
			
			Button tabButton = (Button) this.tabButtonList.getItem(i);
			tabButton.bounds.x = x;
			
			Button closeButton = (Button) this.closeButtonList.getItem(i);
			closeButton.bounds.x = tabButton.bounds.right();
		}
	}
	
	public void addTabButtonAndFocusTab(String filePath) {
		int x, y, w, h;
		// tabButton 만들고 넣기
		if (tabButtonList.count>0) {
			Button rightMostButton = (Button) closeButtonList.getItem(closeButtonList.count-1);
			x = rightMostButton.bounds.right();
		}
		else {
			x = this.buttonToLeft.bounds.right();
		}
		y = bounds.y;
		w = this.widthOfTabButton;
		h = bounds.height;
		
		String text = FileHelper.getFilename(filePath);
		//text = FileHelper.getFilenameExceptExt(text);
		Rectangle boundsButton = new Rectangle(x, y, w, h);
        Button tabButton = new Button(this, text, text, Color.YELLOW, boundsButton, 
         		true, 255, false, 0.0f, null, Color.LTGRAY);
        tabButton.ColorSelected = Color.MAGENTA;
        tabButton.addedInfo = filePath;
        tabButton.setOnTouchListener(this);
        
        this.tabButtonList.add(tabButton);
        
        focusTab(tabButton);
        
        // closeButton 만들고 넣기
        x = boundsButton.right();
        y = bounds.y;
		w = this.widthOfCloseButton;
		h = bounds.height;
        Rectangle boundsCloseButton = new Rectangle(x, y, w, h);
        Button closeButton = new Button(this, "X", "X", Color.BLUE, boundsCloseButton, 
         		false, 255, false, 0.0f, null, Color.LTGRAY);
        closeButton.addedInfo = filePath;
        closeButton.setOnTouchListener(this);
        
        this.closeButtonList.add(closeButton);
        
        //showOrHideButtonToLeftAndToRight();
	}
	
	public void closeAllTabButtons() {
		this.tabButtonList.destroy();
		this.closeButtonList.destroy();
		this.hScrollPos = 0;
		showOrHideButtonToLeftAndToRight();
	}
	
	public void closeTabButton_sub(String filePath) {
		int buttonIndex = this.findTab(filePath);
		this.tabButtonList.delete(buttonIndex, 1);
		this.closeButtonList.delete(buttonIndex, 1);
		if (buttonIndex>0) {
			Button newButton = (Button)this.tabButtonList.getItem(buttonIndex-1);
			selectTabAndFocusTab(newButton);			
		}
		else if (buttonIndex==0) {
			if (this.tabButtonList.count>0) {
				Button newButton = (Button)this.tabButtonList.getItem(buttonIndex);
				selectTabAndFocusTab(newButton);
			}
		}
		if (buttonIndex>=0) {
			changeBoundsOfButtons(buttonIndex);
		}
		
		if (this.tabButtonList.count==0) {
			CommonGUI.editText_compiler.initialize();	
		}
		
		showOrHideButtonToLeftAndToRight();
	}
	
	public void closeTabButton(String filePath) {
		CommonGUI.editText_compiler.closeCompilerDocument(filePath);
		
		
	}
	
	void showOrHideButtonToLeftAndToRight() {
		if (this.tabButtonList.count>this.hScrollPos+this.numOfTabButtonsPerPage) {
        	this.buttonToRight.setIsOpen(true);
        }
		else {
			this.buttonToRight.setIsOpen(false);
		}
		if (this.hScrollPos>0) {
			this.buttonToLeft.setIsOpen(true);
		}
		else {
			this.buttonToLeft.setIsOpen(false);
		}
	}
	
	/**문서를 연다. 탭버튼은 문서를 열때 내부적으로 focus 상태에 있게 된다.*/
	public void selectTabAndFocusTab(Button tabButton) {
		String newDocumentPath = (String) tabButton.addedInfo;
		CommonGUI.editText_compiler.openCompilerDocument(newDocumentPath);
		//this.focusTab(newButton);
	}
	
	public void draw(Canvas canvas) {
		int i;
		int x, y;
		y = bounds.y;
		for (i=hScrollPos; i<hScrollPos+this.numOfTabButtonsPerPage && i<this.tabButtonList.count; i++) {
			Button tabButton = (Button) this.tabButtonList.getItem(i);
			x = this.buttonToLeft.bounds.right() + (i-hScrollPos) * (this.widthOfTabButton+this.widthOfCloseButton);
			tabButton.draw(canvas, x, y);
			//tabButton.draw(canvas);
			
			x += this.widthOfTabButton;
			Button closeButton = (Button) this.closeButtonList.getItem(i);
			closeButton.draw(canvas, x, y);		
			//closeButton.draw(canvas);
		}
		
		this.buttonToLeft.draw(canvas);
		this.buttonToRight.draw(canvas);
	}
	
	@Override
    public boolean onTouch(MotionEvent event, SizeF scaleFactor) {
    	boolean r=false;
    	if (event.actionCode==MotionEvent.ActionDown || event.actionCode==MotionEvent.ActionDoubleClicked) {
	    	r = super.onTouch(event, scaleFactor);
	    	
	    	r = this.buttonToLeft.onTouch(event, scaleFactor);
	    	if (r) return true;
			r = this.buttonToRight.onTouch(event, scaleFactor);
			if (r) return true;
			
			// 스크롤 되었을 경우 event의 좌표를 바꾼다.
			this.scrolledEvent.x = event.x + this.hScrollPos*(this.widthOfTabButton+this.widthOfCloseButton);
			this.scrolledEvent.y = event.y;
	    	int i;
			for (i=0; i<this.tabButtonList.count; i++) {
				Button tabButton = (Button) this.tabButtonList.getItem(i);
				r = tabButton.onTouch(scrolledEvent, scaleFactor);
				if (r) return true;
			}
			for (i=0; i<this.closeButtonList.count; i++) {
				Button closeButton = (Button) this.closeButtonList.getItem(i);
				r = closeButton.onTouch(scrolledEvent, scaleFactor);
				if (r) return true;
			}
	    	return false;
    	}
    	else 
    		return false;
    }
	
	@Override		
	public void onTouchEvent(Object sender, MotionEvent e) {
		
		if (sender instanceof Button) {
			Button button = (Button)sender;
			String text = button.text;
			if (text.equals("=>")) {
				this.hScrollPos++;
				showOrHideButtonToLeftAndToRight();
			}
			else if (text.equals("<=")) {
				this.hScrollPos--;
				showOrHideButtonToLeftAndToRight();
			}
			else if (text.equals("X")) {
				String filePath = (String) button.addedInfo;
				this.closeTabButton(filePath);
			}
			else {
				this.selectTabAndFocusTab(button);
			}
		}
	}
}
