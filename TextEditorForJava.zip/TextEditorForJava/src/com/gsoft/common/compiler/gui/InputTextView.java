package com.gsoft.common.compiler.gui;

import java.io.File;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.CommonGUI;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.Events.MotionEvent;
import com.gsoft.common.IO;
import com.gsoft.common.IO_types.TextFormat;
import com.gsoft.common.Sizing.Rectangle;
import com.gsoft.common.gui.IntegrationKeyboard;
import com.gsoft.common.gui.TextView;
import com.gsoft.common.gui.edittext.Edit.ScrollMode;

/**InputStream*/
public class InputTextView extends TextView {
	//Point oldCursorPos = new Point();

	public InputTextView(boolean hasToolbarAndMenuFontSize,
			boolean isDockingOfToolbarFlexiable, Object owner, String name,
			Rectangle paramBounds, float fontSize, boolean isSingleLine,
			CodeString text, ScrollMode scrollMode, int backColor) {
		super(hasToolbarAndMenuFontSize, isDockingOfToolbarFlexiable, owner, name,
				paramBounds, fontSize, isSingleLine, text, scrollMode, backColor);
		// TODO Auto-generated constructor stub
	}
	
	/** Writes contents of CommonGUI.textViewInput to file named Common_Settings.pathInput*/
	public void writeUntilBlank() {
		File inputFile = new File(Common_Settings.pathInput);
		
		CodeString text = this.getText();
		IO.writeString(inputFile.getAbsolutePath(), text.str, TextFormat.UTF_8, false, true);
	}
	
	/*String getAddedString() {
		String r = "";
		for (int j=oldCursorPos.y; j<=cursorPos.y; j++) {
			int len;
			if (j==cursorPos.y) len = cursorPos.x;
			else len = this.textArray[j].count;
			for (int i=0; i<len; i++) {
				r += this.textArray[j].charAt(i);
			}
		}
		return r;
	}*/
	
	
	/*public void onTouchEvent(Object sender, MotionEvent e) {
		super.onTouchEvent(sender, e);
		if (this.iName==CommonGUI.textViewInput.iName) {
			if (sender instanceof IntegrationKeyboard) {
				IntegrationKeyboard keyboard = (IntegrationKeyboard) sender;
				if (keyboard.key.equals(" ") || keyboard.key.equals("\t") || keyboard.key.equals(IntegrationKeyboard.Enter)) {
					writeUntilBlank();
					HighArray_char consoleText = CommonGUI.textViewConsole.getText4();
					String addedStr = getAddedString();
					consoleText.add(addedStr);
					IO.writeString(Common_Settings.pathConsoleInputAndError+File.separator+"Console", consoleText, TextFormat.UTF_8, false, false);
					oldCursorPos = this.cursorPos;
				}
			}	
		}
	}*/
	
	public void onTouchEvent(Object sender, MotionEvent e) {
		super.onTouchEvent(sender, e);
		if (this.iName==CommonGUI.textViewInput.iName) {
			if (sender instanceof IntegrationKeyboard) {
				IntegrationKeyboard keyboard = (IntegrationKeyboard) sender;
				if (keyboard.key.equals(" ") || keyboard.key.equals("\t") || keyboard.key.equals(IntegrationKeyboard.Enter)) {
					writeUntilBlank();
					
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e1) {
						
						e1.printStackTrace();
					}			
				}
			}	
		}
	}

}
