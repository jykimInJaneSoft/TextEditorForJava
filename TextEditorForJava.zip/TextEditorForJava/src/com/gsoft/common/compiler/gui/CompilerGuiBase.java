package com.gsoft.common.compiler.gui;

import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.Compiler_types.FindFunctionParams;
import com.gsoft.common.compiler.Compiler_types.FindVarParams;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListIReset;
import com.gsoft.common.util.Sort;
import com.gsoft.common.util.Sort.SortItem;
import com.gsoft.common.util.Sort.SortItemIReset;

public class CompilerGuiBase {
	

	/** @param mode : 0(list는 FindFunctionParams[]), 1(list는 FindVarParams[]), 2(list는 FindClassParams[])*/
	public static ArrayListIReset toSortItemList(ArrayListIReset list, int mode) {
		
		if (list==null) return null;
		int i;
		ArrayListIReset r = new ArrayListIReset(list.count);
		if (mode==0) {
			for (i=0; i<list.count; i++) {
				FindFunctionParams func = (FindFunctionParams) list.getItem(i);
				SortItemIReset item = Sort.toSortItemIReset(func.name, func);
				r.add(item);			
			}
		}
		else if (mode==1) {
			for (i=0; i<list.count; i++) {
				FindVarParams var = (FindVarParams) list.getItem(i);
				SortItemIReset item = Sort.toSortItemIReset(var.fieldName, var);
				r.add(item);			
			}
		}
		else if (mode==2) {
			for (i=0; i<list.count; i++) {
				FindClassParams c = (FindClassParams) list.getItem(i);
				SortItemIReset item = Sort.toSortItemIReset(CompilerHelper.getShortName(c.name), c);
				r.add(item);			
			}
		}
		Sort.sort(r);
		
		for (i=0; i<r.count; i++) {
			SortItemIReset item = (SortItemIReset) r.getItem(i);
			r.list[i] = item.obj;
		}
		
		return r;
	}
	
	/** @param mode : 0(list는 FindFunctionParams[]), 1(list는 FindVarParams[]), 2(list는 FindClassParams[])*/
	public static ArrayList toSortItemList(ArrayList list, int mode) {
		
		if (list==null) return null;
		int i;
		ArrayList r = new ArrayList(list.count);
		if (mode==0) {
			for (i=0; i<list.count; i++) {
				FindFunctionParams func = (FindFunctionParams) list.getItem(i);
				SortItem item = Sort.toSortItem(func.name, (Object)func);
				r.add(item);			
			}
		}
		else if (mode==1) {
			for (i=0; i<list.count; i++) {
				FindVarParams var = (FindVarParams) list.getItem(i);
				SortItem item = Sort.toSortItem(var.fieldName, (Object)var);
				r.add(item);			
			}
		}
		else if (mode==2) {
			for (i=0; i<list.count; i++) {
				FindClassParams c = (FindClassParams) list.getItem(i);
				SortItem item = Sort.toSortItem(CompilerHelper.getShortName(c.name), (Object)c);
				r.add(item);			
			}
		}
		Sort.sort(r);
		
		for (i=0; i<r.count; i++) {
			SortItem item = (SortItem) r.getItem(i);
			r.list[i] = item.obj;
		}
		
		return r;
	}
	
	
	public static String[] toSortItemList(String[] list) {
		ArrayList r = new ArrayList(list.length);
		int i;
		for (i=0; i<list.length; i++) {			
			SortItem item = Sort.toSortItem(list[i], (Object)list[i]);
			r.add(item);			
		}
		Sort.sort(r);
		String[] arrString = new String[r.count];
		for (i=0; i<r.count; i++) {
			SortItem item = (SortItem) r.getItem(i);
			arrString[i] = (String) item.obj;
		}
		return arrString;
	}
}