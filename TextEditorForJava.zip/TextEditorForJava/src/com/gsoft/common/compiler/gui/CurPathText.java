package com.gsoft.common.compiler.gui;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.Sizing.Rectangle;
import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.CompilerStatic;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.Compiler_types.FindFunctionParams;
import com.gsoft.common.compiler.Compiler_types.FindVarParams;
import com.gsoft.common.compiler.Compiler_types_Base.Block;
import com.gsoft.common.compiler.Compiler_types_Base.FindStatementParams;
import com.gsoft.common.gui.Control;
import com.gsoft.common.gui.edittext.Edit.ScrollMode;
import com.gsoft.common.gui.edittext.EditText;
import com.gsoft.common.util.ArrayListString;

/**자바를 로딩시 editText_compiler 상단에 있는 경로 바를 말한다*/
public class CurPathText {
	/**자바를 로딩시 editText_compiler 상단에 있는 경로 바를 말한다*/
	public static EditText editTextCurPath;
	
	/**자바를 로딩시 editText_compiler 상단에 있는 경로 바를 bounds에 생성한다.*/
	public static void createEditTextCurPath(Compiler compiler, Rectangle bounds) {
		if (editTextCurPath==null) {
			Rectangle boundsOfDocumentPath = bounds;
			editTextCurPath = new EditText(false, false, Control.view, "CurPath", boundsOfDocumentPath, 
					boundsOfDocumentPath.height*0.5f, true, 
					new CodeString("", Common_Settings.textColor), 
					ScrollMode.Both, Common_Settings.backColor);
			//editTextCurPath.setBackColor(Common_Settings.backColor);
			editTextCurPath.isReadOnly = true;
			
			if (compiler!=null && compiler.data.filename!=null) {
				editTextCurPath.setText(0, new CodeString(compiler.data.filename, editTextCurPath.textColor));
			}
			else {
				editTextCurPath.setText(0, new CodeString("", editTextCurPath.textColor));
			}
		}
		
	}
	
		
	/** editTextCurPath를 text로 바꾼다.*/
	public static void setCurPathTextPlusProjectName(String text) {
		setCurPathTextPlusProjectName(new CodeString(text, Common_Settings.textColor));
	}

	//private static boolean showsCurPath;
	
	/** editTextCurPath를 text로 바꾼다.*/
	public static void setCurPathTextPlusProjectName(CodeString text) {
		if (editTextCurPath!=null) {
			if (Common_Settings.projectName!=null) {
				CodeString projectName = new CodeString(Common_Settings.projectName+" project", Common_Settings.keywordColor);
				CodeString title = projectName;
				if (text!=null && !text.equals("")) {
					title = projectName.concate(new CodeString(", ", Common_Settings.textColor));
					title = projectName.concate(text);
				}
				editTextCurPath.setText(0, title);
			}
			else {
				CodeString projectName = new CodeString("No project", Common_Settings.keywordColor);
				CodeString title = projectName;
				if (text!=null && !text.equals("")) {
					title = projectName.concate(new CodeString(", ", Common_Settings.textColor));
					title = projectName.concate(text);
				}
				editTextCurPath.setText(0, title);
			}
		}
	}
	
	/** editTextCurPath를 cursorPos가 있는 경로로 바꾼다.
	 * Adds Common_Settings.projectName to text*/
	public static void setCurPathTextPlusProjectName(Compiler compiler, int cursorPosX, int cursorPosY, boolean showsCurPath) {
		if (compiler!=null) {
			if (showsCurPath) {
				int indexInmBuffer = -1;
				indexInmBuffer = CompilerStatic.findWord(compiler, cursorPosX, cursorPosY);
				
				FindStatementParams r = null;
				if (compiler.PairErrorExists) {
					r = compiler.findLocationWhenNotPaired( compiler.data.mlistOfClass, indexInmBuffer);
				}
				else {
					r = compiler.findLocation( compiler.data.mlistOfClass, indexInmBuffer);	
				}
				
				CodeString text = null;
				if (compiler.PairErrorExists) {
					text = new CodeString("Not Paired : ", Common_Settings.keywordColor);
				}
				else {
					text = new CodeString("", Common_Settings.textColor);
				}
				
				if (r==null) {
					text = text.concate(new CodeString(compiler.data.filename, 
							Common_Settings.keywordColor));
					setCurPathTextPlusProjectName(text);
				}
				
				String packageName = compiler.data.packageName;
				
				if (r instanceof FindClassParams) {
					if (packageName!=null) {
						text = text.concate(new CodeString(packageName+".", Common_Settings.textColor));
					}
					
					ArrayListString classFullNameExceptPackageName = getClassFullNameExceptPackageName(r);
					
					int i;
					for (i=0; i<classFullNameExceptPackageName.count; i++) {
						if (i!=0) {
							text = text.concate(new CodeString(".", Common_Settings.textColor));
						}
						text = text.concate(new CodeString(classFullNameExceptPackageName.getItem(i), Common_Settings.textColor));
					}
					
					text = text.concate(new CodeString(" - " +  compiler.data.filename, Common_Settings.keywordColor));
					setCurPathTextPlusProjectName(text);
				}
				else if (r instanceof FindFunctionParams) {
					FindFunctionParams f = (FindFunctionParams) r;
					if (packageName!=null) {
						text = text.concate(new CodeString(packageName+".", Common_Settings.textColor));
					}
					ArrayListString classFullNameExceptPackageName = getClassFullNameExceptPackageName(r);
					
					int i;
					for (i=0; i<classFullNameExceptPackageName.count; i++) {
						if (i!=0) {
							text = text.concate(new CodeString(".", Common_Settings.textColor));
						}
						text = text.concate(new CodeString(classFullNameExceptPackageName.getItem(i), Common_Settings.textColor));
					}
					text = text.concate(new CodeString(".", Common_Settings.textColor));
					text = text.concate(new CodeString(f.name+"()", Common_Settings.textColor));
					
					//text = text.concate(new CodeString(" - " +  compiler.data.packageName.toString(), Common_Settings.textColor));
					text = text.concate(new CodeString(" - " +  compiler.data.filename, Common_Settings.keywordColor));
					setCurPathTextPlusProjectName(text);
				}
				else if (r instanceof FindVarParams) {
					FindVarParams v = (FindVarParams) r;
					if (packageName!=null) {
						text = text.concate(new CodeString(packageName+".", Common_Settings.textColor));
					}
					ArrayListString classFullNameExceptPackageName = getClassFullNameExceptPackageName(r);
					
					int i;
					for (i=0; i<classFullNameExceptPackageName.count; i++) {
						if (i!=0) {
							text = text.concate(new CodeString(".", Common_Settings.textColor));
						}
						text = text.concate(new CodeString(classFullNameExceptPackageName.getItem(i), Common_Settings.textColor));
					}
					text = text.concate(new CodeString(".", Common_Settings.textColor));
					text = text.concate(new CodeString(v.fieldName, Common_Settings.textColor));
					
					//text = text.concate(new CodeString(" - " +  compiler.data.packageName.toString(), Common_Settings.textColor));
					text = text.concate(new CodeString(" - " +  compiler.data.filename, Common_Settings.keywordColor));
					setCurPathTextPlusProjectName(text);
				}
			}
		}
	}
	
	/** statement의 parent 클래스 이름들을 모두 연결하여 리턴한다.*/
	public static ArrayListString getClassFullNameExceptPackageName(FindStatementParams statement) {
		Block block = statement.parent;
		ArrayListString r = new ArrayListString(5);
		
		if (statement instanceof FindClassParams) {
			// statement가 클래스일 경우에만 포함을 시킨다.
			FindClassParams c = (FindClassParams) statement;
			String name = CompilerHelper.getShortName(c.name);
			r.add(name);
		}
		while (block!=null) {
			if (block instanceof FindClassParams) {
				FindClassParams c = (FindClassParams) block;
				String name = CompilerHelper.getShortName(c.name);
				r.add(name);
			} 
			block = block.parent;
		}
		ArrayListString r2 = new ArrayListString(5);
		int i;
		for (i=r.count-1; i>=0; i--) {
			r2.add(r.getItem(i));
		}
		return r2;
	}

}
