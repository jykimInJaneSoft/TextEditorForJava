package com.gsoft.common.compiler.gui;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Point;

import com.gsoft.common.gui.Control;
import com.gsoft.common.Code.CodeChar;
import com.gsoft.common.Code.CodeString;
import com.gsoft.common.CommonGUI;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.Events.MotionEvent;
import com.gsoft.common.Sizing.Rectangle;
import com.gsoft.common.Sizing.Size;
import com.gsoft.common.Sizing.SizeF;
import com.gsoft.common.interfaces.OnTouchListener;
import com.gsoft.common.compiler.Checker;
import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.CompilerInterface;
import com.gsoft.common.compiler.CompilerStatic;
import com.gsoft.common.compiler.Fullname;
import com.gsoft.common.compiler.IndexForHighArray;
import com.gsoft.common.compiler.Compiler_types.CategoryOfControls;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.Compiler_types.FindControlBlockParams;
import com.gsoft.common.compiler.Compiler_types.FindFuncCallParam;
import com.gsoft.common.compiler.Compiler_types.FindFunctionParams;
import com.gsoft.common.compiler.Compiler_types.FindVarParams;
import com.gsoft.common.compiler.Compiler_types.FindVarUseParams;
import com.gsoft.common.compiler.Compiler_types.Language;
import com.gsoft.common.compiler.Compiler_types.LoadWayOfFindClassParams;
import com.gsoft.common.compiler.Compiler_types_Base.Block;
import com.gsoft.common.compiler.Compiler_types_Base.FindPackageParams;
import com.gsoft.common.compiler.Compiler_types_Base.ReturnOfFindVarDecl;
import com.gsoft.common.compiler.Compiler_types_Special.FindSpecialBlockParams;
import com.gsoft.common.compiler.HighArray_CodeString;
import com.gsoft.common.compiler.classloader.Loader;
import com.gsoft.common.gui.Buttons.Button;
import com.gsoft.common.gui.Buttons.ButtonGroup;
import com.gsoft.common.gui.Control.Container;
import com.gsoft.common.gui.MenuWithScrollBar;
import com.gsoft.common.gui.MenuWithScrollBarWithMoveButton;
import com.gsoft.common.gui.TextView;
import com.gsoft.common.gui.Pool.PoolOfButton;
import com.gsoft.common.gui.edittext.Edit.ScrollMode;
import com.gsoft.common.util.Array;
import com.gsoft.common.util.ArrayListCodeChar;
import com.gsoft.common.util.ArrayListIReset;
import com.gsoft.common.util.HighArray_CodeChar;

import com.gsoft.common.compiler.gui.CompilerGuiBase;

public class MenuClassAndMemberListBase extends Container implements OnTouchListener 
{
	MenuWithScrollBarWithMoveButton menuClassAndMemberList;
	protected PoolOfButton poolOfFileListButtons;
	Size buttonSize;
	protected HighArray_CodeString src;
	public int countOfNewLineChars;
	

	
	CompilerInterface compiler;
	
	
	public boolean showsExtendsMember;	
	public boolean sortsMembers;
	
	public Button selectedItem;
	
	public Point cursorPosToMove;
	public TextView textView;
	
	int coreThreadID;
	
	
	public void changeBounds(Rectangle bounds) {
		this.bounds = bounds;
		changeBounds_MenuListAndEditTextPath(bounds);
		
		int x, y, w, h;		
		
		int viewWidth = Control.view.getWidth(); 
		int viewHeight = Control.view.getHeight();
		w = (int) (viewWidth * 0.8f);
		h = (int) (viewHeight * 0.5f);
		x = viewWidth/2 - w/2;
		y = viewHeight/2 - h/2;
		Rectangle boundsOfTextView = new Rectangle(x,y,w,h);
		textView.changeBounds(boundsOfTextView);
	}
	
	
	void setButtonSize() {
		if (this.buttonSize==null) {
			this.buttonSize = new Size((int)(bounds.width*0.7f),(int)(bounds.height*0.06f));
		}
		else {
			this.buttonSize.width = (int) (bounds.width*0.7f);
			this.buttonSize.height = (int) (bounds.height*0.06f);
		}
	}
	
	
	public MenuClassAndMemberListBase(Compiler compiler, Rectangle bounds, int coreThreadID) {
		this.compiler = (CompilerInterface) compiler;
		this.bounds = bounds;
		this.coreThreadID = coreThreadID;
		
		//this.buttonSize = new Size((int)(bounds.width*0.7f),(int)(bounds.height*0.06f));
		this.setButtonSize();
		createMenuListAndEditTextPath();
		createPoolOfFileListButtons();
		
		
		int x, y, w, h;
		
		int viewWidth = Control.view.getWidth(); 
		int viewHeight = Control.view.getHeight();
		w = (int) (viewWidth * 0.8f);
		h = (int) (viewHeight * 0.5f);
		x = viewWidth/2 - w/2;
		y = viewHeight/2 - h/2;
		Rectangle boundsOfTextView = new Rectangle(x,y,w,h);
		
		textView = new TextView(false, false, this, "TextView", boundsOfTextView, 
				Control.view.getHeight()*0.03f, false, null, ScrollMode.VScroll, Common_Settings.backColor);
		textView.isReadOnly = true;
		
		open(false);
	}
	
	void changeBounds_MenuListAndEditTextPath(Rectangle newBounds) {
		this.setButtonSize();
		
		Rectangle boundsOfmenuClassAndMemberList = new Rectangle(newBounds);
		int heightOfEditTextPath =  (int) (newBounds.height * 0.1f);
		boundsOfmenuClassAndMemberList.height = (newBounds.height - heightOfEditTextPath);
		if (menuClassAndMemberList!=null) {
			menuClassAndMemberList.changeBounds(boundsOfmenuClassAndMemberList, buttonSize);				
		}
	}
	
	/** 영역만 잡아주고 menuClassAndMemberList 내용(Button[])은 나중에 createAndSetFileListButtons를
	 * 통해 넣어준다. 
	 * @param dir
	 * @param curDir
	 * @param category
	 */
	private void createMenuListAndEditTextPath() {
		Rectangle boundsOfmenuClassAndMemberList = new Rectangle(bounds);
		int heightOfEditTextPath =  (int) (bounds.height * 0.1f);
		boundsOfmenuClassAndMemberList.height = (bounds.height - heightOfEditTextPath);
		if (menuClassAndMemberList==null) {
			
			menuClassAndMemberList = new MenuWithScrollBarWithMoveButton(this, boundsOfmenuClassAndMemberList, 
					buttonSize, 
					ScrollMode.VScroll);
			menuClassAndMemberList.setOnTouchListener(this);				
		}
	}
	
	public void setBackColor(int backColor) {
		menuClassAndMemberList.setBackColor(backColor);
	}
	
	/** FileListButtons 의 Pool을 활용하여 디렉토리를 바꿀 때마다 버튼들을 생성하지 않고 메모리를 절약한다.
	 * 즉 디렉토리를 바꾸면 버튼들을 새로 만드는 것이 아니라 pool에서 가져와서 버튼의 속성만 바꿔준다.
	 * (createFileListButtons참조)*/
	void createPoolOfFileListButtons() {
		if (poolOfFileListButtons==null) {
			poolOfFileListButtons = new PoolOfButton(50, buttonSize);
		}
	}
	
	public void setContainerClassAndSrc(HighArray_CodeString src, FindClassParams containerClassParams) {
		this.src = src;
	}
	
	/** 클래스 여러 개를 Button[]으로 리턴한다.*/
	public Button[] getMenuListButtons(HighArray_CodeString src2, ArrayListIReset listOfClass) {
		if (listOfClass==null) return null;
		
		int countOfClasses = listOfClass.count;
		int buttonCount = countOfClasses + 1;
					
		int i;
		int buttonWidth = menuClassAndMemberList.originButtonWidth;
		int buttonHeight = menuClassAndMemberList.originButtonHeight;
		if (poolOfFileListButtons.list.capacity < buttonCount) {
			poolOfFileListButtons.setCapacity(buttonCount, buttonSize);
		}
		
		Button[] buttons = new Button[buttonCount];
		
		int color;	
		
		color = Color.BLUE;
		buttons[0] = (Button) poolOfFileListButtons.getItem(0);
		buttons[0].name = "Back";
		buttons[0].bounds.x = 0;
		buttons[0].bounds.y = 0;
		buttons[0].bounds.width = buttonWidth;
		buttons[0].bounds.height = buttonHeight;
		buttons[0].changeBounds(buttons[0].bounds);
		buttons[0].setBackColor(color);
		buttons[0].setText(buttons[0].name);
		
		int buttonIndex = 1; 
		for (i=0; i<listOfClass.count; i++, buttonIndex++) {
			FindClassParams c = (FindClassParams)listOfClass.getItem(i);
			color = Color.BLUE;
			buttons[buttonIndex] = (Button) poolOfFileListButtons.getItem(buttonIndex);
			buttons[buttonIndex].name = c.name;
			buttons[buttonIndex].bounds.x = 0;
			buttons[buttonIndex].bounds.y = 0;
			buttons[buttonIndex].bounds.width = buttonWidth;
			buttons[buttonIndex].bounds.height = buttonHeight;
			buttons[buttonIndex].changeBounds(buttons[buttonIndex].bounds);
			buttons[buttonIndex].setBackColor(color);
			if (c.template==null) {
				buttons[buttonIndex].setText(buttons[buttonIndex].name);
			}
			else {
				buttons[buttonIndex].setText(buttons[buttonIndex].name+" <T>");
			}
			buttons[buttonIndex].addedInfo = (FindClassParams)listOfClass.getItem(i);
		}
					
		ButtonGroup group = new ButtonGroup(null, buttons);
		for (i=0; i<buttonCount; i++) {
			buttons[i].setGroup(group, i);
		}
		
		return buttons;
		
	}
	
	/** 클래스 하나에 있는 내부클래스들과 함수와 변수들을 Button[]으로 리턴한다.
	 * @param sortMode : 0(파일에 정의된순), 1(이름에 의한 오름차순), 2(이름에 의한 내림차순)
	 * @param filter : "all"(not filter), "a"(first char to filter), only lower case*/
	public Button[] getMenuListButtons(Compiler compiler, HighArray_CodeString src2, FindClassParams classParams, 
			int sortMode, String filter) {
		try {			
		int buttonCount = 1; // for back button
		int buttonIndex = 1; // for back button
		
		int countOfChildClasses=0;
		if (classParams!=null) {
			countOfChildClasses = 
				(classParams.childClasses==null ? 0 : classParams.childClasses.count);
		
			buttonCount += (countOfChildClasses +  
					classParams.listOfVariableParams.count + 
					classParams.listOfFunctionParams.count);
							
			if (showsExtendsMember) {
				buttonCount += classParams.listOfVarParamsInherited==null ? 0 : classParams.listOfVarParamsInherited.count;
				buttonCount += classParams.listOfFunctionParamsInherited==null ? 0 : classParams.listOfFunctionParamsInherited.count;
			}
		}
		else {
			buttonCount += compiler.data.mlistOfAllFunctions.count;
		}
		
		int i;
		int buttonWidth = menuClassAndMemberList.originButtonWidth;
		int buttonHeight = menuClassAndMemberList.originButtonHeight;
		if (poolOfFileListButtons.list.capacity < buttonCount) {
			poolOfFileListButtons.setCapacity(buttonCount, buttonSize);
		}
		
		Button[] buttons = new Button[buttonCount];
		
		int color;	
		
		color = Color.BLUE;
		buttons[0] = (Button) poolOfFileListButtons.getItem(0);
		buttons[0].name = "Back";
		buttons[0].bounds.x = 0;
		buttons[0].bounds.y = 0;
		buttons[0].bounds.width = buttonWidth;
		buttons[0].bounds.height = buttonHeight;
		buttons[0].changeBounds(buttons[0].bounds);
		buttons[0].setBackColor(color);
		buttons[0].setText(buttons[0].name);
				
		
		if (classParams!=null) {
			ArrayListIReset childClasses = classParams.childClasses;
			
			if (childClasses!=null) {
				if (sortMode==1) {
					childClasses = CompilerGuiBase.toSortItemList(childClasses, 2);
				}
				for (i=0; i<childClasses.count; i++) {
					FindClassParams c = (FindClassParams)childClasses.getItem(i);
					if (filter.equals("all") || CompilerHelper.getShortName(c.name).toLowerCase().indexOf(filter)==0) {
						color = Color.BLUE;
						buttons[buttonIndex] = (Button) poolOfFileListButtons.getItem(buttonIndex);
						buttons[buttonIndex].name = c.name;
						buttons[buttonIndex].bounds.x = 0;
						buttons[buttonIndex].bounds.y = 0;
						buttons[buttonIndex].bounds.width = buttonWidth;
						buttons[buttonIndex].bounds.height = buttonHeight;
						buttons[buttonIndex].changeBounds(buttons[buttonIndex].bounds);
						buttons[buttonIndex].setBackColor(color);
						buttons[buttonIndex].addedInfo = childClasses.getItem(i);
						if (c.template==null) {
							buttons[buttonIndex].setText(buttons[buttonIndex].name);
						}
						else {
							buttons[buttonIndex].setText(buttons[buttonIndex].name + " <"+c.template.typeNameToChange+">");
						}
						buttonIndex++;
					}
				}
			}
			int k;
			int loopCount;
			if (this.showsExtendsMember) loopCount = 2;
			else loopCount = 1;
			for (k=0; k<loopCount; k++) {
				ArrayListIReset listFunctions;
				if (k==0) {
					listFunctions = classParams.listOfFunctionParams;
					if (sortMode==1) {
						listFunctions = CompilerGuiBase.toSortItemList(listFunctions, 0);
					}
				}
				else  {
					listFunctions = classParams.listOfFunctionParamsInherited;
				}
				if (listFunctions!=null) {				
					for (i=0; i<listFunctions.count; i++) {
						color = Color.YELLOW;
						
						FindFunctionParams function = (FindFunctionParams)listFunctions.getItem(i);
						
						//if (filterChar==0 || Character.toLowerCase(function.name.charAt(0))==filterChar) {
						if (filter.equals("all") || function.name.toLowerCase().indexOf(filter)==0) {
							buttons[buttonIndex] = (Button) poolOfFileListButtons.getItem(buttonIndex);
							
							boolean isStatic = false;
							if (function.accessModifier!=null) isStatic = function.accessModifier.isStatic;
							String message = "";
							if (isStatic) message = "S:";
							
							if (function.isConstructor) message += "C:";
							
							if (k==1) {
								message += CompilerStatic.getShortName(((FindClassParams)function.parent).name) + " - ";
							}
							
							String name = null;
							if (function.hasReturnType()) {
								name = message + function.returnType + " " + function.name + "()";
							}
							else {
								if (function.isStaticBlock) name = message + function.name;
								else {
									name = message + function.name + "()";
								}
							}
							buttons[buttonIndex].name = name;
							buttons[buttonIndex].bounds.x = 0;
							buttons[buttonIndex].bounds.y = 0;
							buttons[buttonIndex].bounds.width = buttonWidth;
							buttons[buttonIndex].bounds.height = buttonHeight;
							buttons[buttonIndex].changeBounds(buttons[buttonIndex].bounds);
							String text = name;							
							buttons[buttonIndex].setBackColor(color);
							buttons[buttonIndex].addedInfo = function;
							buttons[buttonIndex].setText(text);
							
							buttonIndex++;
						}
					}
				} // if (listFunctions!=null) {	
				
				ArrayListIReset listVars;
				if (k==0) {
					listVars = classParams.listOfVariableParams;
					if (sortMode==1) {
						listVars = CompilerGuiBase.toSortItemList(listVars, 1);
					}
				}
				else  {
					listVars = classParams.listOfVarParamsInherited;
				}
				if (listVars!=null) {				
					for (i=0; i<listVars.count; i++) {						
						color = Color.LTGRAY;
						
						FindVarParams var = (FindVarParams)listVars.getItem(i);
						//if (filterChar==0 || Character.toLowerCase(var.fieldName.charAt(0))==filterChar) {
						if (filter.equals("all") || var.fieldName.toLowerCase().indexOf(filter)==0) {
							buttons[buttonIndex] = (Button) poolOfFileListButtons.getItem(buttonIndex);
							
							boolean isStatic = false;
							if (var.accessModifier!=null) isStatic = var.accessModifier.isStatic;
							String message = "";
							if (isStatic) message = "S:";
							
							if (k==1) {
								message += CompilerStatic.getShortName(((FindClassParams)var.parent).name) + " - ";
							}
							
							String name = null;
							if (var.isThis) {
								name = message + ((FindClassParams)var.parent).name + " " + "this";
							}
							else if (var.isSuper) {
								name = message + ((FindClassParams)var.parent).name + " " + "super";
							}
							else {
								name = message + var.typeName + " " + var.fieldName;
							}
							buttons[buttonIndex].name = name;
							buttons[buttonIndex].bounds.x = 0;
							buttons[buttonIndex].bounds.y = 0;
							buttons[buttonIndex].bounds.width = buttonWidth;
							buttons[buttonIndex].bounds.height = buttonHeight;
							buttons[buttonIndex].changeBounds(buttons[buttonIndex].bounds);
							buttons[buttonIndex].setBackColor(color);
							buttons[buttonIndex].addedInfo = var;
							String text = name;
							buttons[buttonIndex].setText(text);
							
							buttonIndex++;
						}
					}
				} // if (listVars!=null) {
			}// for k
		} // if (classParams!=null) {
		/*else {
			ArrayListIReset listFunctions = compiler.data.mlistOfAllFunctions;
			if (listFunctions!=null) {				
				for (i=0; i<listFunctions.count; i++, buttonIndex++) {
					color = Color.YELLOW;
					
					FindFunctionParams function = (FindFunctionParams)listFunctions.getItem(i);
					
					buttons[buttonIndex] = (Button) poolOfFileListButtons.getItem(buttonIndex);
					
					boolean isStatic = false;
					if (function.accessModifier!=null) isStatic = function.accessModifier.isStatic;
					String message = "";
					if (isStatic) message = "S:";
					
					if (function.isConstructor) message += "C:";
					
					String name;
					if (function.hasReturnType()) {
						name = message + function.returnType + 
								" " + function.name + "()";
					}
					else {
						name = message + function.name + "()";
					}
					buttons[buttonIndex].name = name;
					buttons[buttonIndex].bounds.x = 0;
					buttons[buttonIndex].bounds.y = 0;
					buttons[buttonIndex].bounds.width = buttonWidth;
					buttons[buttonIndex].bounds.height = buttonHeight;
					buttons[buttonIndex].changeBounds(buttons[buttonIndex].bounds);
					buttons[buttonIndex].setBackColor(color);
					buttons[buttonIndex].addedInfo = function;
					String text = name;
					buttons[buttonIndex].setText(text);
				}
			} // if (listFunctions!=null) {
		}*/
		
		buttons = Array.Resize(buttons, buttonIndex);
		
		ButtonGroup group = new ButtonGroup(null, buttons);
		for (i=0; i<buttonIndex; i++) {
			buttons[i].setGroup(group, i);
		}
		
		return buttons;
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
			CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
			
			return null;
		}
	}
	
	
	/** 클래스 하나에 있는 내부클래스들과 함수와 변수들을 Button[]으로 리턴한다.
	 * @param sortMode : 0(파일에 정의된순), 1(이름에 의한 오름차순), 2(이름에 의한 내림차순)
	 * @param filter : "all"(not filter), "a"(first char to filter), only lower case
	 * @param coreThreadID */
	public Button[] getMenuListButtons(Compiler compiler, HighArray_CodeString src2, FindPackageParams packageParams, 
			int sortMode, String filter, int coreThreadID) {
		try {
		int buttonCount = 1; // for back button
		int buttonIndex = 1; // for back button
		int countOfChildClasses=0;
		
		String[] listOfDirectories = null;
		String[] listOfClasses = null;
		
		if (packageParams!=null) {
			listOfDirectories = packageParams.listOfDirectories();
			listOfClasses = packageParams.listOfClasses();
			
			countOfChildClasses = 
				listOfClasses.length;
		
			buttonCount += listOfDirectories.length + countOfChildClasses;
			
		}
		
		int i;
		int buttonWidth = menuClassAndMemberList.originButtonWidth;
		int buttonHeight = menuClassAndMemberList.originButtonHeight;
		if (poolOfFileListButtons.list.capacity < buttonCount) {
			poolOfFileListButtons.setCapacity(buttonCount, buttonSize);
		}
		
		Button[] buttons = new Button[buttonCount];
		
		int color;	
		
		color = Color.BLUE;
		buttons[0] = (Button) poolOfFileListButtons.getItem(0);
		buttons[0].name = "Back";
		buttons[0].bounds.x = 0;
		buttons[0].bounds.y = 0;
		buttons[0].bounds.width = buttonWidth;
		buttons[0].bounds.height = buttonHeight;
		buttons[0].changeBounds(buttons[0].bounds);
		buttons[0].setBackColor(color);
		buttons[0].setText(buttons[0].name);
		
				
	
		if (packageParams!=null) {
			if (listOfDirectories!=null) {	
				if (sortMode==1) {
					listOfDirectories = CompilerGuiBase.toSortItemList(listOfDirectories);
				}
				for (i=0; i<listOfDirectories.length; i++) {					
					String name = listOfDirectories[i];
					//if (filterChar==0 || Character.toLowerCase(name.charAt(0))==filterChar) {
					if (filter.equals("all") || name.toLowerCase().indexOf(filter)==0) {
						color = Color.MAGENTA;						
						buttons[buttonIndex] = (Button) poolOfFileListButtons.getItem(buttonIndex);
						
						FindPackageParams childPackage = new FindPackageParams(compiler, name, packageParams.packageParentFullName); 
						buttons[buttonIndex].name = name;
						buttons[buttonIndex].bounds.x = 0;
						buttons[buttonIndex].bounds.y = 0;
						buttons[buttonIndex].bounds.width = buttonWidth;
						buttons[buttonIndex].bounds.height = buttonHeight;
						buttons[buttonIndex].changeBounds(buttons[buttonIndex].bounds);
						buttons[buttonIndex].setBackColor(color);
						String text = name;
						buttons[buttonIndex].setText(text);
						buttons[buttonIndex].addedInfo = childPackage;
						
						buttonIndex++;
					}
				}
			} // if (listOfDirectories!=null) {
			
			
			if (listOfClasses!=null) {
				if (sortMode==1) {
					listOfClasses = CompilerGuiBase.toSortItemList(listOfClasses);
				}
				for (i=0; i<listOfClasses.length; i++) {
					
					//if (filterChar==0 || Character.toLowerCase(listOfClasses[i].charAt(0))==filterChar) {
					if (filter.equals("all") || listOfClasses[i].toLowerCase().indexOf(filter)==0) {
						String childClassName = packageParams.getFullName(0)+"."+listOfClasses[i];
						color = Color.BLUE;
						buttons[buttonIndex] = (Button) poolOfFileListButtons.getItem(buttonIndex);
						
						FindClassParams childClass = Loader.loadClass(compiler, childClassName, coreThreadID);
						buttons[buttonIndex].name = listOfClasses[i];
						buttons[buttonIndex].bounds.x = 0;
						buttons[buttonIndex].bounds.y = 0;
						buttons[buttonIndex].bounds.width = buttonWidth;
						buttons[buttonIndex].bounds.height = buttonHeight;
						buttons[buttonIndex].changeBounds(buttons[buttonIndex].bounds);
						buttons[buttonIndex].setBackColor(color);
						buttons[buttonIndex].setText(listOfClasses[i]);
						buttons[buttonIndex].addedInfo = childClass;
						
						buttonIndex++;
					}
				}
			}
		} // if (packageParams!=null) {
		
		buttons = Array.Resize(buttons, buttonIndex);
		
		ButtonGroup group = new ButtonGroup(null, buttons);
		for (i=0; i<buttonIndex; i++) {
			buttons[i].setGroup(group, i);
		}
		
		return buttons;
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
			CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
			
			return null;
		}
	}
	
	@Override
    public boolean onTouch(MotionEvent event, SizeF scaleFactor) {
    	boolean r=false;
    	if (event.actionCode==MotionEvent.ActionDown || event.actionCode==MotionEvent.ActionDoubleClicked) {
	    	r = super.onTouch(event, scaleFactor);
	    	
	    	if (!r) {
	    		open(false);	// 영역에 상관없이 닫힌다.
	    		return true;
	    	}
	    	
	    	if (menuClassAndMemberList!=null) {
	    		r = menuClassAndMemberList.onTouch(event, null);
	    		if (r) return true;
	    	}
	    	
	    	return true;
    	}
    	else 
    		return false;
    }
	
	/** src에서 nameIndex까지의 "\n"의 개수를 센다. 
	 * 주석안의 "\n"은 세고 인용부호안의 "\n"은 세지 않는다.*/
	int getCountOfNewLineChars(HighArray_CodeString src2, int nameIndex) {
		int i;
		int count = 0;
		for (i=0; i<nameIndex; i++) {
			CodeString str = src2.getItem(i);
			CodeChar c = str.charAt(0);
			if (c.c=='\n') count++;
		}
		return count;
	}

	/** listOfClass가 1보다 큰 경우(즉 파일하나에 중첩되지 않은 클래스가 여러 개 있으면, 루트라 이름붙인다.)
	 * 루트에서는  parentClassParams=null, curClassParams=null이다. 
	 * 1인 경우는 parentClassParams=첫번째 클래스, curClassParams=첫번째클래스이다.*/
	@Override		
	public void onTouchEvent(Object sender, MotionEvent e) {
		
		try {
		if (sender instanceof Button) {
			
		}
		else if (sender instanceof MenuWithScrollBar) {
			MenuWithScrollBar menu = (MenuWithScrollBar)sender;
			String nameOfButton = menu.selectedButtonName;
			
			if (nameOfButton==null) return;
			
			Button selectedButton = menu.selectedButton;
			this.selectedItem = selectedButton;
			
			if (nameOfButton.equals("Back")) {
				
			}//back
			else {
				
			}// back
			
		}//else if (sender instanceof MenuWithScrollBar) {
		}catch(Exception e1) {
			e1.printStackTrace();
			CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e1);
		}
		
	}//onTouchEvent()
	
	/** src에서 nameIndex까지의 "\n"의 개수를 센다. 
	 * 주석안의 "\n"은 세고 인용부호안의 "\n"은 세지 않는다.*/
	Point getCursorPos(HighArray_CodeString src2, int nameIndex) {
		return CompilerStatic.getCursorPosInSrc(compiler, nameIndex);
	}
	
	void moveToMemberVar(FindVarParams var, int coreThreadID) {
		if (var.compiler==null || var.compiler!=compiler) {
			textView.initCursorAndScrollPos();
			textView.setText(0, new CodeString("It is defined in other file. so can't move to the file.", Common_Settings.textColor));
			textView.setHides(false);
			return;
		}
		
		String varName;
		varName = var.fieldName;
		if (varName.equals("this")) return;
		FindClassParams parent = (FindClassParams) var.parent;
		
		if (parent.loadWayOfFindClassParams==LoadWayOfFindClassParams.ByteCode) {
			HighArray_CodeString mBuffer = compiler.data.mBuffer;
			compiler.compilerStack.setLanguage(Language.Java);
			// 바이트코드(클래스파일)일 경우 func 의 funcNameIndex는 -1이므로
			// mBuffer에서 func의 name으로 검색하여 일치하면 func의 args들을 찾아
			// 일치하는지 확인하여 funcNameIndex를 찾는다.
			int i;
			for (i=0; i<mBuffer.count; i++) {
				CodeString str = mBuffer.getItem(i);
				if (str.equals(varName)) {
					FindVarParams findVarParams = null;
					ReturnOfFindVarDecl r = compiler.FindVarDeclarationsAndVarUses( i, null, coreThreadID);
					if (r!=null) {
						findVarParams = r.var;
					}
					if (findVarParams!=null && findVarParams.found) {
						findVarParams.typeName = Fullname.getFullName(mBuffer, 
								findVarParams.typeStartIndex(), findVarParams.typeEndIndex()).str;
						findVarParams.fieldName = mBuffer.getItem(findVarParams.varNameIndex()).str;
						if (var.equals(findVarParams)) {
							var.varNameIndex = findVarParams.varNameIndex;
							break;
						}
					}
				}
			}//for (i=0; i<mBuffer.count; i++) {
			int indexOfVarName = var.varNameIndex();
			
			cursorPosToMove = getCursorPos(compiler.data.mBuffer, indexOfVarName);
			// call listener
			callTouchListener(this, null);
		}//if (parent.loadWayOfFindClassParams==LoadWayOfFindClassParams.ByteCode) {
		else {
			int indexOfVarName = var.varNameIndex();
			
			
			cursorPosToMove = getCursorPos(compiler.data.mBuffer, indexOfVarName);
			
			// call listener
			callTouchListener(this, null);
		}
	}
	
	void moveToFunc(FindFunctionParams func, int coreThreadID) {
		if (func.compiler==null || func.compiler!=compiler) {
			textView.initCursorAndScrollPos();
			textView.setText(0, new CodeString("It is defined in other file. so can't move to the file.", Common_Settings.textColor));
			textView.setHides(false);
			return;
		}
		
		FindClassParams c = (FindClassParams)func.parent;							
		if (c.loadWayOfFindClassParams==LoadWayOfFindClassParams.ByteCode) {
			int i;
			compiler.compilerStack.setLanguage(Language.Java);
			HighArray_CodeString mBuffer = compiler.data.mBuffer;
			// 바이트코드(클래스파일)일 경우 func 의 funcNameIndex는 -1이므로
			// mBuffer에서 func의 name으로 검색하여 일치하면 func의 args들을 찾아
			// 일치하는지 확인하여 funcNameIndex를 찾는다.
			for (i=0; i<mBuffer.count; i++) {
				CodeString str = mBuffer.getItem(i);
				if (CompilerHelper.IsComment(str)) continue;
				if (str.equals(func.name)) {
					FindFunctionParams func2 = new FindFunctionParams(compiler, -1, -1);
					compiler.FindFunction( c, func2, i+1, coreThreadID);
					if (func2.found) {
						if (func.name.equals(func2.name)) {
							// i는 func의 name의 인덱스이고, i+1은 '('의 인덱스가 된다.
							int startIndex = i+1+1;
							int endIndex = Checker.CheckParenthesis(compiler,  "(", ")", i+1, mBuffer.count-1, false)-1;
							int j;
							FindVarUseParams funcCall = new FindVarUseParams(IndexForHighArray.indexRelative(null, compiler.data.mBuffer, i));
							ArrayListIReset result = compiler.compilerStack.findFuncCallParams(mBuffer, startIndex-1, endIndex+1, funcCall);
							for (j=0; j<result.count; j++) {
								FindFuncCallParam param = (FindFuncCallParam) result.getItem(j);
								int startIndexOfVar = CompilerHelper.SkipBlank(mBuffer, false, param.startIndex(), mBuffer.count-1); 
								FindVarParams var = new FindVarParams(compiler, startIndexOfVar, param.endIndex());
								int fullnameIndex = Fullname.getFullNameIndex(compiler, false, startIndexOfVar, false); 
								var.typeName = Fullname.getFullName(mBuffer, startIndexOfVar, fullnameIndex).str;									
								func2.listOfFuncArgs.add(var);
							}
							if (func.equals(func2, coreThreadID)) {
								func.functionNameIndex = func2.functionNameIndex;
								break;
							}
						}
					}//if (func2.found) {
				}//if (str.equals("(")) {
			}//for (i=0; i<mBuffer.count; i++) {
			
			cursorPosToMove = getCursorPos(compiler.data.mBuffer, func.functionNameIndex());
			
			// call listener, editText내의 해당 함수로 이동한다.
			callTouchListener(this, null);
			
		}//if (c.loadWayOfFindClassParams==LoadWayOfFindClassParams.ByteCode) {
		else {
			if (func.isConstructor) {
				int indexOfFunctionName = func.functionNameIndex();
										
				cursorPosToMove = getCursorPos(compiler.data.mBuffer, indexOfFunctionName);
				
				// call listener, editText내의 해당 함수로 이동한다.
				callTouchListener(this, null);
				
				// 함수 내 제어블록(문)을 보여준다.
				FindFunctionParams function = func;
				ArrayListCodeChar r = getControlBlocksMessage(compiler.data.mBuffer, function, 0);
				
				CodeString message = null;
				if (r!=null) message = new CodeString(r.getItems(), r.count);
				textView.initCursorAndScrollPos();
				textView.setText(0, message);
				textView.setHides(false);
			}//if (func.isConstructor) {
			else {
				int indexOfFunctionName = func.functionNameIndex();
				
				cursorPosToMove = getCursorPos(compiler.data.mBuffer, indexOfFunctionName);
				
				// call listener, editText내의 해당 함수로 이동한다.
				callTouchListener(this, null);
				
				// 함수 내 제어블록(문)을 보여준다.
				FindFunctionParams function = func;
				ArrayListCodeChar r = getControlBlocksMessage(compiler.data.mBuffer, function, 0);
				
				CodeString message = null;
				if (r!=null) message = new CodeString(r.getItems(), r.count);
				textView.initCursorAndScrollPos();
				textView.setText(0, message);
				textView.setHides(false);
			}//if (func.isConstructor) {
		}
	}
	
	
	void processClick(Object addedInfo, MotionEvent e) {
		FindVarParams var = (FindVarParams) addedInfo;
		if (e.actionCode==MotionEvent.ActionDown) {//메시지를 보여준다.
			HighArray_CodeChar message;
			
			message = compiler.findNode_var_makeString( var, var.varNameIndex(), coreThreadID);
			textView.initCursorAndScrollPos();
			textView.setText(0, message.toCodeString());
			textView.setHides(false);
		}//if (e.actionCode==MotionEvent.ActionDown) {
		else if (e.actionCode==MotionEvent.ActionDoubleClicked) {//위치를 이동한다.
			if (this.listener!=null) {
				this.callTouchListener(this, e);
			}
		}// else if (e.actionCode==MotionEvent.ActionDoubleClicked) {//위치를 이동한다.
	}
	
	
	void processClick2(Object addedInfo, MotionEvent e) {
		FindFunctionParams func = (FindFunctionParams) addedInfo;
		if (e.actionCode==MotionEvent.ActionDown) {//메시지를 보여준다.
			HighArray_CodeChar message;
			if (func.isStaticBlock) {
				message = new HighArray_CodeChar(func.name, textColor);
			}
			else {
				message = compiler.findNode_func_makeString( func, func.functionNameIndex(), coreThreadID);
			}
			textView.initCursorAndScrollPos();
			textView.setText(0, message.toCodeString());
			textView.setHides(false);
		}//if (e.actionCode==MotionEvent.ActionDown) {
		else if (e.actionCode==MotionEvent.ActionDoubleClicked) {//위치를 이동한다.
			if (this.listener!=null) {
				this.callTouchListener(this, e);
			}
		}//else if (e.actionCode==MotionEvent.ActionDoubleClicked) {
		
	}
	
	int findIndex(Compiler compiler, FindClassParams curClass, String name, boolean isFunction) {
		if (/*!compiler.hasPairError && */curClass==null) return -1;
		
			if (isFunction) {
				if (curClass.listOfFunctionParams==null) return -1;
				int i;
				for (i=0; i<curClass.listOfFunctionParams.count; i++) {
					FindFunctionParams function = (FindFunctionParams)curClass.listOfFunctionParams.getItem(i);
					if (function.functionNameIndex()==-1) continue;
					CodeString functionName = compiler.data.mBuffer.getItem(function.functionNameIndex());
					if (functionName.equals(name)) {
						return function.functionNameIndex();
					}
				}
			}
			else {	// 변수
				if (curClass.listOfVariableParams==null) return -1;
				int i;
				for (i=0; i<curClass.listOfVariableParams.count; i++) {
					FindVarParams var = (FindVarParams)curClass.listOfVariableParams.getItem(i);
					if (var.isThis) continue;
					if (var.isSuper) continue;
					if (var.varNameIndex()==-1) continue;
					CodeString varName = compiler.data.mBuffer.getItem(var.varNameIndex());
					if (varName.equals(name)) {
						return var.varNameIndex();
					}
				}				
			}
		//}
		return -1;
	}
	
	FindFunctionParams findFunctionParams(FindClassParams curClass, String name) {
		if (/*!compiler.hasPairError && */curClass==null) return null;
		
			if (curClass.listOfFunctionParams==null) return null;
			int i;
			for (i=0; i<curClass.listOfFunctionParams.count; i++) {
				FindFunctionParams function = (FindFunctionParams)curClass.listOfFunctionParams.getItem(i);
				if (function.functionNameIndex()==-1) return null;
				CodeString functionName = src.getItem(function.functionNameIndex());
				if (functionName.equals(name)) {
					return function;
				}
			}
		//}
		return null;
	}
	
	/** 재귀적 호출, 일:다 관계, 
	 * 함수 내의 모든 제어블록(문)들을 (자식 제어블록(문)을 포함하여) 검색한다.
	 * @param listOfControls : 처음 호출시에는 함수의 listOfControlBlocks를 이용하여 호출
	 * @return : 함수내의 모든 제어블록(문), FindControlBlockParams[] 
	 */
	public ArrayListIReset getControlBlocks(ArrayListIReset listOfControls) {
		if (listOfControls==null) return null;
		ArrayListIReset r = new ArrayListIReset(10);
		r.resizeInc = 10;
		int k;
		int i;
		for (k=0; k<listOfControls.count; k++) {
			FindControlBlockParams control = (FindControlBlockParams)listOfControls.getItem(k);
			r.add(control);
			
			// child 제어블럭(문)
			ArrayListIReset temp = getControlBlocks(control.listOfControlBlocks);
			if (temp==null) continue;
			for (i=0; i<temp.count; i++) {
				r.add(temp.getItem(i));
			}
		}
		return r;
	}
	
	
	/** 재귀적 호출, 일:다 관계, 
	 * 함수 내의 모든 제어블록(문)들을 (자식 제어블록(문)을 포함하여) 검색한다.
	 * @param listOfControls : 처음 호출시에는 함수의 listOfControlBlocks를 이용하여 호출
	 * @param countOfSpace : 들여쓰기 개수
	 * @return : 함수내의 모든 제어블록(문), FindControlBlockParams[] 
	 */
	public ArrayListCodeChar getControlBlocksMessage(HighArray_CodeString src, 
			Block block, int countOfSpace) {
		//if (listOfControls==null) return null;
		ArrayListCodeChar r = new ArrayListCodeChar(200);
		int k;
		int i;
		ArrayListIReset listOfControls = block.listOfControlBlocks;
		//ArrayListIReset listOfSpecialBlocks = block.listOfSpecialBlocks;
		ArrayListIReset list = new ArrayListIReset(listOfControls.count/*+listOfSpecialBlocks.count*/);
					
		for (i=0; i<listOfControls.count; i++) {
			list.add(listOfControls.getItem(i));
		}
		/*for (i=0; i<listOfSpecialBlocks.count; i++) {
			list.add(listOfSpecialBlocks.getItem(i));
		}*/
		ArrayListIReset newList = new ArrayListIReset(list.count);
		CompilerStatic.SortByIndex(list, newList);
		
		for (k=0; k<newList.count; k++) {
			Object o = newList.getItem(k);
			if (o instanceof FindControlBlockParams) {
				FindControlBlockParams control = (FindControlBlockParams)o;
				if (control.catOfControls!=null) {
					ArrayListCodeChar message = toCodeString(src, control, countOfSpace); 
					r.concate( new CodeString(message.getItems(), message.count) );
					//r.add(control);
					
					// child 제어블럭(문)을 위한 재귀적호출, 들여쓰기를 위해 2를 증가
					ArrayListCodeChar temp = getControlBlocksMessage(src, control, countOfSpace+2);
					if (temp==null) continue;
					for (i=0; i<temp.count; i++) {
						r.add(temp.getItem(i));
					}
				}
				else {
					FindSpecialBlockParams control2 = (FindSpecialBlockParams)o;
					ArrayListCodeChar message = toCodeString(src, control2, countOfSpace); 
					r.concate( new CodeString(message.getItems(), message.count) );
					//r.add(control);
					
					// child 제어블럭(문)을 위한 재귀적호출, 들여쓰기를 위해 2를 증가
					ArrayListCodeChar temp = getControlBlocksMessage(src, control2, countOfSpace+2);
					if (temp==null) continue;
					for (i=0; i<temp.count; i++) {
						r.add(temp.getItem(i));
					}
				}
			}
		}
		return r;
	}
	
	
	
	/** @param listOfControls : 일렬로 늘어진 FindControlBlockParams[]*/
	public ArrayListCodeChar toCodeString(HighArray_CodeString src, ArrayListIReset listOfControls) {
		int i;
		ArrayListCodeChar r = new ArrayListCodeChar(100); 
		for (i=0; i<listOfControls.count; i++) {
			//String message = null;
			FindControlBlockParams control = (FindControlBlockParams)listOfControls.getItem(i);
			if (control!=null) {
				CategoryOfControls categoryOfControls = new CategoryOfControls(control.catOfControls.category); 
				r.concate( new CodeString(categoryOfControls.toString(), Common_Settings.textColor) );
				if (control.indexOfLeftParenthesis()>=0 && control.indexOfRightParenthesis()>=0) {
					CodeString[] condition = src.substring(control.indexOfLeftParenthesis(), 
							control.indexOfRightParenthesis()-control.indexOfLeftParenthesis()+1);
					int j;
					for (j=0; j<condition.length; j++) {
						r.concate(condition[j]);
					}
				}
				r.concate(new CodeString("\n", textColor));
			}
		}
		return r;
	}
	
	/** 해당 제어블록(문)에 대한 메시지를 리턴한다.
	 * @param control : FindControlBlockParams
	 * @param countOfSpace : 들여쓰기 개수*/
	public ArrayListCodeChar toCodeString(HighArray_CodeString src, FindControlBlockParams control, int countOfSpace) {
		if (control!=null) {
			ArrayListCodeChar r = new ArrayListCodeChar(50);
			int i;
			for (i=0; i<countOfSpace; i++) {
				r.add(new CodeChar('-', Common_Settings.textColor));
			}
			boolean isDefault = false;
			if (control.catOfControls!=null && 
					control.catOfControls.category==CategoryOfControls.Control_case) {
				if (src.getItem(control.nameIndex()).equals("default"))
					isDefault = true;
			}
			if (!isDefault) {
				r.concate( new CodeString(new CategoryOfControls(control.catOfControls.category).toString(), Common_Settings.keywordColor) );
			}
			else {
				r.concate(new CodeString("default", Common_Settings.keywordColor));
			}
			if (control.indexOfLeftParenthesis()>=0 && control.indexOfRightParenthesis()>=0) {
				CodeString[] condition = src.substring(control.indexOfLeftParenthesis(), 
						control.indexOfRightParenthesis()-control.indexOfLeftParenthesis()+1);
				int j;
				for (j=0; j<condition.length; j++) {
					r.concate(condition[j]);
				}
			}
			r.concate(new CodeString("\n", Common_Settings.textColor));
			return r;
		}
		return null;
	}
	
	/** 해당 제어블록(문)에 대한 메시지를 리턴한다.
	 * @param control : FindControlBlockParams
	 * @param countOfSpace : 들여쓰기 개수*/
	public ArrayListCodeChar toCodeString(HighArray_CodeString src, FindSpecialBlockParams control, int countOfSpace) {
		if (control!=null) {
			ArrayListCodeChar r = new ArrayListCodeChar(50);
			int i;
			for (i=0; i<countOfSpace; i++) {
				r.add(new CodeChar('-', Common_Settings.textColor));
			}
			r.concate( new CodeString(control.toString(), Common_Settings.keywordColor) );
			if (control.indexOfLeftParenthesis()>=0 && control.indexOfRightParenthesis()>=0) {
				CodeString[] condition = src.substring(control.indexOfLeftParenthesis(), 
						control.indexOfRightParenthesis()-control.indexOfLeftParenthesis()+1);
				int j;
				for (j=0; j<condition.length; j++) {
					r.concate(condition[j]);
				}
			}
			r.concate(new CodeString("\n", Common_Settings.textColor));
			return r;
		}
		return null;
	}
	
	
	
	FindClassParams findChildClass(FindClassParams curClass, String className) {
		if (curClass==null) return null;
		if (curClass.childClasses==null) return null;
		int i;			
		for (i=0; i<curClass.childClasses.count; i++) {
			FindClassParams item = (FindClassParams)curClass.childClasses.getItem(i);
			CodeString itemName = src.getItem(item.classNameIndex());
			if (itemName.equals(className)) {
				return item;
			}
		}
		return null;
		
	}
	
	FindClassParams findChildClass(ArrayListIReset listOfClass, String className) {
		if (listOfClass==null) return null;
					
		int i;			
		for (i=0; i<listOfClass.count; i++) {
			FindClassParams item = (FindClassParams)listOfClass.getItem(i);
			CodeString itemName = src.getItem(item.classNameIndex());
			if (itemName.equals(className)) {
				return item;
			}
		}
		return null;
		
	}
	
	
	public void open(boolean isOpen, OnTouchListener listener) {
		this.listener = listener;
		super.open(isOpen);
	}
	
	@Override
	public void draw(Canvas canvas) {
		menuClassAndMemberList.draw(canvas);
	
	}

	public void setButtons(Button[] list) {
		
		menuClassAndMemberList.setButtons(list);
	}


	public void destroy() {
		
		this.buttonSize = null;
		this.compiler = null;
		this.cursorPosToMove = null;
		if (this.menuClassAndMemberList!=null) {
			this.menuClassAndMemberList.destroy();
			this.menuClassAndMemberList = null;
		}
		this.name = null;
		if (this.menuClassAndMemberList!=null) {
			this.poolOfFileListButtons.destroy();
			this.poolOfFileListButtons = null;
		}
		this.selectedItem = null;
		this.src = null;
		this.textView = null;
	}
	
}
