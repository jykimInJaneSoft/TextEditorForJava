package com.gsoft.common.compiler.gui;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Point;

import com.gsoft.common.Code.CodeChar;
import com.gsoft.common.Code.CodeString;
import com.gsoft.common.CommonGUI;
import com.gsoft.common.Events.MotionEvent;
import com.gsoft.common.Sizing.Rectangle;
import com.gsoft.common.Sizing.Size;
import com.gsoft.common.Sizing.SizeF;
import com.gsoft.common.interfaces.OnTouchListener;
import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.CompilerStatic;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.Compiler_types_Base.Error;
import com.gsoft.common.compiler.EditText_Compiler;
import com.gsoft.common.compiler.HighArray_CodeString;
import com.gsoft.common.gui.Control;
import com.gsoft.common.gui.Control.Container;
import com.gsoft.common.gui.MenuWithScrollBar_EditText;
import com.gsoft.common.gui.Pool.PoolOfEditText;
import com.gsoft.common.gui.edittext.Edit.ScrollMode;
import com.gsoft.common.gui.edittext.EditText;
import com.gsoft.common.gui.edittext.FunctionOfEditText;
import com.gsoft.common.util.ArrayListIReset;

public class MenuProblemList_EditText extends Container implements OnTouchListener 
{
	MenuWithScrollBar_EditText menuProblemList;
	private PoolOfEditText poolOfFileListEditTexts;
	Size editTextSize;
	public int countOfNewLineChars;
	public int countOfCol;
	
	//Compiler compiler;
	public Error selectedError;
	
	public MenuProblemList_EditText( Rectangle bounds) {
		//this.compiler = compiler;
		this.bounds = bounds;
		this.editTextSize = new Size( (int)(Control.view.getWidth()*0.75f), (int)(Control.view.getHeight()*0.06f));
		createMenuList();
		createPoolOfFileListEditTexts();
	}
	
	public void setBackColor(int backColor) {
		menuProblemList.setBackColor(backColor);
	}
	
	public void changeBounds(Rectangle newBounds) {
		this.bounds = newBounds;
		this.editTextSize.width = (int)(Control.view.getWidth()*0.75f);
		//this.buttonSize.height = (int)(view.getHeight()*0.1f);
		if (menuProblemList!=null) {
			menuProblemList.changeBounds(newBounds, editTextSize);
		}
	}
	
	/** 영역만 잡아주고 menuClassAndMemberList 내용(Button[])은 나중에 createAndSetFileListButtons를
	 * 통해 넣어준다. 
	 * @param dir
	 * @param curDir
	 * @param category
	 */
	private void createMenuList() {
		if (menuProblemList==null) {
			menuProblemList = new MenuWithScrollBar_EditText(this, bounds, 
					editTextSize, 
					ScrollMode.VScroll);
			menuProblemList.setBackColor(backColor);
			menuProblemList.setOnTouchListener(this); // MenuWithScrollbar의 listener				
		}
	}
	
	/** FileListButtons 의 Pool을 활용하여 디렉토리를 바꿀 때마다 버튼들을 생성하지 않고 메모리를 절약한다.
	 * 즉 디렉토리를 바꾸면 버튼들을 새로 만드는 것이 아니라 pool에서 가져와서 버튼의 속성만 바꿔준다.
	 * (createFileListButtons참조)*/
	void createPoolOfFileListEditTexts() {
		if (poolOfFileListEditTexts==null) {
			poolOfFileListEditTexts = new PoolOfEditText(50, this.editTextSize);
		}
	}
	
	/*void setSrcAndErrors(HighArray_CodeString src, ArrayListIReset errors) {
	}*/
	
	/** errors를 EditText[]으로 리턴한다. This uses poolOfFileListEditTexts.*/
	public EditText[] getMenuListEditTexts(ArrayListIReset errors) {
		if (errors==null) return null;
		
		int editTextCount = errors.count + 1;
					
		int i;
		int editTextWidth = menuProblemList.originEditTextWidth;
		int editTextHeight = menuProblemList.originEditTextHeight;
		
		if (poolOfFileListEditTexts.list.capacity < editTextCount) {
			poolOfFileListEditTexts.setCapacity(editTextCount);
		}
		
		EditText[] editTexts = new EditText[editTextCount];
		
		int color;
		
		String textOfEditText0;
		if (errors.count==0) {
			textOfEditText0 = "No error";
		}
		else {
			textOfEditText0 = "Back";
		}
		
		color = Color.BLUE;
		editTexts[0] = (EditText) poolOfFileListEditTexts.getItem(0);
		editTexts[0].name = textOfEditText0;			
		editTexts[0].bounds.x = 0;
		editTexts[0].bounds.y = 0;
		editTexts[0].bounds.width = editTextWidth;
		editTexts[0].bounds.height = editTextHeight;
		editTexts[0].setBackColor(color);
		editTexts[0].isReadOnly = true;
		editTexts[0].setIsSingleLine(true);
		//editTexts[0].changeBounds(editTexts[0].bounds);
		editTexts[0].setText(0, new CodeString(editTexts[0].name,editTexts[0].textColor));			
		
		
		
		int editTextIndex = 1; 
		for (i=0; i<errors.count; i++) {
			Error error = (Error)errors.getItem(i);
			color = Color.WHITE;
			editTexts[editTextIndex] = (EditText) poolOfFileListEditTexts.getItem(editTextIndex);
			
			editTexts[editTextIndex].name = Integer.toString(i); // errors에서의 index
			editTexts[editTextIndex].bounds.x = 0;
			editTexts[editTextIndex].bounds.y = 0;
			editTexts[editTextIndex].bounds.width = editTextWidth;
			editTexts[editTextIndex].bounds.height = editTextHeight;
			editTexts[editTextIndex].setBackColor(color);
			editTexts[editTextIndex].isReadOnly = true;
			editTexts[editTextIndex].setIsSingleLine(true);
			//editTexts[editTextIndex].changeBounds(editTexts[editTextIndex].bounds);
			editTexts[editTextIndex].setText(0, new CodeString(error.msg+", "+error.compiler.data.filename,editTexts[editTextIndex].textColor));
			editTexts[editTextIndex].addedInfo = error;
			
			editTextIndex++;
		}
		
		
		/*EditTextGroup group = new EditTextGroup(null, editTexts);
		for (i=0; i<editTextCount; i++) {
			editTexts[i].setGroup(group, i);
		}*/
		
		return editTexts;
		
	}
	
			
	@Override
    public boolean onTouch(MotionEvent event, SizeF scaleFactor) {
    	boolean r=false;
    	if (event.actionCode==MotionEvent.ActionDown || event.actionCode==MotionEvent.ActionDoubleClicked) {
    		if (event.actionCode==MotionEvent.ActionDoubleClicked) {
    		}
	    	r = super.onTouch(event, scaleFactor);
	    	if (!r) {
	    		open(false);	// 영역에 상관없이 닫힌다.
	    		return true;
	    	}
	    	
	    	if (menuProblemList!=null) {
	    		r = menuProblemList.onTouch(event, null);
	    		if (r) return true;
	    	}
	    	return true;
    	}
    	else 
    		return false;
    }
	
	/** src에서 nameIndex까지의 "\n"의 개수를 센다. 
	 * 주석안의 "\n"은 세고 인용부호안의 "\n"은 세지 않는다.*/
	int getCountOfNewLineChars(HighArray_CodeString src2, int nameIndex) {
		int i;
		int count = 0;
		for (i=0; i<nameIndex; i++) {
			CodeString str = src2.getItem(i);
			CodeChar c = str.charAt(0);
			if (c.c=='\n') count++;
		}
		return count;
	}
	
	/** src에서 nameIndex를 갖는 토큰의 EditText상에서의 줄과 열번호를 알아낸다. 
	 * 시작시는 isStartOrEnd가 true, 끝날때는 false이다.*/
	Point getPoint(HighArray_CodeString src2, int nameIndex, boolean isStartOrEnd) {
		if (nameIndex<0) {
			return null;
		}
		int i;
		int row = 0; 
		int indexInSrc2OfRow = 0;
		int indexInSrc2OfCol = 0;
		for (i=0; i<nameIndex; i++) {
			CodeString str = src2.getItem(i);
			if (str==null) {
			}
			CodeChar c = str.charAt(0);
			if (c.c=='\n') {
				indexInSrc2OfRow = i+1;
				row++;
			}
		}
		if (row==1984) {
		}
		for (i=indexInSrc2OfRow; i<nameIndex; i++) {
			int len = src2.getItem(i).str.length();
			indexInSrc2OfCol += len;
		} 
		if (isStartOrEnd) {
			return new Point(indexInSrc2OfCol, row);
		}
		else {
			return new Point(indexInSrc2OfCol+src2.getItem(nameIndex).str.length()-1, row);
		}
	}
	
	
	public void MenuWithScrollBar_EditText_handler(Object sender) {
		ThreadMenuWithScrollBar_EditText_handler thread = new ThreadMenuWithScrollBar_EditText_handler(this, sender);
		thread.start();
	}
	
	static class ThreadMenuWithScrollBar_EditText_handler extends Thread {
		private MenuProblemList_EditText owner;
		private Object sender;
		public ThreadMenuWithScrollBar_EditText_handler(
				MenuProblemList_EditText owner, Object sender) {
			
			this.owner = owner;
			this.sender = sender;
		}
		public void run() {
			owner.MenuWithScrollBar_EditText_handler_sub(sender);
			Control.view.postInvalidate();
		}
	}
	
	
	void MenuWithScrollBar_EditText_handler_sub(Object sender) {
		MenuWithScrollBar_EditText menu = (MenuWithScrollBar_EditText)sender;
		String nameOfEditText = menu.selectedEditTextName;
		if (nameOfEditText==null) return;
		if (nameOfEditText.equals("Back") || nameOfEditText.equals("No error")) {					
			setHides(true);
		}
		else {
			if (menu.selectedEditText==null) return;
			//compiler.menuClassAndMemberList.open(false);
			
			EditText selectedEditText = menu.selectedEditText;
			Error error = (Error)selectedEditText.addedInfo;
			
			int indexStart = error.startIndex();
			int indexEnd = error.endIndex();
			Compiler document = error.compiler;
			
			/*if (document.data.disposed) {
				// When building, error.compiler was erased.
				CompilerInterface compiler = new CompilerInterface();
				compiler.start2(Common_Settings.backColor, document.data.filename, 0);
				
				document.data.filename = null;
				document.data = null;
				
				document = compiler;
			}*/
			
			FindClassParams classParams = null;
			for (int q=0; q<document.data.mlistOfClass.count; q++) {
				classParams = (FindClassParams) document.data.mlistOfClass.getItem(q);
				if (classParams==null) continue;
				break;
			}
			int lineNumber = CompilerStatic.getCursorPosYInSrc(document, indexStart)+1;
			
			if (classParams!=null) {
				CommonGUI.editText_compiler.moveToLineNumber(classParams, lineNumber, false, classParams.name, true);
			}
			else {
				// package Test8 without class
				CommonGUI.editText_compiler.openCompilerDocument(document.data.filename);
			}
			
			if (indexStart==-1 || indexEnd==-1) {
				if (indexStart==-1 && indexEnd!=-1) {
					CommonGUI.loggingForMessageBox.setText(true, "invalid error start index ", false);
					indexStart = indexEnd;
				}
				else if (indexEnd==-1 && indexStart!=-1) {
					CommonGUI.loggingForMessageBox.setText(true, "invalid error end index ", false);
					indexEnd = indexStart;
				}
				else if (indexStart==-1 && indexEnd==-1) {
					CommonGUI.loggingForMessageBox.setText(true, "invalid error index ", false);
					CommonGUI.loggingForMessageBox.setHides(false);
					Control.view.invalidate();
					return;
				}
				CommonGUI.loggingForMessageBox.setHides(false);
				Control.view.invalidate();
			}
			if (indexEnd==1984) {
			}
			Point p1 = getPoint(document.data.mBuffer, indexStart, true);
			Point p2 = getPoint(document.data.mBuffer, indexEnd, false);
			
			if (p1.y==154) {
			}
			
			countOfNewLineChars = p1.y;
			countOfCol = /*p2.x*/p1.x;
			this.selectedError = error;
			//countOfNewLineChars = getCountOfNewLineChars(compiler.mBuffer, indexStart);
			if (listener!=null && listener instanceof EditText) {
				EditText editText = (EditText) listener;
				FunctionOfEditText.makeSelectIndices(editText, true, p1, p2);
				editText.isSelecting = true;
				CommonGUI.keyboard.setOnTouchListener(listener);
			}
			
			// call listener
			callTouchListener(this, null);
		}
	}

	/** listOfClass가 1보다 큰 경우(즉 파일하나에 중첩되지 않은 클래스가 여러 개 있으면, 루트라 이름붙인다.)
	 * 루트에서는  parentClassParams=null, curClassParams=null이다. 
	 * 1인 경우는 parentClassParams=첫번째 클래스, curClassParams=첫번째클래스이다.*/
	@Override		
	public void onTouchEvent(Object sender, MotionEvent e) {
		
		try {
		if (sender instanceof MenuWithScrollBar_EditText) {
			MenuWithScrollBar_EditText_handler(sender);
		}
		}catch(Exception e1) {
			e1.printStackTrace();
			CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e1);
		}
		
	}
	
			
	@Override
	public void draw(Canvas canvas) {
		menuProblemList.draw(canvas);
	}

	public void setEditTexts(EditText[] list) {
		
		menuProblemList.setEditTexts(list);
	}

	public void open(boolean isOpen, EditText_Compiler editText_Compiler) {
		
		super.open(isOpen);
		if (isOpen) {
			this.listener = editText_Compiler;
		}
	}
	
}
