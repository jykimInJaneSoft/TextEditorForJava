package com.gsoft.common.compiler.gui;

import com.gsoft.common.CommonGUI;
import com.gsoft.common.Events.MotionEvent;
import com.gsoft.common.Sizing.Rectangle;
import com.gsoft.common.compiler.Compiler;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.Compiler_types.FindFunctionParams;
import com.gsoft.common.compiler.Compiler_types.FindVarParams;
import com.gsoft.common.compiler.Compiler_types_Base.FindPackageParams;
import com.gsoft.common.gui.Buttons.Button;
import com.gsoft.common.gui.MenuWithScrollBar;
import com.gsoft.common.util.HighArray_CodeChar;

import com.gsoft.common.compiler.gui.MenuClassAndMemberListBase;

public class MenuClassAndMemberListWhenInputtingDot extends MenuClassAndMemberListBase {
	
	
	/**"all"(not filter), "a"(chars to filter), only lower case*/
	public String filter;


	public MenuClassAndMemberListWhenInputtingDot(Compiler compiler,
			Rectangle bounds, int coreThreadID) {
		super(compiler, bounds, coreThreadID);
		
		
		
	}
	
	public void changeBounds(Rectangle bounds) {
		super.changeBounds(bounds);
	
	
	}
	
	/** listOfClass가 1보다 큰 경우(즉 파일하나에 중첩되지 않은 클래스가 여러 개 있으면, 루트라 이름붙인다.)
	 * 루트에서는  parentClassParams=null, curClassParams=null이다. 
	 * 1인 경우는 parentClassParams=첫번째 클래스, curClassParams=첫번째클래스이다.*/
	@Override		
	public void onTouchEvent(Object sender, MotionEvent e) {
		
		try {
		 if (sender instanceof MenuWithScrollBar) {
						
			
			MenuWithScrollBar menu = (MenuWithScrollBar)sender;
			String nameOfButton = menu.selectedButtonName;
			
			if (nameOfButton==null) return;
			
			Button selectedButton = menu.selectedButton;
			Object addedInfo = selectedButton.addedInfo;
			
			this.selectedItem = selectedButton;
			
			if (nameOfButton.equals("Back")) {
				
			}//back
			else if (nameOfButton.equals("Move")) {
				
				if (this.listener!=null) {
					this.callTouchListener(this, e);
				}
			}
			else {
				if (addedInfo instanceof FindPackageParams) { // Package
					if (e.actionCode==MotionEvent.ActionDown) {//메시지를 보여준다.
						String message = "Directory "+	selectedButton.text;
						CommonGUI.loggingForMessageBox.setText(true, message, false);
						CommonGUI.loggingForMessageBox.setHides(false);
					}//if (e.actionCode==MotionEvent.ActionDown) {
					else if (e.actionCode==MotionEvent.ActionDoubleClicked) {
						if (this.listener!=null) {
							this.callTouchListener(this, e);
						}
					}
				}
				else if (addedInfo instanceof FindClassParams) { // class
				
					if (e.actionCode==MotionEvent.ActionDown) {//메시지를 보여준다.
						String message = "Class "+	selectedButton.text;
						CommonGUI.loggingForMessageBox.setText(true, message, false);
						CommonGUI.loggingForMessageBox.setHides(false);
					}//if (e.actionCode==MotionEvent.ActionDown) {
					else if (e.actionCode==MotionEvent.ActionDoubleClicked) {
						if (this.listener!=null) {
							this.callTouchListener(this, e);
						}
					}
				}
				else if (addedInfo instanceof FindFunctionParams) {
					processClick2(addedInfo, e);
					
				}//else if (addedInfo instanceof FindFunctionParams) {
				else if (addedInfo instanceof FindVarParams) {
					processClick(addedInfo, e);
				}
			}// back
			
		}//else if (sender instanceof MenuWithScrollBar) {
		}catch(Exception e1) {
			e1.printStackTrace();
			CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e1);
		}
		
	}//onTouchEvent()
	
	
	void processClick(Object addedInfo, MotionEvent e) {
		FindVarParams var = (FindVarParams) addedInfo;
		//selectedItem = var;
		if (e.actionCode==MotionEvent.ActionDown) {//메시지를 보여준다.
			HighArray_CodeChar message;
			
			message = compiler.findNode_var_makeString( var, var.varNameIndex(), coreThreadID);
			textView.initCursorAndScrollPos();
			textView.setText(0, message.toCodeString());
			textView.setHides(false);
		}//if (e.actionCode==MotionEvent.ActionDown) {
		else if (e.actionCode==MotionEvent.ActionDoubleClicked) {//위치를 이동한다.
			if (this.listener!=null) {
				this.callTouchListener(this, e);
			}
		}// else if (e.actionCode==MotionEvent.ActionDoubleClicked) {//위치를 이동한다.
	}
	
	
	void processClick2(Object addedInfo, MotionEvent e) {
		FindFunctionParams func = (FindFunctionParams) addedInfo;
		//selectedItem = func;
		if (e.actionCode==MotionEvent.ActionDown) {//메시지를 보여준다.
			HighArray_CodeChar message;
			if (func.isStaticBlock) {
				message = new HighArray_CodeChar(func.name, textColor);
			}
			else {
				message = compiler.findNode_func_makeString( func, func.functionNameIndex(), coreThreadID);
			}
			textView.initCursorAndScrollPos();
			textView.setText(0, message.toCodeString());
			textView.setHides(false);
		}//if (e.actionCode==MotionEvent.ActionDown) {
		else if (e.actionCode==MotionEvent.ActionDoubleClicked) {//위치를 이동한다.
			if (this.listener!=null) {
				this.callTouchListener(this, e);
			}
		}//else if (e.actionCode==MotionEvent.ActionDoubleClicked) {
		
		
		
		
	}

}
