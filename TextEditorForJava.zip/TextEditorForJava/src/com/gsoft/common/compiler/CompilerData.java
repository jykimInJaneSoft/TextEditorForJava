package com.gsoft.common.compiler;

import android.graphics.Point;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.IO_types.TextFormat;
import com.gsoft.common.compiler.Compiler_types.Language;
import com.gsoft.common.compiler.classloader.PathClassLoader;
import com.gsoft.common.compiler.debug.BreakPoint;
import com.gsoft.common.compiler.gui.MenuClassAndMemberList;
import com.gsoft.common.compiler.gui.MenuClassAndMemberListWhenInputtingDot;
import com.gsoft.common.compiler.gui.MenuProblemList_EditText;
import com.gsoft.common.gui.TextView;
import com.gsoft.common.gui.edittext.RedoBufferOfEditText;
import com.gsoft.common.gui.edittext.UndoBufferOfEditText;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListIReset;
import com.gsoft.common.util.ArrayListInt;
import com.gsoft.common.util.ArrayListString;
import com.gsoft.common.util.HighArray;
import com.gsoft.common.util.HighArray_CodeChar;
import com.gsoft.common.util.HighArray_char;
import com.gsoft.common.util.Stack;
import com.gsoft.common.util.hash.Hashtable2_String;

import com.gsoft.common.compiler.CompilerStatic;
import com.gsoft.common.compiler.HighArray_CodeString;

public class CompilerData {
	/**If CompilerData.destroy() is called, disposed is true*/
	public boolean disposed;
	
	/** compiler마다 공유이므로 static이어야하나 현재는 tab문제와 src연결문제로 non-static,
	 * 다중문서를 열기 위해서는 Compiler클래스들의 리스트를 갖고 있으면 된다.*/
	public static MenuProblemList_EditText menuProblemList_EditText = CompilerStatic.menuProblemList_EditText;
	
	/** LogBird를 위한 textView*/
	static TextView textViewLogBird = CompilerStatic.textViewLogBird;
	
	/** 수식트리를 위한 textView*/
	public static TextView textViewExpressionTreeAndMessage = CompilerStatic.textViewExpressionTreeAndMessage;
	
	/** java.lang 패키지내에 있는 loadJavaLangPackage()에서 읽어들인다.*/
	static ArrayListString TypesOfDefaultLibraryOfJava = CompilerStatic.TypesOfDefaultLibraryOfJava;
	
	public static ArrayListIReset errors = CompilerStatic.errors;
	
	/**FindClassParams[], 
	 * 현재 소스파일에서 정의된 클래스나 import된 클래스, 이 소스파일에서
	 * 읽어들인 클래스들이 등록된 클래스들의 집합, 
	 * 나중에 현재 소스파일이 아니라 전체 프로젝트 단위의 클래스집합으로 바꿀것이다.*/
	//public static ArrayListIReset mlistOfAllClasses = CompilerStatic.mlistOfAllClasses;
	/** mlistOfAllClasses의 해시리스트*/
	//public static Hashtable2_String mlistOfAllClassesHashed  = CompilerStatic.mlistOfAllClassesHashed;
	
	
	
	/** CompilerHelper.loadClassFromSrc_onlyInterface()에서 이미 로드를 시도했지만 실패한 소스파일의 리스트*/
	//public static ArrayListString mlistOfLoadClassFromSrc_onlyInterface_failed = CompilerStatic.mlistOfLoadClassFromSrc_onlyInterface_failed;
	
	/**ThrowStartEnd[]*/
	public Stack throwStack = new Stack();
	/**ThrowStartEnd[], topmost ThrowStartEnd list*/
	public ArrayList listOfThrowStartEnd = new ArrayList(2);
	
	
	/**File[], path list, 필요한 파일만을 컴파일하기 위한 리스트<br>
	 * CompilerData의 인스턴스 멤버이다.<br>
	 * CompilerCache, ClassCache에서 캐시된 자바 파일을 로드(EditText_Compiler.loadCompilerDocument()에서)하더라도 안전하다.<br>
	 * EditText_Compiler.loadCompilerDocument()의 new CompilerInterface()에서 새로 만들어지고 
	 * 자신의 파일외에 다른 파일들은 loadClass()에서 추가되고 
	 * 자신의 소스파일은 ThreadBuild.run()에서 추가된다.<br>
	 * 소스파일이 바뀔 때에는 Update.Update2()에서 reset()되고 다시 추가된다.*/
	//public ListOfBuild1OrPart listOfBuild1OrPart = new ListOfBuild1OrPart();
	
	
	public MenuClassAndMemberList menuClassAndMemberList;
	
	public MenuClassAndMemberListWhenInputtingDot menuClassAndMemberListWhenInputtingDot;
	
	
	public Language language;
	
	public TextFormat textFormat;
	
	
	boolean mIsCompileAll = false;
	
	/**문서마다 하나씩 존재한다. */
	public ArrayListInt listOfBreakPoints = new ArrayListInt(10);

	
	public HighArray_CodeString mBuffer/* = new HighArray_CodeString(1)*/;
	
	public HighArray_CodeChar strInput/* = new HighArray_CodeChar(1)*/;
	public HighArray_CodeChar strOutput/* = new HighArray_CodeChar(1)*/;
	
	/** file path*/
	public String filename = null;
	
	
	
	/**setLanguage()를 참조한다.*/	
	ArrayListString Types = new ArrayListString(1);
	/**setLanguage()를 참조한다.*/
	ArrayListString Keywords = new ArrayListString(1);
	/**setLanguage()를 참조한다.*/
	ArrayListString AccessModifiers = new ArrayListString(1);
	/**setLanguage()를 참조한다.*/
	ArrayListString TypesOfDefaultLibrary = new ArrayListString(1);
	
	
	
	/** 가장 바깥(inner가 아닌) 클래스의 리스트*/
	public ArrayListIReset mlistOfClass = new ArrayListIReset(1);
	
	
	
	
	
	
	
	/** 파일에서 정의하는 모든 클래스들*/
	public ArrayListIReset mlistOfAllDefinedClasses = new ArrayListIReset(5);
	
	/** Short name을 사용할수 있는 클래스들, 
	 * import된 클래스들, 파일에서 정의하는 클래스들, findClassUsing에서 사용한다. 
	 * 참고로 같은 패키지내 클래스들은 findMemberUsesUsingNamespace_sub에서 로드를 하기 때문에 
	 * 여기에는 없다.*/
	//ArrayListIReset mlistOfAllClassesThatCanUseShortName = new ArrayListIReset(10);
	
	/**FindFunctionParams[]*/
	public ArrayListIReset mlistOfAllFunctions = new ArrayListIReset(50);
	/**FindVarParams[]*/
	HighArray mlistOfAllLocalVarDeclarations = new HighArray(100);
	/**FindVarParams[]*/
	HighArray mlistOfAllMemberVarDeclarations = new HighArray(100);
	/**FindVarUseParams[]*/
	public HighArray mlistOfAllVarUses = new HighArray(200);
	/**key는 varUse.originName*/
	public Hashtable2_String mlistOfAllVarUsesHashed = new Hashtable2_String(50, 20);
	
	/**FindControlBlockParams[]*/
	public ArrayListIReset mlistOfAllControlBlocks = new ArrayListIReset(200);
	/**FindControlBlockParams[]*/
	public ArrayListIReset mlistOfAllForLoops = new ArrayListIReset(50);
	
	/**TypeCast[], 파일안의 모든 타입캐스트 리스트*/
	ArrayListIReset mlistOfAllTypeCasts = new ArrayListIReset(20);
	/** 같은 패키지내 클래스 리스트*/
	ArrayListString mSamePackageClasses = new ArrayListString(1);
	/** 같은 패키지내 파일 리스트, 그러므로 디렉토리명을 제외한 확장자 포함 파일이름만 가진다*/
	public ArrayListString mListOfFileOfSamePackage = new ArrayListString(1);
	
	/**FindArrayIntializerParams[], 파일안의 모든 배열초기화문 리스트*/
	public ArrayListIReset mlistOfAllArrayIntializers = new ArrayListIReset(20);
	
	
	
	/**String[]*/	
	public ArrayListString mlistOfImportedClasses = new ArrayListString(50);
	
	/**String[], import com.gsoft.common.Util.*;이와 같은 경우*/	
	public ArrayListString mlistOfImportedClassesStar = new ArrayListString(50);
	
	/**FindThreeOperandsOperation[]*/
	public ArrayListIReset mlistOfThreeOperandsOperation = new ArrayListIReset(1); 
	
	
	
	/**FindStatementParams[], 변수사용 다음에 '='이 오는 할당문, 
	 * 조건문, 반복문에 있는 할당문을 포함한 모든 할당문*/
	ArrayListIReset mlistOfAllAssignStatements = new ArrayListIReset(200);
	
	/** FindAssignStatementParams[], 변수사용 다음에 '='이 오는 할당문, 
	 * 그러나 조건문, 반복문에 할당문이 있을수 있으므로 그것을 제외한다.*/
	ArrayListIReset mlistOfAssignStatements = new ArrayListIReset(100);
	
	
	
	/** FindSpecialStatementParams[]*/
	ArrayListIReset mlistOfSpecialStatement = new ArrayListIReset(60);
	
	/** 최상위 템플릿만 모아놓은 리스트, Template[]*/
	ArrayListIReset mlistOfAllTemplates = new ArrayListIReset(10);
	
	
	
	
	/** FindBlockParams[] : '{':startIndex(), '}':endIndex, 
	 * CheckParenthesis의 인덱스 정보를 저장한다.*/
	ArrayListIReset mlistOfBlocks = new ArrayListIReset(200);
	
	
	
	
	/** fullname constructor의 타입의 리스트, Constructor[]*/
	ArrayListIReset mlistOfAllConstructor = new ArrayListIReset(20);
	
	
	//ArrayListIReset mlistOfSynchronizedBlocks = new ArrayListIReset(5);
	
	
	/** 파일상의 Annotation들의 리스트, 문장의 리스트를 만들때 사용, Annotation[],
	 * mlistOfFindStatementParams을 참조*/
	ArrayListIReset mlistOfAnnotations = new ArrayListIReset(30);
	
	/** 파일상의 ImportStatement들의 리스트, 문장의 리스트를 만들때 사용, ImportStatement[],
	 * mlistOfFindStatementParams을 참조*/
	public ArrayListIReset mlistOfImportStatements = new ArrayListIReset(50);
	
	/** 파일상의 PackageStatement들의 리스트, 문장의 리스트를 만들때 사용, PackageStatement[],
	 * mlistOfFindStatementParams을 참조*/
	public ArrayListIReset mlistOfPackageStatements = new ArrayListIReset(2);
	
	
	/** 파일상의 FindStatementParams들의 리스트, 문장의 리스트를 만들때 사용, FindStatementParam[],
	 * package, import, class, 함수, 제어블록, 변수선언, 주석, 애노테이션 등도 
	 * 모두 문장들(FindStatementParams)이므로 
	 * 파일을 문장들의 리스트로 만들수있다.*/
	ArrayListIReset mlistOfFindStatementParams = new ArrayListIReset(1000);
	
	
	
	 
	
	/** ArrayListString[], 
	 * Character$Subset.class인 경우 item(ArrayListString)에는 Character, Subset순으로 들어간다.*/
	//static ArrayListIReset TypesOfDefaultLibraryOfJava2 = new ArrayListIReset(20);
	
	/** 배열원소는 ArrayListString, 즉 ArrayListString[], 
	 * 파일이름만 들어가므로 전체 디렉토리이름은 
	 * Control.pathAndroid + File.separator + mlistOfImportedClassesStar[i] + 해당파일이름 이다.
	 * 예를들어 해당파일이름이 HashTable이고 mlistOfImportedClassesStar[i]가 com.gsoft.common.Util일 경우
	 * 전체 파일명은 /sdcard/gsoft/com/gsoft/common/Util/HashTable 이 된다.*/
	ArrayListIReset TypesOfImportStarOfJava = new ArrayListIReset(10);
	
	/** .class 파일을 load 할 경우 null 이 아님.*/
	public PathClassLoader mLoader;
	
	/** 파일에 있는 모든 finally절, FindControlBlockParams[]*/
	public ArrayListIReset mlistOfFinally = new ArrayListIReset(10);
	
	/** 파일에 있는 모든 return문, FindSpecialStatementParams[]*/
	//ArrayListIReset mlistOfReturn = new ArrayListIReset(10);
	
	
	/**TempLocalArrayInitializer[] <br>
	 * new ProcessBuilder("java", "-jar", "***.jar")와 같은 함수인 경우 String[]임시지역변수<br>
	System.out.printf("%d %f", 1, 0.5f)와 같은 함수인 경우 Object[]
	임시지역변수를 만들기 위해 FindFunctionParams.equals(HighArray_CodeString src, String funcName, ArrayListIReset listOfFuncCallParams...)
	에서 등록한다.*/
	public ArrayList mlistOfTempLocalArrayInitializers = new ArrayList(10);
	
	/**FindPackageParams[]*/
	ArrayList mlistOfPackages = new ArrayList(1);
	
	public String packageName;
	
	
	
	/**모든 '\n'의 mBuffer에서의 인덱스를 넣은 리스트*/ 
	public ArrayListInt mlistOfNewLines = new ArrayListInt(1);
	
	
	
	/** checkParenthesisAll에서 괄호에러를 검출하면 hasPairError가 true로 설정되어
	 * 함수, 제어블록 등은 각자 자신이 괄호 쌍을 찾게 된다. 
	 * checkParenthesisAll에서 괄호에러를 검출하지 못하면 
	 * 클래스, 함수, 제어블록 등은 괄호 인덱스 캐시(listOfBlocks)에서 괄호 인덱스를 찾는다. 
	 */
	public //private boolean hasPairError;
	//private boolean hasRightPairError;
	
	/** 파일상의 주석, 다큐주석들의 리스트, 문장의 리스트를 만들때 사용, Comment[], 
	 * mlistOfFindStatementParams을 참조, StringTokenizer에서 만든다.*/
	ArrayListIReset mlistOfComments = new ArrayListIReset(10);

	/** Common_Settings.pathProject 외부에 있는 파일을 읽을 경우 true*/
	public boolean isOutsideOfProject;

	
	
	public boolean isModified;
	
	
	Point cursorPos = new Point();
	
	public BreakPoint lineNumberShowingArrow;
	
	public CodeString[] textArray;
	
	int vScrollPos;
	
	int widthOfhScrollPos;
	
	public int numOfLines;
	
	public boolean isSelecting;
	int selectLenY;
	/**selectIndices 좌표 구성은 makeSelectIndices()를 참조한다. Point[]*/
	Point[] selectIndices = new Point[100];
	int selectIndicesCount = 0;
	
	public boolean isFound;
	int findLenY;
	/**findIndices 좌표 구성은 makeFindIndices()를 참조한다. Point[]*/
	Point[] findIndices = new Point[100];
	int findIndicesCount = 0;
	
	
	UndoBufferOfEditText undoBuffer = new UndoBufferOfEditText();
	RedoBufferOfEditText redoBuffer = new RedoBufferOfEditText();

	public boolean isReadOnly;

	
	
	public HighArray_char getText2() {
		int i;
		HighArray_char r = new HighArray_char(100);
		try {
		for (i=0; i<numOfLines; i++) {
			r.add(textArray[i].str);
		}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return r;
	}

	
	public CompilerData() {
		textArray = new CodeString[10];
		
	}
	
	/** 모든 메모리 자원들을 해제한다.*/
	public void destroy() {
		this.disposed = true;
		
		if (this.menuClassAndMemberList!=null) {
			this.menuClassAndMemberList.destroy();
			this.menuClassAndMemberList = null;
		}
		if (this.menuClassAndMemberListWhenInputtingDot!=null) {
			this.menuClassAndMemberListWhenInputtingDot.destroy();
			this.menuClassAndMemberListWhenInputtingDot = null;
		}
		if (this.mBuffer!=null) {
			this.mBuffer.destroy();
			this.mBuffer = null;
		}
		if (this.mlistOfAllArrayIntializers!=null) {
			this.mlistOfAllArrayIntializers.destroy();
			this.mlistOfAllArrayIntializers = null;
		}
		if (this.mlistOfAllAssignStatements!=null) {
			this.mlistOfAllAssignStatements.destroy();
			this.mlistOfAllAssignStatements = null;
		}
		if (this.mlistOfAssignStatements!=null) {
			this.mlistOfAssignStatements.destroy();
			this.mlistOfAssignStatements = null;
		}
		if (this.mlistOfAllConstructor!=null) {
			this.mlistOfAllConstructor.destroy();
			this.mlistOfAllConstructor = null;
		}
		if (this.mlistOfAllControlBlocks!=null) {
			this.mlistOfAllControlBlocks.destroy();
			this.mlistOfAllControlBlocks = null;
		}
		if (this.mlistOfAllDefinedClasses!=null) {
			this.mlistOfAllDefinedClasses.destroy();
			this.mlistOfAllDefinedClasses = null;
		}
		if (this.mlistOfAllFunctions!=null) {
			this.mlistOfAllFunctions.destroy();
			this.mlistOfAllFunctions = null;
		}
		if (this.mlistOfAllLocalVarDeclarations!=null) {
			this.mlistOfAllLocalVarDeclarations.destroy();
			this.mlistOfAllLocalVarDeclarations = null;
		}
		if (this.mlistOfAllMemberVarDeclarations!=null) {
			this.mlistOfAllMemberVarDeclarations.destroy();
			this.mlistOfAllMemberVarDeclarations = null;
		}
		if (this.mlistOfAllTemplates!=null) {
			this.mlistOfAllTemplates.destroy();
			this.mlistOfAllTemplates = null;
		}
		if (this.mlistOfAllTypeCasts!=null) {
			this.mlistOfAllTypeCasts.destroy();
			this.mlistOfAllTypeCasts = null;
		}
		if (this.mlistOfAllVarUses!=null) {
			this.mlistOfAllVarUses.destroy();
			this.mlistOfAllVarUses = null;
		}
		if (this.mlistOfAllVarUsesHashed!=null) {
			this.mlistOfAllVarUsesHashed.reset();
			this.mlistOfAllVarUsesHashed = null;
		}
		if (this.mlistOfAnnotations!=null) {
			this.mlistOfAnnotations.destroy();
			this.mlistOfAnnotations = null;
		}
		if (this.mlistOfBlocks!=null) {
			this.mlistOfBlocks.destroy();
			this.mlistOfBlocks = null;
		}
		if (this.mlistOfClass!=null) {
			this.mlistOfClass.destroy();
			this.mlistOfClass = null;
		}
		
		if (this.mListOfFileOfSamePackage!=null) {
			this.mListOfFileOfSamePackage.destroy();
			this.mListOfFileOfSamePackage = null;
		}
		if (this.mlistOfFindStatementParams!=null) {
			this.mlistOfFindStatementParams.destroy();
			this.mlistOfFindStatementParams = null;
		}
		if (this.mlistOfImportedClasses!=null) {
			this.mlistOfImportedClasses.destroy();
			this.mlistOfImportedClasses = null;
		}
		if (this.mlistOfImportedClassesStar!=null) {
			this.mlistOfImportedClassesStar.destroy();
			this.mlistOfImportedClassesStar = null;
		}
		if (this.mlistOfImportStatements!=null) {
			this.mlistOfImportStatements.destroy();
			this.mlistOfImportStatements = null;
		}
		/*if (this.mlistOfIndependentFuncCall!=null) {
			this.mlistOfIndependentFuncCall.reset();
			this.mlistOfIndependentFuncCall = null;
		}*/
		if (this.mlistOfPackages!=null) {
			mlistOfPackages.destroy();
			this.mlistOfPackages = null;
		}
		
		if (this.mlistOfPackageStatements!=null) {
			this.mlistOfPackageStatements.destroy();
			this.mlistOfPackageStatements = null;
		}
		if (this.mlistOfSpecialStatement!=null) {
			this.mlistOfSpecialStatement.destroy();
			this.mlistOfSpecialStatement = null;
		}
		this.AccessModifiers = null;
		//this.filename = null;
		this.Keywords = null;
		this.language = null;
		this.Types = null;
		// TypesOfDefaultLibraryOfJava은 static 이고
		// setLanguage()에서 loadJavaLangPackage()에서 읽어들인다.
		
		if (this.TypesOfImportStarOfJava!=null) {
			TypesOfImportStarOfJava.destroy();
			TypesOfImportStarOfJava = null;
		}
		if (this.mSamePackageClasses!=null) {
			this.mSamePackageClasses.destroy();
			mSamePackageClasses = null;
		}
		this.packageName = null;
		
		if (this.mLoader!=null) {
			this.mLoader.destroy();
			this.mLoader = null;
		}
		
	} // reset();
}
