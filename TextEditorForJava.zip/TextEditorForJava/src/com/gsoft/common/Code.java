package com.gsoft.common;

import com.gsoft.common.interfaces.IReset;
import com.gsoft.common.util.Array;
import com.gsoft.common.util.HighArray_char;

import android.graphics.Color;
import com.gsoft.common.Common_Settings;

public class Code {
	public static class CodeChar implements IReset {
		public char c;
		public int color = Color.BLACK;
		public byte type;
		boolean isErrorChar;
		
		public boolean getIsErrorChar() {
			return this.isErrorChar;
		}
		public void setIsErrorChar(boolean isErrorChar) {
			this.isErrorChar = isErrorChar;
		}
		public CodeChar(char c, int color) {
			this.c = c;
			this.color = color;
		}
		public CodeChar(char c, int color, byte type) {
			this.c = c;
			this.color = color;
			this.type = type;
		}
		public String toString() {
			char[] arr = {c};
			return new String(arr);
		}
		public Object clone() {
			CodeChar r = new CodeChar(this.c, this.color, this.type);
			return r;
		}
		
		/** = 와 같다, new로 새로 할당하는 것이 아니라 기존 메모리를 재사용한다.*/
		public void copy(CodeChar c) {
			this.c = c.c;
			this.color = c.color;
			this.type = c.type;
		}
		public void destroy() {
			
			
		}
	}
	
	public static class CodeStringType {
		public static byte Text = 1;
		public static byte Keyword = 2;
		public static byte FuncUse = 3;
		public static byte MemberVarDecl = 4;
		public static byte MemberVarUse = 5;
		public static byte Constant = 6;
		public static byte Parenthesis = 7;
		public static byte Comment = 8;
		public static byte DocuComment = 9;
		public static byte Annotation = 10;
	}
	
	public static class CodeString implements IReset {
		//boolean isStruct;
		
		//char[] listChar;
		//int[] listColor;
		
		public CodeChar[] listCodeChar;
		public int count;
		
		/** cache이다. toString()에서 CodeString을 String으로 변환하는 비용을 제거한다.*/
		public String str;
		
		/** types이 없으므로 CodeChar의 type은 null이다.*/
		public CodeString(char[] text, int[] colors) {
			
			int i;
			listCodeChar = new CodeChar[text.length];
			count = text.length;
			for (i=0; i<text.length; i++) {
				listCodeChar[i] = new CodeChar(text[i], colors[i]);
			}
			this.str = new String(text);
		}
		
		/** CodeString에 CodeStringType이 있는게 아니라 CodeChar에 있어야 한다. 
		 * 왜냐하면 editText의 setText가 ArrayListCodeChar혹은 CodeString이기 때문이다.
		 * CodeString에 type이 있다면 setText호출시 CodeString으로 변환할때 type이 소실된다. 
		 * @param text
		 * @param colors
		 * @param types
		 */
		public CodeString(char[] text, int[] colors, byte[] types) {
			
			int i;
			listCodeChar = new CodeChar[text.length];
			count = text.length;
			for (i=0; i<text.length; i++) {
				listCodeChar[i] = new CodeChar(text[i], colors[i], types[i]);
			}
			this.str = new String(text);
		}
		
		public CodeString(String text, int textColor) {
			int i;
			if (text==null) text="";
			listCodeChar = new CodeChar[text.length()];
			count = text.length();
			for (i=0; i<text.length(); i++) {
				listCodeChar[i] = new CodeChar(text.charAt(i), textColor);
			}
			this.str = text;
		}
		
		public CodeString(HighArray_char text, int textColor) {
			int i;
			if (text==null) {
				text=new HighArray_char(1);
				text.add("");
			}
			listCodeChar = new CodeChar[text.count];
			count = text.count;
			for (i=0; i<text.count; i++) {
				listCodeChar[i] = new CodeChar(text.charAt(i), textColor);
			}
			this.str = text.getItems();
		}
		
		public CodeString(char[] text, int textColor) {
			int i;
			//if (text==null) text="";
			listCodeChar = new CodeChar[text.length];
			count = text.length;
			for (i=0; i<text.length; i++) {
				listCodeChar[i] = new CodeChar(text[i], textColor);
			}
			this.str = new String(text);
		}
		
		public Object clone() {
			int i;
			char[] text = new char[this.count];
			int[] color = new int[this.count];
			byte[] type = new byte[this.count];
			int count = text.length;
			for (i=0; i<count; i++) {
				text[i] = listCodeChar[i].c;
				color[i] = listCodeChar[i].color;
				type[i] = listCodeChar[i].type;
			}
			return new CodeString(text, color, type);
		}
		
		
		/** len : text의 실제길이(text.length가 아니다)*/
		public CodeString(CodeChar[] text, int len) {
			try{
			this.listCodeChar = text;
			count = len;
			int i;
			char[] buf = new char[len];
			for (i=0; i<buf.length; i++) {
				buf[i] = text[i].c;
			}
			this.str = new String(buf);
			}catch(Exception e) {
			}
		}

		/**text로 listCodeChar와 str을 모두 바꾸고 count를 새로 설정한다.*/
		public void changeStr(String text) {
			int i;
			int len = text.length();
			for (i=0; i<len; i++) {
				listCodeChar[i].c = text.charAt(i);
			}
			this.count = text.length();
			this.str = text;
		}
		
		public boolean equals(String str) {
			try {
				String string = this.str;
			if (string.equals(str)) return true;
			}catch(Exception e) {
				e.printStackTrace();
			}
			return false;
		}
		
		public boolean equals(CodeString str) {
			if (this.toString().equals(str.toString())) return true;
			return false;
		}
		
		public int length() {
			
			return count;
		}
		public CodeChar charAt(int i) {
			
			return listCodeChar[i];
		}
		/** start포함, end미포함, 현재 스트링이 빈스트링일 경우 빈스트링 리턴*/
		public CodeString substring(int start, int end) {
			
			if (end-start<0) return null;
			if (this.count<=0) return new CodeString("",Common_Settings.textColor);
			
			if (end>listCodeChar.length) return new CodeString("",Common_Settings.textColor);
			int i;
			CodeChar[] r = new CodeChar[end-start];
			int count = 0;
			for (i=start; i<end; i++) {
				r[count++] = listCodeChar[i];
			}
			return new CodeString(r, r.length);
		}
		public CodeString substring(int i) {
			
			return substring(i, this.length());
		}
		
		public String toString() {
			return str;
		}

		public int indexOf(String string) {
			
			return toString().indexOf(string);
		}
		
		/**스트링의 앞과 뒷 부분에서 ' ', '\t', '\r', '\n' 을 제거한다.*/
		public CodeString trim() {
			int i;
			int startIndex = -1, endIndex = -1;
			for (i=0; i<this.str.length(); i++) {
				char c = str.charAt(i);
				if (!(c==' ' || c=='\t' || c=='\r' || c=='\n')) {
					startIndex = i;
					break;
				}
			}
			for (i=str.length()-1; i>=0; i--) {
				char c = str.charAt(i);
				if (!(c==' ' || c=='\t' || c=='\r' || c=='\n')) {
					endIndex = i;
					break;
				}
			}
			return this.substring(startIndex, endIndex+1);
		}
		
		public CodeString concate(CodeString str) {
			if (str==null) return this;
			listCodeChar = com.gsoft.common.util.Array.InsertNoSpaceError(str.listCodeChar, 0, 
					listCodeChar, length(), str.length(), this.count);
			count += str.length();
			return new CodeString(listCodeChar, listCodeChar.length);
		}
		
		public void insert(CodeChar[] src, int srcIndex, int destIndex, int len) {
			this.listCodeChar = 
					Array.InsertNoSpaceError(src, 0, this.listCodeChar, destIndex, len, this.count);
			this.count += len;
			int i;
			char[] buf = new char[this.count];
			for (i=0; i<buf.length; i++) {
				buf[i] = listCodeChar[i].c;
			}
			this.str = new String(buf);			
		}
		
		public void delete(int index, int len) {
			listCodeChar = Array.Delete(this.listCodeChar, index, len);
			this.count -= len;
			int i;
			char[] buf = new char[this.count];
			for (i=0; i<buf.length; i++) {
				buf[i] = listCodeChar[i].c;
			}
			this.str = new String(buf);
		}
		
		public void setColor(int color) {
			int i;
			for (i=0; i<count; i++) {
				listCodeChar[i].color = color;
			}
		}
		
		public void setType(byte type) {
			int i;
			for (i=0; i<count; i++) {
				listCodeChar[i].type = type;
			}
		}
		/**This string has an error. Refer to CodeChar.isErrorChar.*/
		public void setIsErrorString(boolean isErrorString) {
			int i;
			for (i=0; i<count; i++) {
				listCodeChar[i].isErrorChar = isErrorString;
			}
		}

		@Override
		public void destroy() {
			
			if (this.listCodeChar!=null) {
				int i;
				for (i=0; i<this.listCodeChar.length; i++) {
					listCodeChar[i] = null;
				}
			}
			this.str = null;
		}

		
	}

}