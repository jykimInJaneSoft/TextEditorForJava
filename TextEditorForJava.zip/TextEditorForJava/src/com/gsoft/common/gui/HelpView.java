package com.gsoft.common.gui;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;

import android.graphics.Canvas;

import com.gsoft.common.Common_Settings;
import com.gsoft.common.Events.MotionEvent;
import com.gsoft.common.IO_types.TextFormat;
import com.gsoft.common.Sizing.Rectangle;
import com.gsoft.common.Sizing.SizeF;
import com.gsoft.common.gui.edittext.Edit.ScrollMode;
import com.gsoft.common.gui.edittext.EditRichText;
import com.gsoft.common.gui.edittext.EditRichText_Types.TextLine;

import com.gsoft.common.gui.Control;


public class HelpView extends Control {
	EditRichText editRichText;
	
	public HelpView() {
		int x = (int) (Control.view.getWidth()*0.1f);
		int y = (int) (Control.view.getHeight()*0.1f);
		int w = (int) (Control.view.getWidth()*0.8f);
		int h = (int) (Control.view.getHeight()*0.8f);
		
		Rectangle boundsOfEditRichText = new Rectangle(x,y,w,h);
		float fontSize = Control.view.getHeight()*0.07f;
		editRichText = new EditRichText(this, "EditText", boundsOfEditRichText, fontSize, false, 
				"", ScrollMode.Both);		
		editRichText.isReadOnly = true;
	}
	
	@Override
	public boolean onTouch(MotionEvent event, SizeF scaleFactor) {
	   	boolean r;
	   	r = editRichText.onTouch(event, scaleFactor);
	   	if (!r) {
	   		// 외부영역을 터치하면 닫히도록 한다.
	   		this.setHides(true);
	   		return false;
	   	}
	   	return true;
	}
	
	public void setHelpFile(String pathHelpFile) {
		FileInputStream stream = null;
		BufferedInputStream bis = null;
		try {
			stream = new FileInputStream(pathHelpFile);
			bis = new BufferedInputStream(stream);
			editRichText.initialize();
			TextLine text = editRichText.read(bis, TextFormat.UTF_16);
			editRichText.setText(0, text);
			editRichText.setBackColor(Common_Settings.settings.getSelectedColor()[0]);
		}catch(Exception e) {
			
		}
		finally {
			if (bis!=null)
				try {
					bis.close();
				} catch (IOException e) {
					
					e.printStackTrace();
				}
			if (stream!=null)
				try {
					stream.close();
				} catch (IOException e) {
					
					e.printStackTrace();
				}
		}
	}
	
	public void draw(Canvas canvas)
    {
		if (hides) return;
		editRichText.draw(canvas);
    }
}