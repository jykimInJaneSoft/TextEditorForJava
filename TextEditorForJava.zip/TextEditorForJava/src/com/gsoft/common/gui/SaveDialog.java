package com.gsoft.common.gui;

import android.graphics.Color;
import android.view.View;

import com.gsoft.common.ColorEx;
import com.gsoft.common.Events.MotionEvent;
import com.gsoft.common.Sizing.Rectangle;
import com.gsoft.common.Sizing.SizeF;
import com.gsoft.common.interfaces.OnTouchListener;
import com.gsoft.common.R.R;
import com.gsoft.common.gui.Buttons.Button;

import com.gsoft.common.gui.MessageDialog;
import com.gsoft.common.gui.Control;
import com.gsoft.common.gui.Dialog;

public class SaveDialog extends MessageDialog implements OnTouchListener {

	public SaveDialog(View owner, Rectangle bounds) {
		super(owner, bounds);
		
		
		scaleOfOKButtonX = (1-scaleOfGapX*4) / 3;
		
		int x, y, width, height;
		int widthOfGap = (int)(bounds.width * scaleOfGapX);
		int alpha = 255;
		
		int colorOfButton = ColorEx.darkerOrLighter(Color.WHITE, -100);
		
		width = (int) (bounds.width * scaleOfOKButtonX);
		height = (int) (bounds.height * scaleOfOKButtonY);
		x = bounds.x + widthOfGap;
		y = controls[0].bounds.y;
		
		Rectangle boundsOfButtonOK = new Rectangle(x,y,width,height);
		x = boundsOfButtonOK.right() + widthOfGap;
		Rectangle boundsOfButtonOKWithoutSaving = new Rectangle(x,y,width,height);
		x = boundsOfButtonOKWithoutSaving.right() + widthOfGap;
		Rectangle boundsOfButtonCancel = new Rectangle(x,y,width,height);
		
		controls = new Button[3];
		controls[0] = new Button(owner, Dialog.NameButtonOk, Control.res.getString(R.string.OK), 
				colorOfButton, boundsOfButtonOK, false, alpha, true, 0.0f, null, Color.CYAN);
		controls[1] = new Button(owner, Dialog.NameButtonOKWithoutSaving, Control.res.getString(R.string.OKWithoutSaving), 
				colorOfButton, boundsOfButtonOKWithoutSaving, false, alpha, true, 0.0f, null, Color.CYAN);
		controls[2] = new Button(owner, Dialog.NameButtonCancel, Control.res.getString(R.string.cancel), 
				colorOfButton, boundsOfButtonCancel, false, alpha, true, 0.0f, null, Color.CYAN);
		// 이벤트를 이 클래스에서 직접 처리
		controls[0].setOnTouchListener(this);
		controls[1].setOnTouchListener(this);
		controls[2].setOnTouchListener(this);
	}
	
	public void changeBounds(Rectangle bounds) {
		super.changeBounds(bounds);
		
		scaleOfOKButtonX = (1-scaleOfGapX*4) / 3;
		
		int x, y, width, height;
		int widthOfGap = (int)(bounds.width * scaleOfGapX);
	
		
		width = (int) (bounds.width * scaleOfOKButtonX);
		height = (int) (bounds.height * scaleOfOKButtonY);
		x = bounds.x + widthOfGap;
		y = controls[0].bounds.y;
		
	
		Rectangle boundsOfButtonOK = new Rectangle(x,y,width,height);
		x = boundsOfButtonOK.right() + widthOfGap;
		Rectangle boundsOfButtonOKWithoutSaving = new Rectangle(x,y,width,height);
		x = boundsOfButtonOKWithoutSaving.right() + widthOfGap;
		Rectangle boundsOfButtonCancel = new Rectangle(x,y,width,height);
	
		((Button)controls[0]).changeBounds(boundsOfButtonOK);		
		((Button)controls[1]).changeBounds(boundsOfButtonOKWithoutSaving);
		((Button)controls[2]).changeBounds(boundsOfButtonCancel);
	}
	
	 @Override
	 public boolean onTouch(MotionEvent event, SizeF scaleFactor) {
		 return super.onTouch(event, scaleFactor);
	 }   
	
	@Override
	public void onTouchEvent(Object sender, MotionEvent e) {
		
		
		if (sender instanceof Button) {
			Button button = (Button)sender;
			if (button.iName==buttonRefresh.iName) {
				super.onTouchEvent(sender, e);
			}
			else if (button.iName==controls[0].iName) // OK
            {
				open(false);
				OK(true);
				if (listener!=null) listener.onTouchEvent(this, e);
            }
			else if (button.iName==controls[1].iName) { // OK without saving
				open(false);
				OK(false);
				if (listener!=null) listener.onTouchEvent(this, e);
			}
			else if (button.iName==controls[2].iName) { // Cancel
				cancel();
			}
		}		
	}

}
