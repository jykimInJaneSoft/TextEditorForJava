package com.gsoft.common.gui;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.RectF;
import android.util.Log;
import android.view.View;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.CommonGUI;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.Events.MotionEvent;
import com.gsoft.common.FileHelper;
import com.gsoft.common.FileHelper.LanguageAndTextFormat;
import com.gsoft.common.IO_types.TextFormat;
import com.gsoft.common.PowerManagement;
import com.gsoft.common.Sizing.Rectangle;
import com.gsoft.common.Sizing.SizeF;
import com.gsoft.common.Terminal;
import com.gsoft.common.Timer;
import com.gsoft.common.interfaces.TimerListener;
import com.gsoft.common.R.R;
import com.gsoft.common.compiler.EditText_Compiler;
import com.gsoft.common.gui.Buttons.Button;
import com.gsoft.common.gui.SettingsDialog.Settings;
import com.gsoft.common.gui.edittext.Edit;
import com.gsoft.common.gui.edittext.EditRichText;
import com.gsoft.common.gui.edittext.EditRichText_Types.TextLine;
import com.gsoft.common.gui.edittext.EditText;

import com.gsoft.common.gui.Control;
import com.gsoft.common.gui.Dialog;
import com.gsoft.common.gui.Menu;
import com.gsoft.common.gui.MessageDialog;
import com.gsoft.common.gui.SettingsDialog;
import com.gsoft.common.gui.ColorDialog;
import com.gsoft.common.gui.ScrollBars;

@SuppressWarnings("serial")
public class ViewEx extends View 
implements TimerListener, com.gsoft.common.interfaces.OnTouchListener {
	
	
	/** 윈도우 좌측 상단 절대 좌표*/
	public int x;
	/** 윈도우 좌측 상단 절대 좌표*/
	public int y;
	/**original width, Refer to CustomView.paint() and CustomView.realWidth*/
	public int width;
	/**original height, Refer to CustomView.paint() and CustomView.realHeight*/
	public int height;
	/**original width, Refer to CustomView.paint() and CustomView.realWidth*/
	public int getOriginalWidth() {
		return width;
	}
	/**original height, Refer to CustomView.paint() and CustomView.realHeight*/
	public int getOriginalHeight() {
		return height;
	}
	
	/**MaxWindow->PrevSize*/
	public int prevX;
	/**MaxWindow->PrevSize*/
	public int prevY;
	/**MaxWindow->PrevSize*/
	public int prevWidth;
	/**MaxWindow->PrevSize*/
	public int prevHeight;

	protected Timer exitTimer;
	protected long tickTimeOfExitTimer = 4 * 60 * 1000;
	protected long finishTimeOfExitTimer = 4 * 60 * 1000;
	
	protected MessageDialog closeDialog;
	
	protected MessageDialog messageDialog;
	
	
	protected static Settings settings = Common_Settings.settings;
	
	//Pipe.ThreadPipe mPipe;
	
	protected int backColor = Color.LTGRAY;
	
	/** 0:close, 1:minimize, 2:maximize*/
	protected boolean[] flagsOFControls = new boolean[3];
	
	/** 0:close, 1:minimize, 2:maximize*/
	protected Control[] controls = new Control[3];
	
	
	
	protected void createCloseDialog() {
		Rectangle boundsOfCloseDialog = new Rectangle(0, 0, (int)(width*0.8f), (int)(height*0.4f));
		boundsOfCloseDialog.x = (width-boundsOfCloseDialog.width) / 2;
		boundsOfCloseDialog.y = (height-boundsOfCloseDialog.height) / 2;
		
		closeDialog = new MessageDialog(this, boundsOfCloseDialog);
		//closeDialog.setOnTouchListener(this);
		closeDialog.setText("Exit this application?");
	}
	
	public void createMessageDialog(boolean changeBounds) {
		int w = (int)(width*0.9f);
		int h = (int)(height*0.7f);
		int x = width/2 - w/2;
		int y = height/2 - h/2;
		Rectangle boundsOfDialog = new Rectangle(x, y, w, h);
		if (!changeBounds) {
			String message = Control.res.getString(R.string.about_program);
			messageDialog = new MessageDialog(this, boundsOfDialog);
			messageDialog.setFontSize(boundsOfDialog.height*0.04f);
			//closeDialog.setOnTouchListener(this);
			messageDialog.setText(message);
		}
		else {
			messageDialog.changeBounds(boundsOfDialog);
		}
	}
	
	public void writeFile(int isEditRichTextOrEditText, EditRichText editRichText, EditText editText, Terminal terminal,
			String path) {
		FileOutputStream stream=null;
		BufferedOutputStream bos=null;
		try {
			//Control.loggingForMessageBox.setHides(false);
			//Control.loggingForMessageBox.setText(true, "Saving...", false);
			String filenameExceptExt = FileHelper.getFilenameExceptExt(path);				
			if (isEditRichTextOrEditText==0) {
				path = filenameExceptExt + ".kjy";
			}
			/*else {
				filename = filenameExceptExt + ".txt";
			}*/
			String ext = FileHelper.getExt(path);
			
			File file = new File(path);
			//file.setWritable(true, false);//-->NoSuchMethod Exception
			stream = new FileOutputStream(file);
			bos = new BufferedOutputStream(stream/*, IO.DefaultBufferSize*/);
			
			TextFormat format = TextFormat.UTF_8;
			if (ext.equals(".java")) {
				Menu menuTextSaveFormat = CommonGUI.fileDialog.menuTextFormat;
				format = TextFormat.UTF_8;
		    	if (menuTextSaveFormat.buttons[0].getIsSelected()) {
		    		format = TextFormat.UTF_8;
		    	}
		    	else if (menuTextSaveFormat.buttons[1].getIsSelected()) {
		    		//format = TextFormat.UTF_16;
		    		format = TextFormat.UTF_8;
		    	}
		    	else if (menuTextSaveFormat.buttons[2].getIsSelected()) {
		    		format = TextFormat.MS949_Korean;
		    	}
			}
			else if (ext.equals(".htm") || ext.equals(".html")) {
				format = TextFormat.UTF_8;
			}
			else {
				if (ext.equals(".kjy")) {
					format = TextFormat.UTF_16;
				}
				else if (ext.equals(".txt")) {
					if (Common_Settings.settings.textSaveFormat==0) {
						format = TextFormat.UTF_8;
					}
					else if (Common_Settings.settings.textSaveFormat==1) {
						//format = TextFormat.UTF_16;
						format = TextFormat.UTF_8;
					}
					else {
						format = TextFormat.MS949_Korean;
					}
				}
			}
			
			if (isEditRichTextOrEditText==0) {
				editRichText.write(bos, format);
			}
			else if (isEditRichTextOrEditText==1) {
				editText.write(bos, format);
			}
			else if (isEditRichTextOrEditText==2) {
				terminal.editText.write(bos, format);
			}
			bos.flush();
			bos.close();
			stream.close();
			//Control.setModified(true);
			CommonGUI.loggingForMessageBox.setText(true, "Save complete", false);
			CommonGUI.loggingForMessageBox.setHides(false);
			//postInvalidate();
			Control.view.postInvalidate();
		} catch (FileNotFoundException e1) {
			
			e1.printStackTrace();
			Log.e("Save Error", e1.toString());
			CommonGUI.loggingForMessageBox.setHides(false);
			CommonGUI.loggingForMessageBox.setText(true, Control.res.getString(R.string.save_error_read_only), false);					
		}
		catch (Exception e1) {
			
			e1.printStackTrace();
			Log.e("Save Error", e1.toString());
			CommonGUI.loggingForMessageBox.setHides(false);
			CommonGUI.loggingForMessageBox.setText(true, Control.res.getString(R.string.save_error), false);
		}
		finally {
			FileHelper.close(bos);
			FileHelper.close(stream);
		}
	}
	
	
	/** 스레드에서 이 함수를 호출해야 Control.view.postInvalidate();이 제대로 작동할 수 있다.*/
	public void readFile(int isEditRichTextOrEditText, EditRichText editRichText, EditText_Compiler editText, 
			String path) {
		
		String filenameExceptExt;
		String ext;	
		
		filenameExceptExt = FileHelper.getFilenameExceptExt(path);
		ext = FileHelper.getExt(path);
		path = filenameExceptExt + ext;
		
		if (isEditRichTextOrEditText==0) {
			if (!ext.equals(".kjy")) {
				CommonGUI.loggingForMessageBox.setText(true, "Can't open the file extension.", false);
				CommonGUI.loggingForMessageBox.setHides(false);
				Control.view.postInvalidate();
				return;
			}
		}
		
		
		TextFormat format = null;
		com.gsoft.common.compiler.Compiler_types.Language lang = null;
		
		LanguageAndTextFormat languageAndTextFormat = 
				FileHelper.getLanguageAndTextFormat(path);
		if (languageAndTextFormat!=null) {
			lang = languageAndTextFormat.lang;
			format = languageAndTextFormat.format;
		}
		
		else {	// 일반 .txt 는 format 이 null 이다.
			if (isEditRichTextOrEditText==0) {
				if (!ext.equals(".kjy")) {
					CommonGUI.loggingForMessageBox.setText(true, "Can't open the file extension.", false);
					CommonGUI.loggingForMessageBox.setHides(false);
					Control.view.postInvalidate();
					return;
				}
				else {
					format = TextFormat.UTF_16;
				}
			}
			else if (isEditRichTextOrEditText==1) {
				if (ext.equals(".kjy")) {
					CommonGUI.loggingForMessageBox.setText(true, "Can't open the file extension.", false);
					CommonGUI.loggingForMessageBox.setHides(false);
					Control.view.postInvalidate();
					return;
				}
				format = null;
			}	
		}
		
		if (ext.equals(".txt") || ext.equals(".java")) {
			Common_Settings.settingsDialog.enablesMenuTextFormat = true;
		}
		else {
			Common_Settings.settingsDialog.enablesMenuTextFormat = false;
		}
		
		
		boolean r = false;
		if (format!=null) {
			r = load(isEditRichTextOrEditText, editRichText, editText,
					path, format, lang);
			//Control.view.postInvalidate();
			//if (!r) Common_Settings.settingsDialog.setTextSaveFormat(-1);
			if (r) {
				CommonGUI.loggingForMessageBox.setText(true, "Read complete", false);
				CommonGUI.loggingForMessageBox.setHides(false);
				Control.view.postInvalidate();
				return;
			}
		}
		else {
			r = load(isEditRichTextOrEditText, editRichText, editText,
					path, TextFormat.UTF_8, lang);
			//Control.view.postInvalidate();
			if (r) {
				//Common_Settings.settingsDialog.setTextSaveFormat(0);
				CommonGUI.loggingForMessageBox.setText(true, "Read complete", false);
				CommonGUI.loggingForMessageBox.setHides(false);
				Control.view.postInvalidate();
				return;
			}
			if (!r) {
				r = load(isEditRichTextOrEditText, editRichText, editText,
						path, TextFormat.MS949_Korean, lang);
				//Control.view.postInvalidate();
			}
			if (r) {
				//Common_Settings.settingsDialog.setTextSaveFormat(2);
				CommonGUI.loggingForMessageBox.setText(true, "Read complete", false);
				CommonGUI.loggingForMessageBox.setHides(false);
				Control.view.postInvalidate();
				return;
			}
			if (!r) {
				r = load(isEditRichTextOrEditText, editRichText, editText,
						path, TextFormat.UTF_16, lang);
				//Control.view.postInvalidate();
			}
			if (r) {
				//Common_Settings.settingsDialog.setTextSaveFormat(1);
				CommonGUI.loggingForMessageBox.setText(true, "Read complete", false);
				CommonGUI.loggingForMessageBox.setHides(false);
				Control.view.postInvalidate();
				return;
			}
			//if (!r) Common_Settings.settingsDialog.setTextSaveFormat(-1);
		}
	}
	
	public boolean load(int isEditRichTextOrEditText, EditRichText editRichText, EditText_Compiler editText,
			String path, TextFormat format, com.gsoft.common.compiler.Compiler_types.Language lang) {
		
		
		FileInputStream stream=null;
		BufferedInputStream bis=null;
		
		try {
			if (isEditRichTextOrEditText==0) {
				stream = new FileInputStream(path);
				bis = new BufferedInputStream(stream);
				TextLine text = editRichText.read(bis, format);
				bis.close();
				stream.close();
				//editRichText.initCursorAndScrollPos();
				//editRichText.initialize();
				editRichText.setText(0, text);
				editRichText.isModified = false;
				
				if (text==null || text.count==0) {
					File file = new File(path);
					if (file.length()!=0) return false;
				}
			}
			else if (isEditRichTextOrEditText==1) {				
				//editText.initialize();
				if (lang!=null) {		// .java, .htm, .class 등			
					editText.openCompilerDocument(path);
				}
				else { // .txt 등					
					//editText.setBackColor(Common_Settings.settings.selectedColor[0]);
					//String text = EditText.Read(bis, format);
					//editText.setText(0, new CodeString(text, editText.textColor));
					editText.openCompilerDocument(path);
				}
			}
			
			
			CommonGUI.loggingForMessageBox.setHides(true);
			Control.view.postInvalidate();
			return true;
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
			Log.e("Load Error", e.toString());
			
			CommonGUI.loggingForMessageBox.setText(true, e.toString(), false);
			CommonGUI.loggingForMessageBox.setHides(false);
			return false;
		}
		catch (Exception e) {
			
			e.printStackTrace();
			Log.e("Load Error", e.toString());
			
			CommonGUI.loggingForMessageBox.setText(true, e.toString(), false);
			CommonGUI.loggingForMessageBox.setHides(false);
			return false;
		}
		catch (OutOfMemoryError e) {
			e.printStackTrace();
			Log.e("Load Error", e.toString());
			
			CommonGUI.loggingForMessageBox.setText(true, Control.res.getString(R.string.outof_memory_error), false);
			CommonGUI.loggingForMessageBox.setHides(false);
			return false;
		}
		finally {
			FileHelper.close(bis);
			FileHelper.close(stream);
			Control.view.postInvalidate();
		}
	}
	
	public void onBackPressed() {
		
		
		int i=Control.controlStack.count-1;
		//for (i=Control.controlStack.count-1; i>=0; i--)
		if (i>=0) {
			Control control = Control.controlStack.getItem(i); 
			if (control instanceof Dialog) {
				Dialog dialog = (Dialog)control;
				dialog.cancel();
			}
			else if (control instanceof Menu) {
				Menu menu = (Menu)control;
				menu.open(null, false);
			}
			else { // progressBar, log 등
				control.setHides(true);
			}
		}
		else  {
			closeDialog.open(this, true);
		}
		
	}

	public ViewEx(Context context) {
		super(context);
		
		
		//Control.res = context.getResources();
		
		//exitTimer = new Timer(10000000, this, tickTimeOfExitTimer, finishTimeOfExitTimer);
		//exitTimer.setSyncTime(tickTimeOfExitTimer, tickTimeOfExitTimer);
		
		
		createBackupFile();
		
		PowerManagement.getPartialWakeLock(getContext());
		
		
		
	}
	
	/** view에서 size가 정해지면 호출된다.(view.onDraw)*/
	public void sized() {
		
		createColorDialog(false);
		SettingsDialog.createSettingsDialog(Control.view);
		
		
		if (settings==null) {
			settings = Common_Settings.settings;
		}
		
		int selectedColor;
		if (settings!=null) {
			selectedColor = settings.getSelectedColor()[0];
			Common_Settings.settingsDialog.setSelectedColorOfEditText(selectedColor);
			Common_Settings.settingsDialog.setSelectedColorOfKeyboard(settings.getSelectedColor()[1]);
			Common_Settings.pathAndroid = Common_Settings.pathAndroid.replace('/', File.separatorChar);
			Common_Settings.settingsDialog.editTextDirectory.setText(0, new CodeString(Common_Settings.pathAndroid+File.separator,Color.BLACK));
		}
	}
	
	/** 공유 ColorDialog*/
	public void createColorDialog(boolean changeBounds) {
		//if (CommonGUI.colorDialog!=null) return;
		int width = this.getWidth();
		int height = this.getHeight();
		int w = (int) (width*0.7f);
		int h = (int) (height*0.8f);
		int x = width/2 - w/2;
		int y = height/2 - h/2;
		Rectangle bounds = new Rectangle(x,y,w,h);
		if (!changeBounds) {
			if (CommonGUI.colorDialog==null) {
				CommonGUI.colorDialog = new ColorDialog((View)this, bounds);
			}
		}
		else {
			CommonGUI.colorDialog.changeBounds(bounds);
		}
		//Control.colorDialog.setOnTouchListener(this);
	}
	
	
	
	public void pause() {
		
	}
	
	
	
	/** View의 initControls()의 슈퍼 메서드이다.*/
	protected void initControls() throws Exception {
		if (width==0 || height==0) throw new Exception("뷰의 너비와 높이가 정해지지 않았음");
		ScrollBars.setScrollBarScale(this);
		createCloseDialog();
	}
	
	/** View의 initControls() 이후에 호출되는 슈퍼 메서드이다.*/
	public void afterInitControls() {
		int gap = 5;
		int alpha = 255;
		int w = (int) (this.width * 0.03f);
		int h = w;		
		int y = gap;
		int x = this.width;
		
		Rectangle boundsClose = null;
		if (this.flagsOFControls[0]) {
			x = (x - w - gap);
			boundsClose = new Rectangle(x, y, w, h);
			Button closeButton = new Button(this, "Close", "x", 
					Color.RED, boundsClose, false, alpha, true, 0.0f, null, Color.LTGRAY);
			closeButton.setBackColor(Color.RED);
			closeButton.setOnTouchListener(this);
			closeButton.setIsOpen(true);
			this.controls[0] = closeButton;
		}
		
		
		Rectangle boundsMinimize = null;
		if (this.flagsOFControls[1]) {
			x = (x - w - gap);
			boundsMinimize = new Rectangle(x, y, w, h);
			Button minimizeButton = new Button(this, "Minimize", "_", 
					Color.RED, boundsMinimize, false, alpha, true, 0.0f, null, Color.LTGRAY);
			minimizeButton.setBackColor(Color.RED);
			minimizeButton.setOnTouchListener(this);
			minimizeButton.setIsOpen(true);
			this.controls[1] = minimizeButton;
		}
		
		Rectangle boundsMaximize = null;
		if (this.flagsOFControls[2]) {
			x = (x - w - gap);
			boundsMaximize = new Rectangle(x, y, w, h);
			Button maximizeButton = new Button(this, "Maximize", "O", 
					Color.RED, boundsMaximize, false, alpha, true, 0.0f, null, Color.LTGRAY);
			maximizeButton.setBackColor(Color.RED);
			maximizeButton.toggleable = true;
			maximizeButton.setOnTouchListener(this);
			maximizeButton.setIsOpen(true);
			this.controls[2] = maximizeButton;
		}
		
		
		/*
		if (Common_Settings.settings.usesChildCompilerProcess) {
			if (Control.isMasterOrSlave==false) {
				// slave 에서 수신을 위한 소켓의 포트번호
				int portNum = Pipe.countOfCreatedProcesses + Pipe.StartPortNum;
										
				CommonGUI.loggingForNetwork.setText(true, "Listening to port "+portNum, false);
				CommonGUI.loggingForNetwork.setHides(false);
				Control.view.invalidate();
				
				mPipe = new Pipe.ThreadPipe();
				mPipe.start();
			}
		}*/
	}
	
	protected void deleteBackupFile() {
		File contextDir = getContext().getFilesDir();
		String absFilename = contextDir.getAbsolutePath() + File.separator + "backup_text.kjy";
		File backupFile = new File(absFilename);
		backupFile.delete();
	}
	
	/** backup_text.kjy이 존재하지 않으면 생성한다.*/
	protected void createBackupFile() {
		File contextDir = getContext().getFilesDir();
		String absFilename = contextDir.getAbsolutePath() + File.separator + "backup_text.kjy";
		File backupFile = new File(absFilename);
		if (!backupFile.exists()) {
			FileOutputStream stream=null;
			try {
				stream = new FileOutputStream(backupFile);
			} catch (FileNotFoundException e) {
				
			}finally {
				FileHelper.close(stream);
			}
		}	
		
	}
	
	
	
	public boolean lastOperation () {
		/*if (Common_Settings.settings.usesChildCompilerProcess) {
			
			if (Control.isMasterOrSlave) {
				Pipe.destroyMainProcess();
				
			}			
			
			if (Control.isMasterOrSlave==false) {
				Pipe.destroySubProcess();
				if (mPipe!=null) {
					mPipe.destroy();
				}
			}
		}*/
		return true;
	}

	@Override
	public void onTick(Object sender) {
		
		
	}

	@Override
	public void onFinish(Object sender) {
		
		
	}
	
	public void onDraw(Canvas canvas) {
		// 자바에서 배경지우기 추가
		//canvas.g.setColor(java.awt.Color.LIGHT_GRAY);
		//canvas.g.fillRect(0, 0, width, height);
		RectF rectF = new RectF();
		rectF.left = 0;
		rectF.top = 0;
		rectF.right = width;
		rectF.bottom = height;
		Paint paint = new Paint();
		paint.setStyle(Style.FILL);
		paint.setColor(backColor);
		canvas.drawRect(rectF, paint);
	}
	
	public void afterOnDraw(Canvas canvas) {
		int i;
		for (i=0; i<this.controls.length; i++) {
			Control control = controls[i];
			if (control!=null) {
				control.draw(canvas);
			}
		}
	}
	
	protected void resizeView() {
		int gap = 5;
		Button closeButton = null;
		Button minimizeButton;
		Button maximizeButton;
		
		int x = this.width;
		int w;
		
		if (controls[0]!=null) {
			closeButton = (Button) controls[0];
			Rectangle newBounds = closeButton.bounds;
			w = newBounds.width;
			x = x - w - gap;
			newBounds.x = x;
			closeButton.changeBounds(newBounds);
		}
		if (controls[1]!=null) {
			minimizeButton = (Button) controls[1];
			Rectangle newBounds = minimizeButton.bounds;
			w = newBounds.width;
			x = x - w - gap;
			newBounds.x = x;
			//newBounds.x = closeButton.bounds.x - newBounds.width - gap;
			minimizeButton.changeBounds(newBounds);
		}
		if (controls[2]!=null) {
			maximizeButton = (Button) controls[2];
			Rectangle newBounds = maximizeButton.bounds;
			w = newBounds.width;
			x = x - w - gap;
			newBounds.x = x;
			//newBounds.x = closeButton.bounds.x - newBounds.width - gap;
			maximizeButton.changeBounds(newBounds);
		}
		
		if (Edit.menuFontSize!=null) Edit.createMenuFontSize(true);
		if (Edit.fontSizeDialog!=null) Edit.createFontSizeDialog(true);
		
		if (Edit.menuFunction!=null) Edit.createMenuFunction(true);
		if (Edit.findReplaceDialog!=null) Edit.createFindReplaceDialog(true);
		
		if (CommonGUI.colorDialog!=null) this.createColorDialog(true); 
		//this.createTextView(true);
		if (this.messageDialog!=null) createMessageDialog(true);
	
	}
	
	/** close, minimize, maximaize버튼들을 클릭했는지 확인하여 이벤트를 전달한다.*/
	public boolean onTouch(MotionEvent event, SizeF scaleFactor) {
    	boolean r;
    	int i;
    	
    	if (event.actionCode==MotionEvent.ActionDown || event.actionCode==MotionEvent.ActionDoubleClicked) {
    		
    		//CommonGUI.loggingForMessageBox.setHides(true);
    		if (CommonGUI.loggingForMessageBox.getIsOpen()) {
    			CommonGUI.loggingForMessageBox.setHides(true);
    			CommonGUI.loggingForMessageBox.setHides_sub_NotFrame(true);
    			// This makes user click one more to move carret.
    			return true;
    		}
    		
	    	for (i=0; i<controls.length; i++) {
	    		if (controls[i]!=null) {
		    		r = controls[i].onTouch(event, scaleFactor);
		    		if (r) return true;
	    		}
	    	}
    	}
    	return false;
	}
	

	@Override
	public void onTouchEvent(Object sender, MotionEvent e) {
		
		/*if (sender instanceof Button) {
			Button button = (Button) sender;
			if (controls[0]!=null && button.iName==this.controls[0].iName) {
				Control.exit(false);
			}
			else if (controls[1]!=null && button.iName==this.controls[1].iName) {
				this.setState(Frame.ICONIFIED);
			}
		}*/
	}

}
