package com.gsoft.common.gui;

import android.graphics.Color;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.Sizing.Rectangle;
import com.gsoft.common.Sizing.Size;
import com.gsoft.common.gui.Buttons.Button;
import com.gsoft.common.gui.edittext.Edit.ScrollMode;
import com.gsoft.common.gui.edittext.EditText;
import com.gsoft.common.util.ArrayList;

public class Pool {
	public static class PoolOfEditText {
		public ArrayList list;
		Size editTextSize;
		public PoolOfEditText(int initMaxLength, Size editTextSize) {
			list = new ArrayList(initMaxLength);
			this.editTextSize = editTextSize;
			setCapacity(initMaxLength);
		}
		public void reset() {
			list.reset();
		}
		/**저장공간을 늘리거나 줄인다. 또한 Array.Resize는 배열공간만 늘리고 아이템은 null이므로 아이템
		 * 까지 만들어서 넣어준다
		 * @param c
		 */
		public void setCapacity(int c) {
			list.setCapacity(c);
			int i;
			for (i=list.count; i<list.capacity; i++) {
				Rectangle boundsOfEditText = new Rectangle(0, 0, this.editTextSize.width, this.editTextSize.height); 
				EditText editText = new EditText(true, false, this, "EditText", boundsOfEditText, 
						this.editTextSize.height*0.55f, false, new CodeString("", Color.BLACK), 
						ScrollMode.Both, Color.WHITE);
				list.add(editText);
			}
		}
		public void add(Object e) {
			list.add(e);
		}
		
		public Object[] getItems() {
			return list.getItems();
		}
		
		public Object getItem(int index) {
			return list.getItem(index);			
		}
	}
	
	public static class PoolOfButton {
		public ArrayList list;
		public PoolOfButton(int initMaxLength, Size buttonSize) {
			list = new ArrayList(initMaxLength);
			setCapacity(initMaxLength, buttonSize);
		}
		public void reset() {
			list.reset();
		}
		/**저장공간을 늘리거나 줄인다. 또한 Array.Resize는 배열공간만 늘리고 아이템은 null이므로 아이템
		 * 까지 만들어서 넣어준다
		 * @param c
		 */
		public void setCapacity(int c, Size buttonSize) {
			list.setCapacity(c);
			int i;
			for (i=list.count; i<list.capacity; i++) {
				Button button  = new Button(null, "", "", Color.BLUE, 
						new Rectangle(0,0,buttonSize.width,buttonSize.height), 
						false, 255, true, 0, null, Color.CYAN);
				list.add(button);
			}
		}
		public void add(Object e) {
			list.add(e);
		}
		
		public Object[] getItems() {
			return list.getItems();
		}
		
		public Object getItem(int index) {
			return list.getItem(index);			
		}
		public void destroy() {
			
			this.list.destroy();
			this.list = null;
		}
	}
}