package com.gsoft.common.gui;

import java.io.File;
import java.io.IOException;

import android.content.Intent;
import android.net.Uri;
import android.view.View;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.CommonGUI;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.FileHelper;
import com.gsoft.common.IO;
import com.gsoft.common.MultiMedia.MediaPlayerDel;
import com.gsoft.common.MultiMedia.MediaRecorderDel;
import com.gsoft.common.Net;
import com.gsoft.common.Net.WifiThread;
import com.gsoft.common.PowerManagement;
import com.gsoft.common.Sizing.Rectangle;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.util.Decompressor;
import com.gsoft.common.gui.Buttons.Button;
import com.gsoft.common.gui.FileDialog.Category;
import com.gsoft.common.gui.FileDialog.SortByTime;
import com.gsoft.common.gui.FileDialog.State;
import com.gsoft.common.gui.FileDialog.ThreadDelete;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListString;
import com.gsoft.common.util.Sort;

import com.gsoft.common.gui.FileDialog;
import com.gsoft.common.gui.ConnectDialog;
import com.gsoft.common.gui.MenuWithClosable;
import com.gsoft.common.gui.MenuWithScrollBar;
import com.gsoft.common.gui.MessageDialog;
import com.gsoft.common.gui.Control;
import com.gsoft.common.gui.HelpView;
import com.gsoft.common.gui.IntegrationKeyboard;

public class FileDialogEventHandler {
	public FileDialog owner;
	View view;
	
	
	FileDialogEventHandler(FileDialog owner) {
		this.owner = owner;
		this.view = Control.view;
	}
	
	/*public static void merge_sort(SortByTime[] list, int start, int end, boolean isAcending){ // Array를 두개의 덩어리로 나눔    
		int median = (start + end)/2;     
		if (start < end){         
			merge_sort(list, start, median, isAcending);         
			merge_sort(list, median+1, end, isAcending);          
			merge(list, start, median, end, isAcending);     
		} 
	}  */
	/*private static void merge(SortByTime[] list, int start, int median, int end, boolean isAcending){     
		int i,j,k,m,n;     
		SortByTime[] tempArr = new SortByTime[list.length]; // 임시로 데이터를 저장할 배열    
		i = start;     
		j = median+1;     
		k = start;      
		while (i <= median && j <= end){
			if (isAcending) {
				tempArr[k++] = (list[i].modifiedTime > list [j].modifiedTime) ? list [j++] : list [i++]; 
			}
			else {
				tempArr[k++] = (list[i].modifiedTime < list [j].modifiedTime) ? list [j++] : list [i++];
			}
		}           // 아직 배열에 속하지 못한 부분들을 넣기 위한 부분    
		m = (i > median) ? j : i; // 아직 원소가 남아있는 덩어리가 어디인지 파악    
		n = (i > median) ? end : median; // 마찬가지로, for문의 끝 Index를 정하기 위함임     
		for (; m<=n; m++){ // 앞에서 구한 m, n으로 배열에 속하지 못한 원소들을 채워넣음       
			tempArr[k++] = list[m];     
		}      
		for (m=start; m<=end; m++){         
			list[m] = tempArr[m]; // 임시 배열에서 원래 배열로 데이터 옮기기    
		} 
	}*/
	
	void processEventOfConnectDialog(Object sender) {
		ConnectDialog dialog = (ConnectDialog)sender;
		//serverIpAddress = dialog.ipAddress;
		//doWifi();		// serverIp가 입력되면 wifi를 시작한다.
		if (dialog.ipAddress!=null) {
			owner.wifiThread = new WifiThread(view, dialog.ipAddress, owner.fileListOfMultiSelect);
			
			long totalFileSize=0;
			int totalFileCount=0;
			
			//setWifiState(true, " sendLargeFile started.");
			int i;
			for (i=0; i<owner.fileListOfMultiSelect.count; i++) {
				String absFilename = owner.fileListOfMultiSelect.getItem(i);
				totalFileSize += FileHelper.getFileSize(absFilename);
				totalFileCount += FileHelper.getFileCount(absFilename);
			}
			
			Net.setTotalFileSize(totalFileSize);
			Net.setFileCountToSend(totalFileCount);
			owner.wifiThread.start();
			
			PowerManagement.getPartialWakeLock(view.getContext());
		}
		owner.hides = false;
	}
	
	
	void handleMenuFileType(Button button) {
		int i;
		if (owner.menuFileType!=null) {
        	for (i=0; i<FileDialog.namesOfMenuFileType.length; i++) {
        		//if (button.name.equals(namesOfMenuDir[i])) {
        		if (button.iName==owner.menuFileType.buttons[i].iName) {
        			String curDir = owner.getCurDir(true);
        			switch(i) {
        			case 0: owner.createAndSetFileListButtons(curDir, Category.Image);break;
        			case 1: owner.createAndSetFileListButtons(curDir, Category.Text);break;
        			case 2: owner.createAndSetFileListButtons(curDir, Category.Custom);break;
        			case 3: owner.createAndSetFileListButtons(curDir, Category.Music);break;
        			case 4: owner.createAndSetFileListButtons(curDir, Category.Video);break;
        			case 5: owner.createAndSetFileListButtons(curDir, Category.Compression);break;
        			case 6: owner.createAndSetFileListButtons(curDir, Category.All);break;
        			}
        			owner.menuFileType.open(false);
        			break;
        		}
        	}
    	}//if (menuFileType!=null) {
	}
	
	
	void handleMenuCRLF(Button button) {
		int i;
    	for (i=0; i<FileDialog.namesOfMenuCRLF.length; i++) {
    		//if (button.name.equals(namesOfMenuDir[i])) {
    		if (button.iName==owner.menuCRLF.buttons[i].iName) {
    			owner.menuCRLF.open(false);
    			owner.originalOrCRLFOrLF = i;
    		}
    	}
	}
	
	
	void handleMenuDir(Button button) {
		int i;
    	for (i=0; i<FileDialog.namesOfMenuDir.length; i++) {
    		//if (button.name.equals(namesOfMenuDir[i])) {
    		if (button.iName==owner.menuDir.buttons[i].iName) {
    			owner.resetMultiSelect();
    			owner.menuDir.open(false);
    			String absFilename=null;
    			switch(i) {
    			case 0: { // go to app dir
        			//File contextDir = context.getFilesDir();
        			//absFilename = contextDir.getAbsolutePath();
    				absFilename = Common_Settings.pathJaneSoft;
        			break;
    			}
    			case 1: {	// "/" directory
    				absFilename = FileHelper.getPartitionName()+FileDialog.Separator;
        			break;
    			} 
    			case 2: { // go to project dir
    				absFilename = Common_Settings.pathProjectSrc;
    				break;
    			}
    			case 3: { // go to sdk dir
    				absFilename = Common_Settings.pathAndroid;
    				break;
    			}
    			case 4: {
    				Decompressor.decompressAndroidAndProjectSrc();            				            				        				
    				
    				
    				owner.createAndSetFileListButtons(Common_Settings.pathJaneSoft, owner.category);
    				
    				// Common_Settings.settingsDialog의 SDK 디렉토리의 값을
    				// 압축이 풀린 디렉토리 /mnt/sdcard/janeSoft/gsoft 로 바꾸고
    				// backup_Settings에 그 값을 저장한다.
    				absFilename = Common_Settings.pathAndroid;
    				Common_Settings.settingsDialog.setEditTextDirectory(absFilename);
    				Common_Settings.settingsDialog.setSettings();
    				Common_Settings.settingsDialog.backupSettings();
    				
    				return;
    			}
    			}//switch
    			try{
    				if (absFilename!=null) {
	    				File file = new File(absFilename);
	    				if (!file.exists()) {
	    					//CommonGUI.loggingForMessageBox.setText(true, 
	    					//	"Directory not found. Click \"Unzip the SDK files(gsoft.zip, project.zip)\". If you do, project directory is made.", false);
	    					CommonGUI.loggingForMessageBox.setText(true, 
	    	    					"Directory not found. Project is not set.", false);
	    					CommonGUI.loggingForMessageBox.setHides(false);
	    					Control.view.invalidate();
	    				}
	    				else if (file.isDirectory()) {
	    					owner.createAndSetFileListButtons(absFilename, owner.category);
	    				}
    				}
    				else {
    					CommonGUI.loggingForMessageBox.setText(true, 
    	    					"Directory not found. Project is not set.", false);
    					CommonGUI.loggingForMessageBox.setHides(false);
    					Control.view.invalidate();
    				}
    			}catch(Exception e) {
    				e.printStackTrace();
					CompilerHelper.printStackTrace(FileDialog.textViewLogBird, e);
    			}
    			
    		}//if (button.iName==menuDir.buttons[i].iName) {
    	}//for (i=0; i<namesOfMenuDir.length; i++) {
	}
	
	void handleButtonMultiSelect(Button buttonMultiSelect) {
		owner.menuFunc.buttons[8].Toggle();
		owner.fileDialogEventHandler.processEventOfMenuFunc(owner.menuFunc.buttons[8]);		
	}
	
	void handleHelpMe(Button button) {
		int i;
		String filename = null;
    	for (i=0; i<FileDialog.namesOfMenuHelp.length; i++) {
    		if (button.iName==owner.menuHelp.buttons[i].iName) {
    			switch(i) {
    			case 0: {
    				filename = "ListenToMusic.kjy"; 
    				HelpView helpView = new HelpView(); 
    				helpView.setHelpFile(Common_Settings.pathHelpFiles + File.separator + filename);
    				helpView.setHides(false);
    				break;
    			}
    			case 1: {
    				filename = "HowToTransferFiles.kjy"; 
    				HelpView helpView = new HelpView(); 
    				helpView.setHelpFile(Common_Settings.pathHelpFiles + File.separator + filename);
    				helpView.setHides(false);
    				break;
    			}
    			case 2: {
    				filename = "HowToViewJavaFile.kjy"; 
    				HelpView helpView = new HelpView(); 
    				helpView.setHelpFile(Common_Settings.pathHelpFiles + File.separator + filename);
    				helpView.setHides(false);
    				break;
    			}
    			case 3: {
    				filename = "HowToViewClassFile.kjy"; 
    				HelpView helpView = new HelpView(); 
    				helpView.setHelpFile(Common_Settings.pathHelpFiles + File.separator + filename);
    				helpView.setHides(false);
    				break;
    			}
    			}
    		}
    	}
	}
	
	
	void processEventOfMenuSort(Object sender) {
		Button button = (Button)sender;
		
		MenuWithClosable menuSort = owner.menuSort;
		MenuWithScrollBar menuFileList = owner.menuFileList;
		String curDir = owner.getCurDir(true);
		
		if (owner.fileList==null) {
			Button[] buttonsSorted = owner.getFileListButtons(owner.fileList);
        	if (menuFileList!=null) {
    			menuFileList.setButtons(buttonsSorted);
    		}
			return;
		}
		
		// "Sort by name, ascending", "Sort by name, descending",
		// "Sort by time, ascending", "Sort by time, descending"
		if (button.iName==menuSort.buttons[0].iName) {	// Sort by name, ascending            	
        	menuSort.open(false);
        	//Sort.merge_sort(owner.fileList, 0, owner.fileList.length-1, true);
        	ArrayList arrSortItem = new ArrayList(owner.fileList.length);
        	int i;
        	int len = owner.fileList.length;
        	for (i=0; i<len; i++) {      		
        		arrSortItem.add(Sort.toSortItem(owner.fileList[i], owner.fileList[i]));
        	}
        	Sort.sort(arrSortItem);
        	for (i=0; i<arrSortItem.count; i++) {
        		Sort.SortItem sortItem = (Sort.SortItem)arrSortItem.getItem(i);
        		owner.fileList[i] = (String) sortItem.obj;
        	}
        	Button[] buttonsSorted = owner.getFileListButtons(owner.fileList);
        	if (menuFileList!=null) {
    			menuFileList.setButtons(buttonsSorted);
    		}
        }
        else if (button.iName==menuSort.buttons[1].iName) {	// Sort by name, descending            	
        	menuSort.open(false);
        	//Sort.merge_sort(owner.fileList, 0, owner.fileList.length-1, false);
        	ArrayList arrSortItem = new ArrayList(owner.fileList.length);
        	int i;
        	int len = owner.fileList.length;
        	for (i=0; i<len; i++) {      		
        		arrSortItem.add(Sort.toSortItem(owner.fileList[i], owner.fileList[i]));
        	}
        	Sort.sort(arrSortItem);
        	for (i=arrSortItem.count-1; i>=0; i--) {
        		Sort.SortItem sortItem = (Sort.SortItem)arrSortItem.getItem(i);
        		owner.fileList[arrSortItem.count-1-i] = (String) sortItem.obj;
        	}
        	Button[] buttonsSorted = owner.getFileListButtons(owner.fileList);
        	if (menuFileList!=null) {
    			menuFileList.setButtons(buttonsSorted);
    		}
        }
        else if (button.iName==menuSort.buttons[2].iName) {	// Sort by time, ascending            	
        	menuSort.open(false);
        	//SortByTime[] arrSortByTime = new SortByTime[owner.fileList.length];
        	ArrayList arrSortItem = new ArrayList(owner.fileList.length);
        	int i;
        	int len = owner.fileList.length;
        	for (i=0; i<len; i++) {
        		File file = new File(curDir+owner.fileList[i]);
        		SortByTime sortByTime = new SortByTime(file.lastModified(), owner.fileList[i]);
        		arrSortItem.add(new Sort.SortItemLong(file.lastModified(), sortByTime));
        	}
        	Sort.sort_Long(arrSortItem);
        	//merge_sort(arrSortByTime, 0, arrSortByTime.length-1, true);
        	for (i=0; i<arrSortItem.count; i++) {
        		Sort.SortItemLong sortItem = (Sort.SortItemLong)arrSortItem.getItem(i);
        		SortByTime sortByTime = (SortByTime) sortItem.obj;
        		owner.fileList[i] = sortByTime.filename;
        	}
        	Button[] buttonsSorted = owner.getFileListButtons(owner.fileList);
        	if (menuFileList!=null) {
    			menuFileList.setButtons(buttonsSorted);
    		}
        }
        else if (button.iName==menuSort.buttons[3].iName) {	// Sort by time, descending            	
        	menuSort.open(false);
        	/*SortByTime[] arrSortByTime = new SortByTime[owner.fileList.length];
        	int i;
        	for (i=0; i<arrSortByTime.length; i++) {
        		File file = new File(curDir+owner.fileList[i]);
        		arrSortByTime[i] = new SortByTime(file.lastModified(), owner.fileList[i]); 
        	}
        	merge_sort(arrSortByTime, 0, arrSortByTime.length-1, false);
        	for (i=0; i<arrSortByTime.length; i++) {
        		owner.fileList[i] = arrSortByTime[i].filename;
        	}*/
        	ArrayList arrSortItem = new ArrayList(owner.fileList.length);
        	int i;
        	int len = owner.fileList.length;
        	for (i=0; i<len; i++) {
        		File file = new File(curDir+owner.fileList[i]);
        		SortByTime sortByTime = new SortByTime(file.lastModified(), owner.fileList[i]);
        		arrSortItem.add(new Sort.SortItemLong(file.lastModified(), sortByTime));
        	}
        	Sort.sort_Long(arrSortItem);
        	//merge_sort(arrSortByTime, 0, arrSortByTime.length-1, true);
        	for (i=arrSortItem.count-1; i>=0; i--) {
        		Sort.SortItemLong sortItem = (Sort.SortItemLong)arrSortItem.getItem(i);
        		SortByTime sortByTime = (SortByTime) sortItem.obj;
        		owner.fileList[arrSortItem.count-1-i] = sortByTime.filename;
        	}
        	Button[] buttonsSorted = owner.getFileListButtons(owner.fileList);
        	if (menuFileList!=null) {
    			menuFileList.setButtons(buttonsSorted);
    		}
        }
	}
	
	void processEventOfMenuMultimedia(Object sender) {
		Button button = (Button)sender;
		
		MenuWithClosable menuMultimedia = owner.menuMultimedia;
		
		//getfileListOfMultiSelectAndmAbsFileName();
		
		ArrayListString fileListOfMultiSelect = owner.fileListOfMultiSelect;
		ConnectDialog connectDialog = owner.connectDialog;
		//State state = owner.state;
		MediaRecorderDel recorder = owner.recorder;
		MediaPlayerDel mediaPlayer = owner.mediaPlayer;
		
		// "Send a file", "Start receiver", 
		// "Listen to music", "Video", "Record sound", "Play record", "Sound Control Menu", "Help me", "Run a class file"
		if (button.iName==menuMultimedia.buttons[0].iName) {	// Send a file
        	owner.state = State.SendFile;
        	menuMultimedia.open(false);
        	
        	if (fileListOfMultiSelect.count>0) {
            	connectDialog.setOnTouchListener(owner);
				connectDialog.open();
				owner.hides = true; // 키보드가 보이도록 한다.
				IntegrationKeyboard keyboard = CommonGUI.keyboard;
				//keyboard.hides = false;
				//keyboard.setIsOpen(false);
				keyboard.setHides(false);
        	}
        	else {
        		CommonGUI.loggingForMessageBox.setText(true, "Select a file(s).", false);
        		CommonGUI.loggingForMessageBox.setHides(false);
        	}
			owner.state = State.Normal;
        }
        else if (button.iName==menuMultimedia.buttons[1].iName) {	// Start receiver
        	menuMultimedia.open(false);
        	owner.startReceiver();
        }            
        else if (button.iName==menuMultimedia.buttons[2].iName) {	// Listen to music
        	menuMultimedia.open(false);
        	owner.mPlayList =  fileListOfMultiSelect;
        	owner.playListAndCurSongInfo = null;
        	owner.listenToMusic(fileListOfMultiSelect, owner.playListAndCurSongInfo);
        }
        else if (button.iName==menuMultimedia.buttons[3].iName) {	// Watch video
        	menuMultimedia.open(false);
        	if (fileListOfMultiSelect!=null) {
            	String videoFilePath = MediaPlayerDel.getVideoFile(fileListOfMultiSelect);
            	if (videoFilePath==null) {
            		CommonGUI.loggingForMessageBox.setText(true, "Select a video file(s).", false);
            		CommonGUI.loggingForMessageBox.setHides(false);
            		return;
            	}
            	Intent intent = new Intent();
            	intent.setAction(Intent.ACTION_VIEW);
            	File videoFile = new File(videoFilePath);
            	Uri uriOfVideoFile = Uri.fromFile(videoFile);
            	// "video/*"
            	intent.setDataAndType(uriOfVideoFile, "video/*");
            	Control.activity.startActivity(intent);
        	}
        	
        }
        else if (button.iName==menuMultimedia.buttons[4].iName) {	// install a package
        	menuMultimedia.open(false);
        	if (fileListOfMultiSelect!=null && fileListOfMultiSelect.count>0) {
        		String filePath = fileListOfMultiSelect.getItem(0);
        		String ext = FileHelper.getExt(filePath);
        		if (!ext.equals(".apk")) {
        			CommonGUI.loggingForMessageBox.setText(true, "Select a package file.", false);
        			CommonGUI.loggingForMessageBox.setHides(false);
        			return;
        		}
        		
        		Intent intent = new Intent();
            	//intent.setAction(Intent.ACTION_VIEW);
            	intent.setAction(Intent.ACTION_INSTALL_PACKAGE);
            	File file = new File(filePath);
            	Uri uriOfFile = Uri.fromFile(file);
            	intent.setData(uriOfFile);
            	Control.activity.startActivity(intent);
        		
        	}
        	
        }
        else if (button.iName==menuMultimedia.buttons[5].iName) {	// Record sound
        	//menuMultimedia.open(false);
        	if (recorder==null)
        		recorder = new MediaRecorderDel();
        	if (menuMultimedia.buttons[5].getIsSelected()) {
        		if (!recorder.isInitialized) {
        			recorder.initialize();
        			recorder.start();
        		}
        		else {
        			recorder.start();
        		}
        	}
        	else {
        		recorder.stop();
        	}
            	
        	
        }
        else if (button.iName==menuMultimedia.buttons[6].iName) {	// Play record
        	menuMultimedia.open(false);
        	if (mediaPlayer==null) {
        		int x, y, w, h;
        		w = owner.bounds.width;
        		h = owner.buttonFunc.bounds.y;
        		x = 0;
        		y = 0;
        		Rectangle mediaBounds = new Rectangle(x,y,w,h); 
        		mediaPlayer = new MediaPlayerDel(view, mediaBounds);
        		
        		ArrayList list = new ArrayList(1);
        		list.add(new File(MediaRecorderDel.recordFile));
        		mediaPlayer.initialize(list, null);
        		//if (r) menuFunc.buttons[9].isSelected = true;
        		//else menuFunc.buttons[9].isSelected = false;
        	}
        	else {
        		ArrayList list = new ArrayList(1);
        		list.add(new File(MediaRecorderDel.recordFile));
        		mediaPlayer.initialize(list, null);
        		//if (r) menuFunc.buttons[9].isSelected = true;
        		//else menuFunc.buttons[9].isSelected = false;
        	}
        	
        } 
        else if (button.iName==menuMultimedia.buttons[7].iName) {	// Sound Control Menu            	
        	menuMultimedia.open(false);
        	if (mediaPlayer!=null && mediaPlayer.menuSoundControl!=null) {
            	//if (menuFunc.buttons[9].isSelected)
            		mediaPlayer.enableSoundControl(true);
            	//else 
            	//	mediaPlayer.enableSoundControl(false);
        	}
        	else {
        		CommonGUI.loggingForMessageBox.setText(true, "Touch the button, Listen to music", false);
        		CommonGUI.loggingForMessageBox.setHides(false);
        	}
        }
        else if (button.iName==menuMultimedia.buttons[8].iName) {	// Help me            	
        	menuMultimedia.open(false);
        	owner.menuHelp.open(true);
        }
        else if (button.iName==menuMultimedia.buttons[9].iName) {	// run A Class File            	
        	//menuMultimedia.open(false);
        	//this.runAClassFile();
        } 
	}
	
	
	
	
	/**클래스 파일을 jar파일로 만들어서 Console창에 결과를 출력하여 보여준다.*/
	/*void runAClassFile() {
		FileDialog owner = this.owner;
		
		if (owner.mAbsFilename==null) {
			CommonGUI.textViewConsole.setHides(false);
			return;
		}
		
		CommonGUI.loggingForMessageBox.setText(true, "Making a jar file and running it on JVM....", false);
		CommonGUI.loggingForMessageBox.setHides(false);
		
		ThreadRunOrDebugAClassFile thread = new ThreadRunOrDebugAClassFile(this, RunOrDebug.Run);
		thread.start();
	}*/
	
	
	
	
	/** fileListOfMultiSelect와 mAbsFileName을 다시 얻는다.*/
	/*void getfileListOfMultiSelectAndmAbsFileName() {
		int i;
		Button[] buttons = owner.menuFileList.buttons;
		owner.fileListOfMultiSelect.reset2();
		
		String curDir = owner.getCurDir();
		if (curDir.charAt(curDir.length()-1)!=File.separatorChar) {
			curDir += File.separator; 
		}
		
		for (i=0; i<buttons.length; i++) {
			if (buttons[i].getIsSelected()) {
				String filePath = curDir + buttons[i].name;
				owner.fileListOfMultiSelect.add(filePath);
			}
		}
		
		int count = owner.fileListOfMultiSelect.count;
		if (count==0) {
			owner.mAbsFilename = null;
			owner.filename = null;				
		}
		else if (count==1) {
			owner.mAbsFilename = owner.fileListOfMultiSelect.getItem(0);
		}
	}*/
	

	
	
	
	void processEventOfMenuFunc(Object sender) {
		Button button = (Button)sender;
		MenuWithClosable menuFunc = owner.menuFunc;
		String curDir = owner.getCurDir(true);
		
		//getfileListOfMultiSelectAndmAbsFileName();
		
		ArrayListString fileListOfMultiSelect = owner.fileListOfMultiSelect;
		MessageDialog messageDialog = owner.messageDialog;
		
		// "Make Dir", "Delete", "Rename", "Cut", "Copy", "Paste", "Send a file", "MultiSelect", "Listen to music"
		//"Make Dir", "Delete", "Rename", 
		//"Cut", "Copy", "Paste", "MultiSelect", "Sort", "Storage", "Properties" 
        if (button.iName==menuFunc.buttons[0].iName) { // Make Dir
        	boolean r;
        	menuFunc.open(false);
        	File file = new File(curDir+owner.getUniqueRandom());
        	r = file.mkdir();            	
        	if (!r) 	{
        		CommonGUI.loggingForMessageBox.setText(true, "Directory not created", false);
        		CommonGUI.loggingForMessageBox.setHides(false);
        	}
        	else {
        		owner.createAndSetFileListButtons(curDir, owner.category);
        	}
        	
        }
        else if (button.iName==menuFunc.buttons[1].iName) { // MkFile
        	menuFunc.open(false);
        	File file = new File(curDir+owner.getUniqueRandom());
        	try {
				file.createNewFile();
				owner.createAndSetFileListButtons(curDir, owner.category);
				
				CommonGUI.loggingForMessageBox.setText(true, file.getName() + " created", false);
        		CommonGUI.loggingForMessageBox.setHides(false);
			} catch (IOException e) {
				
				e.printStackTrace();
			}            	
        }
        else if (button.iName==menuFunc.buttons[2].iName) { // Delete
        	owner.state = State.Delete;
        	menuFunc.open(false);
        	if (fileListOfMultiSelect.count>0) {
        		messageDialog.setText("Delete this file(s)? ");
				messageDialog.open();
        	}
        	else {
        		CommonGUI.loggingForMessageBox.setText(true, "Select a file(s).", false);
        		CommonGUI.loggingForMessageBox.setHides(false);
        	}
        	
        }
        else if (button.iName==menuFunc.buttons[3].iName) {	// Rename
        	owner.state = State.Rename;
        	menuFunc.open(false);
        	if (fileListOfMultiSelect.count!=1) {
        		CommonGUI.loggingForMessageBox.setText(true, "Select only a file(folder).", false);
        		CommonGUI.loggingForMessageBox.setHides(false);
        		owner.state = State.Normal;
        		return;
        	}
        	String absFilename = fileListOfMultiSelect.getItem(0);
			messageDialog.setText("Rename a file " + 
					FileHelper.getFilename(absFilename) + " to " + 
					owner.editTextFilename.getText() + " ?");
			messageDialog.open();
			owner.mAbsFilename = absFilename;
        }
        else if (button.iName==menuFunc.buttons[4].iName) {	// Cut
        	owner.state = State.Cut;
        	menuFunc.open(false);
        	if (fileListOfMultiSelect.count>0) {
        		owner.cutOrCopy(fileListOfMultiSelect);
        		owner.resetMultiSelect();
            	owner.isCutOrCopy = true;
        	}
        	else {
        		CommonGUI.loggingForMessageBox.setText(true, "Select a file(s).", false);
        		CommonGUI.loggingForMessageBox.setHides(false);
        	}            	
        	owner.state = State.Normal;
        }
        else if (button.iName==menuFunc.buttons[5].iName) {	// Copy
        	owner.state = State.Copy;
        	menuFunc.open(false);
        	if (fileListOfMultiSelect.count>0) {
        		owner.cutOrCopy(fileListOfMultiSelect);
        		owner.resetMultiSelect();
            	owner.isCutOrCopy = false;
        	}
        	else {
        		CommonGUI.loggingForMessageBox.setText(true, "Select a file(s).", false);
        		CommonGUI.loggingForMessageBox.setHides(false);
        	}
        	owner.state = State.Normal;
        }
        else if (button.iName==menuFunc.buttons[6].iName) {	// Paste
        	menuFunc.open(false);
        	if (owner.fileListOfCutOrCopy!=null && owner.fileListOfCutOrCopy.count>0) {
        		// Makes new owner.fileListOfMultiSelect per thread. 
				owner.fileListOfMultiSelect = null;
				owner.resetMultiSelect();
            	if (owner.isCutOrCopy) owner.paste(true);
            	else owner.paste(false);
        	}
        	else {
        		CommonGUI.loggingForMessageBox.setText(true, "Cut or copy a file(s).", false);
        		CommonGUI.loggingForMessageBox.setHides(false);
        	}            	
        }
        else if (button.iName==menuFunc.buttons[7].iName) {	// Privillage
        	
        }
        else if (button.iName==menuFunc.buttons[8].iName) {	// MultiSelect
        	menuFunc.open(false);
        	//fileListOfMultiSelect.reset2();
        	if (menuFunc.buttons[8].getIsSelected()) {
        		owner.state = State.Normal;
            	owner.enableMultiSelect(true);	            	
        	}
        	else {
        		owner.state = State.Normal;
        		owner.enableMultiSelect(false);
        	}
        	owner.buttonMultiSelect.setIsSelected(menuFunc.buttons[8].getIsSelected());
        	if (Common_Settings.CurrentSystem.equals(Common_Settings.CurrentSystemIsJava) &&
        			Button.isTripleBuffering) 
        	{
        		owner.buttonMultiSelect.drawToImage(owner.buttonMultiSelect.mCanvas);
		    }
        }
        else if (button.iName==menuFunc.buttons[9].iName) {	// Sort
        	menuFunc.open(false);
        	owner.menuSort.open(true);
        }
        else if (button.iName==menuFunc.buttons[10].iName) {	// Storage
        	menuFunc.open(false);
        	owner.getStorage();
        	
        }
        else if (button.iName==menuFunc.buttons[11].iName) {	// Properties
        	menuFunc.open(false);
        	owner.getProperties(fileListOfMultiSelect);
        	
        }
	}
	
	void processEventOfMenuWithScrollBar(Object sender) {
		// 폴더나 파일을 사용자가 선택했을 때 호출된다.
		MenuWithScrollBar menu = (MenuWithScrollBar)sender;	
		String curDir = owner.getCurDir(true);
		
		owner.editTextFilename.isSelecting = false;
		if (menu.selectedButtonName==null) { // menuFileList의 공백영역을 터치시
			owner.editTextFilename.setText(0, new CodeString("", owner.editTextFilename.textColor));
			owner.filename = null;
			owner.mAbsFilename = null;
			owner.resetMultiSelect();
			return;
		}
		owner.editTextFilename.setText(0, new CodeString(menu.selectedButtonName, owner.editTextFilename.textColor));
		if (menu.selectedButtonName.equals("Up")) {
			// 윈도우즈에서 루트일 경우 up을 클릭했을때는 
			// absFilename가 IO.LocalComputer가 된다.
			owner.mAbsFilename = FileHelper.upDirectory(curDir);
			
		}
		else {
			if (curDir.equals(IO.LocalComputer+File.separator)) {
				// 윈도우즈에서 파티션들중 하나를 클릭한 경우
				// absFilename는 "c:\"가 되고 curDir을 루트로 정해준다.
				owner.mAbsFilename = menu.selectedButtonName;
				curDir = owner.mAbsFilename;
			}
			else {
				owner.mAbsFilename = curDir + menu.selectedButtonName;
			}
		}
		
		// Makes each delete, paste, properties thread have own fileListOfMultiSelect
		if (owner.fileListOfMultiSelect==null) {
			owner.fileListOfMultiSelect = new ArrayListString(3);
		}
			
		boolean multiSelect = owner.buttonMultiSelect.getIsSelected();
		if (!multiSelect) {
			try{
				File file = new File(owner.mAbsFilename);
				// 윈도우즈에서 루트일 경우 up을 클릭했을때는 
				// absFilename가 IO.LocalComputer가 된다.
				// 이때는 파티션들이 버튼들로 생성된다.
				if (owner.mAbsFilename.equals(IO.LocalComputer+File.separator) || file.isDirectory()) {
					owner.getPermission(file);
					
					// 선택한 디렉토리로 이동한다.
					owner.createAndSetFileListButtons(owner.mAbsFilename, owner.category);
					owner.state = State.Normal;
					owner.menuFileList.buttonsOfSelect.reset();
					owner.fileListOfMultiSelect.reset2();
					owner.closePermission();
					
					// multiselect가 해제된 상태에서 디렉토리 버튼을 눌렀을때는 
					// fileListOfMultiSelect, mAbsFilename, filename들을 모두 초기화한다. 
					owner.mAbsFilename = null;
					owner.filename = null;
				}
				else {
					// 일반적인 파일
					owner.fileListOfMultiSelect.reset2();
					owner.fileListOfMultiSelect.add(owner.mAbsFilename);
				}
				
			}catch(Exception e1) {
				e1.printStackTrace();
				CompilerHelper.printStackTrace(FileDialog.textViewLogBird, e1);
			}
		}// if (!multiSelect) {
		else {
			if (menu.selectedButtonName.equals("Up")) {
				owner.mAbsFilename = null;
				owner.resetMultiSelect();
				return;
			}
			else {
				// multiselect 상태에서 버튼을 선택할 경우 absFilename를 이미 갖고 있는 경우에는 추가를 하지 않고
				// 없을 경우에만 fileListOfMultiSelect에 넣는다.
				String absFilename = owner.mAbsFilename;
				if (menu.selectedButton.getIsSelected()) {
					int index = owner.fileListOfMultiSelect.getIndex(absFilename);
					if (index==-1) {
						owner.fileListOfMultiSelect.add(absFilename);
					}
					owner.mAbsFilename = absFilename;
					owner.filename = FileHelper.getFilename(absFilename);
				}
				// multiselect 상태에서 버튼 선택을 해제할 경우 absFilename를 이미 갖고 있는 경우에는 그것을 제거한다.
				else {
					int index = owner.fileListOfMultiSelect.getIndex(absFilename);
					if (index!=-1) {
						try {
							owner.fileListOfMultiSelect.delete(index, 1);
						} catch (Exception e) {
							
							e.printStackTrace();
						}
					}
					if (owner.fileListOfMultiSelect.count>0) {
						owner.mAbsFilename = owner.fileListOfMultiSelect.getItem(owner.fileListOfMultiSelect.count-1);
						owner.filename = FileHelper.getFilename(owner.mAbsFilename);
					}
					else {
						owner.mAbsFilename = null;
						owner.filename = null;
					}
				}
			}
		}
	}
	
	void processEventOfMessageDialog(Object sender) {
		MessageDialog dialog = (MessageDialog)sender;
		if (dialog.getIsOK()) {
			if (owner.state==State.Delete) {
				CommonGUI.loggingForMessageBox.setText(true, "Deleting..", false);
				CommonGUI.loggingForMessageBox.setHides(false);
				Control.view.invalidate();
				
				ThreadDelete deleteThread = new ThreadDelete(owner, owner.fileListOfMultiSelect);
				// Makes new owner.fileListOfMultiSelect per thread. 
				owner.fileListOfMultiSelect = null;
				owner.resetMultiSelect();
				deleteThread.start();
				
				
			}
			else if (owner.state==State.Rename) {
				File file = new File(owner.mAbsFilename);
				String filename = owner.editTextFilename.getText().str;
				String newFilename = owner.getCurDir(true)+filename;
				boolean success=false;
				if (filename.equals("Up") || filename.equals("") || owner.mAbsFilename.equals(newFilename))
					success = false;
				else {
					success = file.renameTo(new File(newFilename));
				}
				if (!success) {
					CommonGUI.loggingForMessageBox.setText(true, "Rename failed.", false);
					CommonGUI.loggingForMessageBox.setHides(false);
				}
				owner.createAndSetFileListButtons(owner.getCurDir(true), owner.category);
				
				owner.fileListOfMultiSelect.reset2();
				// createAndSetFileListButtons 뒤에 Button의 toggleable상태가 원상태로
				// 바뀌기 때문에 MultiSelect상태를 해제해준다.
				owner.resetMultiSelect();
				owner.state = State.Normal;
			}
		}
	}
	
}