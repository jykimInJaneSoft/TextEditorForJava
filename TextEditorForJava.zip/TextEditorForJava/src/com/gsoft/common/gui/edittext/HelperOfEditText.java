package com.gsoft.common.gui.edittext;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.util.HighArray_CodeChar;

public class HelperOfEditText {
	static boolean isNextCharBkSp(CodeString text, int i) {
		int textLen = text.length();
		CodeString nextCharA;
		nextCharA = text.substring(i+1, i+2);
		if (nextCharA.toString().equals("%")) {
			if (i+3<textLen) {
				CodeString str = text.substring(i+2, i+4);
				if (str.toString().equals("bk")) {
					return true;
				}						
			}
		}
		return false;
	}
	
	static boolean isNextCharBkSp(HighArray_CodeChar text, int i) {
		int textLen = text.getCount();
		CodeString nextCharA;
		nextCharA = text.substring(i+1, i+2);
		if (nextCharA.toString().equals("%")) {
			if (i+3<textLen) {
				CodeString str = text.substring(i+2, i+4);
				if (str.toString().equals("bk")) {
					return true;
				}						
			}
		}
		return false;
	}
	
	static boolean isCurCharBkSp(CodeString text, int i) {
		CodeString charA = text.substring(i, i+1);
		if (charA.toString().equals("%")) {
			if (i+2<text.length()) {
				CodeString str = text.substring(i+1, i+3);
				if (str.toString().equals("bk")) {
					return true;
				}
			}
		}
		return false;
	}
	
	static boolean isCurCharBkSp(HighArray_CodeChar text, int i) {
		CodeString charA = text.substring(i, i+1);
		if (charA.toString().equals("%")) {
			if (i+2<text.getCount()) {
				CodeString str = text.substring(i+1, i+3);
				if (str.toString().equals("bk")) {
					return true;
				}
			}
		}
		return false;
	}
	
	static boolean isCurCharDelete(CodeString text, int i) {
		CodeString charA = text.substring(i, i+1);
		if (charA.toString().equals("%")) {
			if (i+2<text.length()) {
				CodeString str = text.substring(i+1, i+3);
				if (str.toString().equals("dl")) {
					return true;
				}
			}
		}
		return false;
	}
	
	static boolean isCurCharDelete(HighArray_CodeChar text, int i) {
		CodeString charA = text.substring(i, i+1);
		if (charA.toString().equals("%")) {
			if (i+2<text.getCount()) {
				CodeString str = text.substring(i+1, i+3);
				if (str.toString().equals("dl")) {
					return true;
				}
			}
		}
		return false;
	}	
}
