package com.gsoft.common.gui.edittext;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Point;
import android.util.Log;
import android.view.View;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.CommonGUI;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.ContentManager;
import com.gsoft.common.Events.MotionEvent;
import com.gsoft.common.FileHelper;
import com.gsoft.common.Font;
import com.gsoft.common.Font.FontFamily;
import com.gsoft.common.IO;
import com.gsoft.common.Sizing.Rectangle;
import com.gsoft.common.Sizing.Size;
import com.gsoft.common.R.R;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.gui.Control;
import com.gsoft.common.gui.FileDialog;
import com.gsoft.common.gui.FindReplaceDialog;
import com.gsoft.common.gui.FontSizeDialog;
import com.gsoft.common.gui.IntegrationKeyboard;
import com.gsoft.common.gui.IntegrationKeyboard.Hangul;
import com.gsoft.common.gui.IntegrationKeyboard.Mode;
import com.gsoft.common.gui.Menu.MenuType;
import com.gsoft.common.gui.MenuWithAlwaysOpen;
import com.gsoft.common.gui.MenuWithClosable;
import com.gsoft.common.gui.TextView;
import com.gsoft.common.gui.edittext.Edit.ScrollMode;
import com.gsoft.common.gui.edittext.EditRichText.PartOfStr;
import com.gsoft.common.gui.edittext.EditRichText_Types.Character;
import com.gsoft.common.gui.edittext.EditRichText_Types.TextLine;
import com.gsoft.common.util.Array;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.Util;

import com.gsoft.common.gui.edittext.EditRichText;
import com.gsoft.common.gui.edittext.UndoOfEditRichText;
import com.gsoft.common.gui.edittext.RedoOfEditRichText;
import com.gsoft.common.gui.edittext.Edit;

public class FunctionOfEditRichText {
	/**"Left", "Right", "Up", "Down", "Home", "End", "PgUp", "PgDn"*/
	public static void controlChar(EditRichText editRichText, int indexInSpecialKeys, String charA) {
		if (0<=indexInSpecialKeys && indexInSpecialKeys<=7)
			editRichText.isSelecting = false;
		
		Point cursorPos = editRichText.cursorPos;
		TextLine[] textArray = editRichText.textArray;
		
		
		switch (indexInSpecialKeys) {
			case 0: {
				if (cursorPos.x>0) cursorPos.x--;
				else {
					if (cursorPos.x==0 && cursorPos.y>0) {
						cursorPos.y--;
						cursorPos.x = textArray[cursorPos.y].count;
					}
				}
				break;
			}				
			case 1: {
				if (cursorPos.x<textArray[cursorPos.y].count) cursorPos.x++;
				else {
					if (cursorPos.x==textArray[cursorPos.y].count && cursorPos.y<editRichText.numOfLines-1) {
						cursorPos.y++;
						cursorPos.x = 0;
					}
				}
				break;
			}
			case 2: {
				if (cursorPos.y>0) cursorPos.y--;
				if (cursorPos.x>textArray[cursorPos.y].count) 
					cursorPos.x = textArray[cursorPos.y].count;
				if (cursorPos.x<0) cursorPos.x = 0; 
				break;
			}
			case 3: {
				if (cursorPos.y<editRichText.numOfLines-1) cursorPos.y++; 
				if (cursorPos.x>textArray[cursorPos.y].count) 
					cursorPos.x = textArray[cursorPos.y].count;
				if (cursorPos.x<0) cursorPos.x = 0;
				break;
			}
			case 4: cursorPos.x = 0; break;//"Home"
			case 5: {// "End"
				cursorPos.x = textArray[cursorPos.y].count-1;
				if (cursorPos.x<0) cursorPos.x = 0;
				break;
			}
			case 6: { // "PgUp"
						cursorPos.y -= editRichText.numOfLinesPerPage;
						if (cursorPos.y<0) cursorPos.y = 0;
						if (cursorPos.x>textArray[cursorPos.y].count) 
							cursorPos.x = textArray[cursorPos.y].count;
						if (cursorPos.x<0) cursorPos.x = 0;
						break;
				
					}
			case 7: { // "PgDn"
						cursorPos.y += editRichText.numOfLinesPerPage;
						if (cursorPos.y>=editRichText.numOfLines) cursorPos.y = editRichText.numOfLines-1;
						if (cursorPos.x>textArray[cursorPos.y].count) 
							cursorPos.x = textArray[cursorPos.y].count;
						if (cursorPos.x<0) cursorPos.x = 0;
						break;
				
					}
		}//switch
		
		editRichText.cursorPos = cursorPos;
		editRichText.textArray = textArray;
		
		editRichText.setToolbarAndCurState(editRichText.cursorPos);
			
			if (editRichText.scrollMode==ScrollMode.VScroll) {			
				editRichText.setVScrollPos();
				editRichText.setVScrollBar(true);
			}		
			else if (editRichText.scrollMode==ScrollMode.Both) {
				editRichText.setVScrollPos();
				editRichText.setHScrollPos();
				editRichText.setVScrollBar(true);			
				editRichText.setHScrollBar(true);				
			}
		
	}
	
	
	/**selectP1,selectP2는 논리적 좌표*/ 
	public static void makeSelectIndices(EditRichText editRichText, boolean isSelectingOrFinding, Point selectP1, Point selectP2) {
		try{
			if (isSelectingOrFinding) {
				int selectIndicesCount;
				int selectLenY;
				int selectIndicesCountForCopy;
				TextLine[] textArray = editRichText.textArray;
				Point[] selectIndices = editRichText.selectIndices;
				
				int i;
				selectIndicesCount = 0;
				if (selectP1==null || selectP2==null) return;
				if (selectP1.y<=selectP2.y) {
					selectLenY = selectP2.y - selectP1.y + 1;
					
					// 경계처리
					if (textArray[selectP2.y].count<=selectP2.x) {
						if (textArray[selectP2.y].count>0)
							selectP2.x = textArray[selectP2.y].count-1;
						else 
							selectP2.x = 0;
					}
					if (textArray[selectP1.y].count<=selectP1.x) {
						if (textArray[selectP1.y].count>0)
							selectP1.x = textArray[selectP1.y].count-1;
						else
							selectP1.x = 0;
					}
					
					if (selectLenY==1) {
						if (selectP1.x<=selectP2.x) {								
							selectIndices[selectIndicesCount++] = new Point(selectP1.x, selectP1.y);
							selectIndices[selectIndicesCount++] = new Point(selectP2.x, EditRichText.Select_FirstLine);
						}
						else {
							selectIndices[selectIndicesCount++] = new Point(selectP2.x, selectP2.y);
							selectIndices[selectIndicesCount++] = new Point(selectP1.x, EditRichText.Select_FirstLine);
						}
					}
					else {
						// 첫번째 라인
						selectIndices[selectIndicesCount++] = new Point(selectP1.x,selectP1.y);
						selectIndices[selectIndicesCount++] = new Point(textArray[selectP1.y].count-1, 
								EditRichText.Select_FirstLine);
						for (i=selectP1.y+1; i<selectP2.y; i++) {
							if (!(selectIndicesCount<=selectIndices.length-2)) 
								selectIndices = toPointArray( Array.Resize(selectIndices, selectIndices.length+20) );
							selectIndices[selectIndicesCount++] = new Point(0, i);
							selectIndices[selectIndicesCount++] = 
									new Point(textArray[i].count-1, EditRichText.Select_MiddleLine);
						}
						// 마지막 라인
						if (!(selectIndicesCount<=selectIndices.length-2)) 
								selectIndices = toPointArray( Array.Resize(selectIndices, selectIndices.length+20) );
						selectIndices[selectIndicesCount++] = new Point(0, selectP2.y);
						selectIndices[selectIndicesCount++] = new Point(selectP2.x, EditRichText.Select_LastLine);
					}
					selectIndicesCountForCopy = selectIndicesCount;
				}
				else {		// selectP1.y > selectP2.y
					selectLenY = selectP1.y - selectP2.y + 1;
					
					// 경계처리
					if (textArray[selectP2.y].count<=selectP2.x) {
						if (textArray[selectP2.y].count>0)
							selectP2.x = textArray[selectP2.y].count-1;
						else 
							selectP2.x = 0;
					}
					if (textArray[selectP1.y].count<=selectP1.x) {
						if (textArray[selectP1.y].count>0)
							selectP1.x = textArray[selectP1.y].count-1;
						else
							selectP1.x = 0;
					}
					
					// 첫번째 라인
					selectIndices[selectIndicesCount++] = new Point(selectP2.x,selectP2.y);
					selectIndices[selectIndicesCount++] = new Point(textArray[selectP2.y].count-1, 
							EditRichText.Select_FirstLine);
					for (i=selectP2.y+1; i<selectP1.y; i++) {
						if (!(selectIndicesCount<=selectIndices.length-2)) 
							selectIndices = toPointArray( Array.Resize(selectIndices, selectIndices.length+20) );
						selectIndices[selectIndicesCount++] = new Point(0, i);
						selectIndices[selectIndicesCount++] = new Point(textArray[i].count-1, EditRichText.Select_MiddleLine);
					}
					// 마지막 라인
					if (!(selectIndicesCount<=selectIndices.length-2)) 
						selectIndices = toPointArray( Array.Resize(selectIndices, selectIndices.length+20) );
					selectIndices[selectIndicesCount++] = new Point(0, selectP1.y);
					selectIndices[selectIndicesCount++] = new Point(selectP1.x, EditRichText.Select_LastLine);
					
					selectIndicesCountForCopy = selectIndicesCount;
				}
				
				editRichText.selectIndicesCount = selectIndicesCount;
				editRichText.selectLenY = selectLenY;
				editRichText.selectIndicesCountForCopy = selectIndicesCountForCopy;
				editRichText.textArray = textArray; 
				editRichText.selectIndices = selectIndices; 
			}
			else {	// if (isSelectingOrFinding)
				int findIndicesCount;
				int findLenY;
				int findIndicesCountForCopy = editRichText.findIndicesCountForCopy;
				Point findP1 = editRichText.findP1;
				Point findP2 = editRichText.findP2;
				TextLine[] textArray = editRichText.textArray;
				Point[] findIndices = editRichText.findIndices;
				
				int i;
				findIndicesCount = 0;
				if (findP1==null || findP2==null) return;
				if (findP1.y<=findP2.y) {
					findLenY = findP2.y - findP1.y + 1;
					
					// 경계처리
					if (textArray[findP2.y].count<=findP2.x) {
						if (textArray[findP2.y].count>0)
							findP2.x = textArray[findP2.y].count-1;
						else
							findP2.x = 0;
					}
					if (textArray[findP1.y].count<=findP1.x) {
						if (textArray[findP1.y].count>0)
							findP1.x = textArray[findP1.y].count-1;
						else
							findP1.x = 0;
					}
					
					if (findLenY==1) {
						if (findP1.x<=findP2.x) {								
							findIndices[findIndicesCount++] = new Point(findP1.x,findP1.y);
							findIndices[findIndicesCount++] = new Point(findP2.x, EditRichText.Select_FirstLine);
						}
						else {
							findIndices[findIndicesCount++] = new Point(findP2.x,findP2.y);
							findIndices[findIndicesCount++] = new Point(findP1.x, EditRichText.Select_FirstLine);
						}
					}
					else {
						// 첫번째 라인
						findIndices[findIndicesCount++] = new Point(findP1.x,findP1.y);
						findIndices[findIndicesCount++] = new Point(textArray[findP1.y].count-1, 
								EditRichText.Select_FirstLine);
						for (i=findP1.y+1; i<findP2.y; i++) {
							if (!(findIndicesCount<=findIndices.length-2)) 
								findIndices = toPointArray( Array.Resize(findIndices, findIndices.length+20) );
							findIndices[findIndicesCount++] = new Point(0, i);
							findIndices[findIndicesCount++] = 
									new Point(textArray[i].count-1, EditRichText.Select_MiddleLine);
						}
						// 마지막 라인
						if (!(findIndicesCount<=findIndices.length-2)) 
								findIndices = toPointArray( Array.Resize(findIndices, findIndices.length+20) );
						findIndices[findIndicesCount++] = new Point(0, findP2.y);
						findIndices[findIndicesCount++] = new Point(findP2.x, EditRichText.Select_LastLine);
					}
					findIndicesCountForCopy = findIndicesCount;
				}
				else {		// findP1.y > findP2.y
					findLenY = findP1.y - findP2.y + 1;
					
					// 경계처리
					if (textArray[findP2.y].count<=findP2.x) {
						if (textArray[findP2.y].count>0)
							findP2.x = textArray[findP2.y].count-1;
						else
							findP2.x = 0;
					}
					if (textArray[findP1.y].count<=findP1.x) {
						if (textArray[findP1.y].count>0)
							findP1.x = textArray[findP1.y].count-1;
						else
							findP1.x = 0;
					}
					
					// 첫번째 라인
					findIndices[findIndicesCount++] = new Point(findP2.x,findP2.y);
					findIndices[findIndicesCount++] = new Point(textArray[findP2.y].count-1, 
							EditRichText.Select_FirstLine);
					for (i=findP2.y+1; i<findP1.y; i++) {
						if (!(findIndicesCount<=findIndices.length-2)) 
							findIndices = toPointArray( Array.Resize(findIndices, findIndices.length+20) );
						findIndices[findIndicesCount++] = new Point(0, i);
						findIndices[findIndicesCount++] = new Point(textArray[i].count-1, EditRichText.Select_MiddleLine);
					}
					// 마지막 라인
					if (!(findIndicesCount<=findIndices.length-2)) 
						findIndices = toPointArray( Array.Resize(findIndices, findIndices.length+20) );
					findIndices[findIndicesCount++] = new Point(0, findP1.y);
					findIndices[findIndicesCount++] = new Point(findP1.x, EditRichText.Select_LastLine);
					
					findIndicesCountForCopy = findIndicesCount;
				}
				
				editRichText.findIndicesCount = findIndicesCount;
				editRichText.findLenY = findLenY;
				editRichText.findIndicesCountForCopy = findIndicesCountForCopy;
				editRichText.findP1 = findP1;
				editRichText.findP2 = findP2;
				editRichText.textArray = textArray;
				editRichText.findIndices = findIndices;
			}
		}catch(Exception e) {
			//Log.e("makeSelectIndices",e.toString());
			e.printStackTrace();
			CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
		}
	}
	
	public static void copy(EditRichText editRichText) {
		if (editRichText.isSelecting) {
			editRichText.isCopied = true;
			int i;
			int y;
			int startX, endX;
			editRichText.copiedText.reset();
			for (i=0; i<editRichText.selectIndicesCountForCopy; i+=2) {
				y = editRichText.selectIndices[i].y;
				startX = editRichText.selectIndices[i].x;
				endX = editRichText.selectIndices[i+1].x;
				TextLine lineCopiedText = editRichText.textArray[y].subTextLine(startX, endX+1);
				editRichText.copiedText.insert(lineCopiedText.toCharacterArray(),0,
						editRichText.copiedText.count,lineCopiedText.count);
			}
			
			//if (Control.CurrentSystem.equals(Control.CurrentSystemIsJava)) {
				Control.ClipBoardX.setData(editRichText.copiedText.toString());
			//}
		}
	}
	
	public static void cut(EditRichText editRichText) {
		if (editRichText.isReadOnly) return;
		
		editRichText.isModified = true;
		try {
		if (editRichText.isSelecting) {
			editRichText.isCopied = true;
			int i;
			int y;
			int startX, endX;
			editRichText.copiedText.reset();
			int[] fullLines = new int[10];
			int fullLinesCount = 0;
				
			UndoOfEditRichText.backUpForUndo(editRichText, "cut", false);
			// redo 를 무효화한다. redoBuffer를 모두 지워야 한다. 
			// redo 를 무효로 만들지 않으면 undo-redo 시스템의 오류가 발생한다.
			editRichText.redoBuffer.reset();
			
			for (i=0; i<editRichText.selectIndicesCountForCopy; i+=2) {
				y = editRichText.selectIndices[i].y;
				startX = editRichText.selectIndices[i].x;
				endX = editRichText.selectIndices[i+1].x;
				TextLine lineCopiedText = editRichText.textArray[y].subTextLine(startX, endX+1);
				editRichText.copiedText.insert(lineCopiedText.toCharacterArray(),0,
						editRichText.copiedText.count,lineCopiedText.count);
				
				if (editRichText.textArray[y].count==lineCopiedText.count) { 
					// full line이면 줄 자체를 삭제
					if (!(fullLinesCount<=fullLines.length-1)) 
						fullLines = Array.Resize(fullLines, fullLines.length+10);
					fullLines[fullLinesCount++] = y;
				}
				else {
					TextLine line = new TextLine(editRichText.textArray[y].toCharacterArray());
					//list.setText(textArray[y]);
					line.delete(startX, endX-startX+1);
					editRichText.textArray[y] = line;
				}
			}
			
			// full line이면 줄 자체를 삭제
			if (fullLinesCount>0) {
				ArrayList listTextArray = new ArrayList(editRichText.textArray);
				listTextArray.delete(fullLines[0], fullLinesCount);
				editRichText.textArray = toTextLineArray( listTextArray.getItems() );
				editRichText.numOfLines -= fullLinesCount;
			}
			
			// full line을 제외한 select영역에 포함된 newline문자를 제거한다.
			TextLine newText = editRichText.TextArrayToText(editRichText.selectIndices[0].y, editRichText.cursorPos.x, 1);
			editRichText.setTextMultiLine(editRichText.selectIndices[0].y, newText, -1, 1);
			
			Point p1 = editRichText.selectP1;
			if (editRichText.selectP1.y>editRichText.selectP2.y) { // swapping
				p1 = editRichText.selectP2;
			}
			else if (editRichText.selectP1.y==editRichText.selectP2.y) {
				if (editRichText.selectP1.x>editRichText.selectP2.x) {
					// swapping, y가 같을땐 x를 비교해서 작은쪽이 p1이 된다.
					p1 = editRichText.selectP2;
				}
			}
			
			Control.ClipBoardX.setData(editRichText.copiedText.toString());
			
			editRichText.cursorPos.x = p1.x;
			editRichText.cursorPos.y = p1.y;
			
			editRichText.isSelecting = false;
		}
		}catch(Exception e) {
			e.printStackTrace();
			CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
		}
	}
	
	public static void paste(EditRichText editRichText) {
		if (editRichText.isReadOnly) return;
		
		//if (Control.CurrentSystem.equals(Control.CurrentSystemIsJava)) {
			String dataClipboard = Control.ClipBoardX.getData();
			TextLine data = new TextLine(dataClipboard, editRichText.initFontSize);
			if (dataClipboard!=null) {
				editRichText.isCopied = true;
				editRichText.copiedText = data;
			}
		//}
		
		if (!editRichText.isCopied) return;
		
		editRichText.isModified = true;
		
		UndoOfEditRichText.backUpForUndo(editRichText, "paste", false);
		// redo 를 무효화한다. redoBuffer를 모두 지워야 한다. 
		// redo 를 무효로 만들지 않으면 undo-redo 시스템의 오류가 발생한다.
		editRichText.redoBuffer.reset();
		
		TextLine left = editRichText.textArray[editRichText.cursorPos.y].subTextLine(0, editRichText.cursorPos.x);
		TextLine right = editRichText.textArray[editRichText.cursorPos.y].subTextLine(editRichText.cursorPos.x, 
				editRichText.textArray[editRichText.cursorPos.y].count);
		// newCurLineText = left + copiedText + right
		left.insert(editRichText.copiedText.toCharacterArray(), 0, left.count, editRichText.copiedText.count);
		left.insert(right.toCharacterArray(),0,left.count,right.count);
		
		Point oldCursorPos = new Point();
		oldCursorPos.x = editRichText.cursorPos.x;
		oldCursorPos.y = editRichText.cursorPos.y;
		
		editRichText.indexOfCursorInText = editRichText.copiedText.count;
		/*int numOfNewLineChar = getNumOfNewLineChar(left);
		setTextMultiLine(cursorPos.y, left, 1, numOfNewLineChar);
		
		cursorPos.x = oldCursorPos.x;
		cursorPos.y = oldCursorPos.y;*/
		
		int numOfNewLineChar = editRichText.getNumOfNewLineChar(left) + 1;
		if (left.characters[left.count-1].charA=='\n') {
			numOfNewLineChar--;
		}
		editRichText.setTextMultiLine(editRichText.cursorPos.y, left, 1, numOfNewLineChar);
		
		Point relativeCursorPos = editRichText.getRelativeCursorPos(oldCursorPos, editRichText.copiedText);
		
		editRichText.cursorPos.x = relativeCursorPos.x;
		editRichText.cursorPos.y = relativeCursorPos.y;
		
		Control.view.invalidate();
	}
	
	public static void openFindReplaceDialog(EditRichText editRichText) {
		// 모든 EditText들이 findReplaceDialog을 공유하므로 changeBounds를 해준다.			
		Edit.createFindReplaceDialog(true);
		if (editRichText.isSelecting) {
			Edit.findReplaceDialog.setScope(false);
		}
		else {
			Edit.findReplaceDialog.setScope(true);
		}
		Edit.findReplaceDialog.open(editRichText, true);
	}
	
	
	/** functionMenu_listener(), 키보드 가속기(EditText의 OnTouchEvent())에서 호출*/
	public static void selectAll(EditRichText editRichText) {
		if (editRichText.selectP1==null) {
			editRichText.selectP1 = new Point();			
		}
		editRichText.selectP1.x = 0;
		editRichText.selectP1.y = 0;
		
		if (editRichText.selectP2==null) {
			editRichText.selectP2 = new Point();			
		}
		if (editRichText.textArray[editRichText.numOfLines-1].count>0) {
			editRichText.selectP2.x = editRichText.textArray[editRichText.numOfLines-1].count-1;
		}
		else {
			editRichText.selectP2.x = 0;
		}
		editRichText.selectP2.y = editRichText.numOfLines-1;
		
		makeSelectIndices(editRichText, true, editRichText.selectP1, editRichText.selectP2);
		
		editRichText.isSelecting = true;
	}
	
	public static void functionMenu_Listener(EditRichText editRichText, Object sender, String strMenuName) {
		Edit.menuFunction.open(false);
		
		/*static final String[] Menu_Function = { 
			"Undo(Ctrl+z)", "Redo(Ctrl+y)", 
			"Copy(Ctrl+c)", "Cut(Ctrl+x)", "Paste(Ctrl+v)", 
			"Find/Replace(Ctrl+f)", 
			"Select all(Ctrl+a)",
			"Show UndoBuffer", "Show RedoBuffer"
		};*/
		
		
		if (strMenuName.equals("Copy(Ctrl+c)")) {
			copy(editRichText);
		}
		else if (strMenuName.equals("Cut(Ctrl+x)")) {
			cut(editRichText);
		}
		else if (strMenuName.equals("Paste(Ctrl+v)")) {
			paste(editRichText);
		}
		else if (strMenuName.equals("Select all(Ctrl+a)")) {
			selectAll(editRichText);
		}
		else if (strMenuName.equals("Find/Replace(Ctrl+f)")) {
			openFindReplaceDialog(editRichText);
		}
		else if (strMenuName.equals("Undo(Ctrl+z)")) {
			UndoOfEditRichText.undo(editRichText);
		}
		else if (strMenuName.equals("Redo(Ctrl+y)")) {
			RedoOfEditRichText.redo(editRichText);
		}
		else if (strMenuName.equals("Show UndoBuffer")) {
			showUndoBuffer(editRichText);
		}
		else if (strMenuName.equals("Show RedoBuffer")) {
			showRedoBuffer(editRichText);
		}
	
	
		/*if (strMenuName.equals("Copy")) {
			copy();
		}
		else if (strMenuName.equals("Cut")) {
			cut();
		}
		else if (strMenuName.equals("Paste")) {
			paste();
		}
		else if (strMenuName.equals("Find/Replace")) {
			// 모든 EditText들이 findReplaceDialog을 공유하므로 changeBounds를 해준다.			
			Rectangle newBounds = new Rectangle(totalBounds.x, totalBounds.y, totalBounds.width, totalBounds.height);
			Edit.findReplaceDialog.changeBounds(newBounds);
			if (isSelecting) {
				Edit.findReplaceDialog.setScope(false);
			}
			else {
				Edit.findReplaceDialog.setScope(true);
			}
			Edit.findReplaceDialog.open(editRichText, true);
		}
		else if (strMenuName.equals("Undo")) {
			undo();
		}
		else if (strMenuName.equals("Redo")) {
			redo();
		}
		else if (strMenuName.equals("Show UndoBuffer")) {
			showUndoBuffer();
		}
		else if (strMenuName.equals("Show RedoBuffer")) {
			showRedoBuffer();
		}*/
	}
	
	public static void toolbar_Listener(EditRichText editRichText, Object sender, String buttonName) {
		if (buttonName.equals("S")) {	// 툴바버튼
			// open할 때 모든 EditText들이 공유하는 MenuFontSize의 영역을 바꿔준다.
			Edit.createMenuFontSize(true);
			Edit.menuFontSize.open(editRichText, true);
			//return;
		}
		else if (buttonName.equals("F")) {
			editRichText.menuTypeface.open(true);
			//return;
		}
		else if (buttonName.equals("C")) {
			// open할 때 모든 EditText들이 공유하는 ColorDialog의 영역을 바꿔준다.
			Control.viewEx.createColorDialog(true);
			editRichText.colorDialog.open(editRichText, true);
		}
		else if (buttonName.equals("B") || buttonName.equals("I")) {
			FontFamily family = Font.fromString(editRichText.typefaceName);
			if (editRichText.isBold && editRichText.isItalic)
				editRichText.typeface = Font.getTypeface(family, true, true);
			else if (editRichText.isBold)
				editRichText.typeface = Font.getTypeface(family, true, false);
			else if (editRichText.isItalic)
				editRichText.typeface = Font.getTypeface(family, false, true);
			else
				editRichText.typeface = Font.getTypeface(family, false, false);
			if (!editRichText.isSelecting) {							
				return;
			}
			else {
				int k, j;
				for (k=0; k<editRichText.selectIndicesCount; k+=2) {
					int start = editRichText.selectIndices[k].x;
					int end = editRichText.selectIndices[k+1].x;
					int count = editRichText.textArray[editRichText.selectIndices[k].y].count;
					for (j=start; j<=end && j<count; j++) {
						editRichText.textArray[editRichText.selectIndices[k].y].characters[j].typeface = 
								editRichText.typeface;
						editRichText.textArray[editRichText.selectIndices[k].y].characters[j].typefaceName = 
								editRichText.typefaceName;
						editRichText.textArray[editRichText.selectIndices[k].y].characters[j].isBold = 
								editRichText.isBold;
						editRichText.textArray[editRichText.selectIndices[k].y].characters[j].isItalic = 
								editRichText.isItalic;
					}								
				}
				editRichText.realign();
			}
		}
		else if (buttonName.equals("U")) {
			if (editRichText.isSelecting) {
				int k, j;
				for (k=0; k<editRichText.selectIndicesCount; k+=2) {
					int start = editRichText.selectIndices[k].x;
					int end = editRichText.selectIndices[k+1].x;
					int count = editRichText.textArray[editRichText.selectIndices[k].y].count;
					for (j=start; j<=end && j<count; j++) {
						editRichText.textArray[editRichText.selectIndices[k].y].characters[j].isUnderLine = 
								editRichText.isUnderline;
					}								
				}
				editRichText.realign();
			}
		}
		else if (buttonName.equals("P")) {
			editRichText.fileDialog = CommonGUI.fileDialog;
			if (editRichText.fileDialog.getIsOpen()) {
				CommonGUI.loggingForMessageBox.setText(true, "File explorer already opens", false);
				CommonGUI.loggingForMessageBox.setHides(false);
				return;
			}
			
			if (!editRichText.isMaximized) {
				editRichText.fileDialog.isFullScreen = false;					
			}
			else {
				editRichText.fileDialog.isFullScreen = true;
			}
			editRichText.fileDialog.canSelectFileType = false;
			editRichText.fileDialog.isForViewing = false;
			editRichText.fileDialog.setScaleValues();
			Rectangle newBoundsOfEditText = new Rectangle(editRichText.bounds);
			editRichText.fileDialog.changeBounds(newBoundsOfEditText);
			
			editRichText.fileDialog.createAndSetFileListButtons(editRichText.fileDialog.getCurDir(true),
					FileDialog.Category.Image);
			//fileDialog.setOnTouchListener(editRichText);
			editRichText.fileDialog.setIsForReadingOrSaving(1);
			editRichText.fileDialog.open(editRichText, "FileExplorer - Load");
			
		}
		else if (buttonName.equals("FN")) {
			Edit.createMenuFunction(true);
			Edit.menuFunction.open(editRichText, true);
		}
		else if (buttonName.equals("R/W")) {
			if (editRichText.toolbar.buttons[7].getIsSelected()) {
				editRichText.isReadOnly = true;
			}
			else {
				editRichText.isReadOnly = false;
			}
		}
		//bound(BoundMode.ScrollMode, false);
	}
	
	public static void typefaceMenu_Listener(EditRichText editRichText, Object sender, String strTypeface) {
		editRichText.typefaceName = strTypeface;
		
		editRichText.menuTypeface.open(false);
		if (editRichText.isSelecting) {
			int k, j;
			boolean isBold, isItalic;
			for (k=0; k<editRichText.selectIndicesCount; k+=2) {
				int start = editRichText.selectIndices[k].x;
				int end = editRichText.selectIndices[k+1].x;
				int count = editRichText.textArray[editRichText.selectIndices[k].y].count;
				for (j=start; j<=end && j<count; j++) {					
					//Typeface typeface;
					isBold = editRichText.textArray[editRichText.selectIndices[k].y].characters[j].isBold;
					isItalic = editRichText.textArray[editRichText.selectIndices[k].y].characters[j].isItalic;
					
					FontFamily family = Font.fromString(editRichText.typefaceName);
					if (isBold && isItalic)
						editRichText.typeface = Font.getTypeface(family, true, true);
					else if (isBold)
						editRichText.typeface = Font.getTypeface(family, true, false);
					else if (isItalic)
						editRichText.typeface = Font.getTypeface(family, false, true);
					else
						editRichText.typeface = Font.getTypeface(family, false, false);
					/*if (isBold) typeface = Font.getTypeface(null, true, false);
					else typeface = Font.getTypeface(null, false, false);*/
					editRichText.textArray[editRichText.selectIndices[k].y].characters[j].typeface = 
							editRichText.typeface;
					editRichText.textArray[editRichText.selectIndices[k].y].characters[j].typefaceName = 
							editRichText.typefaceName;
					
				}
			}
			editRichText.realign();
		}
	}
	
	public static void colorDialog_Listener(EditRichText editRichText, Object sender, int color) {
		if (!editRichText.isSelecting) {
			//fontSize = Float.parseFloat(strFontSize);
			//int toolbarButtonIndex = toolbar.findIndex("S");
			//toolbar.buttons[toolbarButtonIndex].setText(""+fontSize);
			editRichText.curColor = color;
			//toolbar.buttons[2].backColor = curColor;
			editRichText.toolbar.buttons[2].setBackColor(editRichText.curColor);
		}
		else {
			int k, j;
			//fontSize = Float.parseFloat(strFontSize);
			//int toolbarButtonIndex = toolbar.findIndex("S");
			//toolbar.buttons[toolbarButtonIndex].setText(""+fontSize);
			editRichText.curColor = color;
			//toolbar.buttons[2].backColor = curColor;
			editRichText.toolbar.buttons[2].setBackColor(editRichText.curColor);
			for (k=0; k<editRichText.selectIndicesCount; k+=2) {
				int start = editRichText.selectIndices[k].x;
				int end = editRichText.selectIndices[k+1].x;
				int count = editRichText.textArray[editRichText.selectIndices[k].y].count;
				for (j=start; j<=end && j<count; j++) {
					editRichText.textArray[editRichText.selectIndices[k].y].characters[j].setCharColor(editRichText.curColor);
				}
			}
			// 폰트, 폰트크기 등이 바뀐 경우 다시 줄을 맞춘다. 
			editRichText.realign();
		}
	}
	
	public static void fontSizeMenu_Listener(EditRichText editRichText, Object sender, String strFontSize) {
				
		Edit.menuFontSize.open(null, false);
		if (strFontSize.equals(Edit.Menu_FontSize[Edit.Menu_FontSize.length-1])) {
			// 모든 EditText들이 FontSizeDialog을 공유하므로 changeBounds를 해준다.			
			Edit.createFontSizeDialog(true);
			Edit.fontSizeDialog.open(editRichText);
			//fontSizeDialog.setOnTouchListener(editRichText);
			return;
		}
		if (!editRichText.isSelecting) {
			int indexOfPercent = strFontSize.indexOf("%");
			if (indexOfPercent!=-1) {
				strFontSize = strFontSize.substring(0, indexOfPercent);
			}
			strFontSize = strFontSize.substring(0, indexOfPercent);
			editRichText.fontSize = Float.parseFloat(strFontSize) * Control.view.getHeight() * 0.01f;
			
			//int toolbarButtonIndex = toolbar.findIndex("S");
			editRichText.toolbar.buttons[0].setText(""+editRichText.fontSize);
			if (editRichText.cursorPos.x<editRichText.textArray[editRichText.cursorPos.y].count) {
				if (editRichText.textArray[editRichText.cursorPos.y].characters[editRichText.cursorPos.x].bitmap==null) 
					editRichText.textArray[editRichText.cursorPos.y].characters[editRichText.cursorPos.x].size = editRichText.fontSize;
			}
			else {
				
			}
			// 폰트, 폰트크기 등이 바뀐 경우 다시 줄을 맞춘다. 
			editRichText.realign();
		}
		else {
			int k, j;
			
			int indexOfPercent = strFontSize.indexOf("%");
			if (indexOfPercent!=-1) {
				strFontSize = strFontSize.substring(0, indexOfPercent);
			}
			strFontSize = strFontSize.substring(0, indexOfPercent);
			editRichText.fontSize = Float.parseFloat(strFontSize) * Control.view.getHeight() * 0.01f;
			
			editRichText.toolbar.buttons[0].setText(""+editRichText.fontSize);
			for (k=0; k<editRichText.selectIndicesCount; k+=2) {
				int start = editRichText.selectIndices[k].x;
				int end = editRichText.selectIndices[k+1].x;
				int count = editRichText.textArray[editRichText.selectIndices[k].y].count;
				for (j=start; j<=end && j<count; j++) {
					if (editRichText.textArray[editRichText.selectIndices[k].y].characters[j].bitmap==null) 
						editRichText.textArray[editRichText.selectIndices[k].y].characters[j].size = editRichText.fontSize;						
				}
			}
			// 폰트, 폰트크기 등이 바뀐 경우 다시 줄을 맞춘다. 
			editRichText.realign();
		}
	}
	
	public static void fileDialog_Listener(EditRichText editRichText, Object sender, String filename) {		
		if (editRichText.fileDialog.category==FileDialog.Category.Image) {			
			Bitmap bitmap = null;
			FileInputStream stream=null;
			BufferedInputStream bis=null;
			boolean error = false;
			try {
				stream = new FileInputStream(editRichText.fileDialog.getCurDir(true)+filename);
				int bufferSize = (int) (FileHelper.getFileSize(editRichText.fileDialog.getCurDir(true)+filename)*IO.DefaultBufferSizeParam);
				bis = new BufferedInputStream(stream, bufferSize);
				bitmap = ContentManager.LoadBitmap(editRichText.context, bis);
			} catch (FileNotFoundException e1) {
				
				Log.e("Load Error", e1.toString());
				CommonGUI.loggingForMessageBox.setHides(false);
				CommonGUI.loggingForMessageBox.setText(true, Control.res.getString(R.string.load_error_file_not_found), false);
				error = true;
			}
			catch (OutOfMemoryError e1) {
				Log.e("Load Error", e1.toString());
				CommonGUI.loggingForMessageBox.setHides(false);
				CommonGUI.loggingForMessageBox.setText(true, Control.res.getString(R.string.outof_memory_error), false);
				error = true;
			}
			catch (Exception e1) {
				
				Log.e("Load Error", e1.toString());
				CommonGUI.loggingForMessageBox.setHides(false);
				CommonGUI.loggingForMessageBox.setText(true, Control.res.getString(R.string.load_error), false);
				e1.printStackTrace();
				CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e1);
				error = true;
			}
			finally {
				FileHelper.close(bis);
				FileHelper.close(stream);
				if (error) return;
			}
			
			Character charA = new Character(bitmap, editRichText.fileDialog.filename);
			Character[] chars = {charA};
			
			try {		 
				editRichText.textArray[editRichText.cursorPos.y].resize(editRichText.textArray[editRichText.cursorPos.y].count+1);
			TextLine charATextLine = (new TextLine(chars,chars.length));
			
			Character[] src = charATextLine.characters;
			editRichText.textArray[editRichText.cursorPos.y].insert(src, 0, editRichText.cursorPos.x, chars.length);
			//textArray[cursorPos.y].setLineHeight(30);
			}catch(Exception e) {
				e.printStackTrace();
				CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
			}
			
			TextLine newText=null;
			newText = editRichText.TextArrayToText(editRichText.cursorPos.y, editRichText.cursorPos.x, 1);
			editRichText.setTextMultiLine(editRichText.cursorPos.y, newText, -1, 1);
		}
	}
	
	
	/** EditRichText의 이벤트 리스너, 이후에 draw가 호출된다*/
	public static void editRichText_Listener(EditRichText editRichText, Object sender, MotionEvent e) {
		// scrollMode가 VScroll인지 Both인지는 상관이 없다. 
		// getCursorPos에서 처리하기 때문이다.
		if (e.actionCode==MotionEvent.ActionDown) {
			// 기존 선택한 텍스트 위치를 backup한다.
			if (editRichText.isSelecting) {
				editRichText.selectStartLine = editRichText.selectIndices[0].y;
				editRichText.selectEndLine = editRichText.selectIndices[editRichText.selectIndicesCount-2].y;
			}
			
			editRichText.cursorPos = editRichText.getCharPos(e);
			editRichText.setToolbarAndCurState(editRichText.cursorPos);
			editRichText.isSelecting = false;
			editRichText.isFound = false;
			editRichText.selectLenY = 0;
			editRichText.selectP1 = new Point(editRichText.cursorPos.x, editRichText.cursorPos.y);
			editRichText.selectIndicesCount = 0; 
		}
		
		try {
		// 0 line   : start, end -> (startX, 0), (endX, 선택영역의 첫번째(0))
		// 1-Y line : start, end -> (startX, 1-Y), (endX, 선택영역의 중간(1))
		// Y line   : start, end -> (startX, Y), (endX, 선택영역의 마지막(2))
		if (e.actionCode==MotionEvent.ActionMove || e.actionCode==MotionEvent.ActionUp) {
			if (e.actionCode==MotionEvent.ActionUp) {
			}
			Point charPos = editRichText.getCharPos(e);
			if (editRichText.isSelecting) { // 자동 스크롤 한다.				
				// scrollMode에 상관없이 자동 스크롤 한다.
				if (e.y>editRichText.bounds.bottom()/*-hScrollBarHeight*/) {
					if (editRichText.heightOfLines>editRichText.heightOfLinesPerPage) {
						editRichText.setHeightOfVScrollPos(editRichText.heightOfvScrollInc);						
						editRichText.setVScrollBar(true);
						Point r = charPos;
						editRichText.selectP2 = new Point(r.x,r.y);					
						makeSelectIndices(editRichText, true, editRichText.selectP1, editRichText.selectP2);
						return;
					}							
				}
				else if (e.y<editRichText.bounds.y){
					if (editRichText.heightOfLines>editRichText.heightOfLinesPerPage) {
						editRichText.setHeightOfVScrollPos(-editRichText.heightOfvScrollInc);
						editRichText.setVScrollBar(true);
						Point r = charPos;
						editRichText.selectP2 = new Point(r.x,r.y);					
						makeSelectIndices(editRichText, true, editRichText.selectP1, editRichText.selectP2);
						return;
					}
				}
				
				if (editRichText.scrollMode==ScrollMode.Both) {
					if (e.x>editRichText.bounds.right()-editRichText.vScrollBarWidth) {
						float widthOfCurLine = editRichText.paint.measureText(editRichText.textArray[charPos.y]);
						if (widthOfCurLine>editRichText.widthOfCharsPerPage) {
							editRichText.setWidthOfHScrollPos(editRichText.widthOfhScrollInc);
							editRichText.setHScrollBar(true);
							Point r = charPos;
							editRichText.selectP2 = new Point(r.x,r.y);					
							makeSelectIndices(editRichText, true, editRichText.selectP1, editRichText.selectP2);
							return;
						}							
					}
					else if (e.x<editRichText.bounds.x){
						float widthOfCurLine = editRichText.paint.measureText(editRichText.textArray[charPos.y]);
						if (widthOfCurLine>editRichText.widthOfCharsPerPage) {
							editRichText.setWidthOfHScrollPos(-editRichText.widthOfhScrollInc);
							editRichText.setHScrollBar(true);
							Point r = charPos;
							editRichText.selectP2 = new Point(r.x,r.y);					
							makeSelectIndices(editRichText, true, editRichText.selectP1, editRichText.selectP2);
							return;
						}
					}
				}
			}	// if (isSelecting==true)
			Point r = charPos;
			if (e.actionCode==MotionEvent.ActionMove) {
				editRichText.isSelecting = true;
			}
			editRichText.selectP2 = new Point(r.x,r.y);
			// 적어도 한 문자를 선택해야 선택표시를 그린다.
			if (editRichText.selectP1.x==editRichText.selectP2.x && editRichText.selectP1.y==editRichText.selectP2.y) return;
			
			makeSelectIndices(editRichText, true, editRichText.selectP1, editRichText.selectP2);
			
		} // if (e.actionCode==MotionEvent.ActionMove)
		
		
		}catch(Exception e1) {
			e1.printStackTrace();
			CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e1);
			return;
		}
		finally {
			// 터치시 한글모드와 버퍼를 초기화	
			Hangul.mode = Hangul.Mode.None;
			Hangul.resetBuffer();
		}
	}
	
	public static void findReplaceDialog_Listener(EditRichText editRichText, Object sender, MotionEvent e) {
		FindReplaceDialog dialog = (FindReplaceDialog)sender;
		if (dialog.recentCommand.equals("Find")) {
			boolean isForward = dialog.buttonDirection.text.equals("Forward") ? true : false;
			boolean isScopeAll = dialog.buttonScope.text.equals("All") ? true : false;
			boolean isCaseSensitive = dialog.buttonCaseSensitive.getIsSelected();
			boolean isWholeWord = dialog.buttonWholeWord.getIsSelected();
			//curFindPos.x = editRichText.cursorPos.x; 
			//curFindPos.y = editRichText.cursorPos.y; 
			editRichText.findReplace.find(false, isForward, isScopeAll, isCaseSensitive, isWholeWord, 
					editRichText.cursorPos, dialog.editTextFind.getText().str, true);
			
		}
		else if (dialog.recentCommand.equals("Replace-Find")) {
			boolean isForward = dialog.buttonDirection.text.equals("Forward") ? true : false;
			boolean isScopeAll = dialog.buttonScope.text.equals("All") ? true : false;
			boolean isCaseSensitive = dialog.buttonCaseSensitive.getIsSelected();
			boolean isWholeWord = dialog.buttonWholeWord.getIsSelected();
			//curFindPos.x = editRichText.cursorPos.x; 
			//curFindPos.y = editRichText.cursorPos.y; 
			editRichText.findReplace.replace(false, isForward, isScopeAll, isCaseSensitive, isWholeWord, editRichText.cursorPos, 
				dialog.editTextFind.getText().str, dialog.editTextReplaceWith.getText().str);
		}
		else if (dialog.recentCommand.equals("ReplaceAll")) {
			// ReplaceAll은 scrollMode가 Both일 때만 동작한다.
			if (editRichText.scrollMode==ScrollMode.VScroll) {
				CommonGUI.loggingForMessageBox.setHides(false);
				CommonGUI.loggingForMessageBox.setText(true, "ReplaceAll operates only in Both scrollMode.", false);
				return;
			}
			
			boolean isForward = dialog.buttonDirection.text.equals("Forward") ? true : false;
			boolean isScopeAll = dialog.buttonScope.text.equals("All") ? true : false;
			boolean isCaseSensitive = dialog.buttonCaseSensitive.getIsSelected();
			boolean isWholeWord = dialog.buttonWholeWord.getIsSelected();
			if (isScopeAll) {
				editRichText.cursorPos.x = 0;
				editRichText.cursorPos.y = 0;
			}
			else {
				if (!editRichText.isSelecting) return;
				if (editRichText.selectP1.y == editRichText.selectP2.y) {
					if (editRichText.selectP1.x < editRichText.selectP2.x) {
						editRichText.cursorPos.x = editRichText.selectP1.x;
						editRichText.cursorPos.y = editRichText.selectP1.y;
					}
					else {
						editRichText.cursorPos.x = editRichText.selectP2.x;
						editRichText.cursorPos.y = editRichText.selectP2.y;
					}
				}
				else {
					if (editRichText.selectP1.y < editRichText.selectP2.y) {
						editRichText.cursorPos.x = editRichText.selectP1.x;
						editRichText.cursorPos.y = editRichText.selectP1.y;
					}
					else {
						editRichText.cursorPos.x = editRichText.selectP2.x;
						editRichText.cursorPos.y = editRichText.selectP2.y;
					}
				}
			}
			//curFindPos.x = editRichText.cursorPos.x; 
			//curFindPos.y = editRichText.cursorPos.y; 
			editRichText.findReplace.replace(true, isForward, isScopeAll, isCaseSensitive, isWholeWord, editRichText.cursorPos, 
				dialog.editTextFind.getText().str, dialog.editTextReplaceWith.getText().str);
		}
		else if (dialog.recentCommand.equals("Close")) {
			//curFindPos.x = 0;
			//curFindPos.y = 0;
		}
	}
	
	public static void integrationKeyboard_Listener(EditRichText editRichText, Object sender, MotionEvent e) {
		IntegrationKeyboard keyboard = (IntegrationKeyboard)sender;
		
		// 키보드 가속기는 isReadOnly가 true이더라도 실행이 된다.
		if (IntegrationKeyboard.isCtrlPressed) {
			if (keyboard.key.equals("Z")) {
				UndoOfEditRichText.undo(editRichText);
				return;
			}
			else if (keyboard.key.equals("Y")) {
				RedoOfEditRichText.redo(editRichText);
				return;
			}
			else if (keyboard.key.equals("F")) {
				openFindReplaceDialog(editRichText);
				return;
			}
			else if (keyboard.key.equals("C")) {
				copy(editRichText);
				return;
			}
			else if (keyboard.key.equals("X")) {
				cut(editRichText);
				return;
			}
			else if (keyboard.key.equals("V")) {
				paste(editRichText);
				return;
			}
			else if (keyboard.key.equals("A")) {
				selectAll(editRichText);
				return;
			}
			
		}//키보드 가속기
		
		if (editRichText.isReadOnly) return;
		
		
		
		editRichText.keyboardMode = keyboard.mode;
		editRichText.hangulMode = Hangul.mode;
		
		if (keyboard.mode!=Mode.Hangul) {
			try {
				editRichText.addChar(keyboard.key/*, false*/);
			}catch(Exception e1) {
				e1.printStackTrace();
				CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e1);
			}
		}
		else {
			if (Hangul.isBkSpPressed) {
				editRichText.replaceChar(keyboard.key);
				return;
			}
			
			
			
			if (Hangul.mode==Hangul.Mode.None) {
				// space, delete, enter 키는 Hangul.mode가 None이다.
				// 그리고 isNextToCursor는 true로 설정되어 커서다음위치에 
				// key가 추가된다.
				editRichText.addChar(keyboard.key/*, false*/);
			}						
			else if (Hangul.mode==Hangul.Mode.ChoSung ||
					Hangul.mode==Hangul.Mode.JungSung) {				
				editRichText.addChar(keyboard.key/*, false*/);
			}
			else {
				try {
					editRichText.replaceChar(keyboard.key);
				}catch(Exception e1) {
					e1.printStackTrace();
					CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e1);
				}
			}
			
		} // keyboard.mode==Mode.Hangul
		//Hangul.isNextToCursor = false;
	}
	
	
	
	public static void createFontSizeDialog(EditRichText editRichText, View view) {
		int w = (int) (editRichText.bounds.width*0.7f);
		int h = (int) (editRichText.bounds.height*0.4f);
		int x = editRichText.bounds.x + editRichText.bounds.width/2 - w/2;
		int y = editRichText.bounds.y + editRichText.bounds.height/2 - h/2;
		Rectangle bounds = new Rectangle(x,y,w,h);
		editRichText.fontSizeDialog = new FontSizeDialog(view, bounds);		
	}
	
	
	
	public static void createToolbar(EditRichText editRichText, Rectangle bounds) {
		editRichText.toolbar = new MenuWithAlwaysOpen("menu", bounds, MenuType.Vertical, editRichText.owner, 
				EditRichText.namesOfButtonsOfToolbar, new Size(2,2), false, editRichText, false);
		editRichText.toolbar.buttons[3].selectable = true;	// Bold키는 토글로 동작한다.
		editRichText.toolbar.buttons[3].toggleable = true;
		editRichText.toolbar.buttons[3].ColorSelected = Color.YELLOW;
		editRichText.toolbar.buttons[4].selectable = true;	// Underline키는 토글로 동작한다.
		editRichText.toolbar.buttons[4].toggleable = true;
		editRichText.toolbar.buttons[4].ColorSelected = Color.YELLOW;
		editRichText.toolbar.buttons[5].selectable = true;	// Italic키는 토글로 동작한다.
		editRichText.toolbar.buttons[5].toggleable = true;
		editRichText.toolbar.buttons[5].ColorSelected = Color.YELLOW;
		editRichText.toolbar.buttons[7].selectable = true;	// R/W는 토글로 동작한다.
		editRichText.toolbar.buttons[7].toggleable = true;
		editRichText.toolbar.buttons[7].ColorSelected = Color.YELLOW;
		editRichText.toolbar.open(true, false);
	}
	
	public static void createMenuFunction(EditRichText editRichText) {
		if (Edit.menuFunction!=null) return;
		int viewWidth = Control.view.getWidth();
		int viewHeight = Control.view.getHeight();
		int x, y;
		int width=(int) (viewWidth*0.4f);
		int height=(int) (viewHeight*0.7f);
		x = viewWidth/2-width/2;
		y = viewHeight/2-height/2;
		Rectangle boundsMenuFunction = new Rectangle(x,y,width,height);  
		Edit.menuFunction = new MenuWithClosable("menuFunction", boundsMenuFunction, 
				MenuType.Vertical, editRichText.owner, Edit.Menu_Function, new Size(3,3), true, editRichText);		
	}
	
	public static void createMenuFontSize(EditRichText editRichText) {
		if (Edit.menuFontSize!=null) return;
		int viewWidth = Control.view.getWidth();
		int viewHeight = Control.view.getHeight();
		int x, y;
		int width=(int) (viewWidth*0.4f);
		int height=(int) (viewHeight*0.7f);
		x = viewWidth/2-width/2;
		y = viewHeight/2-height/2;
		Rectangle boundsMenuFontSize = new Rectangle(x,y,width,height);  
		Edit.menuFontSize = new MenuWithClosable("MenuFontSize", boundsMenuFontSize, 
				MenuType.Vertical, editRichText.owner, Edit.Menu_FontSize, new Size(3,3), true, editRichText);		
	}
	
		
	public static void createMenuTypeface(EditRichText editRichText, boolean changeBounds) {
		int viewWidth = Control.view.getWidth();
		int viewHeight = Control.view.getHeight();
		int x, y;
		int width=(int) (viewWidth*0.5f);
		int height=(int) (viewHeight*0.3f);
		x = viewWidth/2-width/2;
		y = viewHeight/2-height/2;
		Rectangle boundsMenuTypeface = new Rectangle(x,y,width,height);
		if (!changeBounds) {
			editRichText.menuTypeface = new MenuWithClosable("MenuTypeface", boundsMenuTypeface, 
				MenuType.Vertical, editRichText.owner, EditRichText.Menu_Typeface, new Size(3,3), true, editRichText);
		}
		else {
			editRichText.menuTypeface.changeBounds(boundsMenuTypeface);
		}
	}
	
	/*void createFileDialog() {
		float w = editRichText.bounds.width;
		float h = editRichText.bounds.height;
		float x = editRichText.bounds.x + editRichText.bounds.width/2 - w/2;
		float y = editRichText.bounds.y + editRichText.bounds.height/2 - h/2;
		RectangleF boundsOfFileDialog = new RectangleF(x, y, w, h);
		fileDialog = new FileDialog(false, false, editRichText, boundsOfFileDialog, null,
				keyboard);		
	}*/
	
	/** undo, redo buffer*/
	public static void createTextView(EditRichText editRichText, boolean changeBounds) {
		int viewWidth = Control.view.getWidth(); 
		int viewHeight = Control.view.getHeight();
		int x, y, w, h;
		
		w = (int) (viewWidth * 0.85f);
		h = (int) (viewHeight * 0.75f);
		x = viewWidth/2 - w/2;
		y = viewHeight/2 - h/2;
		Rectangle boundsOfTextView = new Rectangle(x,y,w,h);
		if (!changeBounds) {
			editRichText.textView = new TextView(false, false, editRichText, "undo_redo buffer of EditRichText", boundsOfTextView, 
					Control.view.getHeight()*0.02f, false, null, ScrollMode.VScroll, Common_Settings.backColor);
			editRichText.textView.isReadOnly = true;
		}
		else {
			if (editRichText.textView!=null) {
				editRichText.textView.changeBounds(boundsOfTextView);
			}
		}
	}
	
	static Point[] toPointArray(Object[] arrObj) {
		int i;
		Point[] r = new Point[arrObj.length];
		for (i=0; i<r.length; i++) {
			r[i] = (Point) arrObj[i];
		}
		return r;
	}
	
	static TextLine[] toTextLineArray(Object[] arrObj) {
		int i;
		TextLine[] r = new TextLine[arrObj.length];
		for (i=0; i<r.length; i++) {
			r[i] = (TextLine) arrObj[i];
		}
		return r;
	}
	
	
	/** 스크롤 윈도우와 선택영역의 교집합을 구한다.*/
	static Point[] getIntersectWithSelect(EditRichText editRichText, boolean isSelectingOrFinding) {
		try{
		if (isSelectingOrFinding) {
			Point[] r = new Point[100];
			int count=0;
			if (editRichText.scrollMode==ScrollMode.VScroll) {			
				int i;
				for (i=0; i<editRichText.selectIndicesCount; i+=2) {
					if (editRichText.vScrollPos<=editRichText.selectIndices[i].y && 
							editRichText.selectIndices[i].y<editRichText.vScrollPos+editRichText.numOfLinesPerPage) {
						if (!(count<=r.length-2)) r = toPointArray( Array.Resize(r, r.length+20) );
						r[count++] = editRichText.selectIndices[i];
						r[count++] = editRichText.selectIndices[i+1];
					}				
				}
				r = toPointArray( Array.Resize(r, count) );
				return r;
			}
			else {
				int i;
				for (i=0; i<editRichText.selectIndicesCount; i+=2) {
					if (editRichText.vScrollPos<=editRichText.selectIndices[i].y && 
							editRichText.selectIndices[i].y<editRichText.vScrollPos+editRichText.numOfLinesPerPage) {
						if (!(count<=r.length-2)) {
							r = toPointArray( Array.Resize(r, r.length+20) );
						}
						r[count++] = editRichText.selectIndices[i];
						r[count++] = editRichText.selectIndices[i+1];
					}				
				}
				Point[] newR = new Point[100];
				int newCount=0;
				for (i=0; i<count; i+=2) {
					//TextLine text = textArray[r[i].y].subTextLine(
					//		r[i].x, r[i+1].x+1); 
					PartOfStr str =	editRichText.getStringHScroll(editRichText.textArray[r[i].y]);				
					if (str.str.count==0) {
						// 선택영역의 첫번째와 중간라인들은 수평스크롤 영역을 벗어나더라도
						// 선택영역이 그려질 수 있도록 한다.
						if ((editRichText.selectLenY>1 && r[i+1].y==EditRichText.Select_FirstLine) ||
							(editRichText.selectLenY>1 && r[i+1].y==EditRichText.Select_MiddleLine)) {
							if (!(newCount<=newR.length-2)) {
								newR = toPointArray( Array.Resize(newR, newR.length+20) );
							}
							newR[newCount++] = new Point(r[i].x,r[i].y);
							newR[newCount++] = new Point(r[i+1].x,r[i+1].y);
						}					
					}
					else {
						// 선택영역과 수평스크롤 영역의 교집합을 구한다.
						Point originP = new Point(r[i].x,r[i+1].x);
						Point newP = new Point(str.start, str.end);					
						Point intersectPoint = getIntersect(originP,newP);
						if (intersectPoint!=null) {
							if (!(newCount<=newR.length-2)) {
								newR = toPointArray( Array.Resize(newR, newR.length+20) );
							}
							newR[newCount++] = new Point(intersectPoint.x,r[i].y);
							newR[newCount++] = new Point(intersectPoint.y,r[i+1].y);
						}
					}
				}
				newR = toPointArray( Array.Resize(newR, newCount) );
				return newR;
			}
		}
		else {
			Point[] r = new Point[100];
			int count=0;
			if (editRichText.scrollMode==ScrollMode.VScroll) {			
				int i;
				for (i=0; i<editRichText.findIndicesCount; i+=2) {
					if (editRichText.vScrollPos<=editRichText.findIndices[i].y && 
							editRichText.findIndices[i].y<editRichText.vScrollPos+editRichText.numOfLinesPerPage) {
						if (!(count<=r.length-2)) r = toPointArray( Array.Resize(r, r.length+20) );
						r[count++] = editRichText.findIndices[i];
						r[count++] = editRichText.findIndices[i+1];
					}				
				}
				r = toPointArray( Array.Resize(r, count) );
				return r;
			}
			else {
				int i;
				for (i=0; i<editRichText.findIndicesCount; i+=2) {
					if (editRichText.vScrollPos<=editRichText.findIndices[i].y && 
							editRichText.findIndices[i].y<editRichText.vScrollPos+editRichText.numOfLinesPerPage) {
						if (!(count<=r.length-2)) {
							r = toPointArray( Array.Resize(r, r.length+20) );
						}
						r[count++] = editRichText.findIndices[i];
						r[count++] = editRichText.findIndices[i+1];
					}				
				}
				Point[] newR = new Point[100];
				int newCount=0;
				for (i=0; i<count; i+=2) {
					//TextLine text = textArray[r[i].y].subTextLine(
					//		r[i].x, r[i+1].x+1); 
					PartOfStr str =	editRichText.getStringHScroll(editRichText.textArray[r[i].y]);				
					if (str.str.count==0) {
						// 선택영역의 첫번째와 중간라인들은 수평스크롤 영역을 벗어나더라도
						// 선택영역이 그려질 수 있도록 한다.
						if ((editRichText.findLenY>1 && r[i+1].y==EditRichText.Select_FirstLine) ||
							(editRichText.findLenY>1 && r[i+1].y==EditRichText.Select_MiddleLine)) {
							if (!(newCount<=newR.length-2)) {
								newR = toPointArray( Array.Resize(newR, newR.length+20) );
							}
							newR[newCount++] = new Point(r[i].x,r[i].y);
							newR[newCount++] = new Point(r[i+1].x,r[i+1].y);
						}					
					}
					else {
						// 선택영역과 수평스크롤 영역의 교집합을 구한다.
						Point originP = new Point(r[i].x,r[i+1].x);
						Point newP = new Point(str.start, str.end);					
						Point intersectPoint = getIntersect(originP,newP);
						if (intersectPoint!=null) {
							if (!(newCount<=newR.length-2)) {
								newR = toPointArray( Array.Resize(newR, newR.length+20) );
							}
							newR[newCount++] = new Point(intersectPoint.x,r[i].y);
							newR[newCount++] = new Point(intersectPoint.y,r[i+1].y);
						}
					}
				}
				newR = toPointArray( Array.Resize(newR, newCount) );
				return newR;
			}
		}
		}catch(Exception e) {
			e.printStackTrace();
			CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
			return null;
		}
	}
	
	/** 교집합 구하기. 
	 * originP:현재줄에서 선택영역의 시작과 끝 x, newP:현재줄에서 수평스크롤 영역의 시작과 끝 x*/
	static Point getIntersect(Point originP, Point newP) {
		if (newP.y<originP.x) // ---  ____	 ---:newP, ___:originP
			return null;
		else if (newP.x<originP.x && newP.y<originP.y) // --__--___ 
			return new Point(originP.x,newP.y); 
		else if (newP.x>=originP.x && newP.y<=originP.y) // _-_-_
			return new Point(newP.x,newP.y);
		else if (newP.x>=originP.x && newP.y>originP.y)  // __--__--__--
			return new Point(newP.x,originP.y);
		else if (newP.x>originP.y)	// _____   -----
			return null;
		
		if (originP.y<newP.x) // ---  ____		---:originP, ___:newP
			return null;
		else if (originP.x<newP.x && originP.y<newP.y) // --__--___ 
			return new Point(newP.x,originP.y); 
		else if (originP.x>=newP.x && originP.y<=newP.y) // _-_-_
			return new Point(originP.x,originP.y);
		else if (originP.x>=newP.x && originP.y>newP.y)  // __--__--__--
			return new Point(originP.x,newP.y);
		else if (originP.x>newP.y)	// _____   -----
			return null;
		
		return null;
		
	}
	
	
	static void showUndoBuffer(EditRichText editRichText) {
		CodeString message = new CodeString("<UndoBuffer Stack>\ncount   buffer(the contents to change) : command(Input key)\n(bottom)\n", 
				Common_Settings.keywordColor);
		int i;
		for (i=0; i<editRichText.undoBuffer.bufferCommand.count; i++) {	
			String buffer = new String(((TextLine)(editRichText.undoBuffer.buffer.getItem(i))).toCharArray());
			String command = editRichText.undoBuffer.bufferCommand.getItem(i);
			if (command.equals(Edit.NewLineChar)) command = "Enter";
			else if (command.equals(Edit.BackspaceChar)) command = "Backspace";
			else if (command.equals(Edit.DeleteChar)) command = "Delete";
			else if (command.equals("")) command = "Char key";
			
			CodeString line = new CodeString(Util.getLineOffset(i), 
					Common_Settings.varUseColor);
			
			if (command.equals("cut") || command.equals("paste")) {
				line = line.concate(new CodeString(buffer + " : " + command +"(Selected)\n", 
						Common_Settings.textColor));
			}
			else if (command.equals("Backspace") || command.equals("Enter") ||
					command.equals("Delete")) {
				boolean isSelecting = false;
				Object s = editRichText.undoBuffer.arrayIsSelecting.getItem(i);
				// s가 null이면 isSelecting은 false이다.
				if (s!=null) isSelecting = ((Boolean)s).booleanValue();
				if (!isSelecting) {
					line = line.concate(new CodeString(buffer + " : " + command +"\n", 
							Common_Settings.textColor));
				}
				else {
					Point selectP1 = (Point) editRichText.undoBuffer.arrayCursorPos.getItem(i);
					Point selectP2 = (Point) editRichText.undoBuffer.arrayAddedInfo.getItem(i);
					String select = "(" + selectP1.x + "," + selectP1.y + ")" + ", " + 
							"(" + selectP2.x + "," + selectP2.y + ")";
					line = line.concate(new CodeString(buffer + " : " + command + " (" + select + " selected)\n", 
							Common_Settings.textColor));
				}				
			}//else if (command.equals("Backspace") || command.equals("Enter") ||
			// command.equals("Delete")) {
			else {	// 일반적인 문자 key 입력	
				if (command.equals("replace") || command.equals("replaceAll")) {
					int indexOfSeparator = buffer.indexOf('-');
					if (indexOfSeparator!=-1) {
						String backupText = buffer.substring(0, indexOfSeparator);
						String replaceWith = buffer.substring(indexOfSeparator+1, buffer.length());
						line = line.concate(new CodeString(backupText + " : " + command +
								"("+backupText + " with " + replaceWith+")\n", 
								Common_Settings.textColor));
					}
				}
				else {
					line = line.concate(new CodeString(buffer + " : " + command +"\n", 
							Common_Settings.textColor));
				}
			}
			message = message.concate(line);
		}
		message = message.concate(new CodeString("(top)\n", Common_Settings.keywordColor));
		editRichText.textView.setText(0, message);
		editRichText.textView.setHides(false);
	}
	
	static void showRedoBuffer(EditRichText editRichText) {
		CodeString message = new CodeString("<RedoBuffer Stack>\ncount   buffer(the contents to change) : command(Input key)\n(bottom)\n", 
				Common_Settings.keywordColor);
		int i;
		for (i=0; i<editRichText.redoBuffer.bufferCommand.count; i++) {	
			String buffer = new String(((TextLine)(editRichText.redoBuffer.buffer.getItem(i))).toCharArray());
			String command = editRichText.redoBuffer.bufferCommand.getItem(i);
			if (command.equals(Edit.NewLineChar)) command = "Enter";
			else if (command.equals(Edit.BackspaceChar)) command = "Backspace";
			else if (command.equals(Edit.DeleteChar)) command = "Delete";
			else if (command.equals("")) command = "Char key";
			
			CodeString line = new CodeString(Util.getLineOffset(i), 
					Common_Settings.varUseColor);
			
			if (command.equals("cut") || command.equals("paste")) {
				line = line.concate(new CodeString(buffer + " : " + command +"(Selected)\n", 
						Common_Settings.textColor));
			}
			else if (command.equals("Backspace") || command.equals("Enter") ||
					command.equals("Delete")) {
				boolean isSelecting = false;
				Object s = editRichText.redoBuffer.arrayIsSelecting.getItem(i);
				// s가 null이면 isSelecting은 false이다.
				if (s!=null) isSelecting = ((Boolean)s).booleanValue();
				if (!isSelecting) {
					line = line.concate(new CodeString(buffer + " : " + command +"\n", 
							Common_Settings.textColor));
				}
				else {
					Point selectP1 = (Point) editRichText.redoBuffer.arrayCursorPos.getItem(i);
					Point selectP2 = (Point) editRichText.redoBuffer.arrayPointP2.getItem(i);
					String select = "(" + selectP1.x + "," + selectP1.y + ")" + ", " + 
							"(" + selectP2.x + "," + selectP2.y + ")";
					line = line.concate(new CodeString(buffer + " : " + command + " (" + select + " selected)\n", 
							Common_Settings.textColor));
				}				
			}//else if (command.equals("Backspace") || command.equals("Enter") ||
			// command.equals("Delete")) {
			else {	
				if (command.equals("replace") || command.equals("replaceAll")) {
					int indexOfSeparator = buffer.indexOf('-');
					if (indexOfSeparator!=-1) {
						String replaceWith = buffer.substring(0, indexOfSeparator);
						String backupText = buffer.substring(indexOfSeparator+1, buffer.length());
						line = line.concate(new CodeString(backupText + " : " + command +
								"("+ replaceWith + " with " + backupText+")\n", 
								Common_Settings.textColor));
					}
				}
				else {
					line = line.concate(new CodeString(buffer + " : " + command +"\n", 
							Common_Settings.textColor));
				}
			}
			message = message.concate(line);
		}
		message = message.concate(new CodeString("(top)\n", Common_Settings.keywordColor));
		editRichText.textView.setText(0, message);
		editRichText.textView.setHides(false);
	}
}
