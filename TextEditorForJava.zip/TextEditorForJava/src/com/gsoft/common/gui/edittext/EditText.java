package com.gsoft.common.gui.edittext;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Region;
import android.util.Log;

import com.gsoft.common.Code.CodeChar;
import com.gsoft.common.Code.CodeString;
import com.gsoft.common.Code.CodeStringType;
import com.gsoft.common.ColorEx;
import com.gsoft.common.CommonGUI;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.Events.MotionEvent;
import com.gsoft.common.IO;
import com.gsoft.common.IO_types.TextFormat;
import com.gsoft.common.PaintEx;
import com.gsoft.common.Sizing.Rectangle;
import com.gsoft.common.Sizing.RectangleF;
import com.gsoft.common.Sizing.Size;
import com.gsoft.common.Sizing.SizeF;
import com.gsoft.common.interfaces.OnTouchListener;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.Compiler_types.Language;
import com.gsoft.common.compiler.Compiler_types_Base.Error;
import com.gsoft.common.compiler.gui.CurPathText;
import com.gsoft.common.compiler.gui.MDITabList;
import com.gsoft.common.gui.Buttons.Button;
import com.gsoft.common.gui.Control;
import com.gsoft.common.gui.Control.Container;
import com.gsoft.common.gui.FindReplaceDialog;
import com.gsoft.common.gui.FontSizeDialog;
import com.gsoft.common.gui.IntegrationKeyboard;
import com.gsoft.common.gui.IntegrationKeyboard.Hangul;
import com.gsoft.common.gui.IntegrationKeyboard.Mode;
import com.gsoft.common.gui.MenuWithAlwaysOpen;
import com.gsoft.common.gui.ScrollBars;
import com.gsoft.common.gui.ScrollBars.HScrollBar;
import com.gsoft.common.gui.ScrollBars.VScrollBarLogical;
import com.gsoft.common.gui.SettingsDialog.Settings;
import com.gsoft.common.gui.TextView;
import com.gsoft.common.gui.edittext.Edit.ScrollMode;
import com.gsoft.common.util.Array;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListCodeChar;
import com.gsoft.common.util.HighArray;
import com.gsoft.common.util.HighArray_CodeChar;
import com.gsoft.common.util.HighArray_char;
import com.gsoft.common.util.Util.Math;

import com.gsoft.common.gui.edittext.UndoBufferOfEditText;
import com.gsoft.common.gui.edittext.RedoBufferOfEditText;
import com.gsoft.common.gui.edittext.FindReplaceOfEditText;
import com.gsoft.common.gui.edittext.FunctionOfEditText;
import com.gsoft.common.gui.edittext.Edit;
import com.gsoft.common.gui.edittext.UndoOfEditText;
import com.gsoft.common.gui.edittext.HelperOfEditText;


@SuppressWarnings("unused")
public class EditText extends Container implements OnTouchListener {
		
	public static String[] namesOfButtonsOfToolbar = {
		"S", "M", "FN", "O", "R/W", "U"	
	};
		
	public MenuWithAlwaysOpen toolbar;
	
	boolean hasToolbarAndMenuFontSize;
	
	
	
	public boolean isReadOnly;
	
	/** 한 줄만 쓰이면 true, 그렇지 않으면 false*/
	protected boolean isSingleLine = true;
	public void setIsSingleLine(boolean b) {
		this.isSingleLine = b;
		if (this.isSingleLine) {
			scrollMode = ScrollMode.Both;
			if (vScrollBar!=null) {
				//vScrollBar.hides = true;
				vScrollBar.setIsOpen(false);
			}
			if (hScrollBar!=null) {
				//hScrollBar.hides = true;
				hScrollBar.setIsOpen(false);
			}
			this.setShowsCurPath(false);
			this.showsMDITabList = false;
			this.hasToolbarAndMenuFontSize = false;
		}
	}
	public boolean getIsSingleLine() {
		return isSingleLine;
	}
	
	
	//CodeString text;
		
	public CodeString[] textArray;
	
	protected float lineHeight;
	public float fontSize;
	float curFontSize;
	protected float descent;
	int gapX;
	
	protected ScrollMode scrollMode;
	VScrollBarLogical vScrollBar;
	HScrollBar hScrollBar;
	
	int vScrollBarWidth;
	protected int vScrollPos;
	
	public int numOfLines;
	public int numOfLinesPerPage;
		
	int hScrollBarHeight;
	protected int widthOfhScrollPos;
	float maxLineWidth;
	int lineNumOfMaxWidth;
	protected int widthOfCharsPerPage = 1;
	protected int widthOfTotalChars;
	protected int widthOfhScrollInc;
	
	boolean isCursorSeen;
	int valueOfCursorRelativeToHScroll;
	float part1OfChar;
	float part2OfChar;
	
	int rationalBoundsWidth;
	int rationalBoundsHeight;
	
	public Point cursorPos;
	
	//int indexOfCursorInText = -1;	// 현재 입력 문자의 Text에서의 인덱스
	int numOfLinesInText;	// setTextVScroll로 수정되는 줄수, 즉 \n을 만날 때까지의 줄수
	
	//boolean isBkSpThatMakeNullStr = false;
	
	
	public boolean isSelecting;
		
	/** editText_Listener()를 참조한다.*/
	protected Point selectP1;
	protected Point selectP2;
	/**selectIndices 좌표 구성은 makeSelectIndices()를 참조한다. Point[]*/
	protected Point[] selectIndices = new Point[100];
	protected int selectLenY;
	protected int selectIndicesCount = 0;
	int selectIndicesCountForCopy;
	
	
	static final int Select_FirstLine = 0;
	static final int Select_MiddleLine = 1;	
	static final int Select_LastLine = 2;
	
	/** 이미 선택된 텍스트를 크기변환 등 변환 후에 다시 선택을 하기 위해 사용한다.*/
	//boolean makingSelectP1P2OutOfEvent;
	
	
	boolean isCopied;
	String copiedText = "";
	
	
	protected int findLenY;
	/**Point[]*/
	protected Point[] findIndices = new Point[100];
	protected int findIndicesCount = 0;
	int findIndicesCountForCopy;
	
	FindReplaceOfEditText findReplace = new FindReplaceOfEditText(this); 
	
	
	protected boolean isFound;
	Point pointFindStart = new Point(0, 0);
	Point pointFindEnd = new Point(0, 0);	
	Point findP1 = new Point(0,0);
	Point findP2 = new Point(0,0);
	ArrayList listFindPos = new ArrayList(100);
	Point oldCursorPos = new Point(0,0);
	
	protected Mode keyboardMode;
	protected IntegrationKeyboard.Hangul.Mode hangulMode;
	
	
	private boolean _isModified;
	
	public void setIsModified(boolean isModified) {
		if (isModified) {
			int a;
			a=0;
			a++;
		}
		this._isModified = isModified;
	}
	
	public boolean getIsModified() {
		return this._isModified;
	}
	
	
	
	protected UndoBufferOfEditText undoBuffer = new UndoBufferOfEditText();
	protected RedoBufferOfEditText redoBuffer = new RedoBufferOfEditText();
	
	
	// PaintEx를 Paint대신에 생성하여 measureText에서 \n을 0으로 계산한다.
	PaintEx paint = new PaintEx();
	protected Paint paintOfBorder = new Paint();
	
	Context context;
	Bitmap bitmapCursor;
	
	
	protected static final int MaxLineCount = 10;
	
	
	boolean isMoveActionCaptured_onlyEditText;
	
	
	public Rectangle totalBounds;


	/** 에디트텍스트가 툴바를 가지고있는 경우 사이즈가 바뀔 때 툴바의 위치도 
	 * 바뀌면 true, 그렇지 않으면 false.changeBounds참조
	 */
	boolean isDockingOfToolbarFlexiable;

	
	protected Language lang;

	private Rectangle boundsOfSizingBorder = new Rectangle();


	/**MenuWithScrollBar_EditText에서 사용한다.*/
	public boolean isSelected;



	protected TextView textViewLogBird = CommonGUI.textViewLogBird;

	/** undo, redo buffer에서 사용한다.*/
	protected TextView textView;
	
	private Rectangle maxBounds;

	/**자바를 로딩시 editText_compiler 상단에 있는 경로 바를 말한다. 
	 * true이면 보여주고(생성하고) false이면 보여주지 않는다(제거한다).*/
	private boolean showsCurPath;
	
	public void setShowsCurPath(boolean showsCurPath) {
		if (this.name.equals("EditText_Compiler")) {
			int a;
			a=0;
			a++;
		}
		this.showsCurPath = showsCurPath;
	}
	
	public boolean getShowsCurPath() {
		return this.showsCurPath;
	}
	
	public boolean showsMDITabList;

	private float scaleOfMDITabList = 0.045f;
	
	private float scaleOfEditTextCurPath = 0.045f;
	
	public Rectangle boundsOfEditTextCurPath;
	
	public Rectangle boundsOfMDITabList;

	public MDITabList mDITabList;

	/**MenuProblemList_EditText.getMenuListEditTexts()에서 사용한다*/
	public Object addedInfo;

	
	
	public void setBackColor(int backColor) {
		if (this.name.equals("CurPath")) {
			String strBackColor = ColorEx.toString(backColor);
			int a;
			a=0;
			a++;
		}
		super.setBackColor(backColor);
		//paintOfBorder.setColor(textColor);
		paintOfBorder.setColor(/*Common_Settings.keywordColor*/Color.LTGRAY);
		if (this.getShowsCurPath()) {
			CurPathText.editTextCurPath.setBackColor(backColor);
		}
				
	}
	
	
	public void write(OutputStream os, TextFormat format) throws IOException {
		String text = getText2();
		IO.writeString(os, text, format, false, true);
		this.setIsModified(false);
		
	}
	
	public static String Read(InputStream is, TextFormat format)  throws Exception {
		String text = IO.readString(is, format).getItems();
		return text;
	}
	
	/** Java 스트림을 사용하여 파일을 읽는다. undo와 redo버퍼를 리셋한다.*/
	public String read(InputStream is, TextFormat format) throws Exception
	{
		//isModified = true;
		undoBuffer.reset();
		redoBuffer.reset();
		return IO.readString(is, format).getItems();
	}
	
	
	/**hides가 false이고 editText의 현재상태가 최대화가 아니면 
	 * (키보드와 SizingBorder의 영역을 바꿔줌과 함께) 키보드를 자동으로 보여주고
	 * 현재상태가 최대화상태이면 키보드를 숨겨준다.
	 * hides가 true이면 SizingBorder를 숨긴다.*/
	public synchronized void setHides(boolean hides) {		
		super.setHides(hides);
		if (isReadOnly) return;
		if (!hides) {
			//Control.totalBoundsOfEditText = totalBounds;
			if (Common_Settings.settings.EnablesScreenKeyboard) {
				IntegrationKeyboard keyboard = CommonGUI.keyboard;
				CommonGUI.keyboard.setOnTouchListener(this);
				if (!isMaximized()) {
					//backUpBounds();
					changeBoundsOfKeyboardAndSizingBorder(bounds);
					CommonGUI.keyboard.setHides(false);
					//Control.isMaximized = false;
				}
				else {
					keyboard .setHides(true);
					//Control.isMaximized = true;
				}
			}
		}
		else {
			if (!Control.sizingBorder.getHides()) 
				Control.sizingBorder.setHides(true);
		}
		
	}
	
	public void changeFontSize(float fontSize) {
		FunctionOfEditText.changeFontSize(this, fontSize);
	}
	
	/** 보이는 상태에서 바운드가 바뀔때는 스택아래 컨트롤들을 복원했다가 
	 * 다시 숨겨지는 컨트롤들을 결정한다.
	 * 보이지 않는 상태에서는 바운드를 바꿀 수 없다.
	 * @param paramBounds : 툴바제외 영역
	 */
	public void changeBoundsSafe(Rectangle paramBounds) {
		changeBounds(paramBounds);
		//setHides(true);
		//setHides(false);
	}
	
	/** view에서 sizingBorder가 바뀔시 호출, 
	 * 이전 바운드와 새로운 바운드간의 차이가 있을 때만 바운드가 바뀐다.
	 * @param boundsOfEditText : 툴바제외 영역*/
	public void resize(Rectangle boundsOfEditText) {
		if (Control.requiresChangingBounds(bounds, boundsOfEditText)) {
			if (!isMaximized()) backUpBounds();
			boolean isSizingBorderHides = Control.sizingBorder.getHides();
			changeBoundsOfKeyboardAndSizingBorder(boundsOfEditText);
			changeBoundsSafe(boundsOfEditText);
			if (!isSizingBorderHides) Control.sizingBorder.setHides(false);
		}
	}
	
	public void changeBoundsOfKeyboardAndSizingBorder(Rectangle boundsOfEditText) {
		int viewHeight = Control.view.getOriginalHeight();
		int viewWidth = Control.view.getOriginalWidth();
		int heightOfGap = (int)(viewHeight * Control.vertScaleOfGap);
		int top = boundsOfEditText.bottom()+heightOfGap;
		Rectangle boundsOfIntegrationKeyboard = new Rectangle(0, top,
				(int)(viewWidth*Control.scaleOfKeyboardX), viewHeight-top);
		if (viewHeight-top<0) {
			boundsOfIntegrationKeyboard.height = (int)(viewHeight*Control.scaleOfKeyboardY);
		}
		
		IntegrationKeyboard keyboard = CommonGUI.keyboard;
		if (keyboard!=null) {
			if (Control.requiresChangingBounds(keyboard.bounds, boundsOfIntegrationKeyboard)) {
				keyboard.changeBounds(boundsOfIntegrationKeyboard);
				boundsOfSizingBorder.x = totalBounds.x;
				boundsOfSizingBorder.width = totalBounds.width;
				boundsOfSizingBorder.y = boundsOfEditText.bottom() + 1;
				boundsOfSizingBorder.height = keyboard.buttons[0].bounds.y - boundsOfSizingBorder.y;
				if (Control.sizingBorder!=null) Control.sizingBorder.bounds = boundsOfSizingBorder;
			}
		}
	}
	
	/**윈도우(뷰)의 크기가 바뀔 때마다 maxBounds를 설정해야 한다.*/
	public void setMaxBounds(Rectangle maxBounds) {
		this.maxBounds = maxBounds;
	}
	
	
	/**maxOrPrev이 true이면 키보드를 없애고 크게 만든다. maxOrPrev이 false이면 키보드를 보이고 editText를 작게 만든다.
	 * 화면을 처음 표시할 때 setMaxBounds()를 호출하지 않고 이 메서드를 호출하면 NullPointerException이 발생하고,
	 * 윈도우(뷰)의 크기가 바뀔때마다 setMaxBounds()를 호출하지 않고 이 메서드를 호출하면 잘못된 결과가 발생할 수 있다.*/
	public void setMaximized(boolean maxOrPrev) {
		if (maxOrPrev) {
			if (maxBounds==null) {
				return;
			}
			if (!isMaximized()) backUpBounds();
			
			changeBounds(maxBounds);
			
			if (CommonGUI.keyboard!=null) CommonGUI.keyboard.setIsOpen(false);
			this.isMaximized = true;
		}
	}
	
	/**maxOrPrev이 true이면 키보드를 없애고 크게 만든다. maxOrPrev이 false이면 키보드를 보이고 editText를 작게 만든다.
	 * 그리고 bounds로 maxBounds와 prevBounds를 설정한다.
	 * 이 메서드를 호출하지 않고 setMaximized(true)를 호출하면 
	 * maxBounds와 prevBounds가 설정이 안되어 있기 때문에 NullPointerException이 발생한다.*/
	public void setMaximized(boolean maxOrPrev, Rectangle bounds) {
		if (maxOrPrev) {			
			if (!isMaximized()) backUpBounds();
			
			
			if (!Control.sizingBorder.getHides()) 
				Control.sizingBorder.setHides(true);
			
			//changeBoundsSafe(bounds);
			this.maxBounds = bounds;
			changeBounds(bounds);
			 
			//setHides(false);
			
			IntegrationKeyboard keyboard = CommonGUI.keyboard;
			if (keyboard!=null) keyboard.setIsOpen(false);
			this.isMaximized = true;
		}
		else {
			//if (keyboard!=null) keyboard.setHides(false);
			//sizingBorder.setHides(true);
			this.isMaximized = false;
			
			Rectangle newBoundsOfEditText = bounds;
			changeBounds(newBoundsOfEditText);
			
			this.changeBoundsOfKeyboardAndSizingBorder(newBoundsOfEditText);
			IntegrationKeyboard keyboard = CommonGUI.keyboard;
			if (keyboard!=null) keyboard.setHides(false);
			
		}
	}
	
	protected void setDescentAndLineHeight(float fontSize) {
		this.descent = fontSize * 0.25f;
		this.lineHeight = this.fontSize + this.descent;
	}
	
	/**paramBounds:툴바를 포함한 bounds*/
	public EditText(boolean hasToolbarAndMenuFontSize, boolean isDockingOfToolbarFlexiable, Object owner, 
			String name, Rectangle paramBounds, float fontSize, 
			boolean isSingleLine, CodeString text, ScrollMode scrollMode, int backColor) {
		super();
		if (this.name!=null && this.name.equals("Directory")) {
			int a;
			a=0;
			a++;
		}
		this.owner = owner;
		this.name = name;
		this.backColor = backColor;
				
		
		setBackColor(backColor);
		
		this.curFontSize = fontSize;
		this.fontSize = fontSize;
		setDescentAndLineHeight(fontSize);
		
		this.bounds = new Rectangle(paramBounds);
		this.totalBounds = new Rectangle(paramBounds);	
		
		this.scrollMode = scrollMode;
		
		this.isSingleLine = isSingleLine;
		this.hasToolbarAndMenuFontSize = hasToolbarAndMenuFontSize;
		this.isDockingOfToolbarFlexiable = isDockingOfToolbarFlexiable;
		
		
		if (isSingleLine) {
			this.setIsSingleLine(true);
		}
		if (hasToolbarAndMenuFontSize) {
			Rectangle boundsOfToolbar;
			Size toolbarSize = FunctionOfEditText.getToolbarSize(paramBounds);
			boundsOfToolbar = new Rectangle(paramBounds.x, paramBounds.y, 
					toolbarSize.width, toolbarSize.height);
			FunctionOfEditText.createToolbar(this, boundsOfToolbar);
			
		}
		
		if (hasToolbarAndMenuFontSize && !isSingleLine) {
			Edit.createMenuFontSize(false);
			
			Edit.createFontSizeDialog(false);
			
			Edit.createMenuFunction(false);
			Edit.createFindReplaceDialog(false);
			
			FunctionOfEditText.createTextView(this, false);
		}

		this.gapX = (int) (Control.view.getOriginalWidth() * 0.02f);
		
		
		this.totalBounds.copyFrom(paramBounds);
		
				
		if (hasToolbarAndMenuFontSize) {			
			Rectangle boundsOfToolbar;
			boundsOfToolbar = toolbar.bounds;
			boundsOfToolbar.x = paramBounds.x;
			boundsOfToolbar.y = paramBounds.y;
			boundsOfToolbar.height = paramBounds.height;
						
			bounds.x = boundsOfToolbar.right();
			bounds.y = boundsOfToolbar.y;
			bounds.width = paramBounds.width - boundsOfToolbar.width;
			bounds.height = paramBounds.height;
		}
		else {
			bounds.copyFrom(paramBounds);
		}
		
		if (this.getShowsCurPath()) {	
			if (this.boundsOfEditTextCurPath==null) {
				this.boundsOfEditTextCurPath = new Rectangle();
				
				this.boundsOfEditTextCurPath.x = this.bounds.x;
				this.boundsOfEditTextCurPath.y = this.bounds.y;
				this.boundsOfEditTextCurPath.width = this.bounds.width;
				this.boundsOfEditTextCurPath.height = (int) (this.bounds.height * scaleOfEditTextCurPath);
			}
			
			this.bounds.height = this.bounds.height - boundsOfEditTextCurPath.height;
			this.bounds.y = this.bounds.y + boundsOfEditTextCurPath.height;			
		}
		
		
		this.numOfLines = 1;
		
		this.cursorPos = new Point(0,0);
		
		context = Control.view.getContext();
		
		textArray = new CodeString[MaxLineCount];
		int i;
		for (i=0; i<textArray.length; i++) {
			textArray[i] = new CodeString("", textColor);
		}
		
		
		paint.setTextSize(fontSize);
		paint.setStyle(Style.FILL);
		paintOfBorder.setStyle(Style.STROKE);
		if (backColor!=Color.BLACK) {
			paintOfBorder.setColor(ColorEx.darkerOrLighter(backColor, -100));
		}
		else {
			paintOfBorder.setColor(ColorEx.darkerOrLighter(backColor, 100));
		}
		
		
		bound(BoundMode.Create, true);
		setText(0, text);
		
		if (!isMaximized()) backUpBounds();
		
		if (Common_Settings.CurrentSystem.equals(Common_Settings.CurrentSystemIsJava) &&
    			Common_Settings.settings.isTripleBuffering)  {
			this.drawToImage(mCanvas);
		}
		
	}
	
	/** 스크롤부분과 관련된 여러 속성값들을 설정한다.*/	
	void boundAttributes(BoundMode boundMode) {
		if (scrollMode==ScrollMode.VScroll) {
			if (boundMode==BoundMode.Create) {
				this.vScrollBarWidth = ScrollBars.getScrollBarSize();
			}
			
			if (this.isSingleLine) {
				rationalBoundsWidth = (int) (bounds.width - 2*gapX);
				numOfLinesPerPage = 1;
			}
			else {
				rationalBoundsWidth = (int) (bounds.width - 2*gapX - vScrollBarWidth);
				rationalBoundsHeight = bounds.height;
				numOfLinesPerPage = (int)(bounds.height / lineHeight);
			}
		
		}		
		else if (scrollMode==ScrollMode.Both) {
			if (boundMode==BoundMode.Create) {
				this.vScrollBarWidth = ScrollBars.getScrollBarSize();
				this.hScrollBarHeight = ScrollBars.getScrollBarSize();
			}		
			
			widthOfhScrollInc = (int)fontSize;
			
			if (isSingleLine) {
				rationalBoundsWidth = (int) (bounds.width - 2*gapX);
				rationalBoundsHeight = bounds.height;
				numOfLinesPerPage = 1;
			}
			else {
				rationalBoundsWidth = (int) (bounds.width - 2*gapX - vScrollBarWidth);
				rationalBoundsHeight = bounds.height - hScrollBarHeight;
				numOfLinesPerPage = (int)(rationalBoundsHeight / lineHeight);
				if (numOfLinesPerPage<=0) numOfLinesPerPage = 1;
			}
			
			this.widthOfCharsPerPage = this.rationalBoundsWidth;
			
		}
	}
	
	enum BoundMode {
		Create,
		ChangeBounds,
		FontSize,
		ScrollMode, 
		SetText
	}
	
	
	/** EditText생성시, changeBounds(), 폰트 size변경시, 스크롤 Mode변경시 호출되므로 주의해야 한다.
	 * ScrollMode가  Both일 때 폰트크기변경, bounds크기 변경을 하면  setText와  cursor를 초기화할 필요가 없다.
	   ScrollMode가 VScroll일 때  bounds크기 변경을 하면  setText(세로로만 크기가 바뀌므로)와  cursor를 초기화할 필요가 없다.*/
	void bound(BoundMode boundMode, boolean initCursor) {
		if (this.name.equals("Directory")) {
			int a;
			a=0;
			a++;
		}
		if (Common_Settings.CurrentSystem.equals(Common_Settings.CurrentSystemIsJava) &&
    			Common_Settings.settings.isTripleBuffering) {
			// 이미지로 그리기
			try {
				if (this.bitmapForRendering!=null) {
					bitmapForRendering.recycle();
				}
			this.bitmapForRendering = 
					Bitmap.createBitmap(this.bounds.width, this.bounds.height, Common_Settings.settings.bufferedImageType);
			mCanvas = new Canvas(this.bitmapForRendering);
			}catch(Exception e) {
				if (Common_Settings.g_printsLog) e.printStackTrace();
			}
		}
		
		
		boundAttributes(boundMode);
		
		if (boundMode==BoundMode.Create || boundMode==BoundMode.FontSize) {
			if (isSingleLine) {
				if (scrollMode==ScrollMode.VScroll) {				
					fontSize = bounds.height * 0.45f;
					setDescentAndLineHeight(fontSize);
				}
				else {
					fontSize = bounds.height * 0.45f;
					setDescentAndLineHeight(fontSize);
				}
			}
			else {
				setDescentAndLineHeight(fontSize);
			}
		}
		
		if (initCursor) {
			vScrollPos = 0;
			widthOfhScrollPos = 0;
			cursorPos.x = 0;
			cursorPos.y = 0;
		}
		if (scrollMode==ScrollMode.VScroll) {
			
			Rectangle boundsOfVScrollBar = new Rectangle(bounds.x+bounds.width-vScrollBarWidth,
					bounds.y, vScrollBarWidth, this.rationalBoundsHeight);
			if (vScrollBar!=null) {
				vScrollBar.changeBounds(boundsOfVScrollBar);
			}
			else {
				vScrollBar = new VScrollBarLogical
							(this, context, boundsOfVScrollBar, 
							numOfLinesPerPage,
							/*numOfLinesInPage,*/
							numOfLines, vScrollPos, 1);			
					vScrollBar.setOnTouchListener(this);
			}
			//setVScrollPos();
			setVScrollBar();
		}		
		else if (scrollMode==ScrollMode.Both) {
			if (this instanceof TextView) {
			}
			else {
			}
			
			Rectangle boundsOfVScrollBar = new Rectangle(bounds.x+bounds.width-vScrollBarWidth,
					bounds.y, vScrollBarWidth, this.rationalBoundsHeight);
			if (vScrollBar!=null) {
				vScrollBar.changeBounds(boundsOfVScrollBar);
			}
			else {
				vScrollBar = new VScrollBarLogical
							(this, context, boundsOfVScrollBar, 
							numOfLinesPerPage,
							/*numOfLinesInPage,*/
							numOfLines, vScrollPos, 1);			
					vScrollBar.setOnTouchListener(this);
			}
			//setVScrollPos();
			setVScrollBar();
			
			Rectangle boundsOfHScrollBar = new Rectangle((int)(bounds.x+gapX), 
					bounds.y+bounds.height-hScrollBarHeight,
					this.rationalBoundsWidth, hScrollBarHeight);
			if (hScrollBar!=null) {
				hScrollBar.changeBounds(boundsOfHScrollBar);
			}
			else {
				hScrollBar = new HScrollBar(this, context, boundsOfHScrollBar);
				hScrollBar.setOnTouchListener(this);
			}
			try{
			//setHScrollPos();
			setHScrollBar();
			}catch(Exception e) {
			}
				
		}
		if (this.isSingleLine) {
			if (vScrollBar!=null) {
				//vScrollBar.hides = true;
				vScrollBar.setIsOpen(false);
			}
			if (hScrollBar!=null) {
				//hScrollBar.hides = true;
				hScrollBar.setIsOpen(false);
			}
			this.hasToolbarAndMenuFontSize = false;
			this.setShowsCurPath(false);
			this.showsMDITabList = false;
		}		
		 
		if (Common_Settings.CurrentSystem.equals(Common_Settings.CurrentSystemIsJava) &&
    			Common_Settings.settings.isTripleBuffering)  this.drawToImage(mCanvas);
	}
		
	
	/** editTextCurPath를 보여주거나 없앤다.
	 * editText의 바운드를 바꾼다.*/
	public void showsCurPath(boolean showsOrHides) {
		boolean showsCurPath_backup = this.getShowsCurPath();
		if (showsOrHides) this.setShowsCurPath(true);
		else this.setShowsCurPath(false);
		
		if (this.isSingleLine) {
			this.setShowsCurPath(false);
		}
		
		if (showsCurPath_backup!=this.getShowsCurPath()) {
			this.changeBounds(this.totalBounds);
		}
	}
	
	/** MDITabList를 보여주거나 없앤다.
	 * editText의 바운드를 바꾼다.*/
	public void showsMDITabList(boolean showsOrHides) {
		boolean showsMDITabList_backup = this.showsMDITabList;
		if (showsOrHides) this.showsMDITabList = true;
		else this.showsMDITabList = false;
		
		if (this.isSingleLine) {
			this.showsMDITabList = false;
		}
		
		if (showsMDITabList_backup!=this.showsMDITabList) {
			this.changeBounds(this.totalBounds);
		}
	}
	
	
	
	/**paramBounds:툴바를 포함한 전체 bounds*/
	public void changeBounds(Rectangle paramBounds) {
		if (this.name!=null && this.name.equals("EditText_Compiler")) {
			int a;
			a=0;
			a++;
		}
		
		// 바운드도 안 바뀌고 editTextCurPath를 보여주거나 없애는 상황이 아니면 리턴을 한다.
		//if (Control.equals(totalBounds, paramBounds) && !changedShowsCurPath)
		//	return;
		
		if (this.isSingleLine) {
			this.setShowsCurPath(false);
			this.showsMDITabList = false;
		}
		
		this.totalBounds.copyFrom(paramBounds);
				
		if (hasToolbarAndMenuFontSize) {
			
			Rectangle boundsOfToolbar;
			boundsOfToolbar = toolbar.bounds;
			boundsOfToolbar.x = paramBounds.x;
			boundsOfToolbar.y = paramBounds.y;
			boundsOfToolbar.height = paramBounds.height;
			toolbar.changeBounds(boundsOfToolbar);
						
			bounds.x = boundsOfToolbar.right();
			bounds.y = boundsOfToolbar.y;
			bounds.width = paramBounds.width - boundsOfToolbar.width;
			bounds.height = paramBounds.height;
		}
		else {
			bounds.copyFrom(paramBounds);
		}
		
		if (this.showsMDITabList) {	
			if (this.boundsOfMDITabList==null) {
				this.boundsOfMDITabList = new Rectangle();
				
				this.boundsOfMDITabList.x = this.bounds.x;
				this.boundsOfMDITabList.y = this.bounds.y;
				this.boundsOfMDITabList.width = this.bounds.width;
				this.boundsOfMDITabList.height = (int) (Control.view.getOriginalHeight() * scaleOfMDITabList);
			}
			else {
				this.boundsOfMDITabList.x = this.bounds.x;
				this.boundsOfMDITabList.y = this.bounds.y;
				this.boundsOfMDITabList.width = this.bounds.width;
			}
			
			this.bounds.height = this.bounds.height - boundsOfMDITabList.height;
			this.bounds.y = this.bounds.y + boundsOfMDITabList.height;			
		}
		
		
		
		if (this.getShowsCurPath()) {	
			if (this.boundsOfEditTextCurPath==null) {
				this.boundsOfEditTextCurPath = new Rectangle();
				
				this.boundsOfEditTextCurPath.x = this.bounds.x;
				this.boundsOfEditTextCurPath.y = this.bounds.y;
				this.boundsOfEditTextCurPath.width = this.bounds.width;
				this.boundsOfEditTextCurPath.height = (int) (Control.view.getOriginalHeight() * scaleOfEditTextCurPath);
			}
			else {
				this.boundsOfEditTextCurPath.x = this.bounds.x;
				this.boundsOfEditTextCurPath.y = this.bounds.y;
				this.boundsOfEditTextCurPath.width = this.bounds.width;
			}
			
			this.bounds.height = this.bounds.height - boundsOfEditTextCurPath.height;
			this.bounds.y = this.bounds.y + boundsOfEditTextCurPath.height;			
		}
	
		
		if (scrollMode==ScrollMode.VScroll) {
			bound(BoundMode.ChangeBounds, false);
			setText(0, this.getText());
		}
		else {
			bound(BoundMode.ChangeBounds, false);
		}
		
		
		if (hasToolbarAndMenuFontSize && !this.isSingleLine) {
			
			FunctionOfEditText.createTextView(this, true);
		}
	}
	
	public String getText2() {
		int i;
		HighArray_char r = new HighArray_char(300); 
		for (i=0; i<numOfLines; i++) {
			r.add(textArray[i].str);
		}
		return r.getItems();
	}
	
	public CodeString getText() {
		int j;
		//String newText = "";
		ArrayListCodeChar newText = new ArrayListCodeChar(this.numOfLines*50);
		newText.setText(new CodeString("", textColor));
		for (j=0; j<numOfLines; j++) {
			//newText.insert(newText.count, textArray[j]);
			if (textArray[j]==null) return null;
			newText.concate(textArray[j]);
		}
		CodeString str = new CodeString(newText.getItems(), newText.count); 
		return str;
	}
	
	public HighArray_CodeChar getText3() {
		int j;
		HighArray_CodeChar newText = new HighArray_CodeChar(this.numOfLines*50);
		for (j=0; j<numOfLines; j++) {
			if (textArray[j]==null) return null;
			newText.add(this.textArray[j]);
		} 
		return newText;
	}
	
	public HighArray_char getText4() {
		int j;
		HighArray_char newText = new HighArray_char(this.numOfLines*50);
		for (j=0; j<numOfLines; j++) {
			if (textArray[j]==null) return null;
			newText.add(this.textArray[j].str);
		} 
		return newText;
	}
	
	
	/** cursorPosY에서 n번째 newLineChar를 만날 때까지의  numOfLines를 리턴한다.*/
	protected int getNumOfLines(int cursorPosY, int numOfNewLineChar) {
		int j;
		int countOfNewLineChar = 0;
		if (scrollMode==ScrollMode.Both) {
			return numOfNewLineChar;
		}
		else {
			for (j=cursorPosY; j<numOfLines; j++) {
				if (textArray[j].charAt(textArray[j].length()-1).c=='\n') {
					countOfNewLineChar++;
					if (countOfNewLineChar==numOfNewLineChar) {
						return j;
					}
				}
			}
		}
		return 0;
	}
	
	
	
	/** cursorPosY에서 n번째 newLineChar를 만날 때까지의  numOfLinesInText을 리턴한다.*/
	int getNumOfLinesInText(int cursorPosY, int cursorPosX, int numOfNewLineChar) {
		try {
		int i, j;
		String c;
		numOfLinesInText = 0;
		int countOfNewLineChar = 0;
		
		for (j=cursorPosY; j<numOfLines; j++) {
			numOfLinesInText++;
			for (i=0; i<textArray[j].length(); i++) {
				c = textArray[j].substring(i, i+1).toString();
				if (c.equals(Edit.NewLineChar)) {
					countOfNewLineChar++;
					if (countOfNewLineChar==numOfNewLineChar) {
						return numOfLinesInText;
					}
				}
			}
		}
		
		return numOfLinesInText;
		}catch(Exception e) {
			//Log.e("EditText-getNumOfLinesInTextMultiLine", e.toString());
			if (Common_Settings.g_printsLog) e.printStackTrace();
			if (Common_Settings.g_printsLog) CompilerHelper.printStackTrace(textViewLogBird, e);
			return -1;
		}
	}
	
		
	/** cursorPosY에서 n번째 newLineChar를 만날 때까지의  스트링을 리턴한다.*/
	protected CodeString TextArrayToText(int cursorPosY, int cursorPosX, int numOfNewLineChar) {
		try {
		int i, j;
		//String newText = "";
		ArrayListCodeChar newText = new ArrayListCodeChar(100);
		int count = 0;
		char c;
		CodeChar cc;
		numOfLinesInText = 0;
		//indexOfCursorInText = -1;
		int countOfNewLineChar = 0;
		
		for (j=cursorPosY; j<numOfLines; j++) {
			numOfLinesInText++;
			for (i=0; i<textArray[j].length(); i++) {
				/*if (j==cursorPosY && i==cursorPosX) {
					indexOfCursorInText = count;
				}*/
				count++;
				cc = textArray[j].charAt(i);
				c = cc.c;
				if (c=='\n') {
					countOfNewLineChar++;
					newText.add( cc );
					if (countOfNewLineChar==numOfNewLineChar)  {
						return new CodeString( newText.getItems(), newText.count );
					}
				}
				else {
					//newText += c;
					newText.add( cc );
				}
				
			}
		}
		// 커서가 텍스트바깥에 위치할 때
		/*if (indexOfCursorInText==-1) {
			indexOfCursorInText = count;
		}*/
		
		// newText의 count가 0인 빈스트링일 경우는 null이 리턴이 된다.
		return new CodeString( newText.getItems(), newText.count );
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
			if (Common_Settings.g_printsLog) CompilerHelper.printStackTrace(textViewLogBird, e);
			return null;
		}
	}
	
	
	
	/** startY라인을 시작으로 numOfLines 끝까지의 스트링을 리턴한다.*/
	protected CodeString TextArrayToText(int startY, int startX, int cursorPosY, int cursorPosX) {
		try {
		int i, j;
		ArrayListCodeChar newText = new ArrayListCodeChar(100); 
		int count = 0;
		int textLen;
		//indexOfCursorInText = -1;
		
				
		for (j=startY; j<numOfLines; j++) {
			textLen = textArray[j].length();
			for (i=0; i<textLen; i++) {				
				newText.add( textArray[j].substring(i, i+1).charAt(0) );
				/*if (j==cursorPosY && i==cursorPosX) {
					indexOfCursorInText = count;
				}*/
				count++;
			}
		}
		// 커서가 텍스트바깥에 위치할 때
		/*if (indexOfCursorInText==-1) {
			indexOfCursorInText = count;
		}*/
		return new CodeString(newText.getItems(), newText.count);
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
			if (Common_Settings.g_printsLog) CompilerHelper.printStackTrace(textViewLogBird, e);
			return null;
		}
	}
	
	/** Arrow Key, <br> 
		Shift + Arrow Key = Select <br>
		ALT + Arrow Key = SelectBlock Move
		@param charA : Arrow Key 
		*/
	public void controlChar(String charA) {
		int i;
		String[] specialKeys = IntegrationKeyboard.SpecialKeys;
		for (i=0; i<specialKeys.length; i++) {
			if (charA.equals(specialKeys[i])) {
				FunctionOfEditText.controlChar(this, i, charA);
				return;
			}
		}
	}
	
	
	/** 키 입력시 호출된다.
	 * redoBuffer를 초기화시켜야 redoBuffer에 남아있는 상태에서 키를 입력하고 나서 
	 * 다시 redo 를 하면 발생하는 오류를 해결할 수 있다.*/
	public void addChar(String charA) {
		//if (isSingleLine==false) {
		setIsModified(true);
		redoBuffer.reset();
		
		if (charA.equals(IntegrationKeyboard.Delete)) {	// BackSpace
			charA = Edit.DeleteChar;
			
		}	// BackSpace
		else if (charA.equals(IntegrationKeyboard.Enter)) {
			charA = Edit.NewLineChar;
		}
		else if (charA.equals(IntegrationKeyboard.BackSpace)) {
			charA = Edit.BackspaceChar;
		}
		if (isSingleLine) {
			if (charA.equals(Edit.NewLineChar)) return;
		}
		addCharReally(charA);
			
		if (this.scrollMode==ScrollMode.VScroll) {
			setVScrollPos();
			setVScrollBar();
		}
		else {
			setVScrollPos();
			setHScrollPos();
			setVScrollBar();
			setHScrollBar();
		}
	}
		
	
		
	
	/** space, delete, enter키는 Hangul.mode가 None이다.
	// 그리고 isNextToCursor는 true로 설정되어 addCharVScroll로 커서다음위치에 
	// key가 추가되므로, TextArrayToTextOneLine, setTextOneLine에 의해 \n을 만날 때까지의 
	// text만 대상으로 하여 성능을 향상한다.
	 * */	
	public void addCharReally(String charA) {
		//int cursorPos_backup = cursorPos.x;
		try {			
		
			UndoOfEditText.backUpForUndo(this, charA, false);
			// redo 를 무효화한다. redoBuffer를 모두 지워야 한다. 
			// redo 를 무효로 만들지 않으면 undo-redo 시스템의 오류가 발생한다.
			redoBuffer.reset();
		
		//if (charA.equals(IntegrationKeyboard.Space)) charA = " ";
		if (textArray[cursorPos.y]==null) {
			textArray[cursorPos.y] = new CodeString("", textColor);
		}
	
		int cursorPosX = cursorPos.x;
		int cursorPosY = cursorPos.y;
		
		if (cursorPosX==18) {
			int a;
			a=0;
			a++;
		}
		
		
		if (this.isSelecting && 
				(charA.equals(Edit.DeleteChar) || charA.equals(Edit.BackspaceChar))) {
			this.deleteSelectedText();
		}
		else {
			try {
			textArray[cursorPos.y].insert(new CodeString(charA, textColor).listCodeChar, 0, cursorPosX, charA.length());
			}catch(Exception e) {
				e.printStackTrace();
			}
			
			
			if (!charA.equals(Edit.DeleteChar) && !charA.equals(Edit.NewLineChar) &&
					!charA.equals(Edit.BackspaceChar)) {
				CodeString newText=null;				
				try {
					newText = TextArrayToText(cursorPos.y, cursorPosX, 1);
					setTextMultiLine(cursorPos.y, newText, -1);
				}catch(Exception e) {
				}				
				
				if (keyboardMode==Mode.Hangul && hangulMode!=Hangul.Mode.None) {
				
				}
				else {
					cursorPos.x = cursorPosX + 1;
				}		
			}
			else {
				if (charA.equals(Edit.BackspaceChar)) {
					addBackspaceChar();
				}
				else if (charA.equals(Edit.DeleteChar)) {
					addDeleteChar();
				}
				else if (charA.equals(Edit.NewLineChar)) {
					addEnterChar();
				}
				else {
					CodeString newText = TextArrayToText(cursorPos.y, 0, cursorPos.y, cursorPosX);
					setText(cursorPos.y, newText);
				}
			}
		}
		
		
				
		}catch(Exception e) {
			//Log.e("EditText-addCharReally", e.toString());
			if (Common_Settings.g_printsLog) e.printStackTrace();
			CompilerHelper.printStackTrace(textViewLogBird, e);
		}
	}
	
	
	
	
	protected void addBackspaceChar() {
		if (this.isSelecting) {
			this.deleteSelectedText();
			return;
		}
		
		if (cursorPos.x!=0) { 
			int cursorPosX_backup = cursorPos.x;
			CodeString newText = TextArrayToText(cursorPos.y, cursorPos.x, 1);		
			setTextMultiLine(cursorPos.y, newText, -1);
			cursorPos.x = cursorPosX_backup-1;			
		}
		else {//if (cursorPos.x==0) { 
			int prevLine = cursorPos.y-1;
			if (prevLine>=0) {
				if (scrollMode==ScrollMode.VScroll) {
					// 지워질 라인수를 먼저 구한다. 
					int numOfLinesToDelete;
					TextArrayToText(cursorPos.y, 0, 1);
					// numOfLinesInText는 현재 라인(마지막 '\n'까지)에서 지워질 라인수이고
					// 플러스 1은 이전 라인에서 지워질 라인을 말한다.
					numOfLinesToDelete = numOfLinesInText + 1;
				
					CodeString newPrevLine;
					if (textArray[prevLine].charAt(textArray[prevLine].length()-1).c=='\n') {
						newPrevLine = deleteNewLineChar(textArray[prevLine]);
					}
					else {
						newPrevLine = textArray[prevLine].substring(0,
								textArray[prevLine].length()-1);
					}
					CodeChar[] charArrayNewPrevLine = newPrevLine.listCodeChar;
					CodeString curLineText = TextArrayToText(cursorPos.y, cursorPos.x, 1);
					// \bk를 제거한다.
					curLineText = curLineText.substring(3, curLineText.length());
					
					CodeChar[] charArrayCurLine = curLineText.listCodeChar;
					int newCursorX = newPrevLine.length();
					try {
						charArrayNewPrevLine = Array.InsertNoSpaceError(charArrayCurLine, 0, 
								charArrayNewPrevLine, newCursorX, 
								charArrayCurLine.length, newPrevLine.count);
					}catch(Exception e) {
						if (Common_Settings.g_printsLog) e.printStackTrace();
						if (Common_Settings.g_printsLog) CompilerHelper.printStackTrace(textViewLogBird, e);
					}
					
					// newPrevLine은 새로운 text 가 된다.
					newPrevLine = new CodeString(charArrayNewPrevLine, charArrayNewPrevLine.length);
					setTextMultiLine(prevLine, newPrevLine, numOfLinesToDelete);
					
					cursorPos.x = newCursorX;
					cursorPos.y = prevLine;
					//vScrollPos = oldVScrollPos;
					//setVScrollPos();
					//setVScrollBar();
				}//if (scrollMode==ScrollMode.VScroll) {
				else {	// 당연히 이전 줄은 newline으로 끝난다.
					int numOfLinesToDelete = 2;
					CodeString newPrevLine = deleteNewLineChar(textArray[prevLine]);
					CodeChar[] charArrayNewPrevLine = newPrevLine.listCodeChar;
					CodeString curLineText = textArray[cursorPos.y];
					// \bk를 제거한다.
					curLineText = curLineText.substring(3, curLineText.length());
					
					CodeChar[] charArrayCurLine = curLineText.listCodeChar;
					int newCursorX = newPrevLine.length();
					try {
						charArrayNewPrevLine = Array.InsertNoSpaceError(charArrayCurLine, 0, 
								charArrayNewPrevLine, newCursorX, 
								charArrayCurLine.length, newPrevLine.count);
					}catch(Exception e) {
						if (Common_Settings.g_printsLog) e.printStackTrace();
						if (Common_Settings.g_printsLog) CompilerHelper.printStackTrace(textViewLogBird, e);
					}
					
					
					newPrevLine = new CodeString(charArrayNewPrevLine, charArrayNewPrevLine.length);
					setTextMultiLine(prevLine, newPrevLine, numOfLinesToDelete);
					
					cursorPos.x = newCursorX;
					cursorPos.y = prevLine;
					/*setVScrollPos();
					setHScrollPos();
					setVScrollBar();
					setHScrollBar();*/
				}//ScrollMode.Both
			} // if (prevLine>=0)
			else {//첫번째 줄에서 0칼럼
				int cursorPosX_backup = cursorPos.x;
				CodeString newText = TextArrayToText(cursorPos.y, cursorPos.x, 1);		
				setTextMultiLine(cursorPos.y, newText, -1);
				cursorPos.x = cursorPosX_backup;
			}//if (prevLine<0)
			
		}//if (cursorPos.x==0) { 
	}
	
	protected void deleteSelectedText() {
		if (this.isSelecting) {
			Point p1 = this.selectP1;
			Point p2 = this.selectP2;
			Point temp;
			
			if (p1.x==-1 && p2.x==-1) return; 
			
			if (p1.y>p2.y) {
				temp = p1;
				p1 = p2;
				p2 = temp;				
			}
			else if (p1.y==p2.y) {
				if (p1.x>p2.x) {
					temp = p1;
					p1 = p2;
					p2 = temp;
				}
			}
			
			// p1.y 가 항상 p2.y 보다 작다.
			// p1.y와 p2.y가 같은 경우에 p1.x 가 항상 p2.x 보다 작다.
			
			int curLine = p1.y;
			int numOfLinesToDelete = this.getNumOfNewLineChar(p1, p2) + 1;
						
			CodeString headText = textArray[curLine];
			headText = headText.substring(0, p1.x);
			
			CodeString tailText = TextArrayToText(p2.y, p2.x, 1);
			if (tailText!=null && tailText.count>0)	// null도 아니고 빈스트링도 아니면		
				tailText = tailText.substring(p2.x+1, tailText.length());
			
			try {
			CodeString newText = headText.concate(tailText);
			if (numOfLinesToDelete==1 && newText.equals("") && p2.y<this.numOfLines-1) {
				newText = new CodeString("\n", textArray[curLine].listCodeChar[0].color);
			}
			else if (p2.x<textArray[p2.y].count && textArray[p2.y].charAt(p2.x).c=='\n') {
				newText = newText.concate(new CodeString("\n", textColor));
			}
			setTextMultiLine(curLine, newText, numOfLinesToDelete);
			}catch(Exception e) {
				if (Common_Settings.g_printsLog) e.printStackTrace();
			}
			
			isSelecting = false;
			
			cursorPos.x = p1.x;
			cursorPos.y = p1.y;
		}
	}
	
	protected void addDeleteChar() {
		if (this.isSelecting) {
			
			this.deleteSelectedText();
			return;
		}
		
		int cursorPosX_backup = cursorPos.x;
		
		// cursorPos는  가리키므로 cursorPos.x는 %를 가리킨다.
		if (cursorPos.x+3<textArray[cursorPos.y].length()) {
			// 자 뒤의 문자
			CodeString curChar = textArray[cursorPos.y].substring(cursorPos.x+3,cursorPos.x+3+1);
			if (!(curChar.toString().equals("\n"))) {
				CodeString newText = TextArrayToText(cursorPos.y, cursorPos.x, 1);		
				setTextMultiLine(cursorPos.y, newText, -1);
			}
			else {	// '\n'문자 지우기
				int nextLine = cursorPos.y + 1;
				int curLine = cursorPos.y;
				if (nextLine<numOfLines) {
					if (scrollMode==ScrollMode.VScroll) {
						int numOfLinesToDelete;
						TextArrayToText(curLine, 0, 2);
						numOfLinesToDelete = numOfLinesInText;
					
						CodeString newCurLine = deleteNewLineChar(textArray[curLine]);
						//  제거한다.
						newCurLine = newCurLine.substring(0, cursorPos.x);
						CodeChar[] charArrayNewCurLine = newCurLine.listCodeChar;
						int newCursorX = newCurLine.length();
						
						CodeString nextLineText = TextArrayToText(nextLine, 0, 1);
						
						//charArrayNewCurLine = Array.Resize(charArrayNewCurLine, 
						//		charArrayNewCurLine.length/*+nextLineText.length()*/);
						CodeChar[] charArrayNextLine = nextLineText.listCodeChar;

						try {
							charArrayNewCurLine = Array.InsertNoSpaceError(charArrayNextLine, 0, 
									charArrayNewCurLine, newCursorX, 
									charArrayNextLine.length, newCurLine.count);
						}catch(Exception e) {
							if (Common_Settings.g_printsLog) e.printStackTrace();
							if (Common_Settings.g_printsLog) CompilerHelper.printStackTrace(textViewLogBird, e);
						}
						
						newCurLine = new CodeString(charArrayNewCurLine, charArrayNewCurLine.length);
						setTextMultiLine(curLine, newCurLine, numOfLinesToDelete);
						
						cursorPos.x = newCursorX;
						cursorPos.y = curLine;
						
					}//if (scrollMode==ScrollMode.VScroll) {
					else {	//ScrollMode.Both
						int numOfLinesToDelete = 2;
						CodeString newCurLine = deleteNewLineChar(textArray[curLine]);
						//  제거한다.
						newCurLine = newCurLine.substring(0, cursorPos.x);
						CodeChar[] charArrayNewCurLine = newCurLine.listCodeChar;						
						int newCursorX = newCurLine.length();
						
						CodeString nextLineText = textArray[nextLine];
						
						CodeChar[] charArrayNextLine = nextLineText.listCodeChar;
						
						try {
							charArrayNewCurLine = Array.InsertNoSpaceError(charArrayNextLine, 0, 
									charArrayNewCurLine, newCursorX, 
									charArrayNextLine.length, newCurLine.count);
						}catch(Exception e) {
							if (Common_Settings.g_printsLog) e.printStackTrace();
							if (Common_Settings.g_printsLog) CompilerHelper.printStackTrace(textViewLogBird, e);
						}
						
						newCurLine = new CodeString(charArrayNewCurLine, charArrayNewCurLine.length);
						setTextMultiLine(curLine, newCurLine, numOfLinesToDelete);
						
						cursorPos.x = newCursorX;
						cursorPos.y = curLine;
					}////ScrollMode.Both
				} // if (nextLine<numOfLines) {
				else {//마지막 라인
					CodeString newText = TextArrayToText(cursorPos.y, cursorPos.x, 1);		
					setTextMultiLine(cursorPos.y, newText, -1);
				}
			} // else {	// '\n'문자 지우기

		}
		else {	// if (cursorPos.x+3<textArray[cursorPos.y].length()) {
			// cursorPos는  가리키므로 cursorPos.x는 %를 가리킨다.
			//  제거한다.
			if (scrollMode==ScrollMode.Both) {
				textArray[cursorPos.y] = textArray[cursorPos.y].substring(0, cursorPos.x);
			}
			else { // 다음 줄의 첫문자를 지운다.
				CodeString newText = TextArrayToText(cursorPos.y, cursorPos.x, 1);		
				setTextMultiLine(cursorPos.y, newText, -1);
			}
		}
		
		cursorPos.x = cursorPosX_backup;
	}
	
	
	/**엔터키를 입력하였으므로 마지막 줄수를 100줄 더 늘린다.
	NullPointerException 이나 getCursorPos()에서 에러를 발생시킬수 있으므로.*/
	public void addEnterChar() {
		int cursorPosX;
		cursorPosX = cursorPos.x;
		
		
		// 추가된 \n 을 포함하는 라인(추가된 \n 까지의 라인)과 그 다음 라인
		CodeString strCurLine = TextArrayToText(cursorPos.y, cursorPosX, 2);
	
		int curLine = cursorPos.y;
		
		// 추가된 \n 을 포함하는 라인(추가된 \n 까지의 라인)
		CodeString newText1 = strCurLine;
		int numOfLinesToDelete = this.getNumOfLinesInText(cursorPos.y, 0, 2);
		setTextMultiLine(cursorPos.y, newText1, numOfLinesToDelete);
		
		
		
		// 엔터키를 입력하였으므로 마지막 줄수를 100줄 더 늘린다.
		// NullPointerException 이나 getCursorPos()에서 에러를 발생시킬수 있으므로.
		textArray = Array.Resize(textArray, numOfLines+100);
	
		
		cursorPos.y = curLine + 1;
		cursorPos.x = 0;
		
	}

	/**한글완성중일 때 이 메서드를 사용한다. 
	 * redoBuffer를 초기화시켜야 redoBuffer에 남아있는 상태에서 키를 입력하고 나서 
	 * 다시 redo 를 하면 발생하는 오류를 해결할 수 있다.*/
	public void replaceChar(String charA) {
		setIsModified(true);
		redoBuffer.reset();

		if (charA.equals(IntegrationKeyboard.Delete)) {	// BackSpace
			charA = Edit.DeleteChar;				
		}	// BackSpace
		else if (charA.equals(IntegrationKeyboard.Enter)) {
			charA = Edit.NewLineChar;
		}
		replaceCharReally(charA);
			
	}
	
	/** 한글이 완성중일때만 동작한다. */
	private void replaceCharReally(String charA) {
		UndoOfEditText.backUpForUndo(this, charA, true);
		// redo 를 무효화한다. redoBuffer를 모두 지워야 한다. 
		// redo 를 무효로 만들지 않으면 undo-redo 시스템의 오류가 발생한다.
		redoBuffer.reset();
		
		//if (charA.equals(IntegrationKeyboard.Space)) charA = " ";
				
		
		int charALen = charA.length();
		
			// I라에서 ㅁ을 입력할때 람이 된다.
			// I람에서 ㅂ을 입력할때 람ㅂ이 된다.
		try {
			textArray[cursorPos.y].delete(cursorPos.x, 1);
			textArray[cursorPos.y].insert(new CodeString(charA, textColor).listCodeChar, 0, cursorPos.x, charALen);
		}
		catch(Exception e) {
			e.printStackTrace();
			int a;
			a=0;
			a++;
		}
		
		
		/*boolean isBkSpThatMakeNullStr = false;
		Point oldCursorPos=null;
		if (charALen==0) { //  도ㄹ에서 ㄹ을 ""으로 만드는 backspace키가 눌릴 때 현재 커서위치를 저장한다.
			isBkSpThatMakeNullStr = true;
			charALen = 1;	// 현재 커서를 가리키도록 한다.
			oldCursorPos = new Point(cursorPos.x, cursorPos.y);
		}*/
		CodeString newText=null;
		newText = TextArrayToText(cursorPos.y, cursorPos.x+charALen-1, 1);
		setTextMultiLine(cursorPos.y, newText, -1);
		
		if (charALen>1 && (CommonGUI.keyboard.mode==Mode.Hangul && Hangul.mode!=Hangul.Mode.None)) {
			cursorPos.x++;
		}
		else {
			
		}
		
		/*if (isBkSpThatMakeNullStr) {
			cursorPos.x = oldCursorPos.x;
			cursorPos.y = oldCursorPos.y;
			isBkSpThatMakeNullStr = false;
		}*/
	}
	
	
	public void initialize() {
		//this.disposeTextArray();
		initCursorAndScrollPos();
		this.textArray = new CodeString[10];
		
		this.isSelecting = false;		
		
		//this.fontSize = view.getOriginalHeight() * 0.03f;
		this.fontSize = this.curFontSize;
		setDescentAndLineHeight(fontSize);
		//int toolbarButtonIndex = toolbar.findIndex("S");
		if (toolbar!=null) toolbar.buttons[0].setText(""+fontSize);
		
		
		this.keyboardMode = IntegrationKeyboard.Mode.Math;
		
		setBackColor(backColor);
		paint.setTextSize(fontSize);
		setText(0,new CodeString("", textColor));
		
		undoBuffer = new UndoBufferOfEditText();
		redoBuffer = new RedoBufferOfEditText();
		//preProcessor = null;
		//isModified = true;
		lang = null;
		
	}
	
	public void initCursorAndScrollPos() {
		cursorPos.x = 0;
		cursorPos.y = 0;
		
		this.boundAttributes(BoundMode.ChangeBounds);
		
		if (scrollMode==ScrollMode.VScroll) {
			vScrollPos = 0;
			vScrollBar.setVScrollBar(numOfLinesPerPage, /*numOfLinesInPage,*/ 
					numOfLines, vScrollPos, 1);
		}
		else {
			vScrollPos = 0;
			//hScrollPos = 0;
			widthOfhScrollPos = 0;
			vScrollBar.setVScrollBar(numOfLinesPerPage, /*numOfLinesInPage,*/ 
					numOfLines, vScrollPos, 1);
			hScrollBar.setHScrollBar(widthOfCharsPerPage, /*widthOfCharsInPage,*/ 
					widthOfTotalChars, widthOfhScrollPos, widthOfhScrollInc);
		}
	}
	
		
	/** startLine에서 시작하여 numOfLinesToDelete 개수 만큼 textArray에서 지우고
	 * 그 지워진 부분에 새로운 text 를 넣는다. 
	 * numOfLinesToDelete가 -1 이면 numOfLinesInText를 가지고 지워질 라인수를 산정한다.*/
	public void setTextMultiLine(int startLine, CodeString text, int numOfLinesToDelete) {
		if (text==null) return;
		//isModified = true;
		if (scrollMode==ScrollMode.VScroll) {
			setTextMultiLineVScroll(startLine, text, numOfLinesToDelete);			
			setVScrollPos();
			setVScrollBar();
		}		
		else if (scrollMode==ScrollMode.Both) {
			setTextMultiLineBoth(startLine, text, numOfLinesToDelete);
			setVScrollPos();
			setHScrollPos();
			setVScrollBar();			
			setHScrollBar();
		}	
	}
	
	void disposeTextArray() {
		int i;
		if (textArray!=null) {
			for (i=0; i<textArray.length; i++) {
				if (textArray[i]!=null) {
					textArray[i].destroy();
					textArray[i] = null;
				}
			}
		}
		//textArray = null;
	}
	
	/**startLine 이후 라인부터 text 를 추가한다.*/
	public synchronized void setText(int startLine, CodeString text) {
		HighArray_CodeChar convertedText = new HighArray_CodeChar(50);
		convertedText.add(text);
		this.setText(startLine, convertedText);
		
	}
	
	/**startLine 이후 라인부터 text 를 추가한다.*/
	public synchronized void setText(int startLine, HighArray_CodeChar text) {
		try {
			if (name.equals("EditText_Compiler")) {
			}
			if (startLine==0) {
				this.isSelecting = false;
				if (text==null || text.equals("")) {
					textArray[0] = new CodeString("", Common_Settings.textColor);
				}
			}
		//synchronized (this.textArray) {
		if (text==null) text = new HighArray_CodeChar(1);	
		
		if (scrollMode==ScrollMode.VScroll) {
			setTextVScroll(startLine, text);			
			setVScrollPos();
			setVScrollBar();
		}		
		else if (scrollMode==ScrollMode.Both) {
			setTextScrollBoth(startLine, text);
			setVScrollPos();
			setHScrollPos();
			setVScrollBar();
			if (!this.getIsSingleLine()) {
				setHScrollBar();
			}
		}
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
			if (Common_Settings.g_printsLog) CompilerHelper.printStackTrace(textViewLogBird, e);
		}
		finally {
			if (Common_Settings.CurrentSystem.equals(Common_Settings.CurrentSystemIsJava) &&
	    			Common_Settings.settings.isTripleBuffering)  this.drawToImage(mCanvas);
		}
	}
	
	
	
	
	public void forwardCursorX() {
		cursorPos.x++;
	}
	
	
	
	
	String[] setTextArrayNoSpaceError(String[] textArray, int lineNumber, String text) {
		if (lineNumber<textArray.length) {
			textArray[lineNumber] = text;
		}
		else {
			textArray = Array.Resize(textArray, lineNumber+20);
			
			textArray[lineNumber] = text;
		}
		return textArray;
	}
	
	ArrayListCodeChar[] setTextArrayNoSpaceError(ArrayListCodeChar[] textArray, int lineNumber, ArrayListCodeChar text) {
		try{
		if (lineNumber<textArray.length-1) {
			textArray[lineNumber] = text;
		}
		else {
			textArray = Array.Resize(textArray, lineNumber+20);
			
			textArray[lineNumber] = text;
		}
		return textArray;
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
			if (Common_Settings.g_printsLog) CompilerHelper.printStackTrace(textViewLogBird, e);
		}
		return null;
	}
	
	
	private void setTextVScroll(int startLine, HighArray_CodeChar text) {
		
		numOfLines = startLine + 1;
				
			
			ArrayListCodeChar textTemp1 = new ArrayListCodeChar(30);
			ArrayListCodeChar textTemp2 = new ArrayListCodeChar(30);
			ArrayListCodeChar[] textListArray = new ArrayListCodeChar[textArray.length];
			
			int i;
			float lineWidth = 0;
			
			CodeChar charA;
			boolean isDeleteChar = false;
			boolean isNextCharBkSp = false;
			boolean isCurCharBkSp = false;
			int textLen = text.length();
			
			paint.setTextSize(fontSize);
			
			for (i=0; i<textLen; i++) {
				
				charA = text.charAt(i);
				if (charA.c=='\r') continue;
				if (i+1<textLen) {
					isNextCharBkSp = HelperOfEditText.isNextCharBkSp(text, i);
				}
				else {
					isNextCharBkSp = false;
				}
				isDeleteChar = HelperOfEditText.isCurCharDelete(text, i);
				isCurCharBkSp = HelperOfEditText.isCurCharBkSp(text, i);
				
				if (isDeleteChar) {
					isDeleteChar = false;
					i+=3; // d 생략
				}
				else {
					if (isNextCharBkSp) {	// 다음 문자가 bksp이면 bksp다음으로 처리를 옮긴다.
						isNextCharBkSp = false;
						i += 3;
						continue;
					}
					if (isCurCharBkSp) {	// 다음 문자가 bksp이면 bksp다음으로 처리를 옮긴다.
						isCurCharBkSp = false;
						i += 2;
						continue;
					}
					if (charA.c==Edit.NewLineChar.charAt(0)) {
						textTemp1.add(charA);
						textListArray = setTextArrayNoSpaceError(textListArray, numOfLines-1, textTemp1);
						numOfLines++;
						textListArray = setTextArrayNoSpaceError(textListArray, numOfLines-1, new ArrayListCodeChar(0));
						// textTemp1.reset()을 사용하지 않고 다음과 같이 한다. 줄마다 동일한 메모리 참조
						textTemp1 = new ArrayListCodeChar(30);
						textTemp2 = new ArrayListCodeChar(30);
						lineWidth = 0;
					}				
					else  {
						textTemp1.add(charA);
						lineWidth += paint.measureText(charA.toString());
						if (lineWidth > rationalBoundsWidth) {
							textListArray = setTextArrayNoSpaceError(textListArray, numOfLines-1, textTemp2);
							numOfLines++;
							textListArray = setTextArrayNoSpaceError(textListArray, numOfLines-1, new ArrayListCodeChar(0));
							// textTemp1.reset()을 사용하지 않고 다음과 같이 한다. 줄마다 동일한 메모리 참조
							textTemp1 = new ArrayListCodeChar(30);
							textTemp2 = new ArrayListCodeChar(30);
							lineWidth = 0;
							i--;	// 초과된 문자(다음줄의 첫문자)를 다시 처리
						}
						else {
							textTemp2.add(charA);
							textListArray = setTextArrayNoSpaceError(textListArray, numOfLines-1, textTemp2);
						}
					}
				}	// isDeleteChar == false;
				
			}		// for			
			
			
			
			textArray = Array.Resize(textArray, textListArray.length);
			for (i=startLine; i<numOfLines; i++) {
				if (textListArray[i]!=null && textListArray[i].count>0) {
					textArray[i] = new CodeString(textListArray[i].getItems(), textListArray[i].count);
				}
				else {
					textArray[i] = new CodeString("", textColor);
				}
			}
	
	}
	
	
	
	
	/** 수직스크롤바만 있는 경우, 즉 수평스크롤바가 없다.
		// cursorPos.y 는 startLine과 같다.*/
		public void setTextVScroll(int startLine, CodeString text) {
			HighArray_CodeChar convertedText = new HighArray_CodeChar(50);
			convertedText.add(text);
			this.setTextVScroll(startLine, convertedText);			
		}
		
		public void setTextScrollBoth(int startLine, HighArray_CodeChar text) {
			try {
				
				//CodeChar c = setTextScrollBoth2(startLine, text);
				
				numOfLines = startLine + 1;
			
			
				ArrayListCodeChar textTemp1 = new ArrayListCodeChar(30);
				ArrayListCodeChar[] textListArray = new ArrayListCodeChar[textArray.length];
				
				int i;
				
				CodeChar charA;
				boolean isDeleteChar = false;
				boolean isNextCharBkSp = false;
				boolean isCurCharBkSp = false;
				int textLen = text.getCount();
				
				
				for (i=0; i<textLen; i++) {
					if (i==7368) {
					}
					charA = text.charAt(i);	
					if (charA.c=='\r') continue;
					
					if (i+1<textLen) {
						isNextCharBkSp = HelperOfEditText.isNextCharBkSp(text, i);
					}
					else {
						isNextCharBkSp = false;
					}
					isDeleteChar = HelperOfEditText.isCurCharDelete(text, i);
					isCurCharBkSp = HelperOfEditText.isCurCharBkSp(text, i);
					
					if (isDeleteChar) {
						isDeleteChar = false;
						i+=3; // d 생략
					}
					else {
						if (isNextCharBkSp) {	// 다음 문자가 bksp이면 bksp다음으로 처리를 옮긴다.
							isNextCharBkSp = false;
							i += 3;
							continue;
						}
						if (isCurCharBkSp) {	// 다음 문자가 bksp이면 bksp다음으로 처리를 옮긴다.
							isCurCharBkSp = false;
							i += 2;
							continue;
						}
						if (charA.c==Edit.NewLineChar.charAt(0)) {
							textTemp1.add(charA);
							textListArray = setTextArrayNoSpaceError(textListArray, numOfLines-1, textTemp1);
							numOfLines++;
							textListArray = setTextArrayNoSpaceError(textListArray, numOfLines-1, new ArrayListCodeChar(0));
							// textTemp1.reset()을 사용하지 않고 다음과 같이 한다. 줄마다 동일한 메모리 참조
							textTemp1 = new ArrayListCodeChar(30);
						}
						else  {
							textTemp1.add(charA);
							textListArray = setTextArrayNoSpaceError(textListArray, numOfLines-1, textTemp1);
							
						}
					}	// isDeleteChar == false;
					
				}		// for
				
				
				
				textArray = Array.Resize(textArray, textListArray.length);
				for (i=startLine; i<numOfLines; i++) {
					if (textListArray[i]!=null && textListArray[i].count>0) {
						textArray[i] = new CodeString(textListArray[i].getItems(), textListArray[i].count);
					}
					else {
						textArray[i] = new CodeString("", textColor);
					}
				}
			
			}catch(Exception e) {
				//Log.e("EditText-setTextScrollBoth", e.toString());
				if (Common_Settings.g_printsLog) e.printStackTrace();
				if (Common_Settings.g_printsLog) CompilerHelper.printStackTrace(textViewLogBird, e);
			}
		}
		
		public void setTextScrollBoth(int startLine, CodeString text) {
			HighArray_CodeChar convertedText = new HighArray_CodeChar(50);
			convertedText.add(text);
			this.setTextScrollBoth(startLine, convertedText);			
		}
		/** paste에서 사용*/
		public void setTextMultiLineVScroll(int lineNumber, CodeString text, int numOfLinesToDelete/*, int numOfNewLineChar*/) {
			int numOfLinesLocal = 1;
			
			try {
				ArrayListCodeChar textTemp1 = new ArrayListCodeChar(30);
				ArrayListCodeChar textTemp2 = new ArrayListCodeChar(30);
				ArrayListCodeChar[] textListArrayLocal = new ArrayListCodeChar[20];// 20 lines
				
				textListArrayLocal[0] = new ArrayListCodeChar(0); // '\n'을 친 후에 새로 생긴 빈 라인을 위한 것이다.
				
				int i;
				float lineWidth = 0;
				
				
				CodeChar charA;
				boolean isDeleteChar = false;
				boolean isNextCharBkSp = false;
				boolean isCurCharBkSp = false;
				int textLen = text.length();
				
				paint.setTextSize(fontSize);
				
				for (i=0; i<textLen; i++) {
					charA = text.charAt(i);
					if (charA.c=='\r') continue;
					
					if (i+1<textLen) {
						isNextCharBkSp = HelperOfEditText.isNextCharBkSp(text, i);
					}
					else {
						isNextCharBkSp = false;
					}
					isDeleteChar = HelperOfEditText.isCurCharDelete(text, i);
					isCurCharBkSp = HelperOfEditText.isCurCharBkSp(text, i);
					
					if (isDeleteChar) {
						isDeleteChar = false;
						i+=3; // d 생략
					}
					else {
						if (isNextCharBkSp) {	// 다음 문자가 bksp이면 bksp다음으로 처리를 옮긴다.
							isNextCharBkSp = false;
							i += 3;
							continue;
						}
						if (isCurCharBkSp) {	// 다음 문자가 bksp이면 bksp다음으로 처리를 옮긴다.
							isCurCharBkSp = false;
							i += 2;
							continue;
						}
						if (charA.toString().equals(Edit.NewLineChar)) {
							textTemp1.add(charA);
							textListArrayLocal = setTextArrayNoSpaceError(textListArrayLocal, numOfLinesLocal-1, textTemp1);
							
							// MultiLine이므로 break를 하지 않는다.
						
							numOfLinesLocal++;
							textTemp1 = new ArrayListCodeChar(30);
							textTemp2 = new ArrayListCodeChar(30);
							lineWidth = 0;
						}				
						else  {
							textTemp1.add(charA);
							lineWidth += paint.measureText(charA.toString());
							if (lineWidth > rationalBoundsWidth) {
								textListArrayLocal = setTextArrayNoSpaceError(textListArrayLocal, numOfLinesLocal-1, textTemp2);
								numOfLinesLocal++;
								textTemp1 = new ArrayListCodeChar(30);
								textTemp2 = new ArrayListCodeChar(30);
								lineWidth = 0;
								i--;	// 초과된 문자(다음줄의 첫문자)를 다시 처리
							}
							else {
								textTemp2.add(charA);
								textListArrayLocal = setTextArrayNoSpaceError(textListArrayLocal, numOfLinesLocal-1, textTemp2);
								
							}
						}
					}	// isDeleteChar == false;
					
				}		// for
				
				if (numOfLinesToDelete==-1) {
					// 마지막 라인에서 엔터를 누른 경우 numOfLinesLocal는 두 줄이므로
					// '\n'으로 끝나더라도 -1을 하지 않는다.
					if (lineNumber!=numOfLines-1 &&
							text.length()>0 && text.charAt(text.length()-1).c=='\n') {
						numOfLinesLocal--;
					}
					this.numOfLines -= numOfLinesInText;
					textArray = Array.Delete(textArray, lineNumber, numOfLinesInText);
				}
				else {
					// 마지막 라인에서 엔터를 누른 경우 numOfLinesLocal는 두 줄이므로
					// '\n'으로 끝나더라도 -1을 하지 않는다.
					if (lineNumber!=numOfLines-1 &&
							text.length()>0 && text.charAt(text.length()-1).c=='\n') {
						numOfLinesLocal--;
					}
					this.numOfLines -= numOfLinesToDelete;
					textArray = Array.Delete(textArray, lineNumber, numOfLinesToDelete);
				}
				
				CodeString[] textArrayLocal = new CodeString[textListArrayLocal.length];
				for (i=0; i<textArrayLocal.length; i++) {
					if (textListArrayLocal[i]!=null && textListArrayLocal[i].count>0) {
						textArrayLocal[i] = new CodeString(textListArrayLocal[i].getItems(), textListArrayLocal[i].count);
					}
					else {
						textArrayLocal[i] = new CodeString("", textColor);
					}
				}
				textArray = Array.InsertNoSpaceError(textArrayLocal, 0, textArray, lineNumber, 
						numOfLinesLocal, numOfLines);
				this.numOfLines += numOfLinesLocal;
				
			}catch(Exception e) {
				if (Common_Settings.g_printsLog) e.printStackTrace();
				if (Common_Settings.g_printsLog) CompilerHelper.printStackTrace(textViewLogBird, e);
			}
		}
		/** paste에서 사용*/
		public void setTextMultiLineBoth(int lineNumber, CodeString text, int numOfLinesToDelete) {
			int numOfLinesLocal = 1;
			
			try {
			
				ArrayListCodeChar[] textListArrayLocal = new ArrayListCodeChar[20]; // 20 lines
				
				textListArrayLocal[0] = new ArrayListCodeChar(0); // '\n'을 친 후에 새로 생긴 빈 라인을 위한 것이다.
				
				
				ArrayListCodeChar textTemp1 = new ArrayListCodeChar(30);
				int i;
				
				CodeChar charA;
				boolean isDeleteChar = false;
				boolean isNextCharBkSp = false;
				boolean isCurCharBkSp = false;
				int textLen = text.length();
				
				for (i=0; i<textLen; i++) {
					charA = text.charAt(i);
					if (charA.c=='\r') continue;
					
					if (i+1<textLen) {
						isNextCharBkSp = HelperOfEditText.isNextCharBkSp(text, i);
					}
					else {
						isNextCharBkSp = false;
					}
					isDeleteChar = HelperOfEditText.isCurCharDelete(text, i);
					isCurCharBkSp = HelperOfEditText.isCurCharBkSp(text, i);
					
					if (isDeleteChar) {
						isDeleteChar = false;
						i+=3; // d 생략
					}
					else {
						if (isNextCharBkSp) {	// 다음 문자가 bksp이면 bksp다음으로 처리를 옮긴다.
							isNextCharBkSp = false;
							i += 3;
							continue;
						}
						if (isCurCharBkSp) {	// 다음 문자가 bksp이면 bksp다음으로 처리를 옮긴다.
							isCurCharBkSp = false;
							i += 2;
							continue;
						}
						// ScrollMode가 Both이므로 딱 1줄이다.따라서 다음과 같이 한다.
						if (charA.c==Edit.NewLineChar.charAt(0)) {
							textTemp1.add(charA);
							textListArrayLocal = setTextArrayNoSpaceError(textListArrayLocal, numOfLinesLocal-1, textTemp1);
													
														
							numOfLinesLocal++;
							textTemp1 = new ArrayListCodeChar(30);
						}
						else  {
							textTemp1.add(charA);
							textListArrayLocal = setTextArrayNoSpaceError(textListArrayLocal, numOfLinesLocal-1, textTemp1);
							
						}
					}	// isDeleteChar == false;
					
				}		// for
				
				
				if (numOfLinesToDelete==-1) {
					if (lineNumber!=numOfLines-1 &&
							text.length()>0 && text.charAt(text.length()-1).c=='\n') {
						numOfLinesLocal--;
					}
					this.numOfLines -= numOfLinesInText;
					//Array.destroy(textArray, lineNumber, numOfLinesInText);
					textArray = Array.Delete(textArray, lineNumber, numOfLinesInText);
				}
				else {
					// 마지막 라인에서 엔터를 누른 경우 numOfLinesLocal는 두 줄이므로
					// '\n'으로 끝나더라도 -1을 하지 않는다.
					if (lineNumber!=numOfLines-1 &&
							text.length()>0 && text.charAt(text.length()-1).c=='\n') {
						numOfLinesLocal--;
					}
					this.numOfLines -= numOfLinesToDelete;
					//Array.destroy(textArray, lineNumber, numOfLinesToDelete);
					textArray = Array.Delete(textArray, lineNumber, numOfLinesToDelete);
				}				
				
				CodeString[] textArrayLocal = new CodeString[numOfLinesLocal];
				for (i=0; i<numOfLinesLocal; i++) {
					if (textListArrayLocal[i]!=null && textListArrayLocal[i].count>0) {
						textArrayLocal[i] = new CodeString(textListArrayLocal[i].getItems(), textListArrayLocal[i].count);
					}
					else {
						// null이거나 빈 스트링
						textArrayLocal[i] = new CodeString("", textColor);
					}
				}
				
				
				
				// 원래 줄이 삭제되고 새로운 줄이 들어온다.
				//textArray = Array.Delete(textArray, lineNumber, numOfLinesInText);
				textArray = Array.InsertNoSpaceError(textArrayLocal, 0, textArray, lineNumber, 
						numOfLinesLocal, numOfLines);
				this.numOfLines += numOfLinesLocal;
				
			}catch(Exception e) {
				if (Common_Settings.g_printsLog) e.printStackTrace();
				if (Common_Settings.g_printsLog) CompilerHelper.printStackTrace(textViewLogBird, e);
			}
				
			
		}
	
	
	/** 키보드에 키를 입력할 경우 호출한다.*/
	public void setVScrollPos() {
		//if (isReadOnly) return;
		if (!(vScrollPos<=cursorPos.y && cursorPos.y<vScrollPos+numOfLinesPerPage)) {
			if (cursorPos.y<vScrollPos) {
				
				vScrollPos = cursorPos.y;
				//vScrollPos--;
				//if (vScrollPos<0) vScrollPos=0;
			}
			else {
				
				//vScrollPos++;
				vScrollPos = cursorPos.y - numOfLinesPerPage + 1;
			}
		}
	}
	
	protected void setHScrollPosFromMenuProblemList() {
		//if (isReadOnly) return;
		
		// 이동할 페이지의 widthOfTotalChars와 widthOfCharsPerPage을 알아야 한다.
		this.setHScrollBar();
		
		String str=null;
		paint.setTextSize(fontSize);
		IntegrationKeyboard keyboard = CommonGUI.keyboard;
		if (keyboard==null) return;
		if (keyboardMode==Mode.Hangul && hangulMode!=Hangul.Mode.None) {
			str = textArray[cursorPos.y].substring(0, cursorPos.x+1).toString();
		}
		else {
			try{
			str = textArray[cursorPos.y].substring(0, cursorPos.x).toString();
			}catch(Exception e) {
				if (Common_Settings.g_printsLog) e.printStackTrace();
			}
		}
		float w = 0;
		try {
		w = paint.measureText(str);
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
		}
	
		// 현재 페이지의 처음과 마지막을 제외한 일반적인 부분에서 적용된다.
		widthOfhScrollPos = (int) (w-2*fontSize);
		// 현재 페이지의 마지막 너비 부분에서 적용된다.
		if (widthOfhScrollPos > this.widthOfTotalChars-this.widthOfCharsPerPage) {
			widthOfhScrollPos = this.widthOfTotalChars-this.widthOfCharsPerPage;
		}
		// 현재 페이지의 처음 너비 부분에서 적용된다.
		if (widthOfhScrollPos<0) widthOfhScrollPos=0;
		
	}
	
	/** 키보드에 키를 입력할 경우 호출한다.*/
	public void setHScrollPos() {
		
		//if (isReadOnly) return;
		float endOfWindow = widthOfhScrollPos+widthOfCharsPerPage;
		String str = null;
		try{
		paint.setTextSize(fontSize);
		IntegrationKeyboard keyboard = CommonGUI.keyboard;
		if (keyboard==null) return;
		if (keyboardMode==Mode.Hangul && hangulMode!=Hangul.Mode.None) {
			str = textArray[cursorPos.y].substring(0, cursorPos.x+1).toString();
		}
		else {
			if (cursorPos.x<=0) str = "";
			else str = textArray[cursorPos.y].substring(0, cursorPos.x).toString();
		}
		}catch(Exception e) {
		}
		try{
		float w = paint.measureText(str);
		if (!(widthOfhScrollPos<=w && w<endOfWindow)) {
			// Backspace키를 눌러 스크롤 시작범위를 넘어선 경우
			if (w < widthOfhScrollPos) {
				widthOfhScrollPos = (int) (w-widthOfCharsPerPage+fontSize);
				if (widthOfhScrollPos<0) widthOfhScrollPos=0;
			}
			// 문자키를 눌러 스크롤 끝범위를 넘어선 경우
			else if (endOfWindow <= w){
				widthOfhScrollPos = (int) (w-widthOfCharsPerPage+fontSize);
				if (widthOfhScrollPos<0) widthOfhScrollPos=0;
			}
		}
		}catch(Exception e) {
		}
		
	}
	
	
	/** move to (cursorPosX, cursorPosY) and then CommonGUI.keyboard.setOnTouchListener(this)*/
	public void moveToCursorPos(int cursorPosX, int cursorPosY) {		
		this.moveToCursorPosY(cursorPosY);
		
		if (scrollMode==ScrollMode.Both) {
			//widthOfhScrollPos = cursorPos.x;
			this.cursorPos.x = cursorPosX;
			this.setHScrollPos();
			//setHScrollPosFromMenuProblemList();
			setHScrollBar();
		}
	}
	
	/** move to (0, cursorPosY) and then CommonGUI.keyboard.setOnTouchListener(this)*/
	public void moveToCursorPosY(int cursorPosY) {
		CommonGUI.keyboard.setOnTouchListener(this);
		
		cursorPos.x = 0;
		if (scrollMode==ScrollMode.VScroll) {
			cursorPos.y = getNumOfLines(0, cursorPosY) + 1;
		}
		else {
			cursorPos.y = cursorPosY;
			cursorPos.x = 0;
		}
		
		vScrollPos = cursorPos.y - this.numOfLinesPerPage/2;
		setVScrollBar();
	}
	
	public void vScrollPosToLastPage() {
		vScrollPos = numOfLines-1;
		this.cursorPos.x = 0;
		this.cursorPos.y = numOfLines-1;
		setVScrollPos();
		setVScrollBar();
		if (this.scrollMode==ScrollMode.Both) {
			widthOfhScrollPos = 0;
			setHScrollPos();
			setHScrollBar();
		}
		if (Common_Settings.CurrentSystem.equals(Common_Settings.CurrentSystemIsJava) &&
    			Common_Settings.settings.isTripleBuffering)  this.drawToImage(mCanvas);
	}
	
	public void hScrollPosToLast(int cursorPosY) {
		if (cursorPosY>=this.textArray.length) return;
		
		vScrollPos = cursorPosY;
		if (this.textArray[cursorPosY]!=null) {
			this.cursorPos.x = this.textArray[cursorPosY].length();
		}
		else {
			this.cursorPos.x = 0;
		}
		this.cursorPos.y = cursorPosY;
		setVScrollPos();
		setVScrollBar();
		if (this.scrollMode==ScrollMode.Both) {
			setHScrollPos();
			setHScrollBar();
		}
		if (Common_Settings.CurrentSystem.equals(Common_Settings.CurrentSystemIsJava) &&
    			Common_Settings.settings.isTripleBuffering)  this.drawToImage(mCanvas);
	}
	
	/** 수직 스크롤부분이 바뀔 경우 호출한다. 예를 들어 vScrollPos, bounds가 바뀔경우*/
	public void setVScrollBar() {
		
		if (this.isSingleLine) {
			numOfLinesPerPage = 1;
		}
		else {
			numOfLinesPerPage = (int)(rationalBoundsHeight / lineHeight);
			if (numOfLinesPerPage<=0) numOfLinesPerPage = 1;
		}
		
		//if (numOfLines>numOfLinesPerPage) {
			if (vScrollPos+numOfLinesPerPage>=numOfLines)
				vScrollPos = numOfLines - numOfLinesPerPage;
		//}
		if (vScrollPos<0) vScrollPos = 0;
		
		
		vScrollBar.setVScrollBar(numOfLinesPerPage, numOfLines, vScrollPos, 1);	
	
	}
	
	
	/** 보이는부분(page)에서만 maxLineWidth(가장 긴 라인의 너비)를 계산한다.
	 * setHScrollBar를 호출하기 전에 setVScrollBar를 호출하여 vScrollPos와 numOfLinesInPage이
	 * 결정되어 있어야 한다.
	 * 수평 스크롤부분이 바뀔 경우 호출한다. 예를 들어 수직 스크롤시, bounds가 바뀔경우
	 * 주의사항 : 문서의 페이지의 최대 수평량을 10문자 정도 늘린다. 
	 * 왜냐하면 수평스크롤시 끝부분에서 1문자 반정도가 짤리기 때문이다.*/
	public void setHScrollBar() {		
		
		paint.setTextSize(fontSize);
		int i;
		float maxLineWidth=0, lineWidth=0;
		int limit = Math.min(vScrollPos+this.numOfLinesPerPage, this.numOfLines);
		for (i=vScrollPos; i<limit; i++) {
			if (textArray[i]==null) {
				lineWidth=0;
			}
			else {
				lineWidth = paint.measureText(textArray[i].toString());
			}
			if (lineWidth>maxLineWidth) {
				lineNumOfMaxWidth = i;
				maxLineWidth = lineWidth;
			}
		}
		// 문서의 페이지의 최대 수평량을 10문자 정도 늘린다. 
		// 왜냐하면 수평스크롤시 끝부분에서 1문자 반정도가 짤리기
		// 때문이다.
		this.maxLineWidth = maxLineWidth;
		
		widthOfTotalChars = (int) this.maxLineWidth;
		widthOfCharsPerPage = (int) rationalBoundsWidth;
				
		// widthOfTotalChars을 계산한 후에 widthOfhScrollPos을 다시 계산한다. 
		// 즉, setHScrollPos 제일 마지막 부분에서 widthOfhScrollPos을 계산하는 것이 아니라 
		// 여기에서 계산한다.
		//widthOfTotalChars는 페이지 내에서의 최대 글자수
		if (widthOfhScrollPos > widthOfTotalChars - widthOfCharsPerPage)
			widthOfhScrollPos = widthOfTotalChars - widthOfCharsPerPage;		
		if (widthOfhScrollPos<0) widthOfhScrollPos = 0;
		
				
		hScrollBar.setHScrollBar(widthOfCharsPerPage,
				widthOfTotalChars, widthOfhScrollPos, widthOfhScrollInc);
		
	}
	

	
	/** 스크롤바의 ActionCapture처리 : ActionDown(drag시작지점이 editText,scrollBar인가)을 활용하여 editText가
	 * action capture(자기영역을 벗어난 ActionMove를 자신이 가져간다)할지 안할지 결정한다.*/
	public boolean onTouch(MotionEvent event, SizeF scaleFactor) {
		boolean r = false;		
		if (event.actionCode==MotionEvent.ActionDown || event.actionCode==MotionEvent.ActionDoubleClicked) {
			if (hides) return false;
			if (hasToolbarAndMenuFontSize) {
				r = toolbar.onTouch(event, scaleFactor);
		    	if (r) return true;
			}
			if (this.showsMDITabList) {
				if (this.mDITabList!=null) {
					r = mDITabList.onTouch(event, scaleFactor);
					if (r) return true;
				}
			}
			if (this.getShowsCurPath()) {
				if (CurPathText.editTextCurPath!=null) {
					r = CurPathText.editTextCurPath.onTouch(event, scaleFactor);
					if (r) return true;
				}
    		}
	    	
			if (!super.onTouch(event, scaleFactor))     		
				return false;
	    	
			r = vScrollBar.onTouch(event, scaleFactor);
			if (r) {
				return true;
			}
			
			if (scrollMode==ScrollMode.Both) {
				if (hScrollBar!=null) {
					r = hScrollBar.onTouch(event, scaleFactor);				
					if (r) {
						return true;
					}
				}
			}
			
			
			
			isSelected = true;
			
			// 통합키보드의 LangDialog의 editText만 제외하고 
			// isReadOnly(읽기모드)와는 상관없이 모든 EditText에 터치하기만하면
			// 키보드의 리스너가 되도록 한다.
			//if (Common_Settings.settings.isKeyboardEnable) {
				if (this.iName!=CommonGUI.keyboard.langDialog.editTextLang.iName) {
					CommonGUI.keyboard.setOnTouchListener(this);
					IntegrationKeyboard.EditTextOfLangDialogIsTouched = false;
				}
				else {
					IntegrationKeyboard.EditTextOfLangDialogIsTouched = true;
				}
			//}
			
			
			
			// onTouchEvent에서 커서위치를 바꾼후(vScrollPos설정) editText의 bounds를 바꾸고 키보드를 보여준다.
			// 다시 말해 순서가 중요하다.
			// 간혹 onTouchEvent에서 log메시지가 열린 후 키보드가 열림으로 인해 
			// log가 키보드에 의해 짤리는 경우가 발생한다.
						
			onTouchEvent(this, event);
			
			if (Common_Settings.settings.EnablesScreenKeyboard) {
				if (!isReadOnly) {
					
					
					if (!isSingleLine) {
						if (isMaximized()) {
							Rectangle newBoundsOfEditText = new Rectangle(this.totalBounds.x, totalBounds.y, totalBounds.width, /*prevSize.height*/(int)(Control.view.getOriginalHeight()*0.5f));
							changeBounds(newBoundsOfEditText);
							changeBoundsOfKeyboardAndSizingBorder(newBoundsOfEditText);
							isMaximized = false;
						}
						else {
							changeBoundsOfKeyboardAndSizingBorder(bounds);
			    		}
					}
					// isSingleLine이 true일 때도 키보드를 보여준다.
					CommonGUI.keyboard.setHides(false);
				}
			}//if (Common_Settings.settings.isKeyboardEnable) {
			
			Control.capturedControl = this;
			
			
			return true;
		}
		else if (event.actionCode==MotionEvent.ActionMove || 
				event.actionCode==MotionEvent.ActionUp) {
			if (event.actionCode==MotionEvent.ActionUp) {
			}
			// drag시작이 scrollBar이면 scrollBar가, editText라면 editText가 핸들링
			if (Control.capturedControl==this) {
				// 영역내에서 터치를 하여 캡쳐를 하면 CustomView에서 ActionMove를 전달하여 스크롤을 하게 된다.
				// 영역검사를 하지않고 영역을 벗어나더라도 자신이 핸들링한다.
				onTouchEvent(this, event);
				return true;
			}
						
		}
		return false;
    }
	
	public void setScrollMode(ScrollMode mode) {
		scrollMode = mode;
		CommonGUI.loggingForMessageBox.setText(true, "Loading...", false);
		CommonGUI.loggingForMessageBox.setHides(false);
		SetTextThread thread = new SetTextThread(this, true);
		thread.start();
		
		// 모드를 바꾸면 undo버퍼를 초기화한다.
		undoBuffer.reset();
		return;
	}
	
	
	int getNumOfNewLineChar(Point p0, Point p1) {
		if (this.scrollMode==ScrollMode.Both) {
			return p1.y - p0.y;
		}
		else {
			return -1;
		}		
	}
	
	/** text내에서 '\n'의 개수를 리턴한다.*/
	public int getNumOfNewLineChar(CodeString text) {
		int i;
		int r = 0;
		for (i=0; i<text.length(); i++) {
			if (text.charAt(i).c=='\n') {
				r++;
			}
		}
		return r;
	}
	
	/** text내에서 '\n'의 개수를 리턴한다.*/
	int getNumOfNewLineChar(String text) {
		int i;
		int r = 0;
		for (i=0; i<text.length(); i++) {
			if (text.charAt(i)=='\n') {
				r++;
			}
		}
		return r;
	}
	
	/** initCursorPos에서 text를 더했을때 커서위치를 구한다.*/
	Point getRelativeCursorPos(Point initCursorPos, String text) {
		int i;
		Point r = new Point(initCursorPos.x,initCursorPos.y);
		for (i=0; i<text.length(); i++) {
			if (text.charAt(i)=='\n') {
				r.y++;
				r.x = 0;
			}
			else if (text.charAt(i)=='\r') {
			}
			else {
				r.x++;
			}
		}
		return r;
	}
	
	
	
	/** ScrollMode가  Both일 때 폰트크기변경, bounds크기 변경을 하면  setText와  cursor를 초기화할 필요가 없다.*/
	static class SetTextThread extends Thread {
		boolean initCursor;
		EditText owner;
		SetTextThread(EditText owner, boolean initCursor) {
			this.initCursor = initCursor;
			this.owner = owner;
		}
		public void run() {
			CommonGUI.loggingForMessageBox.setText(true, "Loading...", false);
			CommonGUI.loggingForMessageBox.setHides(false);
			
			if (initCursor) {
				owner.bound(BoundMode.SetText, true);
			}
			else {
				owner.bound(BoundMode.SetText, false);
			}
			
			CodeString text = owner.TextArrayToText(0, 0, 0, 0);			
			owner.setText(0, text);
			
			CommonGUI.loggingForMessageBox.setHides(true);
			Control.view.postInvalidate();
			
		}
	}
	
	
	
	/** Point[]인 ArrayList를 복제해서 리턴한다.*/
	ArrayList getClone(ArrayList listFindPos) {
		int i;
		ArrayList r = new ArrayList(listFindPos.count);
		for (i=0; i<listFindPos.count; i++) {
			Point p = (Point) listFindPos.getItem(i);
			r.add(new Point(p.x, p.y));
		}
		return r;
	}
	
	

	/** EditText의 이벤트 리스너, 이후에 draw가 호출된다*/
	public void editText_Listener(Object sender, MotionEvent e) {
		FunctionOfEditText.editText_Listener(this, sender, e);
	}
	
	public void fontSizeMenu_Listener(Object sender, String strFontSize) {
		FunctionOfEditText.fontSizeMenu_Listener(this, sender, strFontSize);
	}
	
	
	/** hasToolbarAndMenuFontSize이 true인 editText(즉 singleLine editText는 불가능하다)만 
	 * 호출이 가능하다.*/
	public void functionMenu_Listener(Object sender, String strMenuName) {
		FunctionOfEditText.functionMenu_Listener(this, sender, strMenuName);
	}
	
	public void toolbar_Listener(Object sender, String buttonName) {
		FunctionOfEditText.toolbar_Listener(this, sender, buttonName);
	}
	
	
	public void integrationKeyboard_Listener(Object sender, MotionEvent e) {
		FunctionOfEditText.integrationKeyboard_Listener(this, sender, e);
	}
	
	
	public void findReplaceDialog_Listener(Object sender, MotionEvent e) {
		FunctionOfEditText.findReplaceDialog_Listener(this, sender, e);
	}
	
	
		
	public void onTouchEvent(Object sender, MotionEvent e) {
		
		
		try {
			if (sender==this) {
				if (this.name.equals("DebugView")) {
					int a;
					a=0;
					a++;
				}
				editText_Listener(sender, e);
				callTouchListener(this, e);
			}
			else {
				if (sender instanceof Button) {
					int i;
					Button button = (Button)sender;
					
					for (i=0; i<namesOfButtonsOfToolbar.length; i++) {
						//if (button.name.equals(namesOfButtonsOfToolbar[i])) {
						if (button.iName==toolbar.buttons[i].iName) {
							toolbar_Listener(button, button.name);
							return;
						}
					}
					
					//"10", "14", "18", "22", "26", "30", "기타"
					for (i=0; i<Edit.Menu_FontSize.length; i++) {	// 메뉴버튼
						//if (button.name.equals(Menu_FontSize[i])) {
						if (button.iName==Edit.menuFontSize.buttons[i].iName) {	
							fontSizeMenu_Listener(button, Edit.Menu_FontSize[i]);
							return;
						} 
					}
					
					for (i=0; i<Edit.Menu_Function.length; i++) {	// 메뉴버튼
						//if (button.name.equals(Menu_FontSize[i])) {
						if (button.iName==Edit.menuFunction.buttons[i].iName) {	
							functionMenu_Listener(button, Edit.Menu_Function[i]);
							return;
						} 
					}
				}
				else if (sender instanceof VScrollBarLogical) {
					VScrollBarLogical vScrollBar = (VScrollBarLogical)sender;
					this.vScrollPos = vScrollBar.vScrollPos;
					setVScrollBar();
					// 수직 스크롤바 터치시 수평스크롤 부분도 바뀌므로 호출해야 한다.
					if (scrollMode==ScrollMode.Both) {
						setHScrollBar();
					}
				}
				else if (sender instanceof HScrollBar) {
					HScrollBar hScrollBar = (HScrollBar)sender;
					// 수평 스크롤바 터치시 수직스크롤 부분은 바뀌지 않으므로 호출하지 않는다.
					//setVScrollBar();
					this.widthOfhScrollPos = hScrollBar.widthOfScrollPos;
					setHScrollBar();
					
				}
				else if (sender instanceof FontSizeDialog) {
					fontSizeMenu_Listener(sender, Edit.fontSizeDialog.curText);
				}
				else if (sender instanceof FindReplaceDialog) {
					this.findReplaceDialog_Listener(sender, e);
				}
			
				else if (sender instanceof IntegrationKeyboard) {
					this.integrationKeyboard_Listener(sender, e);
				} // if (className.equals(IntegrationKeyboard))				
			}
		}catch (Exception e1) {
			e1.printStackTrace();
			CompilerHelper.printStackTrace(textViewLogBird, e1);
		}
		finally {
			try {
			if (Common_Settings.CurrentSystem.equals(Common_Settings.CurrentSystemIsJava) &&
	    			Common_Settings.settings.isTripleBuffering)  this.drawToImage(mCanvas);
			}catch(Exception e2) {
				e2.printStackTrace();
			}
		}
		
	}
	
	public String getCurChar() {
		if (cursorPos.x<textArray[cursorPos.y].length()) {
			return textArray[cursorPos.y].substring(cursorPos.x, cursorPos.x+1).toString();
		}
		return null;
	}
	
	public void getCursorPos(MotionEvent e) {
		if (cursorPos.y<0) cursorPos.y=0;
		if (cursorPos.y>=numOfLines) cursorPos.y=numOfLines-1;
		
		paint.setTextSize(fontSize);
		
		if (scrollMode==ScrollMode.VScroll) {
			cursorPos.y = (int)((e.y - bounds.y) / /*fontSize*/lineHeight) + vScrollPos;
			if (cursorPos.y>=numOfLines) cursorPos.y = numOfLines-1;
			if (cursorPos.y<0) cursorPos.y = 0; 
			int i;
			float lineWidth = bounds.x + gapX;
			
			int lineLen = textArray[cursorPos.y].length();
			String charA=null;
			for (i=0; i<lineLen; i++) {
				charA = textArray[cursorPos.y].substring(i, i+1).toString();
				if (charA.equals(Edit.NewLineChar)) break;
				lineWidth += paint.measureText(charA);
				if (e.x<=lineWidth) {				
					break;
				}
			}
			String lastChar = charA;
			if (lineLen==0) cursorPos.x = 0;
			else {	// lineLen>0
				if (i < lineLen) {
					if (i==0) cursorPos.x = 0;
					else {	// 0<i && i<lineLen		문자열 클릭
						if (lastChar.equals(Edit.NewLineChar)) {
							// 커서는 \n을 가리킨다.
							cursorPos.x = i;
						}
						else {
							cursorPos.x = i;
						}
					}
				}
				else {	// i==lineLen 문자열을 넘어서 클릭
					if (lastChar.equals(Edit.NewLineChar)) {
						// 커서는 \n을 가리킨다.
						cursorPos.x = (lineLen-1);
					}					
					else cursorPos.x = lineLen;
				}
			}
		}
		else if (scrollMode==ScrollMode.Both) {
		
			cursorPos.y = (int)((e.y - bounds.y) / lineHeight) + vScrollPos;
			if (cursorPos.y>=numOfLines) cursorPos.y = numOfLines-1;
			if (cursorPos.y<0) cursorPos.y = 0; 
			int i;
			float eventXRelative = e.x-(bounds.x+gapX); 
			float lineWidth = 0;
			
			int lineLen = textArray[cursorPos.y].length();
			String charA=null;
			for (i=0; i<lineLen; i++) {
				charA = textArray[cursorPos.y].substring(i, i+1).toString();
				if (charA.equals(Edit.NewLineChar)) {
					break;
				}
				lineWidth += paint.measureText(charA);
				if (widthOfhScrollPos+eventXRelative <= lineWidth) {				
					break;
				}
			}
			String lastChar = charA;
			if (lineLen==0) {
				cursorPos.x = 0;
			}
			else {	// lineLen>0
				if (i < lineLen) {
					if (lastChar.equals(Edit.NewLineChar)) {
						// 커서는 \n을 가리킨다.
						cursorPos.x = i;
					}						
					else cursorPos.x = i;
				}
				else {	// i==lineLen 문자열을 넘어서 클릭
					
					if (lastChar.equals(Edit.NewLineChar)) {
						// 커서는 \n을 가리킨다.
						cursorPos.x = (lineLen-1);
					}					
					else cursorPos.x = lineLen;
				}
			}
		}//if (scrollMode==ScrollMode.Both)
	}
	
	public boolean endsWithNewLineChar(String lineText) {
		int lineLen = lineText.length();
		if (lineLen > 0) {
			if (lineText.substring(lineLen-1, lineLen).equals(Edit.NewLineChar)) {
				return true;
			}
			return false;
		}
		return false;		
	}
	
	/** \r\n을 제거한다. \r은 있으면 지운다.*/
	CodeString deleteNewLineChar(CodeString lineText) {
		int lineLen = lineText.length();
		CodeString newLine;
		if (lineLen > 0) {
			if (lineText.substring(lineLen-1, lineLen).toString().equals(Edit.NewLineChar)) {
				if (lineLen > 1)
					newLine = lineText.substring(0, lineLen-1);
				else 
					newLine = new CodeString("", textColor);
			}
			else {
				newLine = lineText;
			}
		}
		else {
			newLine = new CodeString("", textColor);
		}
		lineLen = newLine.length();
		if (lineLen > 0) {
			if (newLine.substring(lineLen-1, lineLen).toString().equals("\r")) {
				if (lineLen > 1)
					return newLine.substring(0, lineLen-1);
				else 
					return new CodeString("", textColor);
			}
			else {
				return newLine;
			}
		}
		else {
			return new CodeString("", textColor);
		}
	}
	
	
	PartOfStr getStringHScroll(CodeString str) {
		if (str==null) {
			return null;
		}
		try{
		int start=-1, end=-1;
		float w=0;
		part1OfChar=0;
		part2OfChar=0;
		w= widthOfhScrollPos;
		int i;
		float lineWidth=0;
		
		paint.setTextSize(fontSize);
		
		for (i=0; i<str.length(); i++) {
			CodeString charA = str.substring(i, i+1);
			float wOfCharA = paint.measureText(charA.toString()); 
			lineWidth += wOfCharA;
			if (lineWidth>w) {
				start = i;
				part2OfChar = lineWidth-w;
				part1OfChar = wOfCharA-part2OfChar;
				break;
			}
		}
		int startIndex;
		if (part1OfChar==0) {
			startIndex = start;
			lineWidth = 0;
			part2OfChar = 0;
		}
		else {
			startIndex = start+1;
			lineWidth = part2OfChar;
			end = start;
		}
		if (start!=-1) {
			for (i=startIndex; i<str.length(); i++) {
				CodeString charA = str.substring(i, i+1);
				lineWidth += paint.measureText(charA.toString());
				if (lineWidth<=rationalBoundsWidth) {
					end = i;
				}				
				else {
					end = i;
					break;
				}
			}
		}
		if (start==-1 || end==-1) {
			return new PartOfStr(new CodeString("", textColor),start,end);
		}
		else {
			return new PartOfStr(str.substring(start, end+1), start, end);
		}
		}catch(Exception e) {
			//Log.e("getStringHScroll", e.toString());
			if (Common_Settings.g_printsLog) e.printStackTrace();
			if (Common_Settings.g_printsLog) CompilerHelper.printStackTrace(textViewLogBird, e);
			return null;
		}
			
	}
	
	class PartOfStr {
		CodeString str;
		int start=-1;
		int end=-1;
		
		PartOfStr(CodeString str, int start, int end) {
			this.str = str;
			this.start = start;
			this.end = end;
		}
	}
	
	CodeString getStringHScrollAndCursorVisuablity(CodeString str) {
		try{
		int start=-1, end=-1;
		if (str.toString().equals("") || str.toString().equals("\n")) {			
			if (widthOfhScrollPos>=fontSize) {
				isCursorSeen = false;
				return new CodeString("", textColor);
			}
			else {
				start = 0;
				end = 0;				
			}
		}
		else {		
			PartOfStr result = getStringHScroll(str);
			start = result.start;
			end = result.end;
		}
		
				
		if (start==-1 || end==-1) {
			isCursorSeen = false;
			return new CodeString("", textColor);
		}
		else {
			int endIndex;
			IntegrationKeyboard keyboard = CommonGUI.keyboard;
			if (keyboard.mode==Mode.Hangul && Hangul.mode!=Hangul.Mode.None) {
				endIndex = end;
			}
			else {
				endIndex = end+1;
			}
			//endIndex = end+1;
			if (start<=cursorPos.x && cursorPos.x<=endIndex) {
				isCursorSeen = true;
				valueOfCursorRelativeToHScroll = 0;
				return str.substring(start, cursorPos.x);
			}
			else {
				if (cursorPos.x<start) valueOfCursorRelativeToHScroll = -1;
				else valueOfCursorRelativeToHScroll = 1;
				isCursorSeen = false;
				return new CodeString("", textColor);
			}
		}
		}catch(Exception e) {
			//Log.e("getStringHScrollAndCursorVisuablity", e.toString());
			if (Common_Settings.g_printsLog) e.printStackTrace();
			if (Common_Settings.g_printsLog) CompilerHelper.printStackTrace(textViewLogBird, e);
			return null;
		}
	}
	
	/** CustomView의 비트맵에 컨트롤이 갖는 bitmapForRendering 비트맵(트리플 버퍼링)과 이것과 분리되어 있는 툴바 비트맵을 그린다.
     * @param canvas : CustomView의 mCanvas(내부에 비트맵을 가지므로 더블버퍼링이다.)*/
	public synchronized void draw(Canvas canvas) {
		if (this instanceof TextView) {
		}
		if (Common_Settings.CurrentSystem.equals(Common_Settings.CurrentSystemIsJava) &&
    			Common_Settings.settings.isTripleBuffering) {
			Rect src = (new Rectangle(0,0,bounds.width,bounds.height)).toRect();
			
			RectF dst = this.bounds.toRectF();
			canvas.drawBitmap(this.bitmapForRendering, src, dst, paint);
			
			if (hasToolbarAndMenuFontSize) {
				toolbar.incxForBitmapRendering = (int) this.bounds.x;
				toolbar.incyForBitmapRendering = (int) this.bounds.y;
				toolbar.draw(canvas);
			}
			
			if (this.showsMDITabList) {
				if (mDITabList!=null) {
					mDITabList.draw(canvas);
				}
			}
			
			if (this.getShowsCurPath()) {
				if (CurPathText.editTextCurPath!=null) {
					CurPathText.editTextCurPath.draw(canvas);
				}
			}
		}
		else {
			drawCommon(canvas);
			
			if (hasToolbarAndMenuFontSize) {
				toolbar.draw(canvas);
			}
			
			if (this.showsMDITabList) {
				if (mDITabList!=null) {
					mDITabList.draw(canvas);
				}
			}
			if (this.getShowsCurPath()) {
				if (CurPathText.editTextCurPath!=null) {
					CurPathText.editTextCurPath.draw(canvas);
				}
			}
		}
	}
	
	/**isTripleBuffering이 true이면 mCanvas 안에 있는 bitmapForRendering 비트맵에 그린다. 
     * 비트멥은 원점부터 시작하므로 bounds에서 bounds.x와 bounds.y를 빼서 그려야 비트맵에 그릴 수 있다.<br>
     * isTripleBuffering이 false이면 현재 bounds에 그린다.
     *  @param canvas : isTripleBuffering이 true이면 컨트롤이 갖고 있는 mCanvas이고<br>
     *  CustomView의 mCanvas(내부에 비트맵을 가지므로 더블버퍼링이다.)
     *  */
	protected void drawCommon(Canvas canvas) {
		//synchronized(this) {
			try{
				int i, j;
				float x, y, w;
				
				if (CommonGUI.editText_compiler!=null && this.iName==CommonGUI.editText_compiler.iName) {
					int a;
					a=0;
					a++;
				}
				
				if (textArray==null) {			
					this.textArray = new CodeString[10];
				}
				if ((textArray[0]==null || this.numOfLines==0)) {
					textArray[0] = new CodeString("", Common_Settings.textColor);
					initCursorAndScrollPos();
					this.numOfLines = 1;
					this.isSelecting = false;
				}
				
				if (this.name.equals("CurPath")) {
					int a;
					a=0;
					a++;
				}
				String color = ColorEx.toString(backColor);
				
				
				paint.setColor(backColor);
				paint.setTextSize(fontSize);
				
				canvas.save();
					
				RectF rectBounds;
				if (Common_Settings.CurrentSystem.equals(Common_Settings.CurrentSystemIsJava) &&
		    			Common_Settings.settings.isTripleBuffering) {
					rectBounds = RectangleF.toRectF(bounds, this.bounds.x , this.bounds.y);
				}
				else {
					rectBounds = bounds.toRectF();
				}
				canvas.drawRect(rectBounds, paint);
				paintOfBorder.setColor(ColorEx.reverseColor(backColor));
		    	canvas.drawRect(rectBounds, paintOfBorder);   	
		    	
		    	
		    	Rect clipRect = new Rect();
		    	clipRect.left = (int) (bounds.x+1+gapX); 
		    	clipRect.top = (int)(bounds.y+1);
		    	
		    	if (scrollMode==ScrollMode.VScroll) {
		    		if (isSingleLine) {
		    			clipRect.right = (int) (bounds.right()-gapX);
		    		}
		    		else {
		    			clipRect.right = (int) (bounds.right()-vScrollBarWidth-gapX);
		    		}
		    		clipRect.bottom = (int) (bounds.bottom());
		    	}
		    	else {
		    		if (isSingleLine) {
		    			clipRect.right = (int) (bounds.right()-gapX);
		    			clipRect.bottom = (int) (bounds.bottom());
		    		}
		    		else {
		    			clipRect.right = (int) (bounds.right()-vScrollBarWidth-gapX);
		    			clipRect.bottom = (int) (bounds.bottom()-hScrollBarHeight);
		    		}
		    	}
		    	if (Common_Settings.CurrentSystem.equals(Common_Settings.CurrentSystemIsJava) &&
		    			Common_Settings.settings.isTripleBuffering) {
		    		clipRect = Rectangle.toRect(clipRect, (int)this.bounds.x, (int)this.bounds.y);
		    	}
		    	if (!canvas.clipRect(clipRect, Region.Op.REPLACE)) {
		    		Log.e("editText onDraw","No clipping");
		    	}
		    	
		    	try {
					
					
					if (isSelecting) {					
						Point[] intersectedSelect = FunctionOfEditText.getIntersectWithSelect(this, true);
						if (intersectedSelect!=null && intersectedSelect.length!=0) {
							for (i=0; i<intersectedSelect.length; i+=2) {
								j = intersectedSelect[i].y;
								y = bounds.y + (intersectedSelect[i].y-vScrollPos) * lineHeight + descent;
								if (Common_Settings.CurrentSystem.equals(Common_Settings.CurrentSystemIsJava) &&
						    			Common_Settings.settings.isTripleBuffering)  {
									y -= this.bounds.y;
								}
								
								//float w;
								float x2;
								float selectHeight = lineHeight;
								RectangleF dst = null;
								
								if (selectLenY==1 && intersectedSelect[i+1].y==Select_FirstLine) {
									
									CodeString cstr = textArray[j].substring(0, intersectedSelect[0].x);
									if (cstr!=null) {
										String str = cstr.str;
										x = bounds.x + gapX + paint.measureText(str);
										
										String str2;
										if (intersectedSelect[1].x+1<=textArray[j].length())
											str2 = textArray[j].substring(0, intersectedSelect[1].x+1).toString();
										else 
											str2 = textArray[j].substring(0, intersectedSelect[1].x).toString();
										x2 = bounds.x + gapX + paint.measureText(str2);
										if (scrollMode==ScrollMode.Both) {
											x -= this.widthOfhScrollPos;
											x2 -= this.widthOfhScrollPos;								
										}
										w = x2 - x;
										if (Common_Settings.CurrentSystem.equals(Common_Settings.CurrentSystemIsJava) &&
								    			Common_Settings.settings.isTripleBuffering)  x -= this.bounds.x;
										dst = new RectangleF(x, y, w, selectHeight);
									}
								}
								else if (selectLenY>1 && intersectedSelect[i+1].y==Select_FirstLine) {
									
									String str = textArray[j].substring(0, intersectedSelect[0].x).toString();
									if (str!=null) {
										x = bounds.x + gapX + paint.measureText(str);
										if (scrollMode==ScrollMode.Both) {
											x -= this.widthOfhScrollPos;
											if (x<bounds.x+gapX) x = 0;
										}
										
										w = (bounds.x + bounds.width - vScrollBarWidth) - x;
										if (Common_Settings.CurrentSystem.equals(Common_Settings.CurrentSystemIsJava) &&
								    			Common_Settings.settings.isTripleBuffering)  x -= this.bounds.x;
										dst = new RectangleF(x, y, w, selectHeight);
									}
								}
								else if (selectLenY>1 && intersectedSelect[i+1].y==Select_MiddleLine) {
									x = bounds.x;
									w = (bounds.x + bounds.width - vScrollBarWidth) - x;
									if (Common_Settings.CurrentSystem.equals(Common_Settings.CurrentSystemIsJava) &&
							    			Common_Settings.settings.isTripleBuffering)  x -= this.bounds.x;
									dst = new RectangleF(x, y, w, selectHeight);
								}
								else if (selectLenY>1 && intersectedSelect[i+1].y==Select_LastLine) {
									String str;
									if (intersectedSelect[intersectedSelect.length-1].x+1<=textArray[j].length())
										str = textArray[j].substring(
												0, intersectedSelect[intersectedSelect.length-1].x+1).toString();
									else 
										str = textArray[j].substring(
												0, intersectedSelect[intersectedSelect.length-1].x).toString();
									if (str!=null) {
										x = bounds.x;
										w = (bounds.x + gapX + paint.measureText(str)) - x;
										if (scrollMode==ScrollMode.Both) {
											w -= this.widthOfhScrollPos;
										}
										if (Common_Settings.CurrentSystem.equals(Common_Settings.CurrentSystemIsJava) &&
								    			Common_Settings.settings.isTripleBuffering)  x -= this.bounds.x;
										dst = new RectangleF(x, y, w, selectHeight);
									}
								}
								if (dst!=null) {								
									paint.setColor(Edit.selectColor);
									//paint.setAlpha(80);								 
									canvas.drawRect(dst.toRectF(), paint);
									//paint.setAlpha(255);
								}
								dst = null;
							}
						}
					}
					
					if (isFound) {
						Point[] intersectedSelect = FunctionOfEditText.getIntersectWithSelect(this, false);
						if (intersectedSelect!=null && intersectedSelect.length!=0) {
							for (i=0; i<intersectedSelect.length; i+=2) {
								j = intersectedSelect[i].y;
								y = bounds.y + (intersectedSelect[i].y-vScrollPos) * lineHeight + descent;
								if (Common_Settings.CurrentSystem.equals(Common_Settings.CurrentSystemIsJava) &&
						    			Common_Settings.settings.isTripleBuffering)  y -= this.bounds.y;
								
								//float w;
								float x2;
								float findHeight = lineHeight;
								RectangleF dst = null;
								
								if (findLenY==1 && intersectedSelect[i+1].y==Select_FirstLine) {
									String str = textArray[j].substring(0, intersectedSelect[0].x).toString();
									if (str!=null) {
										x = bounds.x + gapX + paint.measureText(str);
										String str2;
										if (intersectedSelect[1].x+1<=textArray[j].length())
											str2 = textArray[j].substring(0, intersectedSelect[1].x+1).toString();
										else 
											str2 = textArray[j].substring(0, intersectedSelect[1].x).toString();
										x2 = bounds.x + gapX + paint.measureText(str2);
										if (scrollMode==ScrollMode.Both) {
											x -= this.widthOfhScrollPos;
											x2 -= this.widthOfhScrollPos;									
										}
										w = x2 - x;
										if (Common_Settings.CurrentSystem.equals(Common_Settings.CurrentSystemIsJava) &&
								    			Common_Settings.settings.isTripleBuffering)  x -= this.bounds.x;
										dst = new RectangleF(x, y, w, findHeight);
									}
								}
								else if (findLenY>1 && intersectedSelect[i+1].y==Select_FirstLine) {
									String str = textArray[j].substring(0, intersectedSelect[0].x).toString();
									if (str!=null) {
										x = bounds.x + gapX + paint.measureText(str);
										if (scrollMode==ScrollMode.Both) {
											x -= this.widthOfhScrollPos;
											if (x<bounds.x+gapX) x = 0;
										}
										w = (bounds.x + bounds.width - vScrollBarWidth) - x;
										if (Common_Settings.CurrentSystem.equals(Common_Settings.CurrentSystemIsJava) &&
								    			Common_Settings.settings.isTripleBuffering)  x -= this.bounds.x;
										dst = new RectangleF(x, y, w, findHeight);
									}
								}
								else if (findLenY>1 && intersectedSelect[i+1].y==Select_MiddleLine) {
									x = bounds.x;
									w = (bounds.x + bounds.width - vScrollBarWidth) - x;
									if (Common_Settings.CurrentSystem.equals(Common_Settings.CurrentSystemIsJava) &&
							    			Common_Settings.settings.isTripleBuffering)  x -= this.bounds.x;
									dst = new RectangleF(x, y, w, findHeight);
								}
								else if (findLenY>1 && intersectedSelect[i+1].y==Select_LastLine) {
									String str;
									if (intersectedSelect[intersectedSelect.length-1].x+1<=textArray[j].length())
										str = textArray[j].substring(
												0, intersectedSelect[intersectedSelect.length-1].x+1).toString();
									else 
										str = textArray[j].substring(
												0, intersectedSelect[intersectedSelect.length-1].x).toString();
									if (str!=null) {
										x = bounds.x;
										w = (bounds.x + gapX + paint.measureText(str)) - x;
										if (scrollMode==ScrollMode.Both) {
											w -= this.widthOfhScrollPos;
										}
										if (Common_Settings.CurrentSystem.equals(Common_Settings.CurrentSystemIsJava) &&
								    			Common_Settings.settings.isTripleBuffering)  x -= this.bounds.x;
										dst = new RectangleF(x, y, w, findHeight);
									}
								}
								if (dst!=null) {
									paint.setColor(Edit.foundColor);
									//paint.setAlpha(150);								 
									canvas.drawRect(dst.toRectF(), paint);
									//paint.setAlpha(255);
								}
								dst = null;
							}
						}
					}// if (isFound) {
					
					int lineY;
					
					paint.setTextSize(fontSize);
					paint.setColor(textColor);
		    		
		    		try{
			    		int limit = Math.min(vScrollPos+numOfLinesPerPage, numOfLines);
			    		
			    		if (scrollMode==ScrollMode.VScroll) {	    		
							for (i=vScrollPos, lineY=0; i<limit; 
									i++, lineY++) {
								x = bounds.x + gapX;
								y = bounds.y + (lineY+1) * lineHeight;
								if (Common_Settings.CurrentSystem.equals(Common_Settings.CurrentSystemIsJava) &&
						    			Common_Settings.settings.isTripleBuffering) {
									x -= this.bounds.x;
									y -= this.bounds.y;
								}
								
								CodeString lineText = textArray[i];
								if (lineText!=null) { 
									for (j=0; j<lineText.length(); j++) {
										CodeString c = lineText.substring(j, j+1);
										String charA = c.toString();
										if (charA.equals("\t")) {
											x += paint.measureText("\t");
										}
										else if (charA.equals(" ")) {
											x += paint.measureText(" ");
										}
										else if (charA.equals("\n") || charA.equals("\r")) continue;
										else {
											paint.setColor(c.charAt(0).color);								
											canvas.drawText(charA, x, y, paint);
											x += paint.measureText(charA);
										}
									}
								}
							}
			    		}
			    		else if (scrollMode==ScrollMode.Both) {
			    			int limit2 = Math.min(vScrollPos+numOfLinesPerPage, numOfLines);
			    			for (i=vScrollPos, lineY=0; i<limit2; i++, lineY++) {
								x = bounds.x + gapX;
								y = bounds.y + (lineY+1) * lineHeight;
								
								if (Common_Settings.CurrentSystem.equals(Common_Settings.CurrentSystemIsJava) &&
						    			Common_Settings.settings.isTripleBuffering) {
									x -= this.bounds.x;
									y -= this.bounds.y;
								}
								
								CodeString lineText = null;
								if (0<=i && i<textArray.length) {
									lineText = textArray[i];
								}
								if (lineText==null) {
									break;
								}
								PartOfStr lineTextHScroll = getStringHScroll(lineText);
								x -= part1OfChar;
								
								if (lineTextHScroll!=null) {
									int y_Underline = (int) (y + this.fontSize * 0.2f);
									
									for (j=0; j<lineTextHScroll.str.length(); j++) {
										CodeChar c = lineTextHScroll.str.charAt(j);
										if (c==null) {
											int a;
											a=0;
											a++;
										}
										float oldX = x;
										String charA = c.toString();
										if (c.c=='\t') {
											x += paint.measureText("\t");
										}
										else if (c.c==' ') {
											x += paint.measureText(" ");
										}
										else if (c.c=='\n' || c.c=='\r') {
											//continue;
										}
										else {
											paint.setColor(c.color);
											canvas.drawText(charA, x, y, paint);
											x += paint.measureText(charA);
										}
										if (c.getIsErrorChar()) {
											paint.setColor(Common_Settings.errorColor);										
											canvas.drawLine(oldX, y_Underline, x, y_Underline, paint);
										}
									}//for (j=0; j<lineTextHScroll.str.length(); j++) {
								}													
							} // for i
			    		}
		    		}catch(Exception e) {
						//Log.e("EditText Draw 텍스트그리기", e.toString());
		    			if (Common_Settings.g_printsLog) e.printStackTrace();
		    			if (Common_Settings.g_printsLog) CompilerHelper.printStackTrace(textViewLogBird, e);
					}
		    		
		    	 		
					
					canvas.restore();
					
					this.drawCursor(canvas);
					
					if (scrollMode==ScrollMode.Both) {
						if (Common_Settings.CurrentSystem.equals(Common_Settings.CurrentSystemIsJava) &&
				    			Common_Settings.settings.isTripleBuffering) {
							vScrollBar.incxForBitmapRendering = (int) this.bounds.x;
							vScrollBar.incyForBitmapRendering = (int) this.bounds.y;
						}
						else {
							vScrollBar.incxForBitmapRendering = 0;
							vScrollBar.incyForBitmapRendering = 0;
						}
						vScrollBar.draw(canvas);
						if (hScrollBar!=null) {
							if (Common_Settings.CurrentSystem.equals(Common_Settings.CurrentSystemIsJava) &&
					    			Common_Settings.settings.isTripleBuffering) {
								hScrollBar.incxForBitmapRendering = (int) this.bounds.x;
								hScrollBar.incyForBitmapRendering = (int) this.bounds.y;
							}
							else {
								hScrollBar.incxForBitmapRendering = 0;
								hScrollBar.incyForBitmapRendering = 0;
							}
							hScrollBar.draw(canvas);
						}
					}
					else {
						if (Common_Settings.CurrentSystem.equals(Common_Settings.CurrentSystemIsJava) &&
				    			Common_Settings.settings.isTripleBuffering) {
							vScrollBar.incxForBitmapRendering = (int) this.bounds.x;
							vScrollBar.incyForBitmapRendering = (int) this.bounds.y;
						}
						else {
							vScrollBar.incxForBitmapRendering = 0;
							vScrollBar.incyForBitmapRendering = 0;
						}
						vScrollBar.draw(canvas);
					}
		    		}catch(Exception e) {
		    			if (Common_Settings.g_printsLog) e.printStackTrace();
		    			if (Common_Settings.g_printsLog) CompilerHelper.printStackTrace(textViewLogBird, e);
					}
		    		
		    		if (!isSingleLine) {
			    		// 커서의 위치를 수평스크롤바 위에 그린다.
			    		float textSizeOfLoc = vScrollBar.bounds.width * 0.6f;
			    		paint.setTextSize(textSizeOfLoc);
			    		paint.setColor(Color.MAGENTA);
			    		// cursorPos는 0부터 시작이고 화면 커서라인은 1부터 시작한다.
			    		String loc = "(" + (cursorPos.x+1) + "," + (cursorPos.y+1) + ")";
			    		x = bounds.x + bounds.width/2 - paint.measureText(loc)/2;
			    		y = bounds.bottom()-textSizeOfLoc*0.3f;
			    		if (Common_Settings.CurrentSystem.equals(Common_Settings.CurrentSystemIsJava) &&
				    			Common_Settings.settings.isTripleBuffering) {
				    		x -= this.bounds.x;
				    		y -= this.bounds.y;
			    		}
			    		canvas.drawText(loc, x, y, paint);
		    		}
		    				
			}
			catch(Exception e) {
				if (Common_Settings.g_printsLog) e.printStackTrace();
				if (Common_Settings.g_printsLog) CompilerHelper.printStackTrace(textViewLogBird, e);
			}
			
		//}//synchronized
		
	}


	void drawCursor(Canvas canvas) {
		try {
			// 키보드의 listener가 자신이면 커서를 그린다.
			if (CommonGUI.keyboard!=null && this==CommonGUI.keyboard.listener) 
				isCursorSeen = true;
			else isCursorSeen = false;
			
			
			float x, y, w;
			
			// 키보드의 LangDialog의 editText가 터치되도라도 커서를 보여줘야 한다.
			if (IntegrationKeyboard.EditTextOfLangDialogIsTouched) {
				isCursorSeen = true;
			}
			
			if (textArray[cursorPos.y]==null) {
				int a;
				a=0;
				a++;
			}
			
			// 커서가 잘못된 것일 경우 예외 코드
			if (isCursorSeen && vScrollPos<=cursorPos.y && 
					cursorPos.y<vScrollPos+numOfLinesPerPage) {
				try {
	    		if (textArray[cursorPos.y]!=null && ((cursorPos.x<0 || cursorPos.x>textArray[cursorPos.y].length()))) {
	    			isCursorSeen = false;
	    		}
				}catch(Exception e) {
					if (Common_Settings.g_printsLog) e.printStackTrace();
				}
			}
			else {
				isCursorSeen = false;
			}
			
			
			
			if (isCursorSeen && vScrollPos<=cursorPos.y && 
					cursorPos.y<vScrollPos+numOfLinesPerPage) {
				
				String text;
				String curLine = null;
				if (cursorPos.y<this.numOfLines) {
					try {
						if (textArray[cursorPos.y]==null) curLine = "";
						else curLine = textArray[cursorPos.y].toString();
					}catch(Exception e) {
						if (Common_Settings.g_printsLog) e.printStackTrace();
					}
				}
				else {
					curLine = "";
				}
				int lineLen = 0;						
				lineLen = curLine!=null ? curLine.length() : 0;
				
				
				String curChar=null;
				//String lastChar=null;
				if (lineLen>0) {
					if (cursorPos.x<lineLen) {	
						text = curLine.substring(0, cursorPos.x);
						x = bounds.x + gapX + paint.measureText(text);
						curChar = curLine.substring(cursorPos.x,cursorPos.x+1);
						w = paint.measureText(curChar);							
					}
					else { // if (cursorPos.x>=lineLen)	
						text = curLine.substring(0, lineLen);
						x = bounds.x + gapX + paint.measureText(text);
						curChar = "";
						w = 0;
					}
				}
				else {	// if (lineLen<=0)
					if (scrollMode==ScrollMode.Both) {
						x = bounds.x + gapX;
						w = 0;
					}
					else {
						x = bounds.x + gapX;
						w = 0;
					}
					curChar = "";
				}
			
				
				if (isCursorSeen) {
					if (scrollMode==ScrollMode.Both) {
						x -= widthOfhScrollPos;
					}
					y = bounds.y + (cursorPos.y-vScrollPos) * lineHeight + descent;
					drawCursor(canvas, x, y, w, curChar);
				}//if (isCursorSeen) {
			}//if (isCursorSeen && vScrollPos<=cursorPos.y &&
		}catch(Exception e) {
			//if (Common_Settings.g_printsLog) e.printStackTrace();
		}
	}
	
	
	void drawCursor(Canvas canvas, float x, float y, float w, String curChar) {
		if ((CommonGUI.keyboard.mode==Mode.Hangul && !(Hangul.mode==Hangul.Mode.None)) 
				||  isReadOnly) {
			if (curChar!=null && !curChar.equals("") && !curChar.equals("\n")) {
				if (Common_Settings.CurrentSystem==Common_Settings.CurrentSystemIsAndroid) {
					// 한글이 조합중이거나 읽기모드이면
					RectangleF dst = new RectangleF(x, y, w, lineHeight);
					paint.setAlpha(100);
					canvas.drawRect(dst.toRectF(), paint);
					paint.setAlpha(255);
				}
				else { // 현재 시스템이 자바이면 알파가 불가능하므로 이렇게 한다.					
					if (Common_Settings.CurrentSystem.equals(Common_Settings.CurrentSystemIsJava) &&
			    			Common_Settings.settings.isTripleBuffering) {
						x -= this.bounds.x;
						y -= this.bounds.y;
					}
					RectangleF dst = new RectangleF(x, y, lineHeight*0.15f, lineHeight);
					paint.setColor(Edit.cursorColor);
					canvas.drawRect(dst.toRectF(), paint);
				}
			}//if (curChar!=null && !curChar.equals("") && !curChar.equals("\n")) {
			else { 
				// 읽기 모드인데 curChar가 \n이나 ""이더라도 커서를 보여줘야 한다.
				if (Common_Settings.CurrentSystem.equals(Common_Settings.CurrentSystemIsJava) &&
		    			Common_Settings.settings.isTripleBuffering) {
					x -= this.bounds.x;
					y -= this.bounds.y;
				}
				RectangleF dst = new RectangleF(x, y, lineHeight*0.15f, lineHeight);
				paint.setColor(Edit.cursorColor);
				canvas.drawRect(dst.toRectF(), paint);
			}
		}//if ((CommonGUI.keyboard.mode==Mode.Hangul && !(Hangul.mode==Hangul.Mode.None)) 
		 //||  isReadOnly) {
		else {
			// 한글이 조합중도 아니고 읽기모드도 아닌 경우							
			if (Common_Settings.CurrentSystem.equals(Common_Settings.CurrentSystemIsJava) &&
	    			Common_Settings.settings.isTripleBuffering) {
				x -= this.bounds.x;
				y -= this.bounds.y;
			}
			RectangleF dst = new RectangleF(x, y, lineHeight*0.15f, lineHeight);
			paint.setColor(Edit.cursorColor);
			canvas.drawRect(dst.toRectF(), paint);
		}//else
	}
	
	
	/**mCanvas 안에 있는 bitmapForRendering 비트맵에 그린다. 
     * 비트멥은 원점부터 시작하므로 bounds에서 bounds.x와 bounds.y를 빼서 그려야 비트맵에 그릴 수 있다.
     *  @param canvas : 컨트롤이 갖고 있는 mCanvas
     *  */
	public synchronized void drawToImage(Canvas canvas) {
		if (canvas==null) return;
		
		drawCommon(canvas);
		
	}//draw
	public void destroy() {
		
		
	}

}