package com.gsoft.common.gui.edittext;

import android.graphics.Point;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.CommonGUI;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.EditText_Compiler;
import com.gsoft.common.gui.edittext.Edit.ScrollMode;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListCodeChar;
import com.gsoft.common.util.ArrayListString;

import com.gsoft.common.gui.edittext.EditText;
import com.gsoft.common.gui.edittext.FunctionOfEditText;
import com.gsoft.common.gui.edittext.UndoOfEditText;
import com.gsoft.common.gui.edittext.Edit;

public class FindReplaceOfEditText {
	EditText owner;
	
	FindReplaceOfEditText(EditText owner) {
		this.owner = owner;
	}
	
	/*Point getLeftTop(Point selectP1, Point selectP2) {
		if (selectP1.y<selectP2.y) return selectP1;
		else if (selectP1.y>selectP2.y) return selectP2;
		else {
			if (selectP1.x<selectP2.x) return selectP1;
			else if (selectP1.x>selectP2.x) return selectP2;
			else return selectP1;
		}
	}
	
	Point getRightBottom(Point selectP1, Point selectP2) {
		if (selectP1.y>selectP2.y) return selectP1;
		else if (selectP1.y<selectP2.y) return selectP2;
		else {
			if (selectP1.x>selectP2.x) return selectP1;
			else if (selectP1.x<selectP2.x) return selectP2;
			else return selectP1;
		}
	}*/
	

	/** replace를 하면 같은 줄의 다음 인덱스 위치들이 바뀌므로 여기에서 증감치를 더해준다.
	 * isForward에 상관없이 p2.x가 p1.x보다 크거나 같다.*/
	void changeSelectP1AndP2(boolean isAll, boolean isForward, Point p1, Point p2, String textToReplaceWith) {
		if (owner.selectP1==null) return;
		if (owner.selectP2==null) return;
		
		ArrayList list = new ArrayList(2);
		list.add(owner.selectP1);
		list.add(owner.selectP2);			
		
		int incY = p2.y - p1.y + 1;
		int numOfNewLines = owner.getNumOfNewLineChar(textToReplaceWith) + 1;
		if (textToReplaceWith.length()>0) {
			if (textToReplaceWith.charAt(textToReplaceWith.length()-1)=='\n') {
				numOfNewLines--;
			}
		}
		incY = numOfNewLines - incY;
		
		Point temp = owner.getRelativeCursorPos(new Point(0,0), 
				textToReplaceWith); // 들어오는 x, 					
		// p2.x는 나가는 x
		
		int incX = temp.x - (p2.x-p1.x+1);
		
		int i;
		for (i=0; i<list.count; i++) {
			Point p = (Point)list.getItem(i);
			if (p.y<p1.y) { // 필요없다.
				
			}					
			else if (p.y>p1.y && p.y<p2.y) { // 불가능
				p.y += incY;
				list.list[i] = p;
			}
			else if (p.y==p2.y) {
				if (p.x>p2.x) {
					p.x += incX;
					p.y += incY;
					list.list[i] = p;
				}
			}
			else if (p.y>p2.y) { // p1, p2가 바뀌는것이므로 y좌표만 생각하면 된다.
				p.y += incY;
				list.list[i] = p;
			}
		}//for (i=0; i<listFindPos.count; i++) {	
		
					
		if (!isAll) FunctionOfEditText.makeSelectIndices(owner, true, owner.selectP1, owner.selectP2);
	}
	
	/** textToFind, textToReplaceWith는 '\n'이 없어야 한다.*/
	void changeListFindPos(ArrayList listFindPos, int startIndexInListFindPos, int curLine,
			String textToFind, String textToReplaceWith) {
		int incX = textToReplaceWith.length() - textToFind.length();
		int i;
		for (i=startIndexInListFindPos; i<listFindPos.count; i++) {
			Point p = (Point) listFindPos.getItem(i);
			if (p.y>curLine) break;
			p.x += incX;			
		}
	}
	
	/** replaceAll에서만 호출된다. 
	 * replace를 하면 같은 줄의 다음 인덱스 위치들이 바뀌므로 여기에서 증감치를 더해준다.
	 * isForward에 상관없이 p2.x가 p1.x보다 크거나 같다.
	 * ScrollMode가 Both일 때만 가능하다.
	 * @param p1 : 검색된 시작점
	 * @param p2 : 검색된 끝점*/
	void changeListFindPos(ArrayList listFindPos, boolean isForward, Point p1, Point p2, String textToReplaceWith) {
		int incY = p2.y - p1.y + 1;
		int numOfNewLines = owner.getNumOfNewLineChar(textToReplaceWith) + 1;
		if (textToReplaceWith.length()>0 && 
				textToReplaceWith.charAt(textToReplaceWith.length()-1)=='\n') {
			numOfNewLines--;
		}
		incY = numOfNewLines - incY;
		
		Point temp = owner.getRelativeCursorPos(new Point(0,0), 
				textToReplaceWith); // 들어오는 x, 					
		// p2.x는 나가는 x
		
		int incX = temp.x - (p2.x-p1.x+1);
		
		int i;
		int count = listFindPos.count;
		for (i=0; i<count; i++) {
			Point p = (Point)listFindPos.getItem(i);
			if (p.y<p1.y) { // 필요없다.						
			}
			else if (p.y>p1.y && p.y<p2.y) { // 불가능
			}
			else if (p.y==p2.y) {					
				if (p.x>p2.x) { // 같은 줄의 x축으로 다음 점
					// p.x = p.x + temp.x - (p2.x+1);
					p.x += incX;
					p.y += incY;
					listFindPos.list[i] = p;
				}
			}					
			else if (p.y>p2.y) { // 다음 줄
				p.y += incY;
				listFindPos.list[i] = p;
			}
		}//for (i=0; i<listFindPos.count; i++) {
	}
	
	
	boolean isNotEqual(boolean isCaseSensitive, char a, char b) {
		if (isCaseSensitive) {
			if (a!=b) return true;
			return false;
		}
		else {
			if ('A'<=a && a<='z' && 'A'<=b && b<='z') {	// 둘다 영문자이면
				int diff = 'a'-'A';
				if (a>b) {
					if (a==b+diff) return false;
				}
				else if (a<b) {
					if (b==a+diff) return false;
				}
				else return false;
			}
			else {
				if (a!=b) return true;
				return false;
			}
			return true;
		}
	}
	
	/** find에서 whole word시 호출*/
	boolean isAdjacentCharSeparator(Point selectP1, Point selectP2) {
		CodeString[] textArray = owner.textArray;
		int numOfLines = owner.numOfLines;
		
		int i;
		boolean isLeftSeparator = false;
		if (selectP1.x>0) {
			int index = selectP1.x-1;
			for (i=0; i<Edit.find_separators.length; i++) {
				if (textArray[selectP1.y].charAt(index).c==Edit.find_separators[i]) {
					isLeftSeparator = true;
					break;
				}
			}
		}
		else {
			if (selectP1.y>0) {
				int indexY = selectP1.y-1;
				int indexX = textArray[indexY].length()-1;
				for (i=0; i<Edit.find_separators.length; i++) {
					if (textArray[indexY].charAt(indexX).c==Edit.find_separators[i]) {
						isLeftSeparator = true;
						break;
					}
				}
			}
			else {
				if (selectP1.x==0 && selectP1.y==0)
					isLeftSeparator = true;
			}
		}
		
		
		boolean isRightSeparator = false;
		if (selectP2.x+1 < textArray[selectP2.y].length()) {
			int index = selectP2.x+1;
			for (i=0; i<Edit.find_separators.length; i++) {
				if (textArray[selectP2.y].charAt(index).c==Edit.find_separators[i]) {
					isRightSeparator = true;
					break;
				}
			}
		}
		else {
			if (selectP2.y+1 < numOfLines) {
				int indexY = selectP2.y+1;
				int indexX = 0;
				for (i=0; i<Edit.find_separators.length; i++) {
					if (textArray[indexY].charAt(indexX).c==Edit.find_separators[i]) {
						isRightSeparator = true;
						break;
					}
				}
			}
			else {
				if (selectP2.y==numOfLines-1 && selectP2.x==textArray[selectP2.y].length()-1)
					isRightSeparator = true;
			}
		}
		
		if (isLeftSeparator && isRightSeparator) return true;
		else return false;
	}
	
	void findCommon(boolean isAll, boolean isForward, boolean isScopeAll, boolean isCaseSensitive, 
			boolean isWholeWord, Point curFindPosLocal, String textToFind) {
		Point pointFindStart = owner.pointFindStart;
		Point pointFindEnd = owner.pointFindEnd;
		Point findP1 = owner.findP1;
		Point findP2 = owner.findP2;
		
		int i, j;
		int k;
		int len;
		boolean bInit = true;
		int endX;
		
		if (isAll) {
			owner.listFindPos.reset();
		}
		
		boolean[] searchedLines = new boolean[pointFindEnd.y-pointFindStart.y+1];
		
		if (isForward) {
			/*if (owner.isFound) {
				i=curFindPosLocal.x+1;
			}
			else {
				i=curFindPosLocal.x;
			}*/
			k=0;
			
			for (j=curFindPosLocal.y; j<=pointFindEnd.y; j++) {
				len = owner.textArray[j].length();
				try {
				if (searchedLines[j-pointFindStart.y]){
					// 종료조건 : curFindPosLocal.y(검색시작라인) 다음 라인을 시작하기 전에 종료, 즉 검색시작라인을 완전히 검색한다.						
					return;
				}
				}catch(Exception e) {
					if (Common_Settings.g_printsLog) e.printStackTrace();
				}
				
				// bInit은 초기값 설정에서만 사용한다.
				if (bInit) {	// 뒤에 나오는 for 루프의 초기값 설정
					i = this.setCursorPosWhenFinding(isForward, curFindPosLocal);
					bInit = false;
					owner.isFound = false;
				}
				else {	// 뒤 루프를 한번 실행한 경우, 즉 한 줄을 검색한 경우
					if (isScopeAll) i = 0;
					else {
						if (j!=pointFindStart.y) i = 0;
						else i = pointFindStart.x;
					}
					// i==0으로 시작할 때만 검색을 다 한 것으로 예정.
					searchedLines[j-pointFindStart.y] = true; 
				}
				
				if (isScopeAll) endX = len-1;
				else {
					if (j==pointFindEnd.y) endX = pointFindEnd.x;
					else endX = len-1;
				}
				
				int backup_i = i;
				
				for (; i<=endX && i>=0; i++) {	// i<=len이어야 루프를 종료할 수 있다.					
					//if (i==endX) break; // 이것을 하지 않으면 무한 루프 발생
					
					if (isNotEqual(isCaseSensitive, owner.textArray[j].charAt(i).c, 
						textToFind.charAt(k))) {
						if (k>0) {
							// 검색이 틀린 문자부터 다시 시작한다.
							i = backup_i;
							k = 0;
						}
						else {
							k = 0;
						}
					}
					else {
						if (k==0) { // 시작위치
							findP1.x = i;
							findP1.y = j;
							backup_i = i;
						}
						if (k==textToFind.length()-1) {	// 찾은경우, 끝위치
							findP2.x = i;
							findP2.y = j;
							k = 0;
							
							if (!isWholeWord ) {
								FunctionOfEditText.makeSelectIndices(owner, false, findP1, findP2);
								
								owner.isFound = true;
								if (isAll) {
									Point p1 = new Point(findP1.x, findP1.y);
									Point p2 = new Point(findP2.x, findP2.y);
									
									// 현재 라인이 검색시작라인일 경우 
									if (j==curFindPosLocal.y) {
										// 첫번째 검색일 경우에는 listFindPos에 넣는다.
										if (!searchedLines[j-pointFindStart.y]) {
											owner.listFindPos.add(p1);
											owner.listFindPos.add(p2);
										}
										else {
											// 두번째 검색일 경우에는 검색시작라인의 x를 비교하여 listFindPos에 넣는다.
											if (i<curFindPosLocal.x) {
												owner.listFindPos.add(p1);
												owner.listFindPos.add(p2);
											}
										}
									}
									// 현재 라인이 검색시작라인이 아닐 경우 
									else {
										owner.listFindPos.add(p1);
										owner.listFindPos.add(p2);
									}
								}
								
								owner.cursorPos.x = i;	// find next, +1을 하지 않으면 한 문자 찾기에서 전진을 안한다.
								owner.cursorPos.y = j;
								
								/*if (isAll) {
									curFindPosLocal.x = cursorPos.x;
									curFindPosLocal.y = cursorPos.y;
								}*/
								// 검색한 위치로 스크롤바를 이동시킨다.
								if (!(owner.vScrollPos<=owner.cursorPos.y && owner.cursorPos.y<owner.vScrollPos+owner.numOfLinesPerPage)) {
									owner.vScrollPos = owner.cursorPos.y;
									owner.setVScrollBar();
								}							
								if (owner.scrollMode==ScrollMode.Both) {
									owner.setHScrollPos();
									owner.setHScrollBar();
								}
								if (!isAll) return;
							}
							else {	// wholeWord
								if (isAdjacentCharSeparator(findP1, findP2)) {
									FunctionOfEditText.makeSelectIndices(owner, false, findP1, findP2);
									
									owner.isFound = true;
									if (isAll) {
										Point p1 = new Point(findP1.x, findP1.y);
										Point p2 = new Point(findP2.x, findP2.y);
										// 현재 라인이 검색시작라인일 경우 
										if (j==curFindPosLocal.y) {
											// 첫번째 검색일 경우에는 listFindPos에 넣는다.
											if (!searchedLines[j-pointFindStart.y]) {
												owner.listFindPos.add(p1);
												owner.listFindPos.add(p2);
											}
											else {
												// 두번째 검색일 경우에는 검색시작라인의 x를 비교하여 listFindPos에 넣는다.
												if (i<curFindPosLocal.x) {
													owner.listFindPos.add(p1);
													owner.listFindPos.add(p2);
												}
											}
										}
										// 현재 라인이 검색시작라인이 아닐 경우 
										else {
											owner.listFindPos.add(p1);
											owner.listFindPos.add(p2);
										}
									}
									
									owner.cursorPos.x = i;	// find next, +1을 하지 않으면 한 문자 찾기에서 전진을 안한다.
									owner.cursorPos.y = j;
									
									if (!(owner.vScrollPos<=owner.cursorPos.y && owner.cursorPos.y<owner.vScrollPos+owner.numOfLinesPerPage)) {
										owner.vScrollPos = owner.cursorPos.y;
										owner.setVScrollBar();
									}							
									if (owner.scrollMode==ScrollMode.Both) {
										owner.setHScrollPos();
										owner.setHScrollBar();
									}
									if (!isAll) return;
								}
							}// wholeWord
						}	// if (k==textToFind.length()-1) {	// 찾은경우, 끝위치
						else if (k<textToFind.length()-1) k++;
					}//if (isNotEqual(isCaseSensitive, textArray[j].charAt(i).c, 
					//		textToFind.charAt(k))==false) {
				}//for (; i<=endX && i>=0; i++) {
				
				/*if (isScopeAll) endY = numOfLines-1;
				else endY = pointFindEnd.y;
				if (j==endY) {	// 다시 처음라인으로 간다.
					if (i>endX) {
						if (isScopeAll) j = -1;
						else j = pointFindStart.y-1;
						k = 0;
					}
				}*/
				if (j==pointFindEnd.y) {	// 다시 처음라인으로 간다.
					if (i>endX) {
						/*if (isScopeAll) j = -1;
						else */j = pointFindStart.y-1;
						k = 0;
					}
				}
			}	// for (j=curFindPosLocal.y; j<numOfLines; j++) {
		} // if
		else {	// backward
			i=curFindPosLocal.x/*-1*/;
			k = textToFind.length()-1;
			
			for (j=curFindPosLocal.y; j>=pointFindStart.y; j--) {
				len = owner.textArray[j].length();				
				
				if (searchedLines[j-pointFindStart.y]){
					// 종료조건 : curFindPosLocal.y(검색시작라인) 이전 라인을 시작하기 전에 종료,즉 검색시작라인을 완전히 검색한다.
					return;
				}
				
				// bInit은 초기값 설정에서만 사용한다.
				if (bInit) {	// 뒤에 나오는 for 루프의 초기값 설정
					i = this.setCursorPosWhenFinding(isForward, curFindPosLocal);
					bInit = false;
					owner.isFound = false;
				}
				else {	// 뒤 루프를 한번 실행한 경우, 즉 한 줄을 검색한 경우
					if (isScopeAll) i = len-1;
					else {
						if (j!=pointFindEnd.y) i = len-1;
						else i = pointFindEnd.x;
					}
					
					// i==len-1으로 시작할 때만 검색을 다 한 것으로 예정.
					searchedLines[j-pointFindStart.y] = true; 
				}
				
				if (isScopeAll) endX = 0;
				else {
					if (j==pointFindStart.y) endX = pointFindStart.x;
					else endX = 0;
				}
				
				int backup_i = i;
				
				for (; i>=endX && i<len; i--) {	// i>=-1이어야 루프를 종료할 수 있다.
					//if (i==endX) break;  // 이것을 하지 않으면 무한 루프 발생
					
					if (isNotEqual(isCaseSensitive, owner.textArray[j].charAt(i).c, 
						textToFind.charAt(k))) {
						if (k<textToFind.length()-1) {
							// 검색이 틀린 문자부터 다시 시작한다.
							k = textToFind.length()-1;
							i = backup_i;
						}
						else {
							k = textToFind.length()-1;
						}
						//i = backup_i;
					}
					else {
						if (k==textToFind.length()-1) { // 시작위치
							findP2.x = i;
							findP2.y = j;
							backup_i = i;
						}
						if (k==0) {	// 찾은경우, 끝위치
							findP1.x = i;
							findP1.y = j;
							k = textToFind.length()-1;
							
							if (!isWholeWord) {
								FunctionOfEditText.makeSelectIndices(owner, false, findP1, findP2);
								//isSelecting = true;
								
								owner.isFound = true;
								if (isAll) {
									Point p1 = new Point(findP1.x, findP1.y);
									Point p2 = new Point(findP2.x, findP2.y);
									// 현재 라인이 검색시작라인일 경우 
									if (j==curFindPosLocal.y) {
										// 첫번째 검색일 경우에는 listFindPos에 넣는다.
										if (!searchedLines[j-pointFindStart.y]) {
											owner.listFindPos.add(p1);
											owner.listFindPos.add(p2);
										}
										else {
											// 두번째 검색일 경우에는 검색시작라인의 x를 비교하여 listFindPos에 넣는다.
											if (i>curFindPosLocal.x) {
												owner.listFindPos.add(p1);
												owner.listFindPos.add(p2);
											}
										}
									}
									// 현재 라인이 검색시작라인이 아닐 경우 
									else {
										owner.listFindPos.add(p1);
										owner.listFindPos.add(p2);
									}
								}
								
								owner.cursorPos.x = i;
								owner.cursorPos.y = j;
								/*if (isAll) {
									curFindPosLocal.x = cursorPos.x;
									curFindPosLocal.y = cursorPos.y;
								}*/
								if (!(owner.vScrollPos<=owner.cursorPos.y && owner.cursorPos.y<owner.vScrollPos+owner.numOfLinesPerPage)) {
									owner.vScrollPos = owner.cursorPos.y;
									owner.setVScrollBar();
								}							
								if (owner.scrollMode==ScrollMode.Both) {
									owner.setHScrollPos();
									owner.setHScrollBar();
								}
								if (!isAll) return;
							}
							else {
								if  (isAdjacentCharSeparator(findP1, findP2)) {
									FunctionOfEditText.makeSelectIndices(owner, false, findP1, findP2);
									//isSelecting = true;
									
									owner.isFound = true;
									if (isAll) {
										Point p1 = new Point(findP1.x, findP1.y);
										Point p2 = new Point(findP2.x, findP2.y);
										// 현재 라인이 검색시작라인일 경우 
										if (j==curFindPosLocal.y) {
											// 첫번째 검색일 경우에는 listFindPos에 넣는다.
											if (!searchedLines[j-pointFindStart.y]) {
												owner.listFindPos.add(p1);
												owner.listFindPos.add(p2);
											}
											else {
												// 두번째 검색일 경우에는 검색시작라인의 x를 비교하여 listFindPos에 넣는다.
												if (i>curFindPosLocal.x) {
													owner.listFindPos.add(p1);
													owner.listFindPos.add(p2);
												}
											}
										}
										// 현재 라인이 검색시작라인이 아닐 경우 
										else {
											owner.listFindPos.add(p1);
											owner.listFindPos.add(p2);
										}
									}
									
									owner.cursorPos.x = i;
									owner.cursorPos.y = j;
									/*if (isAll) {
										curFindPosLocal.x = cursorPos.x;
										curFindPosLocal.y = cursorPos.y;
									}*/
									if (!(owner.vScrollPos<=owner.cursorPos.y && owner.cursorPos.y<owner.vScrollPos+owner.numOfLinesPerPage)) {
										owner.vScrollPos = owner.cursorPos.y;
										owner.setVScrollBar();
									}							
									if (owner.scrollMode==ScrollMode.Both) {
										owner.setHScrollPos();
										owner.setHScrollBar();
									}
									if (!isAll) return;
								}
							}
						} // if (k==0)
						else if (k>0) k--;
					}
				}
				/*if (isScopeAll) endY = 0;
				else endY = pointFindStart.y;
				if (j==endY) {
					if (i<endX) {
						if (isScopeAll) j = numOfLines;
						else j = pointFindEnd.y+1;
						k = textToFind.length()-1;
					}
				}*/
				if (j==pointFindStart.y) {
					if (i<endX) {
						/*if (isScopeAll) j = numOfLines;
						else */j = pointFindEnd.y+1;
						k = textToFind.length()-1;
					}
				}
			}	// for (j=curFindPosLocal.y; j<numOfLines; j++) {
		}	// else
	
	}
	
	/** 
	 * @param isAll : 여러개를 찾을경우 true, 1개를 찾을 경우 false
	 * @param isForward
	 * @param isScopeAll : 선택라인에서 찾을 경우 false, 모든 영역에서 찾을 경우 true
	 * @param isCaseSensitive
	 * @param isWholeWord
	 * @param curFindPosLocal
	 * @param textToFind
	 * @param isCallerReplace : caller가 OnTouchEvent의 find 명령처리할 때나 
		 * 	replace()이면 true, 아니면 false, 
		 * 	사용자가 find, replace-next나 replaceAll 버튼을 클릭해서
			검색이 실패할 때만 메시지가 나오고
			undo, redo시에는 "the text not found" 메시지가 나오지 않도록 한다.
	 */
	public void find(boolean isAll, boolean isForward, boolean isScopeAll, boolean isCaseSensitive, 
		boolean isWholeWord, Point curFindPosLocal, String textToFind, boolean isCallerReplace) {
		textToFind = FunctionOfEditText.processSpecialChar(owner, textToFind);
		//textToReplaceWith = processSpecialChar(textToReplaceWith);
		
		if (textToFind==null || textToFind.equals("")) return;
		
		Point selectP1 = owner.selectP1;
		Point selectP2 = owner.selectP2;
		Point pointFindStart = owner.pointFindStart;
		Point pointFindEnd = owner.pointFindEnd;
		
		try {
		
		if (!isScopeAll) {	// 선택영역내에서
			if (selectP1.y == selectP2.y) {
				if (selectP1.x < selectP2.x) {
					pointFindStart.x = selectP1.x;
					pointFindStart.y = selectP1.y;
					pointFindEnd.x = selectP2.x;
					pointFindEnd.y = selectP2.y;
				}
				else {
					pointFindStart.x = selectP2.x;
					pointFindStart.y = selectP2.y;
					pointFindEnd.x = selectP1.x;
					pointFindEnd.y = selectP1.y;
				}
			}
			else {
				if (selectP1.y < selectP2.y) {
					pointFindStart.x = selectP1.x;
					pointFindStart.y = selectP1.y;
					pointFindEnd.x = selectP2.x;
					pointFindEnd.y = selectP2.y;
				}
				else {
					pointFindStart.x = selectP2.x;
					pointFindStart.y = selectP2.y;
					pointFindEnd.x = selectP1.x;
					pointFindEnd.y = selectP1.y;
				}
			}
		}
		else {//isScopeAll==true
			pointFindStart.x = 0;
			pointFindStart.y = 0;
			if (owner.textArray[owner.numOfLines-1].length()>0)
				pointFindEnd.x = owner.textArray[owner.numOfLines-1].length()-1;
			else 
				pointFindEnd.x = 0;
			pointFindEnd.y = owner.numOfLines-1;
		
			
			// scope가 all이므로 시작 커서 위치를 원점으로 한다.
			/*if (isAll) {
				curFindPosLocal.y = 0;
				curFindPosLocal.x = 0;
			}*/
		}
		
		
		
		/*if (isForward==false) {
			// isBackward일 때 커서가 라인의 마지막을 가리킬 경우 -1을 해줘야 findCommon()에서 검색을 가능하게 한다. 
			if (curFindPosLocal.x==owner.textArray[curFindPosLocal.y].count) {
				curFindPosLocal.x = owner.textArray[curFindPosLocal.y].count-1;
				if (curFindPosLocal.x<0) curFindPosLocal.x = 0; 
			}
		}*/
		
		findCommon(isAll, isForward, isScopeAll, isCaseSensitive, 
		 	isWholeWord, curFindPosLocal, textToFind);
		
		/*if (owner.isFound) {
			// 사용자가 한문자를 find에 입력하고 findNext를 연쇄적으로 클릭하면  cursor를 전진시켜줘야 
			// 연쇄적으로 검색을 가능하게 한다.
			if (isForward) {
				if (owner.cursorPos.y==pointFindEnd.y) {
					if (owner.textArray[owner.cursorPos.y].count>0) {
						if (owner.cursorPos.x==owner.textArray[owner.cursorPos.y].count-1) {								
							owner.cursorPos.y = pointFindStart.y;
							owner.cursorPos.x = 0;
						}
						else {
							owner.cursorPos.x++;
						}
					}
				}
				else {
					owner.cursorPos.x++;
					if (owner.cursorPos.x>=owner.textArray[owner.cursorPos.y].count) {
						owner.cursorPos.x = owner.textArray[owner.cursorPos.y].count;
					}
				}
			}//if (isForward) {
			else {
				if (owner.cursorPos.y==pointFindStart.y) {
					if (owner.cursorPos.x==0) {
						owner.cursorPos.y = pointFindEnd.y;
						if (owner.textArray[owner.cursorPos.y].count>0) {
							owner.cursorPos.x = owner.textArray[owner.cursorPos.y].count-1;
						}
						else {
							owner.cursorPos.x = 0;
						}
					}
					else {
						owner.cursorPos.x--;
						if (owner.cursorPos.x<0) owner.cursorPos.x = 0;
					}
				}
				else {
					owner.cursorPos.x--;
					if (owner.cursorPos.x<0) owner.cursorPos.x = 0;
				}
			}// isBackward
		}//if (owner.isFound) {*/
		 	
		if (!owner.isFound) {
			// 사용자가 find, replace-next나 replaceAll 버튼을 클릭해서
			// 검색이 실패할 때만 메시지가 나오고
			// undo, redo시에는 "the text not found" 메시지가 나오지 않도록 한다.
			if (isCallerReplace) {
				CommonGUI.loggingForMessageBox.setHides(false);
				CommonGUI.loggingForMessageBox.setText(true, "The text not found.", false);
			}
			owner.findP1.x = -1;
			owner.findP1.y = -1;
			owner.findP2.x = -1;
			owner.findP2.y = -1;
		}
		else {
			//listFindPos = refine(this.listFindPos);
			//refineListFindPos();
		}
		
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
			CompilerHelper.printStackTrace(owner.textViewLogBird, e);
		}
		
	}
	
	/** find()에서 중복된 좌표를 제거한다.*/
	/*void refineListFindPos() {
		int i;
		ArrayList listFindPos = owner.listFindPos;
		ArrayList newListFindPos = new ArrayList(listFindPos.count);
		
		Point first = (Point) listFindPos.getItem(0);
		int y = first.y;
		
		for (i=0; i<listFindPos.count; i++) {
			Point p = (Point) listFindPos.getItem(i);
			if (p.y==y) {
				newListFindPos.add(p);
			}
			else break;
		}
		
		for (i=0; i<listFindPos.count; i++) {
			Point p = (Point) listFindPos.getItem(i);
			if (p.y!=y) {
				newListFindPos.add(p);
			}
		}
		owner.listFindPos = newListFindPos;
	}*/
	
	
	/** findCommon()에서 사용자가 한문자를 find에 입력하고 findNext를 연쇄적으로 클릭하면  cursor를 전진시켜줘야 
		연쇄적으로 검색을 가능하게 한다. 
		또한 isBackward일 때 커서가 라인의 마지막을 가리킬 경우 -1을 해줘야 findCommon()에서 검색을 가능하게 한다. */
	int setCursorPosWhenFinding(boolean isForward, Point curFindPosLocal) {			
		if (isForward) {
			if (owner.isFound) {
				// 사용자가 한문자를 find에 입력하고 findNext를 연쇄적으로 클릭하면  cursor를 전진시켜줘야 
				// 연쇄적으로 검색을 가능하게 한다.
				return curFindPosLocal.x+1;
			}
			else {
				return curFindPosLocal.x;
			}
		}
		else {
			// isBackward일 때 커서가 라인의 마지막을 가리킬 경우 -1을 해줘야 findCommon()에서 검색을 가능하게 한다. 
			if (curFindPosLocal.x==owner.textArray[curFindPosLocal.y].count) {
				curFindPosLocal.x = owner.textArray[curFindPosLocal.y].count-1;
				if (curFindPosLocal.x<0) curFindPosLocal.x = 0; 
			}
			
			if (owner.isFound) {
				// 사용자가 한문자를 find에 입력하고 findNext를 연쇄적으로 클릭하면  cursor를 전진시켜줘야 
				// 연쇄적으로 검색을 가능하게 한다.
				return curFindPosLocal.x-1;
			}
			else {
				return curFindPosLocal.x;
			}
		}
	}
	
	
	/** 항상 p2가 p1보다 크다.
	 * 커서위치는 undo(), undo_replace(), redo(), redo_replace(), replace()에서 
	 * 설정하지 않고 replaceCommon()에서 공통적으로 설정한다. 
	 * 위 함수들이 공통적으로 replaceCommon()을 호출하기 때문이다.
	 * 현재 p1과 p2가 같은 라인에서만 가능하다.*/
	void replaceCommon(boolean isAll, Point p1, Point p2, String textToFind, String textToReplaceWith) {
		//int numOfLines = p2.y - p1.y + 1;
		int numOfLines = owner.getNumOfNewLineChar(textToFind)+1;
		
		if (numOfLines==1) {
			CodeString lineText = owner.textArray[p1.y];
			ArrayListCodeChar list = new ArrayListCodeChar(30);
			list.setText(lineText);
			try {
			list.delete(p1.x, p2.x-p1.x+1);
			}catch(Exception e) {
			}
			list.insert(p1.x, new CodeString(textToReplaceWith, owner.textColor));
			
			CodeString newLineText = new CodeString(list.getItems(), list.count);
			if (owner.scrollMode==ScrollMode.VScroll) {
				if (!isAll) owner.setTextMultiLine(p1.y, newLineText, 1);
				else owner.textArray[p1.y] = newLineText;
				//owner.cursorPos.x = p1.x + textToReplaceWith.length();
				owner.cursorPos.x = p1.x + textToReplaceWith.length();
			}
			else {
				if (!isAll) {
				
					owner.setTextMultiLine(p1.y, newLineText, 1);
				}
				else {
					
					owner.setTextMultiLine(p1.y, newLineText, 1);
				}
				//owner.cursorPos = owner.getRelativeCursorPos(p1, textToReplaceWith);
				owner.cursorPos = owner.getRelativeCursorPos(p1, textToReplaceWith);
			}
			owner.findP1.x = p1.x;
			owner.findP2.x = owner.cursorPos.x-1;
			if (!isAll) FunctionOfEditText.makeSelectIndices(owner, false, owner.findP1, owner.findP2);
		}
		else {
			int i;
			CodeString newLineText = new CodeString("", owner.textColor);
			for (i=0; i<numOfLines; i++) {
				if (i==0) {
					CodeString lineText1 = owner.textArray[p1.y];
					ArrayListCodeChar list1 = new ArrayListCodeChar(30);
					list1.setText(lineText1);
					list1.delete(p1.x, lineText1.length()-1-p1.x+1);
					list1.insert(p1.x, new CodeString(textToReplaceWith, owner.textColor));
					newLineText = newLineText.concate(new CodeString(list1.getItems(), list1.count));
				}
				else if (i==numOfLines-1) {						
					if (textToFind.length()>0 && textToFind.charAt(textToFind.length()-1)=='\n') {
						//	 12\n
						//	 3\n
						//	 456\n
						//	 789 
						//	 에서 textToFind는 2\n이고 textToReplaceWith는 2이다.
						CodeString lineText2 = owner.textArray[p2.y+1];
						ArrayListCodeChar list2 = new ArrayListCodeChar(30);
						list2.setText(lineText2);
						newLineText = newLineText.concate(lineText2);
					}
					else {
						// 위 예에서 textToFind는 2\n3이고 textToReplaceWith는 2이다.
						CodeString lineText2 = owner.textArray[p2.y];
						ArrayListCodeChar list2 = new ArrayListCodeChar(30);
						list2.setText(lineText2);
						list2.delete(0, p2.x+1);
						newLineText = newLineText.concate(new CodeString(list2.getItems(), list2.count));
					}
				}
				else {
				}
			}
			if (owner.scrollMode==ScrollMode.VScroll) {
				if (!isAll) owner.setTextMultiLine(p1.y, newLineText, numOfLines);
				else owner.textArray[p1.y] = newLineText;
				// 커서위치를 찾기 힘들므로 보류한다.
			}
			else {
				
				owner.setTextMultiLine(p1.y, newLineText, numOfLines);
				
				owner.cursorPos = owner.getRelativeCursorPos(p1, newLineText.str);
				
			}
		}
	}
	
	/** REPLACE ALL에서 호출, 
	 * listFindPos에서 start, end좌표로 저장되므로
	 * 원래 text와 null을 함께 저장한다.*/
	public static ArrayListString getListOfTextForNoneCaseSensitive(EditText owner, ArrayList listFindPos) {
		int i;
		ArrayListString r = new ArrayListString(listFindPos.count);
		for (i=0; i<listFindPos.count; i+=2) {
			Point p1 = (Point) listFindPos.getItem(i);
			Point p2 = (Point) listFindPos.getItem(i+1);
			String text = owner.textArray[p1.y].substring(p1.x, p2.x+1).str;
			r.add(text);
			r.add((String)null);
		}
		return r;
	}
	
	/** replace-find에서 호출, 
	 * listFindPos에서 start, end좌표로 저장되므로
	 * 원래 text와 null을 함께 저장한다.*/
	public static ArrayListString getListOfTextForNoneCaseSensitive(EditText owner, Point p1, Point p2) {
		ArrayListString r = new ArrayListString(2);
		String text = owner.textArray[p1.y].substring(p1.x, p2.x+1).str;
		r.add(text);
		r.add((String)null);
		return r;
	}
	
	/**커서위치는 undo(), undo_replace(), redo(), redo_replace(), replace()에서 
	설정하지 않고 replaceCommon()에서 공통적으로 설정한다. 
	위 함수들이 공통적으로 replaceCommon()을 호출하기 때문이다.*/
	public void replace(boolean isAll, boolean isForward, boolean isScopeAll, boolean isCaseSensitive, 
			boolean isWholeWord, Point curFindPosLocal, String textToFind, String textToReplaceWith) {
		if (owner.isReadOnly) return;
		
		Point findP1 = owner.findP1;
		Point findP2 = owner.findP2;
		Point selectP1 = owner.selectP1;
		Point selectP2 = owner.selectP2;
		
		textToFind = FunctionOfEditText.processSpecialChar(owner, textToFind);
		textToReplaceWith = FunctionOfEditText.processSpecialChar(owner, textToReplaceWith);
		
		if (!isAll) {	// Replace-Find
			
			if (owner.isFound) {
				
				ArrayListString listOfTextForNoneCaseSensitive = null;
				if (!isCaseSensitive) {
					listOfTextForNoneCaseSensitive = getListOfTextForNoneCaseSensitive(owner, findP1, findP2);
				}
				
				curFindPosLocal.x = findP1.x;
				curFindPosLocal.y = findP1.y;
				
				Point oldFindP1 = new Point(findP1.x, findP1.y);
				Point oldFindP2 = new Point(findP2.x, findP2.y);
				
				replaceCommon(isAll, findP1, findP2, textToFind, textToReplaceWith);
				changeSelectP1AndP2(false, isForward, oldFindP1, oldFindP2, textToReplaceWith);
				
				
				if (isCaseSensitive) {
					UndoOfEditText.backUpForUndo_replace(owner, "replace", isAll, isForward, isScopeAll, isCaseSensitive, 
						isWholeWord, oldFindP1, oldFindP2, findP1, findP2, textToFind, textToReplaceWith);
				}
				else {
					UndoOfEditText.backUpForUndo_replace(owner, "replace", isAll, isForward, isScopeAll, isCaseSensitive, 
						isWholeWord, oldFindP1, oldFindP2, findP1, findP2, textToFind, textToReplaceWith, listOfTextForNoneCaseSensitive);
				}
				
				
				// redo 를 무효화한다. redoBuffer를 모두 지워야 한다. 
				// redo 를 무효로 만들지 않으면 undo-redo 시스템의 오류가 발생한다.
				owner.redoBuffer.reset();
				
				
				find(false, isForward,  isScopeAll,  isCaseSensitive, 
						isWholeWord,  curFindPosLocal, textToFind, true);
				
				//커서위치는 undo(), undo_replace(), redo(), redo_replace(), replace()에서 
				// 설정하지 않고 replaceCommon()에서 공통적으로 설정한다. 
				// 위 함수들이 공통적으로 replaceCommon()을 호출하기 때문이다.
			}
			else {
				CommonGUI.loggingForMessageBox.setHides(false);
				CommonGUI.loggingForMessageBox.setText(true, "Touch the Find next button ahead and then replace/find.", false);
			}
		}// if (!isAll)
		else {	// ReplaceAll은 scrollMode가 Both일 때만 동작한다. 검색시작위치는 0,0에서 시작되므로 listFindPos은 x, y순으로 정렬된 상태이다.
			//backUpForUndo_replace("replaceAll", isAll, isForward, isScopeAll, isCaseSensitive, 
			//		isWholeWord, curFindPosLocal, textToFind, textToReplaceWith);
			
			
			owner.listFindPos = new ArrayList(50);
			// 나중에 undo를 하기위한 replace한 위치 리스트, listFindPos와 비교한다.
			ArrayList listReplacePos = new ArrayList(50);
			
			
			if (!isScopeAll) { // 선택줄에서 검색시
				curFindPosLocal = new Point(selectP1.x, selectP1.y);
			}
			else {
				curFindPosLocal = new Point(0,0);
			}
			
			find(true, isForward,  isScopeAll,  isCaseSensitive, 
				isWholeWord,  curFindPosLocal, textToFind, true);
			ArrayList list = owner.listFindPos;
			
			ArrayListString listOfTextForNoneCaseSensitive = null;
			if (!isCaseSensitive) {
				listOfTextForNoneCaseSensitive = getListOfTextForNoneCaseSensitive(owner, list);
			}
			
			// 아래 for문에서 this.listFindPos가 바뀌므로 백업해두었다가
			// undoBuffer에 넣는다.
			ArrayList listBackupForFindPos = owner.getClone(owner.listFindPos);
			int count = list.count;
						
			int i;
			for (i=0; i<count; i+=2) {
				Point p1 = (Point)list.list[i];
				Point p2 = (Point)list.list[i+1];
				replaceCommon(isAll, p1, p2, textToFind, textToReplaceWith);
				
				listReplacePos.add(new Point(findP1.x, p1.y));
				listReplacePos.add(new Point(findP2.x, p2.y));
								
				if (!isScopeAll) {
					changeSelectP1AndP2(true, isForward, p1, p2, textToReplaceWith);
				}
				changeListFindPos(list, i+2, p1.y, textToFind, textToReplaceWith);
			}
			if (!isScopeAll) { // 선택줄에서 검색시
				FunctionOfEditText.makeSelectIndices(owner, true, selectP1, selectP2);
				
				Point t1 = selectP1, t2 = selectP2;
				if (selectP1.y>selectP2.y) { // swapping
					t1 = selectP2;
					t2 = selectP1;
				}
				else if (selectP1.y==selectP2.y) {
					if (selectP1.x>selectP2.x) {
						// swapping, y가 같을땐 x를 비교해서 작은쪽이 p1이 된다.
						t1 = selectP2;
						t2 = selectP1;
					}
				}
				selectP1 = t1;
				selectP2 = t2;
			}
			
			if (!isScopeAll) { // 선택줄에서 검색시
				curFindPosLocal = new Point(selectP1.x, selectP1.y);
			}
			else {
				curFindPosLocal = new Point(0,0);
			}
			
			if (isCaseSensitive) {
				UndoOfEditText.backUpForUndo_replace(owner, "replaceAll", isAll, isForward, isScopeAll, isCaseSensitive, 
					isWholeWord, curFindPosLocal, textToFind, textToReplaceWith, listBackupForFindPos, listReplacePos);
			}
			else {
				UndoOfEditText.backUpForUndo_replace(owner, "replaceAll", isAll, isForward, isScopeAll, isCaseSensitive, 
					isWholeWord, curFindPosLocal, textToFind, textToReplaceWith, listBackupForFindPos, listReplacePos, listOfTextForNoneCaseSensitive);
			}
			// redo 를 무효화한다. redoBuffer를 모두 지워야 한다. 
			// redo 를 무효로 만들지 않으면 undo-redo 시스템의 오류가 발생한다.
			owner.redoBuffer.reset();
			
					
			owner.setVScrollPos();
			owner.setVScrollBar();
			if (owner.scrollMode==ScrollMode.Both) {
				owner.setHScrollPos();
				owner.setHScrollBar();	
			}
			
			if (isScopeAll) { // 모든 영역에서 검색시
				owner.isSelecting = false;
				owner.isFound = false;
			}
			else {// 선택줄에서 검색시
				owner.isFound = false;
			}
		}
		if (owner instanceof EditText_Compiler) {
			EditText_Compiler editText_Compiler = (EditText_Compiler) owner;
			if (editText_Compiler.getCompiler()!=null) {
				editText_Compiler.update(0, 0, "all", true);
			}
		}
	}
}