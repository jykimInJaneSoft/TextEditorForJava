package com.gsoft.common.gui.edittext;

import android.graphics.Point;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.compiler.EditText_Compiler;
import com.gsoft.common.gui.IntegrationKeyboard.Hangul;
import com.gsoft.common.gui.edittext.Edit.ScrollMode;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListString;

import com.gsoft.common.gui.edittext.EditText;
import com.gsoft.common.gui.edittext.FunctionOfEditText;
import com.gsoft.common.gui.edittext.FindReplaceOfEditText;
import com.gsoft.common.gui.edittext.RedoBufferOfEditText;
import com.gsoft.common.gui.edittext.UndoOfEditText;
import com.gsoft.common.gui.edittext.Edit;

public class RedoOfEditText {
	protected static final String NewLineChar = Edit.NewLineChar;
	protected static final String BackspaceChar = Edit.BackspaceChar;
	protected static final String DeleteChar = Edit.DeleteChar;
	static final String TabChar = Edit.TabChar;
	
	
	
	public static void redo_replace(EditText editText, RedoBufferOfEditText.Pair pair) {
		String command = pair.command;
		
		Point curFindPosLocal = pair.cursorPos;
		
		int index = pair.text.indexOf("-");
		String textToFind = pair.text.substring(0, index).toString();
		String textToReplaceWith = pair.text.substring(index+1).toString();
		
		String addedInfo = (String)pair.addedInfo;
		int index0 = addedInfo.indexOf("-", 0);		
		boolean isAll = Boolean.parseBoolean(addedInfo.substring(0, index0));
		
		int index1 = addedInfo.indexOf("-", index0+1);
		boolean isForward = Boolean.parseBoolean(addedInfo.substring(index0+1, index1));
		
		int index2 = addedInfo.indexOf("-", index1+1);
		boolean isScopeAll = Boolean.parseBoolean(addedInfo.substring(index1+1, index2));
		
		int index3 = addedInfo.indexOf("-", index2+1);
		boolean isCaseSensitive = Boolean.parseBoolean(addedInfo.substring(index2+1, index3));
		
		boolean isWholeWord;
		
		// replace-find(isAll==false) 시 backupForUndo_replace()에서 addedInfo의 구조
		/************************************************************************************ 
		 * if (isScopeAll==false) {
			addedInfo = isAll + "-" + isForward + "-" + isScopeAll + "-" + isCaseSensitive + "-" +
				isWholeWord + "-" + 
				this.selectP1.x + "-" + this.selectP1.y + "-" + this.selectP2.x + "-" + this.selectP2.y + "-" +
				findP1.x + "-" + findP1.y + "-" + findP2.x + "-" + findP2.y + "-" +
				replacePosP1.x + "-" + replacePosP1.y + "-" + replacePosP2.x + "-" + replacePosP2.y;;
		}
		else {
			addedInfo = isAll + "-" + isForward + "-" + isScopeAll + "-" + isCaseSensitive + "-" +
				isWholeWord + "-" +
				findP1.x + "-" + findP1.y + "-" + findP2.x + "-" + findP2.y + "-" +
				replacePosP1.x + "-" + replacePosP1.y + "-" + replacePosP2.x + "-" + replacePosP2.y;;
		}*****************************************************************************************/
		
		// replaceAll(isAll==true)일 경우 addedInfo의 구조
		/******************************************************************************************
		 * String addedInfo;
		if (isScopeAll==false) {
			addedInfo = isAll + "-" + isForward + "-" + isScopeAll + "-" + isCaseSensitive + "-" +
				isWholeWord + "-" + 
				this.selectP1.x + "-" + this.selectP1.y + "-" + this.selectP2.x + "-" + this.selectP2.y;
		}
		else {
			addedInfo = isAll + "-" + isForward + "-" + isScopeAll + "-" + isCaseSensitive + "-" +
				isWholeWord;
		}************************************************************************************************/
		
		
		int selectP1_x, selectP1_y, selectP2_x, selectP2_y = 0;
		int findP1_x, findP1_y, findP2_x, findP2_y = 0;
		int replacePosP1_x=0, replacePosP1_y=0, replacePosP2_x=0, replacePosP2_y=0;
		if (!isScopeAll) {
			int index4 = addedInfo.indexOf("-", index3+1);
			isWholeWord = Boolean.parseBoolean(addedInfo.substring(index3+1, index4));
			
			int index5 = addedInfo.indexOf("-", index4+1);
			selectP1_x = Integer.parseInt(addedInfo.substring(index4+1, index5));
			
			int index6 = addedInfo.indexOf("-", index5+1);
			selectP1_y = Integer.parseInt(addedInfo.substring(index5+1, index6));
			
			int index7 = addedInfo.indexOf("-", index6+1);
			selectP2_x = Integer.parseInt(addedInfo.substring(index6+1, index7));
			
			int index8 = addedInfo.indexOf("-", index7+1);
			selectP2_y = Integer.parseInt(addedInfo.substring(index7+1));
			
			editText.selectP1.x = selectP1_x;
			editText.selectP1.y = selectP1_y;
			editText.selectP2.x = selectP2_x;
			editText.selectP2.y = selectP2_y;
			
			if (!isAll) {// isScopeAll==false, isAll==false
				int index9 = addedInfo.indexOf("-", index8+1);
				findP1_x = Integer.parseInt(addedInfo.substring(index8+1, index9));
				
				int index10 = addedInfo.indexOf("-", index9+1);
				findP1_y = Integer.parseInt(addedInfo.substring(index9+1, index10));
				
				int index11 = addedInfo.indexOf("-", index10+1);
				findP2_x = Integer.parseInt(addedInfo.substring(index10+1, index11));				
				
				int index12 = addedInfo.indexOf("-", index11+1);
				findP2_y = Integer.parseInt(addedInfo.substring(index11+1, index12));
				
				int index13 = addedInfo.indexOf("-", index12+1);
				replacePosP1_x = Integer.parseInt(addedInfo.substring(index12+1, index13));
				
				int index14 = addedInfo.indexOf("-", index13+1);
				replacePosP1_y = Integer.parseInt(addedInfo.substring(index13+1, index14));
				
				int index15 = addedInfo.indexOf("-", index14+1);
				replacePosP2_x = Integer.parseInt(addedInfo.substring(index14+1, index15));				
				
				
				replacePosP2_y = Integer.parseInt(addedInfo.substring(index15+1));
				
				editText.findP1.x = findP1_x;
				editText.findP1.y = findP1_y;
				editText.findP2.x = findP2_x;
				editText.findP2.y = findP2_y;
			}
			
		}			
		else { // isScopeAll==true
			if (!isAll) {// isScopeAll==true, isAll==false
				int index4 = addedInfo.indexOf("-", index3+1);
				isWholeWord = Boolean.parseBoolean(addedInfo.substring(index3+1, index4));
				
				int index9 = addedInfo.indexOf("-", index4+1);
				findP1_x = Integer.parseInt(addedInfo.substring(index4+1, index9));
				
				int index10 = addedInfo.indexOf("-", index9+1);
				findP1_y = Integer.parseInt(addedInfo.substring(index9+1, index10));
				
				int index11 = addedInfo.indexOf("-", index10+1);
				findP2_x = Integer.parseInt(addedInfo.substring(index10+1, index11));				
				
				int index12 = addedInfo.indexOf("-", index11+1);
				findP2_y = Integer.parseInt(addedInfo.substring(index11+1, index12));
				
				int index13 = addedInfo.indexOf("-", index12+1);
				replacePosP1_x = Integer.parseInt(addedInfo.substring(index12+1, index13));
				
				int index14 = addedInfo.indexOf("-", index13+1);
				replacePosP1_y = Integer.parseInt(addedInfo.substring(index13+1, index14));
				
				int index15 = addedInfo.indexOf("-", index14+1);
				replacePosP2_x = Integer.parseInt(addedInfo.substring(index14+1, index15));				
				
				addedInfo.indexOf("-", index15+1);
				replacePosP2_y = Integer.parseInt(addedInfo.substring(index15+1));
				
				editText.findP1.x = findP1_x;
				editText.findP1.y = findP1_y;
				editText.findP2.x = findP2_x;
				editText.findP2.y = findP2_y;
			}
			else {// isScopeAll==true, isAll==true
				isWholeWord = Boolean.parseBoolean(addedInfo.substring(index3+1));
			}
		}
		
		if (command.equals("replace")) { // replace-find
			ArrayListString listOfTextForNoneCaseSensitive = null;
			if (!isCaseSensitive) {
				listOfTextForNoneCaseSensitive = 
						FindReplaceOfEditText.getListOfTextForNoneCaseSensitive(editText, editText.findP1, editText.findP2);
			}
			
			Point oldFindP1 = new Point(editText.findP1.x, editText.findP1.y);
			Point oldFindP2 = new Point(editText.findP2.x, editText.findP2.y);
			
			// replace-find시에 검색한 위치를 textToReplaceWith로 바꾼다.
			// findP1, findP2는 대체한 위치가 된다.
			editText.findReplace.replaceCommon(isAll, editText.findP1, editText.findP2, textToFind, textToReplaceWith);
			
			if (isCaseSensitive) {
				UndoOfEditText.backUpForUndo_replace(editText, "replace", isAll, isForward, isScopeAll, isCaseSensitive, 
					isWholeWord, 
					oldFindP1, oldFindP2, 
					new Point(replacePosP1_x, replacePosP1_y), new Point(replacePosP2_x, replacePosP2_y), 
					textToFind, textToReplaceWith);
			}
			else {
				UndoOfEditText.backUpForUndo_replace(editText, "replace", isAll, isForward, isScopeAll, isCaseSensitive, 
						isWholeWord, 
						oldFindP1, oldFindP2, 
						new Point(replacePosP1_x, replacePosP1_y), new Point(replacePosP2_x, replacePosP2_y), 
						textToFind, textToReplaceWith, listOfTextForNoneCaseSensitive);
			}
			editText.moveToCursorPos(editText.cursorPos.x, editText.cursorPos.y);
		}
		else {//replaceAll
			
			ArrayList listFindPos = pair.listOfFindPos;
			ArrayList listReplacePos = pair.listOfReplacePos;
			
			ArrayListString listOfTextForNoneCaseSensitive = null;
			if (!isCaseSensitive) {
				listOfTextForNoneCaseSensitive = FindReplaceOfEditText.getListOfTextForNoneCaseSensitive(editText, listFindPos);
			}
			
			// 아래 for문에서 this.listFindPos가 바뀌므로 백업해두었다가
			// undoBuffer에 넣는다.
			ArrayList listBackupForFindPos = editText.getClone(listFindPos);
			int count = listReplacePos.count;
			int i;
			
			for (i=0; i<count; i+=2) {
				Point p1 = (Point)listFindPos.list[i];
				Point p2 = (Point)listFindPos.list[i+1];
				editText.findReplace.replaceCommon(isAll, p1, p2, textToFind, textToReplaceWith);
				
				if (!isScopeAll) {
					editText.findReplace.changeSelectP1AndP2(true, isForward, p1, p2, textToFind);
				}
				editText.findReplace.changeListFindPos(listFindPos, i+2, p1.y, textToFind, textToReplaceWith);
			}
			
			if (!isScopeAll) FunctionOfEditText.makeSelectIndices(editText, true, editText.selectP1, editText.selectP2);
			
			if (isCaseSensitive) {			
				UndoOfEditText.backUpForUndo_replace(editText, "replaceAll", isAll, isForward, isScopeAll, isCaseSensitive, 
					isWholeWord, curFindPosLocal, textToFind, textToReplaceWith, listBackupForFindPos, listReplacePos);
			}
			else {
				UndoOfEditText.backUpForUndo_replace(editText, "replaceAll", isAll, isForward, isScopeAll, isCaseSensitive, 
						isWholeWord, curFindPosLocal, textToFind, textToReplaceWith, listBackupForFindPos, listReplacePos, listOfTextForNoneCaseSensitive);
			}
			
			editText.setVScrollPos();
			editText.setVScrollBar();
			if (editText.scrollMode==ScrollMode.Both) {
				editText.setHScrollPos();
				editText.setHScrollBar();	
			}
			editText.isFound = false;
			
			
			
		}//replaceAll
		if (editText instanceof EditText_Compiler) {
			EditText_Compiler editText_Compiler = (EditText_Compiler) editText;
			if (editText_Compiler.getCompiler()!=null) {
				editText_Compiler.update(0, 0, "all", true);
			}
		}
	}
	
	/** undo를 한 뒤에 호출, back, delete, enter키의 조작 무효를 다시 실행한다.*/
	public static void redo(EditText editText) {
		if (editText.isReadOnly) return;
		
		RedoBufferOfEditText redoBuffer = editText.redoBuffer;
		
		// 터치시 한글모드와 버퍼를 초기화	
		Hangul.mode = Hangul.Mode.None;
		Hangul.resetBuffer();
		
		if (redoBuffer.buffer.count>0) {
			editText.isSelecting = false;
			
			editText.setIsModified(true);
			RedoBufferOfEditText.Pair pair = redoBuffer.pop();
			CodeString newLineText = pair.text;
			
			String command = pair.command;
			
			
			
			if (command.equals("cut")) {
				UndoOfEditText.backUpForUndo(editText, command, pair);
				
				int numToDelete;
				//int numOfNewLineChar = ((Integer)pair.addedInfo).intValue();
				int numOfNewLineChar = editText.getNumOfNewLineChar((String)pair.addedInfo) + 1;
				numToDelete = editText.getNumOfLinesInText(pair.cursorPos.y, editText.cursorPos.x, numOfNewLineChar);
				editText.setTextMultiLine(pair.cursorPos.y, newLineText, numToDelete);
				
				editText.cursorPos.x = pair.cursorPos.x;
				editText.cursorPos.y = pair.cursorPos.y;
			}
			else if (command.equals("paste")) {
				UndoOfEditText.backUpForUndo(editText, command, pair);
				
				int numToDelete;
				numToDelete = editText.getNumOfLinesInText(pair.cursorPos.y, editText.cursorPos.x, 1);
				
				editText.setTextMultiLine(pair.cursorPos.y, newLineText, numToDelete);
				
				editText.cursorPos = editText.getRelativeCursorPos(pair.cursorPos, (String)pair.addedInfo);
				
			}
			else if (command.equals("replace") || command.equals("replaceAll")) {
				
				if (command.equals("replace")) {
					
					redo_replace(editText, pair);
				}
				else {	// replaceAll
					// replaceAll일 경우 
					// redo를 undo하기 위한 백업은 redo_replace(pair)에서 한다.
					redo_replace(editText, pair);
				}
				
				//커서위치는 undo(), undo_replace(), redo(), redo_replace(), replace()에서 
				// 설정하지 않고 replaceCommon()에서 공통적으로 설정한다. 
				// 위 함수들이 공통적으로 replaceCommon()을 호출하기 때문이다.
				//cursorPos.x = pair.cursorPos.x;
				//cursorPos.y = pair.cursorPos.y;
			}
			else if (command.equals(BackspaceChar) || command.equals(NewLineChar) || command.equals(DeleteChar))
			{	// backspace와 delete는 모두 특별하게 '\n'을 제거한 경우이다.
				if (command.equals(BackspaceChar)) {
					if (pair.isSelecting) {
						UndoOfEditText.backUpForUndo(editText, BackspaceChar, pair);
						
						CodeString selectedText = (CodeString) pair.addedInfo; 
						int numToDelete;
						if (selectedText.count>0 && selectedText.charAt(selectedText.count-1).c=='\n') {
							numToDelete = editText.getNumOfNewLineChar(selectedText);
						}
						else {
							numToDelete = editText.getNumOfNewLineChar(selectedText) + 1;
						}
						
						editText.setTextMultiLine(pair.cursorPos.y, newLineText, numToDelete);
						
						editText.cursorPos.x = pair.cursorPos.x;
						editText.cursorPos.y = pair.cursorPos.y;
					}
					else {
						UndoOfEditText.backUpForUndo(editText, BackspaceChar, pair);
						
						int numToDelete;	// pair.cursorPos.y = undoPos.y(back키를누른위치) - 1
						if (pair.cursorPos.x==0) { // 0열에서 '\n'이 지워지는 back키만
							if (pair.cursorPos.y>0) {
								numToDelete = editText.getNumOfLinesInText(pair.cursorPos.y-1, editText.cursorPos.x, 2);
								
								int cursorPosX, cursorPosY;
								cursorPosX = editText.textArray[pair.cursorPos.y-1].count-1;
								cursorPosY = pair.cursorPos.y-1;
								editText.setTextMultiLine(pair.cursorPos.y-1, newLineText, numToDelete);
								editText.cursorPos.x = cursorPosX;
								editText.cursorPos.y = cursorPosY;
							}
							else {
								numToDelete = editText.getNumOfLinesInText(pair.cursorPos.y, editText.cursorPos.x, 1);
								
								editText.setTextMultiLine(pair.cursorPos.y, newLineText, numToDelete);
								editText.cursorPos.x = 0;
								editText.cursorPos.y = 0;
							}
						}
						else { // 일반적인 경우
							numToDelete = editText.getNumOfLinesInText(pair.cursorPos.y, editText.cursorPos.x, 1);
							
							editText.setTextMultiLine(pair.cursorPos.y, newLineText, numToDelete);
							editText.cursorPos.x = pair.cursorPos.x - 1;
							editText.cursorPos.y = pair.cursorPos.y;
						}
						
					}
					
				}
				else if (command.equals(DeleteChar)) {
					if (pair.isSelecting) {
						UndoOfEditText.backUpForUndo(editText, DeleteChar, pair);
						
						CodeString selectedText = (CodeString) pair.addedInfo; 
						int numToDelete;
						if (selectedText.count>0 && selectedText.charAt(selectedText.count-1).c=='\n') {
							numToDelete = editText.getNumOfNewLineChar(selectedText);
						}
						else {
							numToDelete = editText.getNumOfNewLineChar(selectedText) + 1;
						}
						
						editText.setTextMultiLine(pair.cursorPos.y, newLineText, numToDelete);
						
						editText.cursorPos.x = pair.cursorPos.x;
						editText.cursorPos.y = pair.cursorPos.y;
						
					}
					else {
						UndoOfEditText.backUpForUndo(editText, DeleteChar, pair);
						
						int numToDelete;
						if (pair.cursorPos.x==editText.textArray[pair.cursorPos.y].count-1) { 
							// 마지막열에서 '\n'이 지워지는 delete키만
							numToDelete = editText.getNumOfLinesInText(pair.cursorPos.y, editText.cursorPos.x, 2);
						}
						else {
							numToDelete = editText.getNumOfLinesInText(pair.cursorPos.y, editText.cursorPos.x, 1);
						}
						
						editText.setTextMultiLine(pair.cursorPos.y, newLineText, numToDelete);
						
						editText.cursorPos.x = pair.cursorPos.x;
						editText.cursorPos.y = pair.cursorPos.y;
					}
					
				}
				else if (command.equals(NewLineChar)) {
					
					UndoOfEditText.backUpForUndo(editText, NewLineChar, pair);
					
					// undo로 합쳐진 1줄 또는 여러 라인의 개수를 세어 그것들을 삭제하고 newLineText으로 바꾼다.
					int numToDelete;
					numToDelete = editText.getNumOfLinesInText(pair.cursorPos.y, editText.cursorPos.x, 1);
					
					editText.setTextMultiLine(pair.cursorPos.y, newLineText, numToDelete);
					editText.cursorPos.x = 0;
					editText.cursorPos.y = pair.cursorPos.y+1;
				}
			}//else if (command.equals(BackspaceChar) || command.equals(NewLineChar) || command.equals(DeleteChar))
			else {	// 일반적인 경우
				
				// a를 redo한 것을 undo하기 위해 백업
				//CodeString textForBackup = TextArrayToText(pair.cursorPos.y, 0, 1);
				//undoBuffer.push(new Point(cursorPos.x,pair.cursorPos.y), textForBackup);
				
				UndoOfEditText.backUpForUndo(editText, /*"general"*/command, pair);
				
				int numToDelete;
				numToDelete = editText.getNumOfLinesInText(pair.cursorPos.y, editText.cursorPos.x, 1);
				editText.setTextMultiLine(pair.cursorPos.y, newLineText, numToDelete);
				editText.cursorPos.x = pair.cursorPos.x+1;
				editText.cursorPos.y = pair.cursorPos.y;
			}
			editText.moveToCursorPos(editText.cursorPos.x, editText.cursorPos.y);
			
			if (editText instanceof EditText_Compiler) {
				EditText_Compiler editText_Compiler = (EditText_Compiler) editText;
				if (editText_Compiler.getCompiler()!=null) {
					editText_Compiler.update(0, 0, "all", true);
				}
			}
			
		}
	}
	
	/** 선택줄일때만 undo()에서 호출한다.<br>
	 * undo에서 undo를 하기 전의 상태(redo실행결과)를 backup한다. 후에 redo에서 복원한다.*/
	public static void backUpForRedo(EditText editText, String charA, CodeString textOfBackupForUndo, Point undoPos, Object addedInfo, boolean isSelecting, Point p2) {
		RedoBufferOfEditText redoBuffer = editText.redoBuffer;
		
		if (isSelecting) {
			if (charA.equals(BackspaceChar)) {	// 0열에서 '\n'이 지워지는 back키만
				CodeString newText=null;
				newText = editText.TextArrayToText(undoPos.y, undoPos.x, 1);
				redoBuffer.push(new Point(undoPos.x,undoPos.y), newText, charA, addedInfo, true, p2);
			}
			else if (charA.equals(DeleteChar)) { // 마지막열에서 '\n'이 지워지는 delete키만
				CodeString newText=null;
				newText = editText.TextArrayToText(undoPos.y, undoPos.x, 1);
				redoBuffer.push(new Point(undoPos.x,undoPos.y), newText, charA, addedInfo, true, p2);
			}
			else if (charA.equals(NewLineChar)) {
				CodeString newText=null;
				newText = editText.TextArrayToText(undoPos.y, undoPos.x, 1);
				backUpForRedo(editText, charA, newText, undoPos, addedInfo);
			}
			else { // 선택을 하고 문자키를 눌렀을때
				backUpForRedo(editText, charA, textOfBackupForUndo, undoPos, addedInfo);
			}
		}
		else {
			backUpForRedo(editText, charA, textOfBackupForUndo, undoPos, addedInfo);
		}
	}
	
	/** replace, replaceAll에서 호출한다.
	 * undo에서 undo를 하기 전의 상태(redo실행결과)를 backup한다. 후에 redo에서 복원한다.*/
	public static void backUpForRedo(EditText editText, String charA, CodeString textOfBackupForUndo, Point undoPos, boolean isSelecting, Object addedInfo, 
			ArrayList listFindPos, ArrayList listReplacePos) {
		editText.redoBuffer.push(undoPos, textOfBackupForUndo, charA, addedInfo, isSelecting, null, listFindPos, listReplacePos);
	}
	
	
	
	/** undo에서 undo를 하기 전의 상태(redo실행결과)를 backup한다. 후에 redo에서 복원한다.*/
	public static void backUpForRedo(EditText editText, String charA, CodeString textOfBackupForUndo, Point undoPos, Object addedInfo) {
		RedoBufferOfEditText redoBuffer = editText.redoBuffer;
		
		if (charA==null) {
			return;
		}
		if (charA.equals("cut")) {
			CodeString newText=null;
			newText = editText.TextArrayToText(undoPos.y, undoPos.x, 1);
			//redoBuffer.push(new Point(undoPos.x,undoPos.y), newText, charA, new Integer(numOfNewLineChar));
			redoBuffer.push(new Point(undoPos.x,undoPos.y), newText, charA, addedInfo);
			
		}
		else if (charA.equals("paste")) {
			String strAddedInfo = (String)addedInfo;
			// numOfNewLineChar = 선택텍스트의 newLineChar개수 + 원래의 1줄
			int numOfNewLineChar = editText.getNumOfNewLineChar(strAddedInfo) + 1;
			CodeString newText=null;
			newText = editText.TextArrayToText(undoPos.y, undoPos.x, numOfNewLineChar);
			redoBuffer.push(new Point(undoPos.x,undoPos.y), newText, charA, addedInfo);
			
		}
		else if (charA.equals("replace") || charA.equals("replaceAll")) {
			redoBuffer.push(new Point(undoPos.x,undoPos.y), textOfBackupForUndo, charA, addedInfo);			
		}		
		else if (charA.equals(DeleteChar) || charA.equals(NewLineChar) ||
				charA.equals(BackspaceChar))
		{
			if (charA.equals(BackspaceChar)) {	// 0열에서 '\n'이 지워지는 back키만
				if (undoPos.x==0) {
					CodeString newText=null;
					if (undoPos.y==0) {
						newText = editText.TextArrayToText(undoPos.y, undoPos.x, 1);
						redoBuffer.push(new Point(undoPos.x,undoPos.y), newText, charA);
					}
					else {
						newText = editText.TextArrayToText(undoPos.y-1, undoPos.x, 1);
						redoBuffer.push(new Point(undoPos.x,undoPos.y), newText, charA);
					}
				}
				else { // 일반적인 경우
					CodeString newText=null;
					newText = editText.TextArrayToText(undoPos.y, undoPos.x, 1);
					redoBuffer.push(new Point(undoPos.x,undoPos.y), newText, charA);				
				}
			}
			else if (charA.equals(DeleteChar)) { // 마지막열에서 '\n'이 지워지는 delete키만
				CodeString newText=null;
				newText = editText.TextArrayToText(undoPos.y, undoPos.x, 1);
				redoBuffer.push(new Point(undoPos.x,undoPos.y), newText, charA);
			}
			else if (charA.equals(NewLineChar)) {
				CodeString newText=null;
				newText = editText.TextArrayToText(undoPos.y, undoPos.x, 2);
				redoBuffer.push(new Point(undoPos.x,undoPos.y), newText, charA);
			}
		}//else if (charA.equals(DeleteChar) || charA.equals(NewLineChar) ||
		//charA.equals(BackspaceChar))
		else  {	// 일반적인 경우
			CodeString newText=null;
			newText = editText.TextArrayToText(undoPos.y, undoPos.x, 1);
			redoBuffer.push(new Point(undoPos.x,undoPos.y), newText, charA);
		}
	}
}
