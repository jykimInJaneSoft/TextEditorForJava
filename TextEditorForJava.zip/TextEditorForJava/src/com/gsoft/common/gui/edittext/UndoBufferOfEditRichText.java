package com.gsoft.common.gui.edittext;

import android.graphics.Point;

import com.gsoft.common.gui.edittext.EditRichText_Types.TextLine;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListString;

public class UndoBufferOfEditRichText {
	static class Pair {
		TextLine text;
		Point cursorPos;
		String command;
		Object addedInfo;
		public boolean isSelecting;
		/** ReplaceAll에서 빈 스트링("")으로 대체된 경우 null 이 아니다.
		 * replaceAll할때에 검색된 좌표들을 백업한다.*/
		ArrayList listOfFindPos;
		/** replaceAll할때에 대체된 좌표들을 백업한다.*/
		ArrayList listOfReplacePos;
		/**NoneCaseSensitive일때에 replace-find, replaceAll에서 원래 텍스트들을 백업한다.*/
		ArrayListString listOfTextForNoneCaseSensitive;
	}
	ArrayList buffer = new ArrayList(50);
	ArrayList arrayCursorPos = new ArrayList(50);
	ArrayListString bufferCommand = new ArrayListString(50);
	ArrayList arrayAddedInfo = new ArrayList(50);
	ArrayList arrayIsSelecting = new ArrayList(50);
	private ArrayList arrayListOfFindPos = new ArrayList(50);
	private ArrayList arrayListOfReplacePos = new ArrayList(50);
	ArrayList arrayListOfTextForNoneCaseSensitive = new ArrayList(50);
	
	
	void reset() {
		buffer.reset();
		arrayCursorPos.reset();
		bufferCommand.destroy();
		arrayAddedInfo.reset();
		arrayIsSelecting.reset();
		arrayListOfFindPos.reset();
		arrayListOfReplacePos.reset();
		arrayListOfTextForNoneCaseSensitive.reset();
	}
	/*void push(Point cursorPos, TextLine text) {
		buffer.add(text);
		arrayCursorPos.add(cursorPos);
		bufferCommand.add("");
		arrayAddedInfo.add(null);
		arrayIsSelecting.add(null);
	}*/
	void push(Point cursorPos, TextLine text, String charA) {
		buffer.add(text);
		arrayCursorPos.add(cursorPos);
		bufferCommand.add(charA);
		arrayAddedInfo.add(null);
		arrayIsSelecting.add(null);
		arrayListOfFindPos.add(null);
		arrayListOfReplacePos.add(null);
		arrayListOfTextForNoneCaseSensitive.add(null);
	}
	void push(Point cursorPos, TextLine text, String charA, Object addedInfo) {
		buffer.add(text);
		arrayCursorPos.add(cursorPos);
		bufferCommand.add(charA);
		arrayAddedInfo.add(addedInfo);
		arrayIsSelecting.add(null);
		arrayListOfFindPos.add(null);
		arrayListOfReplacePos.add(null);
		arrayListOfTextForNoneCaseSensitive.add(null);
	}
	
	void push(Point cursorPos, TextLine text, String charA, Object addedInfo, ArrayListString listOfTextForNoneCaseSensitive) {
		buffer.add(text);
		arrayCursorPos.add(cursorPos);
		bufferCommand.add(charA);
		arrayAddedInfo.add(addedInfo);
		arrayIsSelecting.add(null);
		arrayListOfFindPos.add(null);
		arrayListOfReplacePos.add(null);
		arrayListOfTextForNoneCaseSensitive.add(listOfTextForNoneCaseSensitive);
	}
	void push(Point cursorPos, TextLine text, String charA, Object addedInfo, ArrayList listOfFindPos) {
		buffer.add(text);
		arrayCursorPos.add(cursorPos);
		bufferCommand.add(charA);
		arrayAddedInfo.add(addedInfo);
		arrayIsSelecting.add(null);
		arrayListOfFindPos.add(listOfFindPos);
		arrayListOfReplacePos.add(null);
		arrayListOfTextForNoneCaseSensitive.add(null);
	}
	void push(Point cursorPos, TextLine text, String charA, Object addedInfo, ArrayList listOfFindPos, ArrayList listOfReplacePos) {
		buffer.add(text);
		arrayCursorPos.add(cursorPos);
		bufferCommand.add(charA);
		arrayAddedInfo.add(addedInfo);
		arrayIsSelecting.add(null);
		arrayListOfFindPos.add(listOfFindPos);
		arrayListOfReplacePos.add(listOfReplacePos);
		arrayListOfTextForNoneCaseSensitive.add(null);
	}
	
	void push(Point cursorPos, TextLine text, String charA, Object addedInfo, ArrayList listOfFindPos, ArrayList listOfReplacePos, ArrayListString listOfTextForNoneCaseSensitive) {
		buffer.add(text);
		arrayCursorPos.add(cursorPos);
		bufferCommand.add(charA);
		arrayAddedInfo.add(addedInfo);
		arrayIsSelecting.add(null);
		arrayListOfFindPos.add(listOfFindPos);
		arrayListOfReplacePos.add(listOfReplacePos);
		arrayListOfTextForNoneCaseSensitive.add(listOfTextForNoneCaseSensitive);
	}
	void push(Point cursorPos, TextLine text, String charA, Object addedInfo, boolean isSelecting) {
		buffer.add(text);
		arrayCursorPos.add(cursorPos);
		bufferCommand.add(charA);
		arrayAddedInfo.add(addedInfo);
		arrayIsSelecting.add(new Boolean(isSelecting));
		arrayListOfFindPos.add(null);
		arrayListOfReplacePos.add(null);
		arrayListOfTextForNoneCaseSensitive.add(null);
	}
	UndoBufferOfEditRichText.Pair pop() {
		UndoBufferOfEditRichText.Pair pair = new UndoBufferOfEditRichText.Pair();
		pair.text = (TextLine) buffer.getItem(buffer.count-1);
		pair.cursorPos = (Point)arrayCursorPos.getItem(arrayCursorPos.count-1);			
		String command = bufferCommand.getItem(bufferCommand.count-1);
		pair.command = command;
		pair.addedInfo = arrayAddedInfo.getItem(arrayAddedInfo.count-1);
		Boolean b = (Boolean) arrayIsSelecting.getItem(arrayIsSelecting.count-1);
		if (b!=null) {
			pair.isSelecting = b.booleanValue();
		}
		pair.listOfFindPos = (ArrayList) arrayListOfFindPos.getItem(arrayListOfFindPos.count-1);
		try {
		pair.listOfReplacePos = (ArrayList) arrayListOfReplacePos.getItem(arrayListOfReplacePos.count-1);
		pair.listOfTextForNoneCaseSensitive = (ArrayListString) arrayListOfTextForNoneCaseSensitive.getItem(arrayListOfTextForNoneCaseSensitive.count-1);
		}catch(Exception e) {
			e.printStackTrace();
		}
		buffer.count--;
		arrayCursorPos.count--;
		bufferCommand.count--;
		arrayAddedInfo.count--;
		arrayIsSelecting.count--;
		arrayListOfFindPos.count--;
		arrayListOfReplacePos.count--;
		arrayListOfTextForNoneCaseSensitive.count--;
		return pair;
	}
}
