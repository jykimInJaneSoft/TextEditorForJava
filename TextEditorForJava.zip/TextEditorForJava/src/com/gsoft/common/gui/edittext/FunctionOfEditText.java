package com.gsoft.common.gui.edittext;

import android.graphics.Color;
import android.graphics.Point;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.CommonGUI;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.Events.MotionEvent;
import com.gsoft.common.Sizing.Rectangle;
import com.gsoft.common.Sizing.Size;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.EditText_Compiler;
import com.gsoft.common.compiler.Update;
import com.gsoft.common.compiler.gui.CurPathText;
import com.gsoft.common.gui.Control;
import com.gsoft.common.gui.FindReplaceDialog;
import com.gsoft.common.gui.IntegrationKeyboard;
import com.gsoft.common.gui.IntegrationKeyboard.Hangul;
import com.gsoft.common.gui.IntegrationKeyboard.Mode;
import com.gsoft.common.gui.Menu.MenuType;
import com.gsoft.common.gui.MenuWithAlwaysOpen;
import com.gsoft.common.gui.TextView;
import com.gsoft.common.gui.edittext.Edit.ScrollMode;
import com.gsoft.common.gui.edittext.EditText.BoundMode;
import com.gsoft.common.gui.edittext.EditText.PartOfStr;
import com.gsoft.common.gui.edittext.EditText.SetTextThread;
import com.gsoft.common.util.Array;
import com.gsoft.common.util.ArrayListChar;
import com.gsoft.common.util.ArrayListCodeChar;
import com.gsoft.common.util.ArrayListCodeString;

import com.gsoft.common.gui.edittext.EditText;
import com.gsoft.common.gui.edittext.UndoOfEditText;
import com.gsoft.common.gui.edittext.RedoOfEditText;
import com.gsoft.common.gui.edittext.Edit;

public class FunctionOfEditText {
	
	private static Point oldMotionPos = new Point();
	private static Point curMotionPos = new Point();
	private static boolean ActionDownClicked;



	public static void changeFontSize(EditText editText, float fontSize) {
		editText.fontSize = fontSize;
		editText.setDescentAndLineHeight(fontSize);
		//int toolbarButtonIndex = toolbar.findIndex("S");
		if (editText.toolbar!=null) editText.toolbar.buttons[0].setText(""+fontSize);
		editText.paint.setTextSize(fontSize);
		
		
		if (editText.scrollMode==ScrollMode.VScroll) {
			SetTextThread thread = new SetTextThread(editText, true);
			thread.start();
		}
		else {	// Both모드일 때는 setText()를 호출할 필요가 없으므로 더 빠르다. 
			// 그리고 cursorPos도 바뀌지 않는다.
			editText.bound(BoundMode.FontSize, false);
			
			CommonGUI.loggingForMessageBox.setHides(true);
			Control.view.postInvalidate();
			
			//}
		}
	}
	
	
	/**"Left", "Right", "Up", "Down", "Home", "End", "PgUp", "PgDn"*/
	public static  void controlChar(EditText editText, int indexInSpecialKeys, String charA) {
		if (IntegrationKeyboard.isAltPressed) {
			if (editText.isSelecting) {
				Point p1=null, p2=null;
				if (editText.selectP1.y < editText.selectP1.y) {
					p1 = editText.selectP1;
					p2 = editText.selectP2;
				}
				else if (editText.selectP1.y == editText.selectP1.y) {
					if (editText.selectP1.x < editText.selectP1.x) {
						p1 = editText.selectP1;
						p2 = editText.selectP2;
					}
					else if (editText.selectP1.x == editText.selectP1.x) {
						p1 = editText.selectP1;
						p2 = editText.selectP2;
					}
					else {
						p1 = editText.selectP2;
						p2 = editText.selectP1;
					}
				}
				else {
					p1 = editText.selectP2;
					p2 = editText.selectP1;
				}
				if (indexInSpecialKeys==1) { //"Right")
					for (int i=p1.y; i<=p2.y; i++) {
						if (i==p1.y) {
							editText.cursorPos.x = p1.x;
							editText.cursorPos.y = p1.y;
						}
						else {
							int j;
							for (j=0; j<editText.textArray[i].count; j++) {
								if (!CompilerHelper.IsBlank(editText.textArray[i].charAt(j).c)) break;
							}
							if (j<editText.textArray[i].count) {
								editText.cursorPos.x = j;
								editText.cursorPos.y = i;
							}
							else {
								if (editText.textArray[i].count==0) {
									editText.cursorPos.x = 0;
								}
								else if (editText.textArray[i].count-1>=0 && editText.textArray[i].charAt(editText.textArray[i].count-1).c=='\n') {
									editText.cursorPos.x = editText.textArray[i].count-1;
								}
								else {
									editText.cursorPos.x = editText.textArray[i].count-1;
								}
								editText.cursorPos.y = i;
							}
						}
						editText.addChar(" ");
					}// for (int i=p1.y; i<=p2.y; i++) {
					p1.x++;
					p2.x++;
					FunctionOfEditText.makeSelectIndices(editText, true, p1, p2);
				} // if (indexInSpecialKeys==1) { //"Right")
				else if (indexInSpecialKeys==0) { // "Left"
					// Because Select + Delete = BlockDelete, turn off isSelecting
					editText.isSelecting = false;
					boolean canMove = true;
					for (int i=p1.y; i<=p2.y; i++) {
						if (i==p1.y) {
							if (p1.x-1>=0 && CompilerHelper.IsBlank(editText.textArray[i].charAt(p1.x-1).c)) {
							}
							else {
								canMove = false;
								break;
							}
						}
						else {
							int j;
							for (j=0; j<editText.textArray[i].count; j++) {
								if (!CompilerHelper.IsBlank(editText.textArray[i].charAt(j).c)) break;
							}
							if (j<editText.textArray[i].count) {
								if (j-1>=0 && CompilerHelper.IsBlank(editText.textArray[i].charAt(j-1).c)) {
								}
								else {
									canMove = false;
									break;
								}
							}
							else {
								if (editText.textArray[i].count==0) {
									canMove = false;
									break;
								}
								else if (editText.textArray[i].count==1 && editText.textArray[i].charAt(editText.textArray[i].count-1).c=='\n') {
									canMove = false;
									break;
								}
							}
						}						
					}// for (int i=p1.y; i<=p2.y; i++) {
					
					if (canMove) {
						for (int i=p1.y; i<=p2.y; i++) {
							if (i==p1.y) {
								if (p1.x-1>=0 && CompilerHelper.IsBlank(editText.textArray[i].charAt(p1.x-1).c)) {
									editText.cursorPos.x = p1.x-1;
									editText.cursorPos.y = p1.y;
									editText.addChar(IntegrationKeyboard.Delete);
									p1.x--;
								}
							}
							else {
								int j;
								for (j=0; j<editText.textArray[i].count; j++) {
									if (!CompilerHelper.IsBlank(editText.textArray[i].charAt(j).c)) break;
								}
								if (j<editText.textArray[i].count) {
									if (j-1>=0 && CompilerHelper.IsBlank(editText.textArray[i].charAt(j-1).c)) {
										editText.cursorPos.x = j-1;
										editText.cursorPos.y = i;
										editText.addChar(IntegrationKeyboard.Delete);
										if (i==p2.y) p2.x--;
									}
								}
								else {
									if (editText.textArray[i].charAt(editText.textArray[i].count-1).c=='\n') {
										editText.cursorPos.x = editText.textArray[i].count-2;
									}
									else {
										editText.cursorPos.x = editText.textArray[i].count-1;
									}
									editText.cursorPos.y = i;
									editText.addChar(IntegrationKeyboard.Delete);
									if (i==p2.y) p2.x--;
								}
							}						
						}// for (int i=p1.y; i<=p2.y; i++) {
						
						FunctionOfEditText.makeSelectIndices(editText, true, p1, p2);
					} // if (canMove)
					editText.isSelecting = true;
				} // if (indexInSpecialKeys==0) { //"Left")
			}// if (editText.isSelecting) {
			
		} // if (IntegrationKeyboard.isAltPressed) {
		else {
			Point cursorPos = editText.cursorPos;
			
			if (!IntegrationKeyboard.isShiftPressed) {
				if (0<=indexInSpecialKeys && indexInSpecialKeys<=7)
					editText.isSelecting = false;
			}
			else {
				if (!editText.isSelecting) {
					if (editText.selectP1==null) editText.selectP1 = new Point();
					if (indexInSpecialKeys==1 || indexInSpecialKeys==3 || indexInSpecialKeys==5 || indexInSpecialKeys==7) {
						editText.selectP1.x = cursorPos.x; 
						editText.selectP1.y = cursorPos.y;
					}
					else {
						int p1_x = cursorPos.x-1>=0 ? cursorPos.x-1 : 0;
						editText.selectP1.x = p1_x; 
						editText.selectP1.y = cursorPos.y;
					}
				}
			}
					
			CodeString[] textArray = editText.textArray;
			
			switch (indexInSpecialKeys) {
				case 0: { // "Left"
					if (cursorPos.x>0) cursorPos.x--;
					else {
						if (cursorPos.x==0 && cursorPos.y>0) {
							cursorPos.y--;
							cursorPos.x = textArray[cursorPos.y].length()-1;// Points to '\n'
						}
					}
					break;
				}				
				case 1: { //"Right"
					if (cursorPos.y<editText.numOfLines-1 && 
							cursorPos.x==textArray[cursorPos.y].count-1) { // Points to '\n'
						cursorPos.y++;
						cursorPos.x = 0;
					}
					else {
						cursorPos.x++;
					}
					if (cursorPos.x>=textArray[cursorPos.y].count) {
						if (textArray[cursorPos.y].count>0 &&
								textArray[cursorPos.y].charAt(textArray[cursorPos.y].count-1).c=='\n') {
							cursorPos.x = textArray[cursorPos.y].count-1;
						}
						else {
							cursorPos.x = textArray[cursorPos.y].count;
						}
					}					
					if (cursorPos.x<0) cursorPos.x = 0;
					break;
				}
				case 2: { //"Up"
					if (cursorPos.y>0) cursorPos.y--;
					if (cursorPos.x>=textArray[cursorPos.y].count) {
						if (textArray[cursorPos.y].count>0 &&
								textArray[cursorPos.y].charAt(textArray[cursorPos.y].count-1).c=='\n') {
							cursorPos.x = textArray[cursorPos.y].count-1;
						}
						else {
							cursorPos.x = textArray[cursorPos.y].count;
						}
					}					
					if (cursorPos.x<0) cursorPos.x = 0; 
					break;
				}
				case 3: { // "Down"
					if (cursorPos.y<editText.numOfLines-1) cursorPos.y++; 
					if (cursorPos.x>=textArray[cursorPos.y].count) {
						if (textArray[cursorPos.y].count>0 &&
								textArray[cursorPos.y].charAt(textArray[cursorPos.y].count-1).c=='\n') {
							cursorPos.x = textArray[cursorPos.y].count-1;
						}
						else {
							cursorPos.x = textArray[cursorPos.y].count;
						}
					}
					if (cursorPos.x<0) cursorPos.x = 0;
					break;
				}
				case 4: cursorPos.x = 0; break; //"Home"
				case 5: { // "End"
					cursorPos.x = textArray[cursorPos.y].count-1;
					if (cursorPos.x<0) cursorPos.x = 0;
					break;
				}
				case 6: { // "PgUp"
							cursorPos.y -= editText.numOfLinesPerPage;
							if (cursorPos.y<0) cursorPos.y = 0;
							if (cursorPos.x>=textArray[cursorPos.y].count) {
								if (textArray[cursorPos.y].count>0 &&
										textArray[cursorPos.y].charAt(textArray[cursorPos.y].count-1).c=='\n') {
									cursorPos.x = textArray[cursorPos.y].count-1;
								}
								else {
									cursorPos.x = textArray[cursorPos.y].count;
								}
							}
							if (cursorPos.x<0) cursorPos.x = 0;
							break;
					
						}
				case 7: { // "PgDn"
							cursorPos.y += editText.numOfLinesPerPage;
							if (cursorPos.y>=editText.numOfLines) cursorPos.y = editText.numOfLines-1;
							if (cursorPos.x>=textArray[cursorPos.y].count) {
								if (textArray[cursorPos.y].count>0 &&
										textArray[cursorPos.y].charAt(textArray[cursorPos.y].count-1).c=='\n') {
									cursorPos.x = textArray[cursorPos.y].count-1;
								}
								else {
									cursorPos.x = textArray[cursorPos.y].count;
								}
							}
							if (cursorPos.x<0) cursorPos.x = 0;
							break;
					
						}
			} // switch
			
			editText.cursorPos = cursorPos;
			
			editText.textArray = textArray;
			
			if (IntegrationKeyboard.isShiftPressed) {			
				if (editText.selectP2==null) editText.selectP2 = new Point();
				if (indexInSpecialKeys==1 || indexInSpecialKeys==3 || indexInSpecialKeys==5 || indexInSpecialKeys==7) {
					int p2_x = cursorPos.x-1>=0 ? cursorPos.x-1 : 0;
					editText.selectP2.x = p2_x; 
					editText.selectP2.y = cursorPos.y;
				}
				else {
					
					editText.selectP2.x = cursorPos.x; 
					editText.selectP2.y = cursorPos.y;
				}
				//editText.selectP2.x = cursorPos.x; 
				//editText.selectP2.y = cursorPos.y;
				editText.isSelecting = true;
				makeSelectIndices(editText, true, editText.selectP1, editText.selectP2);
			}
		} // if (!IntegrationKeyboard.isAltPressed)
			
			if (editText.scrollMode==ScrollMode.VScroll) {			
				editText.setVScrollPos();
				editText.setVScrollBar();
			}		
			else if (editText.scrollMode==ScrollMode.Both) {
				editText.setVScrollPos();
				editText.setHScrollPos();
				editText.setVScrollBar();
				if (editText.hScrollBar!=null) {
					editText.setHScrollBar();
				}
			}
		
	}
	
	
	public static void copy(EditText editText) {
		if (editText.isSelecting) {
			editText.isCopied = true;
			int i;
			int y;
			int startX, endX;
			editText.copiedText = "";
			for (i=0; i<editText.selectIndicesCountForCopy; i+=2) {
				try {
					if (i==editText.selectIndicesCountForCopy-2) {
					}
				y = editText.selectIndices[i].y;
				startX = editText.selectIndices[i].x;
				endX = editText.selectIndices[i+1].x;
				CodeString lineCopiedText = editText.textArray[y].substring(startX, endX+1);
				editText.copiedText += lineCopiedText.str;
				}catch(Exception e) {
					if (Common_Settings.g_printsLog) e.printStackTrace();
				}
			}
			
			//if (Control.CurrentSystem.equals(Control.CurrentSystemIsJava)) {
				Control.ClipBoardX.setData(editText.copiedText);
				
				//if (editText instanceof EditText_Compiler) {
				//	Update.update((EditText_Compiler) editText, null, 0, 0, true, null, "all");
				//}
			//}
		}
	}
	
	public static void cut(EditText editText) {
		if (editText.isReadOnly) return;
		
		editText.setIsModified(true);
		try {
		if (editText.isSelecting) {
			editText.isCopied = true;
			int i;
			int y;
			int startX, endX;
			editText.copiedText = "";
			int[] fullLines = new int[10];
			int fullLinesCount = 0;
			
			UndoOfEditText.backUpForUndo(editText, "cut", false);
			// redo 를 무효화한다. redoBuffer를 모두 지워야 한다. 
			// redo 를 무효로 만들지 않으면 undo-redo 시스템의 오류가 발생한다.
			editText.redoBuffer.reset();
			
			for (i=0; i<editText.selectIndicesCountForCopy; i+=2) {
				if (i==editText.selectIndicesCountForCopy-2) {
				}
				y = editText.selectIndices[i].y;
				startX = editText.selectIndices[i].x;
				endX = editText.selectIndices[i+1].x;
				CodeString lineCopiedText = editText.textArray[y].substring(startX, endX+1);
				editText.copiedText += lineCopiedText.str;
				
				if (editText.textArray[y].length()==lineCopiedText.length()) { 
					// full line이면 줄 자체를 삭제
					if (!(fullLinesCount<=fullLines.length-1)) 
						fullLines = Array.Resize(fullLines, fullLines.length+10);
					fullLines[fullLinesCount++] = y;
				}
				else {
					ArrayListCodeChar list = new ArrayListCodeChar(30);
					list.setText(editText.textArray[y]);
					list.delete(startX, endX-startX+1);
					editText.textArray[y] = new CodeString(list.getItems(), list.count);
				}
			}
			
			// full line이면 줄 자체를 삭제
			if (fullLinesCount>0) {
				ArrayListCodeString listTextArray = new ArrayListCodeString(editText.textArray);
				listTextArray.delete(fullLines[0], fullLinesCount);
				editText.textArray = listTextArray.getItems();
				editText.numOfLines -= fullLinesCount;
			}
			
			
			
			// full line을 제외한 select영역에 포함된 newline문자를 제거한다.
			CodeString newText = editText.TextArrayToText(editText.selectIndices[0].y, editText.cursorPos.x, 1);
			editText.setTextMultiLine(editText.selectIndices[0].y, newText, -1);
			
			
			Point p1 = editText.selectP1;
			if (editText.selectP1.y>editText.selectP2.y) { // swapping
				p1 = editText.selectP2;
			}
			else if (editText.selectP1.y==editText.selectP2.y) {
				if (editText.selectP1.x>editText.selectP2.x) {
					// swapping, y가 같을땐 x를 비교해서 작은쪽이 p1이 된다.
					p1 = editText.selectP2;
				}
			}
			
			Control.ClipBoardX.setData(editText.copiedText);
			
			editText.cursorPos.x = p1.x;
			editText.cursorPos.y = p1.y;
			
			editText.isSelecting = false;
			
			if (editText instanceof EditText_Compiler) {
				Update.update("all");
			}
		}
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
			if (Common_Settings.g_printsLog) CompilerHelper.printStackTrace(editText.textViewLogBird, e);
		}
	}
	
	public static void paste(EditText editText) {
		if (editText.isReadOnly) return;
		
		//if (Control.CurrentSystem.equals(Control.CurrentSystemIsJava)) {
			String dataClipboard = Control.ClipBoardX.getData();
			if (dataClipboard!=null) {
				editText.isCopied = true;
				editText.copiedText = dataClipboard;
			}
		//}
		
		if (!editText.isCopied) return;
		
		editText.setIsModified(true);
		
		UndoOfEditText.backUpForUndo(editText, "paste", false);
		// redo 를 무효화한다. redoBuffer를 모두 지워야 한다. 
		// redo 를 무효로 만들지 않으면 undo-redo 시스템의 오류가 발생한다.
		editText.redoBuffer.reset();
		
		
		Point cursorPos = editText.cursorPos;
		
		CodeString left = editText.textArray[cursorPos.y].substring(0, cursorPos.x);
		CodeString right = editText.textArray[cursorPos.y].substring(cursorPos.x, 
				editText.textArray[cursorPos.y].length());
		CodeString newCurLineText = new CodeString(left.str + editText.copiedText + right.str, editText.textColor);
		
		Point oldCursorPos = new Point();
		oldCursorPos.x = cursorPos.x;
		oldCursorPos.y = cursorPos.y;
		
	
		editText.setTextMultiLine(cursorPos.y, newCurLineText, 1);
		
		Point relativeCursorPos = editText.getRelativeCursorPos(oldCursorPos, editText.copiedText);
		
		editText.cursorPos = relativeCursorPos;
		
		if (editText instanceof EditText_Compiler) {
			Update.update("all");
		}
		
		Control.view.invalidate();
			
		
	}
	
	
	public static String processSpecialChar(EditText editText, String str) {
		int i;
		ArrayListChar list = new ArrayListChar(30);
		list.setText(str);
		for (i=0; i<list.count; i++) {
			if (list.list[i]=='\\') {
				if (i+1<list.count) {
					if (list.list[i+1]=='n') { 
						list.list[i] = '\n';
						list.delete(i+1, 1);
					}
					else if (list.list[i+1]=='r') {
						list.list[i] = '\r';
						list.delete(i+1, 1);
					}
					else if(list.list[i+1]=='t') {
						list.list[i] = '\t';
						list.delete(i+1, 1);
					}
					
				}
			}
		}
		char[] arr = list.getItems();
		return new String(arr);
	}
	
	
	public static void findReplaceDialog_Listener(EditText editText, Object sender, MotionEvent e) {
		FindReplaceDialog dialog = (FindReplaceDialog)sender;
		if (Common_Settings.settings.EnablesScreenKeyboard) {
			CommonGUI.keyboard.setHides(true);
		}
		if (dialog.recentCommand.equals("Find")) {
			boolean isForward = dialog.buttonDirection.text.equals("Forward") ? true : false;
			boolean isScopeAll = dialog.buttonScope.text.equals("All") ? true : false;
			boolean isCaseSensitive = dialog.buttonCaseSensitive.getIsSelected();
			boolean isWholeWord = dialog.buttonWholeWord.getIsSelected();
			//curFindPos.x = cursorPos.x; 
			//curFindPos.y = cursorPos.y; 
			editText.findReplace.find(false, isForward, isScopeAll, isCaseSensitive, isWholeWord, 
					editText.cursorPos, dialog.editTextFind.getText().str, true);
			if (editText instanceof EditText_Compiler) {
				EditText_Compiler editText_compiler = (EditText_Compiler) editText; 
				CurPathText.setCurPathTextPlusProjectName(editText_compiler.getCompiler(), editText_compiler.cursorPos.x, editText_compiler.cursorPos.y, editText_compiler.getShowsCurPath());
			}
			dialog.setHides(true);
			
		}
		else if (dialog.recentCommand.equals("Replace-Find")) {
			boolean isForward = dialog.buttonDirection.text.equals("Forward") ? true : false;
			boolean isScopeAll = dialog.buttonScope.text.equals("All") ? true : false;
			boolean isCaseSensitive = dialog.buttonCaseSensitive.getIsSelected();
			boolean isWholeWord = dialog.buttonWholeWord.getIsSelected();
			//curFindPos.x = cursorPos.x; 
			//curFindPos.y = editText.cursorPos.y; 
			editText.findReplace.replace(false, isForward, isScopeAll, isCaseSensitive, isWholeWord, editText.cursorPos, 
				dialog.editTextFind.getText().str, dialog.editTextReplaceWith.getText().str);
		
			if (editText instanceof EditText_Compiler) {
				EditText_Compiler editText_compiler = (EditText_Compiler) editText; 
				CurPathText.setCurPathTextPlusProjectName(editText_compiler.getCompiler(), editText_compiler.cursorPos.x, editText_compiler.cursorPos.y, editText_compiler.getShowsCurPath());
			}
			dialog.setHides(true);
		}
		else if (dialog.recentCommand.equals("ReplaceAll")) {
			// ReplaceAll은 scrollMode가 Both일 때만 동작한다.
			if (editText.scrollMode==ScrollMode.VScroll) {
				CommonGUI.loggingForMessageBox.setHides(false);
				CommonGUI.loggingForMessageBox.setText(true, "ReplaceAll operates only in Both scrollMode.", false);
				return;
			}
			
			boolean isForward = dialog.buttonDirection.text.equals("Forward") ? true : false;
			boolean isScopeAll = dialog.buttonScope.text.equals("All") ? true : false;
			boolean isCaseSensitive = dialog.buttonCaseSensitive.getIsSelected();
			boolean isWholeWord = dialog.buttonWholeWord.getIsSelected();
			if (isScopeAll) {
				editText.cursorPos.x = 0;
				editText.cursorPos.y = 0;
			}
			else {
				if (!editText.isSelecting) return;
				if (editText.selectP1.y == editText.selectP2.y) {
					if (editText.selectP1.x < editText.selectP2.x) {
						editText.cursorPos.x = editText.selectP1.x;
						editText.cursorPos.y = editText.selectP1.y;
					}
					else {
						editText.cursorPos.x = editText.selectP2.x;
						editText.cursorPos.y = editText.selectP2.y;
					}
				}
				else {
					if (editText.selectP1.y < editText.selectP2.y) {
						editText.cursorPos.x = editText.selectP1.x;
						editText.cursorPos.y = editText.selectP1.y;
					}
					else {
						editText.cursorPos.x = editText.selectP2.x;
						editText.cursorPos.y = editText.selectP2.y;
					}
				}
			}
			//curFindPos.x = editText.cursorPos.x; 
			//curFindPos.y = editText.cursorPos.y; 
			editText.findReplace.replace(true, isForward, isScopeAll, isCaseSensitive, isWholeWord, editText.cursorPos, 
				dialog.editTextFind.getText().str, dialog.editTextReplaceWith.getText().str);
			
			dialog.setHides(true);
		}
		else if (dialog.recentCommand.equals("Close")) {
			//curFindPos.x = 0;
			//curFindPos.y = 0;
		}
	}
	
	public static void integrationKeyboard_Listener(EditText editText, Object sender, MotionEvent e) {
		IntegrationKeyboard keyboard = (IntegrationKeyboard)sender;
		
		// 키보드 가속기는 isReadOnly가 true이더라도 실행이 된다.
		if (IntegrationKeyboard.isCtrlPressed) {
			if (keyboard.key.equals("Z")) {
				UndoOfEditText.undo(editText);
				return;
			}
			else if (keyboard.key.equals("Y")) {
				RedoOfEditText.redo(editText);
				return;
			}
			else if (keyboard.key.equals("F")) {
				FunctionOfEditText.openFindReplaceDialog(editText);
				return;
			}
			else if (keyboard.key.equals("C")) {
				FunctionOfEditText.copy(editText);
				return;
			}
			else if (keyboard.key.equals("X")) {
				FunctionOfEditText.cut(editText);
				return;
			}
			else if (keyboard.key.equals("V")) {
				FunctionOfEditText.paste(editText);
				return;
			}
			else if (keyboard.key.equals("A")) {
				FunctionOfEditText.selectAll(editText);
				return;
			}
			
		}//키보드 가속기
		
		if (!IntegrationKeyboard.isAltPressed) {
			// Arrow Key, 
			// Shift + Arrow Key = Select
			if (IntegrationKeyboard.getIndexInSpecialKeys(CommonGUI.keyboard.key)!=-1) {
				editText.controlChar(keyboard.key);
				return;
			}
		}
		
		
		if (editText.isReadOnly) return;
		
		
		if (IntegrationKeyboard.isAltPressed) {
			// ALT + Arrow Key = SelectBlock Move
			if (IntegrationKeyboard.getIndexInSpecialKeys(CommonGUI.keyboard.key)!=-1) {
				editText.controlChar(keyboard.key);
				return;
			}
		}
		
		
		if (editText.listener!=null) {
			if (keyboard.key.equals(IntegrationKeyboard.Enter)) {
				editText.listener.onTouchEvent(editText, null);
				return;
			}
		}
		
		editText.keyboardMode = keyboard.mode;
		editText.hangulMode = Hangul.mode;
							
		if (keyboard.mode!=Mode.Hangul) {
			try {
				editText.addChar(keyboard.key/*, false*/);
			}catch(Exception e1) {
				e1.printStackTrace();
				CompilerHelper.printStackTrace(editText.textViewLogBird, e1);
			}
		}
		else {//if (keyboard.mode==Mode.Hangul) {
			if (Hangul.isBkSpPressed) {
				editText.replaceChar(keyboard.key);
				return;
			}
									
			if (Hangul.mode==Hangul.Mode.None) {
				// space, delete, enter 키는 Hangul.mode가 None이다.
				// 그리고 isNextToCursor는 true로 설정되어 커서다음위치에 
				// key가 추가된다.
				editText.addChar(keyboard.key/*, false*/);
			}						
			else if (Hangul.mode==Hangul.Mode.ChoSung ||
					Hangul.mode==Hangul.Mode.JungSung) {
				editText.addChar(keyboard.key/*, false*/);
			}
			else {
				try {	
					editText.replaceChar(keyboard.key);
				}catch(Exception e1) {
					//Log.e("replaceChar", rep.toString());
					e1.printStackTrace();
					CompilerHelper.printStackTrace(editText.textViewLogBird, e1);
				}
			}
			
		} // keyboard.mode==Mode.Hangul
		//Hangul.isNextToCursor = false;
	}
	
	
	
	public static void toolbar_Listener(EditText editText, Object sender, String buttonName) {
		if (buttonName.equals("S")) {	// 툴바버튼
			Edit.createMenuFontSize(true);
			Edit.menuFontSize.open(editText, true);
			//menuFontSize.setOnTouchListener(editText);
			return;
		}
		else if (buttonName.equals("M")) {
			ScrollMode scrollMode=editText.scrollMode; 
			if (scrollMode==ScrollMode.VScroll) {
				scrollMode = ScrollMode.Both;
			}
			else {
				scrollMode = ScrollMode.VScroll;
			}
			editText.setScrollMode(scrollMode);
			return;
		}
		else if (buttonName.equals("FN")) {
			Edit.createMenuFunction(true);
			Edit.menuFunction.open(editText, true);
			//menuFunction.setOnTouchListener(editText);
		}
		else if (buttonName.equals("O")) {
			/*if (compiler==null && Control.textViewLogBird!=null) {
				//Control.textViewLogBird.setHides(false);
				Control.textViewLogBird.open(true);
			}
			else if (compiler!=null && compiler.menuClassList!=null) {
				compiler.menuClassList.open(true);
				compiler.menuClassList.setOnTouchListener(editText);
				//Compiler.menuProblemList_EditText.setOnTouchListener(editText);
				compiler.menuProblemList_EditText.setOnTouchListener(editText);
			}
			else if (compiler!=null && compiler.menuClassList==null) {
				Control.textViewLogBird.open(true);
			}*/
		}
		else if (buttonName.equals("U")) {
			/*if (lang!=null) {
				if (isModified) {
					//String input = getText();
					boolean hasLogMessage = false;
					//if (Control.loggingForMessageBox.getHides()) {
						Control.loggingForMessageBox.setText(true, "loading...", false);
						Control.loggingForMessageBox.setHides(false);
						hasLogMessage = true;
					//}
					ThreadSetIsProgramCode thread = new ThreadSetIsProgramCode(hasLogMessage, true);
					thread.start();
				}
				else {
					//if (preProcessor!=null) {
						compiler.menuClassList.open(true);
						compiler.menuClassList.setOnTouchListener(editText);
					//}
				}
			}*/
		}
		else if (buttonName.equals("R/W")) {
			if (editText.toolbar.buttons[4].getIsSelected()) {
				editText.isReadOnly = true;
			}
			else {
				editText.isReadOnly = false;
			}
		}
	}
	
	
	/** functionMenu_listener(), 키보드 가속기(EditText의 OnTouchEvent())에서 호출*/
	public static void selectAll(EditText editText) {
		if (editText.selectP1==null) {
			editText.selectP1 = new Point();			
		}
		editText.selectP1.x = 0;
		editText.selectP1.y = 0;
		
		if (editText.selectP2==null) {
			editText.selectP2 = new Point();			
		}
		if (editText.textArray[editText.numOfLines-1].length()>0)
			editText.selectP2.x = editText.textArray[editText.numOfLines-1].length()-1;
		else
			editText.selectP2.x = 0;
		editText.selectP2.y = editText.numOfLines-1;
		
		makeSelectIndices(editText, true, editText.selectP1, editText.selectP2);
		
		editText.isSelecting = true;
	}
	
	
	/** EditText의 이벤트 리스너, 이후에 draw가 호출된다*/
	public static  void editText_Listener(EditText editText, Object sender, MotionEvent e) {
		// scrollMode가 VScroll인지 Both인지는 상관이 없다. 
		// getCursorPos에서 처리하기 때문이다.
		try{
			editText.paint.setTextSize(editText.fontSize);
		
		if (e.actionCode==MotionEvent.ActionDown) {			
						
			editText.isFound = false;
			editText.getCursorPos(e);
			editText.isSelecting = false;
			editText.selectLenY = 0;
			editText.selectP1 = new Point(editText.cursorPos.x, editText.cursorPos.y);
			editText.selectIndicesCount = 0;
			
			FunctionOfEditText.oldMotionPos.x = e.x;
			FunctionOfEditText.oldMotionPos.y = e.y;
			FunctionOfEditText.ActionDownClicked = true;
			
			return;
		}
		}catch(Exception e1) {
			e1.printStackTrace();
			CompilerHelper.printStackTrace(editText.textViewLogBird, e1);
		}
		
		if (e.actionCode==MotionEvent.ActionUp) {
			FunctionOfEditText.ActionDownClicked = false;
		}
		
		int scrollBounds = (int)(Control.view.getOriginalHeight() * 0.03f);
		
		try {
		// 0 line   : start, end -> (startX, 0), (endX, 선택영역의 첫번째(0))
		// 1-Y line : start, end -> (startX, 1-Y), (endX, 선택영역의 중간(1))
		// Y line   : start, end -> (startX, Y), (endX, 선택영역의 마지막(2))
		if (FunctionOfEditText.ActionDownClicked && e.actionCode==MotionEvent.ActionMove) {
			FunctionOfEditText.curMotionPos.x = e.x;
			FunctionOfEditText.curMotionPos.y = e.y;
			if (Control.equals(oldMotionPos, curMotionPos)) return;
			
			editText.isSelecting = true;
			
			editText.getCursorPos(e);
			
			if (editText.isSelecting) { // 자동 스크롤 한다.				
				// scrollMode에 상관없이 자동 스크롤 한다.
				if (e.y>editText.bounds.bottom()-scrollBounds) {
					if (editText.numOfLines > editText.numOfLinesPerPage) {
						editText.vScrollPos++;
						editText.setVScrollBar();
						Point r = editText.cursorPos;
						editText.selectP2 = new Point(r.x,r.y);					
						makeSelectIndices(editText, true, editText.selectP1, editText.selectP2);
						return;
					}							
				}
				else if (e.y<editText.bounds.y){
					if (editText.numOfLines > editText.numOfLinesPerPage) {
						editText.vScrollPos--;
						editText.setVScrollBar();
						Point r = editText.cursorPos;
						editText.selectP2 = new Point(r.x,r.y);					
						makeSelectIndices(editText, true, editText.selectP1, editText.selectP2);
						return;
					}
				}
				
				if (editText.scrollMode==ScrollMode.Both) {
					if (e.x > editText.bounds.right()-scrollBounds) {
						float widthOfCurLine = editText.paint.measureText(editText.textArray[editText.cursorPos.y].toString());
						if (widthOfCurLine > editText.widthOfCharsPerPage) {
							editText.widthOfhScrollPos += editText.widthOfhScrollInc;
							editText.setHScrollBar();
							Point r = editText.cursorPos;
							editText.selectP2 = new Point(r.x,r.y);					
							makeSelectIndices(editText, true, editText.selectP1, editText.selectP2);
							return;
						}							
					}
					else if (e.x < editText.bounds.x){
						float widthOfCurLine = editText.paint.measureText(editText.textArray[editText.cursorPos.y].toString());
						if (widthOfCurLine > editText.widthOfCharsPerPage) {
							editText.widthOfhScrollPos -= editText.widthOfhScrollInc;
							editText.setHScrollBar();
							Point r = editText.cursorPos;
							editText.selectP2 = new Point(r.x,r.y);					
							makeSelectIndices(editText, true, editText.selectP1, editText.selectP2);
							return;
						}
					}
				}
			}	// if (isSelecting==true)
			Point r = editText.cursorPos;
						
			if (editText.selectP2==null) {
				editText.selectP2 = new Point(r.x,r.y);
			}
			else {
				editText.selectP2.x = r.x;
				editText.selectP2.y = r.y;
			}
			
			// 적어도 한 문자를 선택해야 선택표시를 그린다.
			makeSelectIndices(editText, true, editText.selectP1, editText.selectP2);
			
			
		} // if (e.actionCode==MotionEvent.ActionMove)
		
		
		}catch(Exception e1) {
			//Log.e("EditText-OnTouchEvent ActionMove", e1.toString());
			e1.printStackTrace();
			CompilerHelper.printStackTrace(editText.textViewLogBird, e1);
			return;
		}
		finally {
			// 터치시 한글모드와 버퍼를 초기화	
			Hangul.mode = Hangul.Mode.None;
			Hangul.resetBuffer();
		}
	}
	
	
	
	/**selectP1,selectP2는 논리적 좌표*/ 
	public static void makeSelectIndices(EditText editText, boolean isSelectingOrFinding, Point selectP1, Point selectP2) {
		if (selectP1==null) return;
		if (selectP2==null) return;
		
		try{
		if (isSelectingOrFinding) {
			
			int selectIndicesCount;
			int selectLenY;
			int selectIndicesCountForCopy;
			CodeString[] textArray = editText.textArray;
			Point[] selectIndices = editText.selectIndices;
			
			int i;
			selectIndicesCount = 0;
			if (selectP1==null || selectP2==null) return;
			if (selectP1.y<=selectP2.y) {
				selectLenY = selectP2.y - selectP1.y + 1;
				
				// 경계처리
				if (textArray[selectP2.y].length()<=selectP2.x) {
					if (textArray[selectP2.y].length()>0)
						selectP2.x = textArray[selectP2.y].length()-1;
					else
						selectP2.x = 0;
				}
				if (textArray[selectP1.y].length()<=selectP1.x) {
					if (textArray[selectP1.y].length()>0)
						selectP1.x = textArray[selectP1.y].length()-1;
					else 
						selectP1.x = 0;
				}
				
				if (selectLenY==1) {
					if (selectP1.x<=selectP2.x) {								
						selectIndices[selectIndicesCount++] = new Point(selectP1.x, selectP1.y);
						selectIndices[selectIndicesCount++] = new Point(selectP2.x, EditText.Select_FirstLine);
					}
					else {
						selectIndices[selectIndicesCount++] = new Point(selectP2.x, selectP2.y);
						selectIndices[selectIndicesCount++] = new Point(selectP1.x, EditText.Select_FirstLine);
					}
				}
				else {
					// 첫번째 라인
					selectIndices[selectIndicesCount++] = new Point(selectP1.x,selectP1.y);
					selectIndices[selectIndicesCount++] = new Point(textArray[selectP1.y].length()-1, 
							EditText.Select_FirstLine);
					for (i=selectP1.y+1; i<selectP2.y; i++) {
						if (!(selectIndicesCount<=selectIndices.length-2)) 
							selectIndices = toPointArray( Array.Resize(selectIndices, selectIndices.length+20) );
						selectIndices[selectIndicesCount++] = new Point(0, i);
						selectIndices[selectIndicesCount++] = 
								new Point(textArray[i].length()-1, EditText.Select_MiddleLine);
					}
					// 마지막 라인
					if (!(selectIndicesCount<=selectIndices.length-2)) 
							selectIndices = toPointArray( Array.Resize(selectIndices, selectIndices.length+20) );
					selectIndices[selectIndicesCount++] = new Point(0, selectP2.y);
					selectIndices[selectIndicesCount++] = new Point(selectP2.x, EditText.Select_LastLine);
				}
				selectIndicesCountForCopy = selectIndicesCount;
			}
			else {		// selectP1.y > selectP2.y
				selectLenY = selectP1.y - selectP2.y + 1;
				
				// 경계처리
				if (textArray[selectP2.y].length()<=selectP2.x) {
					if (textArray[selectP2.y].length()>0)
						selectP2.x = textArray[selectP2.y].length()-1;
					else 
						selectP2.x = 0;
				}
				if (textArray[selectP1.y].length()<=selectP1.x) {
					if (textArray[selectP1.y].length()>0)
						selectP1.x = textArray[selectP1.y].length()-1;
					else
						selectP1.x = 0;
				}
				
				// 첫번째 라인
				selectIndices[selectIndicesCount++] = new Point(selectP2.x,selectP2.y);
				selectIndices[selectIndicesCount++] = new Point(textArray[selectP2.y].length()-1, 
						EditText.Select_FirstLine);
				for (i=selectP2.y+1; i<selectP1.y; i++) {
					if (!(selectIndicesCount<=selectIndices.length-2)) 
						selectIndices = toPointArray( Array.Resize(selectIndices, selectIndices.length+20) );
					selectIndices[selectIndicesCount++] = new Point(0, i);
					selectIndices[selectIndicesCount++] = new Point(textArray[i].length()-1, EditText.Select_MiddleLine);
				}
				// 마지막 라인
				if (!(selectIndicesCount<=selectIndices.length-2)) 
					selectIndices = toPointArray( Array.Resize(selectIndices, selectIndices.length+20) );
				selectIndices[selectIndicesCount++] = new Point(0, selectP1.y);
				selectIndices[selectIndicesCount++] = new Point(selectP1.x, EditText.Select_LastLine);
				
				selectIndicesCountForCopy = selectIndicesCount;
			}
			
			editText.selectIndicesCount = selectIndicesCount;
			editText.selectLenY = selectLenY;
			editText.selectIndicesCountForCopy = selectIndicesCountForCopy;
			editText.textArray = textArray; 
			editText.selectIndices = selectIndices;
			
			editText.selectP1 = selectP1;
			editText.selectP2 = selectP2;
			
			//cursorPos.x = editText.selectP1.x;
			//cursorPos.y = editText.selectP1.y;
		}
		else {	// if (isSelecting)
			
			int findIndicesCount;
			int findLenY;
			int findIndicesCountForCopy = editText.findIndicesCountForCopy;
			Point findP1 = editText.findP1;
			Point findP2 = editText.findP2;
			CodeString[] textArray = editText.textArray;
			Point[] findIndices = editText.findIndices;
			
			int i;
			findIndicesCount = 0;
			if (findP1==null || findP2==null) return;
			if (findP1.y<=findP2.y) {
				findLenY = findP2.y - findP1.y + 1;
				
				// 경계처리
				if (textArray[findP2.y].length()<=findP2.x) {
					if (textArray[findP2.y].length()>0)
						findP2.x = textArray[findP2.y].length()-1;
					else
						findP2.x = 0;
				}
				if (textArray[findP1.y].length()<=findP1.x) {
					if (textArray[findP1.y].length()>0)
						findP1.x = textArray[findP1.y].length()-1;
					else
						findP1.x = 0;
				}
				
				if (findLenY==1) {
					if (findP1.x<=findP2.x) {								
						findIndices[findIndicesCount++] = new Point(findP1.x, findP1.y);
						findIndices[findIndicesCount++] = new Point(findP2.x, EditText.Select_FirstLine);
					}
					else {
						findIndices[findIndicesCount++] = new Point(findP2.x, findP2.y);
						findIndices[findIndicesCount++] = new Point(findP1.x, EditText.Select_FirstLine);
					}
				}
				else {
					// 첫번째 라인
					findIndices[findIndicesCount++] = new Point(findP1.x,findP1.y);
					findIndices[findIndicesCount++] = new Point(textArray[findP1.y].length()-1, 
							EditText.Select_FirstLine);
					for (i=findP1.y+1; i<findP2.y; i++) {
						if (!(findIndicesCount<=findIndices.length-2)) 
							findIndices = toPointArray( Array.Resize(findIndices, findIndices.length+20) );
						findIndices[findIndicesCount++] = new Point(0, i);
						findIndices[findIndicesCount++] = 
								new Point(textArray[i].length()-1, EditText.Select_MiddleLine);
					}
					// 마지막 라인
					if (!(findIndicesCount<=findIndices.length-2)) 
							findIndices = toPointArray( Array.Resize(findIndices, findIndices.length+20) );
					findIndices[findIndicesCount++] = new Point(0, findP2.y);
					findIndices[findIndicesCount++] = new Point(findP2.x, EditText.Select_LastLine);
				}
				findIndicesCountForCopy = findIndicesCount;
			}
			else {		// findP1.y > findP2.y
				findLenY = findP1.y - findP2.y + 1;
				
				// 경계처리
				if (textArray[findP2.y].length()<=findP2.x) {
					if (textArray[findP2.y].length()>0)
						findP2.x = textArray[findP2.y].length()-1;
					else
						findP2.x = 0;
				}
				if (textArray[findP1.y].length()<=findP1.x) {
					if (textArray[findP1.y].length()>0)
						findP1.x = textArray[findP1.y].length()-1;
					else
						findP1.x = 0;
				}
				
				// 첫번째 라인
				findIndices[findIndicesCount++] = new Point(findP2.x,findP2.y);
				findIndices[findIndicesCount++] = new Point(textArray[findP2.y].length()-1, 
						EditText.Select_FirstLine);
				for (i=findP2.y+1; i<findP1.y; i++) {
					if (!(findIndicesCount<=findIndices.length-2)) 
						findIndices = toPointArray( Array.Resize(findIndices, findIndices.length+20) );
					findIndices[findIndicesCount++] = new Point(0, i);
					findIndices[findIndicesCount++] = new Point(textArray[i].length()-1, EditText.Select_MiddleLine);
				}
				// 마지막 라인
				if (!(findIndicesCount<=findIndices.length-2)) 
					findIndices = toPointArray( Array.Resize(findIndices, findIndices.length+20) );
				findIndices[findIndicesCount++] = new Point(0, findP1.y);
				findIndices[findIndicesCount++] = new Point(findP1.x, EditText.Select_LastLine);
				
				findIndicesCountForCopy = findIndicesCount;
			}
			
			editText.findIndicesCount = findIndicesCount;
			editText.findLenY = findLenY;
			editText.findIndicesCountForCopy = findIndicesCountForCopy;
			editText.findP1 = findP1;
			editText.findP2 = findP2;
			editText.textArray = textArray;
			editText.findIndices = findIndices;
		}
		}catch(Exception e) {
			//Log.e("makeSelectIndices",e.toString());
			if (Common_Settings.g_printsLog) e.printStackTrace();
			if (Common_Settings.g_printsLog) CompilerHelper.printStackTrace(editText.textViewLogBird, e);
		}
	}
	
	
	/** hasToolbarAndMenuFontSize이 true인 editText(즉 singleLine editText는 불가능하다)만 
	 * 호출이 가능하다.*/
	public static void functionMenu_Listener(EditText editText, Object sender, String strMenuName) {
		Edit.menuFunction.open(false);
		
		/*static final String[] Menu_Function = { 
			"Undo(Ctrl+z)", "Redo(Ctrl+y)", 
			"Copy(Ctrl+c)", "Cut(Ctrl+x)", "Paste(Ctrl+v)", 
			"Find/Replace(Ctrl+f)", 
			"Select all(Ctrl+a)",
			"Show UndoBuffer", "Show RedoBuffer"
		};*/
		
		if (strMenuName.equals("Copy(Ctrl+c)")) {
			copy(editText);
		}
		else if (strMenuName.equals("Cut(Ctrl+x)")) {
			cut(editText);
		}
		else if (strMenuName.equals("Paste(Ctrl+v)")) {
			paste(editText);
		}
		else if (strMenuName.equals("Select all(Ctrl+a)")) {
			selectAll(editText);
		}
		else if (strMenuName.equals("Find/Replace(Ctrl+f)")) {
			openFindReplaceDialog(editText);
		}
		else if (strMenuName.equals("Undo(Ctrl+z)")) {
			UndoOfEditText.undo(editText);
		}
		else if (strMenuName.equals("Redo(Ctrl+y)")) {
			RedoOfEditText.redo(editText);
		}
		else if (strMenuName.equals("Show UndoBuffer")) {
			editText.undoBuffer.showUndoBuffer(editText);
		}
		else if (strMenuName.equals("Show RedoBuffer")) {
			editText.redoBuffer.showRedoBuffer(editText);
		}
	}
	
	public static void fontSizeMenu_Listener(EditText editText, Object sender, String strFontSize) {
		Edit.menuFontSize.open(false);
		if (strFontSize.equals(Edit.Menu_FontSize[Edit.Menu_FontSize.length-1])) {
			// 모든 EditText들이 findReplaceDialog을 공유하므로 changeBounds를 해준다.			
			//Rectangle newBounds = new Rectangle(totalBounds.x, totalBounds.y, totalBounds.width, totalBounds.height/2);
			//Edit.fontSizeDialog.changeBounds(newBounds);
			Edit.createFontSizeDialog(true);
			Edit.fontSizeDialog.open(editText);
			//fontSizeDialog.setOnTouchListener(editText);
			return;
		}
		int indexOfPercent = strFontSize.indexOf("%");
		if (indexOfPercent!=-1) {
			strFontSize = strFontSize.substring(0, indexOfPercent);
		}
		editText.curFontSize = Float.parseFloat(strFontSize) * Control.view.getOriginalHeight() * 0.01f;
		editText.fontSize = editText.curFontSize;
		changeFontSize(editText, editText.curFontSize);
		
	}
	
	
	/** undo, redo buffer*/
	public static void createTextView(EditText editText, boolean changeBounds) {
		int viewWidth = Control.view.getOriginalWidth(); 
		int viewHeight = Control.view.getOriginalHeight();
		int x, y, w, h;
		
		w = (int) (viewWidth * 0.85f);
		h = (int) (viewHeight * 0.75f);
		x = viewWidth/2 - w/2;
		y = viewHeight/2 - h/2;
		Rectangle boundsOfTextView = new Rectangle(x,y,w,h);
		if (!changeBounds) {
			editText.textView = new TextView(false, false, editText, "undo-redo buffer", boundsOfTextView, 
					Control.view.getOriginalHeight()*0.02f, false, null, ScrollMode.VScroll, Common_Settings.backColor);
			editText.textView.isReadOnly = true;
		}
		else {
			if (editText.textView!=null) {
				editText.textView.changeBounds(boundsOfTextView);
			}
		}
	}
		
	
	public static void openFindReplaceDialog(EditText editText) {
		// 모든 EditText들이 findReplaceDialog을 공유하므로 changeBounds를 해준다.			
		Edit.createFindReplaceDialog(true);
		if (editText.isSelecting) {
			Edit.findReplaceDialog.setScope(false);
		}
		else {
			Edit.findReplaceDialog.setScope(true);
		}
		Edit.findReplaceDialog.open(editText, true);
	}
	
	public static Size getToolbarSize(Rectangle bounds) {
		int buttonHeight = (int) (bounds.height * 0.08f);
		int buttonWidth = (int) (bounds.width * 0.08f);
		
		return new Size(buttonWidth, EditText.namesOfButtonsOfToolbar.length * buttonHeight);
	}
	
	
	public static void createToolbar(EditText editText, Rectangle bounds) {
		editText.toolbar = new MenuWithAlwaysOpen("menu", bounds, MenuType.Vertical, editText.owner, 
				EditText.namesOfButtonsOfToolbar, new Size(2,2), false, editText, editText.isDockingOfToolbarFlexiable);
		editText.toolbar.buttons[1].selectable = false;	// Mode키는 토글로 동작한다.
		editText.toolbar.buttons[1].toggleable = true;
		editText.toolbar.buttons[1].ColorSelected = Color.YELLOW;
		
		editText.toolbar.buttons[4].selectable = false;	// R/W는 토글로 동작한다.
		editText.toolbar.buttons[4].toggleable = true;
		editText.toolbar.buttons[4].ColorSelected = Color.YELLOW;
		editText.toolbar.open(true, false);
	}
	
	static Point[] toPointArray(Object[] arrObj) {
		int i;
		Point[] r = new Point[arrObj.length];
		for (i=0; i<r.length; i++) {
			r[i] = (Point) arrObj[i];
		}
		return r;
	}
	
	
	/** 스크롤 윈도우와 선택영역의 교집합을 구한다.
	 * selectIndices 좌표 구성은 makeSelectIndices()를 참조한다.*/
	static Point[] getIntersectWithSelect(EditText editText, boolean isSelectingOrFinding) {
		try{
		if (isSelectingOrFinding) {
			if (editText.selectLenY==2) {
			}
			Point[] r = new Point[100];
			int count=0;
			if (editText.scrollMode==ScrollMode.VScroll) {			
				int i;
				for (i=0; i<editText.selectIndicesCount; i+=2) {
					if (editText.vScrollPos <= editText.selectIndices[i].y && 
							editText.selectIndices[i].y < editText.vScrollPos+editText.numOfLinesPerPage) {
						if (!(count<=r.length-2)) r = FunctionOfEditText.toPointArray( Array.Resize(r, r.length+20) );
						r[count++] = editText.selectIndices[i];
						r[count++] = editText.selectIndices[i+1];
					}				
				}
				r = FunctionOfEditText.toPointArray( Array.Resize(r, count) );
				return r;
			}
			else {
				int i;
				for (i=0; i<editText.selectIndicesCount; i+=2) {
					if (editText.vScrollPos <= editText.selectIndices[i].y && 
							editText.selectIndices[i].y < editText.vScrollPos+editText.numOfLinesPerPage) {
						if (!(count<=r.length-2)) {
							r = FunctionOfEditText.toPointArray( Array.Resize(r, r.length+20) );
						}
						r[count++] = editText.selectIndices[i];
						r[count++] = editText.selectIndices[i+1];
					}				
				}
				Point[] newR = new Point[100];
				int newCount=0;
				for (i=0; i<count; i+=2) {
					//TextLine text = textArray[r[i].y].subTextLine(
					//		r[i].x, r[i+1].x+1); 
					PartOfStr str =	editText.getStringHScroll(editText.textArray[r[i].y]);
					if (str==null) break;
					if (str.str.length()==0) {
						// 선택영역의 첫번째와 중간라인들은 수평스크롤 영역을 벗어나더라도
						// 선택영역이 그려질 수 있도록 한다.
						if ((editText.selectLenY>1 && r[i+1].y==EditText.Select_FirstLine) ||
							(editText.selectLenY>1 && r[i+1].y==EditText.Select_MiddleLine)) {
							if (!(newCount<=newR.length-2)) {
								newR = FunctionOfEditText.toPointArray( Array.Resize(newR, newR.length+20) );
							}
							newR[newCount++] = new Point(r[i].x,r[i].y);
							newR[newCount++] = new Point(r[i+1].x,r[i+1].y);
						}					
					}
					else {
						// 선택영역과 수평스크롤 영역의 교집합을 구한다.
						Point originP = new Point(r[i].x,r[i+1].x);
						Point newP = new Point(str.start, str.end);					
						Point intersectPoint = getIntersect(originP, newP);
						if (intersectPoint!=null) {
							if (!(newCount<=newR.length-2)) {
								newR = FunctionOfEditText.toPointArray( Array.Resize(newR, newR.length+20) );
							}
							newR[newCount++] = new Point(intersectPoint.x,r[i].y);
							newR[newCount++] = new Point(intersectPoint.y,r[i+1].y);
						}
					}
				}
				newR = FunctionOfEditText.toPointArray( Array.Resize(newR, newCount) );
				return newR;
			}
		}
		else { //if (isSelectingOrFinding) {
			Point[] r = new Point[100];
			int count=0;
			if (editText.scrollMode==ScrollMode.VScroll) {			
				int i;
				for (i=0; i<editText.findIndicesCount; i+=2) {
					if (editText.vScrollPos<=editText.findIndices[i].y && 
							editText.findIndices[i].y<editText.vScrollPos+editText.numOfLinesPerPage) {
						if (!(count<=r.length-2)) r = FunctionOfEditText.toPointArray( Array.Resize(r, r.length+20) );
						r[count++] = editText.findIndices[i];
						r[count++] = editText.findIndices[i+1];
					}				
				}
				r = toPointArray( Array.Resize(r, count) );
				return r;
			}
			else {
				int i;
				for (i=0; i<editText.findIndicesCount; i+=2) {
					if (editText.vScrollPos <= editText.findIndices[i].y && 
							editText.findIndices[i].y < editText.vScrollPos+editText.numOfLinesPerPage) {
						if (!(count<=r.length-2)) {
							r = toPointArray( Array.Resize(r, r.length+20) );
						}
						r[count++] = editText.findIndices[i];
						r[count++] = editText.findIndices[i+1];
					}				
				}
				Point[] newR = new Point[100];
				int newCount=0;
				for (i=0; i<count; i+=2) {
					//TextLine text = textArray[r[i].y].subTextLine(
					//		r[i].x, r[i+1].x+1); 
					PartOfStr str =	editText.getStringHScroll(editText.textArray[r[i].y]);
					if (str==null) continue;
					if (str.str.length()==0) {
						// 선택영역의 첫번째와 중간라인들은 수평스크롤 영역을 벗어나더라도
						// 선택영역이 그려질 수 있도록 한다.
						if ((editText.findLenY>1 && r[i+1].y==EditText.Select_FirstLine) ||
							(editText.findLenY>1 && r[i+1].y==EditText.Select_MiddleLine)) {
							if (!(newCount<=newR.length-2)) {
								newR = toPointArray( Array.Resize(newR, newR.length+20) );
							}
							newR[newCount++] = new Point(r[i].x,r[i].y);
							newR[newCount++] = new Point(r[i+1].x,r[i+1].y);
						}					
					}
					else {
						// 선택영역과 수평스크롤 영역의 교집합을 구한다.
						Point originP = new Point(r[i].x,r[i+1].x);
						Point newP = new Point(str.start, str.end);					
						Point intersectPoint = getIntersect(originP,newP);
						if (intersectPoint!=null) {
							if (!(newCount<=newR.length-2)) {
								newR = toPointArray( Array.Resize(newR, newR.length+20) );
							}
							newR[newCount++] = new Point(intersectPoint.x,r[i].y);
							newR[newCount++] = new Point(intersectPoint.y,r[i+1].y);
						}
					}
				}
				newR = toPointArray( Array.Resize(newR, newCount) );
				return newR;
			}
		}
		}catch(Exception e) {
			//Log.e("getIntersectWithSelect", e.toString());
			if (Common_Settings.g_printsLog) e.printStackTrace();
			if (Common_Settings.g_printsLog) CompilerHelper.printStackTrace(editText.textViewLogBird, e);
			return null;
		}
	}
	
	
	
	/** 교집합 구하기. 
	 * originP:현재줄에서 선택영역의 시작과 끝 x, newP:현재줄에서 수평스크롤 영역의 시작과 끝 x*/
	static Point getIntersect(Point originP, Point newP) {
		if (newP.y<originP.x) // ---  ____	 ---:newP, ___:originP
			return null;
		else if (newP.x<originP.x && newP.y<originP.y) // --__--___ 
			return new Point(originP.x,newP.y); 
		else if (newP.x>=originP.x && newP.y<=originP.y) // _-_-_
			return new Point(newP.x,newP.y);
		else if (newP.x>=originP.x && newP.y>originP.y)  // __--__--__--
			return new Point(newP.x,originP.y);
		else if (newP.x>originP.y)	// _____   -----
			return null;
		
		if (originP.y<newP.x) // ---  ____		---:originP, ___:newP
			return null;
		else if (originP.x<newP.x && originP.y<newP.y) // --__--___ 
			return new Point(newP.x,originP.y); 
		else if (originP.x>=newP.x && originP.y<=newP.y) // _-_-_
			return new Point(originP.x,originP.y);
		else if (originP.x>=newP.x && originP.y>newP.y)  // __--__--__--
			return new Point(originP.x,newP.y);
		else if (originP.x>newP.y)	// _____   -----
			return null;
		
		return null;
		
	}
	

}
