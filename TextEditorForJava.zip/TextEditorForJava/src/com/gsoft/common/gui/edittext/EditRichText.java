package com.gsoft.common.gui.edittext;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.Typeface;
import android.util.Log;

import com.gsoft.common.ColorEx;
import com.gsoft.common.CommonGUI;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.ContentManager;
import com.gsoft.common.Events.MotionEvent;
import com.gsoft.common.Font;
import com.gsoft.common.Font.FontSortVert;
import com.gsoft.common.IO_types.TextFormat;
import com.gsoft.common.PaintEx;
import com.gsoft.common.Sizing.Rectangle;
import com.gsoft.common.Sizing.RectangleF;
import com.gsoft.common.Sizing.SizeF;
import com.gsoft.common.interfaces.OnTouchListener;
import com.gsoft.common.R.R;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.gui.Buttons.Button;
import com.gsoft.common.gui.ColorDialog;
import com.gsoft.common.gui.Control;
import com.gsoft.common.gui.Control.Container;
import com.gsoft.common.gui.FileDialog;
import com.gsoft.common.gui.FindReplaceDialog;
import com.gsoft.common.gui.FontSizeDialog;
import com.gsoft.common.gui.IntegrationKeyboard;
import com.gsoft.common.gui.IntegrationKeyboard.Hangul;
import com.gsoft.common.gui.IntegrationKeyboard.Mode;
import com.gsoft.common.gui.MenuWithAlwaysOpen;
import com.gsoft.common.gui.MenuWithClosable;
import com.gsoft.common.gui.ScrollBars;
import com.gsoft.common.gui.ScrollBars.HScrollBar;
import com.gsoft.common.gui.ScrollBars.VScrollBar;
import com.gsoft.common.gui.TextView;
import com.gsoft.common.gui.edittext.Edit.ScrollMode;
import com.gsoft.common.gui.edittext.EditRichText_Types.Character;
import com.gsoft.common.gui.edittext.EditRichText_Types.TextLine;
import com.gsoft.common.util.Array;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListChar;
import com.gsoft.common.util.Util.Math;

import com.gsoft.common.gui.edittext.EditRichText;
import com.gsoft.common.gui.edittext.FindReplaceOfEditRichText;
import com.gsoft.common.gui.edittext.FunctionOfEditRichText;
import com.gsoft.common.gui.edittext.UndoOfEditRichText;
import com.gsoft.common.gui.edittext.UndoBufferOfEditRichText;
import com.gsoft.common.gui.edittext.RedoBufferOfEditRichText;
import com.gsoft.common.gui.edittext.Edit;

public class EditRichText extends Container implements OnTouchListener {
	
	public static String[] namesOfButtonsOfToolbar = {
		"S", "F", "C", "B", "U", "P", "FN", "R/W"
	};
	
	public MenuWithAlwaysOpen toolbar;
	
	
	
	
	
	public boolean isReadOnly;
	
	public boolean isSingleLine = true;
	
	private String text;	
	TextLine textLine;
		
	public TextLine[] textArray;
	
	//float lineHeight;
	
	public float fontSize;
	float initFontSize;
	//float maxFontSize;
	
	float descent;
	float descentRate;
	float leading;
	float leadingRate;
	int gapX;
	
	ScrollMode scrollMode;
	VScrollBar vScrollBar;
	HScrollBar hScrollBar;
	
	public int numOfLines;
	
	int vScrollBarWidth;
		
	int vScrollPos;
	int numOfLinesPerPage;
	//int numOfLinesInPage;
	
	float partOfCharY;  // y축으로 폰트의 잘리는 부분의 크기
	
	int heightOfvScrollInc = 10;
	int heightOfvScrollPos;
	int heightOfLines;
	int heightOfLinesPerPage;
	//int heightOfLinesInPage;
		
	int hScrollBarHeight;
	
	int widthOfhScrollPos;
	float maxLineWidth;
	int lineNumOfMaxWidth;
	int widthOfCharsPerPage  =1;
	//int widthOfCharsInPage;
	int widthOfTotalChars;
	int widthOfhScrollInc = 10;
	
	boolean isCursorSeen;
	int valueOfCursorRelativeToHScroll;
	
	int rationalBoundsWidth;
	int rationalBoundsHeight;
	
	public Point cursorPos;
	int indexOfCursorInText = -1;	// 현재 입력 문자의 Text에서의 인덱스
	int numOfLinesInText;	// setTextVScroll로 수정되는 줄수, 즉 \n을 만날 때까지의 줄수
	
	boolean isBkSpThatMakeNullStr = false;
	
	public boolean isSelecting;
	int selectLenY;
	Point selectP1 = new Point(0,0);
	Point selectP2 = new Point(0,0);
	Point[] selectIndices = new Point[100];
	int selectIndicesCount = 0;
	
	/** selectStartLine,selectEndLine는 paste할 때 ActionDown이 일어날 수도 있고, 
	 * paste후에 다시 선택을 할 수도 있기 때문에 paste한 라인들을 가리키기 위해 사용한다.
	 * editText_listener(ActionDown)에서 선택라인의 정보를 저장하고 backupForUndo에서 사용한다.*/
	int selectStartLine;
	int selectEndLine;
	
	static final int Select_FirstLine = 0;
	static final int Select_MiddleLine = 1;	
	static final int Select_LastLine = 2;
	
	
	
	// 이미 선택된 텍스트를 크기변환 등 변환 후에 다시 선택을 하기 위해 사용한다.
	boolean makingSelectP1P2OutOfEvent;
	int selectP1Index, selectP2Index;
	Point selectP1Logical, selectP2Logical; // 차례로 선택된 텍스트의 앞과 뒤를 가리킨다.
	
	int selectIndicesCountForCopy;
	boolean isCopied;
	TextLine copiedText = new TextLine(30); 
	
	
	FindReplaceOfEditRichText findReplace = new FindReplaceOfEditRichText(this);
	
	int findLenY;
	Point[] findIndices = new Point[100];
	int findIndicesCount = 0;
	int findIndicesCountForCopy;
		
	boolean isFound;
	Point pointFindStart = new Point(0, 0);
	Point pointFindEnd = new Point(0, 0);
	Point findP1 = new Point(0,0);
	Point findP2 = new Point(0,0);
	ArrayList listFindPos = new ArrayList(100);
	
	
	// PaintEx를 Paint대신에 생성하여 measureText에서 \n을 0으로 계산한다.
	PaintEx paint = new PaintEx();
	Paint paintOfBorder = new Paint();
	
	Context context;
	Bitmap bitmapCursor;
	
	OnTouchListener oldTouchListener;
	
	
	
	static final int MaxLineCount = 100;
		
	
	
	static final String[] Menu_Typeface = {
		"Default", "SansSerif", "Serif"
	};
	
	MenuWithClosable menuTypeface;
	
	Typeface typeface = Typeface.DEFAULT;
	//Typeface typeface = Control.typefaceDefault;
	
	
	//Font.Style style = Font.Style.Normal;
	
	/** DEFAULT, SANSSERIF, SERIF, MONOSPACE만 가능, isBold, isItalic은 따로*/
	String typefaceName = Menu_Typeface[0];
	
	boolean isBold;
	boolean isUnderline;					
	boolean isItalic;
	
	int curColor;
	
	public boolean isSizing;
	
	// 툴바와 스크롤바를 제외한 영역에서 일어난 MoveAction Capture
	boolean isMoveActionCaptured_onlyEditText;

	FontSizeDialog fontSizeDialog;
	
	//View view;

	ColorDialog colorDialog = CommonGUI.colorDialog;

	FileDialog fileDialog = CommonGUI.fileDialog;

	String errorMessage;
	
	/** isChangeBounds이 true이면 changeBounds동작중임을 나타낸다.*/
	boolean isChangeBounds;

	public Rectangle totalBounds;
	
	public boolean isModified;
	//public String curFileName = "";
	
	Mode keyboardMode;
	IntegrationKeyboard.Hangul.Mode hangulMode;
	
	
	
	
	
	UndoBufferOfEditRichText undoBuffer = new UndoBufferOfEditRichText();
	RedoBufferOfEditRichText redoBuffer = new RedoBufferOfEditRichText();

	private Rectangle boundsOfSizingBorder = new Rectangle();

	TextView textView;

	private Rectangle maxBounds;

	
	
	
	public void write(OutputStream os, TextFormat format) throws IOException {
		//oos = new ObjectOutputStream(os);
		TextLine text = this.TextArrayToText(0,  0,  0, 0);
		text.write(os, format);
		
	}
	
	public static TextLine Read(InputStream is, TextFormat format) {
		//BufferedInputStream bis = new BufferedInputStream(is, IO.DefaultBufferSize);
		TextLine r=null;
		try {
			r = TextLine.read(is, format);
		}catch(OutOfMemoryError e) {
			throw e;
		}
		//is.close();
		return r;
	}
	
	public TextLine read(InputStream is, TextFormat format) {
		//BufferedInputStream bis = new BufferedInputStream(is, IO.DefaultBufferSize);
		TextLine r=null;
		try {
			r = TextLine.read(is, format);
		}catch(OutOfMemoryError e) {
			throw e;
		}
		//is.close();
		return r;
	}
	
	void setHeightOfLines() {
		int i;
		float h=0;
		for (i=0; i<numOfLines; i++) {
			h += textArray[i].lineHeight;			
		}
		this.heightOfLines = (int) h;
	}
	/**스크롤영역(heightOfvScrollPos, heightOfvScrollPos+heightOfLinesPerPage)의 edge부분에 걸치는
	 * 줄도 포함한다.
	 * @param heightOfvScrollPos
	 * @param heightOfLinesPerPage
	 */
	void setNumOfLinesPerPage(float heightOfvScrollPos, float heightOfLinesPerPage) {
		float h=0;
		int i;
		int start=-1, end=-1;
		for (i=0; i<numOfLines; i++) {
			h += textArray[i].lineHeight;
			if (h>heightOfvScrollPos) {
				start = i;
				break;
			}
		}
		if (start==-1) {	// 빈 텍스트
			numOfLinesPerPage = 0;
			return;
		}
		if (h>heightOfvScrollPos+heightOfLinesPerPage) {	// start라인이 매우 큰 라인일 경우
			numOfLinesPerPage = 1;
			return;
		}
		for (i=start+1; i<numOfLines; i++) {
			h += textArray[i].lineHeight;
			if (h>heightOfvScrollPos+heightOfLinesPerPage) {
				end = i;
				break;
			}
		}
		
		if (end==-1) {	// 텍스트는 있으나 내용이 작을 때
			numOfLinesPerPage = (i-1)-start+1;
		}
		else {
			numOfLinesPerPage = end-start+1;
		}
	}
	
	
		
	public void setBackColor(int backColor) {
		super.setBackColor(backColor);
		curColor = textColor;
		int j, i;
		for (j=0; j<numOfLines; j++) {
			TextLine line = textArray[j];
			for (i=0; i<line.count; i++) {
				Character c = line.characters[i]; 
				if (ColorEx.isSameColor(c.charColor,backColor)) {
					c.setCharColor(textColor);
				}
			}
		}
		//this.drawToImage(mCanvas);
	}
	
	/**hides가 false이고 editText의 현재상태가 최대화가 아니면 
	 * (키보드와 SizingBorder의 영역을 바꿔줌과 함께) 키보드를 자동으로 보여주고
	 * 현재상태가 최대화상태이면 키보드를 숨겨준다.
	 * hides가 true이면 SizingBorder를 숨긴다.*/
	public synchronized void setHides(boolean hides) {		
		super.setHides(hides);
		if (!hides) {	
			//Control.totalBoundsOfEditText = totalBounds;
			if (Common_Settings.settings.EnablesScreenKeyboard) {
				CommonGUI.keyboard.setOnTouchListener(this);
				if (!isMaximized()) {
					//backUpBounds();
					changeBoundsOfKeyboardAndSizingBorder(bounds);
					CommonGUI.keyboard.setHides(false);
					//Control.isMaximized = false;
				}
				else {
					CommonGUI.keyboard.setHides(true);
					//Control.isMaximized = true;
				}
			}
		}
		else {
			if (!Control.sizingBorder.getHides()) 
				Control.sizingBorder.setHides(true);
		}
	}
	
	/** 보이는 상태에서 바운드가 바뀔때는 스택아래 컨트롤들을 복원했다가 
	 * 다시 숨겨지는 컨트롤들을 결정한다.
	 * 보이지 않는 상태에서는 바운드를 바꿀 수 없다.
	 * @param paramBounds : 툴바제외 영역
	 */
	public void changeBoundsSafe(Rectangle paramBounds) {
		changeBounds(paramBounds);
		//setHides(true);
		//setHides(false);
	}
	
	/** view에서 sizingBorder가 바뀔시 호출, 
	 * 이전 바운드와 새로운 바운드간의 차이가 있을 때만 바운드가 바뀐다.
	 * @param boundsOfEditText : 툴바제외 영역*/
	public void resize(Rectangle boundsOfEditText) {
		if (Control.requiresChangingBounds(bounds, boundsOfEditText)) {
			if (!isMaximized()) backUpBounds();
			boolean isSizingBorderHides = Control.sizingBorder.getHides();
			changeBoundsOfKeyboardAndSizingBorder(boundsOfEditText);
			changeBoundsSafe(boundsOfEditText);
			if (!isSizingBorderHides) Control.sizingBorder.setHides(false);
		}
	}
	
	void changeBoundsOfKeyboardAndSizingBorder(Rectangle boundsOfEditText) {
		int viewHeight = Control.view.getHeight();
		int viewWidth = Control.view.getWidth();
		int heightOfGap = (int)(viewHeight * Control.vertScaleOfGap);
		int top = boundsOfEditText.bottom()+heightOfGap;
		Rectangle boundsOfIntegrationKeyboard = new Rectangle(0, top,
				(int)(viewWidth*Control.scaleOfKeyboardX), viewHeight-top);
		if (viewHeight-top<0) {
			boundsOfIntegrationKeyboard.height = (int)(viewHeight*Control.scaleOfKeyboardY);
		}
		if (CommonGUI.keyboard!=null) {
			if (Control.requiresChangingBounds(CommonGUI.keyboard.bounds, boundsOfIntegrationKeyboard)) {
				CommonGUI.keyboard.changeBounds(boundsOfIntegrationKeyboard);
				boundsOfSizingBorder.x = totalBounds.x;
				boundsOfSizingBorder.width = totalBounds.width;
				boundsOfSizingBorder.y = boundsOfEditText.bottom() + 1;
				boundsOfSizingBorder.height = CommonGUI.keyboard.buttons[0].bounds.y - boundsOfSizingBorder.y;
				Control.sizingBorder.bounds = boundsOfSizingBorder;
			}
		}
	}
	
	/** bounds가 바뀔 때 호출, setHides에서 호출*/
	public void backUpBounds() {
		if (prevSize!=null) prevSize.copyFrom(totalBounds);
		else prevSize = new Rectangle(totalBounds);
		//Control.prevSizeOfEditText = prevSize;
		//prevSizeOfKeyboard.copy(keyboard.bounds);
		//if (sizingBorder!=null) prevSizeOfSizingBorder.copy(sizingBorder.bounds);		
	}
	
	/**maxOrPrev이 true이면 키보드를 없애고 크게 만든다. maxOrPrev이 false이면 키보드를 보이고 editText를 작게 만든다.
	 * 그리고 bounds로 maxBounds와 prevBounds를 설정한다.
	 * 이 메서드를 호출하지 않고 setMaximized(true)를 호출하면 
	 * maxBounds와 prevBounds가 설정이 안되어 있기 때문에 NullPointerException이 발생한다.*/
	public void setMaximized(boolean maxOrPrev, Rectangle bounds) {
		if (maxOrPrev) {			
			if (!isMaximized()) backUpBounds();			
		
			this.maxBounds = bounds;
			changeBounds(bounds);
			
			if (CommonGUI.keyboard!=null) CommonGUI.keyboard.setIsOpen(false);
			this.isMaximized = true;
		}
	}
	
	/**윈도우(뷰)의 크기가 바뀔 때마다 maxBounds를 설정해야 한다.*/
	public void setMaxBounds(Rectangle maxBounds) {
		this.maxBounds = maxBounds;
	}
	
	/**maxOrPrev이 true이면 키보드를 없애고 크게 만든다. maxOrPrev이 false이면 키보드를 보이고 editText를 작게 만든다.
	 * 화면을 처음 표시할 때 setMaxBounds()를 호출하지 않고 이 메서드를 호출하면 NullPointerException이 발생하고,
	 * 윈도우(뷰)의 크기가 바뀔때마다 setMaxBounds()를 호출하지 않고 이 메서드를 호출하면 잘못된 결과가 발생할 수 있다.*/
	public void setMaximized(boolean maxOrPrev) {
		if (maxOrPrev) {
			if (maxBounds==null) {
				return;
			}
			if (!isMaximized()) backUpBounds();
			
			changeBounds(maxBounds);
			
			if (CommonGUI.keyboard!=null) CommonGUI.keyboard.setIsOpen(false);
			this.isMaximized = true;
		}
		
	}
	
	
	
	public EditRichText(Object owner, String name, Rectangle paramBounds, 
			float fontSize, 
			boolean isSingleLine, String text, ScrollMode scrollMode) {
		super();
		this.owner = owner;
		this.name = name;
		
		setBackColor(Color.WHITE);
		curColor = textColor;
		
		descentRate = TextLine.physicalDescentRate;
		leadingRate = TextLine.leadingRate;
		
		this.fontSize = fontSize;
		this.descent = fontSize * descentRate;
		this.initFontSize = fontSize;
		//this.lineHeight = this.fontSize + this.descent;
		
		this.isSingleLine = isSingleLine;
		this.text = text;
		
		Rectangle boundsOfToolbar = new Rectangle(paramBounds.x, paramBounds.y, 
				(int)(paramBounds.width*0.1f), paramBounds.height); 
		Rectangle boundsOfEditRichText = new Rectangle(boundsOfToolbar.right(), paramBounds.y, 
				(int)(paramBounds.width*0.9f), paramBounds.height);
		FunctionOfEditRichText.createToolbar(this, boundsOfToolbar);
		this.bounds = boundsOfEditRichText;
		this.totalBounds = new Rectangle();
		this.totalBounds.copyFrom(paramBounds);
		
		this.numOfLines = 1;
		//this.backColor = Color.WHITE;
		
		//this.gapX = maxFontSize;
		this.gapX = 10;
		this.cursorPos = new Point(0,0);
		
		context = Control.view.getContext();
		
		
		if (!isSingleLine) {
			Edit.createMenuFontSize(false);
			
			Edit.createFontSizeDialog(false);
			
			Edit.createMenuFunction(false);
			Edit.createFindReplaceDialog(false);
			
			FunctionOfEditRichText.createMenuTypeface(this, false);
			FunctionOfEditRichText.createTextView(this, false);
		}
		
		
		//createColorDialog(view);
		//createFileDialog();
		
		
		textArray = new TextLine[MaxLineCount];
		int i;
		for (i=0; i<textArray.length; i++) {
			textArray[i] = new TextLine(0,initFontSize);
		}
		
		paint.setTypeface(typeface);
		paint.setColor(Color.BLACK);
		paint.setTextSize(fontSize);
		paint.setStyle(Style.FILL);
		paintOfBorder.setStyle(Style.STROKE);
		paintOfBorder.setColor(ColorEx.darkerOrLighter(backColor, -100));
		
		bitmapCursor = ContentManager.LoadBitmap(context, R.drawable.cursor);
		
		this.scrollMode = scrollMode;
		
		bound(BoundMode.Create, true);
			
		
		
		this.textLine = new TextLine(text, fontSize);
		setText(0, textLine);
		
		
		if (!isMaximized()) backUpBounds();
		
		
	}
	
	/** 스크롤부분과 관련된 여러 속성값들을 설정한다.*/	
	void boundAttributes(BoundMode boundMode) {
		if (scrollMode==ScrollMode.VScroll) {
			if (boundMode==BoundMode.Create) {
				this.vScrollBarWidth = ScrollBars.getScrollBarSize();
			}
			
			rationalBoundsWidth = bounds.width - 2*gapX - vScrollBarWidth;
			rationalBoundsHeight = bounds.height;
			heightOfLinesPerPage = (int) rationalBoundsHeight;
			setNumOfLinesPerPage(heightOfvScrollPos, heightOfLinesPerPage);
		}		
		else if (scrollMode==ScrollMode.Both) {
			if (boundMode==BoundMode.Create) {
				this.vScrollBarWidth = ScrollBars.getScrollBarSize();
				this.hScrollBarHeight = ScrollBars.getScrollBarSize();
			}
			
			if (this.vScrollBarWidth>this.hScrollBarHeight) {
				this.vScrollBarWidth = this.hScrollBarHeight;
			}
			else {
				this.hScrollBarHeight = this.vScrollBarWidth;
			}
			
			rationalBoundsWidth = bounds.width - 2*gapX - vScrollBarWidth;
			rationalBoundsHeight = bounds.height - hScrollBarHeight;
			heightOfLinesPerPage = (int) rationalBoundsHeight;  
			setNumOfLinesPerPage(heightOfvScrollPos, heightOfLinesPerPage);
						
		}
	}
	
	/** EditRichText생성시, changeBounds(), 폰트 size변경시, 스크롤 Mode변경시 호출되므로 주의해야 한다.
	 * ScrollMode가  Both일 때 폰트크기변경, bounds크기 변경을 하면  setText와  cursor를 초기화할 필요가 없다.
	   ScrollMode가 VScroll일 때  bounds크기 변경을 하면  setText(세로로만 크기가 바뀌므로)와  cursor를 초기화할 필요가 없다.*/
	void bound(BoundMode boundMode, boolean initCursor) {
		boundAttributes(boundMode);
		if (initCursor) {
			vScrollPos = 0;
			heightOfvScrollPos = 0;
			widthOfhScrollPos = 0;
			cursorPos.x = 0;
			cursorPos.y = 0;
		}
		if (scrollMode==ScrollMode.VScroll) {
			
			Rectangle boundsOfVScrollBar = new Rectangle(bounds.x+bounds.width-vScrollBarWidth,
					bounds.y, vScrollBarWidth, this.rationalBoundsHeight);
			if (vScrollBar!=null) vScrollBar.changeBounds(boundsOfVScrollBar);
			else {
				vScrollBar = new VScrollBar(this, context, boundsOfVScrollBar);
				vScrollBar.setOnTouchListener(this);
			}
			setVScrollPos();
			setVScrollBar(true);
			setToolbarAndCurState(cursorPos);
		}		
		else if (scrollMode==ScrollMode.Both) {
		
			Rectangle boundsOfVScrollBar = new Rectangle(bounds.x+bounds.width-vScrollBarWidth,
					bounds.y, vScrollBarWidth, this.rationalBoundsHeight);
			if (vScrollBar!=null) vScrollBar.changeBounds(boundsOfVScrollBar);
			else {
				vScrollBar = new VScrollBar(this, context, boundsOfVScrollBar);
				vScrollBar.setOnTouchListener(this);
			}
			setVScrollPos();
			setVScrollBar(true);
			
			Rectangle boundsOfHScrollBar = new Rectangle(bounds.x+gapX, 
					bounds.y+bounds.height-hScrollBarHeight,
					this.rationalBoundsWidth, hScrollBarHeight);
			if (hScrollBar!=null) hScrollBar.changeBounds(boundsOfHScrollBar);
			else {
				hScrollBar = new HScrollBar(this, context, boundsOfHScrollBar);
				hScrollBar.setOnTouchListener(this);
			}
			
			setHScrollPos();
			setHScrollBar(true);
			
			setToolbarAndCurState(cursorPos);
		}
	}
	
	enum BoundMode {
		Create,
		ChangeBounds,
		FontSize,
		ScrollMode, 
		SetText
	}
	
	/**paramBounds:툴바를 포함한 전체 bounds*/
	public void changeBounds(Rectangle paramBounds) {		
		this.totalBounds.copyFrom(paramBounds);
						
		Rectangle boundsOfToolbar;
		boundsOfToolbar = toolbar.bounds;
		boundsOfToolbar.x = paramBounds.x;
		boundsOfToolbar.y = paramBounds.y;
		boundsOfToolbar.height = paramBounds.height;
		toolbar.changeBounds(boundsOfToolbar);
					
		bounds.x = boundsOfToolbar.right();
		bounds.y = boundsOfToolbar.y;
		bounds.width = paramBounds.width - boundsOfToolbar.width;
		bounds.height = paramBounds.height;
		
	
		if (scrollMode==ScrollMode.VScroll) {
			bound(BoundMode.ChangeBounds, false);			
			TextLine text = this.TextArrayToText(0, 0, cursorPos.y, cursorPos.x);
			setText(0, text);
		}
		else {
			bound(BoundMode.ChangeBounds, false);
		}
		
		if (!isSingleLine) {
			FunctionOfEditRichText.createMenuTypeface(this, true);
			FunctionOfEditRichText.createTextView(this, true);
		}
		
		//cursorPos = backupCursorPos;
	}
	
	/** ScrollMode가  Both일 때 폰트크기변경, bounds크기 변경을 하면  setText와  cursor를 초기화할 필요가 없다.*/
	static class SetTextThread extends Thread {
		boolean initCursor;
		EditRichText owner;
		SetTextThread(EditRichText owner, boolean initCursor) {
			this.owner = owner;
			this.initCursor = initCursor;
		}
		public void run() {
			if (initCursor) {
				owner.bound(BoundMode.SetText, true);
			}
			else {
				owner.bound(BoundMode.SetText, false);
			}
			TextLine text = owner.TextArrayToText(0, 0, 0, 0);			
			owner.setText(0, text);
			CommonGUI.loggingForMessageBox.setHides(true);
			Control.view.postInvalidate();
			
		}
	}
	
	public String getText() {
		int j;
		String newText = "";
		for (j=0; j<numOfLines; j++) {
			newText += textArray[j];
		}
		return newText;
	}
	
	/** cursorPosY에서 n번째 newLineChar를 만날 때까지의  numOfLinesInText을 리턴한다.*/
	int getNumOfLinesInText(int cursorPosY, int numOfNewLineChar) {
		try {
		int i, j;
		char c;
		numOfLinesInText = 0;
		int countOfNewLineChar = 0;
		
		for (j=cursorPosY; j<numOfLines; j++) {
			numOfLinesInText++;
			for (i=0; i<textArray[j].count; i++) {
				c = textArray[j].characters[i].charA;
				if (c=='\n') {
					countOfNewLineChar++;
					if (countOfNewLineChar==numOfNewLineChar) {
						return numOfLinesInText;
					}
				}
			}
		}
		return numOfLinesInText;
		}catch(Exception e) {
			e.printStackTrace();
			CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
			return -1;
		}
	}
	
		
	/** cursorPosY에서 n번째 newLineChar를 만날 때까지의  스트링을 리턴한다.*/
	TextLine TextArrayToText(int cursorPosY, int cursorPosX, int numOfNewLineChar) {
		try {
		int i, j;
		TextLine newText = new TextLine(0,0);
		int count = 0;
		char c;
		numOfLinesInText = 0;
		indexOfCursorInText = -1;
		int countOfNewLineChar = 0;
		
		for (j=cursorPosY; j<numOfLines; j++) {
			numOfLinesInText++;
			for (i=0; i<textArray[j].count; i++) {
				if (j==cursorPosY && i==cursorPosX) {
					indexOfCursorInText = count;
				}
				count++;
				c = textArray[j].characters[i].charA;
				if (c=='\n') {
					countOfNewLineChar++;
					newText.add(textArray[j].characters[i]);
					if (countOfNewLineChar==numOfNewLineChar)  {
						return newText;
					}
				}
				else {
					newText.add(textArray[j].characters[i]);
				}
				
			}
		}
		// 커서가 텍스트바깥에 위치할 때
		if (indexOfCursorInText==-1) {
			indexOfCursorInText = count;
		}
		return newText;
		}catch(Exception e) {
			e.printStackTrace();
			CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
			return null;
		}
	}
		
	
	TextLine TextArrayToText(int startY, int startX, int cursorPosY, int cursorPosX) {
		int i, j;
		TextLine newText = new TextLine(0,0);
		int count = 0;
		int textLen;
		indexOfCursorInText = -1;
				
		Point selectP1=null, selectP2=null;
		if (makingSelectP1P2OutOfEvent) {
			selectP1 = new Point(selectIndices[0].x,selectIndices[0].y);
			int lastIndex = selectIndicesCount-2;
			selectP2 = new Point(selectIndices[lastIndex+1].x,selectIndices[lastIndex].y);
		}
		
		for (j=startY; j<numOfLines; j++) {
			textLen = textArray[j].count;
			for (i=0; i<textLen; i++) {				
				newText.add(textArray[j].characters[i]);
				if (j==cursorPosY && i==cursorPosX) {
					indexOfCursorInText = count;
				}
				if (makingSelectP1P2OutOfEvent) {
					if (j==selectP1.y && i==selectP1.x) {
						selectP1Index = count;
					}
					if (j==selectP2.y && i==selectP2.x) {
						selectP2Index = count;
					}
				}
				count++;
			}
		}
		// 커서가 텍스트바깥에 위치할 때
		if (indexOfCursorInText==-1) {
			indexOfCursorInText = count;
		}
		return newText;		
	}
	
	
	
	/** 키 입력시 호출된다.
	 * redoBuffer를 초기화시켜야 redoBuffer에 남아있는 상태에서 키를 입력하고 나서 
	 * 다시 redo 를 하면 발생하는 오류를 해결할 수 있다.*/
	public void addChar(String charA/*, boolean isNextToCursor*/) {
		//isBackSpacePressed = false;
		isModified = true;
		redoBuffer.reset();
		
		if (charA==null || charA.equals("")) return;
		if (!isSingleLine) {
			int i;
			String[] specialKeys = IntegrationKeyboard.SpecialKeys;
			for (i=0; i<specialKeys.length; i++) {
				if (charA.equals(specialKeys[i])) {
					FunctionOfEditRichText.controlChar(this, i, charA);
					return;
				}
			}
			if (charA.equals(IntegrationKeyboard.Delete)) {	// BackSpace
				charA = Edit.DeleteChar;				
			}	// BackSpace
			else if (charA.equals(IntegrationKeyboard.Enter)) {
				charA = Edit.NewLineChar;				
			}
			else if (charA.equals(IntegrationKeyboard.BackSpace)) {
				charA = Edit.BackspaceChar;
			}
			addCharReally(charA/*, isNextToCursor*/);
			
			if (this.scrollMode==ScrollMode.VScroll) {
				setVScrollPos();
				setVScrollBar(true);
			}
			else {
				setVScrollPos();
				setHScrollPos();
				setVScrollBar(true);
				setHScrollBar(true);
			}
			
			//setVScrollBar();
		}
		else {	// singleLine
			if (!charA.equals(Edit.NewLineChar)) {
				text += charA;
			}
		}
	}
	
	
	
	/** text내에서 '\n'의 개수를 리턴한다.*/
	int getNumOfNewLineChar(TextLine text) {
		int i;
		int r = 0;
		for (i=0; i<text.count; i++) {
			if (text.characters[i].charA=='\n') {
				r++;
			}
		}
		return r;
	}
	
	/** initCursorPos에서 text를 더했을때 커서위치를 구한다.*/
	Point getRelativeCursorPos(Point initCursorPos, TextLine text) {
		int i;
		Point r = new Point(initCursorPos.x,initCursorPos.y);
		for (i=0; i<text.count; i++) {
			if (text.characters[i].charA=='\n') {
				r.y++;
				r.x = 0;
			}
			else if (text.characters[i].charA=='\r') {
			}
			else {
				r.x++;
			}
		}
		return r;
	}
	
	
	/** space, delete, enter 키는 Hangul.mode가 None이다.
	 그리고 isNextToCursor는 true로 설정되어 addChar로 커서다음위치에 
	 key가 추가된다. 이 메서드는 일반문자(영어, 숫자, 특수문자등)를 대상으로 한다.
	 TextArrayToTextOneLine, setTextOneLine에 의해 \n을 만날 때까지의 
	 text만 대상으로 하여 성능을 향상한다.*/
	void addCharReally(String charA/*, boolean isNextToCursor*/) {
		isModified = true;
		
		UndoOfEditRichText.backUpForUndo(this, charA, false);
		// redo 를 무효화한다. redoBuffer를 모두 지워야 한다. 
		// redo 를 무효로 만들지 않으면 undo-redo 시스템의 오류가 발생한다.
		redoBuffer.reset();
		
		//if (charA.equals(IntegrationKeyboard.Space)) charA = " ";
		if (textArray[cursorPos.y]==null) {
			textArray[cursorPos.y] = new TextLine(0,initFontSize);
		}
		
		int cursorPosX = -1;
		int len;
		
		if (charA.equals(Edit.DeleteChar) || charA.equals(Edit.BackspaceChar)) {
			if (this.isSelecting) {
				Point p1 = this.selectP1;
				Point p2 = this.selectP2;
				
				if (p1.x==-1 && p2.x==-1) return;
			}
			len = 1;
		}
		else len = charA.length();
	
		cursorPosX = cursorPos.x + len - 1;
		
				
		if (this.isSelecting && 
				(charA.equals(Edit.DeleteChar) || charA.equals(Edit.BackspaceChar))) {
			this.deleteSelectedText();
		}
		else {
		
			try {		 
			//textArray[cursorPos.y].resize(textArray[cursorPos.y].count+charA.length());
			TextLine charATextLine = (new TextLine(charA, fontSize));
			int i;
			for (i=0; i<charATextLine.count; i++) {
				charATextLine.characters[i].typeface = typeface;
				charATextLine.characters[i].typefaceName = typefaceName;
				charATextLine.characters[i].isUnderLine = isUnderline;
				charATextLine.characters[i].isBold = isBold;
				charATextLine.characters[i].isItalic = isItalic;
				charATextLine.characters[i].setCharColor(curColor);
			}
			Character[] src = charATextLine.characters;
			//textArray[cursorPos.y].insert(src, 0, cursorPosX, charA.length());
			textArray[cursorPos.y].insert(src, 0, cursorPosX, charA.length());
			}catch(Exception e) {
				e.printStackTrace();
				CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
			}
			
			if (!charA.equals(Edit.DeleteChar) && !charA.equals(Edit.NewLineChar) &&
					!charA.equals(Edit.BackspaceChar)) {
				TextLine newText=null;
				newText = TextArrayToText(cursorPos.y, cursorPosX, 1);
				setTextMultiLine(cursorPos.y, newText, -1, 1);			
			}
			else {
				if (charA.equals(Edit.BackspaceChar)) {		
					addBackspaceChar();
				}
				else if (charA.equals(Edit.DeleteChar)) {
					addDeleteChar();
				}
				else if (charA.equals(Edit.NewLineChar)) {
					addEnterChar(/*isNextToCursor*/);
				}
				else {
					TextLine newText = TextArrayToText(cursorPos.y, 0, cursorPos.y, cursorPosX);		
					setText(cursorPos.y, newText);
				}
			}
		}
	}
	
	int getNumOfNewLineChar(Point p0, Point p1) {
		if (this.scrollMode==ScrollMode.Both) {
			return p1.y - p0.y;
		}
		else {
			return -1;
		}
		
	}
	
	void deleteSelectedText() {
		if (this.isSelecting) {
			Point p1 = this.selectP1;
			Point p2 = this.selectP2;
			Point temp;
			
			if (p1.x==-1 && p2.x==-1) return; 
			
			if (p1.y>p2.y) {
				temp = p1;
				p1 = p2;
				p2 = temp;				
			}
			else if (p1.y==p2.y) {
				if (p1.x>p2.x) {
					temp = p1;
					p1 = p2;
					p2 = temp;
				}
			}
			
			// p1.y 가 항상 p2.y 보다 작다.
			// p1.y와 p2.y가 같은 경우에 p1.x 가 항상 p2.x 보다 작다.
			
			int curLine = p1.y;
			int numOfLinesToDelete = getNumOfNewLineChar(p1, p2) + 1;
			
			TextLine headText = textArray[curLine];
			headText = headText.subTextLine(0, p1.x);
			int oldHeadTextLen = headText.count;
			
			TextLine tailText = TextArrayToText(p2.y, p2.x, 1);
			if (tailText!=null && tailText.count>0) // null도 아니고 빈스트링도 아니면
				tailText = tailText.subTextLine(p2.x+1, tailText.count);
			
			
			// headText에 tailText를 연결한다.
			headText.resize(headText.count+tailText.count);
			headText.insert(tailText.characters, 0, oldHeadTextLen, tailText.count);
			
			if (numOfLinesToDelete==1 && headText.equals("") && p2.y<this.numOfLines-1) {
				headText = new TextLine("\n", textArray[curLine].characters[0].size);
			}
			else if (textArray[selectP1.y].characters[selectP1.x].charA=='\n' && 
					textArray[selectP2.y].characters[selectP2.x].charA=='\n') {
				headText.insert(headText.count, new TextLine("\n", initFontSize));
			}
			
			setTextMultiLine(curLine, headText, numOfLinesToDelete, 1);
			
			isSelecting = false;
			
			cursorPos.x = p1.x;
			cursorPos.y = p1.y;
		}
	}
	
	void addDeleteChar() {
		isModified = true;
		// cursorPos는  가리키므로 cursorPos.x는 %를 가리킨다.
		if (cursorPos.x+3<textArray[cursorPos.y].count) {
			// 자 뒤의 문자
			TextLine curChar = textArray[cursorPos.y].subTextLine(cursorPos.x+3,cursorPos.x+3+1);
			if (!(curChar.equals("\n"))) {
				TextLine newText = TextArrayToText(cursorPos.y, cursorPos.x, 1);		
				setTextMultiLine(cursorPos.y, newText, -1, 1);
			}
			else {
				int nextLine = cursorPos.y + 1;
				int curLine = cursorPos.y;
				if (nextLine<numOfLines) {
					if (scrollMode==ScrollMode.VScroll) {
						int numOfLinesToDelete;
						TextArrayToText(curLine, 0, 2);
						numOfLinesToDelete = numOfLinesInText + 1;
						
					
						TextLine newCurLine = deleteNewLineChar(textArray[curLine]);
						//  제거한다.
						newCurLine = newCurLine.subTextLine(0, cursorPos.x);
						Character[] charArrayNewCurLine = newCurLine.toCharacterArray();
						int newCursorX = newCurLine.count;
						
						TextLine nextLineText = TextArrayToText(nextLine, 0, 1);
						
						//charArrayNewCurLine = Array.Resize(charArrayNewCurLine, 
						//		charArrayNewCurLine.length+nextLineText.count);
						Character[] charArrayNextLine = nextLineText.toCharacterArray();

						try {
							charArrayNewCurLine = (Character[]) Array.InsertNoSpaceError(charArrayNextLine, 0, 
									charArrayNewCurLine, newCursorX, 
									charArrayNextLine.length, newCurLine.count);
						}catch(Exception e) {
							e.printStackTrace();
							CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
						}
						
						int oldVScrollPos = vScrollPos;
						
												
						newCurLine = new TextLine(charArrayNewCurLine);
						setTextMultiLine(curLine, newCurLine, numOfLinesToDelete, 1);
						
						cursorPos.x = newCursorX;
						cursorPos.y = curLine;
						vScrollPos = oldVScrollPos;
						setVScrollPos();
						setVScrollBar(true);
					}
					else {	
						int numOfLinesToDelete = 2;
						TextLine newCurLine = deleteNewLineChar(textArray[curLine]);
						//  제거한다.
						newCurLine = newCurLine.subTextLine(0, cursorPos.x);
						Character[] charArrayNewCurLine = newCurLine.toCharacterArray();						
						int newCursorX = newCurLine.count;
						
						TextLine nextLineText = textArray[nextLine];
						
						//charArrayNewCurLine = Array.Resize(charArrayNewCurLine, 
						//		charArrayNewCurLine.length+nextLineText.count);
						Character[] charArrayNextLine = nextLineText.toCharacterArray();
						
						try {
							charArrayNewCurLine = (Character[]) Array.InsertNoSpaceError(charArrayNextLine, 0, 
									charArrayNewCurLine, newCursorX, 
									charArrayNextLine.length, newCurLine.count);
						}catch(Exception e) {
							e.printStackTrace();
							CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
						}
						
						int oldHScrollPos = widthOfhScrollPos;
						int oldVScrollPos = vScrollPos;
						
												
						newCurLine = new TextLine(charArrayNewCurLine);
						setTextMultiLine(curLine, newCurLine, numOfLinesToDelete, 1);
						
						cursorPos.x = newCursorX;
						cursorPos.y = curLine;
						widthOfhScrollPos = oldHScrollPos;
						vScrollPos = oldVScrollPos;
						setVScrollPos();
						setHScrollPos();
						setVScrollBar(true);
						setHScrollBar(true);
					}
				} // if (nextLine<numOfLines) {
				else {
					TextLine newText = TextArrayToText(cursorPos.y, cursorPos.x, 1);		
					setTextMultiLine(cursorPos.y, newText, -1, 1);
				}
			} // else

		}
		else {	// if (cursorPos.x+3<textArray[cursorPos.y].length()) {
			// cursorPos는  가리키므로 cursorPos.x는 %를 가리킨다.
			//  제거한다.
			if (scrollMode==ScrollMode.Both) {
				textArray[cursorPos.y] = textArray[cursorPos.y].subTextLine(0, cursorPos.x);
			}
			else { // 다음 줄의 첫문자를 지운다.
				TextLine newText = TextArrayToText(cursorPos.y, cursorPos.x, 1);		
				setTextMultiLine(cursorPos.y, newText, -1, 1);
			}
		}
	}

	/**엔터키를 입력하였으므로 마지막 줄수를 100줄 더 늘린다.
		NullPointerException 이나 getCursorPos()에서 에러를 발생시킬수 있으므로.*/
	void addEnterChar(/*boolean isNextToCursor*/) {
		isModified = true;
		
		int cursorPosX;
		cursorPosX = cursorPos.x;
		
		TextLine strCurLine = TextArrayToText(cursorPos.y, cursorPosX, 2);
		
		int curLine = cursorPos.y;
		
		
		TextLine newText1 = strCurLine;
		int numOfLinesToDelete = this.getNumOfLinesInText(cursorPos.y, 2);
		setTextMultiLine(cursorPos.y, newText1, numOfLinesToDelete, 1);
		
		
		// 엔터키를 입력하였으므로 마지막 줄수를 100줄 더 늘린다.
		// NullPointerException 이나 getCursorPos()에서 에러를 발생시킬수 있으므로.
		textArray = FunctionOfEditRichText.toTextLineArray( Array.Resize(textArray, numOfLines+100) );
				
		//textArray[curLine+1] = strRemainder;

		
		cursorPos.y = curLine + 1;
		cursorPos.x = 0;
		
	}
	
	void addBackspaceChar() {
		isModified = true;
		
		if (this.isSelecting) {
			this.deleteSelectedText();
			return;
		}
		
		if (cursorPos.x!=0) { 
			TextLine newText = TextArrayToText(cursorPos.y, cursorPos.x, 1);		
			setTextMultiLine(cursorPos.y, newText, -1, 1);
			
		}
		else {//if (cursorPos.x==0) { 
			int prevLine = cursorPos.y-1;
			if (prevLine>=0) {
				if (scrollMode==ScrollMode.VScroll) {
					// 지워질 라인수를 먼저 구한다. 
					int numOfLinesToDelete;
					TextArrayToText(cursorPos.y, 0, 1);
					// numOfLinesInText는 현재 라인(마지막 '\n'까지)에서 지워질 라인수이고
					// 플러스 1은 이전 라인에서 지워질 라인을 말한다.
					numOfLinesToDelete = numOfLinesInText + 1;
				
					TextLine newPrevLine;
					if (textArray[prevLine].characters[textArray[prevLine].count-1].charA=='\n') {
						newPrevLine = deleteNewLineChar(textArray[prevLine]);
					}
					else {
						newPrevLine = textArray[prevLine].subTextLine(0,
								textArray[prevLine].count-1);
					}
					Character[] charArrayNewPrevLine = newPrevLine.toCharacterArray();
					TextLine curLineText = TextArrayToText(cursorPos.y, cursorPos.x, 1);
					// \bk를 제거한다.
					curLineText = curLineText.subTextLine(3, curLineText.count);
					
					Character[] charArrayCurLine = curLineText.toCharacterArray();
					int newCursorX = newPrevLine.count;
					try {
						charArrayNewPrevLine = (Character[]) Array.InsertNoSpaceError(charArrayCurLine, 0, 
								charArrayNewPrevLine, newCursorX, 
								charArrayCurLine.length, newPrevLine.count);
					}catch(Exception e) {
						e.printStackTrace();
						CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
					}
										
					// newPrevLine은 새로운 text 가 된다.					
					newPrevLine = new TextLine(charArrayNewPrevLine);
					setTextMultiLine(prevLine, newPrevLine, numOfLinesToDelete, 1);
										
					cursorPos.x = newCursorX;
					cursorPos.y = prevLine;
					
					//setVScrollPos();
					//setVScrollBar(true);
				}//if (scrollMode==ScrollMode.VScroll) {
				else {	// 당연히 이전 줄은 newline으로 끝난다.
					int numOfLinesToDelete = 2;
					TextLine newPrevLine = deleteNewLineChar(textArray[prevLine]);
					Character[] charArrayNewPrevLine = newPrevLine.toCharacterArray();
					TextLine curLineText = textArray[cursorPos.y];
					// \bk를 제거한다.
					curLineText = curLineText.subTextLine(3, curLineText.count);
					//charArrayNewPrevLine = Array.Resize(charArrayNewPrevLine, 
					//		charArrayNewPrevLine.length+curLineText.count);
					Character[] charArrayCurLine = curLineText.toCharacterArray();
					int newCursorX = newPrevLine.count;
					try {
						charArrayNewPrevLine = (Character[]) Array.InsertNoSpaceError(charArrayCurLine, 0, 
								charArrayNewPrevLine, newCursorX, 
								charArrayCurLine.length, newPrevLine.count);
					}catch(Exception e) {
						e.printStackTrace();
						CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
					}
					
					newPrevLine = new TextLine(charArrayNewPrevLine);
					setTextMultiLine(prevLine, newPrevLine, numOfLinesToDelete, 1);
					
					cursorPos.x = newCursorX;
					cursorPos.y = prevLine;
					//setVScrollPos();
					//setHScrollPos();
					//setVScrollBar(true);
					//setHScrollBar(true);
				}//ScrollMode.Both
			} // if (prevLine>=0)
			else {
				TextLine newText = TextArrayToText(cursorPos.y, cursorPos.x, 1);		
				setTextMultiLine(cursorPos.y, newText, -1, 1);
			}//if (prevLine<0)
			
		}//if (cursorPos.x==0) { 
	}

	
	/**한글완성중일 때 이 메서드를 사용한다. 
	 * redoBuffer를 초기화시켜야 redoBuffer에 남아있는 상태에서 키를 입력하고 나서 
	 * 다시 redo 를 하면 발생하는 오류를 해결할 수 있다.*/
	public void replaceChar(String charA) {
		redoBuffer.reset();
		
		//if (charA==null || charA.equals("")) return;
		if (charA.equals(IntegrationKeyboard.Delete)) {	// BackSpace
			charA = Edit.DeleteChar;				
		}	// BackSpace
		else if (charA.equals(IntegrationKeyboard.Enter)) {
			charA = Edit.NewLineChar;
		}
		replaceCharReally(charA);		
	}
	
	/**한글이 완성중일때만 동작한다. TextArrayToTextOneLine, setTextOneLine에 의해 \n을 만날 때까지의 
	 text만 대상으로 하여 성능을 향상한다.*/	
	void replaceCharReally(String charA) {
		UndoOfEditRichText.backUpForUndo(this, charA, true);
		// redo 를 무효화한다. redoBuffer를 모두 지워야 한다. 
		// redo 를 무효로 만들지 않으면 undo-redo 시스템의 오류가 발생한다.
		redoBuffer.reset();
		
		//if (charA.equals(IntegrationKeyboard.Space)) charA = " ";
		
		try {
		textArray[cursorPos.y].delete(cursorPos.x, 1);
		}catch(Exception e) {
		}
		textArray[cursorPos.y].setLineHeight(30);
		
		int charALen = charA.length();
		
		try {
		if (charALen!=0) {		// charA==0이면 insert가 필요없다.
			//textArray[cursorPos.y].resize(textArray[cursorPos.y].count+charA.length());
			TextLine charATextLine = (new TextLine(charA, fontSize));
			int i;
			for (i=0; i<charATextLine.count; i++) {
				charATextLine.characters[i].typeface = typeface;
				charATextLine.characters[i].typefaceName = typefaceName;
				charATextLine.characters[i].isUnderLine = isUnderline;
				charATextLine.characters[i].isBold = isBold;
				charATextLine.characters[i].isItalic = isItalic;
				charATextLine.characters[i].setCharColor(curColor);
			}
			Character[] src = charATextLine.characters;
			textArray[cursorPos.y].insert(src, 0, cursorPos.x, charALen);
		}
		}catch(Exception e) {
			e.printStackTrace();
			CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
		}
		Point oldCursorPos=null;
		if (charALen==0) {	//  도ㄹ에서 ㄹ을 ""으로 만드는 backspace키가 눌릴 때 현재 커서위치를 저장한다.
			isBkSpThatMakeNullStr = true;
			charALen = 1;	// 현재 커서를 가리키도록 한다.
			oldCursorPos = new Point(cursorPos.x, cursorPos.y);
			
		}
		TextLine newText=null;
		newText = TextArrayToText(cursorPos.y, cursorPos.x+charALen-1, 1);
		setTextMultiLine(cursorPos.y, newText, -1, 1);
		
		if (isBkSpThatMakeNullStr) {
			cursorPos.x = oldCursorPos.x;
			cursorPos.y = oldCursorPos.y;
			isBkSpThatMakeNullStr = false;
		}
		
		
	}	
	
	public void initialize() {
		initCursorAndScrollPos();
		this.keyboardMode = IntegrationKeyboard.Mode.Math;
		TextLine text = new TextLine(0,0);
		setText(0,text);
		setToolbarAndCurState(cursorPos);
		setBackColor(backColor);
		this.descent = fontSize * descentRate;
		isSelecting = false;
		undoBuffer.reset();
		redoBuffer.reset();
	}
	
	public void initCursorAndScrollPos() {
		cursorPos.x = 0;
		cursorPos.y = 0;
		if (scrollMode==ScrollMode.VScroll) {
			vScrollPos = 0;
			vScrollBar.setVScrollBar(heightOfLinesPerPage,
					
					heightOfLines, heightOfvScrollPos, heightOfvScrollInc);
		}
		else {
			vScrollPos = 0;
			//hScrollPos = 0;
			widthOfhScrollPos = 0;
			vScrollBar.setVScrollBar(heightOfLinesPerPage,
					
					heightOfLines, heightOfvScrollPos, heightOfvScrollInc);
			hScrollBar.setHScrollBar(widthOfCharsPerPage, 
					widthOfTotalChars, widthOfhScrollPos, widthOfhScrollInc);
		}
		setToolbarAndCurState(cursorPos);
	}
	
		
	
	/** startLine부터 textArray를 만든다.
	// 처음 생성자에서 addChar, replaceChar를 거치지 않고 직접 setText를 호출시 indexInText가
	// -1이므로 커서위치는 바뀌지 않는다. 따라서 scrollPos도 바뀌지 않는다.*/
	public synchronized void setText(int startLine, TextLine text) {
		//if (text==null) return;
		if (text==null || text.equals("")) {
			textArray[0] = new TextLine("", Common_Settings.textColor);
		}
		if (startLine!=0) isModified = true;
		if (scrollMode==ScrollMode.VScroll) {
			setTextVScroll(startLine, text);			
			setVScrollPos();
			setVScrollBar(true);
		}		
		else if (scrollMode==ScrollMode.Both) {
			setTextScrollBoth(startLine, text);
			setVScrollPos();
			setHScrollPos();
			setVScrollBar(true);			
			setHScrollBar(true);
		}
	}
	
		
	/** startLine에서 시작하여 numOfLinesToDelete 개수 만큼 textArray에서 지우고
	 * 그 지워진 부분에 새로운 text 를 넣는다. 
	 * numOfLinesToDelete가 -1 이면 numOfLinesInText를 가지고 지워질 라인수를 산정한다.*/
	public void setTextMultiLine(int startLine, TextLine text, int numOfLinesToDelete, int numOfNewLineChar) {
		isModified = true;
		if (scrollMode==ScrollMode.VScroll) {
			setTextMultiLineVScroll(startLine, text, numOfLinesToDelete);
			setVScrollPos();
			setVScrollBar(true);
		}		
		else if (scrollMode==ScrollMode.Both) {
			try {
			setTextMultiLineBoth(startLine, text, numOfLinesToDelete);
			}catch(Exception e) {
				e.printStackTrace();
				CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
			}
			
			setVScrollPos();
			setHScrollPos();
			setVScrollBar(true);			
			setHScrollBar(true);
			
		}
	}
	
	/** 현재 입력한 문자 다음에 커서가 위치하도록 한다.
	 한글은 문자를 완성중일 때는 전진시키지 않는다. 즉 현재 완성중인 문자에 커서가 위치한다.*/
	public void setCursorPos(int lineNumber, int index, boolean isNewLine, 
			boolean isLineWidthNarrow, Point result) {
		// 문자를 완성중이거나 빈스트링을 만드는 BackSpace키일때는 커서를 전진시키지 않는다.
		if ((CommonGUI.keyboard.mode==Mode.Hangul && Hangul.mode!=Hangul.Mode.None)) {
			if (isNewLine) {
				if (!isLineWidthNarrow) {	// \n
					if (index<indexOfCursorInText) {
						result.y++;
						result.x = 0;
					}
				}
				else {	// 라인이 텍스트 너비보다 좁을 때
					// index==indexInText면 현재 입력 문자가 칸이 모잘라 아래줄에 쓰여지는 상황 
					if (index<=indexOfCursorInText) {
						result.y++;
						result.x = 0;
					}
				}
			}
			else {
				if (index<indexOfCursorInText) {
					result.x++;
				}
			}
		}
		else {
			if (isNewLine) {
				if (index<=indexOfCursorInText) {
					// BkSp는 한글이 아닐 때는 일반 문자로 동작한다.
					//if (!(keyboard.mode==Mode.Hangul && 
					//		Hangul.mode==Hangul.Mode.None && 
					//		Hangul.isBkSpPressed)) {
					//	result.y++;
					//	result.x = 0;
					//}
					result.y++;
					result.x = 0;
				}
			}
			else {
				if (index<=indexOfCursorInText) {
					result.x++;
				}
			}			
		}
	}
	
	public void forwardCursorX() {
		cursorPos.x++;
	}
	
	TextLine[] setTextArrayNoSpaceError(TextLine[] textArray, int lineNumber, TextLine text) {
		if (lineNumber<textArray.length) {
			textArray[lineNumber] = text;
		}
		else {
			textArray = FunctionOfEditRichText.toTextLineArray( Array.Resize(textArray, lineNumber+10) );
			textArray[lineNumber] = text;
		}
		return textArray;
			
	}
	
	boolean isNextCharBkSp(TextLine text, int i) {
		int textLen = text.count;
		TextLine nextCharA;
		nextCharA = text.subTextLine(i+1, i+2);
		if (nextCharA.equals("%")) {
			if (i+3<textLen) {
				TextLine str = text.subTextLine(i+2, i+4);
				if (str.equals("bk")) {
					return true;
				}						
			}
		}
		return false;
	}
	
	boolean isCurCharBkSp(TextLine text, int i) {
		TextLine charA = text.subTextLine(i, i+1);
		if (charA.equals("%")) {
			if (i+2<text.count) {
				TextLine str = text.subTextLine(i+1, i+3);
				if (str.equals("bk")) {
					return true;
				}
			}
		}
		return false;
	}
	
	boolean isCurCharDelete(TextLine text, int i) {
		TextLine charA = text.subTextLine(i, i+1);
		if (charA.equals("%")) {
			if (i+2<text.count) {
				TextLine str = text.subTextLine(i+1, i+3);
				if (str.equals("dl")) {
					return true;
				}
			}
		}
		return false;
	}
	
	// 수직스크롤바만 있는 경우, 즉 수평스크롤바가 없다.
	// cursorPos.y 는 startLine과 같다.
	public void setTextVScroll(int startLine, TextLine text) {
		if (text==null) return;
		numOfLines = startLine + 1;
		
		if (!isSingleLine) {
			Point cursorPosLocal = new Point(0,startLine);
			
			int i;
			float lineWidth = 0;
			
			for (i=startLine; i<textArray.length; i++) {
				textArray[i] = new TextLine(0,initFontSize);
			}
			TextLine textTemp1 = new TextLine(0,0);
			TextLine textTemp2 = new TextLine(0,0);
			
			TextLine charA;
			boolean isDeleteChar = false;
			boolean isNextCharBkSp = false;
			boolean isCurCharBkSp = false;
			int textLen = text.count;			
			int selectIndexX=0, selectIndexY=0;
			for (i=0; i<textLen; i++) {
				if (makingSelectP1P2OutOfEvent) {
					if (i==selectP1Index) {
						selectP1Logical = new Point(selectIndexX,startLine+selectIndexY);
					}
					if (i==selectP2Index) {
						selectP2Logical = new Point(selectIndexX,startLine+selectIndexY);
					}
				}
				charA = text.subTextLine(i, i+1);
				if (i+1<textLen) {
					isNextCharBkSp = isNextCharBkSp(text, i);
				}
				else {
					isNextCharBkSp = false;
				}
				isDeleteChar = isCurCharDelete(text, i);
				isCurCharBkSp = isCurCharBkSp(text, i);
				
				if (isDeleteChar) {
					isDeleteChar = false;
					i+=3; // d 생략
				}
				else {
					if (isNextCharBkSp) {	// 다음 문자가 bksp이면 bksp다음으로 처리를 옮긴다.
						isNextCharBkSp = false;
						i += 3;
						continue;
					}
					if (isCurCharBkSp) {	// 다음 문자가 bksp이면 bksp다음으로 처리를 옮긴다.
						isCurCharBkSp = false;
						i += 2;
						continue;
					}
					if (charA.equals(Edit.NewLineChar)) {
						textTemp1.add(charA.characters[0]);
						textArray = setTextArrayNoSpaceError(textArray, numOfLines-1, textTemp1);
						numOfLines++;
						textArray = setTextArrayNoSpaceError(textArray, numOfLines-1, new TextLine(0,0));
						selectIndexY++;
						selectIndexX = 0;
						setCursorPos(startLine, i, true, false, cursorPosLocal);
						textTemp1 = new TextLine(0,0);
						textTemp2 = new TextLine(0,0);
						lineWidth = 0;
						// newline문자의 다음 줄을 newline문자의 size로 바꾼다.
						textArray[numOfLines-1].setLineHeight(charA.characters[0].size);
						
					}
					else  {
						textTemp1.add(charA.characters[0]);
						//lineWidth = paint.measureText(textTemp1);
						lineWidth += paint.measureText(charA);
						if (lineWidth > rationalBoundsWidth) {
							textArray = setTextArrayNoSpaceError(textArray, numOfLines-1, textTemp2);
							numOfLines++;
							textArray = setTextArrayNoSpaceError(textArray, numOfLines-1, new TextLine(0,0));
							selectIndexY++;
							selectIndexX = 0;
							setCursorPos(startLine, i, true, true, cursorPosLocal);
							textTemp1 = new TextLine(0,0);
							textTemp2 = new TextLine(0,0);
							lineWidth = 0;
							i--;	// 초과된 문자(다음줄의 첫문자)를 다시 처리
						}
						else {
							textTemp2.add(charA.characters[0]);
							//textArray[numOfLines-1].add(charA.characters[0]);
							textArray = setTextArrayNoSpaceError(textArray, numOfLines-1, textTemp2);
							setCursorPos(startLine, i, false, false, cursorPosLocal);
							selectIndexX++;
						}
					}
				}	// isDeleteChar == false;
				
			}		// for			
			
			for (i=startLine; i<numOfLines; i++) {
				if (textArray[i].count!=0) {
					textArray[i].setLineHeight(30);
				}
			}
			this.cursorPos = cursorPosLocal;
			
			//textArray = Array.Resize(textArray, numOfLines+100);
			
		} // if (!isSingleLine)
	}
	
	/** newline문자의 다음 줄을 newline문자의 size로 바꾼다.*/
	public void setTextScrollBoth(int startLine, TextLine text) {
		try{
		if (text==null) return;
		numOfLines = startLine + 1;
		
		if (!isSingleLine) {			
			Point cursorPosLocal = new Point(0,startLine);
			TextLine textTemp1 = new TextLine(0,0);
			int i;
			for (i=startLine; i<textArray.length; i++) {
				textArray[i] = new TextLine(0,initFontSize);
			}
			
			TextLine charA;
			boolean isDeleteChar = false;
			boolean isNextCharBkSp = false;
			boolean isCurCharBkSp = false;
			int textLen = text.count;
			
			for (i=0; i<textLen; i++) {
				charA = text.subTextLine(i, i+1);
				if (i+1<textLen) {
					isNextCharBkSp = isNextCharBkSp(text, i);
				}
				else {
					isNextCharBkSp = false;
				}
				isDeleteChar = isCurCharDelete(text, i);
				isCurCharBkSp = isCurCharBkSp(text, i);
				
				if (isDeleteChar) {
					isDeleteChar = false;
					i+=3; // d 생략
				}
				else {
					if (isNextCharBkSp) {	// 다음 문자가 bksp이면 bksp다음으로 처리를 옮긴다.
						isNextCharBkSp = false;
						i += 3;
						continue;
					}
					if (isCurCharBkSp) {	// 다음 문자가 bksp이면 bksp다음으로 처리를 옮긴다.
						isCurCharBkSp = false;
						i += 2;
						continue;
					}
					if (charA.equals(Edit.NewLineChar)) {						
						textTemp1.add(charA.characters[0]);
						textArray = setTextArrayNoSpaceError(textArray, numOfLines-1, textTemp1);
						numOfLines++;
						textArray = setTextArrayNoSpaceError(textArray, numOfLines-1, new TextLine(0,0));
						setCursorPos(startLine, i, true, false, cursorPosLocal);
						textTemp1 = new TextLine(0,0);
						// newline문자의 다음 줄을 newline문자의 size로 바꾼다.
						textArray[numOfLines-1].setLineHeight(charA.characters[0].size);						
					}				
					else  {
						textTemp1.add(charA.characters[0]);
						textArray = setTextArrayNoSpaceError(textArray, numOfLines-1, textTemp1);
						setCursorPos(startLine, i, false, false, cursorPosLocal);
					}
				}	// isDeleteChar == false;
				
			}		// for
			
			this.cursorPos = cursorPosLocal;
			for (i=startLine; i<numOfLines; i++) {
				if (textArray[i].count!=0) {
					textArray[i].setLineHeight(30);
				}
			}
			//textArray = Array.Resize(textArray, numOfLines+100);
			
		} // if (!isSingleLine)
		}catch(Exception e) {
			
		}
	}
	
	
	/** paste에서 사용*/
	public void setTextMultiLineVScroll(int lineNumber, TextLine text, int numOfLinesToDelete) {
		if (text==null) return;
		int numOfLinesLocal = 1;
		
		if (!isSingleLine) {
			TextLine[] textArrayLocal = new TextLine[20];
			Point cursorPosLocal = new Point(0,lineNumber);
			TextLine textTemp1 = new TextLine(0,0);
			TextLine textTemp2 = new TextLine(0,0);
			int i;
			float lineWidth = 0;
			textArrayLocal[0] = new TextLine(0,initFontSize); // '\n'을 친 후에 새로 생긴 빈 라인을 위한 것이다.
			
			TextLine charA;
			boolean isDeleteChar = false;
			boolean isNextCharBkSp = false;
			boolean isCurCharBkSp = false;
			int textLen = text.count;
			
			for (i=0; i<textLen; i++) {
				charA = text.subTextLine(i, i+1);
				if (i+1<textLen) {
					isNextCharBkSp = isNextCharBkSp(text, i);
				}
				else {
					isNextCharBkSp = false;
				}
				isDeleteChar = isCurCharDelete(text, i);
				isCurCharBkSp = isCurCharBkSp(text, i);
				
				if (isDeleteChar) {
					isDeleteChar = false;
					i+=3; // d 생략
				}
				else {
					if (isNextCharBkSp) {	// 다음 문자가 bksp이면 bksp다음으로 처리를 옮긴다.
						isNextCharBkSp = false;
						i += 3;
						continue;
					}
					if (isCurCharBkSp) {	// 다음 문자가 bksp이면 bksp다음으로 처리를 옮긴다.
						isCurCharBkSp = false;
						i += 2;
						continue;
					}
					if (charA.equals(Edit.NewLineChar)) {
						textTemp1.add(charA.characters[0]);
						textArrayLocal = setTextArrayNoSpaceError(textArrayLocal, numOfLinesLocal-1, textTemp1);
						setCursorPos(lineNumber, i, true, false, cursorPosLocal);						
						
						numOfLinesLocal++;
						textTemp1 = new TextLine(0,0);
						textTemp2 = new TextLine(0,0);
						lineWidth = 0;
					}				
					else  {
						textTemp1.add(charA.characters[0]);
						//lineWidth = paint.measureText(textTemp1);
						lineWidth += paint.measureText(charA);
						if (lineWidth > rationalBoundsWidth) {
							textArrayLocal = setTextArrayNoSpaceError(textArrayLocal, numOfLinesLocal-1, textTemp2);
							numOfLinesLocal++;
							textArrayLocal = setTextArrayNoSpaceError(textArrayLocal, numOfLinesLocal-1, new TextLine(0,0));
							setCursorPos(lineNumber, i, true, true, cursorPosLocal);
							textTemp1 = new TextLine(0,0);
							textTemp2 = new TextLine(0,0);
							lineWidth = 0;
							i--;	// 초과된 문자(다음줄의 첫문자)를 다시 처리
						}
						else {
							textTemp2.add(charA.characters[0]);
							textArrayLocal = setTextArrayNoSpaceError(textArrayLocal, numOfLinesLocal-1, textTemp2);
							setCursorPos(lineNumber, i, false, false, cursorPosLocal);
						}
					}
				}	// isDeleteChar == false;
				
			}		// for
			
						
			for (i=0; i<numOfLinesLocal; i++) {
				if (textArrayLocal[i]!=null && textArrayLocal[i].count!=0) {
					textArrayLocal[i].setLineHeight(30);
				}
			}
			try {
				if (numOfLinesToDelete==-1) {
					// 마지막 라인에서 엔터를 누른 경우 numOfLinesLocal는 두 줄이므로
					// '\n'으로 끝나더라도 -1을 하지 않는다.
					if (lineNumber!=numOfLines-1 &&
							text.count>0 && text.characters[text.count-1].charA=='\n') {
						numOfLinesLocal--;
					}
					this.numOfLines -= numOfLinesInText;
					textArray = FunctionOfEditRichText.toTextLineArray( Array.Delete(textArray, lineNumber, numOfLinesInText) );
				}
				else {
					// 마지막 라인에서 엔터를 누른 경우 numOfLinesLocal는 두 줄이므로
					// '\n'으로 끝나더라도 -1을 하지 않는다.
					if (lineNumber!=numOfLines-1 &&
							text.count>0 && text.characters[text.count-1].charA=='\n') {
						numOfLinesLocal--;
					}
					this.numOfLines -= numOfLinesToDelete;
					textArray = FunctionOfEditRichText.toTextLineArray( Array.Delete(textArray, lineNumber, numOfLinesToDelete) );
				}
				textArray = FunctionOfEditRichText.toTextLineArray( Array.InsertNoSpaceError(textArrayLocal, 0, textArray, lineNumber, 
						numOfLinesLocal, numOfLines) );
				this.numOfLines += numOfLinesLocal;
				//textArray = Array.Resize(textArray, numOfLines+100);
			}catch(Exception e) {
				e.printStackTrace();
				CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
			}
			
			//setVScrollBar();
			
			this.cursorPos = cursorPosLocal;
			
		} // if (!isSingleLine)
	}
	/** paste에서 사용*/
	public void setTextMultiLineBoth(int lineNumber, TextLine text, int numOfLinesToDelete) {
		if (text==null) return;
		int numOfLinesLocal = 1;
		
		if (!isSingleLine) {		
			TextLine[] textArrayLocal = new TextLine[20];
			Point cursorPosLocal = new Point(0,lineNumber);
			TextLine textTemp1 = new TextLine(0,0);
			int i;
			
			textArrayLocal[0] = new TextLine(0,initFontSize); // '\n'을 친 후에 새로 생긴 빈 라인을 위한 것이다.
			
			TextLine charA;
			boolean isDeleteChar = false;
			boolean isNextCharBkSp = false;
			boolean isCurCharBkSp = false;
			int textLen = text.count;
			
			
			for (i=0; i<textLen; i++) {
				charA = text.subTextLine(i, i+1);
				if (i+1<textLen) {
					isNextCharBkSp = isNextCharBkSp(text, i);
				}
				else {
					isNextCharBkSp = false;
				}
				isDeleteChar = isCurCharDelete(text, i);
				isCurCharBkSp = isCurCharBkSp(text, i);
				
				if (isDeleteChar) {
					isDeleteChar = false;
					i+=3; // d 생략
				}
				else {
					if (isNextCharBkSp) {	// 다음 문자가 bksp이면 bksp다음으로 처리를 옮긴다.
						isNextCharBkSp = false;
						i += 3;
						continue;
					}
					if (isCurCharBkSp) {	// 다음 문자가 bksp이면 bksp다음으로 처리를 옮긴다.
						isCurCharBkSp = false;
						i += 2;
						continue;
					}
					if (charA.equals(Edit.NewLineChar)) {
						//textTemp1 += "\n";
						textTemp1.add(charA.characters[0]);
						//textArrayLocal[numOfLinesLocal-1] = new String(textTemp1.getItems());
						textArrayLocal = setTextArrayNoSpaceError(
							textArrayLocal, numOfLinesLocal-1, textTemp1);
						setCursorPos(lineNumber, i, true, false, cursorPosLocal);						
						
						
						numOfLinesLocal++;
						textTemp1 = new TextLine(0,0);
					}				
					else  {
						textTemp1.add(charA.characters[0]);
						//textArrayLocal[numOfLinesLocal-1].add(charA.characters[0]);
						textArrayLocal = setTextArrayNoSpaceError(textArrayLocal, numOfLinesLocal-1, textTemp1);
						setCursorPos(lineNumber, i, false, false, cursorPosLocal);
					}
				}	// isDeleteChar == false;
				
			}		// for
			
			
			for (i=0; i<numOfLinesLocal; i++) {
				if (textArrayLocal[i]!=null && textArrayLocal[i].count!=0) {
					textArrayLocal[i].setLineHeight(30);
				}
			}
			
			try {
				//textArray = Array.Delete(textArray, lineNumber, numOfLinesInText);
				if (numOfLinesToDelete==-1) {
					// 마지막 라인에서 엔터를 누른 경우 numOfLinesLocal는 두 줄이므로
					// '\n'으로 끝나더라도 -1을 하지 않는다.
					if (lineNumber!=numOfLines-1 &&
							text.count>0 && text.characters[text.count-1].charA=='\n') {
						numOfLinesLocal--;
					}
					this.numOfLines -= numOfLinesInText;
					textArray = FunctionOfEditRichText.toTextLineArray( Array.Delete(textArray, lineNumber, numOfLinesInText) );
				}
				else {
					// 마지막 라인에서 엔터를 누른 경우 numOfLinesLocal는 두 줄이므로
					// '\n'으로 끝나더라도 -1을 하지 않는다.
					if (lineNumber!=numOfLines-1 &&
							text.count>0 && text.characters[text.count-1].charA=='\n') {
						numOfLinesLocal--;
					}
					this.numOfLines -= numOfLinesToDelete;
					textArray = FunctionOfEditRichText.toTextLineArray( Array.Delete(textArray, lineNumber, numOfLinesToDelete) );
				}
				
								
				textArray = FunctionOfEditRichText.toTextLineArray( Array.InsertNoSpaceError(textArrayLocal, 0, textArray, lineNumber, 
						numOfLinesLocal, numOfLines) );
				this.numOfLines += numOfLinesLocal;
				
				for (i=0; i<numOfLines; i++) {
					if (textArray[i]==null) {
						textArray[i] = new TextLine("", initFontSize);
					}
					else if (textArray[i].count!=0) {
						textArray[i].setLineHeight(30);
					}
				}
				//textArray = Array.Resize(textArray, numOfLines+100);
			}catch(Exception e) {
				e.printStackTrace();
				CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
			}
			
			this.cursorPos = cursorPosLocal;
			
		} // if (!isSingleLine)
	}
	
	void setHeightOfVScrollPos(int inc) {
		heightOfvScrollPos += inc;
		if (heightOfvScrollPos>heightOfLines-heightOfLinesPerPage) {
			heightOfvScrollPos = heightOfLines-heightOfLinesPerPage;
		}
		if (heightOfvScrollPos<0) heightOfvScrollPos = 0;
		setVScrollPos(heightOfvScrollPos);
	}
	
	void setWidthOfHScrollPos(int inc) {
		widthOfhScrollPos += inc;
		if (widthOfhScrollPos>widthOfTotalChars-widthOfCharsPerPage) {
			widthOfhScrollPos = widthOfTotalChars-widthOfCharsPerPage;
		}
		if (widthOfhScrollPos<0) widthOfhScrollPos = 0;
	}
	
	/** 이 메서드는 스크롤 위치(heightOfvScrollPos)가 바뀌면 vScrollPos가 바뀌어야 하므로 
	* 텍스트 내용이 바뀌거나(setVScrollPos()) 스크롤 버튼을 누르면(onTouchEvent) 호출된다.*/ 
	void setVScrollPos(float heightOfvScrollPos) {
		float h=0;
		int i;
		partOfCharY = 0;
		for (i=0; i<numOfLines; i++) {
			h += textArray[i].lineHeight;
			if (h>heightOfvScrollPos) {
				vScrollPos = i;
				partOfCharY = textArray[i].lineHeight - (h-heightOfvScrollPos);
				break;
			}
		}
	}
	
	/**  커서 위치(cursorPos)에 따라 자동 스크롤한다. 문자키를 눌러서 자동스크롤하여 그 다음 문자를 누르기 편하기위해 사용한다.
	 * setVScrollPos와 setHScrollPos, setVScrollBar, setHScrollBar는 텍스트 내용이 바뀔 때마다 
	 * setText, setTextOneLine에서 호출된다.커서위치는 setText, setTextOneLine에 있는 setCursorPos에서
	 * indexInText로 새로운 cursorPos가 결정된다. indexInText는 TextArrayToText에서 기존 cursorPos를 기반으로
	 * 결정된다. 
	 * 문자가 화면크기보다 큰 경우에도 스크롤할 수 있다.*/
	void setVScrollPos() {
		if (isReadOnly) return;
		
		float heightOfCursorPosY=0;
		int i;
		float topOfCursor, bottomOfCursor;
		try{
		for (i=0; i<=cursorPos.y; i++) {
			heightOfCursorPosY += textArray[i].lineHeight;
		}
		}catch(Exception e) {
		}
		
		bottomOfCursor = heightOfCursorPosY;
		descent = textArray[cursorPos.y].descent;
		leading = textArray[cursorPos.y].leading;
		topOfCursor = heightOfCursorPosY - textArray[cursorPos.y].maxFontSize - descent;
		
		if (!(heightOfvScrollPos<=topOfCursor && 
				bottomOfCursor<heightOfvScrollPos+heightOfLinesPerPage)) {
			if (heightOfvScrollPos>topOfCursor) {
				heightOfvScrollPos =  (int) topOfCursor;
			}
			else {
				heightOfvScrollPos = (int) (bottomOfCursor - heightOfLinesPerPage);
			}
			
		}
	}
	
	/** 키보드에 키를 입력할 경우 호출한다.
	 * 문자가 화면크기보다 큰 경우에도 스크롤할 수 있다.*/
	void setHScrollPos() {
		if (isReadOnly) return;
		try {
			float endOfWindow = widthOfhScrollPos+widthOfCharsPerPage;
			TextLine str;
			// 한글과 기타 다른 언어의 커서위치가 다르기 때문에 다음과 같이 한다.
			if (keyboardMode==Mode.Hangul && hangulMode!=Hangul.Mode.None) {
			//if (keyboard.mode==Mode.Hangul && Hangul.mode!=Hangul.Mode.None) {
				str = textArray[cursorPos.y].subTextLine(0, cursorPos.x);
			}
			else {
				if (cursorPos.x<=0) str = new TextLine("", fontSize);
				else str = textArray[cursorPos.y].subTextLine(0, cursorPos.x);
			}
			// 커서가 가리키는 문자의 폭을 측정한다.
			TextLine cursorChar;
			if (cursorPos.x<textArray[cursorPos.y].count)
				cursorChar = textArray[cursorPos.y].subTextLine(cursorPos.x, cursorPos.x+1);
			else 
				cursorChar = new TextLine("3", initFontSize);
			float cursorCharWidth = paint.measureText(cursorChar);
			
			float cursorStart = paint.measureText(str);
			float cursorEnd;
			if (cursorPos.x<textArray[cursorPos.y].count) {
				if (textArray[cursorPos.y].characters[cursorPos.x].size>heightOfLinesPerPage) {
					cursorEnd = cursorStart+initFontSize;
				}
				else {
					cursorEnd = cursorStart+cursorCharWidth;
				}
			}
			else {
				cursorEnd = cursorStart+initFontSize;
			}
			
			// 커서가 보이도록 스크롤한다.
			if (!(widthOfhScrollPos<=cursorStart && cursorEnd<endOfWindow)) {
				// Backspace키를 눌러 스크롤 시작범위를 넘어선 경우
				/*if (cursorEnd < widthOfhScrollPos) {
					widthOfhScrollPos = (int) (cursorEnd-widthOfCharsPerPage);
					if (widthOfhScrollPos<0) widthOfhScrollPos=0;
				}
				// 문자키를 눌러 스크롤 끝범위를 넘어선 경우
				else if (cursorStart >= endOfWindow){
					widthOfhScrollPos = (int) (cursorEnd-widthOfCharsPerPage);
					if (widthOfhScrollPos<0) widthOfhScrollPos=0;
				}
				else {
					widthOfhScrollPos = (int) (cursorEnd-widthOfCharsPerPage);
					if (widthOfhScrollPos<0) widthOfhScrollPos=0;
				}*/
				widthOfhScrollPos = (int) (cursorEnd-widthOfCharsPerPage+30);
				if (widthOfhScrollPos<0) widthOfhScrollPos=0;
			}
		}catch(Exception e) {
			e.printStackTrace();
			CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
		}
		
		
	}
	
	/** 수직 스크롤부분이 바뀔 경우 호출한다. 예를 들어 vScrollPos, bounds가 바뀔경우*/
	public void setVScrollBar(boolean requiresSetVScrollBar) {
		setHeightOfLines();
		heightOfLinesPerPage = (int) rationalBoundsHeight;
		
		if (heightOfvScrollPos+heightOfLinesPerPage>=heightOfLines)
			heightOfvScrollPos = heightOfLines - heightOfLinesPerPage;
		if (heightOfvScrollPos<0) heightOfvScrollPos = 0;
		setVScrollPos(heightOfvScrollPos);
		
				
		setNumOfLinesPerPage(heightOfvScrollPos, heightOfLinesPerPage);
		
		if (requiresSetVScrollBar) {
			vScrollBar.setVScrollBar(
					heightOfLinesPerPage,
					heightOfLines, heightOfvScrollPos, heightOfvScrollInc);
		}
	}
	
	/** 수평 스크롤부분이 바뀔 경우 호출한다. 예를 들어 hScrollPos, bounds가 바뀔경우*/
	public void setHScrollBar(boolean requiresSetHScrollBar) {
		
		int i;
		float maxLineWidth=0, lineWidth=0;
		for (i=0; i<numOfLines; i++) {
			lineWidth = paint.measureText(textArray[i]);
			if (lineWidth>maxLineWidth) {
				lineNumOfMaxWidth = i;
				maxLineWidth = lineWidth;
			}
		}
		this.maxLineWidth = maxLineWidth;
		
		
		widthOfTotalChars = (int) this.maxLineWidth;				
		widthOfCharsPerPage = (int) rationalBoundsWidth;
				
		if (widthOfhScrollPos+widthOfCharsPerPage>=widthOfTotalChars)
			widthOfhScrollPos = widthOfTotalChars - widthOfCharsPerPage;
		if (widthOfhScrollPos<0) widthOfhScrollPos = 0;
		
		
		if (requiresSetHScrollBar) {
			hScrollBar.setHScrollBar(
					widthOfCharsPerPage,
					widthOfTotalChars, widthOfhScrollPos, widthOfhScrollInc);
		}	
	}
	
	
	/** move to (cursorPosX, cursorPosY) and then CommonGUI.keyboard.setOnTouchListener(this)*/
	public void moveToCursorPos(int cursorPosX, int cursorPosY) {		
		this.moveToCursorPosY(cursorPosY);
		
		if (scrollMode==ScrollMode.Both) {
			//widthOfhScrollPos = cursorPos.x;
			this.cursorPos.x = cursorPosX;
			this.setHScrollPos();
			//setHScrollPosFromMenuProblemList();
			setHScrollBar(true);
		}
	}
	
	/** move to (0, cursorPosY) and then CommonGUI.keyboard.setOnTouchListener(this)*/
	public void moveToCursorPosY(int cursorPosY) {
		CommonGUI.keyboard.setOnTouchListener(this);
		
		cursorPos.x = 0;
		if (scrollMode==ScrollMode.VScroll) {
			cursorPos.y = getNumOfLinesInText(0, cursorPosY) + 1;
		}
		else {
			cursorPos.y = cursorPosY;
			cursorPos.x = 0;
		}
		
		vScrollPos = cursorPos.y - this.numOfLinesPerPage/2;
		setVScrollBar(true);
	}
	
	void deleteClone(int startLine) {
		int i;
		int[] items = new int[20];
		int countItems=0;
		boolean[] listRedunduncy = new boolean[listFindPos.count];
		int k;
		for (i=0; i<listFindPos.count; i+=2) {
			Point p = (Point)listFindPos.getItem(i);
			if (p.y==startLine) {
				
				for (k=0; k<countItems; k++) {
					if (items[k] == p.x) break;
				}
				if (k==countItems) {	// 발견되지 않았음.
					items[countItems++] = p.x;
				}
				else {
					listRedunduncy[i] = true;
					listRedunduncy[i+1] = true;
				}
			}
		}
		
		ArrayList listNewFindPos = new ArrayList(listFindPos.count);
		for (i=0; i<listRedunduncy.length; i++) {
			if (!listRedunduncy[i]) {
				listNewFindPos.add(listFindPos.list[i]);
			}
		}
		
		this.listFindPos = listNewFindPos;
	}
	
	
	String processSpecialChar(String str) {
		int i;
		ArrayListChar list = new ArrayListChar(30);
		list.setText(str);
		for (i=0; i<list.count; i++) {
			if (list.list[i]=='\\') {
				if (i+1<list.count) {
					if (list.list[i+1]=='n') { 
						list.list[i] = '\n';
						list.delete(i+1, 1);
					}
					else if (list.list[i+1]=='r') {
						list.list[i] = '\r';
						list.delete(i+1, 1);
					}
					else if(list.list[i+1]=='t') {
						list.list[i] = '\t';
						list.delete(i+1, 1);
					}
					
				}
			}
		}
		char[] arr = list.getItems();
		return new String(arr);
	}
		
	
	/** 스크롤바와 EditRichText선택영역의 MoveActionCapture처리 : 
	 * ActionDown(drag시작지점이 editRichText,scrollBar인가)을 활용하여 editRichText가
	 * action capture(자기영역을 벗어난 ActionMove를 자신이 가져간다)할지 안할지 결정한다.*/
	public boolean onTouch(MotionEvent event, SizeF scaleFactor) {		
		boolean r = false;		
		if (event.actionCode==MotionEvent.ActionDown || event.actionCode==MotionEvent.ActionDoubleClicked) {
			if (hides) return false;
			r = toolbar.onTouch(event, scaleFactor);
	    	if (r) return true;
	    	
			if (!super.onTouch(event, scaleFactor))     		
				return false;	    	
	    	
			r = vScrollBar.onTouch(event, scaleFactor);
			if (r) return true;
			if (scrollMode==ScrollMode.Both) {
				r = hScrollBar.onTouch(event, scaleFactor);
				if (r) return true;
			}
			
			// 통합키보드의 LangDialog의 editText만 제외하고 
			// isReadOnly(읽기모드)와는 상관없이 모든 EditText에 터치하기만하면
			// 키보드의 리스너가 되도록 한다.
			//if (Common_Settings.settings.isKeyboardEnable) {
				if (this.iName!=CommonGUI.keyboard.langDialog.editTextLang.iName) {
					CommonGUI.keyboard.setOnTouchListener(this);
					IntegrationKeyboard.EditTextOfLangDialogIsTouched = false;
				}
				else {
					IntegrationKeyboard.EditTextOfLangDialogIsTouched = true;
				}
			//}
			
			Control.capturedControl = this;
			onTouchEvent(this, event);
			
			// onTouchEvent에서 커서위치를 바꾼후(vScrollPos설정) editText의 bounds를 바꾸고 키보드를 보여준다.
			// 다시 말해 순서가 중요하다.
			if (Common_Settings.settings.EnablesScreenKeyboard) {
				if (!isReadOnly) {				
					if (!isSingleLine) {
						if (isMaximized()) {
							Rectangle newBoundsOfEditText = new Rectangle(totalBounds.x, totalBounds.y, totalBounds.width, (int)(Control.view.getHeight()*0.5f));
							changeBounds(newBoundsOfEditText);
							changeBoundsOfKeyboardAndSizingBorder(newBoundsOfEditText);
							isMaximized = false;
						}
						else {
							changeBoundsOfKeyboardAndSizingBorder(bounds);
			    		}
					}
					// isSingleLine이 true일 때도 키보드를 보여준다.
					//if (CommonGUI.keyboard.getHides()==true) {
						CommonGUI.keyboard.setHides(false);
					//}
					
				}
			}
			return true;
		}
		else if (event.actionCode==MotionEvent.ActionMove || 
				event.actionCode==MotionEvent.ActionUp) {
			
			// drag시작이 scrollBar이면 scrollBar가, editText라면 editText가 핸들링
			
			if (Control.capturedControl==this) {
				// 영역내에서 터치를 하여 캡쳐를 하면 CustomView에서 ActionMove를 전달하여 스크롤을 하게 된다.
				// 영역검사를 하지않고 영역을 벗어나더라도 자신이 핸들링한다.
				//modified = true;
				onTouchEvent(this, event);
				return true;
			}
			
		}
		return false;
    }
	
	
	
	
	
	void realign() {
		int k;
		if (scrollMode==ScrollMode.VScroll) {
			makingSelectP1P2OutOfEvent = true;
			TextLine newText = TextArrayToText(selectIndices[0].y, 0, cursorPos.y, cursorPos.x);
			setText(selectIndices[0].y, newText);			
		}
		else {
			if (!isSelecting) {
				textArray[cursorPos.y].setLineHeight(30);
			}
			else {
				// Both인 경우 textArray가 바뀌지 않으므로
				for (k=0; k<selectIndicesCount; k+=2) {
					textArray[selectIndices[k].y].setLineHeight(30);
				}
			}
			setVScrollPos();
			setHScrollPos();
			setVScrollBar(true);
			setHScrollBar(true);
		}
	}
	
	
	
	
	/** EditText의 이벤트 리스너, 이후에 draw가 호출된다*/
	public void editRichText_Listener(Object sender, MotionEvent e) {
		FunctionOfEditRichText.editRichText_Listener(this, sender, e);
	}
	
	public void fontSizeMenu_Listener(Object sender, String strFontSize) {
		FunctionOfEditRichText.fontSizeMenu_Listener(this, sender, strFontSize);
	}
	
	
	/** hasToolbarAndMenuFontSize이 true인 editText(즉 singleLine editText는 불가능하다)만 
	 * 호출이 가능하다.*/
	public void functionMenu_Listener(Object sender, String strMenuName) {
		FunctionOfEditRichText.functionMenu_Listener(this, sender, strMenuName);
	}
	
	public void toolbar_Listener(Object sender, String buttonName) {
		FunctionOfEditRichText.toolbar_Listener(this, sender, buttonName);
	}
	
	public void fileDialog_Listener(Object sender, String filename) {
		FunctionOfEditRichText.fileDialog_Listener(this, sender, filename);
	}
	
	public void integrationKeyboard_Listener(Object sender, MotionEvent e) {
		FunctionOfEditRichText.integrationKeyboard_Listener(this, sender, e);
	}
	
	public void findReplaceDialog_Listener(Object sender, MotionEvent e) {
		FunctionOfEditRichText.findReplaceDialog_Listener(this, sender, e);
	}
	
	public void typefaceMenu_Listener(Object sender, String strTypeface) {
		FunctionOfEditRichText.typefaceMenu_Listener(this, sender, strTypeface);
	}
	
	public void colorDialog_Listener(Object sender, int color) {
		FunctionOfEditRichText.colorDialog_Listener(this, sender, color);
	}
	
	public void onTouchEvent(Object sender, MotionEvent e) {
		
		errorMessage = null;
		try {
			if (sender==this) {
				editRichText_Listener(sender, e);
				return;
			}
			else { // if (sender!=this)
								
				if (sender instanceof Button) {
					Button button = (Button)sender;
					
					isBold = toolbar.buttons[3].getIsSelected();
					isUnderline = toolbar.buttons[4].getIsSelected();					
					isItalic = toolbar.buttons[5].getIsSelected();
					int i;
					// "S", "F", "C", "B", "U", "I", "P"
					for (i=0; i<namesOfButtonsOfToolbar.length; i++) {
						//if (button.name.equals(namesOfButtonsOfToolbar[i])) {
						if (button.iName==toolbar.buttons[i].iName) {
							toolbar_Listener(button, button.name);
							return;
						}
					}
					
					//"10", "14", "18", "22", "26", "30", "기타"
					for (i=0; i<Edit.Menu_FontSize.length; i++) {	// 메뉴버튼
						//if (button.name.equals(Menu_FontSize[i])) {
						if (button.iName==Edit.menuFontSize.buttons[i].iName) {	
							fontSizeMenu_Listener(button, Edit.Menu_FontSize[i]);
							return;
						} 
					}					
					
					// "Default", "SansSerif", "Serif"
					for (i=0; i<Menu_Typeface.length; i++) {	// 메뉴버튼
						//if (button.name.equals(Menu_Typeface[i])) {
						if (button.iName==menuTypeface.buttons[i].iName) {
							typefaceMenu_Listener(button, Menu_Typeface[i]);
							return;
						} // if
					}
					
					for (i=0; i<Edit.Menu_Function.length; i++) {	// 메뉴버튼
						//if (button.name.equals(Menu_FontSize[i])) {
						if (button.iName==Edit.menuFunction.buttons[i].iName) {	
							functionMenu_Listener(button, Edit.Menu_Function[i]);
							return;
						} 
					}
					
				}
				else if (sender instanceof VScrollBar) {
					VScrollBar vScrollBar = (VScrollBar)sender;
					this.heightOfvScrollPos = vScrollBar.heightOfvScrollPos;
					// setVScrollPos()가 아니라 setVScrollPos(heightOfvScrollPos)을 사용한다.
					setVScrollPos(heightOfvScrollPos);
					setVScrollBar(false);
					// 수직 스크롤바 터치시 수평스크롤 부분도 바뀌므로 호출해야 한다.
					if (scrollMode==ScrollMode.Both) {
						setHScrollBar(false);
					}
				}
				else if (sender instanceof HScrollBar) {
					HScrollBar hScrollBar = (HScrollBar)sender;
					this.widthOfhScrollPos = hScrollBar.widthOfScrollPos;
					setHScrollBar(false);
					// 수평 스크롤바 터치시 수직스크롤 부분은 바뀌지 않으므로 호출하지 않는다.
					//setVScrollPos(heightOfvScrollPos);
					//setVScrollBar(false);
				}
				else if (sender instanceof IntegrationKeyboard) {
					integrationKeyboard_Listener(sender, e);
				} // if (className.equals(IntegrationKeyboard))
				else if (sender instanceof FontSizeDialog) {
					fontSizeMenu_Listener(sender, fontSizeDialog.curText);
				}
				else if (sender instanceof FindReplaceDialog) {
					this.findReplaceDialog_Listener(sender, e);
				}
				else if (sender instanceof ColorDialog) {
					colorDialog_Listener(sender, colorDialog.selectedColor);
				}
				else if (sender instanceof FileDialog) {
					FileDialog dialog = (FileDialog)sender;
					if (dialog.getIsOK()) {
						if (dialog.iName!=fileDialog.iName) return;
						fileDialog_Listener(sender, fileDialog.filename);
					}
				}
			}
		}catch (Exception e1) {
			e1.printStackTrace();
			CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e1);
		}
		
	}
	
	public TextLine getCurChar() {
		if (cursorPos.x<textArray[cursorPos.y].count) {
			return textArray[cursorPos.y].subTextLine(cursorPos.x, cursorPos.x+1);
		}
		return null;
	}
	
	public Point getCharPos(MotionEvent e) {
		if (cursorPos.y<0) cursorPos.y=0;
		if (cursorPos.y>=numOfLines) cursorPos.y=numOfLines-1;
		
		Point r = new Point();
		try{
		if (scrollMode==ScrollMode.VScroll) {
			int i;			
			float h = -partOfCharY;
			float eventY = e.y - bounds.y;
			r.y = numOfLines-1;
			for (i=vScrollPos; i<numOfLines; i++) {
				h += textArray[i].lineHeight;
				if (eventY <= h) {
					r.y = i;
					break;				
				}
			}
			if (r.y>=numOfLines) r.y = numOfLines-1;
			
			
			float lineWidth = bounds.x + gapX;
			
			int lineLen = textArray[r.y].count;
			TextLine charA=null;
			for (i=0; i<lineLen; i++) {
				charA = textArray[r.y].subTextLine(i, i+1);
				if (charA.equals(Edit.NewLineChar)) break;
				lineWidth += paint.measureText(charA);
				if (e.x<=lineWidth) {				
					break;
				}
			}
			TextLine lastChar = charA;
			if (lineLen==0) r.x = 0;
			else {	// lineLen>0
				if (i < lineLen) {
					if (i==0) r.x = 0;
					else {	// 0<i && i<lineLen		문자열 클릭
						if (lastChar.equals(Edit.NewLineChar)) r.x = i; 
						// 커서는 \n을 가리킨다.
						else r.x = i;
					}
				}
				else {	// i==lineLen 문자열을 넘어서 클릭
					if (lastChar.equals(Edit.NewLineChar)) r.x = (lineLen-1);
					// 커서는 \n을 가리킨다.
					else r.x = lineLen;
				}
			}
			
			
		}
		else if (scrollMode==ScrollMode.Both) {		
			int i;			
			float h = -partOfCharY;
			r.y = numOfLines-1;
			float eventY = e.y - bounds.y;
			for (i=vScrollPos; i<numOfLines; i++) {
				h += textArray[i].lineHeight;
				if (eventY <= h) {
					r.y = i;
					break;				
				}
			}
			if (r.y>=numOfLines) r.y = numOfLines-1;
			if (r.y<0) r.y = 0; 			
			
			float eventXRelative = e.x-(bounds.x+gapX); 
			float lineWidth = 0;
			
			int lineLen = textArray[r.y].count;
			TextLine charA=null;
			for (i=0; i<lineLen; i++) {
				charA = textArray[r.y].subTextLine(i, i+1);
				if (charA.equals(Edit.NewLineChar)) {
					break;
				}
				lineWidth += paint.measureText(charA);
				if (widthOfhScrollPos+eventXRelative <= lineWidth) {				
					break;
				}
			}
			TextLine lastChar = charA;
			if (lineLen==0) {
				r.x = 0;
			}
			else {	// lineLen>0
				if (i < lineLen) {
					//if (i==0) r.x = 0;
					//else {	// 0<i && i<lineLen		문자열 클릭
						if (lastChar.equals(Edit.NewLineChar)) {
							// 커서는 \n을 가리킨다.
							r.x = i; 
						}						
						else r.x = i;
					//}
				}
				else {	// i==lineLen 문자열을 넘어서 클릭
					r.x = lineLen;
					// 커서는 마지막문자의 뒤를 가리킨다.
				}
			}
			
		}//if (scrollMode==ScrollMode.Both)
		}catch(Exception e1) {
			e1.printStackTrace();
			CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e1);
			return null;
		}
		return r;
	}
	
	/**fontSize를 커서의 문자크기로 set한다. 
	 * 툴바와 현재상태를 현재 커서가 가리키는 문자의 상태로 바꾼다. 이후에 addChar, replaceChar에서 그 툴바상태로 문자를 입력한다.*/
	void setToolbarAndCurState(Point cursorPos) {
		
		if (textArray[cursorPos.y].count==0) {
			fontSize = initFontSize;
			curColor = textColor;
			isUnderline = false;
			//typeface = Control.typefaceDefault;
			typefaceName = Menu_Typeface[0];
			isBold = false;
			isItalic = false;
		}
		else if (textArray[cursorPos.y].count>cursorPos.x) {
			Character c = textArray[cursorPos.y].characters[cursorPos.x];
			fontSize = c.size;
			curColor = c.charColor;
			isUnderline = c.isUnderLine;
			isBold = c.isBold;
			isItalic = c.isItalic;
			typeface = c.typeface;
			typefaceName = c.typefaceName;
			
			/*toolbar.buttons[2].backColor = curColor;
			toolbar.buttons[3].Select(isBold);
			toolbar.buttons[4].Select(isUnderline);
			toolbar.buttons[5].Select(isItalic);*/
		}
		else {
			// 그 줄의 마지막 문자의 size로 fontSize를 정한다.
			Character c = textArray[cursorPos.y].characters[textArray[cursorPos.y].count-1];
			fontSize = c.size;
			curColor = c.charColor;
			isUnderline = c.isUnderLine;
			isBold = c.isBold;
			isItalic = c.isItalic;
			typeface = c.typeface;
			typefaceName = c.typefaceName;
			
		}
		toolbar.buttons[0].setText(""+fontSize);
		//toolbar.buttons[2].backColor = curColor;
		toolbar.buttons[2].setBackColor(curColor);
		toolbar.buttons[3].setIsSelected(isBold);
		toolbar.buttons[4].setIsSelected(isUnderline);
		toolbar.buttons[5].setIsSelected(isItalic);
	}
	
	public boolean endsWithNewLineChar(TextLine lineText) {
		int lineLen = lineText.count;
		if (lineLen > 0) {
			if (lineText.subTextLine(lineLen-1, lineLen).equals(Edit.NewLineChar)) {
				return true;
			}
			return false;
		}
		return false;		
	}
	
	TextLine deleteNewLineChar(TextLine lineText) {
		int lineLen = lineText.count;
		if (lineLen > 0) {
			if (lineText.subTextLine(lineLen-1, lineLen).equals(Edit.NewLineChar)) {
				if (lineLen > 1)
					return lineText.subTextLine(0, lineLen-1);
				else 
					return new TextLine(0,0);
			}
			else {
				return lineText;
			}
		}
		else {
			return new TextLine(0,0);
		}
	}
	
	PartOfStr getStringHScroll(TextLine str) {
		try{
		int start=-1, end=-1;
		float w=0;
		float part1OfChar=0;
		float part2OfChar=0;
		w= widthOfhScrollPos;
		int i;
		float lineWidth=0;
		for (i=0; i<str.count; i++) {
			TextLine charA = str.subTextLine(i, i+1);
			float wOfCharA = paint.measureText(charA); 
			lineWidth += wOfCharA;
			if (lineWidth>w) {
				start = i;
				part2OfChar = lineWidth-w;
				part1OfChar = wOfCharA-part2OfChar;
				break;
			}
		}
		int startIndex;
		if (part1OfChar==0) {
			startIndex = start;
			lineWidth = 0;
		}
		else {
			startIndex = start+1;
			lineWidth = part2OfChar;
			end = start;
		}
		if (start!=-1) {
			for (i=startIndex; i<str.count; i++) {
				TextLine charA = str.subTextLine(i, i+1);
				lineWidth += paint.measureText(charA);
				if (lineWidth<=rationalBoundsWidth) {
					end = i;
				}				
				else { // 넘은 문자 포함
					end = i;
					break;
				}
			}
		}
		if (start==-1 || end==-1) {
			return new PartOfStr(new TextLine(0,0),start,end,
					part1OfChar,part2OfChar);
		}
		else {
			return new PartOfStr(str.subTextLine(start, end+1),start,end,
					part1OfChar,part2OfChar);
		}
		}catch(Exception e) {
			e.printStackTrace();
			CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
			return null;
		}
			
	}
	
	class PartOfStr {
		TextLine str;
		int start=-1;
		int end=-1;
		float part1OfChar=0;
		float part2OfChar=0;
		
		PartOfStr(TextLine str, int start, int end, 
				float part1OfChar, float part2OfChar) {
			this.str = str;
			this.start = start;
			this.end = end;
			this.part1OfChar=part1OfChar;
			this.part2OfChar=part2OfChar;
		}
	}
	
	
	
	PartOfStr getStringHScrollAndCursorVisuablity(TextLine str) {
		try{
		int start=-1, end=-1;
		float part1OfChar=0;
		float part2OfChar=0;		
		
		if (str.equals("") || str.equals("\n")) {			
			if (widthOfhScrollPos>=fontSize) {
				isCursorSeen = false;
				return new PartOfStr(new TextLine(0,0),start,end,
						part1OfChar,part2OfChar);
			}
			else {
				start = 0;
				end = 0;				
			}
		}
		else {		
			PartOfStr result = getStringHScroll(str);
			start = result.start;
			end = result.end;
			part1OfChar=result.part1OfChar;
			part2OfChar=result.part2OfChar;
		}
		
		if (start==-1 || end==-1) {
			isCursorSeen = false;
			return new PartOfStr(new TextLine(0,0),start,end,
					part1OfChar,part2OfChar);
		}
		else {
			int endIndex;
			if (CommonGUI.keyboard.mode==Mode.Hangul && Hangul.mode!=Hangul.Mode.None) {
				endIndex = end;
			}
			else {
				endIndex = end+1;
			}
			//endIndex = end+1;
			if (start<=cursorPos.x && cursorPos.x<=endIndex) {
				isCursorSeen = true;
				valueOfCursorRelativeToHScroll = 0;
				return new PartOfStr(str.subTextLine(start, cursorPos.x),start,end,
						part1OfChar,part2OfChar);
				// return str.subTextLine(start, cursorPos.x);
			}
			else {
				if (cursorPos.x<start) valueOfCursorRelativeToHScroll = -1;
				else valueOfCursorRelativeToHScroll = 1;
				isCursorSeen = false;
				//return new TextLine(0,0);
				return new PartOfStr(new TextLine(0,0),start,end,
						part1OfChar,part2OfChar);
			}
		}
		}catch(Exception e) {
			e.printStackTrace();
			CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
			return null;
		}
	}
	
	void drawErrorMessage(Canvas canvas) {
		float x, y;
		paint.setColor(Color.RED);
		float w = paint.measureText(errorMessage);
		x = bounds.x + bounds.width/2 - w/2;
		y = bounds.y + bounds.height/2 - paint.getTextSize()/2;
		canvas.drawText(errorMessage, x, y, paint);
	}
	
	
	
	/** 실행순서에서 제일 마지막에 그린다.
	 * 실행순서 : constructor->(add or replace Char)->setText or setTextOneLine->
	 * setVScrollBar or setHScrollBar->draw*/
	public synchronized void draw(Canvas canvas) {
		synchronized(this) {
		try{
		if (hides) return;
	
		canvas.save();
		
		paint.setColor(backColor);
		//paint.setTypeface(typeface);
				
		canvas.drawRect(bounds.toRectF(), paint);		
    	canvas.drawRect(bounds.toRectF(), paintOfBorder);
    	
    	    	
    	Rect clipRect = new Rect();
    	clipRect.left = (int) (bounds.x+gapX); 
    	clipRect.top = (int)(bounds.y+1); 
    	if (scrollMode==ScrollMode.VScroll) {
    		clipRect.right = (int) (bounds.right()-vScrollBarWidth-gapX);
    		clipRect.bottom = (int) (bounds.bottom());
    	}
    	else {
    		if (isSingleLine) {
    			clipRect.right = (int) (bounds.right()-gapX);
    			clipRect.bottom = (int) (bounds.bottom());
    		}
    		else {
    			clipRect.right = (int) (bounds.right()-vScrollBarWidth-gapX);
    			clipRect.bottom = (int) (bounds.bottom()-hScrollBarHeight);
    		}
    	}
    	if (!canvas.clipRect(clipRect, Region.Op.REPLACE)) {
    		Log.e("editRichText onDraw","No clipping");
    	}
    	
		if (isSingleLine) {
			RectangleF locAndSizeOfText = Font.getLocAndTextSize(paint, bounds, 
    				text, FontSortVert.Middle, 0);
    		paint.setTextSize(locAndSizeOfText.height);
    		paint.setColor(textColor);
    		//paint.setAlpha(60);
    		canvas.drawText(text, locAndSizeOfText.x, locAndSizeOfText.y, paint);
    		//paint.setAlpha(255);
		}
		else {
			int i, j;
			float x, y, y1, y2;
			
			try{				
				if (isSelecting) {
					if (scrollMode==ScrollMode.VScroll && makingSelectP1P2OutOfEvent) {
						FunctionOfEditRichText.makeSelectIndices(this, true, selectP1Logical,selectP2Logical);
						makingSelectP1P2OutOfEvent = false;
					}
					Point[] intersectedSelect = FunctionOfEditRichText.getIntersectWithSelect(this, true);
					if (intersectedSelect!=null && intersectedSelect.length!=0) {
						y1 = bounds.y + TextLine.measureHeight(textArray, vScrollPos, intersectedSelect[0].y);
						y1 -= partOfCharY;
						for (i=0; i<intersectedSelect.length; i+=2) {
							j = intersectedSelect[i].y;
							y1 += TextLine.measureHeight(textArray, j, j+1);
							float charSize;
							float selectHeight;
							RectangleF dst = null;
							float x2;
							charSize = textArray[j].maxFontSize;
							y2 = y1 - textArray[j].descent; // baseline
							selectHeight = charSize + textArray[j].descent + textArray[j].leading;
							y = y2 - (charSize+textArray[j].leading);
							
							float w;
							if (selectLenY==1 && intersectedSelect[i+1].y==Select_FirstLine) {									
								TextLine str = textArray[j].subTextLine(0, intersectedSelect[0].x);
								if (str!=null) {
									x = bounds.x + gapX + paint.measureText(str);
									TextLine str2;
									if (intersectedSelect[1].x+1<=textArray[j].count)
										str2 = textArray[j].subTextLine(0, intersectedSelect[1].x+1);
									else 
										str2 = textArray[j].subTextLine(0, intersectedSelect[1].x);
									x2 = bounds.x + gapX + paint.measureText(str2);
									if (scrollMode==ScrollMode.Both) {
										x -= this.widthOfhScrollPos;
										x2 -= this.widthOfhScrollPos;									
									}
									w = x2 - x;
									dst = new RectangleF(x, y, w, selectHeight);
								}
							}
							else if (selectLenY>1 && intersectedSelect[i+1].y==Select_FirstLine) {
								TextLine str = null;
								if (intersectedSelect[0].x>=0)
									str = textArray[j].subTextLine(0, intersectedSelect[0].x);
								if (str!=null) {
									x = bounds.x + gapX + paint.measureText(str);
									if (scrollMode==ScrollMode.Both) {
										x -= this.widthOfhScrollPos;
										if (x<bounds.x+gapX) x = 0;
									}
									w = (bounds.x + bounds.width - vScrollBarWidth) - x;
									dst = new RectangleF(x, y, w, selectHeight);
								}
							}
							else if (selectLenY>1 && intersectedSelect[i+1].y==Select_MiddleLine) {
								x = bounds.x;
								w = (bounds.x + bounds.width - vScrollBarWidth) - x;
								dst = new RectangleF(x, y, w, selectHeight);
							}
							else if (selectLenY>1 && intersectedSelect[i+1].y==Select_LastLine) {
								TextLine str;
								if (intersectedSelect[intersectedSelect.length-1].x+1<=textArray[j].count)
									str = textArray[j].subTextLine(
											0, intersectedSelect[intersectedSelect.length-1].x+1);
								else 
									str = textArray[j].subTextLine(
											0, intersectedSelect[intersectedSelect.length-1].x);
								if (str!=null) {
									x = bounds.x;
									w = (bounds.x + gapX + paint.measureText(str)) - x;
									if (scrollMode==ScrollMode.Both) {
										w -= this.widthOfhScrollPos;
									}
									dst = new RectangleF(x, y, w, selectHeight);
								}
							}
							if (dst!=null) {
								paint.setColor(Edit.selectColor);
								//paint.setAlpha(80);								 
								canvas.drawRect(dst.toRectF(), paint);
								//paint.setAlpha(255);
							}
							dst = null;
						}
					}
				}
			}catch(Exception e) {
				e.printStackTrace();
				CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
			}
			try {
			if (isFound) {
				/*if (scrollMode==ScrollMode.VScroll && makingSelectP1P2OutOfEvent) {
					makeSelectIndices(selectP1Logical,selectP2Logical);
					makingSelectP1P2OutOfEvent = false;
				}*/
				Point[] intersectedSelect = FunctionOfEditRichText.getIntersectWithSelect(this, false);
				if (intersectedSelect!=null && intersectedSelect.length!=0) {
					y1 = bounds.y + TextLine.measureHeight(textArray, vScrollPos, intersectedSelect[0].y);
					y1 -= partOfCharY;
					for (i=0; i<intersectedSelect.length; i+=2) {
						j = intersectedSelect[i].y;
						y1 += TextLine.measureHeight(textArray, j, j+1);
						float charSize;
						float findHeight;
						RectangleF dst = null;
						float x2;
						charSize = textArray[j].maxFontSize;
						y2 = y1 - textArray[j].descent; // baseline
						findHeight = charSize + textArray[j].descent + textArray[j].leading;
						y = y2 - (charSize+textArray[j].leading);
						
						float w;
						if (findLenY==1 && intersectedSelect[i+1].y==Select_FirstLine) {									
							TextLine str = textArray[j].subTextLine(0, intersectedSelect[0].x);
							if (str!=null) {
								x = bounds.x + gapX + paint.measureText(str);
								TextLine str2;
								if (intersectedSelect[1].x+1<=textArray[j].count)
									str2 = textArray[j].subTextLine(0, intersectedSelect[1].x+1);
								else 
									str2 = textArray[j].subTextLine(0, intersectedSelect[1].x);
								x2 = bounds.x + gapX + paint.measureText(str2);
								if (scrollMode==ScrollMode.Both) {
									x -= this.widthOfhScrollPos;
									x2 -= this.widthOfhScrollPos;									
								}
								w = x2 - x;
								dst = new RectangleF(x, y, w, findHeight);
							}
						}
						else if (findLenY>1 && intersectedSelect[i+1].y==Select_FirstLine) {
							TextLine str = textArray[j].subTextLine(0, intersectedSelect[0].x);
							if (str!=null) {
								x = bounds.x + gapX + paint.measureText(str);
								if (scrollMode==ScrollMode.Both) {
									x -= this.widthOfhScrollPos;
									if (x<bounds.x+gapX) x = 0;
								}
								w = (bounds.x + bounds.width - vScrollBarWidth) - x;
								dst = new RectangleF(x, y, w, findHeight);
							}
						}
						else if (findLenY>1 && intersectedSelect[i+1].y==Select_MiddleLine) {
							x = bounds.x;
							w = (bounds.x + bounds.width - vScrollBarWidth) - x;
							dst = new RectangleF(x, y, w, findHeight);
						}
						else if (findLenY>1 && intersectedSelect[i+1].y==Select_LastLine) {
							TextLine str;
							if (intersectedSelect[intersectedSelect.length-1].x+1<=textArray[j].count)
								str = textArray[j].subTextLine(
										0, intersectedSelect[intersectedSelect.length-1].x+1);
							else 
								str = textArray[j].subTextLine(
										0, intersectedSelect[intersectedSelect.length-1].x);
							if (str!=null) {
								x = bounds.x;
								w = (bounds.x + gapX + paint.measureText(str)) - x;
								if (scrollMode==ScrollMode.Both) {
									w -= this.widthOfhScrollPos;
								}
								dst = new RectangleF(x, y, w, findHeight);
							}
						}
						if (dst!=null) {
							paint.setColor(Edit.foundColor);
							//paint.setAlpha(150);								 
							canvas.drawRect(dst.toRectF(), paint);
							//paint.setAlpha(255);
						}
						dst = null;
					}
				}
			}// if (isFound)
			}catch(Exception e) {
				e.printStackTrace();
				CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
			}
			
			try {
				//int i, j;
				//float x=0, y=0, y1=0, y2=0;
				
				//paint.setTextSize(fontSize);
	    		paint.setColor(textColor);
	    		//paint.setAlpha(60);
	    		
	    		if (scrollMode==ScrollMode.VScroll) {
	    			y1 = bounds.y;
	    			y1 -= partOfCharY;
	    			float oldTextSize = paint.getTextSize();
	    			int oldColor = paint.getColor();
	    			Typeface oldTypeface = paint.getTypeface();
	    			int limit = Math.min(vScrollPos+numOfLinesPerPage, this.numOfLines);
					for (i=vScrollPos; i<limit; i++) {
						x = bounds.x + gapX;
						//y = bounds.y + (lineY+1) * lineHeight;
						y1 += textArray[i].lineHeight;						
						y2 = y1 - textArray[i].descent; // baseline
						//if (y1 < bounds.y+bounds.height) {
							TextLine lineText = deleteNewLineChar(textArray[i]);
							for (j=0; j<lineText.count; j++) {
								if (lineText.characters[j].bitmap==null) {
									paint.setTextSize(lineText.characters[j].size);
									paint.setTypeface(lineText.characters[j].typeface);
									paint.setColor(lineText.characters[j].charColor);
									if (lineText.characters[j].isUnderLine)
										paint.setUnderlineText(true);
									else paint.setUnderlineText(false);
									String c = lineText.characters[j].toString();
									//paint.setColor(lineText.characters[j].color);
									canvas.drawText(c, x, y2, paint);
									x += paint.measureText(c);
								}
								else {
									Bitmap bitmap = lineText.characters[j].bitmap;
									canvas.drawBitmap(bitmap, x, (y1+y2)/2-lineText.characters[j].size, paint);
									x += bitmap.getWidth();
								}
							}
						//}					
					}
					paint.setTextSize(oldTextSize);
					paint.setTypeface(oldTypeface);
	    			paint.setColor(oldColor);
	    		}
	    		else if (scrollMode==ScrollMode.Both) {
	    			y1 = bounds.y;
	    			y1 -= partOfCharY;
	    			float oldTextSize = paint.getTextSize();
	    			int oldColor = paint.getColor();
	    			Typeface oldTypeface = paint.getTypeface();
	    			int limit = Math.min(vScrollPos+numOfLinesPerPage, this.numOfLines);
	    			for (i=vScrollPos; i<limit; i++) {
						x = bounds.x + gapX;
						y1 += textArray[i].lineHeight;
						y2 = y1 - textArray[i].descent;	// baseline
						//if (y1 < bounds.y+bounds.height) {
							TextLine lineText=null;
							lineText = deleteNewLineChar(textArray[i]);
							if ( !lineText.equals(new TextLine(0,0)) ) {
								PartOfStr lineTextHScroll=null;
								lineTextHScroll = getStringHScroll(lineText);
								x -= lineTextHScroll.part1OfChar;
								try {
									for (j=0; j<lineTextHScroll.str.count; j++) {
										if (lineTextHScroll.str.characters[j].bitmap==null) {
											paint.setColor(lineTextHScroll.str.characters[j].charColor);
											paint.setTextSize(lineTextHScroll.str.characters[j].size);
											paint.setTypeface(lineTextHScroll.str.characters[j].typeface);
											if (lineTextHScroll.str.characters[j].isUnderLine)
												paint.setUnderlineText(true);
											else paint.setUnderlineText(false);
											String c = lineTextHScroll.str.characters[j].toString();								
											canvas.drawText(c, x, y2, paint);
											x += paint.measureText(c);
										}
										else {
											Bitmap bitmap = lineTextHScroll.str.characters[j].bitmap;
											//canvas.drawBitmap(bitmap, x, (y1+y2)/2-lineTextHScroll.str.characters[j].size, paint);
											canvas.drawBitmap(bitmap, x, y2-lineTextHScroll.str.characters[j].size, paint);
											x += bitmap.getWidth();
										}
									}
								
									// 문자의 잘리는 부분을 backColor로 칠하여 지운다.
									/*x = bounds.x+gapX-lineTextHScroll.part1OfChar;
									paint.setColor(this.backColor);
									canvas.drawRect(new RectF(x,y1-lineTextHScroll.str.lineHeight+1,
											x+lineTextHScroll.part1OfChar,y1+lineTextHScroll.str.lineHeight), paint);
									paint.setColor(Color.BLACK);*/
								}catch(Exception e) {
									e.printStackTrace();
									CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
								}
							}
							
						//}//if (y1 < bounds.y+bounds.height) {					
					}
	    			paint.setTextSize(oldTextSize);
	    			paint.setTypeface(oldTypeface);
	    			paint.setColor(oldColor);
	    		}
	    		//paint.setAlpha(255);
	    		
	    		
				
	    		try{
				float w;
				x = 0;
				
				// 읽기모드와는 상관없이 키보드의 listener가 자신이면 커서를 그린다.
	    		if (CommonGUI.keyboard!=null && this==CommonGUI.keyboard.listener) 
	    			isCursorSeen = true;
	    		else isCursorSeen = false;
	    		
	    		// 키보드의 LangDialog의 editText가 터치되도라도 커서를 보여줘야 한다.
	    		if (IntegrationKeyboard.EditTextOfLangDialogIsTouched) {
	    			isCursorSeen = true;
	    		}
	    		
	    		// 커서가 잘못된 것일 경우 예외 코드
	    		if (isCursorSeen && vScrollPos<=cursorPos.y && 
						cursorPos.y<vScrollPos+numOfLinesPerPage) {
		    		if (cursorPos.x<0 || cursorPos.x>textArray[cursorPos.y].count) {
		    			isCursorSeen = false;
		    		}
	    		}
	    		else {
	    			isCursorSeen = false;
	    		}
	    		
	    		
				if (isCursorSeen && vScrollPos<=cursorPos.y && 
						cursorPos.y<vScrollPos+numOfLinesPerPage) {
					
					TextLine text;
					TextLine curLine = textArray[cursorPos.y];
					int lineLen = curLine.count;
					
					isCursorSeen = true;
					TextLine curChar=null;
					if (lineLen>0) {
						// 문자열 바깥을 클릭하면 getCharPos에서 마지막 문자가 \n인지 아닌지에 따라
						// 커서위치를 정해주므로 여기에서는 고려할 필요가 없고, 커서위치에 커서를 
						// 그려주기만 하면 된다.
						if (scrollMode==ScrollMode.Both) {
							PartOfStr textHScroll = getStringHScrollAndCursorVisuablity(curLine);
							if (isCursorSeen) {
								x = bounds.x + gapX + paint.measureText(textHScroll.str);
								x -= textHScroll.part1OfChar;
							}
						}
						else {
							text = curLine.subTextLine(0, cursorPos.x);
							float w1 = paint.measureText(text);
							x = bounds.x + gapX + w1;
						}
						if (cursorPos.x<lineLen) {
							curChar = curLine.subTextLine(cursorPos.x,cursorPos.x+1);
							w = paint.measureText(curChar);
						}
						else { // if (cursorPos.x>=lineLen) 문자열 바깥
							curChar = new TextLine(0,0);
							w = 0;							
						}						
					}
					else {	// if (lineLen<=0)
						if (scrollMode==ScrollMode.Both) {
							PartOfStr textHScroll = getStringHScrollAndCursorVisuablity(new TextLine(0,0));
							x = bounds.x + gapX + paint.measureText(textHScroll.str);
							w = 0;
						}
						else {
							x = bounds.x + gapX;
							w = 0;
						}
						curChar = new TextLine(0,0);
					}
					
					if (isCursorSeen) {
						y1 = bounds.y;
						y1 -= partOfCharY;
						y1 += TextLine.measureHeight(textArray, vScrollPos, cursorPos.y+1);
						float cursorHeight;
						y2 = y1 - textArray[cursorPos.y].descent;	// baseline
						
						if (cursorPos.x<textArray[cursorPos.y].count) {
							if (textArray[cursorPos.y].characters[cursorPos.x].bitmap==null) {
								descent = fontSize*descentRate;
								leading = fontSize*leadingRate;								
							}
							else {
								descent = textArray[cursorPos.y].descent;
								leading = textArray[cursorPos.y].leading;
							}
						}
						else {
							descent = fontSize*descentRate;
							leading = fontSize*leadingRate;							
						}
						cursorHeight = fontSize + descent + leading;
						y = y2 - (fontSize+leading);
						
						//y = y2 - (fontSize+leading);
						drawCursor(canvas, x, y, y1, w, cursorHeight, curChar);
					}
				}
	    		}catch(Exception e) {
	    			e.printStackTrace();
	    			CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
				}
	    		
	    		
	    		/*if (!canvas.clipRect(originBounds, Region.Op.REPLACE)) {
	    			Log.e("editRichText onDraw", "No clip release");
	    		}*/
	    		
	    		canvas.restore();
	    		
				
				if (scrollMode==ScrollMode.Both) {
					vScrollBar.draw(canvas);
					hScrollBar.draw(canvas);
				}
				else {
					vScrollBar.draw(canvas);
				}
				
				toolbar.draw(canvas);
				
				
					    		
			}catch(Exception e) {
				e.printStackTrace();
				CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
			}
		}
		
		
		}catch(Exception e) {
    		
    	}
		}
		
	}// draw
	
	
	void drawCursor(Canvas canvas, float x, float y, float y1, float w, float cursorHeight,
			TextLine curChar) {
		if ((CommonGUI.keyboard.mode==Mode.Hangul && !(Hangul.mode==Hangul.Mode.None)) 
				||  isReadOnly) {
			// 한글이 조합중이거나 읽기모드인 경우
			if (curChar!=null && !curChar.equals("") && !curChar.equals("\n")) {
				if (Common_Settings.CurrentSystem==Common_Settings.CurrentSystemIsAndroid) {
					RectangleF dst = new RectangleF(x, y, w, cursorHeight);
					paint.setColor(Color.LTGRAY);
					paint.setAlpha(100);
					canvas.drawRect(dst.toRectF(), paint);
					paint.setAlpha(255);
				}
				else {// 현재 시스템이 자바이면 알파가 불가능하므로 이렇게 한다.
					RectangleF dst;
					if (cursorHeight>heightOfLinesPerPage) {
						y = y1-initFontSize;
						dst = new RectangleF(x, y, 5, initFontSize);
					}
					else {
						dst = new RectangleF(x, y, 5, cursorHeight);
					}
					paint.setColor(Edit.cursorColor);
					canvas.drawRect(dst.toRectF(), paint);
				}
			}//if (curChar!=null && !curChar.equals("") && !curChar.equals("\n")) {
			else {
				// 읽기 모드인데 curChar가 \n이나 ""이더라도 커서를 보여줘야 한다.
				RectangleF dst;
				if (cursorHeight>heightOfLinesPerPage) {
					y = y1-initFontSize;
					dst = new RectangleF(x, y, 5, initFontSize);
				}
				else {
					dst = new RectangleF(x, y, 5, cursorHeight);
				}
				paint.setColor(Edit.cursorColor);
				canvas.drawRect(dst.toRectF(), paint);
			}
		}//if ((CommonGUI.keyboard.mode==Mode.Hangul && !(Hangul.mode==Hangul.Mode.None)) 
		 //		||  isReadOnly) {
		else {// 한글이 조합중도 아니고 읽기모드도 아닌 경우
			RectangleF dst;
			if (cursorHeight>heightOfLinesPerPage) {
				y = y1-initFontSize;
				dst = new RectangleF(x, y, 5, initFontSize);
			}
			else {
				dst = new RectangleF(x, y, 5, cursorHeight);
			}
			paint.setColor(Edit.cursorColor);
			canvas.drawRect(dst.toRectF(), paint);
		}
	}

}