package com.gsoft.common.gui.edittext;

import android.graphics.Point;

import com.gsoft.common.gui.edittext.Edit.ScrollMode;
import com.gsoft.common.gui.edittext.EditRichText_Types.TextLine;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListString;

import com.gsoft.common.gui.edittext.EditRichText;
import com.gsoft.common.gui.edittext.UndoBufferOfEditRichText;
import com.gsoft.common.gui.edittext.FunctionOfEditRichText;
import com.gsoft.common.gui.edittext.RedoOfEditRichText;
import com.gsoft.common.gui.edittext.RedoBufferOfEditRichText;
import com.gsoft.common.gui.edittext.Edit;

public class UndoOfEditRichText {
	
	/** replaceAll에서 replace하는 위치들을 백업하기 위해 호출한다.*/
	public static void backUpForUndo_replace(EditRichText editRichText, String command, boolean isAll, boolean isForward, boolean isScopeAll, boolean isCaseSensitive, 
			boolean isWholeWord, Point curFindPosLocal, String textToFind, String textToReplaceWith,
			ArrayList listOfFindPos, ArrayList listOfReplacePos) {
		String addedInfo;
		if (!isScopeAll) {
			addedInfo = isAll + "-" + isForward + "-" + isScopeAll + "-" + isCaseSensitive + "-" +
				isWholeWord + "-" + 
				editRichText.selectP1.x + "-" + editRichText.selectP1.y + "-" + editRichText.selectP2.x + "-" + editRichText.selectP2.y;
		}
		else {
			addedInfo = isAll + "-" + isForward + "-" + isScopeAll + "-" + isCaseSensitive + "-" +
					isWholeWord;
		}
		String text = textToFind + "-" + textToReplaceWith;
		/*if (command.equals("replace")) {			
			editRichText.undoBuffer.push(new Point(curFindPosLocal.x,curFindPosLocal.y), new TextLine(text,editRichText.fontSize), command, addedInfo);
		}
		else*/ if (command.equals("replaceAll")) {
			editRichText.undoBuffer.push(new Point(curFindPosLocal.x,curFindPosLocal.y), new TextLine(text,editRichText.fontSize), command, addedInfo, listOfFindPos, listOfReplacePos);
		}
	}
	
	
	/** NoneCaseSensitive일때 replaceAll에서 replace하는 위치들과 원래 텍스트들을 백업하기 위해 호출한다.*/
	public static void backUpForUndo_replace(EditRichText editRichText, String command, boolean isAll, boolean isForward, boolean isScopeAll, boolean isCaseSensitive, 
			boolean isWholeWord, Point curFindPosLocal, String textToFind, String textToReplaceWith,
			ArrayList listOfFindPos, ArrayList listOfReplacePos, ArrayListString listOfTextForNoneCaseSensitive) {
		String addedInfo;
		if (!isScopeAll) {
			addedInfo = isAll + "-" + isForward + "-" + isScopeAll + "-" + isCaseSensitive + "-" +
				isWholeWord + "-" + 
				editRichText.selectP1.x + "-" + editRichText.selectP1.y + "-" + editRichText.selectP2.x + "-" + editRichText.selectP2.y;
		}
		else {
			addedInfo = isAll + "-" + isForward + "-" + isScopeAll + "-" + isCaseSensitive + "-" +
					isWholeWord;
		}
		String text = textToFind + "-" + textToReplaceWith;
		/*if (command.equals("replace")) {			
			editRichText.undoBuffer.push(new Point(curFindPosLocal.x,curFindPosLocal.y), new TextLine(text,editRichText.fontSize), command, addedInfo);
		}
		else*/ if (command.equals("replaceAll")) {
			editRichText.undoBuffer.push(new Point(curFindPosLocal.x,curFindPosLocal.y), new TextLine(text,editRichText.fontSize), command, addedInfo, listOfFindPos, listOfReplacePos, listOfTextForNoneCaseSensitive);
		}
	}
	
	
	
	/**replace-find 에서만 호출한다. 즉 isAll 은 false 이다. 
	 * 검색한 위치(findP1,findP2)와 대체한 위치(replacePosP1,replacePosP2) 모두를 백업한다.
	 * String addedInfo = isAll + "-" + isForward + "-" + isScopeAll + "-" + isCaseSensitive + "-" +
	 * 		isWholeWord;
	 * String text = textToFind + "-" + textToReplaceWith;
	 * editRichText.cursorPos = curFindPosLocal(검색시작위치)
	 * command = "replace"/"replaceAll" */
	public static void backUpForUndo_replace(EditRichText editRichText, String command, boolean isAll, boolean isForward, boolean isScopeAll, boolean isCaseSensitive, 
			boolean isWholeWord, 
			Point findP1, Point findP2, Point replacePosP1, Point replacePosP2, 
			String textToFind, String textToReplaceWith) {
		String addedInfo;
		if (!isScopeAll) {
			addedInfo = isAll + "-" + isForward + "-" + isScopeAll + "-" + isCaseSensitive + "-" +
				isWholeWord + "-" + 
				editRichText.selectP1.x + "-" + editRichText.selectP1.y + "-" + editRichText.selectP2.x + "-" + editRichText.selectP2.y + "-" +
				findP1.x + "-" + findP1.y + "-" + findP2.x + "-" + findP2.y + "-" +
				replacePosP1.x + "-" + replacePosP1.y + "-" + replacePosP2.x + "-" + replacePosP2.y;
		}
		else {
			addedInfo = isAll + "-" + isForward + "-" + isScopeAll + "-" + isCaseSensitive + "-" +
				isWholeWord + "-" +
				findP1.x + "-" + findP1.y + "-" + findP2.x + "-" + findP2.y + "-" +
				replacePosP1.x + "-" + replacePosP1.y + "-" + replacePosP2.x + "-" + replacePosP2.y;
		}
		TextLine text = new TextLine(textToFind + "-" + textToReplaceWith, editRichText.fontSize);
		if (command.equals("replace")) {			
			editRichText.undoBuffer.push(new Point(replacePosP1.x,replacePosP1.y), text, command, addedInfo);
		}
		else if (command.equals("replaceAll")) {
			editRichText.undoBuffer.push(new Point(replacePosP1.x,replacePosP1.y), text, command, addedInfo);
		}
	}
	
	
	/** replace-find에서 none-case sentivie일 때 호출한다.*/
	public static void backUpForUndo_replace(EditRichText editRichText, String command, boolean isAll, boolean isForward, boolean isScopeAll, boolean isCaseSensitive, 
			boolean isWholeWord, 
			Point findP1, Point findP2, Point replacePosP1, Point replacePosP2, 
			String textToFind, String textToReplaceWith, ArrayListString listOfTextForNoneCaseSensitive) {
		String addedInfo;
		if (!isScopeAll) {
			addedInfo = isAll + "-" + isForward + "-" + isScopeAll + "-" + isCaseSensitive + "-" +
				isWholeWord + "-" + 
				editRichText.selectP1.x + "-" + editRichText.selectP1.y + "-" + editRichText.selectP2.x + "-" + editRichText.selectP2.y + "-" +
				findP1.x + "-" + findP1.y + "-" + findP2.x + "-" + findP2.y + "-" +
				replacePosP1.x + "-" + replacePosP1.y + "-" + replacePosP2.x + "-" + replacePosP2.y;
		}
		else {
			addedInfo = isAll + "-" + isForward + "-" + isScopeAll + "-" + isCaseSensitive + "-" +
				isWholeWord + "-" +
				findP1.x + "-" + findP1.y + "-" + findP2.x + "-" + findP2.y + "-" +
				replacePosP1.x + "-" + replacePosP1.y + "-" + replacePosP2.x + "-" + replacePosP2.y;
		}
		TextLine text = new TextLine(textToFind + "-" + textToReplaceWith, editRichText.fontSize);
		if (command.equals("replace")) {			
			editRichText.undoBuffer.push(new Point(replacePosP1.x,replacePosP1.y), text, command, addedInfo, listOfTextForNoneCaseSensitive);
		}
	}
	
	
	/** redo를 undo한다.*/
	public static void backUpForUndo(EditRichText editRichText, String charA, RedoBufferOfEditRichText.Pair pair) {
		if (charA.equals("cut")) {			
		
			
			editRichText.copiedText = (TextLine) pair.addedInfo;
			
			//int firstLine = editRichText.selectIndices[0].y;
			int firstLine = pair.cursorPos.y;
			int numOfNewLineChar = editRichText.getNumOfNewLineChar(editRichText.copiedText) + 1;
			//int editRichText.getNumOfLinesInText(firstLine, 0, numOfNewLineChar);
			TextLine newText = editRichText.TextArrayToText(firstLine, 0, numOfNewLineChar);
			Object addedInfo = editRichText.copiedText;
			editRichText.undoBuffer.push(new Point(pair.cursorPos.x,firstLine), newText, charA, addedInfo);
		
		}
		else if (charA.equals("paste")) {	// paste를 undo
			TextLine textForBackup = editRichText.TextArrayToText(pair.cursorPos.y, 0, 1);
			//Object addedInfo = editRichText.copiedText;
			editRichText.undoBuffer.push(new Point(pair.cursorPos.x,pair.cursorPos.y), textForBackup, charA, 
					pair.addedInfo);
		}
		
		else if (charA.equals(Edit.BackspaceChar) || charA.equals(Edit.NewLineChar) || charA.equals(Edit.DeleteChar))
		{
			if (charA.equals(Edit.BackspaceChar)) {
				if (pair.isSelecting) {
					
					// 선택된 줄들을 백업한다.
					TextLine textForBackup = (TextLine) pair.addedInfo;
					editRichText.undoBuffer.push(new Point(pair.cursorPos.x, pair.cursorPos.y), textForBackup, charA, pair.p2, pair.isSelecting);
				}
				else {
					if (pair.cursorPos.x!=0) { // undo에서 일반적인 경우로 취급
						TextLine textForBackup = editRichText.TextArrayToText(pair.cursorPos.y, 0, 1);
						editRichText.undoBuffer.push(new Point(pair.cursorPos.x,pair.cursorPos.y), textForBackup, charA);
					}
					else {
						int prevLine;
						if (pair.cursorPos.y>0) {
							prevLine = pair.cursorPos.y-1;
							if (editRichText.textArray[prevLine].count>0 && editRichText.textArray[prevLine].characters[editRichText.textArray[prevLine].count-1].charA=='\n') {
								// 이전라인과 현재라인 모두를 백업한다.(0열에서 '\n'이 지워지는 back키만)
								TextLine newText=null;
								newText = editRichText.TextArrayToText(prevLine, pair.cursorPos.x, 2);
								editRichText.undoBuffer.push(new Point(pair.cursorPos.x,pair.cursorPos.y), newText, charA);
								//editRichText.setTextMultiLine(editRichText.cursorPos.y, newText, -1);
							}
							else {	// scrollMode가 VScroll일 때만 
								TextLine textForBackup = editRichText.TextArrayToText(prevLine, 0, 1);
								editRichText.undoBuffer.push(new Point(pair.cursorPos.x, prevLine), textForBackup, charA);
							}
						}					
					}
				}
			}
			else if (charA.equals(Edit.DeleteChar)) {
				if (pair.isSelecting) {
					/*Point p1 = editRichText.selectP1, p2 = editRichText.selectP2;
					if (editRichText.selectP1.y>=editRichText.selectP2.y) {
						p1 = editRichText.selectP2;
						p2 = editRichText.selectP1;
					}
					// 선택된 줄들을 백업한다.
					CodeString textForBackup = editRichText.TextArrayToText(p1.y, 0, p2.y-p1.y+1);
					editRichText.undoBuffer.push(new Point(p1.x, p1.y), textForBackup, charA, null, editRichText.isSelecting);*/
					
					// 선택된 줄들을 백업한다.
					TextLine textForBackup = (TextLine) pair.addedInfo;
					editRichText.undoBuffer.push(new Point(pair.cursorPos.x, pair.cursorPos.y), textForBackup, charA, pair.p2, pair.isSelecting);
					
				}
				else {
					if (pair.cursorPos.x<editRichText.textArray[pair.cursorPos.y].count) {
						if (editRichText.textArray[pair.cursorPos.y].characters[pair.cursorPos.x].charA!='\n') { // undo에서 일반적인 경우로 취급
							//editRichText.undoBuffer.push(editRichText.cursorPos, editRichText.textArray[editRichText.cursorPos.y]);
							TextLine textForBackup = editRichText.TextArrayToText(pair.cursorPos.y, 0, 1);
							editRichText.undoBuffer.push(new Point(pair.cursorPos.x,pair.cursorPos.y), textForBackup, charA);
						}
						else {	// 마지막열에서 '\n'이 지워지는 delete키만
							// 현재라인과 다음라인 모두를 백업한다.
							TextLine newText=null;
							newText = editRichText.TextArrayToText(pair.cursorPos.y, pair.cursorPos.x, 2);
							editRichText.undoBuffer.push(new Point(pair.cursorPos.x,pair.cursorPos.y), newText, charA);
						}
					}
					else {	// 지우는 문자가 '\n'이 아닌 경우, undo에서 일반적인 경우로 취급
						TextLine textForBackup = editRichText.TextArrayToText(pair.cursorPos.y, 0, 1);
						editRichText.undoBuffer.push(new Point(pair.cursorPos.x,pair.cursorPos.y), textForBackup, charA);
					}
				}
			}
			else if (charA.equals(Edit.NewLineChar)) {
				// 현재라인과 다음라인 모두를 백업한다.
				TextLine newText=null;
				newText = editRichText.TextArrayToText(pair.cursorPos.y, pair.cursorPos.x, 1);
				editRichText.undoBuffer.push(new Point(pair.cursorPos.x,pair.cursorPos.y), newText, charA);
			}
		}//else if (charA.equals(Edit.BackspaceChar) || charA.equals(Edit.NewLineChar) || charA.equals(Edit.DeleteChar))
		
		else  { // 일반적인 경우
			TextLine textForBackup = editRichText.TextArrayToText(pair.cursorPos.y, 0, 1);
			editRichText.undoBuffer.push(new Point(editRichText.cursorPos.x,pair.cursorPos.y), textForBackup, charA);
		}
	}
	
	/** 사용자가 키를 조작하기 전의 상태를 backup한다. 
	 * undoBuffer의 cursorPos는 다음과 같다. 
	 * cut:(0,editRichText.selectIndices[0].y),  
	 * 0열 back:(editRichText.cursorPos.x,editRichText.cursorPos.y),  
	 * 마지막열 delete:(editRichText.cursorPos.x,editRichText.cursorPos.y), 
	 * 일반적인경우:(editRichText.cursorPos.x,editRichText.cursorPos.y)*/
	public static void backUpForUndo(EditRichText editRichText, String charA, boolean isReplaceChar) {
		if (charA.equals("cut")) {
						
			int i;
			int y;
			int startX, endX;
			for (i=0; i<editRichText.selectIndicesCountForCopy; i+=2) {
				y = editRichText.selectIndices[i].y;
				startX = editRichText.selectIndices[i].x;
				endX = editRichText.selectIndices[i+1].x;
				TextLine lineCopiedText = editRichText.textArray[y].subTextLine(startX, endX+1);
				editRichText.copiedText.insert(lineCopiedText.toCharacterArray(),0,
					editRichText.copiedText.count,lineCopiedText.count);
			}
			
			int firstLine = editRichText.selectIndices[0].y;
			int numOfNewLineChar = editRichText.getNumOfNewLineChar(editRichText.copiedText) + 1;
			//int editRichText.getNumOfLinesInText(firstLine, 0, numOfNewLineChar);
			TextLine newText = editRichText.TextArrayToText(firstLine, 0, numOfNewLineChar);
			Object addedInfo = editRichText.copiedText;
			editRichText.undoBuffer.push(new Point(editRichText.selectIndices[0].x,firstLine), newText, charA, addedInfo);
			//Log.d("backUpForUndo", "newText:"+newText);
		
		}
		else if (charA.equals("paste")) {	// paste를 undo
			TextLine textForBackup = editRichText.TextArrayToText(editRichText.cursorPos.y, 0, 1);
			Object addedInfo = editRichText.copiedText;
			editRichText.undoBuffer.push(new Point(editRichText.cursorPos.x,editRichText.cursorPos.y), textForBackup, charA, 
					addedInfo);
		}
		
		else if (charA.equals(Edit.DeleteChar) || charA.equals(Edit.NewLineChar) ||
				charA.equals(Edit.BackspaceChar)) {
			if (charA.equals(Edit.BackspaceChar)) {
				if (editRichText.isSelecting) {
					Point p1 = editRichText.selectP1, p2 = editRichText.selectP2;
					if (editRichText.selectP1.y>editRichText.selectP2.y) { // swapping
						p1 = editRichText.selectP2;
						p2 = editRichText.selectP1;
					}
					else if (editRichText.selectP1.y==editRichText.selectP2.y) {
						if (editRichText.selectP1.x>editRichText.selectP2.x) {
							// swapping, y가 같을땐 x를 비교해서 작은쪽이 p1이 된다.
							p1 = editRichText.selectP2;
							p2 = editRichText.selectP1;
						}
					}
					// 선택된 줄들을 백업한다.
					TextLine textForBackup = editRichText.TextArrayToText(p1.y, 0, p2.y-p1.y+1);
					//editRichText.undoBuffer.push(new Point(p1.x, p2.y), textForBackup);
					//editRichText.undoBuffer.push(new Point(p1.x, p1.y), textForBackup, charA, null, editRichText.isSelecting);
					editRichText.undoBuffer.push(p1, textForBackup, charA, p2, editRichText.isSelecting);
				}
				else {
					if (editRichText.cursorPos.x!=0) { // undo에서 일반적인 경우로 취급
						TextLine textForBackup = editRichText.TextArrayToText(editRichText.cursorPos.y, 0, 1);
						editRichText.undoBuffer.push(new Point(editRichText.cursorPos.x,editRichText.cursorPos.y), textForBackup, charA);
					}
					else {
						int prevLine;
						if (editRichText.cursorPos.y>0) {
							prevLine = editRichText.cursorPos.y-1;
							if (editRichText.textArray[prevLine].count>0 && editRichText.textArray[prevLine].characters[editRichText.textArray[prevLine].count-1].charA=='\n') {
								// 이전라인과 현재라인 모두를 백업한다.(0열에서 '\n'이 지워지는 back키만)
								TextLine newText=null;
								newText = editRichText.TextArrayToText(prevLine, editRichText.cursorPos.x, 2);
								editRichText.undoBuffer.push(new Point(editRichText.cursorPos.x,editRichText.cursorPos.y), newText, charA);
								//editRichText.setTextMultiLine(editRichText.cursorPos.y, newText, -1);
							}
							else {	// scrollMode가 VScroll일 때만 
								TextLine textForBackup = editRichText.TextArrayToText(prevLine, 0, 1);
								editRichText.undoBuffer.push(new Point(editRichText.cursorPos.x, prevLine), textForBackup, charA);
							}
						}					
					}
				}
			}
			else if (charA.equals(Edit.DeleteChar)) {
				if (editRichText.isSelecting) {
					Point p1 = editRichText.selectP1, p2 = editRichText.selectP2;
					if (editRichText.selectP1.y>editRichText.selectP2.y) { // swapping
						p1 = editRichText.selectP2;
						p2 = editRichText.selectP1;
					}
					else if (editRichText.selectP1.y==editRichText.selectP2.y) {
						if (editRichText.selectP1.x>editRichText.selectP2.x) {
							// swapping, y가 같을땐 x를 비교해서 작은쪽이 p1이 된다.
							p1 = editRichText.selectP2;
							p2 = editRichText.selectP1;
						}
					}
					// 선택된 줄들을 백업한다.
					TextLine textForBackup = editRichText.TextArrayToText(p1.y, 0, p2.y-p1.y+1);
					//editRichText.undoBuffer.push(new Point(p1.x, p2.y), textForBackup);
					//editRichText.undoBuffer.push(new Point(p1.x, p1.y), textForBackup, charA, null, editRichText.isSelecting);
					editRichText.undoBuffer.push(p1, textForBackup, charA, p2, editRichText.isSelecting);
				}
				else {
					if (editRichText.cursorPos.x<editRichText.textArray[editRichText.cursorPos.y].count) {
						if (editRichText.textArray[editRichText.cursorPos.y].characters[editRichText.cursorPos.x].charA!='\n') { // undo에서 일반적인 경우로 취급
							//editRichText.undoBuffer.push(editRichText.cursorPos, editRichText.textArray[editRichText.cursorPos.y]);
							TextLine textForBackup = editRichText.TextArrayToText(editRichText.cursorPos.y, 0, 1);
							editRichText.undoBuffer.push(new Point(editRichText.cursorPos.x,editRichText.cursorPos.y), textForBackup, charA);
						}
						else {	// 마지막열에서 '\n'이 지워지는 delete키만
							// 현재라인과 다음라인 모두를 백업한다.
							TextLine newText=null;
							newText = editRichText.TextArrayToText(editRichText.cursorPos.y, editRichText.cursorPos.x, 2);
							editRichText.undoBuffer.push(new Point(editRichText.cursorPos.x,editRichText.cursorPos.y), newText, charA);
						}
					}
					else {	// 지우는 문자가 '\n'이 아닌 경우, undo에서 일반적인 경우로 취급
						TextLine textForBackup = editRichText.TextArrayToText(editRichText.cursorPos.y, 0, 1);
						editRichText.undoBuffer.push(new Point(editRichText.cursorPos.x,editRichText.cursorPos.y), textForBackup, charA);
					}
				}
			}
			else if (charA.equals(Edit.NewLineChar)) {
				// 현재라인과 다음라인 모두를 백업한다.
				TextLine newText=null;
				newText = editRichText.TextArrayToText(editRichText.cursorPos.y, editRichText.cursorPos.x, 1);
				editRichText.undoBuffer.push(new Point(editRichText.cursorPos.x,editRichText.cursorPos.y), newText, charA);
			}
		}//else if (charA.equals(Edit.DeleteChar) || charA.equals(Edit.NewLineChar) ||
		//charA.equals(Edit.BackspaceChar)) 
		/*else  {
			TextLine textForBackup = editRichText.TextArrayToText(editRichText.cursorPos.y, 0, 1);
			editRichText.undoBuffer.push(new Point(editRichText.cursorPos.x,editRichText.cursorPos.y), textForBackup);
		}*/
		else {// 일반적인 경우
			if (isReplaceChar) {
				TextLine textForBackup = editRichText.TextArrayToText(editRichText.cursorPos.y, 0, 1);
				editRichText.undoBuffer.push(new Point(editRichText.cursorPos.x,editRichText.cursorPos.y), textForBackup, charA);
			}
			else {
				TextLine textForBackup = editRichText.TextArrayToText(editRichText.cursorPos.y, 0, 1);
				editRichText.undoBuffer.push(new Point(editRichText.cursorPos.x,editRichText.cursorPos.y), textForBackup, charA);
			}
		}
	}
	
	
	
	/** String addedInfo = isAll + "-" + isForward + "-" + isScopeAll + "-" + isCaseSensitive + "-" +
	 *		isWholeWord;
	 *	String text = textToFind + "-" + textToReplaceWith;
	 *	editRichText.cursorPos = curFindPosLocal(검색시작위치)
	 *	command = "replace"/"replaceAll" */
	public static void undo_replace(EditRichText editRichText, UndoBufferOfEditRichText.Pair pair) {
		String command = pair.command;
		
		
		int index = pair.text.toString().indexOf("-");
		String textToFind = pair.text.subTextLine(0, index).toString();
		String textToReplaceWith = pair.text.subTextLine(index+1, pair.text.count).toString();
		
		String addedInfo = (String)pair.addedInfo;
		int index0 = addedInfo.indexOf("-", 0);		
		boolean isAll = Boolean.parseBoolean(addedInfo.substring(0, index0));
		
		int index1 = addedInfo.indexOf("-", index0+1);
		boolean isForward = Boolean.parseBoolean(addedInfo.substring(index0+1, index1));
		
		int index2 = addedInfo.indexOf("-", index1+1);
		boolean isScopeAll = Boolean.parseBoolean(addedInfo.substring(index1+1, index2));
		
		int index3 = addedInfo.indexOf("-", index2+1);
		boolean isCaseSensitive = Boolean.parseBoolean(addedInfo.substring(index2+1, index3));
		
		
		// replace-find(isAll==false) 시 backupForUndo_replace()에서 addedInfo의 구조
		/************************************************************************************ 
		 * if (isScopeAll==false) {
			addedInfo = isAll + "-" + isForward + "-" + isScopeAll + "-" + isCaseSensitive + "-" +
				isWholeWord + "-" + 
				editRichText.selectP1.x + "-" + editRichText.selectP1.y + "-" + editRichText.selectP2.x + "-" + editRichText.selectP2.y + "-" +
				findP1.x + "-" + findP1.y + "-" + findP2.x + "-" + findP2.y + "-" +
				replacePosP1.x + "-" + replacePosP1.y + "-" + replacePosP2.x + "-" + replacePosP2.y;;
		}
		else {
			addedInfo = isAll + "-" + isForward + "-" + isScopeAll + "-" + isCaseSensitive + "-" +
				isWholeWord + "-" +
				findP1.x + "-" + findP1.y + "-" + findP2.x + "-" + findP2.y + "-" +
				replacePosP1.x + "-" + replacePosP1.y + "-" + replacePosP2.x + "-" + replacePosP2.y;;
		}*****************************************************************************************/
		
		// replaceAll(isAll==true)일 경우 addedInfo의 구조
		/******************************************************************************************
		 * String addedInfo;
		if (isScopeAll==false) {
			addedInfo = isAll + "-" + isForward + "-" + isScopeAll + "-" + isCaseSensitive + "-" +
				isWholeWord + "-" + 
				editRichText.selectP1.x + "-" + editRichText.selectP1.y + "-" + editRichText.selectP2.x + "-" + editRichText.selectP2.y;
		}
		else {
			addedInfo = isAll + "-" + isForward + "-" + isScopeAll + "-" + isCaseSensitive + "-" +
				isWholeWord;
		}************************************************************************************************/
		
		int selectP1_x, selectP1_y, selectP2_x, selectP2_y = 0;
		int findP1_x, findP1_y, findP2_x, findP2_y = 0;
		int replacePosP1_x=0, replacePosP1_y=0, replacePosP2_x=0, replacePosP2_y=0;
		if (!isScopeAll) {
			int index4 = addedInfo.indexOf("-", index3+1);
			
			int index5 = addedInfo.indexOf("-", index4+1);
			selectP1_x = Integer.parseInt(addedInfo.substring(index4+1, index5));
			
			int index6 = addedInfo.indexOf("-", index5+1);
			selectP1_y = Integer.parseInt(addedInfo.substring(index5+1, index6));
			
			int index7 = addedInfo.indexOf("-", index6+1);
			selectP2_x = Integer.parseInt(addedInfo.substring(index6+1, index7));
			
			int index8 = addedInfo.indexOf("-", index7+1);
			selectP2_y = Integer.parseInt(addedInfo.substring(index7+1));
			
			editRichText.selectP1.x = selectP1_x;
			editRichText.selectP1.y = selectP1_y;
			editRichText.selectP2.x = selectP2_x;
			editRichText.selectP2.y = selectP2_y;
			
			if (!isAll) {// isScopeAll==false, isAll==false
				int index9 = addedInfo.indexOf("-", index8+1);
				findP1_x = Integer.parseInt(addedInfo.substring(index8+1, index9));
				
				int index10 = addedInfo.indexOf("-", index9+1);
				findP1_y = Integer.parseInt(addedInfo.substring(index9+1, index10));
				
				int index11 = addedInfo.indexOf("-", index10+1);
				findP2_x = Integer.parseInt(addedInfo.substring(index10+1, index11));				
				
				int index12 = addedInfo.indexOf("-", index11+1);
				findP2_y = Integer.parseInt(addedInfo.substring(index11+1, index12));
				
				int index13 = addedInfo.indexOf("-", index12+1);
				replacePosP1_x = Integer.parseInt(addedInfo.substring(index12+1, index13));
				
				int index14 = addedInfo.indexOf("-", index13+1);
				replacePosP1_y = Integer.parseInt(addedInfo.substring(index13+1, index14));
				
				int index15 = addedInfo.indexOf("-", index14+1);
				replacePosP2_x = Integer.parseInt(addedInfo.substring(index14+1, index15));				
				
			
				replacePosP2_y = Integer.parseInt(addedInfo.substring(index15+1));
				
				editRichText.findP1.x = findP1_x;
				editRichText.findP1.y = findP1_y;
				editRichText.findP2.x = findP2_x;
				editRichText.findP2.y = findP2_y;
			}
			
		}			
		else { // isScopeAll==true
			if (!isAll) {// isScopeAll==true, isAll==false
				int index4 = addedInfo.indexOf("-", index3+1);
				
				int index9 = addedInfo.indexOf("-", index4+1);
				findP1_x = Integer.parseInt(addedInfo.substring(index4+1, index9));
				
				int index10 = addedInfo.indexOf("-", index9+1);
				findP1_y = Integer.parseInt(addedInfo.substring(index9+1, index10));
				
				int index11 = addedInfo.indexOf("-", index10+1);
				findP2_x = Integer.parseInt(addedInfo.substring(index10+1, index11));				
				
				int index12 = addedInfo.indexOf("-", index11+1);
				findP2_y = Integer.parseInt(addedInfo.substring(index11+1, index12));
				
				int index13 = addedInfo.indexOf("-", index12+1);
				replacePosP1_x = Integer.parseInt(addedInfo.substring(index12+1, index13));
				
				int index14 = addedInfo.indexOf("-", index13+1);
				replacePosP1_y = Integer.parseInt(addedInfo.substring(index13+1, index14));
				
				int index15 = addedInfo.indexOf("-", index14+1);
				replacePosP2_x = Integer.parseInt(addedInfo.substring(index14+1, index15));				
				
				
				replacePosP2_y = Integer.parseInt(addedInfo.substring(index15+1));
				
				editRichText.findP1.x = findP1_x;
				editRichText.findP1.y = findP1_y;
				editRichText.findP2.x = findP2_x;
				editRichText.findP2.y = findP2_y;
			}
			else {// isScopeAll==true, isAll==true
			}
		}
		
		if (command.equals("replace")) {			
			
			// replace-find시에 대체한 위치를 textToFind로 바꾼다.
			if (isCaseSensitive) {
				editRichText.findReplace.replaceCommon(isAll, new Point(replacePosP1_x, replacePosP1_y), 
					new Point(replacePosP2_x, replacePosP2_y), 
					textToReplaceWith, textToFind);
			}
			else {
				ArrayListString listTextForNoneCaseSensitive = pair.listOfTextForNoneCaseSensitive;
				if (listTextForNoneCaseSensitive.count>0) {
					String originText = listTextForNoneCaseSensitive.getItem(0);
					editRichText.findReplace.replaceCommon(isAll, new Point(replacePosP1_x, replacePosP1_y), 
						new Point(replacePosP2_x, replacePosP2_y), 
						textToReplaceWith, originText);
				}
			}
			editRichText.moveToCursorPos(editRichText.cursorPos.x, editRichText.cursorPos.y);
		}
		else {
			if (!isScopeAll) editRichText.isSelecting = true;
			
			
			// 일반적인 경우
			
			// 여기에서 find()를 해서 textToReplaceWith을 다시 검색하면 잘못된 것이고
			// pair.listOfReplacePos을 사용해야 한다.
			
			ArrayList listReplacePos = pair.listOfReplacePos;
			
			ArrayListString listTextForNoneCaseSensitive = pair.listOfTextForNoneCaseSensitive;
			
			// 아래 for문에서 editRichText.listFindPos가 바뀌므로 백업해두었다가
			// undoBuffer에 넣는다.
			ArrayList listBackupForReplacePos = editRichText.findReplace.getClone(listReplacePos);
			int count = listReplacePos.count;
			int i;
			for (i=0; i<count; i+=2) {
				Point p1 = (Point)listReplacePos.list[i];
				Point p2 = (Point)listReplacePos.list[i+1];
				
				if (isCaseSensitive) {
					editRichText.findReplace.replaceCommon(isAll, p1, p2, textToReplaceWith, textToFind);
				}
				else {
					String originText = listTextForNoneCaseSensitive.getItem(i);
					editRichText.findReplace.replaceCommon(isAll, p1, p2, textToReplaceWith, originText);
				}
				
				if (!isScopeAll) {
					editRichText.findReplace.changeSelectP1AndP2(true, isForward, p1, p2, textToFind);
				}
				editRichText.findReplace.changeListFindPos(listReplacePos, i+2, p1.y, textToReplaceWith, textToFind);
			}
			
			pair.listOfReplacePos = listBackupForReplacePos;
			
			if (!isScopeAll) {
				FunctionOfEditRichText.makeSelectIndices(editRichText, true, editRichText.selectP1, editRichText.selectP2);
			}
			
			editRichText.setVScrollPos();
			editRichText.setVScrollBar(true);
			if (editRichText.scrollMode==ScrollMode.Both) {
				editRichText.setHScrollPos();
				editRichText.setHScrollBar(true);	
			}
			
			editRichText.isFound = false;
		}//replaceAll
	}
	
	
	
	
	
	
	
	/** back, delete, enter키 등의 조작을 무효로 한다.*/
	public static void undo(EditRichText editRichText) {
		if (editRichText.isReadOnly) return;
		
		if (editRichText.undoBuffer.buffer.count>0) {
			editRichText.isModified = true;
			
			editRichText.isSelecting = false;
			
			UndoBufferOfEditRichText.Pair pair = editRichText.undoBuffer.pop();
			TextLine newLineText = pair.text;
			
			String command = pair.command;
			
			if (!command.equals("replace") && !command.equals("replaceAll")) {
				if (!pair.isSelecting) {
					RedoOfEditRichText.backUpForRedo(editRichText, command, newLineText, pair.cursorPos, pair.addedInfo);
				}
				else {
					RedoOfEditRichText.backUpForRedo(editRichText, command, newLineText, pair.cursorPos, newLineText, pair.isSelecting, (Point)pair.addedInfo);
				}
			}
			else {//if (command.equals("replace") || command.equals("replaceAll")) {
				
			}
			
			if (command.equals("replace") || command.equals("replaceAll")) {
				undo_replace(editRichText, pair);
				// 커서위치는 undo(), undo_replace(), redo(), redo_replace(), replace()에서 
				// 설정하지 않고 replaceCommon()에서 공통적으로 설정한다. 
				// 위 함수들이 공통적으로 replaceCommon()을 호출하기 때문이다.
				
				// replace, replaceAll만 여기에서 백업한다.
				RedoOfEditRichText.backUpForRedo(editRichText, command, newLineText, pair.cursorPos, pair.isSelecting, pair.addedInfo, 
						pair.listOfFindPos, pair.listOfReplacePos);
			}
			else if (command.equals("cut")) {
				int numToDelete = editRichText.getNumOfLinesInText(pair.cursorPos.y, 1);
				int numOfNewLineChar = editRichText.getNumOfNewLineChar(newLineText) + 1;
				if (newLineText.count>0 && newLineText.characters[newLineText.count-1].charA=='\n') numOfNewLineChar--;
				
				editRichText.setTextMultiLine(pair.cursorPos.y, newLineText, numToDelete, numOfNewLineChar);
				Point relativeCursorPos = editRichText.getRelativeCursorPos(pair.cursorPos, (TextLine)pair.addedInfo);
				editRichText.cursorPos.x = relativeCursorPos.x;
				editRichText.cursorPos.y = relativeCursorPos.y;
			}
			else if (command.equals("paste")) {
				TextLine addedInfo = (TextLine)pair.addedInfo;
				// numOfNewLineCharToDelete = 선택텍스트의 newLineChar개수 + 원래의 1줄
				int numOfNewLineCharToDelete = editRichText.getNumOfNewLineChar(addedInfo) + 1;
				int numToDelete = editRichText.getNumOfLinesInText(pair.cursorPos.y, numOfNewLineCharToDelete);
				int numOfNewLineChar = editRichText.getNumOfNewLineChar(newLineText);
				editRichText.setTextMultiLine(pair.cursorPos.y, newLineText, numToDelete, numOfNewLineChar);
				editRichText.cursorPos.x = pair.cursorPos.x;
				editRichText.cursorPos.y = pair.cursorPos.y;
			}
			else if (command.equals(Edit.BackspaceChar) || command.equals(Edit.NewLineChar) || command.equals(Edit.DeleteChar))
			{
				// backspace(0열)와 delete(마지막열)는 모두 특별하게 '\n'을 제거한 경우이거나, 그렇지 않은 경우이다.
				if (command.equals(Edit.BackspaceChar)) {
					if (pair.isSelecting) {
						int numOfNewLineChar = editRichText.getNumOfNewLineChar(newLineText) + 1;
						if (newLineText.count>0 && newLineText.characters[newLineText.count-1].charA=='\n') {
							numOfNewLineChar--;
						}
						// pair.cursorPos.y는 p1의 y이다.
						editRichText.setTextMultiLine(pair.cursorPos.y, newLineText, 1, numOfNewLineChar);
						
						Point p2 = (Point) pair.addedInfo;
						editRichText.cursorPos.x = p2.x+1;
						editRichText.cursorPos.y = p2.y;
					}
					else {
						// newLineText가 두줄이면 0열에서 back키를 누른 경우이고
						// 한줄이면 그렇지 않은 경우
						// pair.cursorPos.y-1은 이전 라인(prevLine)을 의미한다.
						if (editRichText.scrollMode==ScrollMode.Both) { // 2줄이 1줄로 바뀐경우이므로 1줄을 삭제하고 원래의 2줄로 바꾼다.
							if (pair.cursorPos.x==0) {// 2줄이 1줄로 바뀐경우이므로 1줄을 삭제하고 원래의 2줄로 바꾼다.
								int numOfNewLineChar = editRichText.getNumOfNewLineChar(newLineText) + 1;
								if (newLineText.count>0 && newLineText.characters[newLineText.count-1].charA=='\n') {
									numOfNewLineChar--;
								}
								if (pair.cursorPos.y==0) {
									editRichText.setTextMultiLine(pair.cursorPos.y, newLineText, 1, numOfNewLineChar);
								}
								else {
									editRichText.setTextMultiLine(pair.cursorPos.y-1, newLineText, 1, numOfNewLineChar);
								}
								editRichText.cursorPos.x = 0;
								editRichText.cursorPos.y = pair.cursorPos.y;
							}
							else {
								int numOfNewLineChar = editRichText.getNumOfNewLineChar(newLineText) + 1;
								if (newLineText.count>0 && newLineText.characters[newLineText.count-1].charA=='\n') {
									numOfNewLineChar--;
								}
								editRichText.setTextMultiLine(pair.cursorPos.y, newLineText, 1, numOfNewLineChar);
								editRichText.cursorPos.x = pair.cursorPos.x;
								editRichText.cursorPos.y = pair.cursorPos.y;
							}
						}
						else { 
							int numToDelete = editRichText.getNumOfLinesInText(pair.cursorPos.y-1, 1);
							int numOfNewLineChar = editRichText.getNumOfNewLineChar(newLineText);
							editRichText.setTextMultiLine(pair.cursorPos.y-1, newLineText, numToDelete, numOfNewLineChar);
						}
					}
					
				}
				else if (command.equals(Edit.DeleteChar)) {
					if (pair.isSelecting) { // Both일 경우에만
						int numOfNewLineChar = editRichText.getNumOfNewLineChar(newLineText) + 1;
						if (newLineText.count>0 && newLineText.characters[newLineText.count-1].charA=='\n') {
							numOfNewLineChar--;
						}
						editRichText.setTextMultiLine(pair.cursorPos.y, newLineText, 1, numOfNewLineChar);
						
						Point p2 = (Point) pair.addedInfo;
						editRichText.cursorPos.x = p2.x+1;
						editRichText.cursorPos.y = p2.y;
					}
					else {
						if (editRichText.scrollMode==ScrollMode.Both) { // 2줄이 1줄로 바뀐경우이므로 1줄을 삭제하고 원래의 2줄로 바꾼다.
							int numOfNewLineChar = editRichText.getNumOfNewLineChar(newLineText) + 1;
							if (newLineText.count>0 && newLineText.characters[newLineText.count-1].charA=='\n') {
								numOfNewLineChar--;
							}
							
							int cursorPosX, cursorPosY;
							if (pair.cursorPos.x<=editRichText.textArray[pair.cursorPos.y].count-1 && 
								editRichText.textArray[pair.cursorPos.y].characters[pair.cursorPos.x].charA!='\n') {
								cursorPosX = pair.cursorPos.x+1;
								cursorPosY = pair.cursorPos.y;
							}
							else {
								cursorPosX = pair.cursorPos.x;
								cursorPosY = pair.cursorPos.y;
							}
							
							editRichText.setTextMultiLine(pair.cursorPos.y, newLineText, 1, numOfNewLineChar);
							
							editRichText.cursorPos.x = cursorPosX;
							editRichText.cursorPos.y = cursorPosY;
						}
						else {
							int numToDelete = editRichText.getNumOfLinesInText(pair.cursorPos.y, 1);
							int numOfNewLineChar = editRichText.getNumOfNewLineChar(newLineText);
							editRichText.setTextMultiLine(pair.cursorPos.y, newLineText, numToDelete, numOfNewLineChar);
						}
					}
				}
				else if (command.equals(Edit.NewLineChar)) { // 1줄이 2줄로 바뀐경우
					if (editRichText.scrollMode==ScrollMode.Both) {
						int numOfNewLineChar = editRichText.getNumOfNewLineChar(newLineText);
						editRichText.setTextMultiLine(pair.cursorPos.y, newLineText, 2, numOfNewLineChar);
					}
					else {
						int numToDelete = editRichText.getNumOfLinesInText(pair.cursorPos.y, 2);
						int numOfNewLineChar = editRichText.getNumOfNewLineChar(newLineText);
						editRichText.setTextMultiLine(pair.cursorPos.y, newLineText, numToDelete, numOfNewLineChar);
					}
					editRichText.cursorPos.x = pair.cursorPos.x;
					editRichText.cursorPos.y = pair.cursorPos.y;
				}
			}//else if (command.equals(Edit.BackspaceChar) || command.equals(Edit.NewLineChar) || command.equals(Edit.DeleteChar))
			else {	// 일반적인 경우			
				editRichText.setTextMultiLine(pair.cursorPos.y, newLineText, -1, 1);
				editRichText.cursorPos.x = pair.cursorPos.x;
				editRichText.cursorPos.y = pair.cursorPos.y;
			}
			editRichText.moveToCursorPos(editRichText.cursorPos.x, editRichText.cursorPos.y);
		}
	}
}
