package com.gsoft.common.gui.edittext;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;

import com.gsoft.common.CommonGUI;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.Font;
import com.gsoft.common.Font.FontFamily;
import com.gsoft.common.IO;
import com.gsoft.common.IO_types.TextFormat;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.util.Array;

public class EditRichText_Types {
	public static class Character {
		public Bitmap bitmap;
		String filename;	// context에 저장된 파일이름
		
		public char charA;
		public float size;
		int charColor = Color.BLACK;
		
		public void setCharColor(int color) {
			this.charColor = color;
		}
		boolean isUnderLine;
		boolean isBold;
		boolean isItalic;
		public Typeface typeface = Typeface.DEFAULT;		
		String typefaceName;
		//FontFamily fontFamily = Font.fromString(typefaceName);
		
		public void write(OutputStream os, TextFormat format) throws IOException {			
			if (filename==null) {
				IO.writeString(os, "null", format, true, true);
				IO.writeChar(os, charA, format, true);
				IO.writeFloat(os, size, true);
				IO.writeInt(os, charColor, true);
				IO.writeBoolean(os, isUnderLine);
				IO.writeBoolean(os, isBold);
				IO.writeBoolean(os, isItalic);
				if (typefaceName==null) IO.writeString(os, "null", format, true, true);
				else IO.writeString(os, typefaceName, format, true, true);
				
			}
			else {
				IO.writeString(os, filename, format, true, true);
				if (bitmap!=null) {
					/*if (Control.CurrentSystem.equals(Control.CurrentSystemIsAndroid)) {
						bitmap.compress(Bitmap.CompressFormat.PNG, 70, os);
					}
					else {*/
						try {
							String imagePath = Common_Settings.DownloadedImageDirPath;
							File dir = new File(imagePath);
							dir.mkdir();
							File imageFile = new File(imagePath + File.separator + filename); 
							FileOutputStream out = new FileOutputStream(imageFile);
							bitmap.compress(Bitmap.CompressFormat.PNG, 70, out);
							out.close();
						}catch(Exception e) {
							e.printStackTrace();
						}
					//}
				}
				//IO.writeFloat(os, size);
				
			}
			
			
		}
		
		public static Character read(InputStream is, TextFormat format) {
			try{
			Character c = new Character();
			c.filename = IO.readString(is, format).getItems();			
			if (c.filename.equals("null")) c.filename = null;
			
			if (c.filename==null) {
				c.charA = IO.readCharUTF16(is, format, true);
				c.size = IO.readFloat(is, true);
				c.charColor = IO.readInt(is, true);
				c.isUnderLine = IO.readBoolean(is);
				c.isBold = IO.readBoolean(is);
				c.isItalic = IO.readBoolean(is);
				c.typefaceName = IO.readString(is, format).getItems();
				if (c.typefaceName.equals("null")) {
					c.typefaceName = "Default";
					c.typeface = Typeface.DEFAULT;
				}
				else {
					FontFamily family = Font.fromString(c.typefaceName);
					if (c.isBold && c.isItalic)
						c.typeface = Font.getTypeface(family, true, true);
					else if (c.isBold)
						c.typeface = Font.getTypeface(family, true, false);
					else if (c.isItalic)
						c.typeface = Font.getTypeface(family, false, true);
					else
						c.typeface = Font.getTypeface(family, false, false);
					
				}
			}
			else {
				try {
					/*if (Control.CurrentSystem.equals(Control.CurrentSystemIsAndroid)) {
						c.bitmap = BitmapFactory.decodeStream(is);
						c.size = c.bitmap.getHeight();
					}
					else {*/
						String imagePath = Common_Settings.DownloadedImageDirPath;
						File imageFile = new File(imagePath + File.separator + c.filename); 
						FileInputStream in = new FileInputStream(imageFile);
						c.bitmap = BitmapFactory.decodeStream(in);
						c.size = c.bitmap.getHeight();
						in.close();
					//}
				}catch(OutOfMemoryError e) {
					throw e;
				}
			}
			
			return c;
			}catch(Exception e) {
				e.printStackTrace();
				CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
				return null;
			}
		}
		
		// read, write 목적
		public Character() {
			//typeface = Control.typefaceDefault;
		}
		
		public Character(Bitmap bitmap, String filename) {
			this.bitmap = bitmap;
			this.filename = filename;
			size = bitmap.getHeight();
		}
		
		public Character(char charA, float size) {
			this.charA = charA;
			this.size = size;
		}
		
		public Character(Character c) {
			if (c.bitmap==null) {
				this.charA = c.charA;
				this.size = c.size;
				this.charColor = c.charColor;
				this.isUnderLine = c.isUnderLine;
				this.isBold = c.isBold;
				this.isItalic = c.isItalic;
				this.typeface = c.typeface;
				this.typefaceName = c.typefaceName;
			}
			else {
				this.bitmap = c.bitmap;
				this.filename = c.filename;
				this.size = c.size;
			}
		}
		
		public void allocate(Character c) {
			if (c.bitmap==null) {
				this.charA = c.charA;
				this.size = c.size;
				this.charColor = c.charColor;
				this.isUnderLine = c.isUnderLine;
				this.isBold = c.isBold;
				this.isItalic = c.isItalic;
				this.typeface = c.typeface;
				this.typefaceName = c.typefaceName;
			}
			else {
				this.bitmap = c.bitmap;
				this.filename = c.filename;
				this.size = c.size;
			}
		}
		
		public String toString() {
			char[] arg = {charA};
			String r = new String(arg);
			return r;
		}
		
		public boolean equals(Character c) {
			if (bitmap==null) {
				if (charA==c.charA && size==c.size)
					return true;
				return false;
			}
			else {
				return false;
			}
		}
		
		public boolean equals(char c) {
			if (charA==c)
				return true;
			return false;
		}
	}
	
	public static class TextLine {
		public Character[] characters;
		public int count;
		float lineHeight;
		float maxFontSize;
		//boolean maxFontSizeIsImage;
		
		float descent;
		float leading;
		
		static float physicalDescentRate = 0.28f;
		//static float logicalDescentRate = 0.25f;
		static float leadingRate = 0.05f;
		static float physicalDescentRate_Image = 0.1f;
		static float leadingRate_Image = 0.01f;
		static final int MaxCharCount = 100;
		
		public void write(OutputStream os, TextFormat format) throws IOException {
			int i;
			IO.writeInt(os, count, true);
			IO.writeFloat(os, lineHeight, true);
			IO.writeFloat(os, maxFontSize, true);
			for (i=0; i<count; i++) {
				characters[i].write(os, format);
			}
			
		}
		
		public static TextLine read(InputStream is, TextFormat format) {
			int i;
			TextLine textLine = new TextLine();			
			
			textLine.count = IO.readInt(is, true);
			textLine.lineHeight = IO.readFloat(is, true);
			textLine.maxFontSize = IO.readFloat(is, true);
			textLine.characters = new Character[textLine.count];  
			for (i=0; i<textLine.count; i++) {
				try {
					textLine.characters[i] = Character.read(is, format);
				}catch(OutOfMemoryError e) {
					throw e;
				}
			}
			
			return textLine;			
		}
		
		// read, write 목적
		public TextLine() {
			
		}
		
		public TextLine(Character[] characters, int count) {
			this.characters = characters;
			this.count = count;
			setLineHeight(30);
		}
		
		public TextLine(Character[] characters) {
			this.characters = characters;
			this.count = characters.length;
			setLineHeight(30);
		}
		
		public TextLine(int count, float size) {
			this.characters = new Character[count];
			int i;
			for (i=0; i<count; i++) {
				characters[i] = new Character((char)0, size);
			}
			this.count = count;
			//this.maxFontSize = size;
			setLineHeight(size);
		}
		
		public TextLine(int count) {
			this.characters = new Character[count];
			int i;
			for (i=0; i<count; i++) {
				characters[i] = new Character((char)0, 0);
			}
			this.count = count;
			setLineHeight(30);
		}
		
		public TextLine(String c, float size) {
			int i;
			if (c==null) c="";
			characters = new Character[c.length()];
			for (i=0; i<c.length(); i++) {
				characters[i] = new Character(c.charAt(i), size);
			}
			this.count = c.length();
			this.maxFontSize = size;
			setLineHeight(size);
		}
		
		public void reset() {
			count = 0;
		}
		
		/*public TextLine(char[] c, float size) {
			int i;
			if (c==null) c= new char[0];
			characters = new Character[c.length];
			for (i=0; i<c.length; i++) {
				characters[i] = new Character(c[i], size);
			}
			this.count = c.length;
			this.maxFontSize = size;
			setLineHeight(size);
		}*/
			
		public char[] toCharArray() {
			int i;
			char[] r = new char[count];
			for (i=0; i<count; i++) {
				r[i] = this.characters[i].charA;
			}
			return r;
		}
		
		public Character[] toCharacterArray() {
			int i;
			Character[] r = new Character[count];
			for (i=0; i<count; i++) {
				r[i] = new Character(this.characters[i]);
			}
			return r;
		}
	
		
		public String toString() {
			char[] charArray = this.toCharArray();
			return new String(charArray);
		}
		
		/**start포함, end미포함, 현재 스트링이 빈스트링일 경우 빈스트링 리턴*/
		public TextLine subTextLine(int start , int end) {
			//if (end-start<0) return null;	// 길이
			//if (start<0 || end<0) return null;
			if (this.count<=0) return new TextLine("", maxFontSize);
			TextLine r = new TextLine(end-start, maxFontSize);
			for (int i=start; i<end; i++) {
				r.characters[i-start] = this.characters[i];
			}
			r.setLineHeight(30);
			return r;
		}
		
		public boolean equals(String str) {
			if (this.count!=str.length()) return false;
			for (int i=0; i<str.length(); i++) {
				if (characters[i].charA!=str.charAt(i))
					return false;
			}
			return true;
		}
		
		public boolean equals(TextLine str) {
			if (this.count!=str.count) return false;
			for (int i=0; i<str.count; i++) {
				if (!characters[i].equals(str.characters[i]))
					return false;
			}
			return true;
		}
		
		void setLineHeight(float sizeWhenCountIsZero/*OrWhenElementIsOne*/) {
			if (count==0) {
				maxFontSize = sizeWhenCountIsZero;
				this.descent = maxFontSize*physicalDescentRate;
				this.leading = maxFontSize*leadingRate;
				this.lineHeight = maxFontSize + descent + leading;
				return;
			}
			int i;				
			maxFontSize = 0;
			this.descent = 0;
			this.leading = 0;
			float descent=0;
			float leading=0;
			for (i=0; i<count; i++) {
				float charSize = characters[i].size;
				if (characters[i].bitmap==null) {
					descent = charSize*physicalDescentRate;
					leading = charSize*leadingRate;
					if (this.descent<descent) this.descent = descent;
					if (this.leading<leading) this.leading = leading;
				}
				if (charSize>maxFontSize) {
					maxFontSize = charSize;						
				}
			}
			lineHeight = maxFontSize + this.descent + this.leading;
		}
		
		void add(Character c) {
			if (count==0) {
				characters = (Character[]) Array.Resize(characters, count+1);
			}
			else {
				if (count>=characters.length)
					characters = (Character[]) Array.Resize(characters, count+10);
			}
			//characters[count] = new Character(c);
			characters[count] = c;
			setLineHeight(c.size);
			count++;
		}
		
		/**startIndex포함, endIndex미포함*/
		public static float measureHeight(TextLine[] textArray, int startIndex, int endIndex) {
			int i;
			float r=0;
			for (i=startIndex; i<endIndex; i++)  {
				r += textArray[i].lineHeight;
			}
			return r;
		}
		
		public void resize(int len) {
			this.characters = Array.Resize(characters, len);
			if (count>len) count = len;			
		}
		
		public void insert(Character[] src, int srcIndex, int destIndex, int len) {
			try {
				characters = (Character[]) Array.InsertNoSpaceError(src, 0, characters, destIndex, len, this.count);
				count+=len;
			} catch (Exception e) {
				
				e.printStackTrace();
				CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
			}			
		}
		
		public void insert(int destIndex, TextLine str) {
			try {
				characters = (Character[]) Array.InsertNoSpaceError(str.characters, 0, characters, destIndex, str.count, this.count);
				count+=str.count;
			} catch (Exception e) {
				
				e.printStackTrace();
				CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
			}
		}
		
		public void delete(int startIndex, int len) {
			this.characters = Array.Delete(this.characters, 
					startIndex, len);
			count-=len;
		}
				
	}
}
