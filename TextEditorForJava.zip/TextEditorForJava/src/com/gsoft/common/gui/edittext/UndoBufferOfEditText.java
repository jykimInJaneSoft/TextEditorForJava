package com.gsoft.common.gui.edittext;

import android.graphics.Point;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListCodeString;
import com.gsoft.common.util.ArrayListString;
import com.gsoft.common.util.Util;

import com.gsoft.common.gui.edittext.EditText;
import com.gsoft.common.gui.edittext.Edit;

public class UndoBufferOfEditText {
	//EditText owner;
	
	public static class Pair {
		CodeString text;
		Point cursorPos;
		String command;
		Object addedInfo;
		public boolean isSelecting;
		/** ReplaceAll에서 빈 스트링("")으로 대체된 경우 null 이 아니다.
		 * replaceAll할때에 검색된 좌표들을 백업한다.*/
		ArrayList listOfFindPos;
		/** replaceAll할때에 replace된 좌표들을 백업한다.*/
		ArrayList listOfReplacePos;
		/**NoneCaseSensitive일때에 replace-find, replaceAll에서 원래 텍스트들을 백업한다.*/
		public ArrayListString listOfTextForNoneCaseSensitive;
	}
	ArrayListCodeString buffer = new ArrayListCodeString(50);
	private ArrayList arrayCursorPos = new ArrayList(50);
	private ArrayListString bufferCommand = new ArrayListString(50);
	private ArrayList arrayAddedInfo = new ArrayList(50);
	private ArrayList arrayIsSelecting = new ArrayList(50);
	private ArrayList arrayListOfFindPos = new ArrayList(50);
	private ArrayList arrayListOfReplacePos = new ArrayList(50);
	ArrayList arrayListOfTextForNoneCaseSensitive = new ArrayList(50);
	
	
	public UndoBufferOfEditText() {
		
	}
	void reset() {
		buffer.reset();
		arrayCursorPos.reset();
		bufferCommand.destroy();
		arrayAddedInfo.reset();
		arrayIsSelecting.reset();
		arrayListOfFindPos.reset();
		arrayListOfReplacePos.reset();
		arrayListOfTextForNoneCaseSensitive.reset();
	}
	/*void push(Point cursorPos, CodeString text) {
		buffer.add(text);
		arrayCursorPos.add(cursorPos);
		bufferCommand.add("");
		arrayAddedInfo.add(null);
		arrayIsSelecting.add(null);
		arrayMessage.add(null);
	}*/
	void push(Point cursorPos, CodeString text, String charA) {
		buffer.add(text);
		arrayCursorPos.add(cursorPos);
		bufferCommand.add(charA);
		arrayAddedInfo.add(null);
		arrayIsSelecting.add(null);
		arrayListOfFindPos.add(null);
		arrayListOfReplacePos.add(null);
		arrayListOfTextForNoneCaseSensitive.add(null);
	}
	void push(Point cursorPos, CodeString text, String charA, Object addedInfo) {
		buffer.add(text);
		arrayCursorPos.add(cursorPos);
		bufferCommand.add(charA);
		arrayAddedInfo.add(addedInfo);
		arrayIsSelecting.add(null);
		arrayListOfFindPos.add(null);
		arrayListOfReplacePos.add(null);
		arrayListOfTextForNoneCaseSensitive.add(null);
	}
	void push(Point cursorPos, CodeString text, String charA, Object addedInfo, ArrayListString listTextForNoneCaseSensitive) {
		buffer.add(text);
		arrayCursorPos.add(cursorPos);
		bufferCommand.add(charA);
		arrayAddedInfo.add(addedInfo);
		arrayIsSelecting.add(null);
		arrayListOfFindPos.add(null);
		arrayListOfReplacePos.add(null);
		this.arrayListOfTextForNoneCaseSensitive.add(listTextForNoneCaseSensitive);
	}
	void push(Point cursorPos, CodeString text, String charA, Object addedInfo, boolean isSelecting) {
		buffer.add(text);
		arrayCursorPos.add(cursorPos);
		bufferCommand.add(charA);
		arrayAddedInfo.add(addedInfo);
		arrayIsSelecting.add(new Boolean(isSelecting));
		arrayListOfFindPos.add(null);
		arrayListOfReplacePos.add(null);
		arrayListOfTextForNoneCaseSensitive.add(null);
	}
	void push(Point cursorPos, CodeString text, String charA, Object addedInfo, boolean isSelecting, ArrayList listFindPos) {
		buffer.add(text);
		arrayCursorPos.add(cursorPos);
		bufferCommand.add(charA);
		arrayAddedInfo.add(addedInfo);
		arrayIsSelecting.add(new Boolean(isSelecting));
		arrayListOfFindPos.add(listFindPos);
		arrayListOfReplacePos.add(null);
		arrayListOfTextForNoneCaseSensitive.add(null);
	}
	void push(Point cursorPos, CodeString text, String charA, Object addedInfo, boolean isSelecting, ArrayList listFindPos, ArrayList listReplacePos) {
		buffer.add(text);
		arrayCursorPos.add(cursorPos);
		bufferCommand.add(charA);
		arrayAddedInfo.add(addedInfo);
		arrayIsSelecting.add(new Boolean(isSelecting));
		arrayListOfFindPos.add(listFindPos);
		arrayListOfReplacePos.add(listReplacePos);
		arrayListOfTextForNoneCaseSensitive.add(null);
	}
	void push(Point cursorPos, CodeString text, String charA, Object addedInfo, boolean isSelecting, ArrayList listFindPos, ArrayList listReplacePos, ArrayListString arrayListOfTextForNoneCaseSensitive) {
		buffer.add(text);
		arrayCursorPos.add(cursorPos);
		bufferCommand.add(charA);
		arrayAddedInfo.add(addedInfo);
		arrayIsSelecting.add(new Boolean(isSelecting));
		arrayListOfFindPos.add(listFindPos);
		arrayListOfReplacePos.add(listReplacePos);
		this.arrayListOfTextForNoneCaseSensitive.add(arrayListOfTextForNoneCaseSensitive);
		
	}
	UndoBufferOfEditText.Pair pop() {
		UndoBufferOfEditText.Pair pair = new UndoBufferOfEditText.Pair();
		pair.text = buffer.getItem(buffer.count-1);
		pair.cursorPos = (Point)arrayCursorPos.getItem(arrayCursorPos.count-1);			
		String command = bufferCommand.getItem(bufferCommand.count-1);
		pair.command = command;
		pair.addedInfo = arrayAddedInfo.getItem(arrayAddedInfo.count-1);
		Boolean b = (Boolean) arrayIsSelecting.getItem(arrayIsSelecting.count-1);
		if (b!=null) {
			pair.isSelecting = b.booleanValue();
		}
		pair.listOfFindPos = (ArrayList) arrayListOfFindPos.getItem(arrayListOfFindPos.count-1);
		pair.listOfReplacePos = (ArrayList) arrayListOfReplacePos.getItem(arrayListOfReplacePos.count-1);
		pair.listOfTextForNoneCaseSensitive = (ArrayListString) arrayListOfTextForNoneCaseSensitive.getItem(arrayListOfTextForNoneCaseSensitive.count-1);
		buffer.count--;
		arrayCursorPos.count--;
		bufferCommand.count--;
		arrayAddedInfo.count--;
		arrayIsSelecting.count--;
		arrayListOfFindPos.count--;
		arrayListOfReplacePos.count--;
		arrayListOfTextForNoneCaseSensitive.count--;
		return pair;
	}
	
	void showUndoBuffer(EditText owner) {
		CodeString message = new CodeString("<UndoBuffer Stack>\ncount   buffer(the contents to change) : command(Input key)\n(bottom)\n", 
				Common_Settings.keywordColor);
		int i;
		for (i=0; i<bufferCommand.count; i++) {	
			String buffer = this.buffer.getItem(i).str;
			String command = bufferCommand.getItem(i);
			if (command.equals(Edit.NewLineChar)) command = "Enter";
			else if (command.equals(Edit.BackspaceChar)) command = "Backspace";
			else if (command.equals(Edit.DeleteChar)) command = "Delete";
			else if (command.equals("")) command = "Char key";
			
			CodeString line = new CodeString(Util.getLineOffset(i), 
					Common_Settings.varUseColor);
			
			if (command.equals("cut") || command.equals("paste")) {
				line = line.concate(new CodeString(buffer + " : " + command +"(Selected)\n", 
						Common_Settings.textColor));
			}
			else if (command.equals("Backspace") || command.equals("Enter") ||
					command.equals("Delete")) {
				boolean isSelecting = false;
				Object s = arrayIsSelecting.getItem(i);
				// s가 null이면 isSelecting은 false이다.
				if (s!=null) isSelecting = ((Boolean)s).booleanValue();
				if (!isSelecting) {
					line = line.concate(new CodeString(buffer + " : " + command +"\n", 
							Common_Settings.textColor));
				}
				else {
					Point selectP1 = (Point) arrayCursorPos.getItem(i);
					Point selectP2 = (Point) arrayAddedInfo.getItem(i);
					String select = "(" + selectP1.x + "," + selectP1.y + ")" + ", " + 
							"(" + selectP2.x + "," + selectP2.y + ")";
					line = line.concate(new CodeString(buffer + " : " + command + " (" + select + " selected)\n", 
							Common_Settings.textColor));
				}				
			}//else if (command.equals("Backspace") || command.equals("Enter") ||
			// command.equals("Delete")) {
			else {	// 일반적인 문자 key 입력	
				if (command.equals("replace") || command.equals("replaceAll")) {
					int indexOfSeparator = buffer.indexOf('-');
					if (indexOfSeparator!=-1) {
						String backupText = buffer.substring(0, indexOfSeparator);
						String replaceWith = buffer.substring(indexOfSeparator+1, buffer.length());
						line = line.concate(new CodeString(backupText + " : " + command +
								"("+backupText + " with " + replaceWith+")\n", 
								Common_Settings.textColor));
					}
				}
				else {
					line = line.concate(new CodeString(buffer + " : " + command +"\n", 
							Common_Settings.textColor));
				}
			}
			message = message.concate(line);
		}
		message = message.concate(new CodeString("(top)\n", Common_Settings.keywordColor));
		owner.textView.setText(0, message);
		owner.textView.setHides(false);
	}
}