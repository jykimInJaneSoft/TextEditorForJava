package com.gsoft.common.gui.edittext;

import android.graphics.Color;

import com.gsoft.common.ColorEx;
import com.gsoft.common.R.R;
import com.gsoft.common.Sizing.Rectangle;
import com.gsoft.common.Sizing.Size;
import com.gsoft.common.gui.Control;
import com.gsoft.common.gui.FindReplaceDialog;
import com.gsoft.common.gui.FontSizeDialog;
import com.gsoft.common.gui.Menu.MenuType;
import com.gsoft.common.gui.MenuWithClosable;

public class Edit {
	
	public static final String NewLineChar = "\n";
	public static final String BackspaceChar = "%"+"bk";
	public static final String DeleteChar = "%"+"dl";
	public static final String TabChar = "\t";
	
	/**들여쓰기시 넣는 ' '의 공간 크기*/
	public static int SpaceSize = 3;
	/**Tab키의 ' '의 공간의 배율, 현재는 3배크기*/
	public static float TabScale = 3;
	
	public static int selectColor;
	public static int foundColor;
	public static int cursorColor;
	
	public static void setBackColor(int backColor) {
		selectColor = Color.YELLOW;
		foundColor = Color.LTGRAY;
		cursorColor = ColorEx.darkerOrLighter(Color.RED, -50);
	}
	
	/** 모든 EditText인스턴스들이 menuFunction를 공유한다.*/
	public static MenuWithClosable menuFunction;
	
	static final String[] Menu_Function = { 
		"Undo(Ctrl+z)", "Redo(Ctrl+y)", 
		"Copy(Ctrl+c)", "Cut(Ctrl+x)", "Paste(Ctrl+v)", 
		"Find/Replace(Ctrl+f)", 
		"Select all(Ctrl+a)",
		"Show UndoBuffer", "Show RedoBuffer"
	};
	
	
	/** 모든 EditText인스턴스들이 menuFontSize를 공유한다.*/
	public static MenuWithClosable menuFontSize;
	
	/** 모든 EditText인스턴스들이 menuFontSize를 공유한다.*/
	public static FontSizeDialog fontSizeDialog;
	
	static final String[] Menu_FontSize = { 
		"1%", "2%", "2.5%", "3%", "4%", "5%", "6%", "7%", "9%", "11%", "13%", Control.res.getString(R.string.font_others)
	};
	
	public static FindReplaceDialog findReplaceDialog;
	
	public static char[] find_separators = {' ', ';', ',', ':', '.', '\t', '\n', 
			'+', '-' , '*', '/', '\'', '\"', '<', '>', '=', 
			'{', '}', '(', ')', '[', ']'};
	
	/** 모든 EditText들이 공유하는 FindReplaceDialog를 가운데에 생성하거나 영역을 바꿔준다.*/
	public static void createFindReplaceDialog(boolean changeBounds) {
		//if (Edit.findReplaceDialog!=null) return;
		int w = (int) (Control.view.getWidth()*0.7f);
		int h = (int) (Control.view.getHeight()*0.6f);
		int x = Control.view.getWidth()/2 - w/2;
		int y = 0;
		Rectangle bounds = new Rectangle(x, y, w, h);
		if (!changeBounds) {
			if (Edit.findReplaceDialog==null) {
				Edit.findReplaceDialog = new FindReplaceDialog(bounds);
			}
		}
		else {
			Edit.findReplaceDialog.changeBounds(bounds);
		}
	}
	
	/** 모든 EditText들이 공유하는 MenuFontSize를 가운데에 생성하거나 영역을 바꿔준다.*/
	public static void createMenuFontSize(boolean changeBounds) {
		//if (Edit.menuFontSize!=null) return;
		int viewWidth = Control.view.getWidth();
		int viewHeight = Control.view.getHeight();
		int x, y;
		int width=(int) (viewWidth*0.4f);
		int height=(int) (viewHeight*0.7f);
		x = viewWidth/2-width/2;
		y = viewHeight/2-height/2;
		Rectangle boundsMenuFontSize = new Rectangle(x,y,width,height);
		if (!changeBounds) {
			if (Edit.menuFontSize==null) {
				Edit.menuFontSize = new MenuWithClosable("MenuFontSize", boundsMenuFontSize, 
						MenuType.Vertical, Control.view, Edit.Menu_FontSize, new Size(3,3), true, null);
			}
		}
		else {
			Edit.menuFontSize.changeBounds(boundsMenuFontSize);
		}
	}
	
	/** 모든 EditText들이 공유하는 MenuFunction를 가운데에 생성하거나 영역을 바꿔준다.*/
	public static void createMenuFunction(boolean changeBounds) {
		//if (Edit.menuFunction!=null) return;
		int viewWidth = Control.view.getWidth();
		int viewHeight = Control.view.getHeight();
		int x, y;
		int width=(int) (viewWidth*0.4f);
		int height=(int) (viewHeight*0.7f);
		x = viewWidth/2-width/2;
		y = viewHeight/2-height/2;
		Rectangle boundsMenuFunction = new Rectangle(x,y,width,height);
		if (!changeBounds) {
			if (Edit.menuFunction==null) {
				Edit.menuFunction = new MenuWithClosable("menuFunction", boundsMenuFunction, 
						MenuType.Vertical, Control.view, Edit.Menu_Function, new Size(3,3), true, null);
			}
		}
		else {
			Edit.menuFunction.changeBounds(boundsMenuFunction);
		}
	}
	
	
	/** 모든 EditText들이 공유하는 FontSizeDialog를 가운데에 생성하거나 영역을 바꿔준다.*/
	public static void createFontSizeDialog(boolean changeBounds) {
		//if (Edit.fontSizeDialog!=null) return;
		int w = (int) (Control.view.getWidth()*0.7f);
		int h = (int) (Control.view.getHeight()*0.4f);
		int x = Control.view.getWidth()/2 - w/2;
		int y = 0;
		Rectangle bounds = new Rectangle(x,y,w,h);
		if (!changeBounds) {
			if (Edit.fontSizeDialog==null) {
				Edit.fontSizeDialog = new FontSizeDialog(Control.view, bounds);
			}
		}
		else {
			try {
			Edit.fontSizeDialog.changeBounds(bounds);
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public static enum ScrollMode {		
		VScroll,
		Both
	}
	
	
}//public static class Edit {