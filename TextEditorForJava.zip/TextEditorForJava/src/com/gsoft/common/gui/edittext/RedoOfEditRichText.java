package com.gsoft.common.gui.edittext;

import android.graphics.Point;

import com.gsoft.common.gui.edittext.Edit.ScrollMode;
import com.gsoft.common.gui.edittext.EditRichText_Types.TextLine;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListString;

import com.gsoft.common.gui.edittext.EditRichText;
import com.gsoft.common.gui.edittext.RedoBufferOfEditRichText;
import com.gsoft.common.gui.edittext.FindReplaceOfEditRichText;
import com.gsoft.common.gui.edittext.UndoOfEditRichText;
import com.gsoft.common.gui.edittext.FunctionOfEditRichText;
import com.gsoft.common.gui.edittext.Edit;

public class RedoOfEditRichText {
	protected static final String NewLineChar = Edit.NewLineChar;
	protected static final String BackspaceChar = Edit.BackspaceChar;
	protected static final String DeleteChar = Edit.DeleteChar;
	static final String TabChar = Edit.TabChar;
	
	/** replace, replaceAll에서 호출한다.
	 * undo에서 undo를 하기 전의 상태(redo실행결과)를 backup한다. 후에 redo에서 복원한다.*/
	public static void backUpForRedo(EditRichText editRichText, String charA, TextLine textOfBackupForUndo, Point undoPos, boolean isSelecting, Object addedInfo, 
			ArrayList listFindPos, ArrayList listReplacePos) {
		editRichText.redoBuffer.push(undoPos, textOfBackupForUndo, charA, addedInfo, editRichText.isSelecting, null, listFindPos, listReplacePos);
	}
	
	/** 선택줄일때만 undo()에서 호출한다.<br>
	 * undo에서 undo를 하기 전의 상태(redo실행결과)를 backup한다. 후에 redo에서 복원한다.*/
	public static void backUpForRedo(EditRichText editRichText, String charA, TextLine textOfBackupForUndo, Point undoPos, Object addedInfo, boolean isSelecting, Point p2) {
		if (editRichText.isSelecting) {
			if (charA.equals(Edit.BackspaceChar)) {	// 0열에서 '\n'이 지워지는 back키만
				TextLine newText=null;
				newText = editRichText.TextArrayToText(undoPos.y, undoPos.x, 1);
				editRichText.redoBuffer.push(new Point(undoPos.x,undoPos.y), newText, charA, addedInfo, true, p2);
			}
			else if (charA.equals(Edit.DeleteChar)) { // 마지막열에서 '\n'이 지워지는 delete키만
				TextLine newText=null;
				newText = editRichText.TextArrayToText(undoPos.y, undoPos.x, 1);
				editRichText.redoBuffer.push(new Point(undoPos.x,undoPos.y), newText, charA, addedInfo, true, p2);
			}
			else if (charA.equals(Edit.NewLineChar)) {
				TextLine newText=null;
				newText = editRichText.TextArrayToText(undoPos.y, undoPos.x, 1);
				backUpForRedo(editRichText, charA, newText, undoPos, addedInfo);
			}
			else { // 선택을 하고 문자키를 눌렀을때
				backUpForRedo(editRichText, charA, textOfBackupForUndo, undoPos, addedInfo);
			}
		}
		else {
			backUpForRedo(editRichText, charA, textOfBackupForUndo, undoPos, addedInfo);
		}
	}
	
	
	/** undo에서 undo를 하기 전의 상태(redo실행결과)를 backup한다. 후에 redo에서 복원한다.*/
	public static void backUpForRedo(EditRichText editRichText, String charA, TextLine textOfBackupForUndo, Point undoPos, Object addedInfo) {
		if (charA==null) return;
		
		if (charA.equals("cut")) {
			TextLine newText=null;
			newText = editRichText.TextArrayToText(undoPos.y, undoPos.x, 1);
			editRichText.redoBuffer.push(new Point(undoPos.x,undoPos.y), newText, charA, addedInfo);
			
		}
		else if (charA.equals("paste")) {
			TextLine strAddedInfo = (TextLine)addedInfo;
			// numOfNewLineChar = 선택텍스트의 newLineChar개수 + 원래의 1줄
			int numOfNewLineChar = editRichText.getNumOfNewLineChar(strAddedInfo) + 1;
			TextLine newText=null;
			newText = editRichText.TextArrayToText(undoPos.y, undoPos.x, numOfNewLineChar);
			editRichText.redoBuffer.push(new Point(undoPos.x,undoPos.y), newText, charA, addedInfo);
			
		}
		else if (charA.equals("replace") || charA.equals("replaceAll")) {
			editRichText.redoBuffer.push(new Point(undoPos.x,undoPos.y), textOfBackupForUndo, charA, addedInfo);
			
		}
		
		else if (charA.equals(Edit.DeleteChar) || charA.equals(Edit.NewLineChar) ||
				charA.equals(Edit.BackspaceChar))
		{
			if (charA.equals(Edit.BackspaceChar)) {	// 0열에서 '\n'이 지워지는 back키만
				if (undoPos.x==0) {
					TextLine newText=null;
					if (undoPos.y==0) {
						newText = editRichText.TextArrayToText(undoPos.y, undoPos.x, 1);
						editRichText.redoBuffer.push(new Point(undoPos.x,undoPos.y), newText, charA);
					}
					else {
						newText = editRichText.TextArrayToText(undoPos.y-1, undoPos.x, 1);
						editRichText.redoBuffer.push(new Point(undoPos.x,undoPos.y), newText, charA);
					}
				}
				else { // 일반적인 경우
					TextLine newText=null;
					newText = editRichText.TextArrayToText(undoPos.y, undoPos.x, 1);
					editRichText.redoBuffer.push(new Point(undoPos.x,undoPos.y), newText, charA);				
				}
			}
			else if (charA.equals(Edit.DeleteChar)) { // 마지막열에서 '\n'이 지워지는 delete키만
				TextLine newText=null;
				newText = editRichText.TextArrayToText(undoPos.y, undoPos.x, 1);
				editRichText.redoBuffer.push(new Point(undoPos.x,undoPos.y), newText, charA);
			}
			else if (charA.equals(Edit.NewLineChar)) {
				TextLine newText=null;
				newText = editRichText.TextArrayToText(undoPos.y, undoPos.x, 2);
				editRichText.redoBuffer.push(new Point(undoPos.x,undoPos.y), newText, charA);
			}
		}//else if (charA.equals(Edit.DeleteChar) || charA.equals(Edit.NewLineChar) ||
		//charA.equals(Edit.BackspaceChar))
		
		else  {	// 일반적인 경우
			TextLine newText=null;
			newText = editRichText.TextArrayToText(undoPos.y, undoPos.x, 1);
			editRichText.redoBuffer.push(new Point(undoPos.x,undoPos.y), newText, charA);
		}
	}
	
	
	public static void redo_replace(EditRichText editRichText, RedoBufferOfEditRichText.Pair pair) {
		String command = pair.command;
		
		Point curFindPosLocal = pair.cursorPos;
		
		int index = pair.text.toString().indexOf("-");
		String textToFind = pair.text.subTextLine(0, index).toString();
		String textToReplaceWith = pair.text.subTextLine(index+1, pair.text.count).toString();
		
		String addedInfo = (String)pair.addedInfo;
		int index0 = addedInfo.indexOf("-", 0);		
		boolean isAll = Boolean.parseBoolean(addedInfo.substring(0, index0));
		
		int index1 = addedInfo.indexOf("-", index0+1);
		boolean isForward = Boolean.parseBoolean(addedInfo.substring(index0+1, index1));
		
		int index2 = addedInfo.indexOf("-", index1+1);
		boolean isScopeAll = Boolean.parseBoolean(addedInfo.substring(index1+1, index2));
		
		int index3 = addedInfo.indexOf("-", index2+1);
		boolean isCaseSensitive = Boolean.parseBoolean(addedInfo.substring(index2+1, index3));
		
		boolean isWholeWord;
		
		// replace-find(isAll==false) 시 backupForUndo_replace()에서 addedInfo의 구조
		/************************************************************************************ 
		 * if (isScopeAll==false) {
			addedInfo = isAll + "-" + isForward + "-" + isScopeAll + "-" + isCaseSensitive + "-" +
				isWholeWord + "-" + 
				editRichText.selectP1.x + "-" + editRichText.selectP1.y + "-" + editRichText.selectP2.x + "-" + editRichText.selectP2.y + "-" +
				editRichText.findP1.x + "-" + editRichText.findP1.y + "-" + editRichText.findP2.x + "-" + editRichText.findP2.y + "-" +
				replacePosP1.x + "-" + replacePosP1.y + "-" + replacePosP2.x + "-" + replacePosP2.y;;
		}
		else {
			addedInfo = isAll + "-" + isForward + "-" + isScopeAll + "-" + isCaseSensitive + "-" +
				isWholeWord + "-" +
				editRichText.findP1.x + "-" + editRichText.findP1.y + "-" + editRichText.findP2.x + "-" + editRichText.findP2.y + "-" +
				replacePosP1.x + "-" + replacePosP1.y + "-" + replacePosP2.x + "-" + replacePosP2.y;;
		}*****************************************************************************************/
		
		// replaceAll(isAll==true)일 경우 addedInfo의 구조
		/******************************************************************************************
		 * String addedInfo;
		if (isScopeAll==false) {
			addedInfo = isAll + "-" + isForward + "-" + isScopeAll + "-" + isCaseSensitive + "-" +
				isWholeWord + "-" + 
				editRichText.selectP1.x + "-" + editRichText.selectP1.y + "-" + editRichText.selectP2.x + "-" + editRichText.selectP2.y;
		}
		else {
			addedInfo = isAll + "-" + isForward + "-" + isScopeAll + "-" + isCaseSensitive + "-" +
				isWholeWord;
		}************************************************************************************************/
		
		
		int selectP1_x, selectP1_y, selectP2_x, selectP2_y = 0;
		int findP1_x, findP1_y, findP2_x, findP2_y = 0;
		int replacePosP1_x=0, replacePosP1_y=0, replacePosP2_x=0, replacePosP2_y=0;
		if (!isScopeAll) {
			int index4 = addedInfo.indexOf("-", index3+1);
			isWholeWord = Boolean.parseBoolean(addedInfo.substring(index3+1, index4));
			
			int index5 = addedInfo.indexOf("-", index4+1);
			selectP1_x = Integer.parseInt(addedInfo.substring(index4+1, index5));
			
			int index6 = addedInfo.indexOf("-", index5+1);
			selectP1_y = Integer.parseInt(addedInfo.substring(index5+1, index6));
			
			int index7 = addedInfo.indexOf("-", index6+1);
			selectP2_x = Integer.parseInt(addedInfo.substring(index6+1, index7));
			
			int index8 = addedInfo.indexOf("-", index7+1);
			selectP2_y = Integer.parseInt(addedInfo.substring(index7+1));
			
			editRichText.selectP1.x = selectP1_x;
			editRichText.selectP1.y = selectP1_y;
			editRichText.selectP2.x = selectP2_x;
			editRichText.selectP2.y = selectP2_y;
			
			if (!isAll) {// isScopeAll==false, isAll==false
				int index9 = addedInfo.indexOf("-", index8+1);
				findP1_x = Integer.parseInt(addedInfo.substring(index8+1, index9));
				
				int index10 = addedInfo.indexOf("-", index9+1);
				findP1_y = Integer.parseInt(addedInfo.substring(index9+1, index10));
				
				int index11 = addedInfo.indexOf("-", index10+1);
				findP2_x = Integer.parseInt(addedInfo.substring(index10+1, index11));				
				
				int index12 = addedInfo.indexOf("-", index11+1);
				findP2_y = Integer.parseInt(addedInfo.substring(index11+1, index12));
				
				int index13 = addedInfo.indexOf("-", index12+1);
				replacePosP1_x = Integer.parseInt(addedInfo.substring(index12+1, index13));
				
				int index14 = addedInfo.indexOf("-", index13+1);
				replacePosP1_y = Integer.parseInt(addedInfo.substring(index13+1, index14));
				
				int index15 = addedInfo.indexOf("-", index14+1);
				replacePosP2_x = Integer.parseInt(addedInfo.substring(index14+1, index15));				
				
				replacePosP2_y = Integer.parseInt(addedInfo.substring(index15+1));
				
				editRichText.findP1.x = findP1_x;
				editRichText.findP1.y = findP1_y;
				editRichText.findP2.x = findP2_x;
				editRichText.findP2.y = findP2_y;
			}
			
		}			
		else { // isScopeAll==true
			if (!isAll) {// isScopeAll==true, isAll==false
				int index4 = addedInfo.indexOf("-", index3+1);
				isWholeWord = Boolean.parseBoolean(addedInfo.substring(index3+1, index4));
				
				int index9 = addedInfo.indexOf("-", index4+1);
				findP1_x = Integer.parseInt(addedInfo.substring(index4+1, index9));
				
				int index10 = addedInfo.indexOf("-", index9+1);
				findP1_y = Integer.parseInt(addedInfo.substring(index9+1, index10));
				
				int index11 = addedInfo.indexOf("-", index10+1);
				findP2_x = Integer.parseInt(addedInfo.substring(index10+1, index11));				
				
				int index12 = addedInfo.indexOf("-", index11+1);
				findP2_y = Integer.parseInt(addedInfo.substring(index11+1, index12));
				
				int index13 = addedInfo.indexOf("-", index12+1);
				replacePosP1_x = Integer.parseInt(addedInfo.substring(index12+1, index13));
				
				int index14 = addedInfo.indexOf("-", index13+1);
				replacePosP1_y = Integer.parseInt(addedInfo.substring(index13+1, index14));
				
				int index15 = addedInfo.indexOf("-", index14+1);
				replacePosP2_x = Integer.parseInt(addedInfo.substring(index14+1, index15));				
				
				replacePosP2_y = Integer.parseInt(addedInfo.substring(index15+1));
				
				editRichText.findP1.x = findP1_x;
				editRichText.findP1.y = findP1_y;
				editRichText.findP2.x = findP2_x;
				editRichText.findP2.y = findP2_y;
			}
			else {// isScopeAll==true, isAll==true
				isWholeWord = Boolean.parseBoolean(addedInfo.substring(index3+1));
			}
		}
		
		if (command.equals("replace")) {
			ArrayListString listOfTextForNoneCaseSensitive = null;
			if (!isCaseSensitive) {
				listOfTextForNoneCaseSensitive = 
						FindReplaceOfEditRichText.getListOfTextForNoneCaseSensitive(editRichText, editRichText.findP1, editRichText.findP2);
			}
			
			Point oldFindP1 = new Point(editRichText.findP1.x, editRichText.findP1.y);
			Point oldFindP2 = new Point(editRichText.findP2.x, editRichText.findP2.y);
			
			// replace-find시에 검색한 위치를 textToReplaceWith로 바꾼다.
			// editRichText.findP1, findP2는 대체한 위치가 된다.
			editRichText.findReplace.replaceCommon(isAll, editRichText.findP1, editRichText.findP2, textToFind, textToReplaceWith);
			
			if (isCaseSensitive) {
				UndoOfEditRichText.backUpForUndo_replace(editRichText, "replace", isAll, isForward, isScopeAll, isCaseSensitive, 
					isWholeWord, 
					oldFindP1, oldFindP2, 
					new Point(replacePosP1_x, replacePosP1_y), new Point(replacePosP2_x, replacePosP2_y), 
					textToFind, textToReplaceWith);
			}
			else {
				UndoOfEditRichText.backUpForUndo_replace(editRichText, "replace", isAll, isForward, isScopeAll, isCaseSensitive, 
						isWholeWord, 
						oldFindP1, oldFindP2, 
						new Point(replacePosP1_x, replacePosP1_y), new Point(replacePosP2_x, replacePosP2_y), 
						textToFind, textToReplaceWith, listOfTextForNoneCaseSensitive);
			}
			editRichText.moveToCursorPos(editRichText.cursorPos.x, editRichText.cursorPos.y);
		}
		else {//replaceAll
			
			ArrayList listFindPos = pair.listOfFindPos;
			ArrayList listReplacePos = pair.listOfReplacePos;
			
			ArrayListString listOfTextForNoneCaseSensitive = null;
			if (!isCaseSensitive) {
				listOfTextForNoneCaseSensitive = FindReplaceOfEditRichText.getListOfTextForNoneCaseSensitive(editRichText, listFindPos);
			}
			
			// 아래 for문에서 editRichText.listFindPos가 바뀌므로 백업해두었다가
			// undoBuffer에 넣는다.
			ArrayList listBackupForFindPos = editRichText.findReplace.getClone(listFindPos);
			int count = listReplacePos.count;
			int i;
			for (i=0; i<count; i+=2) {
				Point p1 = (Point)listFindPos.list[i];
				Point p2 = (Point)listFindPos.list[i+1];
				editRichText.findReplace.replaceCommon(isAll, p1, p2, textToFind, textToReplaceWith);
				
				if (!isScopeAll) {
					editRichText.findReplace.changeSelectP1AndP2(true, isForward, p1, p2, textToReplaceWith);
				}
				
				editRichText.findReplace.changeListFindPos(listFindPos, i+2, p1.y, textToFind, textToReplaceWith);
				
			}
			if (!isScopeAll) FunctionOfEditRichText.makeSelectIndices(editRichText, true, editRichText.selectP1, editRichText.selectP2);
			
			if (isCaseSensitive) {	
				UndoOfEditRichText.backUpForUndo_replace(editRichText, "replaceAll", isAll, isForward, isScopeAll, isCaseSensitive, 
					isWholeWord, curFindPosLocal, textToFind, textToReplaceWith, listBackupForFindPos, listReplacePos);
			}
			else {
				UndoOfEditRichText.backUpForUndo_replace(editRichText, "replaceAll", isAll, isForward, isScopeAll, isCaseSensitive, 
					isWholeWord, curFindPosLocal, textToFind, textToReplaceWith, listBackupForFindPos, listReplacePos, listOfTextForNoneCaseSensitive);
			}
			
			editRichText.setVScrollPos();
			editRichText.setVScrollBar(true);
			if (editRichText.scrollMode==ScrollMode.Both) {
				editRichText.setHScrollPos();
				editRichText.setHScrollBar(true);	
			}
			editRichText.isFound = false;
		}//replaceAll
		
	}
	
	/** undo를 한 뒤에 호출, back, delete, enter키의 조작 무효를 다시 실행한다.*/
	public static void redo(EditRichText editRichText) {
		if (editRichText.isReadOnly) return;
		
		if (editRichText.redoBuffer.buffer.count>0) {
			editRichText.isSelecting = false;
			
			editRichText.isModified = true;
			RedoBufferOfEditRichText.Pair pair = editRichText.redoBuffer.pop();
			TextLine newLineText = pair.text;
			
			String command = pair.command;
			
			if (command.equals("cut")) {
				UndoOfEditRichText.backUpForUndo(editRichText, command, pair);
				
				int numToDelete;
				//int numOfNewLineChar = ((Integer)pair.addedInfo).intValue();
				int numOfNewLineChar = editRichText.getNumOfNewLineChar((TextLine)pair.addedInfo) + 1;
				numToDelete = editRichText.getNumOfLinesInText(pair.cursorPos.y, numOfNewLineChar);
				editRichText.setTextMultiLine(pair.cursorPos.y, newLineText, numToDelete, 1);
				editRichText.cursorPos.x = pair.cursorPos.x;
				editRichText.cursorPos.y = pair.cursorPos.y;
			}
			else if (command.equals("paste")) {
				UndoOfEditRichText.backUpForUndo(editRichText, command, pair);
				
				int numToDelete;
				numToDelete = editRichText.getNumOfLinesInText(pair.cursorPos.y, 1);
				int numOfNewLineChar = editRichText.getNumOfNewLineChar(newLineText) + 1;
				if (newLineText.count>0 && newLineText.characters[newLineText.count-1].charA=='\n') {
					numOfNewLineChar--;
				}
				editRichText.setTextMultiLine(pair.cursorPos.y, newLineText, numToDelete, numOfNewLineChar);
				
				Point relativeCursorPos = editRichText.getRelativeCursorPos(pair.cursorPos, (TextLine)pair.addedInfo);
				editRichText.cursorPos.x = relativeCursorPos.x;
				editRichText.cursorPos.y = relativeCursorPos.y;				
			}
			else if (command.equals("replace") || command.equals("replaceAll")) {
				if (command.equals("replace")) {
					redo_replace(editRichText, pair);
				}
				else {	// replaceAll
					// replaceAll일 경우 
					// redo 를 undo 하기 위한 백업은 redo_replace(pair)에서 한다.
					redo_replace(editRichText, pair);
				}
								
				//커서위치는 undo(), undo_replace(), redo(), redo_replace(), replace()에서 
				// 설정하지 않고 replaceCommon()에서 공통적으로 설정한다. 
				// 위 함수들이 공통적으로 replaceCommon()을 호출하기 때문이다.
				//editRichText.cursorPos.x = pair.cursorPos.x;
				//editRichText.cursorPos.y = pair.cursorPos.y;
			}
			
			else if (command.equals(Edit.BackspaceChar) || command.equals(Edit.NewLineChar) || command.equals(Edit.DeleteChar))
			{
				// backspace와 delete는 모두 특별하게 '\n'을 제거한 경우이다.
				if (command.equals(Edit.BackspaceChar)) { // 0열에서 '\n'이 지워지는 back키만
					if (pair.isSelecting) {
						UndoOfEditRichText.backUpForUndo(editRichText, Edit.BackspaceChar, pair);
						
						TextLine selectedText = (TextLine) pair.addedInfo; 
						int numToDelete;
						if (selectedText.count>0 && selectedText.characters[selectedText.count-1].charA=='\n') {
							numToDelete = editRichText.getNumOfNewLineChar(selectedText);
						}
						else {
							numToDelete = editRichText.getNumOfNewLineChar(selectedText) + 1;
						}
						int numOfNewLineChar = editRichText.getNumOfNewLineChar(newLineText);
						editRichText.setTextMultiLine(pair.cursorPos.y, newLineText, numToDelete, numOfNewLineChar);
						
						editRichText.cursorPos.x = pair.cursorPos.x;
						editRichText.cursorPos.y = pair.cursorPos.y;
					}
					else {
						UndoOfEditRichText.backUpForUndo(editRichText, Edit.BackspaceChar, pair);
						
						int numToDelete;	// pair.cursorPos.y = undoPos.y(back키를누른위치) - 1
						if (pair.cursorPos.x==0) { // 0열에서 '\n'이 지워지는 back키만
							if (pair.cursorPos.y>0) {
								numToDelete = editRichText.getNumOfLinesInText(pair.cursorPos.y-1, 2);
								int numOfNewLineChar = editRichText.getNumOfNewLineChar(newLineText);
								int cursorPosX, cursorPosY;
								cursorPosX = editRichText.textArray[pair.cursorPos.y-1].count-1;
								cursorPosY = pair.cursorPos.y-1;
								editRichText.setTextMultiLine(pair.cursorPos.y-1, newLineText, numToDelete, numOfNewLineChar);
								editRichText.cursorPos.x = cursorPosX;
								editRichText.cursorPos.y = cursorPosY;
							}
							else {
								numToDelete = editRichText.getNumOfLinesInText(pair.cursorPos.y, 1);
								int numOfNewLineChar = editRichText.getNumOfNewLineChar(newLineText);
								editRichText.setTextMultiLine(pair.cursorPos.y, newLineText, numToDelete, numOfNewLineChar);
								editRichText.cursorPos.x = 0;
								editRichText.cursorPos.y = 0;
							}
						}
						else { // 일반적인 경우
							numToDelete = editRichText.getNumOfLinesInText(pair.cursorPos.y, 1);
							int numOfNewLineChar = editRichText.getNumOfNewLineChar(newLineText);
							editRichText.setTextMultiLine(pair.cursorPos.y, newLineText, numToDelete, numOfNewLineChar);
							editRichText.cursorPos.x = pair.cursorPos.x - 1;
							editRichText.cursorPos.y = pair.cursorPos.y;
						}
					}
				}
				else if (command.equals(Edit.DeleteChar)) { // 마지막열에서 '\n'이 지워지는 delete키만
					if (pair.isSelecting) {
						UndoOfEditRichText.backUpForUndo(editRichText, Edit.DeleteChar, pair);
						
						TextLine selectedText = (TextLine) pair.addedInfo; 
						int numToDelete;
						if (selectedText.count>0 && selectedText.characters[selectedText.count-1].charA=='\n') {
							numToDelete = editRichText.getNumOfNewLineChar(selectedText);
						}
						else {
							numToDelete = editRichText.getNumOfNewLineChar(selectedText) + 1;
						}
						int numOfNewLineChar = editRichText.getNumOfNewLineChar(newLineText);
						editRichText.setTextMultiLine(pair.cursorPos.y, newLineText, numToDelete, numOfNewLineChar);
						
						editRichText.cursorPos.x = pair.cursorPos.x;
						editRichText.cursorPos.y = pair.cursorPos.y;
					}
					else {
						UndoOfEditRichText.backUpForUndo(editRichText, Edit.DeleteChar, pair);
						
						int numToDelete;
						if (pair.cursorPos.x==editRichText.textArray[pair.cursorPos.y].count-1) { 
							// 마지막열에서 '\n'이 지워지는 delete키만
							numToDelete = editRichText.getNumOfLinesInText(pair.cursorPos.y, 2);
						}
						else {
							numToDelete = editRichText.getNumOfLinesInText(pair.cursorPos.y, 1);
						}
						int numOfNewLineChar = editRichText.getNumOfNewLineChar(newLineText);
						editRichText.setTextMultiLine(pair.cursorPos.y, newLineText, numToDelete, numOfNewLineChar);
						
						editRichText.cursorPos.x = pair.cursorPos.x;
						editRichText.cursorPos.y = pair.cursorPos.y;
					}
					
					
				}
				else if (command.equals(Edit.NewLineChar)) {
					UndoOfEditRichText.backUpForUndo(editRichText, Edit.NewLineChar, pair);
					
					// undo로 합쳐진 1줄 또는 여러 라인의 개수를 세어 그것들을 삭제하고 newLineText으로 바꾼다.
					int numToDelete;
					numToDelete = editRichText.getNumOfLinesInText(pair.cursorPos.y, 1);
					int numOfNewLineChar = editRichText.getNumOfNewLineChar(newLineText) + 1;
					/*if (newLineText.characters[newLineText.count-1].charA=='\n') {
						numOfNewLineChar--;
					}*/
					editRichText.setTextMultiLine(pair.cursorPos.y, newLineText, numToDelete, numOfNewLineChar);
					editRichText.cursorPos.x = 0;
					editRichText.cursorPos.y = pair.cursorPos.y+1;
					
				}
				
			}//else if (command.equals(Edit.BackspaceChar) || command.equals(Edit.NewLineChar) || command.equals(Edit.DeleteChar))
			
			else {		// 일반적인 경우
				// a를 redo한 것을 undo하기 위해 백업
				UndoOfEditRichText.backUpForUndo(editRichText, command, pair);
				
				int numToDelete;
				numToDelete = editRichText.getNumOfLinesInText(pair.cursorPos.y, 1);
				editRichText.setTextMultiLine(pair.cursorPos.y, newLineText, numToDelete, 1);
				editRichText.cursorPos.x = pair.cursorPos.x+1;
				editRichText.cursorPos.y = pair.cursorPos.y;
			}
			
			
			editRichText.moveToCursorPos(editRichText.cursorPos.x, editRichText.cursorPos.y);	
		}//if (editRichText.redoBuffer.buffer.count>0) {
	}
}
