package com.gsoft.common.gui.edittext;

import android.graphics.Point;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.compiler.EditText_Compiler;
import com.gsoft.common.gui.IntegrationKeyboard.Hangul;
import com.gsoft.common.gui.edittext.Edit.ScrollMode;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListString;

import com.gsoft.common.gui.edittext.EditText;
import com.gsoft.common.gui.edittext.UndoBufferOfEditText;
import com.gsoft.common.gui.edittext.FunctionOfEditText;
import com.gsoft.common.gui.edittext.RedoOfEditText;
import com.gsoft.common.gui.edittext.RedoBufferOfEditText;
import com.gsoft.common.gui.edittext.Edit;

public class UndoOfEditText {
	
	/** String addedInfo = isAll + "-" + isForward + "-" + isScopeAll + "-" + isCaseSensitive + "-" +
	 *		isWholeWord;
	 *	String text = textToFind + "-" + textToReplaceWith;
	 *	cursorPos = curFindPosLocal(검색시작위치)
	 *	command = "replace"/"replaceAll" */
	public static void undo_replace(EditText editText, UndoBufferOfEditText.Pair pair) {
		String command = pair.command;
		
		int index = pair.text.indexOf("-");
		String textToFind = pair.text.substring(0, index).toString();
		String textToReplaceWith = pair.text.substring(index+1).toString();
		
		String addedInfo = (String)pair.addedInfo;
		int index0 = addedInfo.indexOf("-", 0);		
		boolean isAll = Boolean.parseBoolean(addedInfo.substring(0, index0));
		
		int index1 = addedInfo.indexOf("-", index0+1);
		boolean isForward = Boolean.parseBoolean(addedInfo.substring(index0+1, index1));
		
		int index2 = addedInfo.indexOf("-", index1+1);
		boolean isScopeAll = Boolean.parseBoolean(addedInfo.substring(index1+1, index2));
		
		int index3 = addedInfo.indexOf("-", index2+1);
		boolean isCaseSensitive = Boolean.parseBoolean(addedInfo.substring(index2+1, index3));
		
		
		
		// replace-find(isAll==false) 시 backupForUndo_replace()에서 addedInfo의 구조
		/************************************************************************************ 
		 * if (isScopeAll==false) {
			addedInfo = isAll + "-" + isForward + "-" + isScopeAll + "-" + isCaseSensitive + "-" +
				isWholeWord + "-" + 
				this.selectP1.x + "-" + this.selectP1.y + "-" + this.selectP2.x + "-" + this.selectP2.y + "-" +
				findP1.x + "-" + findP1.y + "-" + findP2.x + "-" + findP2.y + "-" +
				replacePosP1.x + "-" + replacePosP1.y + "-" + replacePosP2.x + "-" + replacePosP2.y;;
		}
		else {
			addedInfo = isAll + "-" + isForward + "-" + isScopeAll + "-" + isCaseSensitive + "-" +
				isWholeWord + "-" +
				findP1.x + "-" + findP1.y + "-" + findP2.x + "-" + findP2.y + "-" +
				replacePosP1.x + "-" + replacePosP1.y + "-" + replacePosP2.x + "-" + replacePosP2.y;;
		}*****************************************************************************************/
		
		// replaceAll(isAll==true)일 경우 addedInfo의 구조
		/******************************************************************************************
		 * String addedInfo;
		if (isScopeAll==false) {
			addedInfo = isAll + "-" + isForward + "-" + isScopeAll + "-" + isCaseSensitive + "-" +
				isWholeWord + "-" + 
				this.selectP1.x + "-" + this.selectP1.y + "-" + this.selectP2.x + "-" + this.selectP2.y;
		}
		else {
			addedInfo = isAll + "-" + isForward + "-" + isScopeAll + "-" + isCaseSensitive + "-" +
				isWholeWord;
		}************************************************************************************************/
		
		int selectP1_x, selectP1_y, selectP2_x, selectP2_y = 0;
		int findP1_x, findP1_y, findP2_x, findP2_y = 0;
		int replacePosP1_x=0, replacePosP1_y=0, replacePosP2_x=0, replacePosP2_y=0;
		if (!isScopeAll) {
			int index4 = addedInfo.indexOf("-", index3+1);
			int index5 = addedInfo.indexOf("-", index4+1);
			selectP1_x = Integer.parseInt(addedInfo.substring(index4+1, index5));
			
			int index6 = addedInfo.indexOf("-", index5+1);
			selectP1_y = Integer.parseInt(addedInfo.substring(index5+1, index6));
			
			int index7 = addedInfo.indexOf("-", index6+1);
			selectP2_x = Integer.parseInt(addedInfo.substring(index6+1, index7));
			
			int index8 = addedInfo.indexOf("-", index7+1);
			selectP2_y = Integer.parseInt(addedInfo.substring(index7+1));
			
			editText.selectP1.x = selectP1_x;
			editText.selectP1.y = selectP1_y;
			editText.selectP2.x = selectP2_x;
			editText.selectP2.y = selectP2_y;
			
			if (!isAll) {// isScopeAll==false, isAll==false
				int index9 = addedInfo.indexOf("-", index8+1);
				findP1_x = Integer.parseInt(addedInfo.substring(index8+1, index9));
				
				int index10 = addedInfo.indexOf("-", index9+1);
				findP1_y = Integer.parseInt(addedInfo.substring(index9+1, index10));
				
				int index11 = addedInfo.indexOf("-", index10+1);
				findP2_x = Integer.parseInt(addedInfo.substring(index10+1, index11));				
				
				int index12 = addedInfo.indexOf("-", index11+1);
				findP2_y = Integer.parseInt(addedInfo.substring(index11+1, index12));
				
				int index13 = addedInfo.indexOf("-", index12+1);
				replacePosP1_x = Integer.parseInt(addedInfo.substring(index12+1, index13));
				
				int index14 = addedInfo.indexOf("-", index13+1);
				replacePosP1_y = Integer.parseInt(addedInfo.substring(index13+1, index14));
				
				int index15 = addedInfo.indexOf("-", index14+1);
				replacePosP2_x = Integer.parseInt(addedInfo.substring(index14+1, index15));				
				
				replacePosP2_y = Integer.parseInt(addedInfo.substring(index15+1));
				
				editText.findP1.x = findP1_x;
				editText.findP1.y = findP1_y;
				editText.findP2.x = findP2_x;
				editText.findP2.y = findP2_y;
			}
			
		}			
		else { // isScopeAll==true
			if (!isAll) {// isScopeAll==true, isAll==false
				int index4 = addedInfo.indexOf("-", index3+1);
				int index9 = addedInfo.indexOf("-", index4+1);
				findP1_x = Integer.parseInt(addedInfo.substring(index4+1, index9));
				
				int index10 = addedInfo.indexOf("-", index9+1);
				findP1_y = Integer.parseInt(addedInfo.substring(index9+1, index10));
				
				int index11 = addedInfo.indexOf("-", index10+1);
				findP2_x = Integer.parseInt(addedInfo.substring(index10+1, index11));				
				
				int index12 = addedInfo.indexOf("-", index11+1);
				findP2_y = Integer.parseInt(addedInfo.substring(index11+1, index12));
				
				int index13 = addedInfo.indexOf("-", index12+1);
				replacePosP1_x = Integer.parseInt(addedInfo.substring(index12+1, index13));
				
				int index14 = addedInfo.indexOf("-", index13+1);
				replacePosP1_y = Integer.parseInt(addedInfo.substring(index13+1, index14));
				
				int index15 = addedInfo.indexOf("-", index14+1);
				replacePosP2_x = Integer.parseInt(addedInfo.substring(index14+1, index15));				
				
				replacePosP2_y = Integer.parseInt(addedInfo.substring(index15+1));
				
				editText.findP1.x = findP1_x;
				editText.findP1.y = findP1_y;
				editText.findP2.x = findP2_x;
				editText.findP2.y = findP2_y;
			}
			else {// isScopeAll==true, isAll==true
				
			}
		}
		
		if (command.equals("replace")) { // replace-find
		
			
			// replace-find시에 대체한 위치를 textToFind로 바꾼다.
			if (isCaseSensitive) {
				editText.findReplace.replaceCommon(isAll, 
					new Point(replacePosP1_x, replacePosP1_y), new Point(replacePosP2_x, replacePosP2_y), 
					textToReplaceWith, textToFind);
			}
			else {
				ArrayListString listTextForNoneCaseSensitive = pair.listOfTextForNoneCaseSensitive;
				if (listTextForNoneCaseSensitive.count>0) {
					String originText = listTextForNoneCaseSensitive.getItem(0);
					editText.findReplace.replaceCommon(isAll, 
							new Point(replacePosP1_x, replacePosP1_y), new Point(replacePosP2_x, replacePosP2_y), 
							textToReplaceWith, originText);
				}
				
			}
			editText.moveToCursorPos(editText.cursorPos.x, editText.cursorPos.y);
		}
		else { // replaceAll
			if (!isScopeAll) editText.isSelecting = true;
		
			
			// 일반적인 경우
			
			ArrayList listReplacePos = pair.listOfReplacePos;
			// 아래 for문에서 this.listFindPos가 바뀌므로 백업해두었다가
			// undoBuffer에 넣는다.
			ArrayListString listTextForNoneCaseSensitive = pair.listOfTextForNoneCaseSensitive;
			
			ArrayList listBackupForReplacePos = editText.getClone(listReplacePos);
			int count = listReplacePos.count;
			int i;
			for (i=0; i<count; i+=2) {
				Point p1 = (Point)listReplacePos.list[i];
				Point p2 = (Point)listReplacePos.list[i+1];
				if (isCaseSensitive) {
					editText.findReplace.replaceCommon(isAll, p1, p2, textToReplaceWith, textToFind);
				}
				else {
					String originText = listTextForNoneCaseSensitive.getItem(i);
					editText.findReplace.replaceCommon(isAll, p1, p2, textToReplaceWith, originText);
				}
				
				if (!isScopeAll) {
					editText.findReplace.changeSelectP1AndP2(true, isForward, p1, p2, textToFind);
				}
				editText.findReplace.changeListFindPos(listReplacePos, i+2, p1.y, textToReplaceWith, textToFind);
			}
			
			pair.listOfReplacePos = listBackupForReplacePos;
						
			if (!isScopeAll) {
				FunctionOfEditText.makeSelectIndices(editText, true, editText.selectP1, editText.selectP2);
			}
			
			editText.setVScrollPos();
			editText.setVScrollBar();
			if (editText.scrollMode==ScrollMode.Both) {
				editText.setHScrollPos();
				editText.setHScrollBar();	
			}
			
			editText.isFound = false;
		}// replaceAll
		
		if (editText instanceof EditText_Compiler) {
			EditText_Compiler editText_Compiler = (EditText_Compiler) editText;
			if (editText_Compiler.getCompiler()!=null) {
				editText_Compiler.update(0, 0, "all", true);
			}
		}
	}
	
	/** back, delete, enter키 등의 조작을 무효로 한다.*/
	public static void undo(EditText editText) {
		if (editText.isReadOnly) return;
		
		// 터치시 한글모드와 버퍼를 초기화	
		Hangul.mode = Hangul.Mode.None;
		Hangul.resetBuffer();
		
		if (editText.undoBuffer.buffer.count>0) {
			editText.isSelecting = false;
			
			editText.setIsModified(true);
			
			UndoBufferOfEditText.Pair pair = editText.undoBuffer.pop();
			CodeString newLineText = pair.text;
			
			String command = pair.command;
			
		
			
			if (!command.equals("replace") && !command.equals("replaceAll")) {
				if (!pair.isSelecting) {
					RedoOfEditText.backUpForRedo(editText, command, newLineText, pair.cursorPos, pair.addedInfo);
				}
				else {
					RedoOfEditText.backUpForRedo(editText, command, newLineText, pair.cursorPos, newLineText, pair.isSelecting, (Point)pair.addedInfo);
				}
			}
			else {//if (command.equals("replace") || command.equals("replaceAll")) {
				
				
			}
			
			
			if (command.equals("replace") || command.equals("replaceAll")) {
				undo_replace(editText, pair);
				//커서위치는 undo(), undo_replace(), redo(), redo_replace(), replace()에서 
				// 설정하지 않고 replaceCommon()에서 공통적으로 설정한다. 
				// 위 함수들이 공통적으로 replaceCommon()을 호출하기 때문이다.
				
				// replace, replaceAll만 여기에서 백업한다.
				RedoOfEditText.backUpForRedo(editText, pair.command, pair.text, pair.cursorPos, pair.isSelecting, pair.addedInfo, 
						pair.listOfFindPos, pair.listOfReplacePos);
				
			}
			else if (command.equals("cut")) {
				int numToDelete = editText.getNumOfLinesInText(pair.cursorPos.y, 0, 1);
								
				editText.setTextMultiLine(pair.cursorPos.y, newLineText, numToDelete);
				
				editText.cursorPos = editText.getRelativeCursorPos(pair.cursorPos, (String)pair.addedInfo);
				
			}
			else if (command.equals("paste")) {
				String addedInfo = (String)pair.addedInfo;
				// numOfNewLineCharToDelete = 선택텍스트의 newLineChar개수 + 원래의 1줄
				int numOfNewLineCharToDelete = editText.getNumOfNewLineChar(addedInfo) + 1;
				int numToDelete = editText.getNumOfLinesInText(pair.cursorPos.y, 0, numOfNewLineCharToDelete);
				editText.setTextMultiLine(pair.cursorPos.y, newLineText, numToDelete);
								
				editText.cursorPos.x = pair.cursorPos.x;
				editText.cursorPos.y = pair.cursorPos.y;
			}//paste
			else if (command.equals(Edit.BackspaceChar) || command.equals(Edit.NewLineChar) || command.equals(Edit.DeleteChar))
			{	// backspace(0열)와 delete(마지막열)는 모두 특별하게 '\n'을 제거한 경우이거나, 그렇지 않은 경우이다.
				if (command.equals(Edit.BackspaceChar)) {					
					if (pair.isSelecting) {
						
						// pair.cursorPos.y는 p1의 y이다.
						editText.setTextMultiLine(pair.cursorPos.y, newLineText, 1);
						
						Point p2 = (Point) pair.addedInfo;
						editText.cursorPos.x = p2.x+1;
						editText.cursorPos.y = p2.y;
					}
					else {
						// newLineText가 두줄이면 0열에서 back키를 누른 경우이고
						// 한줄이면 그렇지 않은 경우
						// pair.cursorPos.y-1은 이전 라인(prevLine)을 의미한다.
						if (editText.scrollMode==ScrollMode.Both) { 
							if (pair.cursorPos.x==0) {// 2줄이 1줄로 바뀐경우이므로 1줄을 삭제하고 원래의 2줄로 바꾼다.
								
								if (pair.cursorPos.y==0) {
									editText.setTextMultiLine(pair.cursorPos.y, newLineText, 1);
								}
								else {
									editText.setTextMultiLine(pair.cursorPos.y-1, newLineText, 1);
								}
								editText.cursorPos.x = 0;
								editText.cursorPos.y = pair.cursorPos.y;
							}
							else {
								
								editText.setTextMultiLine(pair.cursorPos.y, newLineText, 1);
								editText.cursorPos.x = pair.cursorPos.x;
								editText.cursorPos.y = pair.cursorPos.y;
							}
						}//if (scrollMode==ScrollMode.Both) { 
						else { 
							int numToDelete = editText.getNumOfLinesInText(pair.cursorPos.y-1, 0, 1);
							editText.setTextMultiLine(pair.cursorPos.y-1, newLineText, numToDelete);
						}
					}
					
				}
				else if (command.equals(Edit.DeleteChar)) {
					if (pair.isSelecting) { // Both일 경우에만
						
						editText.setTextMultiLine(pair.cursorPos.y, newLineText, 1);
						
						Point p2 = (Point) pair.addedInfo;
						editText.cursorPos.x = p2.x+1;
						editText.cursorPos.y = p2.y;
					}
					else {
						if (editText.scrollMode==ScrollMode.Both) { // 2줄이 1줄로 바뀐경우이므로 1줄을 삭제하고 원래의 2줄로 바꾼다.
							
							int cursorPosX, cursorPosY;
							if (pair.cursorPos.x<=editText.textArray[pair.cursorPos.y].count-1 && 
									editText.textArray[pair.cursorPos.y].charAt(pair.cursorPos.x).c!='\n') {
								cursorPosX = pair.cursorPos.x+1;
								cursorPosY = pair.cursorPos.y;
							}
							else {
								cursorPosX = pair.cursorPos.x;
								cursorPosY = pair.cursorPos.y;
							}
														
							editText.setTextMultiLine(pair.cursorPos.y, newLineText, 1);
														
							editText.cursorPos.x = cursorPosX;
							editText.cursorPos.y = cursorPosY;
						}
						else {
							int numToDelete = editText.getNumOfLinesInText(pair.cursorPos.y, 0, 1);
							editText.setTextMultiLine(pair.cursorPos.y, newLineText, numToDelete);
						}
					}
					
				}
				else if (command.equals(Edit.NewLineChar)) { // 1줄이 2줄로 바뀐경우
					if (editText.scrollMode==ScrollMode.Both) {
						editText.setTextMultiLine(pair.cursorPos.y, newLineText, 2);
					}
					else {
						int numToDelete = editText.getNumOfLinesInText(pair.cursorPos.y, 0, 2);
						editText.setTextMultiLine(pair.cursorPos.y, newLineText, numToDelete);
					}
					editText.cursorPos.x = pair.cursorPos.x;
					editText.cursorPos.y = pair.cursorPos.y;
				}
			}//else if (command.equals(Edit.BackspaceChar) || command.equals(Edit.NewLineChar) || command.equals(Edit.DeleteChar))
			else {	// 일반적인 경우
				editText.setTextMultiLine(pair.cursorPos.y, newLineText, -1);
				editText.cursorPos.x = pair.cursorPos.x;
				editText.cursorPos.y = pair.cursorPos.y;
			}
			editText.moveToCursorPos(editText.cursorPos.x, editText.cursorPos.y);
			
			if (editText instanceof EditText_Compiler) {
				EditText_Compiler editText_Compiler = (EditText_Compiler) editText;
				if (editText_Compiler.getCompiler()!=null) {
					editText_Compiler.update(0, 0, "all", true);
				}
			}
		}//if (undoBuffer.buffer.count>0) {
	}
	
	public static void backUpForUndo(EditText editText, String charA, boolean isReplaceChar) {
		CodeString[] textArray = editText.textArray;
		UndoBufferOfEditText undoBuffer = editText.undoBuffer;
		
		if (charA.equals("cut")) {			
			int i;
			int y;
			int startX, endX;
			String copiedText = "";
			for (i=0; i<editText.selectIndicesCountForCopy; i+=2) {
				y = editText.selectIndices[i].y;
				startX = editText.selectIndices[i].x;
				endX = editText.selectIndices[i+1].x;
				CodeString lineCopiedText = textArray[y].substring(startX, endX+1);
				copiedText += lineCopiedText.str;
			}
			
			int firstLine = editText.selectIndices[0].y;
			int numOfNewLineChar = editText.getNumOfNewLineChar(copiedText) + 1;
			//int this.getNumOfLinesInText(firstLine, 0, numOfNewLineChar);
			CodeString newText = editText.TextArrayToText(firstLine, 0, numOfNewLineChar);
			Object addedInfo = copiedText;
			undoBuffer.push(new Point(editText.selectIndices[0].x,firstLine), newText, charA, addedInfo);
		
		}
		else if (charA.equals("paste")) {	// paste를 undo
			CodeString textForBackup = editText.TextArrayToText(editText.cursorPos.y, 0, 1);
			Object addedInfo = editText.copiedText;
			undoBuffer.push(new Point(editText.cursorPos.x, editText.cursorPos.y), textForBackup, charA, 
					addedInfo);
		}
		
		else if (charA.equals(Edit.DeleteChar) || charA.equals(Edit.NewLineChar) ||
				charA.equals(Edit.BackspaceChar)) 
		{
			if (charA.equals(Edit.BackspaceChar)) {
				if (editText.isSelecting) {
					Point p1 = editText.selectP1, p2 = editText.selectP2;
					if (editText.selectP1.y>editText.selectP2.y) { // swapping
						p1 = editText.selectP2;
						p2 = editText.selectP1;
					}
					else if (editText.selectP1.y==editText.selectP2.y) {
						if (editText.selectP1.x>editText.selectP2.x) {
							// swapping, y가 같을땐 x를 비교해서 작은쪽이 p1이 된다.
							p1 = editText.selectP2;
							p2 = editText.selectP1;
						}
					}
					// 선택된 줄들을 백업한다.
					CodeString textForBackup = editText.TextArrayToText(p1.y, 0, p2.y-p1.y+1);
					//undoBuffer.push(new Point(p2.x, p1.y), textForBackup, charA, null, isSelecting);
					undoBuffer.push(p1, textForBackup, charA, p2, editText.isSelecting);
				}
				else {
					if (editText.cursorPos.x!=0) { // undo에서 일반적인 경우로 취급
						Point cursorPos = editText.cursorPos;
						CodeString textForBackup = editText.TextArrayToText(cursorPos.y, 0, 1);
						undoBuffer.push(new Point(cursorPos.x, cursorPos.y), textForBackup, charA);
					}
					else {
						int prevLine;
						if (editText.cursorPos.y>0) {
							Point cursorPos = editText.cursorPos;
							prevLine = cursorPos.y-1;
							if (editText.textArray[prevLine].length()>0 && editText.textArray[prevLine].charAt(editText.textArray[prevLine].length()-1).c=='\n') {
								// 이전라인과 현재라인 모두를 백업한다.(0열에서 '\n'이 지워지는 back키만)
								CodeString newText=null;
								newText = editText.TextArrayToText(prevLine, cursorPos.x, 2);
								editText.undoBuffer.push(new Point(cursorPos.x, cursorPos.y), newText, charA);
								//setTextMultiLine(cursorPos.y, newText, -1);
							}
							else {	// scrollMode가 VScroll일 때만 
								CodeString textForBackup = editText.TextArrayToText(prevLine, 0, 1);
								editText.undoBuffer.push(new Point(cursorPos.x, prevLine), textForBackup, charA);
							}
						}					
					}
				}
			}
			else if (charA.equals(Edit.DeleteChar)) {
				if (editText.isSelecting) {
					Point p1 = editText.selectP1, p2 = editText.selectP2;
					if (editText.selectP1.y>editText.selectP2.y) { // swapping
						p1 = editText.selectP2;
						p2 = editText.selectP1;
					}
					else if (editText.selectP1.y==editText.selectP2.y) {
						if (editText.selectP1.x>editText.selectP2.x) {
							// swapping, y가 같을땐 x를 비교해서 작은쪽이 p1이 된다.
							p1 = editText.selectP2;
							p2 = editText.selectP1;
						}
					}
					// 선택된 줄들을 백업한다.
					CodeString textForBackup = editText.TextArrayToText(p1.y, 0, p2.y-p1.y+1);
					//undoBuffer.push(new Point(p2.x, p1.y), textForBackup, charA, null, isSelecting);
					editText.undoBuffer.push(p1, textForBackup, charA, p2, editText.isSelecting);
				}
				else {
					Point cursorPos = editText.cursorPos;
					if (cursorPos.x<editText.textArray[cursorPos.y].length()) {
						if (editText.textArray[cursorPos.y].charAt(cursorPos.x).c!='\n') { // undo에서 일반적인 경우로 취급
							//undoBuffer.push(cursorPos, textArray[cursorPos.y]);
							CodeString textForBackup = editText.TextArrayToText(cursorPos.y, 0, 1);
							editText.undoBuffer.push(new Point(cursorPos.x, cursorPos.y), textForBackup, charA);
						}
						else {	// 마지막열에서 '\n'이 지워지는 delete키만
							// 현재라인과 다음라인 모두를 백업한다.
							CodeString newText=null;
							newText = editText.TextArrayToText(cursorPos.y, cursorPos.x, 2);
							editText.undoBuffer.push(new Point(cursorPos.x, cursorPos.y), newText, charA);
						}
					}
					else {	// 지우는 문자가 '\n'이 아닌 경우, undo에서 일반적인 경우로 취급
						CodeString textForBackup = editText.TextArrayToText(cursorPos.y, 0, 1);
						editText.undoBuffer.push(new Point(cursorPos.x, cursorPos.y), textForBackup, charA);
					}
				}
				
			}
			else if (charA.equals(Edit.NewLineChar)) {
				// 현재라인과 다음라인 모두를 백업한다.
				CodeString newText=null;
				Point cursorPos = editText.cursorPos;
				newText = editText.TextArrayToText(cursorPos.y, cursorPos.x, 1);
				editText.undoBuffer.push(new Point(cursorPos.x,cursorPos.y), newText, charA);
			}
		}
		else { // 일반적인 경우
			Point cursorPos = editText.cursorPos;
			if (isReplaceChar) {
				CodeString textForBackup = editText.TextArrayToText(cursorPos.y, 0, 1);
				editText.undoBuffer.push(new Point(cursorPos.x, cursorPos.y), textForBackup, charA);
			}
			else {
				CodeString textForBackup = editText.TextArrayToText(cursorPos.y, 0, 1);
				editText.undoBuffer.push(new Point(cursorPos.x, cursorPos.y), textForBackup, charA);
			}
		}
	}
	
	
	/** replaceAll에서 replace하는 위치들을 백업하기 위해 호출한다.*/
	public static void backUpForUndo_replace(EditText editText, String command, boolean isAll, boolean isForward, boolean isScopeAll, boolean isCaseSensitive, 
			boolean isWholeWord, Point curFindPosLocal, String textToFind, String textToReplaceWith,
			ArrayList listOfFindPos, ArrayList listOfReplacePos) {
		String addedInfo;
		if (!isScopeAll) {
			addedInfo = isAll + "-" + isForward + "-" + isScopeAll + "-" + isCaseSensitive + "-" +
				isWholeWord + "-" + 
				editText.selectP1.x + "-" + editText.selectP1.y + "-" + editText.selectP2.x + "-" + editText.selectP2.y;
		}
		else {
			addedInfo = isAll + "-" + isForward + "-" + isScopeAll + "-" + isCaseSensitive + "-" +
					isWholeWord;
		}
		CodeString text = new CodeString(textToFind + "-" + textToReplaceWith, editText.textColor);
		/*if (command.equals("replace")) {			
			editText.undoBuffer.push(new Point(curFindPosLocal.x,curFindPosLocal.y), text, command, addedInfo);
		}
		else*/ if (command.equals("replaceAll")) {
			editText.undoBuffer.push(new Point(curFindPosLocal.x,curFindPosLocal.y), text, command, addedInfo, !isScopeAll, listOfFindPos, listOfReplacePos);
		}
	}
	
	/** replaceAll에서 replace하는 위치들과 NoneCaseSensitive일때 다양한 텍스트들을 백업하기 위해 호출한다.*/
	public static void backUpForUndo_replace(EditText editText, String command, boolean isAll, boolean isForward, boolean isScopeAll, boolean isCaseSensitive, 
			boolean isWholeWord, Point curFindPosLocal, String textToFind, String textToReplaceWith,
			ArrayList listOfFindPos, ArrayList listOfReplacePos, ArrayListString listOfTextForNoneCaseSensitive) {
		String addedInfo;
		if (!isScopeAll) {
			addedInfo = isAll + "-" + isForward + "-" + isScopeAll + "-" + isCaseSensitive + "-" +
				isWholeWord + "-" + 
				editText.selectP1.x + "-" + editText.selectP1.y + "-" + editText.selectP2.x + "-" + editText.selectP2.y;
		}
		else {
			addedInfo = isAll + "-" + isForward + "-" + isScopeAll + "-" + isCaseSensitive + "-" +
					isWholeWord;
		}
		CodeString text = new CodeString(textToFind + "-" + textToReplaceWith, editText.textColor);
		/*if (command.equals("replace")) {			
			editText.undoBuffer.push(new Point(curFindPosLocal.x,curFindPosLocal.y), text, command, addedInfo);
		}
		else*/ if (command.equals("replaceAll")) {
			editText.undoBuffer.push(new Point(curFindPosLocal.x,curFindPosLocal.y), text, command, addedInfo, !isScopeAll, listOfFindPos, listOfReplacePos, listOfTextForNoneCaseSensitive);
		}
	}
	
	/**replace-find 에서만 호출한다. 즉 isAll 은 false 이다. 
	 * 검색한 위치(findP1,findP2)와 대체한 위치(replacePosP1,replacePosP2) 모두를 백업한다.
	 * String addedInfo = isAll + "-" + isForward + "-" + isScopeAll + "-" + isCaseSensitive + "-" +
	 * 		isWholeWord;
	 * String text = textToFind + "-" + textToReplaceWith;
	 * cursorPos = curFindPosLocal(검색시작위치)
	 * command = "replace"/"replaceAll" */
	public static void backUpForUndo_replace(EditText editText, String command, boolean isAll, boolean isForward, boolean isScopeAll, boolean isCaseSensitive, 
			boolean isWholeWord, 
			Point findP1, Point findP2, Point replacePosP1, Point replacePosP2, 
			String textToFind, String textToReplaceWith) {
		String addedInfo;
		if (!isScopeAll) {
			addedInfo = isAll + "-" + isForward + "-" + isScopeAll + "-" + isCaseSensitive + "-" +
				isWholeWord + "-" + 
				editText.selectP1.x + "-" + editText.selectP1.y + "-" + editText.selectP2.x + "-" + editText.selectP2.y + "-" +
				findP1.x + "-" + findP1.y + "-" + findP2.x + "-" + findP2.y + "-" +
				replacePosP1.x + "-" + replacePosP1.y + "-" + replacePosP2.x + "-" + replacePosP2.y;
		}
		else {
			addedInfo = isAll + "-" + isForward + "-" + isScopeAll + "-" + isCaseSensitive + "-" +
				isWholeWord + "-" +
				findP1.x + "-" + findP1.y + "-" + findP2.x + "-" + findP2.y + "-" +
				replacePosP1.x + "-" + replacePosP1.y + "-" + replacePosP2.x + "-" + replacePosP2.y;
		}
		CodeString text = new CodeString(textToFind + "-" + textToReplaceWith, editText.textColor);
		if (command.equals("replace")) {			
			editText.undoBuffer.push(new Point(replacePosP1.x,replacePosP1.y), text, command, addedInfo);
		}
		/*else if (command.equals("replaceAll")) {
			editText.undoBuffer.push(new Point(replacePosP1.x,replacePosP1.y), text, command, addedInfo);
		}*/
	}
	
	/** replace-find에서 none-case sentivie일 때 호출한다.*/
	public static void backUpForUndo_replace(EditText editText, String command, boolean isAll, boolean isForward, boolean isScopeAll, boolean isCaseSensitive, 
			boolean isWholeWord, 
			Point findP1, Point findP2, Point replacePosP1, Point replacePosP2, 
			String textToFind, String textToReplaceWith, ArrayListString listOfTextForNoneCaseSensitive) {
		String addedInfo;
		if (!isScopeAll) {
			addedInfo = isAll + "-" + isForward + "-" + isScopeAll + "-" + isCaseSensitive + "-" +
				isWholeWord + "-" + 
				editText.selectP1.x + "-" + editText.selectP1.y + "-" + editText.selectP2.x + "-" + editText.selectP2.y + "-" +
				findP1.x + "-" + findP1.y + "-" + findP2.x + "-" + findP2.y + "-" +
				replacePosP1.x + "-" + replacePosP1.y + "-" + replacePosP2.x + "-" + replacePosP2.y;
		}
		else {
			addedInfo = isAll + "-" + isForward + "-" + isScopeAll + "-" + isCaseSensitive + "-" +
				isWholeWord + "-" +
				findP1.x + "-" + findP1.y + "-" + findP2.x + "-" + findP2.y + "-" +
				replacePosP1.x + "-" + replacePosP1.y + "-" + replacePosP2.x + "-" + replacePosP2.y;
		}
		CodeString text = new CodeString(textToFind + "-" + textToReplaceWith, editText.textColor);
		if (command.equals("replace")) {
			editText.undoBuffer.push(new Point(replacePosP1.x,replacePosP1.y), text, command, addedInfo, listOfTextForNoneCaseSensitive);
		}
		/*else if (command.equals("replaceAll")) {
			editText.undoBuffer.push(new Point(replacePosP1.x,replacePosP1.y), text, command, addedInfo);
		}*/
	}
	
	/** redo를 undo한다.*/
	public static void backUpForUndo(EditText editText, String charA, RedoBufferOfEditText.Pair pair) {
		UndoBufferOfEditText undoBuffer = editText.undoBuffer;
		CodeString[] textArray = editText.textArray;
		
		if (charA.equals("cut")) {			
			String copiedText = "";
			/*for (i=0; i<selectIndicesCountForCopy; i+=2) {
				y = selectIndices[i].y;
				startX = selectIndices[i].x;
				endX = selectIndices[i+1].x;
				CodeString lineCopiedText = textArray[y].substring(startX, endX+1);
				copiedText += lineCopiedText;
			}*/
			copiedText = (String) pair.addedInfo;
			
			//int firstLine = selectIndices[0].y;
			int firstLine = pair.cursorPos.y;
			int numOfNewLineChar = editText.getNumOfNewLineChar(copiedText) + 1;
			//int this.getNumOfLinesInText(firstLine, 0, numOfNewLineChar);
			CodeString newText = editText.TextArrayToText(firstLine, 0, numOfNewLineChar);
			Object addedInfo = copiedText;
			undoBuffer.push(new Point(pair.cursorPos.x,firstLine), newText, charA, addedInfo);
		
		}
		else if (charA.equals("paste")) {	// paste를 undo
			CodeString textForBackup = editText.TextArrayToText(pair.cursorPos.y, 0, 1);
			//Object addedInfo = copiedText;
			undoBuffer.push(new Point(pair.cursorPos.x,pair.cursorPos.y), textForBackup, charA, 
					pair.addedInfo);
		}
		
		else if (charA.equals(Edit.BackspaceChar) || charA.equals(Edit.NewLineChar) || charA.equals(Edit.DeleteChar))
		{
			if (charA.equals(Edit.BackspaceChar)) {
				if (pair.isSelecting) {
					
					// 선택된 줄들을 백업한다.
					CodeString textForBackup = (CodeString) pair.addedInfo;
					undoBuffer.push(new Point(pair.cursorPos.x, pair.cursorPos.y), textForBackup, charA, pair.p2, pair.isSelecting);
				}
				else {
					if (pair.cursorPos.x!=0) { // undo에서 일반적인 경우로 취급
						CodeString textForBackup = editText.TextArrayToText(pair.cursorPos.y, 0, 1);
						undoBuffer.push(new Point(pair.cursorPos.x,pair.cursorPos.y), textForBackup, charA);
					}
					else {
						int prevLine;
						if (pair.cursorPos.y>0) {
							prevLine = pair.cursorPos.y-1;
							if (textArray[prevLine].length()>0 && textArray[prevLine].charAt(textArray[prevLine].length()-1).c=='\n') {
								// 이전라인과 현재라인 모두를 백업한다.(0열에서 '\n'이 지워지는 back키만)
								CodeString newText=null;
								newText = editText.TextArrayToText(prevLine, pair.cursorPos.x, 2);
								undoBuffer.push(new Point(pair.cursorPos.x,pair.cursorPos.y), newText, charA);
								//setTextMultiLine(cursorPos.y, newText, -1);
							}
							else {	// scrollMode가 VScroll일 때만 
								CodeString textForBackup = editText.TextArrayToText(prevLine, 0, 1);
								undoBuffer.push(new Point(pair.cursorPos.x, prevLine), textForBackup, charA);
							}
						}					
					}
				}
			}
			else if (charA.equals(Edit.DeleteChar)) {
				if (pair.isSelecting) {
					/*Point p1 = selectP1, p2 = selectP2;
					if (this.selectP1.y>=this.selectP2.y) {
						p1 = selectP2;
						p2 = selectP1;
					}
					// 선택된 줄들을 백업한다.
					CodeString textForBackup = TextArrayToText(p1.y, 0, p2.y-p1.y+1);
					undoBuffer.push(new Point(p1.x, p1.y), textForBackup, charA, null, isSelecting);*/
					
					// 선택된 줄들을 백업한다.
					CodeString textForBackup = (CodeString) pair.addedInfo;
					undoBuffer.push(new Point(pair.cursorPos.x, pair.cursorPos.y), textForBackup, charA, pair.p2, pair.isSelecting);
					
				}
				else {
					if (pair.cursorPos.x<textArray[pair.cursorPos.y].length()) {
						if (textArray[pair.cursorPos.y].charAt(pair.cursorPos.x).c!='\n') { // undo에서 일반적인 경우로 취급
							//undoBuffer.push(cursorPos, textArray[cursorPos.y]);
							CodeString textForBackup = editText.TextArrayToText(pair.cursorPos.y, 0, 1);
							undoBuffer.push(new Point(pair.cursorPos.x,pair.cursorPos.y), textForBackup, charA);
						}
						else {	// 마지막열에서 '\n'이 지워지는 delete키만
							// 현재라인과 다음라인 모두를 백업한다.
							CodeString newText=null;
							newText = editText.TextArrayToText(pair.cursorPos.y, pair.cursorPos.x, 2);
							undoBuffer.push(new Point(pair.cursorPos.x, pair.cursorPos.y), newText, charA);
						}
					}
					else {	// 지우는 문자가 '\n'이 아닌 경우, undo에서 일반적인 경우로 취급
						CodeString textForBackup = editText.TextArrayToText(pair.cursorPos.y, 0, 1);
						undoBuffer.push(new Point(pair.cursorPos.x, pair.cursorPos.y), textForBackup, charA);
					}
				}
				
			}
			else if (charA.equals(Edit.NewLineChar)) {
				// 현재라인과 다음라인 모두를 백업한다.
				CodeString newText=null;
				newText = editText.TextArrayToText(pair.cursorPos.y, pair.cursorPos.x, 1);
				undoBuffer.push(new Point(pair.cursorPos.x, pair.cursorPos.y), newText, charA);
			}
		}
		
		else  { // 일반적인 경우
			CodeString textForBackup = editText.TextArrayToText(pair.cursorPos.y, 0, 1);
			undoBuffer.push(new Point(editText.cursorPos.x, pair.cursorPos.y), textForBackup, charA);
		}
	}

}
