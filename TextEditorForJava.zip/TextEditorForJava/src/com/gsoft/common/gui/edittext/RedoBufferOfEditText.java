package com.gsoft.common.gui.edittext;

import android.graphics.Point;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListCodeString;
import com.gsoft.common.util.ArrayListString;
import com.gsoft.common.util.Util;

import com.gsoft.common.gui.edittext.EditText;
import com.gsoft.common.gui.edittext.Edit;

public class RedoBufferOfEditText {
	//EditText owner;
	
	static class Pair {
		CodeString text;
		/** 선택상태에서 백키나 delete키를 눌러서 한번에 지울경우에 사용.
		 * isSelecting이 true 일때 cursorPos는 p1이다.<br>
		 *  선택줄일때 p1은 왼쪽 위를 말하고 p2는 오른쪽 아래를 말한다.*/ 
		Point cursorPos;
		String command;
		Object addedInfo;
		/** 선택상태에서 백키나 delete키를 눌러서 한번에 지울경우에 사용*/
		public boolean isSelecting;
		/** 선택상태에서 백키나 delete키를 눌러서 한번에 지울경우에 사용.
		 * isSelecting이 true 일때 cursorPos는 p1이다.<br>
		 *  선택줄일때 p1은 왼쪽 위를 말하고 p2는 오른쪽 아래를 말한다.*/ 
		Point p2;
		/** ReplaceAll에서 빈 스트링("")으로 대체된 경우 null 이 아니다.
		 * replaceAll할때에 검색된 좌표들을 백업한다.*/
		ArrayList listOfFindPos;
		/** replaceAll할때에 replace 된 좌표들을 백업한다.*/
		ArrayList listOfReplacePos;
	}
	ArrayListCodeString buffer = new ArrayListCodeString(50);
	private ArrayList arrayCursorPos = new ArrayList(50);
	private ArrayListString bufferCommand = new ArrayListString(50);
	private ArrayList arrayAddedInfo = new ArrayList(50);
	private ArrayList arrayIsSelecting = new ArrayList(50);
	private ArrayList arrayPointP2 = new ArrayList(50);
	private ArrayList arrayListOfFindPos = new ArrayList(50);
	private ArrayList arrayListOfReplacePos = new ArrayList(50);
	
	public RedoBufferOfEditText() {
		
	}
	public void reset() {
		buffer.reset();
		arrayCursorPos.reset();
		bufferCommand.destroy();
		arrayAddedInfo.reset();
		arrayIsSelecting.reset();
		arrayPointP2.reset();
		arrayListOfFindPos.reset();
		arrayListOfReplacePos.reset();
	}
	void push(Point cursorPos, CodeString text, String charA) {
		buffer.add(text);
		arrayCursorPos.add(cursorPos);
		bufferCommand.add(charA);
		arrayAddedInfo.add(null);
		arrayIsSelecting.add(null);
		arrayPointP2.add(null);
		arrayListOfFindPos.add(null);
		arrayListOfReplacePos.add(null);
	}
	void push(Point cursorPos, CodeString text, String charA, Object addedInfo) {
		buffer.add(text);
		arrayCursorPos.add(cursorPos);
		bufferCommand.add(charA);
		arrayAddedInfo.add(addedInfo);
		arrayIsSelecting.add(null);
		arrayPointP2.add(null);
		arrayListOfFindPos.add(null);
		arrayListOfReplacePos.add(null);
	}
	void push(Point cursorPos, CodeString text, String charA, Object addedInfo, boolean isSelecting, Point p2) {
		buffer.add(text);
		arrayCursorPos.add(cursorPos);
		bufferCommand.add(charA);
		arrayAddedInfo.add(addedInfo);
		arrayIsSelecting.add(new Boolean(isSelecting));
		arrayPointP2.add(p2);
		arrayListOfFindPos.add(null);
		arrayListOfReplacePos.add(null);
	}
	void push(Point cursorPos, CodeString text, String charA, Object addedInfo, boolean isSelecting, Point p2, ArrayList listFindPos) {
		buffer.add(text);
		arrayCursorPos.add(cursorPos);
		bufferCommand.add(charA);
		arrayAddedInfo.add(addedInfo);
		arrayIsSelecting.add(new Boolean(isSelecting));
		arrayPointP2.add(p2);
		arrayListOfFindPos.add(listFindPos);
		arrayListOfReplacePos.add(null);
	}
	void push(Point cursorPos, CodeString text, String charA, Object addedInfo, boolean isSelecting, Point p2, ArrayList listFindPos, ArrayList listReplacePos) {
		buffer.add(text);
		arrayCursorPos.add(cursorPos);
		bufferCommand.add(charA);
		arrayAddedInfo.add(addedInfo);
		arrayIsSelecting.add(new Boolean(isSelecting));
		arrayPointP2.add(p2);
		arrayListOfFindPos.add(listFindPos);
		arrayListOfReplacePos.add(listReplacePos);
	}
	RedoBufferOfEditText.Pair pop() {
		RedoBufferOfEditText.Pair pair = new RedoBufferOfEditText.Pair();
		pair.text = buffer.getItem(buffer.count-1);
		pair.cursorPos = (Point)arrayCursorPos.getItem(arrayCursorPos.count-1);			
		String command = bufferCommand.getItem(bufferCommand.count-1);
		pair.command = command;
		pair.addedInfo = arrayAddedInfo.getItem(arrayAddedInfo.count-1);
		Boolean b = (Boolean) arrayIsSelecting.getItem(arrayIsSelecting.count-1);
		if (b!=null) {
			pair.isSelecting = b.booleanValue();
		}
		pair.p2 = (Point) arrayPointP2.getItem(arrayPointP2.count-1);
		pair.listOfFindPos = (ArrayList) arrayListOfFindPos.getItem(arrayListOfFindPos.count-1);
		pair.listOfReplacePos = (ArrayList) arrayListOfReplacePos.getItem(arrayListOfReplacePos.count-1);
		buffer.count--;
		arrayCursorPos.count--;
		bufferCommand.count--;
		arrayAddedInfo.count--;
		arrayIsSelecting.count--;
		arrayPointP2.count--;
		arrayListOfFindPos.count--;
		arrayListOfReplacePos.count--;
		return pair;
	}
	
	void showRedoBuffer(EditText owner) {
		CodeString message = new CodeString("<RedoBuffer Stack>\ncount   buffer(the contents to change) : command(Input key)\n(bottom)\n", 
				Common_Settings.keywordColor);
		int i;
		for (i=0; i<this.bufferCommand.count; i++) {	
			String buffer = this.buffer.getItem(i).str;
			String command = this.bufferCommand.getItem(i);
			if (command.equals(Edit.NewLineChar)) command = "Enter";
			else if (command.equals(Edit.BackspaceChar)) command = "Backspace";
			else if (command.equals(Edit.DeleteChar)) command = "Delete";
			else if (command.equals("")) command = "Char key";
			
			CodeString line = new CodeString(Util.getLineOffset(i), 
					Common_Settings.varUseColor);
			
			if (command.equals("cut") || command.equals("paste")) {
				line = line.concate(new CodeString(buffer + " : " + command +"(Selected)\n", 
						Common_Settings.textColor));
			}
			else if (command.equals("Backspace") || command.equals("Enter") ||
					command.equals("Delete")) {
				boolean isSelecting = false;
				Object s = this.arrayIsSelecting.getItem(i);
				// s가 null이면 isSelecting은 false이다.
				if (s!=null) isSelecting = ((Boolean)s).booleanValue();
				if (!isSelecting) {
					line = line.concate(new CodeString(buffer + " : " + command +"\n", 
							Common_Settings.textColor));
				}
				else {
					Point selectP1 = (Point) this.arrayCursorPos.getItem(i);
					Point selectP2 = (Point) this.arrayPointP2.getItem(i);
					String select = "(" + selectP1.x + "," + selectP1.y + ")" + ", " + 
							"(" + selectP2.x + "," + selectP2.y + ")";
					line = line.concate(new CodeString(buffer + " : " + command + " (" + select + " selected)\n", 
							Common_Settings.textColor));
				}				
			}//else if (command.equals("Backspace") || command.equals("Enter") ||
			// command.equals("Delete")) {
			else {	
				if (command.equals("replace") || command.equals("replaceAll")) {
					int indexOfSeparator = buffer.indexOf('-');
					if (indexOfSeparator!=-1) {
						String replaceWith = buffer.substring(0, indexOfSeparator);
						String backupText = buffer.substring(indexOfSeparator+1, buffer.length());
						line = line.concate(new CodeString(backupText + " : " + command +
								"("+ replaceWith + " with " + backupText+")\n", 
								Common_Settings.textColor));
					}
				}
				else {
					line = line.concate(new CodeString(buffer + " : " + command +"\n", 
							Common_Settings.textColor));
				}
			}
			message = message.concate(line);
		}
		message = message.concate(new CodeString("(top)\n", Common_Settings.keywordColor));
		owner.textView.setText(0, message);
		owner.textView.setHides(false);
	}
}
