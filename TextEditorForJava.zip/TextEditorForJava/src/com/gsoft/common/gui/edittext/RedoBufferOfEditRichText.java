package com.gsoft.common.gui.edittext;

import android.graphics.Point;

import com.gsoft.common.gui.edittext.EditRichText_Types.TextLine;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListString;

public class RedoBufferOfEditRichText {
	static class Pair {
		TextLine text;
		/** 선택상태에서 백키나 delete키를 눌러서 한번에 지울경우에 사용.
		 * isSelecting이 true 일때 cursorPos는 p1이다.<br>
		 *  선택줄일때 p1은 왼쪽 위를 말하고 p2는 오른쪽 아래를 말한다.*/ 
		Point cursorPos;
		String command;
		Object addedInfo;
		/** 선택상태에서 백키나 delete키를 눌러서 한번에 지울경우에 사용*/
		public boolean isSelecting;
		/** 선택상태에서 백키나 delete키를 눌러서 한번에 지울경우에 사용.
		 * isSelecting이 true 일때 cursorPos는 p1이다.<br>
		 *  선택줄일때 p1은 왼쪽 위를 말하고 p2는 오른쪽 아래를 말한다.*/ 
		Point p2;
		/** ReplaceAll에서 빈 스트링("")으로 대체된 경우 null 이 아니다.
		 * replaceAll할때에 검색된 좌표들을 백업한다.*/
		ArrayList listOfFindPos;
		/** replaceAll할때에 replace 된 좌표들을 백업한다.*/
		ArrayList listOfReplacePos;
	}
	ArrayList buffer = new ArrayList(50);
	ArrayList arrayCursorPos = new ArrayList(50);
	ArrayListString bufferCommand = new ArrayListString(50);
	private ArrayList arrayAddedInfo = new ArrayList(50);
	ArrayList arrayIsSelecting = new ArrayList(50);
	ArrayList arrayPointP2 = new ArrayList(50);
	private ArrayList arrayListOfFindPos = new ArrayList(50);
	private ArrayList arrayListOfReplacePos = new ArrayList(50);
	
	void reset() {
		buffer.reset();
		arrayCursorPos.reset();
		bufferCommand.destroy();
		arrayAddedInfo.reset();
		arrayIsSelecting.reset();
		arrayPointP2.reset();
		arrayListOfFindPos.reset();
		arrayListOfReplacePos.reset();
	}
	
	void push(Point cursorPos, TextLine text, String charA) {
		buffer.add(text);
		arrayCursorPos.add(cursorPos);
		bufferCommand.add(charA);
		arrayAddedInfo.add(null);
		arrayIsSelecting.add(null);
		arrayPointP2.add(null);
		arrayListOfFindPos.add(null);
		arrayListOfReplacePos.add(null);
	}
	void push(Point cursorPos, TextLine text, String charA, Object addedInfo) {
		buffer.add(text);
		arrayCursorPos.add(cursorPos);
		bufferCommand.add(charA);
		arrayAddedInfo.add(addedInfo);
		arrayIsSelecting.add(null);
		arrayPointP2.add(null);
		arrayListOfFindPos.add(null);
		arrayListOfReplacePos.add(null);
	}
	void push(Point cursorPos, TextLine text, String charA, Object addedInfo, boolean isSelecting, Point p2) {
		buffer.add(text);
		arrayCursorPos.add(cursorPos);
		bufferCommand.add(charA);
		arrayAddedInfo.add(addedInfo);
		arrayIsSelecting.add(new Boolean(isSelecting));
		arrayPointP2.add(p2);
		arrayListOfFindPos.add(null);
		arrayListOfReplacePos.add(null);
	}
	
	void push(Point cursorPos, TextLine text, String charA, Object addedInfo, boolean isSelecting, Point p2, ArrayList listFindPos) {
		buffer.add(text);
		arrayCursorPos.add(cursorPos);
		bufferCommand.add(charA);
		arrayAddedInfo.add(addedInfo);
		arrayIsSelecting.add(new Boolean(isSelecting));
		arrayPointP2.add(p2);
		arrayListOfFindPos.add(listFindPos);
		arrayListOfReplacePos.add(null);
	}
	void push(Point cursorPos, TextLine text, String charA, Object addedInfo, boolean isSelecting, Point p2, ArrayList listFindPos, ArrayList listReplacePos) {
		buffer.add(text);
		arrayCursorPos.add(cursorPos);
		bufferCommand.add(charA);
		arrayAddedInfo.add(addedInfo);
		arrayIsSelecting.add(new Boolean(isSelecting));
		arrayPointP2.add(p2);
		arrayListOfFindPos.add(listFindPos);
		arrayListOfReplacePos.add(listReplacePos);
	}
	RedoBufferOfEditRichText.Pair pop() {
		RedoBufferOfEditRichText.Pair pair = new RedoBufferOfEditRichText.Pair();
		pair.text = (TextLine) buffer.getItem(buffer.count-1);
		pair.cursorPos = (Point)arrayCursorPos.getItem(arrayCursorPos.count-1);			
		String command = bufferCommand.getItem(bufferCommand.count-1);
		pair.command = command;
		pair.addedInfo = arrayAddedInfo.getItem(arrayAddedInfo.count-1);
		Boolean b = (Boolean) arrayIsSelecting.getItem(arrayIsSelecting.count-1);
		if (b!=null) {
			pair.isSelecting = b.booleanValue();
		}
		pair.p2 = (Point) arrayPointP2.getItem(arrayPointP2.count-1);
		pair.listOfFindPos = (ArrayList) arrayListOfFindPos.getItem(arrayListOfFindPos.count-1);
		pair.listOfReplacePos = (ArrayList) arrayListOfReplacePos.getItem(arrayListOfReplacePos.count-1);
		buffer.count--;
		arrayCursorPos.count--;
		bufferCommand.count--;
		arrayAddedInfo.count--;
		arrayIsSelecting.count--;
		arrayPointP2.count--;
		arrayListOfFindPos.count--;
		arrayListOfReplacePos.count--;
		return pair;
	}
}
