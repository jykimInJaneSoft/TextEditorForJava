package com.gsoft.common.gui;


import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Point;

import com.gsoft.common.Events.MotionEvent;
import com.gsoft.common.Sizing.Rectangle;
import com.gsoft.common.Sizing.Size;
import com.gsoft.common.Sizing.SizeF;
import com.gsoft.common.interfaces.OnTouchListener;
import com.gsoft.common.gui.MenuWithScrollBar.ButtonLine;
import com.gsoft.common.gui.Buttons.Button;
import com.gsoft.common.gui.edittext.Edit.ScrollMode;
import com.gsoft.common.util.Util.Math;

import com.gsoft.common.gui.MenuWithScrollBar;
import com.gsoft.common.gui.Control;


@SuppressWarnings("unused")
public class MenuWithScrollBarWithMoveButton extends MenuWithScrollBar implements OnTouchListener {
	
	
	
	private Button buttonMove;


	/** MenuClassList에서 바운드가 바뀔때 사용, 
	 * buttonSize가 originButtonWidth, originButtonHeight가 된다.*/
	public void changeBounds(Rectangle bounds, Size buttonSize) {
		super.changeBounds(bounds, buttonSize);
	}
	
	public void changeBounds(Rectangle bounds) {
		super.changeBounds(bounds);
	}
	
	
	
	public MenuWithScrollBarWithMoveButton(Object owner, Rectangle bounds, Size buttonSize,
			ScrollMode scrollMode) {
		super(owner, bounds, buttonSize, scrollMode);
		
	}
	
	public void setButtons(Button[] buttons) {
		super.setButtons(buttons);
		if (this.buttonMove==null) {
			Rectangle buttonBounds = new Rectangle(0, 0, 
					(int)((this.bounds.width-this.originButtonWidth)*0.4f), this.originButtonHeight);
			this.buttonMove = new Button(this, "Move", "Move", Color.RED, buttonBounds, 
            		false, 255, false, 0.0f, null, Color.LTGRAY);
			this.buttonMove.setBackColor(Color.CYAN);
			this.buttonMove.setOnTouchListener(this);
			this.buttonMove.setIsOpen(false);
		}
		else {
			this.buttonMove.setIsOpen(false);
		}
	}
	
	
	
	public void draw(Canvas canvas) {
		super.draw(canvas);
    	
    	if (this.buttonMove!=null) {
    		this.buttonMove.draw(canvas);
    	}
    
	}
	
	
	@Override
    public boolean onTouch(MotionEvent event, SizeF scaleFactor) {
		boolean r=false;
    	if (event.actionCode==MotionEvent.ActionDown || event.actionCode==MotionEvent.ActionDoubleClicked) {
    		if (hides || !IsPointIn(new Point(event.x, event.y))) 
    			return false;
	    	if (buttons==null || buttons.length==0) return false;
	    	int i, j;
	    	if (scrollMode==ScrollMode.VScroll) {
	    		boolean r1=false;
				r1 = vScrollBar.onTouch(event, null);
				if (r1) {
					return true;
				}
				
				if (this.buttonMove!=null && !this.buttonMove.getHides()) {
		    		r = this.buttonMove.onTouch(event, scaleFactor);
		    		if (r) {
		    			return true;
		    		}
		    	}
						
				
	    		// 한 번 그린 뒤에(draw에서 vScrollPos에 따라 Button들의 영역을 다시 계산한다)
	    		// 터치를 하므로 다음과 같이 하는 것이 가능하다. 다시 계산된 버튼들의 영역을 바탕으로 터치 이벤트를 전달한다.
				int limit = Math.min(vScrollPos+numOfLinesPerPage, this.numOfLines);
				for (i=vScrollPos; i<limit; i++) {
					//if (y < bounds.y+bounds.height) {
						ButtonLine buttonLine = linesOfButtons[i];						
						for (j=0; j<buttonLine.count; j++) {
							r = buttonLine.buttons[j].onTouch(event, null);
							if (r) {
								if (buttonLine.buttons[j].getIsSelected()) {
									buttonsOfSelect.add(buttonLine.buttons[j]);
								}
								return true;
							}
						}
					//}
				}
				
				// MenuScrollable영역안에서 스크롤바와 버튼들을 제외한 공백영역을 터치시
				// 선택된 버튼을 원래대로 초기화한다.
				for (i=0; i<buttonsOfSelect.count; i++) {
					Button button = (Button)buttonsOfSelect.getItem(i);
					button.Select(false);
				}
				buttonsOfSelect.reset();
				
				Control.capturedControl = this;
				
				onTouchEvent(this, event);
				
				oldDownPoint.x = event.x;
				oldDownPoint.y = event.y;
				oldMoveTime = System.currentTimeMillis();
				
	    	}//if (scrollMode==ScrollMode.VScroll) {
	    	
	    	return true;
    	}
    	else if (event.actionCode==MotionEvent.ActionMove) {
    		if (this==Control.capturedControl) {
    			// 영역내에서 터치를 하여 캡쳐를 하면 CustomView에서 ActionMove를 전달하여 스크롤을 하게 된다.
    			// 영역검사를 하지않고 영역을 벗어나더라도 자신이 핸들링한다.
    			onTouchEvent(this, event);
				return true;
			}
    	}
    	return false;
    	
    	
    }

	
	@Override
	public void onTouchEvent(Object sender, MotionEvent e) {
			
		if (this.buttonMove!=null) {
			this.buttonMove.setIsOpen(false);
		}
		
		if (sender instanceof Button) { // 버튼 터치시 호출된다.
			Button button = (Button)sender;
			if (button.iName!=this.buttonMove.iName) {
				int i;
				for (i=0; i<buttons.length; i++) {
					if (button.iName==buttons[i].iName) {
						selectedButtonName = button.name;
						selectedButton = button;
						
						this.buttonMove.addedInfo = selectedButton.addedInfo;
					
						this.buttonMove.bounds.x = selectedButton.bounds.right()+5;
						this.buttonMove.bounds.y = selectedButton.bounds.y;
						this.buttonMove.changeBounds(this.buttonMove.bounds);
						this.buttonMove.setIsOpen(true);							
						listener.onTouchEvent(this, e);
						return;
					}
				}
			}
			else {
				// buttonMove clicked
				selectedButtonName = button.name;
				selectedButton = button;
				button.setHides(true);
				if (listener!=null) {
					listener.onTouchEvent(this, e);
				}
			}
			return;
		}
		
		super.onTouchEvent(sender, e);
	}//onTouchEvent()

	public void destroy() {
		
		if (this.buttonMove!=null) {
			this.buttonMove.destroy();
			this.buttonMove = null;
		}
	}
}
