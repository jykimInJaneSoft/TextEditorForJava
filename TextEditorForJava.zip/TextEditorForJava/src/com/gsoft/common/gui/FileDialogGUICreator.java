package com.gsoft.common.gui;

import android.graphics.Color;
import android.view.View;

import com.gsoft.common.Sizing.Rectangle;
import com.gsoft.common.Sizing.Size;
import com.gsoft.common.gui.Buttons.Button;
import com.gsoft.common.gui.Menu.MenuType;

import com.gsoft.common.gui.FileDialog;
import com.gsoft.common.gui.Control;
import com.gsoft.common.gui.MenuWithClosable;
import com.gsoft.common.gui.ConnectDialog;
import com.gsoft.common.gui.MessageDialog;

public class FileDialogGUICreator {
	FileDialog owner;
	View view;
	
	FileDialogGUICreator(FileDialog owner) {
		this.owner = owner;
		this.view = Control.view;
	}
	
	void createMenuTextFormat(boolean changeBounds) {		
		int viewWidth = view.getWidth();
		int viewHeight = view.getHeight();
		int x, y;
		int width=(int) (viewWidth*0.6f);
		int height=(int) (viewHeight*0.3f);
		x = viewWidth/2-width/2;
		y = viewHeight/2-height/2;
		Rectangle boundsMenuTextSaveFormat = new Rectangle(x,y,width,height);
		if (!changeBounds) {
			owner.menuTextFormat = new MenuWithClosable("MenuTextFormat", boundsMenuTextSaveFormat, 
				MenuType.Vertical, this, FileDialog.namesOfMenuTextFormat, new Size(3,3), true, owner);
		}
		else {
			owner.menuTextFormat.changeBounds(boundsMenuTextSaveFormat);
		}
	}
	
	void createConnectDialog(boolean changeBounds) {
		Rectangle boundsOfConnectDialog = new Rectangle(owner.bounds.x, owner.bounds.y, 
				(int)(view.getWidth()*0.9f), (int)(view.getHeight()*0.4f));
		boundsOfConnectDialog.x = view.getWidth()/2 - boundsOfConnectDialog.width/2;
		
		if (!changeBounds) {
			owner.connectDialog = new ConnectDialog(view, boundsOfConnectDialog);
		}
		else {
			owner.connectDialog.changeBounds(boundsOfConnectDialog);
		}
		
	}
	
	void createMenuCRLF(boolean changeBounds) {
		int viewWidth = view.getWidth();
		int viewHeight = view.getHeight();
		int x, y;
		int width=(int) (viewWidth*0.5f);
		int height=(int) (viewHeight*0.25f);
		x = viewWidth/2-width/2;
		y = viewHeight/2-height/2;
		Rectangle boundsMenuCRLF = new Rectangle(x,y,width,height);
		if (!changeBounds) {
			owner.menuCRLF = new MenuWithClosable("CRLF", boundsMenuCRLF, 
					MenuType.Vertical, this, FileDialog.namesOfMenuCRLF, new Size(3,3), true, owner);		
		}
		else {
			owner.menuCRLF.changeBounds(boundsMenuCRLF);
		}
	}

	void createMenuDir(boolean changeBounds) {
		int viewWidth = view.getWidth();
		int viewHeight = view.getHeight();
		int x, y;
		int width=(int) (viewWidth*0.6f);
		int height=(int) (viewHeight*0.35f);
		x = viewWidth/2-width/2;
		y = viewHeight/2-height/2;
		Rectangle boundsMenuDir = new Rectangle(x,y,width,height);
		if (!changeBounds) {
			owner.menuDir = new MenuWithClosable("MenuDir", boundsMenuDir, 
					MenuType.Vertical, this, FileDialog.namesOfMenuDir, new Size(3,3), true, owner);		
		}
		else {
			owner.menuDir.changeBounds(boundsMenuDir);
		}
	}
	
	void createMenuFunc(boolean changeBounds) {
		int widthButton = (int) (0.08f * view.getWidth());
		int heightButton = (int) (owner.scaleOfTitleBarY * owner.bounds.height);
		Rectangle srcBoundsButton = new Rectangle(owner.bounds.x, owner.bounds.y, widthButton, heightButton);
		if (!changeBounds) {				
			owner.buttonMultiSelect = new Button(this, "MultiSelect", "MultiSelect", Color.CYAN, srcBoundsButton, 
            		false, 255, false, 0.0f, null, Color.LTGRAY);
			owner.buttonMultiSelect.toggleable = true;
			owner.buttonMultiSelect.setOnTouchListener(owner);
		}
		else {
			owner.buttonMultiSelect.changeBounds(srcBoundsButton);
		}
		
		int viewWidth = view.getWidth();
		int viewHeight = view.getHeight();
		int x, y;
		int width=(int) (viewWidth*0.6f);
		int height=(int) (viewHeight*0.8f);
		x = viewWidth/2-width/2;
		y = viewHeight/2-height/2;
		Rectangle boundsMenuFunc = new Rectangle(x,y,width,height);
		if (!changeBounds) {
			owner.menuFunc = new MenuWithClosable("MenuFunc", boundsMenuFunc, 
					MenuType.Vertical, owner, FileDialog.namesOfMenuFunc, new Size(3,3), true, owner);
			
			owner.menuFunc.buttons[8].selectable = false;	// MultiSelect 메뉴는 토글로 동작한다.
			owner.menuFunc.buttons[8].toggleable = true;
			owner.menuFunc.buttons[8].ColorSelected = Color.YELLOW;
		}
		else {
			owner.menuFunc.changeBounds(boundsMenuFunc);
		}
		
		/*menuFunc.buttons[9].selectable = true;	// Sound Control Menu 메뉴는 토글로 동작한다.
		menuFunc.buttons[9].toggleable = true;
		menuFunc.buttons[9].ColorSelected = Color.YELLOW;*/
	}
	
	
	void createMenuHelp(boolean changeBounds) {
		int viewWidth = view.getWidth();
		int viewHeight = view.getHeight();
		int x, y;
		int width=(int) (viewWidth*0.6f);
		int height=(int) (viewHeight*0.5f);
		x = viewWidth/2-width/2;
		y = viewHeight/2-height/2;
		Rectangle boundsMenuMultimedia = new Rectangle(x,y,width,height);
		if (!changeBounds) {
			owner.menuHelp = new MenuWithClosable("menuHelp", boundsMenuMultimedia, 
				MenuType.Vertical, owner, FileDialog.namesOfMenuHelp, new Size(3,3), true, owner);
		}
		else {
			owner.menuHelp.changeBounds(boundsMenuMultimedia);
		}
		
	
	}
	
	void createMenuMultimedia(boolean changeBounds) {
		int viewWidth = view.getWidth();
		int viewHeight = view.getHeight();
		int x, y;
		int width=(int) (viewWidth*0.6f);
		int height=(int) (viewHeight*0.75f);
		x = viewWidth/2-width/2;
		y = viewHeight/2-height/2;
		Rectangle boundsMenuMultimedia = new Rectangle(x,y,width,height);
		if (!changeBounds) {
			owner.menuMultimedia = new MenuWithClosable("menuMultimedia", boundsMenuMultimedia, 
				MenuType.Vertical, owner, FileDialog.namesOfMenuMultimedia, new Size(3,3), true, owner);
		
			owner.menuMultimedia.buttons[5].selectable = true;	// Record sound 메뉴는 토글로 동작한다.
			owner.menuMultimedia.buttons[5].toggleable = true;
			owner.menuMultimedia.buttons[5].ColorSelected = Color.YELLOW;
		}
		else {
			owner.menuMultimedia.changeBounds(boundsMenuMultimedia);
		}
	
	}
	
	/** Send a File메뉴를 통해서 FileDialog에 접근하는 방법으로만 menuFileType을 생성하고 
	 * 다른 방법으로는 이것을 생성하지 않는다. 즉 다른 방법으로는 이 메서드를 호출하지 않는다.
	 */
	public void createMenuFileType(boolean changeBounds) {
		//if (menuFileType!=null) return; // 한 번만 생성한다.
		
		int viewWidth = view.getWidth();
		int viewHeight = view.getHeight();
		int x, y;
		int width=(int) (viewWidth*0.6f);
		int height=(int) (viewHeight*0.6f);
		x = viewWidth/2-width/2;
		y = viewHeight/2-height/2;
		Rectangle boundsMenuFileType = new Rectangle(x,y,width,height);
		if (!changeBounds) {
			owner.menuFileType = new MenuWithClosable("MenuFileType", boundsMenuFileType, 
				MenuType.Vertical, owner, FileDialog.namesOfMenuFileType, new Size(3,3), true, owner);
		}
		else {
			owner.menuFileType.changeBounds(boundsMenuFileType);
		}
	}
	
	public void createMenuSort(boolean changeBounds) {
		
		int viewWidth = view.getWidth();
		int viewHeight = view.getHeight();
		int x, y;
		int width=(int) (viewWidth*0.65f);
		int height=(int) (viewHeight*0.5f);
		x = viewWidth/2-width/2;
		y = viewHeight/2-height/2;
		Rectangle boundsMenuSort = new Rectangle(x,y,width,height);
		if (!changeBounds) {
			owner.menuSort = new MenuWithClosable("MenuSort", boundsMenuSort, 
				MenuType.Vertical, owner, FileDialog.namesOfMenuSort, new Size(3,3), true, owner);
		}
		else {
			owner.menuSort.changeBounds(boundsMenuSort);
		}
	}
	
	void createMessageDialog(boolean changeBounds) {
		
		int viewWidth = view.getWidth();
		int viewHeight = view.getHeight();
		int x, y;
		int width=(int) (viewWidth*0.7f);
		int height=(int) (viewHeight*0.6f);
		x = viewWidth/2-width/2;
		y = viewHeight/2-height/2;
		Rectangle boundsMessageDialog = new Rectangle(x,y,width,height);
		if (!changeBounds) {
			owner.messageDialog = new MessageDialog(view, boundsMessageDialog);
			owner.messageDialog.setOnTouchListener(owner);
		}
		else {
			owner.messageDialog.changeBounds(boundsMessageDialog);
		}
	}	
}