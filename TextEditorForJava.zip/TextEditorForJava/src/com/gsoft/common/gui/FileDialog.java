package com.gsoft.common.gui;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.util.Random;

import android.graphics.Canvas;
import android.graphics.Color;
import android.net.wifi.WifiInfo;
import android.os.Environment;
import android.util.Log;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.ColorEx;
import com.gsoft.common.CommonGUI;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.Events.MotionEvent;
import com.gsoft.common.FileHelper;
import com.gsoft.common.FileHelper.SizeAndCount;
import com.gsoft.common.IO;
import com.gsoft.common.IO_types;
import com.gsoft.common.IO_types.TextFormat;
import com.gsoft.common.MultiMedia;
import com.gsoft.common.MultiMedia.MediaPlayerDel;
import com.gsoft.common.MultiMedia.MediaPlayerDel.PlayListAndCurSongInfo;
import com.gsoft.common.MultiMedia.MediaRecorderDel;
import com.gsoft.common.Net.ServiceThread;
import com.gsoft.common.Net.Wifi;
import com.gsoft.common.Net.WifiThread;
import com.gsoft.common.PowerManagement;
import com.gsoft.common.Sizing.Rectangle;
import com.gsoft.common.Sizing.Size;
import com.gsoft.common.Sizing.SizeF;
import com.gsoft.common.interfaces.OnTouchListener;
import com.gsoft.common.R.R;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.gui.Buttons.Button;
import com.gsoft.common.gui.Buttons.ButtonGroup;
import com.gsoft.common.gui.Dialog.EditableDialog;
import com.gsoft.common.gui.Pool.PoolOfButton;
import com.gsoft.common.gui.edittext.Edit.ScrollMode;
import com.gsoft.common.gui.edittext.EditText;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListString;
import com.gsoft.common.util.Util;


import com.gsoft.common.gui.MenuWithScrollBar;
import com.gsoft.common.gui.MenuWithClosable;
import com.gsoft.common.gui.IntegrationKeyboard;
import com.gsoft.common.gui.FileDialogGUICreator;
import com.gsoft.common.gui.TextView;
import com.gsoft.common.gui.Control;
import com.gsoft.common.gui.FileDialogEventHandler;
import com.gsoft.common.gui.MessageDialog;
import com.gsoft.common.gui.ConnectDialog;
import com.gsoft.common.gui.Dialog;



public class FileDialog extends EditableDialog implements OnTouchListener {
	//IntegrationKeyboard keyboard = Control.keyboard;
	String charA;
	
	String[] fileList;
	String[] oldFileList;
	public EditText editTextDir;
	public String filename;
	
	public MenuWithScrollBar menuFileList;
	
	public Button buttonCRLF;
	
	public Button buttonSaveToCurFile;
	public Button buttonSaveAll;
	public Button buttonConvertAllInProject;
	
	public EditText editTextFilename;
	
	Button buttonDir;
	Button buttonCategory;
	Button buttonTextFormat;
	Button buttonFunc;
	Button buttonMultimedia;
	
	
	Button buttonOnOff;
	
	Size mButtonSize  = new Size((int)(Control.view.getWidth()*0.35f),(int)(Control.view.getHeight()*0.06f));
		
	
	float scaleOfTitleBarY = 0.13f;
	
	
	
	// 버튼:5개, gapX:7개, editTextDir버튼:나머지버튼들의 4배, gapX는 동일크기이고 나머지 버튼의 0.1, 
	// 나머지 버튼 : x
	// 4x(editTextDir) + 5x + 0.1*x*7 = 1, 9.7x = 1, x= 1/9.7
	
	float scaleOfCategoryX = 1 / 9.7f;
	float scaleOfCategoryY = 0.13f;
	
	float scaleOfFilenameX = scaleOfCategoryX * 4;
	float scaleOfFilenameY = 0.13f;
	
	float scaleOfGapX = scaleOfCategoryX * 0.1f;
	
	float scaleOfMenuFileListX = 1-scaleOfGapX*2;
	float scaleOfMenuFileListY = 0.3f;
	
	float scaleOfeditTextDirX = 1-scaleOfGapX*2;
	float scaleOfeditTextDirY = 0.18f;
		
	float scaleOfOKButtonX = (1-scaleOfGapX*3) / 2;
	float scaleOfOKButtonY = 0.13f;
	
	// 6는 gap개수
	float scaleOfGapY = (1-(scaleOfTitleBarY+scaleOfMenuFileListY+scaleOfFilenameY+
			scaleOfeditTextDirY+scaleOfOKButtonY)) / 6;
	
	//private boolean WasKeyboardHiddenBeforeOpen;
	private Rectangle boundsOfMenuFileList;
	OnTouchListener oldKeyboardListener;
	
	/**reading을 위한 것이면 1, saving을 위한 것이면 2, 해당 없으면 0*/
	private int isForReadingOrSaving;
	
	/*public enum Dir {
		Context, Asset, CurDir
	};*/	
	
	public enum Category {
		Image, Text, Custom, Music, Video, All, Compression
	};
	
	String toString(Category category) {
		String r=null;
		if (category==Category.Image) r="Image";
		else if (category==Category.Text) r="Text";
		else if (category==Category.Custom) r="Custom";
		else if (category==Category.Music) r="Music";
		else if (category==Category.Video) r="Video";
		else if (category==Category.All) r="All";
		else if (category==Category.Compression) r="Compression";
		return r;
	}
	
	
	
	//Dir dir = Dir.Context;	
	
	String curPartision = "";
	private String curDir = FileHelper.getPartitionName() + File.separator;
	
	/** curDir이 /으로 끝나지 않으면 /을 붙인다. setCurDir()을 참조한다.*/
	public String getCurDir(boolean addsSeparatorAtLast) {
		if (this.curDir.equals(File.separator)) {
			return this.curDir;
		}
		if (addsSeparatorAtLast) {
			if (this.curDir.length()>0 && this.curDir.charAt(this.curDir.length()-1)==File.separatorChar) {
				return this.curDir;
			}
			else {
				return this.curDir+File.separator;
			}
		}
		else {
			if (this.curDir.length()>0 && this.curDir.charAt(this.curDir.length()-1)==File.separatorChar) {
				return this.curDir.substring(0, this.curDir.length()-1);
			}
			else {
				return this.curDir;
			}
		}
		
	}
	
	public FileDialogGUICreator fileDialogGUICreator;
	public FileDialogEventHandler fileDialogEventHandler;
	
	public Category category = Category.Custom;
	
	MenuWithClosable menuCRLF;
	MenuWithClosable menuDir;
	public MenuWithClosable menuTextFormat;
	
	static String[] partitionSymbols = FileHelper.getPartitionSymbols();
	
	public static String Separator = File.separator;
	
	public static String[] namesOfMenuCRLF = {
		"Original", 
		"CRLF", 
		"LF"
	};
	
	public static String[] namesOfMenuDir = {
		Control.res.getString(R.string.file_dir_app),
		Control.res.getString(R.string.file_dir_root), 
		"Go to project dir", "Go to SDK dir",
		"Unzip the SDK files(gsoft.zip, project.zip)"
		};
	
	public MenuWithClosable menuFunc;	
	public static String[] namesOfMenuFunc = {/*"Make Dir", "Delete", "Rename", 
		"Cut", "Copy", "Paste", "MultiSelect", "Sort", "Properties"*/
		Control.res.getString(R.string.file_func_mkdir), "MkFile", Control.res.getString(R.string.file_func_del),
		Control.res.getString(R.string.file_func_ren), Control.res.getString(R.string.file_func_cut),
		Control.res.getString(R.string.file_func_copy), Control.res.getString(R.string.file_func_paste),
		"Privillage", 
		Control.res.getString(R.string.file_func_multiselect), Control.res.getString(R.string.file_func_sort),
		"Storage", Control.res.getString(R.string.file_func_properties)};
	
	/** Media 버튼을 눌렀을때 나오는 메뉴*/
	MenuWithClosable menuMultimedia;	
	public static String[] namesOfMenuMultimedia = {
		/*"Send a file(s)", "Start receiver", 
		"Listen to music", "Watch video", "Record sound", "Play record", 
		"Sound Control Menu"*/
		Control.res.getString(R.string.file_media_send), Control.res.getString(R.string.file_media_receiver),
		Control.res.getString(R.string.file_media_music), Control.res.getString(R.string.file_media_video),
		"Install a package",
		Control.res.getString(R.string.file_media_record), Control.res.getString(R.string.file_media_play_record),
		Control.res.getString(R.string.file_media_sound_menu), Control.res.getString(R.string.file_media_help_menu)
		};
	
	/** Help 버튼을 눌렀을때 나오는 메뉴*/
	MenuWithClosable menuHelp;
	public static String[] namesOfMenuHelp = {
		"How to play music", "How to transfer files", "How to view a java file", "How to view a class file"
	};
	
	MenuWithClosable menuFileType;	
	public static String[] namesOfMenuFileType = {"Image", "Text", "Custom", "Music", "Video", "Compression", "All"};
	
	MenuWithClosable menuSort;	
	public static String[] namesOfMenuSort = {/*"Sort by name, ascending", "Sort by name, descending",
		"Sort by time, ascending", "Sort by time, descending"*/
		Control.res.getString(R.string.file_sort_name_ascend), Control.res.getString(R.string.file_sort_name_descend),
		Control.res.getString(R.string.file_sort_time_ascend), Control.res.getString(R.string.file_sort_time_descend)};
	
	
	public static String[] namesOfMenuTextFormat = {"UTF-8", "UTF-16", "MS-949"};
	
	public static class SortByTime {
		public long modifiedTime;
		String filename;
		SortByTime(long modifiedTime, String filename) {
			this.modifiedTime = modifiedTime;
			this.filename = filename;
		}
	}
	
	
	
	public enum State {
		Normal,
		Delete,
		Rename,
		Cut, Copy, Paste,
		SendFile/*, MultiSelect*/ 
	}
	
	public State state = State.Normal;
	
	MessageDialog messageDialog;
	
	public String mAbsFilename;
	
	ConnectDialog connectDialog;
	
	public boolean canSelectFileType;
	public boolean isForViewing;
	
	/** load/save와 openFileDialog를 구분한다.*/
	public boolean isOpenFileDialog;
	
	PoolOfButton poolOfFileListButtons;
	Button[] fileListButtons;
	boolean isDirectoryOrFileForCutOrCopy;
	/** cut이나 copy한 파일 또는 디렉토리의 파일 리스트, 
	 * 디렉토리의 경우는 ArrayList(File), 파일의 경우는 File이다.*/
	ArrayList fileListOfCutOrCopy; 
	//private ArrayList fileListOfCutOrCopy;
	
	/** 다중선택한 파일리스트, 파일(디렉토리)의 절대경로 스트링을 담는다.*/ 
	public ArrayListString fileListOfMultiSelect = new ArrayListString(10);
	boolean isCutOrCopy;
	
	WifiThread wifiThread;
	private ServiceThread serviceThread;
	
	//SoundPool soundPool = new SoundPool(1, AudioManager.STREAM_MUSIC, 0);
	//SoundPlayer soundPlayer;
	public MediaPlayerDel mediaPlayer = null;
	public boolean isFullScreen;
	MediaRecorderDel recorder;
	ArrayListString mPlayList;
	PlayListAndCurSongInfo playListAndCurSongInfo;
	private Process su;
	private Process data;
	
	/** multiselect를 하기 쉽도록 새로 만들어서 파일다이얼로그를 열때 제목줄에 나타나는 버튼*/
	Button buttonMultiSelect;

	private float scaleOfSingleLineEditTextFontSize = 0.3f;

	/**original=0, CRLF=1, LF=2*/
	public int originalOrCRLFOrLF;

	//IntegrationKeyboard keyboard = CommonGUI.keyboard;

	static TextView textViewLogBird = CommonGUI.textViewLogBird;
	
	
	/**reading을 위한 것이면 1, saving을 위한 것이면 2, 해당 없으면 0*/
	public void setIsForReadingOrSaving(int isForReadingOrSaving) {
		this.isForReadingOrSaving = isForReadingOrSaving;
		if (isForReadingOrSaving==2) {
			editTextFilename.isReadOnly = false;
			//Text = title + " - Load";
		}
		else { 
			editTextFilename.isReadOnly = false;
			//Text = title + " - Save";
		}
	}
	
	/**reading을 위한 것이면 1, saving을 위한 것이면 2, 해당 없으면 0*/
	public int getIsForReadingOrSaving() {
		return isForReadingOrSaving;
	}
	
	/** EditRichText 크기, 또는 전체화면으로 fileDialog를 사용할 때 컨트롤들의 위치와 크기를 
	 * 바꾸기 위해 호출한다. 먼저 isFullScreen을 true,false로 설정한다.*/
	public void setScaleValues() {
		if (isFullScreen) {
			scaleOfTitleBarY = 0.06f;		
			
			
			scaleOfCategoryY = 0.06f;
					
			scaleOfFilenameY = 0.06f;
			
			scaleOfMenuFileListY = 0.6f;		
			
			scaleOfeditTextDirY = 0.08f;			
			
			scaleOfOKButtonY = 0.06f;
			
			// 6는 gap개수
			scaleOfGapY = (1-(scaleOfTitleBarY+scaleOfMenuFileListY+scaleOfFilenameY+
					scaleOfeditTextDirY+scaleOfOKButtonY)) / 6;
		}
		else {
			
			scaleOfTitleBarY = 0.11f;
			
						
			scaleOfCategoryX = 1 / 9.7f;
			scaleOfCategoryY = 0.13f;
			
			scaleOfFilenameX = scaleOfCategoryX * 4;
			scaleOfFilenameY = 0.13f;
			
			scaleOfGapX = scaleOfCategoryX * 0.1f;
			
			scaleOfMenuFileListX = 1-scaleOfGapX*2;
			scaleOfMenuFileListY = 0.3f;
			
			scaleOfeditTextDirX = 1-scaleOfGapX*2;
			scaleOfeditTextDirY = 0.13f;
				
			scaleOfOKButtonX = (1-scaleOfGapX*3) / 2;
			scaleOfOKButtonY = 0.13f;
			
			// 6는 gap개수
			scaleOfGapY = (1-(scaleOfTitleBarY+scaleOfMenuFileListY+scaleOfFilenameY+
					scaleOfeditTextDirY+scaleOfOKButtonY)) / 6;
		}
	}
	
		
	boolean equals(String[] oldFileList, String[] fileList) {
		if (oldFileList==null) return false;
		if (oldFileList.length!=fileList.length) return false;
		int i, j;
		boolean[] arrayEqual = new boolean[oldFileList.length];
		for (i=0; i<oldFileList.length; i++) {
			for (j=0; j<fileList.length; j++) {
				if (oldFileList[i].equals(fileList[j])) {
					arrayEqual[i] = true;
					break;
				}
			}
			if (j==fileList.length) return false;
		}
		return true;
	}
	
	
	
	
	
	/**filtering by directory and category*/
	String[] findFiles(String[] fileList, Category category) {		
		if (fileList==null) return null;
		int i;
		ArrayListString r = new ArrayListString(100);
		try {
			for (i=0; i<fileList.length; i++) {
				String filename = fileList[i].toLowerCase();
				String absFilename = getCurDir(true) + filename;
				File file = new File(absFilename);
				if (file.isDirectory()) {
					r.add(fileList[i]);
				}
			}
		}catch(Exception e) {
			Log.e("findFiles-findFile",e.toString());
			e.printStackTrace();
			CompilerHelper.printStackTrace(textViewLogBird , e);
		}
		
		if (category==Category.Image) {			
			for (i=0; i<fileList.length; i++) {
				try{					
				String filename = fileList[i].toLowerCase();
				
				String absFilename = getCurDir(true) + filename;
				File file = new File(absFilename);
				if (file.isDirectory()) continue;
				
				String ext = FileHelper.getExt(filename);
				if (ext==null) continue;
				//if (ext.equals(".bmp") | ext.equals(".png") | ext.equals(".jpg") |
				//		 ext.equals(".gif")) {
				for (int k=0; k<MultiMedia.extensionOfImage.length; k++) {
    				if (ext.contains(MultiMedia.extensionOfImage[k])) {
    					r.add(fileList[i]);
						break;
    				}
				}
				}catch(Exception e) {
					e.printStackTrace();
					CompilerHelper.printStackTrace(textViewLogBird, e);
				}
			}
			return r.getItems();
		}
		else if (category==Category.Text) {
			for (i=0; i<fileList.length; i++) {
				String filename = fileList[i].toLowerCase();
				
				String absFilename = getCurDir(true) + filename;
				File file = new File(absFilename);
				if (file.isDirectory()) continue;
				
				String ext = FileHelper.getExt(filename);
				if (ext==null) continue;
				int k;
				boolean isNotText=false;
				for (k=0; k<MultiMedia.extensionOfImage.length; k++) {
    				if (ext.contains(MultiMedia.extensionOfImage[k])) {
    					isNotText = true;
    					break;
    				}
				}
				if (isNotText) continue;
				for (k=0; k<MultiMedia.extensionOfAudio.length; k++) {
    				if (ext.contains(MultiMedia.extensionOfAudio[k])) {
    					isNotText = true;
    					break;
    				}
				}
				if (isNotText) continue;
				for (k=0; k<MultiMedia.extensionOfVideo.length; k++) {
    				if (ext.contains(MultiMedia.extensionOfVideo[k])) {
    					isNotText = true;
    					break;
    				}
				}
				if (isNotText) continue;
				/*if (ext.equals(".txt") || ext.equals(".xml") || 
						ext.equals(".htm") || ext.equals(".html") ||
						ext.equals(".h") || ext.equals(".java") || 
						ext.equals(".c") || ext.equals(".cpp") ||
						ext.equals(".sh")) {*/
				r.add(fileList[i]);
				//}
			}
			return r.getItems();
			
		}
		else if (category==Category.Custom) {
			for (i=0; i<fileList.length; i++) {
				String filename = fileList[i].toLowerCase();

				String absFilename = getCurDir(true) + filename;
				File file = new File(absFilename);
				if (file.isDirectory()) continue;

				String ext = FileHelper.getExt(filename);
				if (ext==null) continue;
				if (ext.equals(".kjy")) {
					r.add(fileList[i]);
				}
			}
			return r.getItems();
			
		}
		else if (category==Category.Music) {			
			for (i=0; i<fileList.length; i++) {
				try{
				String filename = fileList[i].toLowerCase();

				String absFilename = getCurDir(true) + filename;
				File file = new File(absFilename);
				if (file.isDirectory()) continue;
				
				String ext = FileHelper.getExt(filename);
				if (ext==null) continue;
				//if (ext.equals(".wav") | ext.equals(".mp3") | ext.equals(".wma")) {
				for (int k=0; k<MultiMedia.extensionOfAudio.length; k++) {
    				if (ext.contains(MultiMedia.extensionOfAudio[k])) {
						//if (count>=r.length) r = Array.Resize(r, r.length+10);
						//r[count++] = fileList[i];
    					r.add(fileList[i]);
						break;
    				}
				}
				}catch(Exception e) {
					e.printStackTrace();
					CompilerHelper.printStackTrace(textViewLogBird, e);
				}
			}
			return r.getItems();
		}
		else if (category==Category.Video) {			
			for (i=0; i<fileList.length; i++) {
				try{
				String filename = fileList[i].toLowerCase();

				String absFilename = getCurDir(true) + filename;
				File file = new File(absFilename);
				if (file.isDirectory()) continue;
				
				String ext = FileHelper.getExt(filename);
				if (ext==null) continue;
				//if (ext.equals(".mp4") | ext.equals(".wmv") | ext.equals(".avi")) {
				for (int k=0; k<MultiMedia.extensionOfVideo.length; k++) {
    				if (ext.contains(MultiMedia.extensionOfVideo[k])) {
    					r.add(fileList[i]);
						break;
    				}
				}
				}catch(Exception e) {
					e.printStackTrace();
					CompilerHelper.printStackTrace(textViewLogBird, e);
				}
			}
			return r.getItems();
		}
		else if (category==Category.Compression) {			
			for (i=0; i<fileList.length; i++) {
				try{
				String filename = fileList[i].toLowerCase();

				String absFilename = getCurDir(true) + filename;
				File file = new File(absFilename);
				if (file.isDirectory()) continue;
				
				String ext = FileHelper.getExt(filename);
				if (ext==null) continue;
				//if (ext.equals(".mp4") | ext.equals(".wmv") | ext.equals(".avi")) {
				for (int k=0; k<MultiMedia.extensionOfCompression.length; k++) {
    				if (ext.contains(MultiMedia.extensionOfCompression[k])) {
    					r.add(fileList[i]);
						break;
    				}
				}
				}catch(Exception e) {
					e.printStackTrace();
					CompilerHelper.printStackTrace(textViewLogBird, e);
				}
			}
			return r.getItems();
		}
		else if (category==Category.All) {
			for (i=0; i<fileList.length; i++) {
				try{
					String filename = fileList[i].toLowerCase();

					String absFilename = getCurDir(true) + filename;
					File file = new File(absFilename);
					if (file.isDirectory()) continue;

					r.add(fileList[i]);
				}catch(Exception e) {
					e.printStackTrace();
					CompilerHelper.printStackTrace(textViewLogBird, e);
				}
			}
			return r.getItems();
			
		}
		
		return fileList;
	}
	
	String[] fileList(String curDir) {
		try {
			File dir = new File(getCurDir(true));
			String[] list = dir.list();
			
			return list;
		}catch(Exception e) {
			e.printStackTrace();
			CompilerHelper.printStackTrace(textViewLogBird, e);
			return null;
		}
	}
	
	/** FileListButtons 의 Pool을 활용하여 디렉토리를 바꿀 때마다 버튼들을 생성하지 않고 메모리를 절약한다.
	 * 즉 디렉토리를 바꾸면 버튼들을 새로 만드는 것이 아니라 pool에서 가져와서 버튼의 속성만 바꿔준다.
	 * (createFileListButtons참조)*/
	void createPoolOfFileListButtons() {
		if (poolOfFileListButtons==null) {
			poolOfFileListButtons = new PoolOfButton(50, mButtonSize);
		}
	}
	
	
	private String[] createFileListButtons(String curDir, Category category) {
		// 윈도우즈(자바)이면 루트에서 up을 클릭할때 파티션들이 나와야한다.
		if (curDir.equals(IO.LocalComputer+File.separator)) {
			editTextDir.setText(0, new CodeString(getCurDir(true), Common_Settings.textColor));
			buttonCategory.setText(toString(Category.All));
			fileList = partitionSymbols;
			fileList = findFiles(fileList, Category.All);
			//return getFileListButtons(fileList);
			return fileList;
		}
		
		buttonCategory.setText(toString(category));
		File dir = new File(getCurDir(true));
		// 현재 디렉토리의 파티션 문자를 얻는다. 그러나 뒤에 separator 가 없어진다.
		//curDir = dir.getAbsolutePath();		
		//dir = new File(curDir);
		editTextDir.setText(0, new CodeString(dir.getAbsolutePath(), this.editTextDir.textColor));
		editTextDir.hScrollPosToLast(0);
		
	
		
		this.curDir = curDir;
		this.setCurDir(curDir);
		this.category = category;		
		
		
		try{
			//Log.d("createFileListButtons", curDir+", "+category);
		fileList = fileList(curDir);
		fileList = findFiles(fileList, category);
		}catch(Exception e) {
			e.printStackTrace();
			CompilerHelper.printStackTrace(textViewLogBird, e);
			return null;
		}
		
		return fileList;
		//return getFileListButtons(fileList);
		
	
	}
	
	Button[] getFileListButtons(String[] fileList) {
		//try {
		int buttonCount;
		if (fileList==null) buttonCount = 1;
		else if (curDir.equals(IO.LocalComputer+File.separator)) {
			buttonCount = fileList.length;
		}
		else buttonCount = 1+fileList.length;
		
				
		int i;
		int buttonWidth = menuFileList.originButtonWidth;
		int buttonHeight = menuFileList.originButtonHeight;
		if (poolOfFileListButtons.list.capacity<buttonCount) {
			poolOfFileListButtons.setCapacity(buttonCount, mButtonSize);
		}
		
		
		Button[] buttons = new Button[buttonCount];
		
		if (!curDir.equals(IO.LocalComputer+File.separator)) {
			//buttons[0] = new Button(owner, "Up", "..", Color.YELLOW, 
			//		buttonBounds, false, 255, true, 0);
			buttons[0] = (Button) poolOfFileListButtons.getItem(0);
			buttons[0].isManualOrAutoSize = true;
			buttons[0].name = "Up";
			buttons[0].bounds.x = 0;
			buttons[0].bounds.y = 0;
			buttons[0].bounds.width = buttonWidth;
			buttons[0].bounds.height = buttonHeight;			
			buttons[0].setBackColor(Color.BLUE);
			buttons[0].selectable = true;
			buttons[0].toggleable = false;
			buttons[0].setIsSelected(false);
			buttons[0].setText("..");
		}
		
		int startIndex;
		
		if (!curDir.equals(IO.LocalComputer+File.separator)) {
			startIndex = 1;			
		}
		else {
			startIndex = 0;
		}
		
		int color;
		for (i=startIndex; i<buttons.length; i++) {
			File file;
			if (!curDir.equals(IO.LocalComputer+File.separator)) {
				file = new File(getCurDir(true) + fileList[i-1]);
				if (file.isDirectory()) color = Color.BLUE;
				else color = Color.YELLOW;
				
				buttons[i] = (Button) poolOfFileListButtons.getItem(i);
				buttons[i].isManualOrAutoSize = true;
				buttons[i].name = fileList[i-1];
				buttons[i].bounds.x = 0;
				buttons[i].bounds.y = 0;
				buttons[i].bounds.width = buttonWidth;
				buttons[i].bounds.height = buttonHeight;				
				buttons[i].setBackColor(color);
				buttons[i].selectable = true;
				buttons[i].toggleable = false;
				buttons[i].setIsSelected(false);
				buttons[i].setText(fileList[i-1]);
			}
			else {
				file = new File(fileList[i]);
				if (file.isDirectory()) color = Color.BLUE;
				else color = Color.YELLOW;
				
				buttons[i] = (Button) poolOfFileListButtons.getItem(i);
				buttons[i].isManualOrAutoSize = true;
				buttons[i].name = fileList[i];
				buttons[i].bounds.x = 0;
				buttons[i].bounds.y = 0;
				buttons[i].bounds.width = buttonWidth;
				buttons[i].bounds.height = buttonHeight;
				buttons[i].setBackColor(color);
				buttons[i].selectable = true;
				buttons[i].toggleable = false;
				buttons[i].setIsSelected(false);
				buttons[i].setText(fileList[i]);
			}
			
		}
		
		ButtonGroup group = new ButtonGroup(null, buttons);
		for (i=0; i<buttons.length; i++) {
			buttons[i].setGroup(group, i);
		}
		
		return buttons;
		
	}
	
	/** curDir이 /으로 끝나지 않으면 /을 붙인다*/
	void setCurDir(String curDirectory) {
		if (curDirectory!=null) {
			if (curDirectory.equals(IO.LocalComputer+File.separator)) {
				curDir = IO.LocalComputer+File.separator;
			}
			else {
				String str = curDirectory.substring(curDirectory.length()-1);
				//Log.d("setCurDir", "str:"+str);
				if (!str.equals(File.separator)) {
					curDir = curDirectory + File.separator;
				}
				else {
					curDir = curDirectory;
				}
			}
		}
		//Log.d("setCurDir", curDir);
	}
	
	public void createAndSetFileListButtons(String curDirectory, Category category) {
		/*Button[] fileList=null;
		
		try {
		setCurDir(curDirectory);
		fileList = createFileListButtons(getCurDir(true), category);
		
		}catch(Exception e) {
			e.printStackTrace();
			CompilerHelper.printStackTrace(textViewLogBird, e);
		}
		try {
		if (menuFileList!=null) {
			menuFileList.setButtons(fileList);
			//Control.setModified(true);
		}
		}catch(Exception e) {
			e.printStackTrace();
			CompilerHelper.printStackTrace(textViewLogBird, e);
		}*/
		setCurDir(curDirectory);
		this.fileList = this.createFileListButtons(curDirectory, category);
		this.fileDialogEventHandler.processEventOfMenuSort(this.menuSort.buttons[0]);
	}
	
	/** 영역만 잡아주고 menuFileList의 내용(Button[])은 나중에 createAndSetFileListButtons를
	 * 통해 넣어준다. 
	 * @param dir
	 * @param curDir
	 * @param category
	 */
	private void createMenuFileList(String curDir, Category category) {
		// fileDialog생성시에 dir은 null로 설정된다.
		//if (dir==null) return;
		if (category!=null) {
			//String[] fileList = createFileListButtons(getCurDir(true), category);
			if (menuFileList==null) {
				menuFileList = new MenuWithScrollBar(owner, boundsOfMenuFileList, 
						mButtonSize, 
						ScrollMode.VScroll);
				menuFileList.setOnTouchListener(this);				
			}
			//menuFileList.setButtons(fileList);
			this.createAndSetFileListButtons(curDir, category);
		}
		else {
			if (menuFileList==null) {
				menuFileList = new MenuWithScrollBar(owner, boundsOfMenuFileList, 
						mButtonSize, 
						ScrollMode.VScroll);
				menuFileList.setOnTouchListener(this);				
			}
		}
		//menuFileList.isOpen = true;
	}
	
	
	
	public void changeBounds(Rectangle paramBounds) {	
		
		this.bounds = paramBounds;
		applySizingBorderOfView(bounds);
		if (!isMaximized()) backUpBounds();
		
		heightTitleBar = (int) (bounds.height * scaleOfTitleBarY);
		
		int heightOfGap = (int)(bounds.height * scaleOfGapY);
		int widthOfGap = (int)(bounds.width * scaleOfGapX);
		
		boundsOfMenuFileList = new Rectangle(bounds.x+widthOfGap, 
				bounds.y+heightTitleBar+heightOfGap, 
				(int)(bounds.width*scaleOfMenuFileListX), (int)(bounds.height*scaleOfMenuFileListY));
		if (menuFileList!=null)
			menuFileList.changeBounds(boundsOfMenuFileList);
				
		Rectangle boundsOfEditTextDir = new Rectangle(bounds.x+widthOfGap, 
				boundsOfMenuFileList.bottom()+heightOfGap, 
				(int)(bounds.width*scaleOfeditTextDirX), (int)(bounds.height*scaleOfeditTextDirY));
		editTextDir.changeBounds(boundsOfEditTextDir);
		editTextDir.changeFontSize(boundsOfEditTextDir.height*scaleOfSingleLineEditTextFontSize);
		
		
		int widthOfbuttonSaveToCurFile = (int) (bounds.width * 0.2f);
		
		Rectangle boundsOfCRLF = 
				new Rectangle(this.menuFileList.vScrollBar.bounds.x-2-widthOfbuttonSaveToCurFile, boundsOfMenuFileList.y, 
						widthOfbuttonSaveToCurFile, (int) (bounds.height * scaleOfFilenameY));
		buttonCRLF.changeBounds(boundsOfCRLF);
		
		Rectangle boundsOfSaveToCurFile = 
				new Rectangle(this.menuFileList.vScrollBar.bounds.x-2-widthOfbuttonSaveToCurFile, buttonCRLF.bounds.bottom(), 
				widthOfbuttonSaveToCurFile, (int) (bounds.height * scaleOfFilenameY));
		buttonSaveToCurFile.changeBounds(boundsOfSaveToCurFile);
		
		Rectangle boundsOfSaveAll = 
				new Rectangle(this.menuFileList.vScrollBar.bounds.x-2-widthOfbuttonSaveToCurFile, buttonSaveToCurFile.bounds.bottom(), 
						widthOfbuttonSaveToCurFile, (int) (bounds.height * scaleOfFilenameY));
		buttonSaveAll.changeBounds(boundsOfSaveAll);
		
		Rectangle boundsOfConvertAllInProject = 
				new Rectangle(this.menuFileList.vScrollBar.bounds.x-2-widthOfbuttonSaveToCurFile, buttonSaveAll.bounds.bottom(), 
						widthOfbuttonSaveToCurFile, (int) (bounds.height * scaleOfFilenameY));
		buttonConvertAllInProject.changeBounds(boundsOfConvertAllInProject);
		
		
		int width = (int) (bounds.width * scaleOfFilenameX);
		int height = (int) (bounds.height * scaleOfFilenameY);
		int x = bounds.x + widthOfGap;
		int y = boundsOfEditTextDir.bottom() + heightOfGap;
		Rectangle boundsOfFilename = new Rectangle(x,y,width,height);
		
		width = (int) (bounds.width * scaleOfCategoryX);
		height = (int) (bounds.height * scaleOfCategoryY);
		x = bounds.x + widthOfGap;
		y = boundsOfEditTextDir.bottom() + heightOfGap;
		Rectangle boundsOfButtonDir = new Rectangle(boundsOfFilename.right()+widthOfGap,y,
				width,height);
		Rectangle boundsOfCategory = new Rectangle(boundsOfButtonDir.right()+widthOfGap,y,
				width,height);
		Rectangle boundsOfTextFormat = new Rectangle(boundsOfCategory.right()+widthOfGap,y,
				width,height);
		
		Rectangle boundsOfFunc = new Rectangle(boundsOfTextFormat.right()+widthOfGap,y,
				width,height);
		Rectangle boundsOfMultimedia = new Rectangle(boundsOfFunc.right()+widthOfGap,y,
				width,height);
		
		width = boundsOfCategory.width;
		height = heightTitleBar;
		Rectangle boundsOfOnOff = new Rectangle(bounds.x+bounds.width-width, bounds.y,
				width,height);
		
		editTextFilename.changeBounds(boundsOfFilename);
		editTextFilename.changeFontSize(boundsOfFilename.height*scaleOfSingleLineEditTextFontSize);
		
		buttonDir.changeBounds(boundsOfButtonDir);
		buttonCategory.changeBounds(boundsOfCategory);
		buttonTextFormat.changeBounds(boundsOfTextFormat);
		buttonFunc.changeBounds(boundsOfFunc);
		buttonMultimedia.changeBounds(boundsOfMultimedia);
		
		buttonOnOff.changeBounds(boundsOfOnOff);
				
			
		width = (int) (bounds.width * scaleOfOKButtonX);
		height = (int) (bounds.height * scaleOfOKButtonY);
		x = bounds.x + widthOfGap;
		y = boundsOfFilename.bottom() + heightOfGap;
		Rectangle boundsOfButtonOK = new Rectangle(x,y,width,height);
		x = boundsOfButtonOK.right() + widthOfGap;
		Rectangle boundsOfButtonCancel = new Rectangle(x,y,width,height);
		
		
		fileDialogGUICreator.createMenuCRLF(true);
		fileDialogGUICreator.createMenuDir(true);
		fileDialogGUICreator.createMenuTextFormat(true);
		
		fileDialogGUICreator.createMenuFunc(true);
		fileDialogGUICreator.createMenuMultimedia(true);
		fileDialogGUICreator.createMenuHelp(true);
		fileDialogGUICreator.createMessageDialog(true);
		
		fileDialogGUICreator.createMenuFileType(true);			
		fileDialogGUICreator.createMenuSort(true);
		
		fileDialogGUICreator.createConnectDialog(true);
		
		((Button)controls[0]).changeBounds(boundsOfButtonOK);		
		((Button)controls[1]).changeBounds(boundsOfButtonCancel);
		
		//connectDialog.changeBounds(bounds);
	}
	
	
	
	
	void createWifiDir() {
		try {
			File wifiDir = new File(Common_Settings.pathWifi);
			if (!wifiDir.exists()) {
				wifiDir.mkdirs();
				/*boolean r = wifiDir.mkdirs();
				if (!r) {
					Control.loggingForNetwork.setText(true, "Can't make '/wifi' directory" , true);
					Control.loggingForNetwork.setHides(false);
				}*/
			}
		}
		catch(Exception e) {
			e.printStackTrace();
			CompilerHelper.printStackTrace(textViewLogBird, e);
		}
	}
	
	
	public FileDialog(/*boolean isFullScreen, boolean canSelectFileType, */Object owner, Rectangle bounds, String[] fileList) {
		super(owner, bounds);
			
		createWifiDir();
		
		try {
				        
		this.fileList = fileList;
		oldFileList = fileList;
		
		this.name = "FileDialog";
		this.isTitleBarEnable = true;
		//this.title = Control.res.getString(R.string.file_explorer_dialog); 
		this.Text = "FileExplorer";
		
		heightTitleBar = (int) (bounds.height * scaleOfTitleBarY);
		
		int heightOfGap = (int)(bounds.height * scaleOfGapY);
		int widthOfGap = (int)(bounds.width * scaleOfGapX);
		int alpha = 255;
		
		int colorOfButton = ColorEx.darkerOrLighter(Color.WHITE, -100);
		
			
		// 영역만 잡아놓고 나중에 Button[]을 넣어준다.
		boundsOfMenuFileList = new Rectangle(bounds.x+widthOfGap, 
				bounds.y+heightTitleBar+heightOfGap, 
				(int)(bounds.width*scaleOfMenuFileListX), (int)(bounds.height*scaleOfMenuFileListY));
		createMenuFileList(null, null);
		
		createPoolOfFileListButtons();
		
		
		
		
		
		// owner속성을 this로 해야 editText.owner 속성으로 키보드에서 EditableDialog를 최대화할 수 있다.		
		Rectangle boundsOfEditTextDir = new Rectangle(bounds.x+widthOfGap, 
				boundsOfMenuFileList.bottom()+heightOfGap, 
				(int)(bounds.width*scaleOfeditTextDirX), (int)(bounds.height*scaleOfeditTextDirY));
		editTextDir = new EditText(false, false, this, "editTextDir", boundsOfEditTextDir, 
				boundsOfEditTextDir.height*scaleOfSingleLineEditTextFontSize, true, 
				new CodeString("", Color.BLACK), 
				ScrollMode.Both, Color.WHITE);
		editTextDir.isReadOnly = true;
		//oldListener = keyboard.setOnTouchListener(editText);
		
		
		int widthOfbuttonSaveToCurFile = (int) (bounds.width * 0.2f);
		
		buttonCRLF = new Button(owner, "", "Menu CRLF", 
				Color.LTGRAY, 
				new Rectangle(this.menuFileList.vScrollBar.bounds.x-2-widthOfbuttonSaveToCurFile, boundsOfMenuFileList.y, 
						widthOfbuttonSaveToCurFile, (int) (bounds.height * scaleOfFilenameY)), 
				false, alpha, false, 0.0f, null, Color.CYAN);
		buttonCRLF.setOnTouchListener(this);
		
		buttonSaveToCurFile = new Button(owner, "", "SaveModfiesToCurFile", 
				Color.GREEN, 
				new Rectangle(this.menuFileList.vScrollBar.bounds.x-2-widthOfbuttonSaveToCurFile, buttonCRLF.bounds.bottom(), 
						widthOfbuttonSaveToCurFile, (int) (bounds.height * scaleOfFilenameY)), 
				false, alpha, false, 0.0f, null, Color.CYAN);
		buttonSaveToCurFile.setOnTouchListener(this);
		//buttonSaveToCurFile.toggleable = true;
		
		
		buttonSaveAll = new Button(owner, "", "SaveAllModfies", 
				Color.GREEN, 
				new Rectangle(this.menuFileList.vScrollBar.bounds.x-2-widthOfbuttonSaveToCurFile, buttonSaveToCurFile.bounds.bottom(), 
						widthOfbuttonSaveToCurFile, (int) (bounds.height * scaleOfFilenameY)), 
				false, alpha, false, 0.0f, null, Color.CYAN);
		buttonSaveAll.setOnTouchListener(this);
		
		buttonConvertAllInProject = new Button(owner, "", "ConvertAllInProject", 
				Color.GREEN, 
				new Rectangle(this.menuFileList.vScrollBar.bounds.x-2-widthOfbuttonSaveToCurFile, buttonSaveAll.bounds.bottom(), 
						widthOfbuttonSaveToCurFile, (int) (bounds.height * scaleOfFilenameY)), 
				false, alpha, false, 0.0f, null, Color.CYAN);
		buttonConvertAllInProject.setOnTouchListener(this);
		
		
		int buttonWidth = (int) (bounds.width * scaleOfFilenameX);
		int buttonHeight = (int) (bounds.height * scaleOfFilenameY);
		int x = bounds.x + widthOfGap;
		int y = boundsOfEditTextDir.bottom() + heightOfGap;
		Rectangle boundsOfFilename = new Rectangle(x,y,buttonWidth,buttonHeight);
		
		buttonWidth = (int) (bounds.width * scaleOfCategoryX);
		buttonHeight = (int) (bounds.height * scaleOfCategoryY);
		x = bounds.x + widthOfGap;
		y = boundsOfEditTextDir.bottom() + heightOfGap;	
		
		Rectangle boundsOfButtonDir = new Rectangle(boundsOfFilename.right()+widthOfGap,y,
				buttonWidth,buttonHeight);
		
		Rectangle boundsOfCategory = new Rectangle(boundsOfButtonDir.right()+widthOfGap,y,
				buttonWidth,buttonHeight);
		
		Rectangle boundsOfTextFormat = new Rectangle(boundsOfCategory.right()+widthOfGap,y,
				buttonWidth,buttonHeight);
		
		Rectangle boundsOfFunc = new Rectangle(boundsOfTextFormat.right()+widthOfGap,y,
				buttonWidth,buttonHeight);
		
		Rectangle boundsOfMultimedia = new Rectangle(boundsOfFunc.right()+widthOfGap,y,
				buttonWidth,buttonHeight);
		
		
		
		buttonWidth = boundsOfCategory.width;
		buttonHeight = heightTitleBar;
		Rectangle boundsOfOnOff = new Rectangle(bounds.x+bounds.width-buttonWidth, bounds.y,
				buttonWidth,buttonHeight);
		
		editTextFilename = new EditText(false, false, this, "editTextFilename", boundsOfFilename, 
				boundsOfFilename.height*scaleOfSingleLineEditTextFontSize, true, 
				new CodeString("", Color.BLACK), 
				ScrollMode.Both, Color.WHITE);
		buttonDir = new Button(owner, "", "Dir", 
				colorOfButton, boundsOfButtonDir, false, alpha, false, 0.0f, null, Color.CYAN);	
		buttonCategory = new Button(owner, "", Control.res.getString(R.string.file_but_category), 
				colorOfButton, boundsOfCategory, false, alpha, false, 0.0f, null, Color.CYAN);		
		buttonFunc = new Button(owner, "", Control.res.getString(R.string.file_but_func), 
				colorOfButton, boundsOfFunc, false, alpha, false, 0.0f, null, Color.CYAN);
		buttonMultimedia = new Button(owner, "", Control.res.getString(R.string.file_but_media), 
				colorOfButton, boundsOfMultimedia, false, alpha, false, 0.0f, null, Color.CYAN);
		buttonTextFormat = new Button(owner, "", /*Control.res.getString(R.string.file_but_media)*/"TextFormat", 
				colorOfButton, boundsOfTextFormat, false, alpha, false, 0.0f, null, Color.CYAN);
		
		buttonOnOff = new Button(owner, "", "On/Off", 
				colorOfButton, boundsOfOnOff, false, alpha, false, 0.0f, null, Color.GREEN);
		
		buttonOnOff.selectable = true;	// OnOff 버튼은 토글로 동작한다.
		buttonOnOff.toggleable = true;
		buttonOnOff.ColorSelected = Color.YELLOW;
		buttonOnOff.setIsSelected(true);
		
		editTextFilename.setOnTouchListener(this);
		
		buttonDir.setOnTouchListener(this);
		buttonCategory.setOnTouchListener(this);
		buttonFunc.setOnTouchListener(this);
		buttonMultimedia.setOnTouchListener(this);
		buttonTextFormat.setOnTouchListener(this);
		
		
		
		buttonOnOff.setOnTouchListener(this);
		
		buttonWidth = (int) (bounds.width * scaleOfOKButtonX);
		buttonHeight = (int) (bounds.height * scaleOfOKButtonY);
		x = bounds.x + widthOfGap;
		y = boundsOfFilename.bottom() + heightOfGap;
		Rectangle boundsOfButtonOK = new Rectangle(x,y,buttonWidth,buttonHeight);
		x = boundsOfButtonOK.right() + widthOfGap;
		Rectangle boundsOfButtonCancel = new Rectangle(x,y,buttonWidth,buttonHeight);		
		
		controls = new Button[2];
		controls[0] = new Button(owner, Dialog.NameButtonOk, Control.res.getString(R.string.OK), 
				colorOfButton, boundsOfButtonOK, false, alpha, true, 0.0f, null, Color.CYAN);
		controls[1] = new Button(owner, Dialog.NameButtonCancel, Control.res.getString(R.string.cancel), 
				colorOfButton, boundsOfButtonCancel, false, alpha, true, 0.0f, null, Color.CYAN);
		// 이벤트를 이 클래스에서 직접 처리
		controls[0].setOnTouchListener(this);
		controls[1].setOnTouchListener(this);
		
		// 대화상자 이벤트를 받는 리스너 설정
		//setOnTouchListener(listener);
		
		this.fileDialogGUICreator = new FileDialogGUICreator(this);
		
		fileDialogGUICreator.createMenuCRLF(false);
		fileDialogGUICreator.createMenuDir(false);
		fileDialogGUICreator.createMenuTextFormat(false);
		
		fileDialogGUICreator.createMenuFunc(false);
		fileDialogGUICreator.createMenuMultimedia(false);
		fileDialogGUICreator.createMenuHelp(false);
		fileDialogGUICreator.createMessageDialog(false);
		
		fileDialogGUICreator.createMenuFileType(false);			
		fileDialogGUICreator.createMenuSort(false);
		
		fileDialogGUICreator.createConnectDialog(false);
		
		this.fileDialogEventHandler = new FileDialogEventHandler(this); 
		
		//buttonMultiSelect.setOnTouchListener(this);
		
		setRootPermission();
		
		if (!isMaximized()) backUpBounds();
		
		}catch(Exception e) {
			e.printStackTrace();
			CompilerHelper.printStackTrace(textViewLogBird, e);
		}
		
	}
	
	public void setRootPermission() {
		/*ProcessBuilder builder = new ProcessBuilder();
		
		//File workingDir = view.getContext().getFilesDir();
		//builder.directory(workingDir);
		String msg = "/system/xbin/su -> ";
		builder.command("/system/xbin/su");
		builder.redirectErrorStream(true);
		if (su==null) {
			try {
				su = builder.start();
				InputStream is = su.getInputStream();
				msg += IO.readString(is, TextFormat.UTF_8);
				Control.loggingForMessageBox.setText(true, msg, false);
				Control.loggingForMessageBox.setHides(false);
			}catch (Exception e) {
				
				Control.loggingForMessageBox.setText(true, "error:"+msg, false);
				Control.loggingForMessageBox.setHides(false);
			}
		}
		
		//String command = "sudo";
		msg += "chmod -R 775 /data -> ";
		String[] commandAndArg = {"chmod", "-R", "775", "/data"};
		builder.command(commandAndArg);
		builder.redirectErrorStream(true);
		Process process=null;
		try {
			process = builder.start();
			InputStream is = process.getInputStream();
			msg += IO.readString(is, TextFormat.UTF_8);
			Control.loggingForMessageBox.setText(true, msg, false);
			Control.loggingForMessageBox.setHides(false);
			
		} catch (Exception e) {
			
			Control.loggingForMessageBox.setText(true, msg, false);
			Control.loggingForMessageBox.setHides(false);
		}
			
		msg += "chmod -R 4775 /data -> ";
		String[] commandAndArg2 = {"chmod", "-R", "4775", "/data"};
		builder.command(commandAndArg2);
		builder.redirectErrorStream(true);
		Process process2 = null;
		try {
			process2 = builder.start();
			InputStream is = process2.getInputStream();
			msg += IO.readString(is, TextFormat.UTF_8);
			Control.loggingForMessageBox.setText(true, msg, false);
			Control.loggingForMessageBox.setHides(false);
			
		} catch (Exception e) {
			
			Control.loggingForMessageBox.setText(true, msg, false);
			Control.loggingForMessageBox.setHides(false);
		}				
		
		msg += "passwd root -> ";
		String[] commandAndArg3 = {"passwd", "root"};
		builder.command(commandAndArg3);
		builder.redirectErrorStream(true);
		Process process3 = null;
		try {
			process3 = builder.start();
			InputStream is = process3.getInputStream();
			msg += IO.readString(is, TextFormat.UTF_8);
			Control.loggingForMessageBox.setText(true, msg, false);
			Control.loggingForMessageBox.setHides(false);
			
		} catch (Exception e) {
			
			Control.loggingForMessageBox.setText(true, msg, false);
			Control.loggingForMessageBox.setHides(false);
		}*/
				
	}
	
	public void getPermission(File file) {
		if (su==null) return;
		//if (su.exitValue()!=1) return;
		
		ProcessBuilder builder = new ProcessBuilder("chmod", "777", file.getAbsolutePath());
		try {
			data = builder.start();
		} catch (IOException e) {
			
		}
		
	}
	
	public void closePermission() {
		if (data!=null) data.destroy();
	}
	
		
	public static PlayListAndCurSongInfo readPlayListAndCurSongInfo(InputStream is) throws Exception {
		IO_types.TextFormat format = com.gsoft.common.IO_types.TextFormat.UTF_8;
		return MediaPlayerDel.readPlayListAndCurSongInfo(is, format);
	}
	
	/** state에 상관없이 playListAndCurSongInfo를 만든다. 
	 * mPlayList는 restorePlaylist()에서 읽어들인 리스트 혹은 listenToMusic에서 갱신된 리스트이다.*/
	public void write(OutputStream os, TextFormat format) throws Exception {
		MediaPlayerDel.write(os, mPlayList, TextFormat.UTF_8);
	}
		
	
	
	
	public void draw(Canvas canvas)
    {
		if (hides) return;
		synchronized(this) {
		try{
		if (!hides) {
	        super.draw(canvas);
	        if (menuFileList!=null/* && menuFileList.isOpen*/)
	        	menuFileList.draw(canvas);
	        editTextDir.draw(canvas);
	        editTextFilename.draw(canvas);
	        
	        buttonDir.draw(canvas);
	        buttonCategory.draw(canvas);
	        buttonTextFormat.draw(canvas);
	        buttonFunc.draw(canvas);
	        buttonMultimedia.draw(canvas);
	        
	        buttonOnOff.draw(canvas);
	        
	       
	        this.buttonMultiSelect.draw(canvas);
	        
	        if (isForReadingOrSaving==2) {
	        	this.buttonCRLF.draw(canvas);
	        }
	        if (this.isForReadingOrSaving==2) {
	        	this.buttonSaveToCurFile.draw(canvas);
	        }
	        if (this.isForReadingOrSaving==2) {
	        	this.buttonSaveAll.draw(canvas);
	        }
	        if (this.isForReadingOrSaving==2) {
	        	this.buttonConvertAllInProject.draw(canvas);
	        }
		}
		else {
			
	        
		}
		}catch(Exception e) {
			e.printStackTrace();
			CompilerHelper.printStackTrace(textViewLogBird, e);
    	}
		}
    }
	
	public void open(OnTouchListener listener, String title) {
		// 키보드의 리스너가 겹치므로 키보드의 기존 리스너를 보관하고 있다가 대화상자가 닫힐 시
		// 환원한다.
		if (!getIsOpen()) {
			this.Text = title;
			if (Common_Settings.settings.EnablesScreenKeyboard) {
				IntegrationKeyboard keyboard = CommonGUI.keyboard;
				WasKeyboardHiddenBeforeOpen = keyboard .hides;
				oldKeyboardListener = keyboard.backUp();
				/*if (isForReadingOrSaving==false) {
					keyboard.setOnTouchListener(editText);
				}*/
				
				// menuFileList가 Up, Down, PgUp, PgDn키의 이벤트를 필요로 하므로
				// FileDialog가 키보드의 이벤트를 받아서 눌린 키에 따라 그 이벤트를 중개한다.
				if (!isMaximized()) {
					changeBoundsOfKeyboard(bounds);
					keyboard.setOnTouchListener(editTextFilename);
					if (keyboard.getHides()) {
						keyboard.setHides(false);	// 키보드를 전면에 보이도록 한다.컨트롤스택 참조
					}
				}
			}
						
			super.open(true);
			setOnTouchListener(listener);
			this.resetMultiSelect();
		}
	}
	
	/*public void setActive() {
		// 키보드의 리스너가 겹치므로 키보드의 기존 리스너를 보관하고 있다가 대화상자가 닫힐 시
		// 환원한다.
		oldListener = keyboard.setOnTouchListener(editText);
	}*/
	
	/** bounds가 바뀔 때 호출, setHides에서 호출*/
	public void backUpBounds() {
		if (prevSize!=null) prevSize.copyFrom(bounds);
		else prevSize = new Rectangle(bounds);
	}
    
    @Override
    public boolean onTouch(MotionEvent event, SizeF scaleFactor) {
    	boolean r=false;
    	if (event.actionCode==MotionEvent.ActionDown || event.actionCode==MotionEvent.ActionDoubleClicked) {
	    	r = super.onTouch(event, scaleFactor);
	    	if (!r) return false;
	    	r = editTextDir.onTouch(event, scaleFactor);
	    	if (r) {
	    		if (Common_Settings.settings.EnablesScreenKeyboard) {
		    		if (isMaximized()) {
		    			isFullScreen = false;
			    		//canSelectFileType = false;
						isForViewing = false;
						setScaleValues();
						
						Rectangle newBounds = new Rectangle(0, 0, Control.view.getWidth(), prevSize.height);
						
						changeBounds(newBounds);
						setHides(false);
						changeBoundsOfKeyboard(newBounds);
						CommonGUI.keyboard.setHides(false);
		    		}
		    		else {
		    			changeBoundsOfKeyboard(bounds);
		    			CommonGUI.keyboard.setHides(false);
		    		}
	    		}
	    		return true;
	    	}
	    	r = this.buttonMultiSelect.onTouch(event, scaleFactor);
	    	if (r) {
	    		return true;
	    	}
	    	if (this.isForReadingOrSaving==2) {
		    	r = this.buttonCRLF.onTouch(event, scaleFactor);
		    	if (r) {
		    		return true;
		    	}
	    	}
	    	if (this.isForReadingOrSaving==2) {
		    	r = this.buttonSaveToCurFile.onTouch(event, scaleFactor);
		    	if (r) {
		    		return true;
		    	}
	    	}
	    	if (this.isForReadingOrSaving==2) {
		    	r = this.buttonSaveAll.onTouch(event, scaleFactor);
		    	if (r) {
		    		return true;
		    	}
	    	}
	    	if (this.isForReadingOrSaving==2) {
		    	r = this.buttonConvertAllInProject.onTouch(event, scaleFactor);
		    	if (r) {
		    		return true;
		    	}
	    	}
	    	r = editTextFilename.onTouch(event, scaleFactor);
	    	if (r) return true;
	    	
	    	r = buttonDir.onTouch(event, scaleFactor);
	    	if (r) return true;
	    	r = buttonCategory.onTouch(event, scaleFactor);
	    	if (r) return true;
	    	r = buttonTextFormat.onTouch(event, scaleFactor);
	    	if (r) return true;
	    	r = buttonFunc.onTouch(event, scaleFactor);
	    	if (r) return true;
	    	r = buttonMultimedia.onTouch(event, scaleFactor);
	    	if (r) return true;
	    	r = buttonOnOff.onTouch(event, scaleFactor);
	    	if (r) return true;
	    	
	    	int i;
    		for (i=0; i<controls.length; i++) {
    			r = controls[i].onTouch(event, scaleFactor);
    			if (r) return true;
    		}
	    	
	    	if (menuFileList!=null) {
	    		r = menuFileList.onTouch(event, null);
	    		if (r) return true;
	    	}
	    	return true;
    	}
    	else 
    		return false;
    }
    
    int getUniqueRandom() {
    	Random rand = new Random();
    	boolean exist = false;
    	int num=0;
    	do {
	    	num = rand.nextInt(300);
	    	int i;
	    	if (fileList==null) break;
	    	for (i=0; i<fileList.length; i++) {
	    		if (fileList[i].equals(String.valueOf(num))) {
	    			exist = true;
	    			break;
	    		}
	    	}
    	}while(exist);
    	return num;
    }
    
    /** multiselect 가능, 절대경로 파일(디렉토리)을 대상으로 한다.*/
    boolean cutOrCopy(ArrayListString fileList) {
    	int i;
    	fileListOfCutOrCopy = new ArrayList(10);
    	for (i=0; i<fileList.count; i++) {
	    	String absFilename = fileList.getItem(i);
		    File file  = new File(absFilename);
			if (!file.isDirectory()) {
				//fileListOfCutOrCopy = new ArrayList(5);
				fileListOfCutOrCopy.add(file);
				//isDirectoryOrFileForCutOrCopy = false;
			}
			else {
				ArrayList fileListOfCutOrCopyForDirectory;
				fileListOfCutOrCopyForDirectory = FileHelper.getFileList(absFilename, true);
				fileListOfCutOrCopy.add(fileListOfCutOrCopyForDirectory);
				//isDirectoryOrFileForCutOrCopy = true;
				
			}
    	}
		return true;
    }
    
    //@SuppressLint("UseValueOf")
	void getStorage() {
    	ArrayList arrName = new ArrayList(5);
    	//ArrayList arrTotalSpace = new ArrayList(5);
    	//ArrayList arrUsableSpace = new ArrayList(5);
    	ArrayList arrUsedSpace = new ArrayList(5);
    	
    	// "/" partition
    	try {
	    	/*File file = Environment.getRootDirectory();
	    	arrName.add(file.getAbsolutePath());
	    	arrTotalSpace.add(new Long(file.getTotalSpace()));
	    	arrUsableSpace.add(new Long(file.getUsableSpace()));*/
	    	    	
	    	File sdcard = Environment.getExternalStorageDirectory();
	    	arrName.add(sdcard.getAbsolutePath());
	    	//arrTotalSpace.add(new Long(sdcard.getTotalSpace()));
	    	//arrUsableSpace.add(new Long(sdcard.getUsableSpace()));
	    	arrUsedSpace.add(
	    		new Long(FileHelper.getFileSize(sdcard.getAbsolutePath())));
	    	//arrUsableSpace.add(new Long(sdcard.getUsableSpace()));
    	}catch(Exception e) {
    		e.printStackTrace();
			CompilerHelper.printStackTrace(textViewLogBird, e);
    	}
    	
    	int i;
    	String msg = "";
    	long usedSpace;
    	for (i=0; i<arrName.count; i++) {
    		msg += arrName.getItem(i) + "\n";
    		//msg += "Total Space : " + arrTotalSpace.getItem(i) + "\n";
    		long valueOfUsedSpace = ((Long)arrUsedSpace.getItem(i)).longValue();
    		usedSpace = valueOfUsedSpace;
    		msg += "Used Space : " + usedSpace + "\n";
    		//msg += "Usable Space : " + arrUsableSpace.getItem(i);
    		if (i!=arrName.count-1) msg += "\n\n";
    	}
    	
    	CommonGUI.loggingForMessageBox.setText(true, msg, false);
    	CommonGUI.loggingForMessageBox.setHides(false);
    }
	
	static class Thread_getProperties extends Thread {
		private ArrayListString fileList;
		private FileDialog owner;

		Thread_getProperties(FileDialog owner, ArrayListString fileList) {
			this.owner = owner;
			this.fileList = fileList;
		}
		public void run() {
			owner.getProperties_sub(fileList);
			Control.view.postInvalidate();
		}
	}
	
	 /** multiselect 가능, 절대경로 파일(디렉토리)을 대상으로 한다.*/
    void getProperties(ArrayListString fileList) {
    	Thread_getProperties thread = new Thread_getProperties(this, fileList);
    	// Makes new owner.fileListOfMultiSelect per thread. 
		this.fileListOfMultiSelect = null;
		this.resetMultiSelect();
    	thread.start();
    }
    
    /** multiselect 가능, 절대경로 파일(디렉토리)을 대상으로 한다.*/
    void getProperties_sub(ArrayListString fileList) {
    	int i;
    	long size=0;
    	int fileCount=0;
    	long lastModified;
    	String msg;
    	
    	if (fileList==null) return;
    	
    	if (fileList.count==1) {
    		String absFilename = fileList.getItem(0);
		    File file  = new File(absFilename);
		    
		    if (!file.isDirectory()) {
		    	size = file.length();
		    	fileCount = 1;
		    }
		    else {
		    	SizeAndCount sizeAndCount = FileHelper.getFileSizeAndCount(absFilename);
		    	size += sizeAndCount.size;
		    	fileCount += sizeAndCount.count;
		    }
    		
    		lastModified = file.lastModified();
    		
    		/*
			Date.addUserTime(1,9,0,1);
    		com.gsoft.common.util.Util.Date date = new com.gsoft.common.util.Util.Date(lastModified);
    		String strLastModified = date.getMonth() + "-" +
    				date.getDate() + "-" + date.getYear() + " " + 
    				date.getHour(false) + "h" + ":" + date.getMin() + "m";
    		*/
    		
    		
    		String strLastModified = Util.toDateString(lastModified);
    		
    		
    		    		
    		
    		    		
    		msg = "Path : "+absFilename + "\n" + 
    				"Size : "+com.gsoft.common.compiler.Number.toFormatString(size) + "\n" + 
    				"File count : "+com.gsoft.common.compiler.Number.toFormatString(fileCount) + "\n" +  
    				"Last Modified : "+strLastModified;
    	}
    	else {
    		msg = "FileList : \n";
	    	for (i=0; i<fileList.count; i++) {
		    	String absFilename = fileList.getItem(i);
			    SizeAndCount sizeAndCount = FileHelper.getFileSizeAndCount(absFilename);
		    	size += sizeAndCount.size;
		    	fileCount += sizeAndCount.count;
		    	msg += absFilename + "\n";
	    	}
	    	msg += "Size : "+com.gsoft.common.compiler.Number.toFormatString(size) + "\n" + 
	    			"File count : "+com.gsoft.common.compiler.Number.toFormatString(fileCount);
    	}
    	
    	CommonGUI.loggingForMessageBox.setText(true, msg, false);
    	CommonGUI.loggingForMessageBox.setHides_sub_NotFrame(false);
    }
    
    /** 시간이 걸리는 paste작업을 스레드로 활용하여 처리한다.*/
    static class ThreadPaste extends Thread {
    	FileDialog fileDialog;
    	String curDir;
    	Category category;
    	String filename;
    	ArrayList fileListOfCutOrCopy;
    	boolean cutOrCopy;
    	
    	ThreadPaste(FileDialog fileDialog,	String curDir, Category category, String filename,
    			ArrayList fileListOfCutOrCopy, boolean cutOrCopy) {
    		this.fileDialog = fileDialog;
    		this.curDir = curDir;
    		this.category = category;
    		this.filename = filename;
    		this.fileListOfCutOrCopy = fileListOfCutOrCopy;
    		this.cutOrCopy = cutOrCopy;
    	}
    	
    	public void run() {
    		FileDialog.paste_sub(fileDialog, curDir, category, filename, fileListOfCutOrCopy, cutOrCopy);
    		
    		fileDialog.createAndSetFileListButtons(curDir, fileDialog.category);
    		
    		//fileDialog.fileListOfMultiSelect.reset2();
    		// createAndSetFileListButtons 뒤에 Button의 toggleable상태가 원상태로
    			// 바뀌기 때문에 MultiSelect상태를 해제해준다.
    		fileDialog.resetMultiSelect();
    		fileDialog.state = FileDialog.State.Normal;
    		
        	CommonGUI.loggingForMessageBox.setText(true, "Paste completed", false);
        	CommonGUI.loggingForMessageBox.setHides_sub_NotFrame(false);
        	Control.view.postInvalidate();
    	}
    }
    
    /** 시간이 걸리는 paste작업을 스레드로 처리하기 위해 fileListOfCutOrCopy등의 복사작업을 한 후
     * 스레드를 생성하여 처리한다.
     * @param cutOrCopy
     * @return
     */
    boolean paste(boolean cutOrCopy) {
    	String curDir = this.curDir;
    	Category category = this.category;
    	String filename = null;
    	if (this.filename!=null) {
    		filename = this.filename.substring(0, this.filename.length());
    	}
    	ArrayList fileList = new ArrayList(this.fileListOfCutOrCopy.count);
    	int i, j;
    	for (i=0; i<this.fileListOfCutOrCopy.count; i++) {
    		Object o = this.fileListOfCutOrCopy.getItem(i);
    		if (o instanceof ArrayList) { //디렉토리
    			ArrayList d = (ArrayList)o;
    			ArrayList directory = new ArrayList(d.count);
    			for (j=0; j<d.count; j++) {
    				File file = (File) d.getItem(j);
    				directory.add(new File(file.getAbsolutePath()));
    			}
    			fileList.add(directory);
    		}
    		else { // 파일
    			File file = (File) o;
    			fileList.add(new File(file.getAbsolutePath()));
    		}
    	}
    	ThreadPaste threadPaste = new ThreadPaste(this, curDir, category, 
    			filename, fileList, cutOrCopy);
    	threadPaste.start();
    	return true;
    }
    
  
    /** multiselect 가능, 절대경로 파일(디렉토리)을 대상으로 한다.*/
    static boolean paste_sub(FileDialog fileDialog, String curDir, Category category, 
    		String filename, ArrayList fileListOfCutOrCopy, boolean cutOrCopy) {
    	String msg="";
    	if (cutOrCopy) {
	    	if (fileListOfCutOrCopy!=null && fileListOfCutOrCopy.count>0) {
	    		int c;
	    		for (c=0; c<fileListOfCutOrCopy.count; c++) {
	    			Object item = fileListOfCutOrCopy.getItem(c);
	    			boolean isDirectoryOrFileForCut =  
	    					(item instanceof ArrayList) ? true : false;
		    		if (isDirectoryOrFileForCut) {	// cut directory
		        		String relativePath="";
		        		ArrayList list = (ArrayList)item;
		        		int i;
		        		for (i=0; i<list.count; i++) {
		        			if (i==0) {
		        				File file = (File) list.getItem(i);
		        				if (file.isDirectory()) {
		    	            		String filePath = file.getAbsolutePath();
		    	            		String fn = FileHelper.getFilename(filePath);
		    	            		relativePath = filePath.substring(filePath.indexOf(fn));
		    	            		File newFile = new File(fileDialog.getCurDir(true)+relativePath);
				            		boolean r = file.renameTo(newFile);
				            		if (!r) {
				            			/*msg += " " + filename + " cut failed.";
				            			Control.loggingForMessageBox.setText(true, msg, false);
				    	            	Control.loggingForMessageBox.setHides(false);
				    	            	return false;*/
				            		}
		        				}
		        			}
		        			else {
			            		File file = (File) list.getItem(i);
			            		String filePath = file.getAbsolutePath();
			            		String relativeFilename = filePath.substring(filePath.indexOf(relativePath));
			            		File newFile = new File(fileDialog.getCurDir(true)+relativeFilename);
			            		boolean r = file.renameTo(newFile);
			            		if (!r) {
			            			/*msg += " " + filename + " cut failed.";
			            			Control.loggingForMessageBox.setText(true, msg, false);
			    	            	Control.loggingForMessageBox.setHides(false);
			    	            	return false;*/
			            		}
		        			}
		        		}//for (i=0; i<list.count; i++) {
		    		} //if (isDirectoryOrFileForCut) {	// cut directory
		    		else {	// cut file
		    			File file = (File) item;
	            		String filePath = file.getAbsolutePath();
	            		String fn = FileHelper.getFilename(filePath);
	            		File newFile = new File(fileDialog.getCurDir(true)+fn);
	            		boolean r = file.renameTo(newFile);
	            		if (!r) {
	            			/*msg += " " + filename + " cut failed.";
	            			Control.loggingForMessageBox.setText(true, msg, false);
	    	            	Control.loggingForMessageBox.setHides(false);
	    	            	return false;*/
	            		}
		    		}
		    		//createAndSetFileListButtons(curDir, category);
	    		}// for (c=0; c<fileListOfCutOrCopy.count; c++) {
	    		fileDialog.createAndSetFileListButtons(curDir, category);
	    	}//if (fileListOfCutOrCopy!=null && fileListOfCutOrCopy.count>0) {
    	}//if (cutOrCopy) {
    	else {
	    	if (fileListOfCutOrCopy!=null && fileListOfCutOrCopy.count>0) {
	    		int c;
	    		byte[] buf = new byte[1000];
	    		for (c=0; c<fileListOfCutOrCopy.count; c++) {
	    			Object item = fileListOfCutOrCopy.getItem(c);
	    			boolean isDirectoryOrFile =  
	    					(item instanceof ArrayList) ? true : false;
	    		
		    		int i;
		    		if (!isDirectoryOrFile) {	// copy file
		    			FileInputStream inStream = null; 
	            		FileOutputStream outStream = null;
	            		BufferedInputStream binStream = null; 
	            		BufferedOutputStream boutStream = null;
	        			try {
		            		File file = (File) item;
		            		String fn = FileHelper.getFilename(file.getAbsolutePath());
		            		File newFile = new File(fileDialog.getCurDir(true)+fn);
		            		inStream = new FileInputStream(file); 
		            		outStream = new FileOutputStream(newFile);
		            		binStream = new BufferedInputStream(inStream); 
		            		boutStream = new BufferedOutputStream(outStream);
		            		FileHelper.move(buf, binStream, boutStream);
	        			}catch(Exception e2) {
	        				msg += " " + filename + " copy failed.";
	        				CommonGUI.loggingForMessageBox.setText(true, msg, false);
	        				CommonGUI.loggingForMessageBox.setHides(false);	
	    	            	
	    	            	e2.printStackTrace();
	    					CompilerHelper.printStackTrace(textViewLogBird, e2);
	    	            	return false;
	        			}
	        			finally {
	        				FileHelper.close(inStream);
	        				FileHelper.close(outStream);
	        				FileHelper.close(binStream);
	        				FileHelper.close(boutStream);
	        			}
		    		} // copy file
		    		else {	// copy directory
		    			String relativePath="";
		    			ArrayList list = (ArrayList)item;
		    			//byte[] buf = new byte[1000];
		    			for (i=0; i<list.count; i++) {
		    				FileInputStream inStream = null; 
		            		FileOutputStream outStream = null;
		            		BufferedInputStream binStream = null; 
		            		BufferedOutputStream boutStream = null;
		            		File file = (File) list.getItem(i);
		            		try {
		        				if (i==0) {		        					
		            				if (file.isDirectory()) {
			    	            		String filePath = file.getAbsolutePath();
			    	            		String fn = FileHelper.getFilename(filePath);
			    	            		relativePath = filePath.substring(filePath.indexOf(fn));
			    	            		File newFile = new File(fileDialog.getCurDir(true)+relativePath);
					            		boolean r2 = newFile.mkdir();
					            		if (!r2) {
					            			msg += " " + fn + " mkdir failed.";
					            			CommonGUI.loggingForMessageBox.setText(true, msg, false);
					            			CommonGUI.loggingForMessageBox.setHides(false);
					    	            	//return false;
					            		}
		            				}
		        				}
		        				else {  
				            		String filePath = file.getAbsolutePath();
				            		String relativeFilename = filePath.substring(filePath.indexOf(relativePath));
				            		File newFile = new File(fileDialog.getCurDir(true)+relativeFilename);
				            		if (file.isDirectory()) {
				            			newFile.mkdir();
				            		}
				            		else {				            		
					            		inStream = new FileInputStream(file); 
					            		outStream = new FileOutputStream(newFile);
					            		binStream = new BufferedInputStream(inStream); 
					            		boutStream = new BufferedOutputStream(outStream);
					            		FileHelper.move(buf, binStream, boutStream);
				            		}
		        				}
		        			}catch(Exception e2) {
		        				msg += " " + filename + " copy failed.";
		        				CommonGUI.loggingForMessageBox.setText(true, msg, false);
		        				CommonGUI.loggingForMessageBox.setHides(false);
		    	            			    	            	
		    	            	e2.printStackTrace();
		    					CompilerHelper.printStackTrace(textViewLogBird, e2);
		    	            	return false;
		        			}
		        			finally {
		        				FileHelper.close(inStream);
		        				FileHelper.close(outStream);
		        				FileHelper.close(binStream);
		        				FileHelper.close(boutStream);
		        			}
		        		} // for (i=0; i<list.count; i++) {
		    			
		    		} // if (isDirectoryOrFileForCutOrCopy==true)
	    		}//for (c=0; c<fileListOfCutOrCopy.count; c++) {
	    		fileDialog.createAndSetFileListButtons(curDir, category);
	    	}//if (fileListOfCutOrCopy!=null && fileListOfCutOrCopy.count>0) {
    	} // if (!cutOrCopy)
    	
    	
    	return true;
    } // paste
    
    public void enableMultiSelect(boolean toggleable) {
    	if (toggleable) {
    		int i;
        	for (i=0; i<menuFileList.buttons.length; i++) {
        		menuFileList.buttons[i].toggleable = true;
        		menuFileList.buttons[i].setIsSelected(false);
        	}
    	}
    	else {
    		int i;
        	for (i=0; i<menuFileList.buttons.length; i++) {
        		menuFileList.buttons[i].toggleable = false;
        		menuFileList.buttons[i].setIsSelected(false);
        	}
    	}
    }

    public void cancel() {
    	super.cancel();
    	// cancel버튼이 눌릴 시 리시버에 전달
    	if (listener!=null)
    		listener.onTouchEvent(this, null);
    }
    
    public boolean isPlaying() {
    	if (mediaPlayer!=null) {
    		return mediaPlayer.isPlaying();
    	}
    	if (Wifi.isRunning) {
    		return true;
    	}
    	if (this.recorder!=null && this.recorder.isRunning) {
    		return true;
    	}
    	
    	return false;
    }
    
    void resetMultiSelect() {
    	this.menuFunc.buttons[8].setIsSelected(false);
    	this.buttonMultiSelect.setIsSelected(false);
    	
    	enableMultiSelect(false);
    	//menuFunc.buttons[8].setIsSelected(false);
    	//this.buttonMultiSelect.setIsSelected(false);
    	if (Common_Settings.CurrentSystem.equals(Common_Settings.CurrentSystemIsJava) &&
    			Button.isTripleBuffering) 
    	{
    		buttonMultiSelect.drawToImage(buttonMultiSelect.mCanvas);
	    }
    	if (Common_Settings.CurrentSystem.equals(Common_Settings.CurrentSystemIsJava) &&
    			Button.isTripleBuffering) 
    	{
    		menuFunc.buttons[8].drawToImage(menuFunc.buttons[8].mCanvas);
	    }
    }
    
    public void listenToMusic(ArrayListString fileListOfMultiSelect, PlayListAndCurSongInfo info) {
    	menuMultimedia.open(false);

    	if (fileListOfMultiSelect==null) return;
    	this.mPlayList = (ArrayListString)fileListOfMultiSelect.clone();
    	
    	if (fileListOfMultiSelect.count>0) {
        	cutOrCopy(fileListOfMultiSelect);
        	
        	resetMultiSelect();
        	
        	isCutOrCopy = false;
        	
        	if (isFullScreen) {
            	if (mediaPlayer==null) {
            		int x, y, w, h;
            		w = bounds.width;
            		h = buttonFunc.bounds.y;
            		x = 0;
            		y = 0;
            		Rectangle mediaBounds = new Rectangle(x,y,w,h); 
            		mediaPlayer = new MediaPlayerDel(Control.view, mediaBounds);
            		
            		mediaPlayer.initialize(fileListOfCutOrCopy, info);
            		/*if (info!=null) {	            			
            			mediaPlayer.play(info.seekOfCurSong);
            		}*/
            		mediaPlayer.play();
            		//if (r) menuFunc.buttons[9].isSelected = true;
            		//else menuFunc.buttons[9].isSelected = false;
            	}
            	else {
            		mediaPlayer.initialize(fileListOfCutOrCopy, info);
            		/*if (info!=null) {	            			
            			mediaPlayer.play(info.seekOfCurSong);
            		}*/
            		mediaPlayer.play();
            		//if (r) menuFunc.buttons[9].isSelected = true;
            		//else menuFunc.buttons[9].isSelected = false;
            	}
        	}
        	
    	}
    	else {
    		CommonGUI.loggingForMessageBox.setText(true, "Select a file(s).", false);
    		CommonGUI.loggingForMessageBox.setHides(false);
    	}
    }
    
	@Override
	public void onTouchEvent(Object sender, MotionEvent e) {
			
		
		if (sender instanceof Button) {
			Button button = (Button)sender;
			if (button.iName==controls[0].iName)	// OK
            {
				//state = State.Normal;				
				filename = editTextFilename.getText().str;
				if (filename!=null && filename.equals("")) {
					if (!isFullScreen) {
						CommonGUI.loggingForMessageBox.setText(true, "Input file name.", false);
						CommonGUI.loggingForMessageBox.setHides(false);
		            	return;
					}
				}
				super.ok();
				// ok버튼이 눌릴 시 리시버에 전달
				if (listener!=null)
					listener.onTouchEvent(this, e);
				//menuFunc.buttons[9].isSelected = false;
			
            }
            else if (button.iName==controls[1].iName) // Cancel
            {
            	//state = State.Normal;
            	cancel();
            	//menuFunc.buttons[9].isSelected = false;
            }
            else if (button.iName==buttonOnOff.iName)
            {
            	if (buttonOnOff.getIsSelected()) {
            		PowerManagement.keepScreenOn();            		
            	}
            	else {
            		PowerManagement.clearScreenOn();
            		boolean hasWakeLock = false;
            		hasWakeLock = isPlaying();
            		
            		if (!hasWakeLock) {
            			PowerManagement.releaseWakeLock();
            		}
            		else {
            			PowerManagement.getPartialWakeLock(Control.view.getContext());
            		}
            	}
            }
            else if (button.iName==buttonCRLF.iName) {
            	//this.open(false);
            	this.menuCRLF.open(this, true);
            	
            }
            else if (button.iName==buttonSaveToCurFile.iName) {
            	this.open(false);
            	try {
					CommonGUI.editText_compiler.write(TextFormat.UTF_8);
				} catch (IOException e1) {
					
					e1.printStackTrace();
				}
            }
            else if (button.iName==this.buttonSaveAll.iName) {
            	this.open(false);
            	try {
					CommonGUI.editText_compiler.writeAllFiles();
				} catch (IOException e1) {
					
					e1.printStackTrace();
				}
            }
            else if (button.iName==this.buttonConvertAllInProject.iName) {
            	this.open(false);
            	try {
					CommonGUI.editText_compiler.writeAllFilesInProject();
				} catch (IOException e1) {
					
					e1.printStackTrace();
				}
            }
            else if (button.iName==buttonDir.iName)
            {
            	//state = State.Normal;
            	menuDir.open(true); 
            }
            else if (button.iName==buttonTextFormat.iName)
            {
            	//state = State.Normal;
            	menuTextFormat.open(true); 
            }
            else if (button.iName==buttonCategory.iName) {
            	//state = State.Normal;
            	if (canSelectFileType) menuFileType.open(true);
            }
            else if (button.iName==buttonFunc.iName) {
            	//state = State.Normal;
            	menuFunc.open(true);
            }
            else if (button.iName==buttonMultimedia.iName) {
            	//state = State.Normal;
            	menuMultimedia.open(true);
            }
            else if (button.iName==this.buttonMultiSelect.iName) {
            	this.fileDialogEventHandler.handleButtonMultiSelect(button);
            }
			
            
            else {//MenuDir handler
            	
            	int i;
            	for (i=0; i<this.menuFunc.buttons.length; i++) {
            		if (button.iName==this.menuFunc.buttons[i].iName) {
            			fileDialogEventHandler.processEventOfMenuFunc(sender);
            			return;
            		}
            	}
            	
            	for (i=0; i<this.menuMultimedia.buttons.length; i++) {
            		if (button.iName==this.menuMultimedia.buttons[i].iName) {
            			fileDialogEventHandler.processEventOfMenuMultimedia(sender);
            			return;
            		}
            	}
            	
            	for (i=0; i<this.menuSort.buttons.length; i++) {
            		if (button.iName==this.menuSort.buttons[i].iName) {
            			fileDialogEventHandler.processEventOfMenuSort(sender);
            			return;
            		}
            	}
            	
            	fileDialogEventHandler.handleMenuCRLF(button);
            	
            	fileDialogEventHandler.handleMenuDir(button);
            	
            	fileDialogEventHandler.handleHelpMe(button);
            	
            	fileDialogEventHandler.handleMenuFileType(button);
            	
            	
            	
            } // else {
		}//if (sender instanceof Button)
		else if (sender instanceof MenuWithScrollBar) {
			fileDialogEventHandler.processEventOfMenuWithScrollBar(sender);
		}// else if (sender instanceof MenuWithScrollBar) {
		else if (sender instanceof IntegrationKeyboard) {
			// menuFileList가 Up, Down, PgUp, PgDn키의 이벤트를 필요로 하므로
			// FileDialog가 키보드의 이벤트를 받아서 눌린 키에 따라 그 이벤트를 중개한다.
			IntegrationKeyboard keyboard = (IntegrationKeyboard)sender;
			int i;
			String[] specialKeys = IntegrationKeyboard.SpecialKeys;
			for (i=0; i<specialKeys.length; i++) {
				if (keyboard.key.equals(specialKeys[i])) {
					menuFileList.controlChar(i, charA);
					return;
				}
			}
			editTextFilename.onTouchEvent(sender, e);
		}
		
		else if (sender instanceof MessageDialog) {
			fileDialogEventHandler.processEventOfMessageDialog(sender);
		}
		else if (sender instanceof ConnectDialog) { // ok, cancel
			fileDialogEventHandler.processEventOfConnectDialog(sender);
		}
	}
	
	
	
	
	
	
	
	/** 시간이 걸리는 delete작업을 스레드로 활용하여 처리한다.*/
	static class ThreadDelete extends Thread {
		ArrayListString fileListOfMultiSelect;
		FileDialog fileDialog;
		
		/** 시간이 걸리는 delete작업을 스레드로 처리하기 위해 fileListOfMultiSelect 복사작업을 한 후
	     * 스레드를 생성하여 처리한다.*/
		ThreadDelete(FileDialog fileDialog, ArrayListString fileListOfMultiSelect) {
			this.fileDialog = fileDialog;
			this.fileListOfMultiSelect = (ArrayListString)fileListOfMultiSelect.clone();
		}
		public void run() {
			boolean r = false;
			int i;
			for (i=0; i<fileListOfMultiSelect.count; i++) {
				//getPermission(new File(fileListOfMultiSelect.getItem(i)));
				r = FileHelper.delete(fileListOfMultiSelect.getItem(i));
				//closePermission();
				if (!r) break;
			}
			fileDialog.createAndSetFileListButtons(fileDialog.getCurDir(true), fileDialog.category);
			
			//fileListOfMultiSelect.reset2();
			//createAndSetFileListButtons(curDir, category);
			// createAndSetFileListButtons 뒤에 Button의 toggleable상태가 원상태로
			// 바뀌기 때문에 MultiSelect상태를 해제해준다.
			fileDialog.resetMultiSelect();
			fileDialog.state = FileDialog.State.Normal;
			
			if (r) {
				CommonGUI.loggingForMessageBox.setText(true, "Delete completed.", false);
				CommonGUI.loggingForMessageBox.setHides_sub_NotFrame(false);
				Control.view.postInvalidate();
			}
			else {
				CommonGUI.loggingForMessageBox.setText(true, "Delete failed.", false);
				CommonGUI.loggingForMessageBox.setHides_sub_NotFrame(false);
				Control.view.postInvalidate();
			}
		}
		
	}
	
	boolean startReceiver() {	
		
		WifiInfo info=null;
		info = Wifi.startWifi(Control.view);
		short[] shortIpAddress = new short[4];
		byte[] ipAddress;
		InetAddress address=null;
		int port = 3000;
		String wifiState = "";
		String macAddress;
		
		if (info==null) {
			Wifi.setWifiStateSync(false, "Can't start receiver");
			return false;
		}
		else {
			try {
				PowerManagement.getPartialWakeLock(Control.view.getContext());
				
				ipAddress = Wifi.getIpAddress(info.getIpAddress());
				shortIpAddress[0] = (short) (ipAddress[0]&0xff);
				shortIpAddress[1] = (short) (ipAddress[1]&0xff);
				shortIpAddress[2] = (short) (ipAddress[2]&0xff);
				shortIpAddress[3] = (short) (ipAddress[3]&0xff);
				wifiState += " ip : " + shortIpAddress[0]+"."+shortIpAddress[1]+"."+
						shortIpAddress[2]+"."+shortIpAddress[3];
				wifiState += " port : " + port;
				macAddress = info.getMacAddress();
				wifiState += " Mac : " + macAddress;
				
				address = InetAddress.getByAddress(ipAddress);
				
				Wifi.setWifiStateSync(false,wifiState);
				
				
			} catch (Exception e) {
				wifiState += "CustomView"+e.toString();
				e.printStackTrace();
				CompilerHelper.printStackTrace(textViewLogBird, e);
			}
			
			if (serviceThread!=null) killServiceThread();
			
			serviceThread = new ServiceThread(address, port);
			serviceThread.owner = Control.view;
			serviceThread.start();
			
			return true;
		}
	}

	void killServiceThread() {
		if(serviceThread==null) return;
		serviceThread.killThread();
		serviceThread = null;
	}

	void killWifiThread() {
		if(wifiThread==null) return;
		wifiThread.killThread();
		wifiThread = null;
	}
	public boolean lastOperation() {
		if (su!=null) su.destroy();
		killWifiThread();
		killServiceThread();
		if (mediaPlayer!=null) {
			mediaPlayer.lastOperation();
		}
		if (CommonGUI.editText_compiler!=null) {
			boolean r = CommonGUI.editText_compiler.lastOperation();
			return r;
		}
		return true;
	}

	public void setPlayListAndCurSongInfo(ArrayListString fileList2,
			PlayListAndCurSongInfo playListAndCurSongInfo) {
		
		this.fileListOfMultiSelect = fileList2;
		this.playListAndCurSongInfo = playListAndCurSongInfo;
		MediaPlayerDel.indexOfFileList_1Dim = playListAndCurSongInfo.indexOfCurSong;
		MediaPlayerDel.curPos = playListAndCurSongInfo.seekOfCurSong;
		MediaPlayerDel.state = MediaPlayerDel.stateFromString( playListAndCurSongInfo.state);
		MediaPlayerDel.allRepeated = playListAndCurSongInfo.allRepeated;
		MediaPlayerDel.isRandomOnOrOff = playListAndCurSongInfo.isRandomOnOrOff;
		
	}
}