package com.gsoft.common.gui;

import java.io.File;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.CommonGUI;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.Events.MotionEvent;
import com.gsoft.common.IO;
import com.gsoft.common.IO_types.TextFormat;
import com.gsoft.common.Sizing.Rectangle;
import com.gsoft.common.Sizing.SizeF;
import com.gsoft.common.gui.edittext.Edit.ScrollMode;
import com.gsoft.common.gui.edittext.EditText;

import com.gsoft.common.gui.IntegrationKeyboard;

/** bounds 외부를 터치하면 닫히는 EditText*/
public class TextView extends EditText {

	public TextView(boolean hasToolbarAndMenuFontSize,
			boolean isDockingOfToolbarFlexiable, Object owner, String name,
			Rectangle paramBounds, float fontSize, boolean isSingleLine,
			CodeString text, ScrollMode scrollMode, int backColor) {
		super(hasToolbarAndMenuFontSize, isDockingOfToolbarFlexiable, owner, name,
				paramBounds, fontSize, isSingleLine, text, scrollMode, backColor);
		
	}
	
	@Override
	public void initialize() {
		super.initialize();	
	}
	
	public int getCount() {
		int i;
		int count = 0;
		if (this.numOfLines==1 && this.textArray[0]==null) return 0;
		for (i=0; i<this.numOfLines; i++) {			
			count += this.textArray[i].count;
		}
		return count;
	}
	
	
	
	@Override
    public boolean onTouch(MotionEvent event, SizeF scaleFactor) {
    	boolean r=false;
    	if (event.actionCode==MotionEvent.ActionDown || event.actionCode==MotionEvent.ActionDoubleClicked) {
	    	r = super.onTouch(event, scaleFactor);
	    	if (!r) {
	    		open(false);	// 영역에 상관없이 닫힌다.
	    		return true;
	    	}
	    	else {
	    		return true;
	    	}
    	}
    	else if (event.actionCode==MotionEvent.ActionMove) {
    		r = super.onTouch(event, scaleFactor);
    		if (r) return true;
    		return false;
    	}
    	else 
    		return false;
    }
			
}