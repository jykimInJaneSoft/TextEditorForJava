package com.gsoft.common.gui;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Color;
import android.view.View;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.ColorEx;
import com.gsoft.common.CommonGUI;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.Events.MotionEvent;
import com.gsoft.common.FileHelper;
import com.gsoft.common.IO;
import com.gsoft.common.IO_types.TextFormat;
import com.gsoft.common.Sizing.Rectangle;
import com.gsoft.common.Sizing.Size;
import com.gsoft.common.Sizing.SizeF;
import com.gsoft.common.interfaces.OnTouchListener;
import com.gsoft.common.R.R;
import com.gsoft.common.compiler.EditText_Compiler;
import com.gsoft.common.compiler.util.OtherLibsDialog;
import com.gsoft.common.gui.Buttons.Button;
import com.gsoft.common.gui.Menu.MenuType;
import com.gsoft.common.gui.edittext.Edit;
import com.gsoft.common.gui.edittext.Edit.ScrollMode;
import com.gsoft.common.gui.edittext.EditText;

import com.gsoft.common.gui.Dialog;
import com.gsoft.common.gui.Static;
import com.gsoft.common.gui.Control;
import com.gsoft.common.gui.ColorDialog;
import com.gsoft.common.gui.FileDialog;
import com.gsoft.common.gui.Menu;
import com.gsoft.common.gui.Panel;
import com.gsoft.common.gui.MenuWithClosable;

/**ViewEx의 createSettingsDialog(View view)에서 생성되어 
 * Common_Settings.settingsDialog에 저장된다.*/
public class SettingsDialog extends Dialog  implements OnTouchListener {
	static int[] colors = {Color.WHITE, Color.RED
	};
	static String[] namesOfColorButtons = {"White", "Red"
	};
	static String[] textesOfColorButtons = {"EditText Color", "Keyboard Color"
	};
	
	float scaleOfGapX = 0.05f;
	
	float scaleOfTitleBar = 0.1f;
	
	// static과 button
	float scaleOfColorButtonsX = (1-scaleOfGapX*3) / 2;
	float scaleOfColorButtonsY = 0.07f;
	
	float scaleOfOKButtonX = (1-scaleOfGapX*3) / 2;
	float scaleOfOKButtonY = 0.07f;
	
	float scaleOfstaticEditTextDirectory = 0.07f;
	
	//float scaleOfbuttonTextSaveFormatY = 0.07f;
	
	//Static staticButtonTextSaveFormat;
	
	//Button buttonTextSaveFormat;
	
	Static staticIsTripleBuffering;
	
	Button buttonIsTripleBuffering;
	
	
	float scaleOfbuttonIsTripleBufferingY = 0.07f;
	
	float scaleOfbuttonIsTripleBufferingX = 0.4f;
	
	Static staticEditTextDirectory;
	
	/** 짝수번째는 Static, 홀수번째는 Button*/
	Control[] controlsOfSettings = new Control[namesOfColorButtons.length*2];
	
	ColorDialog colorDialog = CommonGUI.colorDialog;
	//public int[] selectedColor = {Color.WHITE, Color.RED};
	
	
	int indexOfSelectedButton;
	
	/** 뒤에 '/'이 붙는것을 주의한다. 예를 들어 /sdcard/adroid/ */
	public EditText editTextDirectory;	
	Button buttonFileExplorer;
	
	//float scaleOfstaticTextSaveFormatX = 0.4f;
	
	float scaleOfEditTextDirectoryX = 0.7f;
	float scaleOfButtonFileExplorerX =  1 - (scaleOfEditTextDirectoryX+scaleOfGapX*3);
	
	// scaleOfstaticEditTextDirectory을 합친 크기, 나중에 실제 높이를 계산할때는 
	// scaleOfstaticEditTextDirectory을 빼준다.
	float scaleOfEditTextDirectoryY = 0.11f + scaleOfstaticEditTextDirectory;
	
	float scaleOfButtonPageControllerY = 0.05f;
	
	float scaleOfButtonPageControllerX = 0.15f;
	
	
	// 나누는 수는 gap 개수
	float scaleOfGapY = (1-(scaleOfTitleBar + scaleOfColorButtonsY*2  +	scaleOfEditTextDirectoryY + 
			scaleOfOKButtonY + /*scaleOfbuttonTextSaveFormatY +*/ scaleOfbuttonIsTripleBufferingY + scaleOfButtonPageControllerY)) / 8;
	
	
	Button buttonPageController;
	
	public static String[] namesOfMenuTextFormat = {"UTF-8", "UTF-16", "MS-949"};
	
	public static float scaleOfWidth = 0.8f;
	public static float scaleOfHeight = 0.8f;
	
	Menu menuTextFormat;
	boolean enablesMenuTextFormat;
	
	/** 텍스트저장형식 utf-8:0, utf-16:1, ms-949(ksc):2이다.*/
	//public int textSaveFormat = 0;
	
	Panel panelControls;
	
	//boolean isTripleBuffering;
	
	/** 클래스캐시를 사용하는지 여부*/
	float scaleOfStaticUsesClassCacheX = 0.4f;
	float scaleOfButtonUsesClassCacheX = 0.4f;
	float scaleOfUsesClassCacheY = scaleOfstaticEditTextDirectory;
	
	/** child 프로세스를 사용해서 자바문서를 열면 true(MDI), 
	 * 그게아니라 메인프로세스에서 열면 false(SDI)*/
	float scaleOfStaticUsesChildCompilerProcessX = this.scaleOfStaticUsesClassCacheX;
	float scaleOfButtonUsesChildCompilerProcessX = this.scaleOfStaticUsesClassCacheX;
	float scaleOfUsesChildCompilerProcessY = this.scaleOfstaticEditTextDirectory;
	
	
	/** 자주 사용하는 클래스 파일들을 스레드를 사용하여 미리 로드하는지 여부*/
	float scaleOfStaticLoadsClassesFrequentlyUsedAdvancelyX = this.scaleOfStaticUsesClassCacheX;
	float scaleOfButtonLoadsClassesFrequentlyUsedAdvancelyX = this.scaleOfStaticUsesClassCacheX;
	float scaleOfLoadsClassesFrequentlyUsedAdvancelyY = this.scaleOfstaticEditTextDirectory;
	
	float scaleOfStaticEnablesScreenKeyboardX = scaleOfStaticLoadsClassesFrequentlyUsedAdvancelyX;
	float scaleOfButtonEnablesScreenKeyboardX = scaleOfButtonLoadsClassesFrequentlyUsedAdvancelyX;
	float scaleOfEnablesScreenKeyboard = scaleOfLoadsClassesFrequentlyUsedAdvancelyY;
	
	float scaleOfStaticEnablesUnzipLibraryX = scaleOfStaticLoadsClassesFrequentlyUsedAdvancelyX;
	float scaleOfButtonEnablesUnzipLibraryX = scaleOfButtonLoadsClassesFrequentlyUsedAdvancelyX;
	float scaleOfEnablesUnzipLibrary = scaleOfLoadsClassesFrequentlyUsedAdvancelyY;
	
	float scaleOfButtonRegisterOtherLibX = 0.7f;
	float scaleOfButtonRegisterOtherLibY = scaleOfLoadsClassesFrequentlyUsedAdvancelyY;
	
	
	float scaleOfGapXBetweenPageControllers = (1-(scaleOfButtonPageControllerX*3)) / 4;
	
	private Button buttonPageController2;
	private Static staticUsesClassCache;
	private Button buttonUsesClassCache;
	private Static staticUsesChildCompilerProcess;
	private Button buttonUsesChildCompilerProcess;
	private Static staticLoadsClassesFrequentlyUsedAdvancely;
	private Button buttonLoadsClassesFrequentlyUsedAdvancely;
	private Static staticEnablesScreenKeyboard;
	private Button buttonEnablesScreenKeyboard;
	private Static staticEnablesUnzipLibrary;
	private Button buttonEnablesUnzipLibrary;
	private Panel panelControls2;
	
	
	private Button buttonPageController3;
	private Static staticShowsCopyRight;
	public Button buttonShowsCopyRight;
	
	public Button buttonRegisterOtherLib;
	
	public OtherLibsDialog otherLibsDialog;
	
	private Panel panelControls3;
	
	
	void setEnablesShowsCopyRight(boolean showsCopyRight) {
		this.buttonShowsCopyRight.Select(showsCopyRight);
		if (showsCopyRight) this.buttonShowsCopyRight.setText("enabled");
		else this.buttonShowsCopyRight.setText("disabled");
	}
	
	void setIsTripleBuffering(boolean isTripleBuffering) {
		this.buttonIsTripleBuffering.Select(isTripleBuffering);
		if (isTripleBuffering) this.buttonIsTripleBuffering.setText("enabled");
		else this.buttonIsTripleBuffering.setText("disabled");
	}
	
	void setUsesClassCache(boolean usesClassCache) {
		this.buttonUsesClassCache.Select(usesClassCache);
		if (usesClassCache) this.buttonUsesClassCache.setText("enabled");
		else this.buttonUsesClassCache.setText("disabled");
	}
	
	void setUsesChildCompilerProcess(boolean usesChildProcess) {
		//this.usesChildCompilerProcess = usesChildProcess;
		this.buttonUsesChildCompilerProcess.Select(usesChildProcess);
		if (usesChildProcess) this.buttonUsesChildCompilerProcess.setText("enabled");
		else this.buttonUsesChildCompilerProcess.setText("disabled");
	}
	
	void setLoadsClassesFrequentlyUsedAdvancely(boolean loadsClassesFrequentlyUsedAdvancely) {
		//this.loadsClassesFrequentlyUsedAdvancely = loadsClassesFrequentlyUsedAdvancely;
		this.buttonLoadsClassesFrequentlyUsedAdvancely.Select(loadsClassesFrequentlyUsedAdvancely);
		if (loadsClassesFrequentlyUsedAdvancely) this.buttonLoadsClassesFrequentlyUsedAdvancely.setText("enabled");
		else this.buttonLoadsClassesFrequentlyUsedAdvancely.setText("disabled");
	}
	
	void setEnablesScreenKeyboard(boolean enablesScreenKeyboard) {
		//this.loadsClassesFrequentlyUsedAdvancely = loadsClassesFrequentlyUsedAdvancely;
		this.buttonEnablesScreenKeyboard.Select(enablesScreenKeyboard);
		if (enablesScreenKeyboard) this.buttonEnablesScreenKeyboard.setText("enabled");
		else this.buttonEnablesScreenKeyboard.setText("disabled");
	}
	
	void setEnablesUnzipLibrary(boolean enablesUnzipLibrary) {
		//this.loadsClassesFrequentlyUsedAdvancely = loadsClassesFrequentlyUsedAdvancely;
		this.buttonEnablesUnzipLibrary.Select(enablesUnzipLibrary);
		if (enablesUnzipLibrary) this.buttonEnablesUnzipLibrary.setText("enabled");
		else this.buttonEnablesUnzipLibrary.setText("disabled");
	}
	
	
	/**ViewEx의 sized()에서 createSettingsDialog(View view)가 호출되어 생성되고 
	 * Common_Settings.settingsDialog에 저장된다.*/
	public static SettingsDialog createSettingsDialog(View view) {
		if (Common_Settings.settingsDialog!=null) 
			return Common_Settings.settingsDialog;
		int width = view.getWidth();
		int height = view.getHeight();
		int w = (int) (width*scaleOfWidth);
		int h = (int) (height*scaleOfHeight);
		int x = width/2 - w/2;
		int y = height/2 - h/2;
		Rectangle bounds = new Rectangle(x,y,w,h);
		Common_Settings.settingsDialog = new SettingsDialog(view, bounds);
		//Control.colorDialog.setOnTouchListener(this);
		Common_Settings.settingsDialog.setIsTripleBuffering(Common_Settings.settings.isTripleBuffering);
		return Common_Settings.settingsDialog;
	}
	
	
	/**여기에서 정의되는 값들은 backup_settings파일이 없을 경우 갖게 되는 디폴트 세팅값들이다.<br>
	 * janeSoft/other_lib/jl1.0.1 폴더는 있고 backup_settings이 없을 경우
	   janeSoft/other_lib/jl1.0.1 폴더를 Control.listOfOtherLibs에 등록해야 한다.<br>
	   janeSoft/other_lib/jl1.0.1 폴더가 없고 backup_settings도 없을 경우
	   디폴트 세팅값들이 적용되고 janeSoft/other_lib/jl1.0.1 폴더에 압축이 풀리고 폴더위치가 Control.listOfOtherLibs에 등록된다.<br>
	   janeSoft/other_lib/jl1.0.1 폴더가 있(없)고 backup_settings도 있을 경우
	   backup_settings의 세팅값들이 적용된다.*/
	public static class Settings {
		/** 0:backColor, 1:Keyboard Color*/
		private int[] selectedColor = {Color.WHITE, Color.RED};
		
		public int[] getSelectedColor() {
			return selectedColor;
		}
		public void setSelectedColor(int column, int selectedColor) {
			this.selectedColor[column] = selectedColor;
		}
		
		/** 이전 종료시 finish()를 안하고 종료했으면 0, 했으면 1*/
		public int isFinishingWhenExitingPrevly = 0;
		
		public boolean isTripleBuffering = false;
		
		/** isTripleBuffering이 true이고 윈도우즈에서만 가능하다.*/
		public Config bufferedImageType = Config.RGB_565;
		
		/** usesClassCache가 false이면 클래스 캐시를 지워서 클래스와 소스 등의 자원을 해제한다.*/
		public boolean usesClassCache = false;
		
		/** child 프로세스를 사용해서 자바문서를 열면 true(MDI), 
		 * 그게아니라 메인프로세스에서 열면 false(SDI)*/
		//public boolean usesChildCompilerProcess = false;
		
		/** 자주 사용하는 클래스 파일들을 스레드를 사용하여 미리 로드하는지 여부*/
		public boolean loadsClassesFrequentlyUsedAdvancely = false;
		public int textSaveFormat;
		
		/** backup_settings 파일에 없을 경우 디폴트는 0, 0 이다. 안드로이드에서는 참조안한다. 윈도우에서만*/
		public int viewX = 0;
		/** backup_settings 파일에 없을 경우 디폴트는 0, 0 이다. 안드로이드에서는 참조안한다. 윈도우에서만*/
		public int viewY = 0;
		
		/** backup_settings 파일에 없을 경우 디폴트는 1200, 700이다. 안드로이드에서는 참조안한다. 윈도우에서만, real width*/
		public int viewWidth = 1200;
		/** backup_settings 파일에 없을 경우 디폴트는 1200, 700이다.안드로이드에서는 참조안한다. 윈도우에서만, real height*/
		public int viewHeight = 750;
		
		/** original width*/
		public int originalViewWidth = 1200;
		/** original height*/
		public int originalViewHeight = 750;
		
				
		/** 화면 키보드가 가능한지 여부*/
		public boolean EnablesScreenKeyboard = false;
		
		/** 프로그램 시작시 gsoft.zip, project.zip 등을 압축해제할 것인지를 결정한다.*/
		public boolean EnablesUnzipLibrary = false;
		
		public boolean EnablesShowsCopyRight = false;
		
		public Settings() {
			if (Common_Settings.CurrentSystem.equals(Common_Settings.CurrentSystemIsJava)) {
				EnablesScreenKeyboard = false;
			}
			else {//안드로이드
				EnablesScreenKeyboard = true;
			}
		}
	}
	
	
	void createMenuTextFormat() {
		
		int viewWidth = Control.view.getWidth();
		int viewHeight = Control.view.getHeight();
		int x, y;
		int width=(int) (viewWidth*0.6f);
		int height=(int) (viewHeight*0.3f);
		x = viewWidth/2-width/2;
		y = viewHeight/2-height/2;
		Rectangle boundsMenuTextSaveFormat = new Rectangle(x,y,width,height);  
		menuTextFormat = new MenuWithClosable("MenuTextSaveFormat", boundsMenuTextSaveFormat, 
				MenuType.Vertical, this, namesOfMenuTextFormat, new Size(3,3), true, this);
	}
	
	public void createOtherLibsDialog(boolean changeBounds) {
		//if (Edit.findReplaceDialog!=null) return;
		int w = (int) (Control.view.getWidth()*0.7f);
		int h = (int) (Control.view.getHeight()*0.6f);
		int x = Control.view.getWidth()/2 - w/2;
		int y = Control.view.getHeight()/2 - h/2;
		Rectangle bounds = new Rectangle(x, y, w, h);
		if (!changeBounds) {
			if (otherLibsDialog==null) {
				otherLibsDialog = new OtherLibsDialog(Control.view, bounds);
			}
		}
		else {
			otherLibsDialog.changeBounds(bounds);
		}
	}
	

	public SettingsDialog(Object owner, Rectangle bounds) {
		super(owner, bounds);
		
		this.bounds = bounds;
		heightTitleBar = (int) (bounds.height*scaleOfTitleBar);
		
		
		this.isTitleBarEnable = true;
		this.Text = "Settings";
		
		int heightOfGap = (int)(bounds.height * scaleOfGapY);
		int widthOfGap = (int)(bounds.width * scaleOfGapX);
		int alpha = 255;
		
		this.backColor = Color.CYAN;
		setBackColor(backColor);
		
		Edit.setBackColor(Color.WHITE);
		
		int colorOfButton = ColorEx.darkerOrLighter(Color.WHITE, -100);
		
		int widthOfGapBetweenButtonPageControllers = 
				(int) (bounds.width * this.scaleOfGapXBetweenPageControllers);
		int x, y, width, height;
		
		
		/////////////////////////// Page 1 시작 /////////////////////////
		
		width = (int) (bounds.width * scaleOfButtonPageControllerX);
		height = (int) (bounds.height * scaleOfButtonPageControllerY);
		x = bounds.x + widthOfGapBetweenButtonPageControllers;
		y = bounds.y + heightTitleBar + heightOfGap;
		
		buttonPageController  = new Button(owner, "PageSet 1", "PageSet 1", 
				Color.DKGRAY, new Rectangle(x,y,width,height), false, alpha, true, 0.0f, null, Color.CYAN);
		buttonPageController.setBackColor(Color.DKGRAY);
		buttonPageController.setOnTouchListener(this);
		
		
		
		width = (int) (bounds.width * scaleOfColorButtonsX);
		height = (int) (bounds.height * scaleOfColorButtonsY);
		x = bounds.x;
		y = buttonPageController.bounds.bottom();
		
		
		Rectangle boundsOfColorButtons=null;
		
		int i, j, k=0;
		for (j=0; j<namesOfColorButtons.length; j++) {
			y += heightOfGap;
			x = bounds.x; 
			for (i=0; i<2; i++) {				
				x += widthOfGap;
				boundsOfColorButtons = new Rectangle(x, y,width,height);
				//k = j*1+i;
				if (i%2==0) {
					Static text = new Static(owner, textesOfColorButtons[j], textColor, boundsOfColorButtons);
					controlsOfSettings[k] = text;
				}
				else {
					Button button  = new Button(owner, namesOfColorButtons[j], namesOfColorButtons[j], 
							colors[j], boundsOfColorButtons, false, alpha, true, 0.0f, null, Color.CYAN);
					controlsOfSettings[k] = button;
					button.ColorSelected = Color.DKGRAY;				
					button.setOnTouchListener(this);
				}
				k++;
				x += width;
			}
			y += height;
		}
		
		
		int widthOfGapOfIsTripleBuffering = (int) ((1 - 2 * this.scaleOfbuttonIsTripleBufferingX) * bounds.width / 3);
		
		x = bounds.x + widthOfGapOfIsTripleBuffering;
		y = boundsOfColorButtons.bottom() + heightOfGap;
		width = (int) (bounds.width * this.scaleOfbuttonIsTripleBufferingX);
		height = (int) (bounds.height * this.scaleOfbuttonIsTripleBufferingY);
		Rectangle boundsOfstaticIsTripleBuffering = new Rectangle(x,y,width,height);
		
		this.staticIsTripleBuffering = new Static(owner, "IsTripleBuffering", textColor, boundsOfstaticIsTripleBuffering);
		
		
		x = boundsOfstaticIsTripleBuffering.right() + widthOfGapOfIsTripleBuffering;
		Rectangle boundsOfButtonIsTripleBuffering = new Rectangle(x,y,width,height);
		
		this.buttonIsTripleBuffering  = new Button(owner, "IsTripleBuffering", "enabled", 
				Color.WHITE, boundsOfButtonIsTripleBuffering, true, alpha, true, 0.0f, null, Color.CYAN);
		buttonIsTripleBuffering.toggleable = true;
		buttonIsTripleBuffering.setOnTouchListener(this);
		
		
		
		
		width = (int) (bounds.width * this.scaleOfEditTextDirectoryX);
		height = (int) (bounds.height * this.scaleOfstaticEditTextDirectory);
		x = bounds.x + widthOfGap;
		y = boundsOfstaticIsTripleBuffering.bottom() + heightOfGap;
		Rectangle boundsOfstaticEditTextDirectory = new Rectangle(x,y,width,height);
		
		this.staticEditTextDirectory = new Static(owner, "SDK directory", textColor, boundsOfstaticEditTextDirectory);
		
		
		// staticEditTextDirectory의 영역 바로 아래에 boundsOfEditTextDirectory의 영역을 잡는다.
		width = (int) (bounds.width * this.scaleOfEditTextDirectoryX);
		// 영역의 크기를 scaleOfEditTextDirectoryY의 크기에서 scaleOfstaticEditTextDirectory의 크기를 뺀
		// 크기로 설정한다. 참고) scaleOfGapY을 계산할때 gapY의 개수를 4개로 설정한것과 비교한다.
		height = (int) (bounds.height * (this.scaleOfEditTextDirectoryY-this.scaleOfstaticEditTextDirectory));
		x = bounds.x + widthOfGap;
		y = boundsOfstaticEditTextDirectory.bottom()/* + heightOfGap*/;
		Rectangle boundsOfEditTextDirectory = new Rectangle(x,y,width,height);
		
		width = (int) (bounds.width * this.scaleOfButtonFileExplorerX);
		height = boundsOfEditTextDirectory.height;
		x = boundsOfEditTextDirectory.right() + widthOfGap;
		Rectangle boundsOfButtonFileExplorer = new Rectangle(x,y,width,height);
		
		/*EditText(boolean hasToolbarAndMenuFontSize, boolean isDockingOfToolbarFlexiable, Object owner, 
				String name, RectangleF paramBounds, float fontSize, 
				boolean isSingleLine, CodeString text, ScrollMode scrollMode, int backColor) {*/
		this.editTextDirectory = new EditText(false, false, this, "Directory", boundsOfEditTextDirectory, 
				boundsOfEditTextDirectory.height*0.5f, true, 
				new CodeString("",Color.BLACK), ScrollMode.VScroll, Color.WHITE);
		editTextDirectory.isReadOnly = true;
		editTextDirectory.setIsSingleLine(true);
		
		this.buttonFileExplorer = new Button(owner, "Explorer", "Explorer", 
				colorOfButton, boundsOfButtonFileExplorer, false, alpha, true, 0.0f, null, Color.CYAN);
		buttonFileExplorer.setOnTouchListener(this);
		
		
		
		
		// 이제까지의 컨트롤들을 담는 패널을 만든다.
		x = bounds.x;
		y = this.buttonPageController.bounds.bottom();
		width = bounds.width;
		height = boundsOfEditTextDirectory.bottom() - y;
		
		panelControls = new Panel(new Rectangle(x,y,width,height));
		for (k=0; k<controlsOfSettings.length; k++) {
			panelControls.add(controlsOfSettings[k]);
		}
		//panelControls.add(staticButtonTextSaveFormat);
		//panelControls.add(buttonTextSaveFormat);
		
		// 메뉴는 setHides(false)를 하면 스택에 등록되어 자동적으로 그려지므로
		// 넣지 않는다.
		//panelControls.add(menuTextSaveFormat);
		panelControls.add(staticIsTripleBuffering);
		panelControls.add(buttonIsTripleBuffering);
		panelControls.add(staticEditTextDirectory);
		panelControls.add(editTextDirectory);
		panelControls.add(buttonFileExplorer);
		
		/////////////////////////// Page 1 끝 /////////////////////////
		
		
		/////////////////////////// Page 2 시작 /////////////////////////
		
		width = (int) (bounds.width * scaleOfButtonPageControllerX);
		height = (int) (bounds.height * scaleOfButtonPageControllerY);
		x = buttonPageController.bounds.right() + widthOfGapBetweenButtonPageControllers;
		y = bounds.y + heightTitleBar + heightOfGap;
		
		buttonPageController2  = new Button(owner, "PageSet 2", "PageSet 2", 
				Color.DKGRAY, new Rectangle(x,y,width,height), false, alpha, true, 0.0f, null, Color.CYAN);
		buttonPageController2.setBackColor(Color.DKGRAY);
		buttonPageController2.setOnTouchListener(this);
		
		
		width = (int) (bounds.width * this.scaleOfStaticUsesClassCacheX);
		height = (int) (bounds.height * this.scaleOfUsesClassCacheY);
		x = bounds.x + widthOfGapOfIsTripleBuffering;
		y = buttonPageController2.bounds.bottom() + heightOfGap;
		
		this.staticUsesClassCache = new Static(owner, "Uses Class Cache", textColor, new Rectangle(x,y,width,height));
		
		
		width = (int) (bounds.width * this.scaleOfbuttonIsTripleBufferingX);
		height = (int) (bounds.height * this.scaleOfbuttonIsTripleBufferingY);
		x = staticUsesClassCache.bounds.right() + widthOfGapOfIsTripleBuffering;
		
		this.buttonUsesClassCache  = new Button(owner, "UsesClassCache", "UsesClassCache", 
				Color.WHITE, new Rectangle(x,y,width,height), true, alpha, true, 0.0f, null, Color.CYAN);
		buttonUsesClassCache.toggleable = true;
		buttonUsesClassCache.setOnTouchListener(this);
		
		
		
		
		x = bounds.x + widthOfGapOfIsTripleBuffering;
		width = (int) (bounds.width * this.scaleOfStaticUsesChildCompilerProcessX);
		height = (int) (bounds.height * this.scaleOfUsesChildCompilerProcessY);
		y = staticUsesClassCache.bounds.bottom() + heightOfGap;		
		this.staticUsesChildCompilerProcess = new Static(owner, "Uses child process", textColor, new Rectangle(x,y,width,height));
		
		
		x = staticUsesChildCompilerProcess.bounds.right() + widthOfGapOfIsTripleBuffering;		
		this.buttonUsesChildCompilerProcess  = new Button(owner, "Uses child process", "Uses child process", 
				Color.WHITE, new Rectangle(x,y,width,height), true, alpha, true, 0.0f, null, Color.CYAN);
		buttonUsesChildCompilerProcess.toggleable = true;
		buttonUsesChildCompilerProcess.setOnTouchListener(this);
		
		
		x = bounds.x + widthOfGapOfIsTripleBuffering;
		width = (int) (bounds.width * this.scaleOfStaticLoadsClassesFrequentlyUsedAdvancelyX);
		height = (int) (bounds.height * this.scaleOfLoadsClassesFrequentlyUsedAdvancelyY);
		y = staticUsesChildCompilerProcess.bounds.bottom() + heightOfGap;		
		this.staticLoadsClassesFrequentlyUsedAdvancely = new Static(owner, "Loads classes advancely", textColor, new Rectangle(x,y,width,height));
		
		
		x = staticLoadsClassesFrequentlyUsedAdvancely.bounds.right() + widthOfGapOfIsTripleBuffering;		
		this.buttonLoadsClassesFrequentlyUsedAdvancely  = new Button(owner, "LoadsClassesFrequentlyUsedAdvancely", "LoadsClassesFrequentlyUsedAdvancely", 
				Color.WHITE, new Rectangle(x,y,width,height), true, alpha, true, 0.0f, null, Color.CYAN);
		buttonLoadsClassesFrequentlyUsedAdvancely.toggleable = true;
		buttonLoadsClassesFrequentlyUsedAdvancely.setOnTouchListener(this);
		
		
		
		x = bounds.x + widthOfGapOfIsTripleBuffering;
		width = (int) (bounds.width * this.scaleOfStaticEnablesScreenKeyboardX);
		height = (int) (bounds.height * this.scaleOfEnablesScreenKeyboard);
		y = staticLoadsClassesFrequentlyUsedAdvancely.bounds.bottom() + heightOfGap;		
		this.staticEnablesScreenKeyboard = new Static(owner, "Enables screen keyboard", textColor, new Rectangle(x,y,width,height));
		
		
		x = staticEnablesScreenKeyboard.bounds.right() + widthOfGapOfIsTripleBuffering;		
		this.buttonEnablesScreenKeyboard  = new Button(owner, "EnablesScreenKeyboard", "EnablesScreenKeyboard", 
				Color.WHITE, new Rectangle(x,y,width,height), true, alpha, true, 0.0f, null, Color.CYAN);
		buttonEnablesScreenKeyboard.toggleable = true;
		buttonEnablesScreenKeyboard.setOnTouchListener(this);
		
		
		x = bounds.x + widthOfGapOfIsTripleBuffering;
		width = (int) (bounds.width * this.scaleOfStaticEnablesUnzipLibraryX);
		height = (int) (bounds.height * this.scaleOfEnablesUnzipLibrary);
		y = staticEnablesScreenKeyboard.bounds.bottom() + heightOfGap;		
		this.staticEnablesUnzipLibrary = new Static(owner, "Enables Unzipping library", textColor, new Rectangle(x,y,width,height));
		
		
		x = staticEnablesUnzipLibrary.bounds.right() + widthOfGapOfIsTripleBuffering;		
		this.buttonEnablesUnzipLibrary  = new Button(owner, "EnablesUnzipLibrary", "EnablesUnzipLibrary", 
				Color.WHITE, new Rectangle(x,y,width,height), true, alpha, true, 0.0f, null, Color.CYAN);
		buttonEnablesUnzipLibrary.toggleable = true;
		buttonEnablesUnzipLibrary.setOnTouchListener(this);
		
		
		// 이제까지의 컨트롤들을 담는 패널을 만든다.
		x = bounds.x;
		y = this.buttonPageController2.bounds.bottom();
		width = bounds.width;
		height = boundsOfEditTextDirectory.bottom() - y;
		
		panelControls2 = new Panel(new Rectangle(x,y,width,height));
		
		panelControls2.add(staticUsesClassCache);
		panelControls2.add(buttonUsesClassCache);
		panelControls2.add(this.staticUsesChildCompilerProcess);
		panelControls2.add(this.buttonUsesChildCompilerProcess);
		panelControls2.add(this.staticLoadsClassesFrequentlyUsedAdvancely);
		panelControls2.add(this.buttonLoadsClassesFrequentlyUsedAdvancely);
		panelControls2.add(this.staticEnablesScreenKeyboard);
		panelControls2.add(this.buttonEnablesScreenKeyboard);
		panelControls2.add(this.staticEnablesUnzipLibrary);
		panelControls2.add(this.buttonEnablesUnzipLibrary);
		
		panelControls2.setIsOpen(false);
		
		
		/////////////////////////// Page 2 끝 /////////////////////////
		
		
		/////////////////////////// Page 3 시작 /////////////////////////
		
		
		width = (int) (bounds.width * scaleOfButtonPageControllerX);
		height = (int) (bounds.height * scaleOfButtonPageControllerY);
		x = buttonPageController2.bounds.right() + widthOfGapBetweenButtonPageControllers;
		y = bounds.y + heightTitleBar + heightOfGap;
		
		buttonPageController3  = new Button(owner, "PageSet 3", "PageSet 3", 
				Color.DKGRAY, new Rectangle(x,y,width,height), false, alpha, true, 0.0f, null, Color.CYAN);
		buttonPageController3.setBackColor(Color.DKGRAY);
		buttonPageController3.setOnTouchListener(this);
		
		
		width = (int) (bounds.width * this.scaleOfStaticUsesClassCacheX);
		height = (int) (bounds.height * this.scaleOfUsesClassCacheY);
		x = bounds.x + widthOfGapOfIsTripleBuffering;
		y = buttonPageController3.bounds.bottom() + heightOfGap;
		
		this.staticShowsCopyRight = new Static(owner, "Shows CopyRight", textColor, new Rectangle(x,y,width,height));
		
		
		width = (int) (bounds.width * this.scaleOfbuttonIsTripleBufferingX);
		height = (int) (bounds.height * this.scaleOfbuttonIsTripleBufferingY);
		x = staticShowsCopyRight.bounds.right() + widthOfGapOfIsTripleBuffering;
		
		this.buttonShowsCopyRight  = new Button(owner, "ShowsCopyRight", "ShowsCopyRight", 
				Color.WHITE, new Rectangle(x,y,width,height), true, alpha, true, 0.0f, null, Color.CYAN);
		buttonShowsCopyRight.toggleable = true;
		buttonShowsCopyRight.setOnTouchListener(this);
		
		this.setEnablesShowsCopyRight(false/*true*/);
		
		
		width = (int) (bounds.width * this.scaleOfButtonRegisterOtherLibX);
		height = (int) (bounds.height * this.scaleOfButtonRegisterOtherLibY);
		float scaleOfGapX = (1-this.scaleOfButtonRegisterOtherLibX) / 2;
		int gapX = (int) (bounds.width * scaleOfGapX);
		x = bounds.x + gapX;
		y = buttonShowsCopyRight.bounds.bottom() + heightOfGap;
		
		this.buttonRegisterOtherLib  = new Button(owner, "RegisterOtherLib", "Register Other Library", 
				Color.WHITE, new Rectangle(x,y,width,height), true, alpha, true, 0.0f, null, Color.CYAN);
		buttonRegisterOtherLib.selectable = false;
		buttonRegisterOtherLib.setOnTouchListener(this);
		
		this.createOtherLibsDialog(false);
		
		
		// 이제까지의 컨트롤들을 담는 패널을 만든다.
		x = bounds.x;
		y = this.buttonPageController3.bounds.bottom();
		width = bounds.width;
		height = boundsOfEditTextDirectory.bottom() - y;
		
		panelControls3 = new Panel(new Rectangle(x,y,width,height));
		
		panelControls3.add(staticShowsCopyRight);
		panelControls3.add(buttonShowsCopyRight);
		panelControls3.add(this.buttonRegisterOtherLib);
		
		panelControls3.setIsOpen(false);
		
		
		/////////////////////////// Page 3 끝 /////////////////////////
		
		
				
		width = (int) (bounds.width * scaleOfOKButtonX);
		height = (int) (bounds.height * scaleOfOKButtonY);
		x = bounds.x + widthOfGap;
		y = boundsOfEditTextDirectory.bottom() + heightOfGap;
		Rectangle boundsOfButtonOK = new Rectangle(x,y,width,height);
		x = boundsOfButtonOK.right() + widthOfGap;
		Rectangle boundsOfButtonCancel = new Rectangle(x,y,width,height);
		
		controls = new Button[2];
		controls[0] = new Button(owner, Dialog.NameButtonOk, Control.res.getString(R.string.OK), 
				colorOfButton, boundsOfButtonOK, false, alpha, true, 0.0f, null, Color.CYAN);
		controls[1] = new Button(owner, Dialog.NameButtonCancel, Control.res.getString(R.string.cancel), 
				colorOfButton, boundsOfButtonCancel, false, alpha, true, 0.0f, null, Color.CYAN);
		// 이벤트를 이 클래스에서 직접 처리
		controls[0].setOnTouchListener(this);
		controls[1].setOnTouchListener(this);
	}
	
	/*public void open() {
		super.open(true);		
	}*/
	
	 public void changeBounds() {
		this.bounds.width = (int) (Control.view.getWidth()*scaleOfWidth);
		this.bounds.height = (int) (Control.view.getHeight()*scaleOfHeight);
		this.bounds.x = Control.view.getWidth()/2 - this.bounds.width/2;
		this.bounds.y = Control.view.getHeight()/2 - this.bounds.height/2;
		
	    //this.bounds = bounds;
		heightTitleBar = (int) (bounds.height*scaleOfTitleBar);
		
		
		int heightOfGap = (int)(bounds.height * scaleOfGapY);
		int widthOfGap = (int)(bounds.width * scaleOfGapX);
		int widthOfGapBetweenButtonPageControllers = 
				(int) (bounds.width * this.scaleOfGapXBetweenPageControllers);
		int x, y, width, height;
		Rectangle boundsControl = null;
		
		
		/////////////////////////// Page 1 시작 /////////////////////////
		
		width = (int) (bounds.width * scaleOfButtonPageControllerX);
		height = (int) (bounds.height * scaleOfButtonPageControllerY);
		x = bounds.x + widthOfGapBetweenButtonPageControllers;
		y = bounds.y + heightTitleBar + heightOfGap;
		boundsControl = new Rectangle(x, y, width, height);
		buttonPageController.changeBounds(boundsControl);
		
		
		
		width = (int) (bounds.width * scaleOfColorButtonsX);
		height = (int) (bounds.height * scaleOfColorButtonsY);
		x = bounds.x;
		y = buttonPageController.bounds.bottom();
		
		
		Rectangle boundsOfColorButtons=null;
		
		int i, j, k=0;
		for (j=0; j<namesOfColorButtons.length; j++) {
			y += heightOfGap;
			x = bounds.x; 
			for (i=0; i<2; i++) {				
				x += widthOfGap;
				boundsOfColorButtons = new Rectangle(x, y,width,height);
				//k = j*1+i;
				if (i%2==0) {
					((Static)controlsOfSettings[k]).changeBounds(boundsOfColorButtons);
				}
				else {
					((Button)controlsOfSettings[k]).changeBounds(boundsOfColorButtons);
				}
				k++;
				x += width;
			}
			y += height;
		}
		
		
		int widthOfGapOfIsTripleBuffering = (int) ((1 - 2 * this.scaleOfbuttonIsTripleBufferingX) * bounds.width / 3);
		
		x = bounds.x + widthOfGapOfIsTripleBuffering;
		y = boundsOfColorButtons.bottom() + heightOfGap;
		width = (int) (bounds.width * this.scaleOfbuttonIsTripleBufferingX);
		height = (int) (bounds.height * this.scaleOfbuttonIsTripleBufferingY);
		Rectangle boundsOfstaticIsTripleBuffering = new Rectangle(x,y,width,height);
		
		this.staticIsTripleBuffering.changeBounds(boundsOfstaticIsTripleBuffering);
		
		
		x = boundsOfstaticIsTripleBuffering.right() + widthOfGapOfIsTripleBuffering;
		Rectangle boundsOfButtonIsTripleBuffering = new Rectangle(x,y,width,height);
		
		this.buttonIsTripleBuffering.changeBounds(boundsOfButtonIsTripleBuffering);
		
		
		
		width = (int) (bounds.width * this.scaleOfEditTextDirectoryX);
		height = (int) (bounds.height * this.scaleOfstaticEditTextDirectory);
		x = bounds.x + widthOfGap;
		y = boundsOfstaticIsTripleBuffering.bottom() + heightOfGap;
		Rectangle boundsOfstaticEditTextDirectory = new Rectangle(x,y,width,height);
		
		this.staticEditTextDirectory.changeBounds(boundsOfstaticEditTextDirectory);
		
		
		// staticEditTextDirectory의 영역 바로 아래에 boundsOfEditTextDirectory의 영역을 잡는다.
		width = (int) (bounds.width * this.scaleOfEditTextDirectoryX);
		// 영역의 크기를 scaleOfEditTextDirectoryY의 크기에서 scaleOfstaticEditTextDirectory의 크기를 뺀
		// 크기로 설정한다. 참고) scaleOfGapY을 계산할때 gapY의 개수를 4개로 설정한것과 비교한다.
		height = (int) (bounds.height * (this.scaleOfEditTextDirectoryY-this.scaleOfstaticEditTextDirectory));
		x = bounds.x + widthOfGap;
		y = boundsOfstaticEditTextDirectory.bottom()/* + heightOfGap*/;
		Rectangle boundsOfEditTextDirectory = new Rectangle(x,y,width,height);
		
		width = (int) (bounds.width * this.scaleOfButtonFileExplorerX);
		height = boundsOfEditTextDirectory.height;
		x = boundsOfEditTextDirectory.right() + widthOfGap;
		Rectangle boundsOfButtonFileExplorer = new Rectangle(x,y,width,height);
		
		/*EditText(boolean hasToolbarAndMenuFontSize, boolean isDockingOfToolbarFlexiable, Object owner, 
				String name, RectangleF paramBounds, float fontSize, 
				boolean isSingleLine, CodeString text, ScrollMode scrollMode, int backColor) {*/
		this.editTextDirectory.changeBounds(boundsOfEditTextDirectory);
		
		this.buttonFileExplorer.changeBounds(boundsOfButtonFileExplorer);
		
		
		
		
		// 이제까지의 컨트롤들을 담는 패널을 만든다.
		x = bounds.x;
		y = this.buttonPageController.bounds.bottom();
		width = bounds.width;
		height = boundsOfEditTextDirectory.bottom() - y;
		
		panelControls.changeBounds(new Rectangle(x,y,width,height));
		
		
		/////////////////////////// Page 1 끝 /////////////////////////
		
		
		/////////////////////////// Page 2 시작 /////////////////////////
		
		width = (int) (bounds.width * scaleOfButtonPageControllerX);
		height = (int) (bounds.height * scaleOfButtonPageControllerY);
		x = buttonPageController.bounds.right() + widthOfGapBetweenButtonPageControllers;
		y = bounds.y + heightTitleBar + heightOfGap;
		
		buttonPageController2.changeBounds(new Rectangle(x,y,width,height));
		
		
		width = (int) (bounds.width * this.scaleOfStaticUsesClassCacheX);
		height = (int) (bounds.height * this.scaleOfUsesClassCacheY);
		x = bounds.x + widthOfGapOfIsTripleBuffering;
		y = buttonPageController2.bounds.bottom() + heightOfGap;
		
		this.staticUsesClassCache.changeBounds(new Rectangle(x,y,width,height));
		
		
		width = (int) (bounds.width * this.scaleOfbuttonIsTripleBufferingX);
		height = (int) (bounds.height * this.scaleOfbuttonIsTripleBufferingY);
		x = staticUsesClassCache.bounds.right() + widthOfGapOfIsTripleBuffering;
		
		this.buttonUsesClassCache.changeBounds(new Rectangle(x,y,width,height));
		
		
		x = bounds.x + widthOfGapOfIsTripleBuffering;
		width = (int) (bounds.width * this.scaleOfStaticUsesChildCompilerProcessX);
		height = (int) (bounds.height * this.scaleOfUsesChildCompilerProcessY);
		y = staticUsesClassCache.bounds.bottom() + heightOfGap;		
		this.staticUsesChildCompilerProcess.changeBounds(new Rectangle(x,y,width,height));
		
		
		x = staticUsesChildCompilerProcess.bounds.right() + widthOfGapOfIsTripleBuffering;		
		this.buttonUsesChildCompilerProcess.changeBounds(new Rectangle(x,y,width,height));
		
		
		x = bounds.x + widthOfGapOfIsTripleBuffering;
		width = (int) (bounds.width * this.scaleOfStaticLoadsClassesFrequentlyUsedAdvancelyX);
		height = (int) (bounds.height * this.scaleOfLoadsClassesFrequentlyUsedAdvancelyY);
		y = staticUsesChildCompilerProcess.bounds.bottom() + heightOfGap;		
		this.staticLoadsClassesFrequentlyUsedAdvancely.changeBounds(new Rectangle(x,y,width,height));
		
		
		x = staticLoadsClassesFrequentlyUsedAdvancely.bounds.right() + widthOfGapOfIsTripleBuffering;		
		this.buttonLoadsClassesFrequentlyUsedAdvancely.changeBounds(new Rectangle(x,y,width,height));
		
		
		
		x = bounds.x + widthOfGapOfIsTripleBuffering;
		width = (int) (bounds.width * this.scaleOfStaticEnablesScreenKeyboardX);
		height = (int) (bounds.height * this.scaleOfEnablesScreenKeyboard);
		y = staticLoadsClassesFrequentlyUsedAdvancely.bounds.bottom() + heightOfGap;		
		this.staticEnablesScreenKeyboard.changeBounds(new Rectangle(x,y,width,height));
		
		
		x = staticEnablesScreenKeyboard.bounds.right() + widthOfGapOfIsTripleBuffering;		
		this.buttonEnablesScreenKeyboard.changeBounds(new Rectangle(x,y,width,height));
		
		
		x = bounds.x + widthOfGapOfIsTripleBuffering;
		width = (int) (bounds.width * this.scaleOfStaticEnablesUnzipLibraryX);
		height = (int) (bounds.height * this.scaleOfEnablesUnzipLibrary);
		y = staticEnablesScreenKeyboard.bounds.bottom() + heightOfGap;		
		this.staticEnablesUnzipLibrary.changeBounds(new Rectangle(x,y,width,height));
		
		
		x = staticEnablesUnzipLibrary.bounds.right() + widthOfGapOfIsTripleBuffering;		
		this.buttonEnablesUnzipLibrary.changeBounds(new Rectangle(x,y,width,height));
		
		// 이제까지의 컨트롤들을 담는 패널을 만든다.
		x = bounds.x;
		y = this.buttonPageController2.bounds.bottom();
		width = bounds.width;
		height = boundsOfEditTextDirectory.bottom() - y;
		
		panelControls2.changeBounds(new Rectangle(x,y,width,height));
		
		
		
		/////////////////////////// Page 2 끝 /////////////////////////
		
		
		/////////////////////////// Page 3 시작 /////////////////////////
		
		
		width = (int) (bounds.width * scaleOfButtonPageControllerX);
		height = (int) (bounds.height * scaleOfButtonPageControllerY);
		x = buttonPageController2.bounds.right() + widthOfGapBetweenButtonPageControllers;
		y = bounds.y + heightTitleBar + heightOfGap;
		
		buttonPageController3.changeBounds(new Rectangle(x,y,width,height));
		
		
		width = (int) (bounds.width * this.scaleOfStaticUsesClassCacheX);
		height = (int) (bounds.height * this.scaleOfUsesClassCacheY);
		x = bounds.x + widthOfGapOfIsTripleBuffering;
		y = buttonPageController3.bounds.bottom() + heightOfGap;
		
		this.staticShowsCopyRight.changeBounds(new Rectangle(x,y,width,height));
		
		
		width = (int) (bounds.width * this.scaleOfbuttonIsTripleBufferingX);
		height = (int) (bounds.height * this.scaleOfbuttonIsTripleBufferingY);
		x = staticShowsCopyRight.bounds.right() + widthOfGapOfIsTripleBuffering;
		
		this.buttonShowsCopyRight.changeBounds(new Rectangle(x,y,width,height));
		
		
		
		width = (int) (bounds.width * this.scaleOfButtonRegisterOtherLibX);
		height = (int) (bounds.height * this.scaleOfButtonRegisterOtherLibY);
		float scaleOfGapX = (1-this.scaleOfButtonRegisterOtherLibX) / 2;
		int gapX = (int) (bounds.width * scaleOfGapX);
		x = bounds.x + gapX;
		y = buttonShowsCopyRight.bounds.bottom() + heightOfGap;
		
		this.buttonRegisterOtherLib.changeBounds(new Rectangle(x,y,width,height));
		
		// 이제까지의 컨트롤들을 담는 패널을 만든다.
		x = bounds.x;
		y = this.buttonPageController3.bounds.bottom();
		width = bounds.width;
		height = boundsOfEditTextDirectory.bottom() - y;
		
		panelControls3.changeBounds(new Rectangle(x,y,width,height));
		
		
		/////////////////////////// Page 3 끝 /////////////////////////
		
		
				
		width = (int) (bounds.width * scaleOfOKButtonX);
		height = (int) (bounds.height * scaleOfOKButtonY);
		x = bounds.x + widthOfGap;
		y = boundsOfEditTextDirectory.bottom() + heightOfGap;
		Rectangle boundsOfButtonOK = new Rectangle(x,y,width,height);
		x = boundsOfButtonOK.right() + widthOfGap;
		Rectangle boundsOfButtonCancel = new Rectangle(x,y,width,height);
		
		this.controls[0].changeBounds(boundsOfButtonOK);
		this.controls[1].changeBounds(boundsOfButtonCancel);
		
		
		this.createOtherLibsDialog(true);
	 }
	
	
	public void draw(Canvas canvas)
    {
		if (hides) return;
		synchronized(this) {
			try {
		        super.draw(canvas);
		        
		        this.buttonPageController.draw(canvas);
		        this.buttonPageController2.draw(canvas);
		        this.buttonPageController3.draw(canvas);
		        this.panelControls.draw(canvas);
		        this.panelControls2.draw(canvas);
		        this.panelControls3.draw(canvas);
			}catch(Exception e) { 	}
    	}
    }
	
	public void open(OnTouchListener listener, boolean isOpen) {
		// slave 로 동작할때는 settings를 바꾸지 못한다.
		if (isOpen) {
			/*if (Common_Settings.settings.usesChildCompilerProcess) {
				if (Control.isMasterOrSlave==false) return;
			}*/
		}
		super.open(isOpen);
		if (isOpen) {
			boolean isTripleBuffering = Common_Settings.settings.isTripleBuffering;
			boolean usesClassCache = Common_Settings.settings.usesClassCache;
			//boolean usesChildCompilerProcess = Common_Settings.settings.usesChildCompilerProcess;
			boolean loadsClassesFrequentlyUsedAdvancely = Common_Settings.settings.loadsClassesFrequentlyUsedAdvancely;
			boolean enablesScreenKeyboard = Common_Settings.settings.EnablesScreenKeyboard;
			boolean enablesUnzipLibrary = Common_Settings.settings.EnablesUnzipLibrary;
			
			this.setIsTripleBuffering(isTripleBuffering);
			this.setUsesClassCache(usesClassCache);
			//this.setUsesChildCompilerProcess(usesChildCompilerProcess);
			this.setLoadsClassesFrequentlyUsedAdvancely(loadsClassesFrequentlyUsedAdvancely);
			this.setEnablesScreenKeyboard(enablesScreenKeyboard);
			this.setEnablesUnzipLibrary(enablesUnzipLibrary);
			
		}
	}
	
	public static Settings restoreSettings() {
		FileInputStream stream=null;
		BufferedInputStream bis=null;
		String absFilename=null;
		String projectLocation = null;
		try {
			if (File.separator.equals("\\")) {
				absFilename = Common_Settings.pathGSoftFiles + File.separator + "backup_settings_windows";
			}
			else {
				absFilename = Common_Settings.pathGSoftFiles + File.separator + "backup_settings_linux";
			}
			stream = new FileInputStream(absFilename);
			bis = new BufferedInputStream(stream);
			projectLocation = SettingsDialog.loadProjectLocation(bis);
			
			if (projectLocation==null || projectLocation.equals("")) return null;
		} 
		catch (Exception e) {
			// backup_settings_windows, backup_settings_linux 가 없는 경우
		}
		finally {
			FileHelper.close(bis);
			FileHelper.close(stream);			
		}
		if (projectLocation==null || projectLocation.equals("")) return null;
		
		Settings r = restoreProjectSettings(projectLocation);
		return r;
	}
	
	public static Settings restoreProjectSettings(String projectLocation) {
		FileInputStream stream=null;
		BufferedInputStream bis=null;
		String absFilename=null;
		Settings settings = null;
		try {
			if (projectLocation==null) {
				return new Settings();
			}
			//absFilename = projectLocation + File.separator + "backup_settings";
			if (File.separator.equals("\\")) {
				absFilename = projectLocation + File.separator + "backup_settings_windows";
			}
			else {
				absFilename = projectLocation + File.separator + "backup_settings_linux";
			}
			
			stream = new FileInputStream(absFilename);
			bis = new BufferedInputStream(stream);
			settings = SettingsDialog.loadProjectSettings(bis);
			
		} 
		catch (Exception e) {
			// backup_settings_windows, backup_settings_linux 파일이 없는 경우
			settings = new Settings();
		}
		finally {
			FileHelper.close(bis);
			FileHelper.close(stream);
		}
		return settings;
	}
	
	
	
	
	public static String loadProjectLocation(InputStream is) {
		try {			
			String pathProject = IO.readString(is, TextFormat.UTF_8).getItems();
			if (pathProject.equals("null")) {
				Common_Settings.set_pathProject(null);
			}
			else {
				Common_Settings.set_pathProject(pathProject);
				Common_Settings.setProjectPath(Common_Settings.get_pathProject());
			}
			
			
			
			return pathProject;
		}catch(Exception e) {
			//if (Common_Settings.g_printsLog) e.printStackTrace();
		}
		return null;
	}
	
	
	
	
	
	public static Settings loadProjectSettings(InputStream is) {
		try {
			Settings settings = new Settings();
			String settingsStr = IO.readString(is, TextFormat.UTF_8).getItems();
			
			int i;
			int oldStartIndexOfItem = 0;
			int startIndexOfItem = 0;
			int endIndexOfItem = -1;
			for (i=startIndexOfItem; i<settingsStr.length(); i++) {
				if (settingsStr.charAt(i)==';') {
					oldStartIndexOfItem = startIndexOfItem; 
					startIndexOfItem = i+1;
					endIndexOfItem = i;
					break;
				}
			}
			
			String color = settingsStr.substring(oldStartIndexOfItem, endIndexOfItem);
			int iColor = ColorEx.fromString(color);
			settings.setSelectedColor(0, iColor);
			
			if (settings.getSelectedColor()[0]==0) {
				settings.setSelectedColor(0, Color.WHITE);
			}
			
			for (i=startIndexOfItem; i<settingsStr.length(); i++) {
				if (settingsStr.charAt(i)==';') {
					oldStartIndexOfItem = startIndexOfItem; 
					startIndexOfItem = i+1;
					endIndexOfItem = i;
					break;
				}
			}
			color = settingsStr.substring(oldStartIndexOfItem, endIndexOfItem);
			iColor = ColorEx.fromString(color);
			settings.setSelectedColor(1, iColor);
			
			if (settings.getSelectedColor()[1]==0) {
				settings.setSelectedColor(1, Color.RED);
			}
			try {
				for (i=startIndexOfItem; i<settingsStr.length(); i++) {
					if (settingsStr.charAt(i)==';') {
						oldStartIndexOfItem = startIndexOfItem; 
						startIndexOfItem = i+1;
						endIndexOfItem = i;
						break;
					}
				}
				
				Common_Settings.pathAndroid = settingsStr.substring(oldStartIndexOfItem, endIndexOfItem);
		
				if (Common_Settings.pathAndroid.equals("null")) {
					Common_Settings.pathAndroid = Common_Settings.pathJaneSoft + File.separator + "gsoft";
				}
				if (Common_Settings.pathAndroid.length()>1 && Common_Settings.pathAndroid.charAt(Common_Settings.pathAndroid.length()-1)==File.separator.charAt(0)) {
					Common_Settings.pathAndroid = Common_Settings.pathAndroid.substring(0, Common_Settings.pathAndroid.length()-1);
				}
			} catch (Exception e) {
				Common_Settings.pathAndroid = Common_Settings.pathJaneSoft + File.separator + "gsoft";
				if (Common_Settings.g_printsLog) e.printStackTrace();
			}
			
			for (i=startIndexOfItem; i<settingsStr.length(); i++) {
				if (settingsStr.charAt(i)==';') {
					oldStartIndexOfItem = startIndexOfItem; 
					startIndexOfItem = i+1;
					endIndexOfItem = i;
					break;
				}
			}
			
			String value = settingsStr.substring(oldStartIndexOfItem, endIndexOfItem);
			boolean bValue = Boolean.parseBoolean(value);
			settings.isTripleBuffering = bValue;
			
			for (i=startIndexOfItem; i<settingsStr.length(); i++) {
				if (settingsStr.charAt(i)==';') {
					oldStartIndexOfItem = startIndexOfItem; 
					startIndexOfItem = i+1;
					endIndexOfItem = i;
					break;
				}
			}
			
			value = settingsStr.substring(oldStartIndexOfItem, endIndexOfItem);
			bValue = Boolean.parseBoolean(value);
			settings.usesClassCache = bValue;
			
			for (i=startIndexOfItem; i<settingsStr.length(); i++) {
				if (settingsStr.charAt(i)==';') {
					oldStartIndexOfItem = startIndexOfItem; 
					startIndexOfItem = i+1;
					endIndexOfItem = i;
					break;
				}
			}
			
			value = settingsStr.substring(oldStartIndexOfItem, endIndexOfItem);
			bValue = Boolean.parseBoolean(value);
			settings.loadsClassesFrequentlyUsedAdvancely = bValue;
			
			for (i=startIndexOfItem; i<settingsStr.length(); i++) {
				if (settingsStr.charAt(i)==';') {
					oldStartIndexOfItem = startIndexOfItem; 
					startIndexOfItem = i+1;
					endIndexOfItem = i;
					break;
				}
			}
			
			value = settingsStr.substring(oldStartIndexOfItem, endIndexOfItem);
			bValue = Boolean.parseBoolean(value);
			settings.EnablesScreenKeyboard = bValue;
			
			for (i=startIndexOfItem; i<settingsStr.length(); i++) {
				if (settingsStr.charAt(i)==';') {
					oldStartIndexOfItem = startIndexOfItem; 
					startIndexOfItem = i+1;
					endIndexOfItem = i;
					break;
				}
			}
			
			value = settingsStr.substring(oldStartIndexOfItem, endIndexOfItem);
			bValue = Boolean.parseBoolean(value);
			settings.EnablesUnzipLibrary = bValue;
			
			for (i=startIndexOfItem; i<settingsStr.length(); i++) {
				if (settingsStr.charAt(i)==';') {
					oldStartIndexOfItem = startIndexOfItem; 
					startIndexOfItem = i+1;
					endIndexOfItem = i;
					break;
				}
			}
			
			Common_Settings.pathJavaBin = settingsStr.substring(oldStartIndexOfItem, endIndexOfItem);
			String pathJavaBin = Common_Settings.pathJavaBin.toLowerCase();
			if (!(pathJavaBin.contains("java") && pathJavaBin.contains("bin"))) {
				Common_Settings.pathJavaBin = null;
			}
			if (Common_Settings.pathJavaBin!=null && Common_Settings.pathJavaBin.equals("null")) {
				Common_Settings.pathJavaBin = null;
			}
			
			
			
			try {
				for (i=startIndexOfItem; i<settingsStr.length(); i++) {
					if (settingsStr.charAt(i)==';') {
						oldStartIndexOfItem = startIndexOfItem; 
						startIndexOfItem = i+1;
						endIndexOfItem = i;
						break;
					}
				}
				
				Common_Settings.listOfOtherLibs.reset2();
				
				String countStr = settingsStr.substring(oldStartIndexOfItem, endIndexOfItem);  
				int countOfOtherLibs = Integer.parseInt(countStr);				
				
				for (i=0; i<countOfOtherLibs; i++) {
					try {
						for (i=startIndexOfItem; i<settingsStr.length(); i++) {
							if (settingsStr.charAt(i)==';') {
								oldStartIndexOfItem = startIndexOfItem; 
								startIndexOfItem = i+1;
								endIndexOfItem = i;
								break;
							}
						}
						
						String pathOtherLib = settingsStr.substring(oldStartIndexOfItem, endIndexOfItem);
						File fileOtherLib = new File(pathOtherLib);
						if (fileOtherLib.exists()) {
							int index = Common_Settings.listOfOtherLibs.getIndex(pathOtherLib);
							if (index==-1) {
								Common_Settings.listOfOtherLibs.add(pathOtherLib);
							}
						}
					} catch (Exception e) {
						
						if (Common_Settings.g_printsLog) e.printStackTrace();
					}
				}// for (i=0; i<countOfOtherLibs; i++) {
			}catch (Exception e) {
				
			}
			
			return settings;
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
		}
		return null;
	}
	
	
	/** Common_Settings.settings 를 저장한다.
	 * 저장시에는 pathAndroid의 끝에 '/'이 없도록 저장한다.*/
	public void saveProjectLocation(OutputStream os) {
		
		String pathProject = "null";
		if (Common_Settings.get_pathProject()!=null) {
			pathProject = Common_Settings.get_pathProject();
		}
		try {
			IO.writeString(os, pathProject, TextFormat.UTF_8, false, true);
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
	}
	
	
	
	/** Common_Settings.settings 를 저장한다.
	 * 저장시에는 pathAndroid의 끝에 '/'이 없도록 저장한다.
	 * @throws IOException */
	public void saveProjectSettings(OutputStream os) throws IOException {
		Settings settings = Common_Settings.settings;
		if (settings.getSelectedColor()[0]==0) {
			settings.setSelectedColor(0, Color.WHITE);
		}
		
		String color = ColorEx.toString(settings.getSelectedColor()[0]);
		IO.writeString(os, color, TextFormat.UTF_8, false, true);
		this.printSeparator(os);
		
		if (settings.getSelectedColor()[1]==0) {
			settings.setSelectedColor(1, Color.WHITE);
		}
		
		color = ColorEx.toString(settings.getSelectedColor()[1]);
		IO.writeString(os, color, TextFormat.UTF_8, false, true);
		this.printSeparator(os);
		
		
		String pathAndroid = Common_Settings.pathAndroid;
		if (pathAndroid==null) pathAndroid = "null";
		// 마지막 "/"을 제거한다.
		if (pathAndroid.length()>1 && pathAndroid.charAt(pathAndroid.length()-1)==File.separator.charAt(0)) {
			pathAndroid = pathAndroid.substring(0, pathAndroid.length()-1);
		}
		IO.writeString(os, pathAndroid, TextFormat.UTF_8, false, true);
		this.printSeparator(os);
				
		IO.writeString(os, String.valueOf(settings.isTripleBuffering), TextFormat.UTF_8, false, true);
		this.printSeparator(os);
		IO.writeString(os, String.valueOf(settings.usesClassCache), TextFormat.UTF_8, false, true);
		this.printSeparator(os);
		
		IO.writeString(os, String.valueOf(settings.loadsClassesFrequentlyUsedAdvancely), TextFormat.UTF_8, false, true);
		this.printSeparator(os);
		
		IO.writeString(os, String.valueOf(settings.EnablesScreenKeyboard), TextFormat.UTF_8, false, true);
		this.printSeparator(os);
		
		IO.writeString(os, String.valueOf(settings.EnablesUnzipLibrary), TextFormat.UTF_8, false, true);
		this.printSeparator(os);
		
		String pathJavaBin = Common_Settings.pathJavaBin;
		if (pathJavaBin==null) pathJavaBin = "null";
		IO.writeString(os, pathJavaBin, TextFormat.UTF_8, false, true);
		this.printSeparator(os);
		
		/*String pathProject = "null";
		if (Common_Settings.get_pathProject()!=null) {
			pathProject = Common_Settings.get_pathProject();
		}
		IO.writeString(os, pathProject, TextFormat.UTF_8, false, true);
		this.printSeparator(os);*/
		
		int i;
		// Store integer Common_Settings.listOfOtherLibs.count as a string
		// char '0'=48, '\0'(null)=0
		IO.writeString(os, String.valueOf(Common_Settings.listOfOtherLibs.count), TextFormat.UTF_8, false, true);
		this.printSeparator(os);
		for (i=0; i<Common_Settings.listOfOtherLibs.count; i++) {
			String pathOtherLib = Common_Settings.listOfOtherLibs.getItem(i);
			IO.writeString(os, pathOtherLib, TextFormat.UTF_8, false, true);
			this.printSeparator(os);
		}
		
		
	}
	
	void printSeparator(OutputStream os) {
		try {
			IO.writeString(os, ";", TextFormat.UTF_8, false, true);
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	
	String readSeparator(InputStream is) {
		try {
			return IO.readString(is, TextFormat.UTF_8).getItems();
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		return null;
	}
	
	public void setSelectedColorOfEditText(int selectedColorOfEditText) {
		//this.selectedColor[0] = selectedColorOfEditText;
		Button button = (Button)controlsOfSettings[1]; 
		button.setText(ColorEx.toString(selectedColorOfEditText));
		button.setBackColor(selectedColorOfEditText);
	}
	
	public void setSelectedColorOfKeyboard(int selectedColor) {
		//this.selectedColor[1] = selectedColor;
		Button button = (Button)controlsOfSettings[3]; 
		button.setText(ColorEx.toString(selectedColor));
		button.setBackColor(selectedColor);
	}
		
    
    @Override
    public boolean onTouch(MotionEvent event, SizeF scaleFactor) {
    	boolean r;
    	int i;
    	if (event.actionCode==MotionEvent.ActionDown || event.actionCode==MotionEvent.ActionDoubleClicked) {
	    	r = super.onTouch(event, scaleFactor);
	    	if (!r) return false;
	    	for (i=0; i<controls.length; i++) {
	    		r = controls[i].onTouch(event, scaleFactor);
	    		if (r) return true;
	    	}
	    	
	    	r = this.buttonPageController.onTouch(event, scaleFactor);
	    	if (r) return true;
	    	
	    	r = this.buttonPageController2.onTouch(event, scaleFactor);
	    	if (r) return true;
	    	
	    	r = this.buttonPageController3.onTouch(event, scaleFactor);
	    	if (r) return true;
	    	
	    	r = this.panelControls.onTouch(event, scaleFactor);
	    	if (r) return true;
	    	
	    	r = this.panelControls2.onTouch(event, scaleFactor);
	    	if (r) return true;
	    	
	    	r = this.panelControls3.onTouch(event, scaleFactor);
	    	if (r) return true;
	    	
	    	return true;
    	}
    	return false;
    }   
    
    public void cancel() {
		OK(false);
		open(false);
    }
    
   
    
    public void setEditTextDirectory(String pathAndroid) {
    	this.editTextDirectory.setText(0, new CodeString(pathAndroid, editTextDirectory.textColor));
    }
    
    /** 대화상자에서 OK 버튼을 누르면 호출된다. 
     * SettingsDialog에 있는 컨트롤들의 값으로
     * Common_Settings.settings을 설정한다.*/
    public void setSettings() {
    	Settings settings = Common_Settings.settings;
		Button colorButton1 = (Button)this.controlsOfSettings[1];
		Button colorButton3 = (Button)this.controlsOfSettings[3];
		settings.setSelectedColor(0, colorButton1.backColor);
		settings.setSelectedColor(1, colorButton3.backColor);				
						
		Common_Settings.pathAndroid = this.editTextDirectory.getText().str;
		settings.isTripleBuffering = this.buttonIsTripleBuffering.getIsSelected();
		settings.usesClassCache = this.buttonUsesClassCache.getIsSelected();
		//settings.usesChildCompilerProcess = this.buttonUsesChildCompilerProcess.getIsSelected();
		settings.loadsClassesFrequentlyUsedAdvancely = this.buttonLoadsClassesFrequentlyUsedAdvancely.getIsSelected();
		settings.EnablesScreenKeyboard = this.buttonEnablesScreenKeyboard.getIsSelected();
		settings.EnablesUnzipLibrary = this.buttonEnablesUnzipLibrary.getIsSelected();
		
		// 안드로이드의 경우 isTripleBuffering, usesChildCompilerProcess 등은 false로 한다.
		if (Common_Settings.CurrentSystem.equals(Common_Settings.CurrentSystemIsAndroid)) {
			settings.isTripleBuffering = false;
			settings.usesClassCache = false;
			//settings.usesChildCompilerProcess = false;
		}
    }
    
    
    void saveFile(String filename, TextFormat textFormat) {
    	int i;
    	EditText_Compiler editText = null;
    	for (i=Control.controlStack.count-1; i>=0; i--) {
    		Control control = Control.controlStack.getItem(i);
    		if (control instanceof EditText_Compiler) {
    			editText = (EditText_Compiler) control;
    			break;
    		}
    	}
    	
    	FileOutputStream outputStream = null;
    	BufferedOutputStream output = null;
    	
    	try {
			outputStream = new FileOutputStream(filename);
			output = new BufferedOutputStream(outputStream);
			String str = editText.getText().str;
	    	IO.writeString(output, str, textFormat, false, true);
		} catch (FileNotFoundException e) {
			
			if (Common_Settings.g_printsLog) e.printStackTrace();
		} catch (Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
		}
    	finally {
    		if (output!=null) {
				try {
					output.close();
				} catch (IOException e) {
					
					if (Common_Settings.g_printsLog) e.printStackTrace();
				}
			}
			if (outputStream!=null) {
				try {
					outputStream.close();
				} catch (IOException e) {
					
					if (Common_Settings.g_printsLog) e.printStackTrace();
				}
			}
		}
    	
    }
    

	@Override
	public void onTouchEvent(Object sender, MotionEvent e) {
		
		if (sender instanceof Button) {
			Button button = (Button)sender;
			int i;
			// button들에 대해서만, 즉 static은 아님
			for (i=1; i<controlsOfSettings.length; i+=2) {
				//if (button.name.equals(namesOfColorButtons[i])) {
				if (button.iName==controlsOfSettings[i].iName) {
					indexOfSelectedButton = i;
					CommonGUI.colorDialog.open(this, true);					
					//selectedColor[i/2] = Control.colorDialog.selectedColor;
					return;
				}
			}
			if (button.iName==controls[0].iName) // OK
            { 
				this.setSettings();
				
				// settings 를 여기에서 저장한다. 
				// slave 로 동작할때는 settings 를 저장을 못하게 한다.
				this.backupSettings();
				
				/*String filename = CommonGUI.fileDialog.curDir+CommonGUI.fileDialog.filename;
		    	TextFormat textFormat = null;
		    	if (menuTextFormat.buttons[0].isSelected) {
		    		textFormat = TextFormat.UTF_8;
		    	}
		    	else if (menuTextFormat.buttons[1].isSelected) {
		    		textFormat = TextFormat.UTF_16;
		    	}
		    	else if (menuTextFormat.buttons[2].isSelected) {
		    		textFormat = TextFormat.MS949_Korean;
		    	}
		    	if (textFormat!=null) {
		    		this.saveFile(filename, textFormat);
		    	}*/
				
				OK(true);
            	open(false);
            	callTouchListener(this, null);
            	
            	ThreadAutoTerminating thread = new ThreadAutoTerminating(this);
            	thread.start();
            	
            	
            }
            else if (button.iName==controls[1].iName) // Cancel
            {
            	cancel();
            	//this.backupSettings();
            }
            else if (button.iName==this.buttonFileExplorer.iName) {
            	CommonGUI.fileDialog.isFullScreen = true;
            	CommonGUI.fileDialog.canSelectFileType = false;
            	CommonGUI.fileDialog.isForViewing = true;
            	CommonGUI.fileDialog.setScaleValues();
            	CommonGUI.fileDialog.changeBounds(new Rectangle(0,0,Control.view.getWidth(),Control.view.getHeight()));
            	CommonGUI.fileDialog.createAndSetFileListButtons(CommonGUI.fileDialog.getCurDir(true), FileDialog.Category.All);
				//integrationKeyboard.setHides(true);
            	CommonGUI.fileDialog.open(this, "Set SDK Directory");
            	CommonGUI.fileDialog.setOnTouchListener(this);
            }
            else if (button.iName==this.buttonIsTripleBuffering.iName) {
            	this.setIsTripleBuffering(button.getIsSelected());
            }
            else if (button.iName==this.buttonPageController.iName) {
            	this.panelControls.setIsOpen(true);
            	this.panelControls2.setIsOpen(false);            	
            	this.panelControls3.setIsOpen(false);
            }
            else if (button.iName==this.buttonPageController2.iName) {
            	this.panelControls.setIsOpen(false);
            	this.panelControls2.setIsOpen(true);
            	this.panelControls3.setIsOpen(false);
            }
            else if (button.iName==this.buttonPageController3.iName) {
            	this.panelControls.setIsOpen(false);
            	this.panelControls2.setIsOpen(false);
            	this.panelControls3.setIsOpen(true);
            }
            else if (button.iName==this.buttonUsesClassCache.iName) {
            	this.setUsesClassCache(button.getIsSelected());
            }
            else if (button.iName==this.buttonUsesChildCompilerProcess.iName) {
            	this.setUsesChildCompilerProcess(button.getIsSelected());
            }
            else if (button.iName==this.buttonLoadsClassesFrequentlyUsedAdvancely.iName) {
            	this.setLoadsClassesFrequentlyUsedAdvancely(button.getIsSelected());
            }
            else if (button.iName==this.buttonEnablesScreenKeyboard.iName) {
            	this.setEnablesScreenKeyboard(button.getIsSelected());
            }
            else if (button.iName==this.buttonEnablesUnzipLibrary.iName) {
            	this.setEnablesUnzipLibrary(button.getIsSelected());
            }
            else if (button.iName==this.buttonShowsCopyRight.iName) {
            	this.setEnablesShowsCopyRight(button.getIsSelected());
            }
            else if (button.iName==this.buttonRegisterOtherLib.iName) {
            	this.otherLibsDialog.open(true);
            }
            /*else {
            	if (button.iName==this.menuTextFormat.buttons[0].iName) { // UTF-8
            		this.setTextSaveFormat(0);
            		menuTextFormat.open(false);
            	}
            	else if (button.iName==this.menuTextFormat.buttons[1].iName) { // UTF-16
            		this.setTextSaveFormat(1);
            		menuTextFormat.open(false);
            		
            	}
            	else if (button.iName==this.menuTextFormat.buttons[2].iName) { // MS-949
            		this.setTextSaveFormat(2);
            		menuTextFormat.open(false);
            	}
            }*/
		}//if (sender instanceof Button) {
		else if (sender instanceof ColorDialog) {
			ColorDialog colorDialog = (ColorDialog)sender;
			//selectedColor[indexOfSelectedButton/2] = colorDialog.selectedColor;
			String strSelectedColor = CommonGUI.colorDialog.strSelectedColor; 
			Button button = (Button)controlsOfSettings[indexOfSelectedButton];
			button.setBackColor(colorDialog.selectedColor);
			button.setText(strSelectedColor);
			
		}
		else if (sender instanceof FileDialog) {
			FileDialog fileDialog = (FileDialog)sender;
			if (fileDialog.isOK) {
				String dir = fileDialog.editTextDir.getText2();
				this.editTextDirectory.setText(0, new CodeString(dir,Color.BLACK));
			}
		}
		
	}
	
	/** Common_Settings.settings 를 저장한다.
	 * 저장시에는 pathAndroid의 끝에 '/'이 없도록 저장한다.*/
	public void backupSettings() {
		FileOutputStream stream=null;
		BufferedOutputStream bos=null;
		String absFilename=null;
		try {
			if (File.separator.equals("\\")) {
				absFilename = Common_Settings.pathGSoftFiles + File.separator + "backup_settings_windows";
			}
			else {
				absFilename = Common_Settings.pathGSoftFiles + File.separator + "backup_settings_linux";
			}
			stream = new FileOutputStream(absFilename);
			bos = new BufferedOutputStream(stream/*, IO.DefaultBufferSize*/);
			Common_Settings.settingsDialog.saveProjectLocation(bos);
		} catch (FileNotFoundException e) {
		}
		catch (Exception e) {
		}
		finally {
			if (bos!=null)
				try {
					bos.flush();
				} catch (IOException e) {
					
					e.printStackTrace();
				}
			FileHelper.close(bos);
			FileHelper.close(stream);			
		}
		
		backupProjectSettings();
	}
	
	/** Common_Settings.settings 를 저장한다.
	 * 저장시에는 pathAndroid의 끝에 '/'이 없도록 저장한다.*/
	public void backupProjectSettings() {
		FileOutputStream stream=null;
		BufferedOutputStream bos=null;
		boolean r = false;
		String absFilename=null;
		try {
			if (Common_Settings.get_pathProject()!=null) {
				if (File.separator.equals("\\")) {
					absFilename = Common_Settings.get_pathProject() + File.separator + "backup_settings_windows";
				}
				else {
					absFilename = Common_Settings.get_pathProject() + File.separator + "backup_settings_linux";
				}
				stream = new FileOutputStream(absFilename);
				bos = new BufferedOutputStream(stream/*, IO.DefaultBufferSize*/);
				Common_Settings.settingsDialog.saveProjectSettings(bos);
			}
			
			r = true;
		} catch (FileNotFoundException e) {
			r= false;
		}
		catch (Exception e) {
			r = false;
		}
		finally {
			if (bos!=null)
				try {
					bos.flush();
				} catch (IOException e) {
					
					e.printStackTrace();
				}
			FileHelper.close(bos);
			FileHelper.close(stream);
			if (!r) {
				if (absFilename!=null) {
					File file = new File(absFilename);
					file.delete();
				}
			}
		}
	}
	
	static class ThreadAutoTerminating extends Thread {
		SettingsDialog owner;
		ThreadAutoTerminating(SettingsDialog owner) {
			this.owner = owner;
		}
		public void run() {
			CommonGUI.loggingForMessageBox.setText(true, "Terminating autoly after 3 seconds..",  false);
        	CommonGUI.loggingForMessageBox.setHides(false);
        	Control.view.postInvalidate();
        	
        	try {
				Thread.sleep(3000);
			} catch (InterruptedException e1) {
				
				if (Common_Settings.g_printsLog) e1.printStackTrace();
			}
        	
        	
        	
        	Control.exit(false);
		}
	}

}