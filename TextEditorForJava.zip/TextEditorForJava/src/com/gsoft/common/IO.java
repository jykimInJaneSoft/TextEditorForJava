package com.gsoft.common;

import java.awt.Point;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;

import android.util.Log;

import com.gsoft.common.IO_types.ReturnOfReadString;
import com.gsoft.common.IO_types.TextFormat;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.util.Array;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListByte;
import com.gsoft.common.util.ArrayListChar;
import com.gsoft.common.util.ArrayListInt;
import com.gsoft.common.util.HighArray_char;
import com.gsoft.common.util.Util.BufferByte;

import com.gsoft.common.Charset;
import com.gsoft.common.IO_types;

public class IO {
	
	
	
	
	public static byte[] arrByte_Len1 = new byte[1];
	public static byte[] arrByte_Len2 = new byte[2];
	public static byte[] arrByte_Len4 = new byte[4];
	public static byte[] arrByte_Len8 = new byte[8];
	
	
	
	
	public static String LocalComputer = "LocalComputer"; 
	
	/** 리틀 엔디언이면 true이고 빅 엔디언이면 false이다.<br>
	 * 디폴트로 true이므로 little endian이 기본이다. 만약에 big endian을 쓰고 싶다면 
	 * 빅엔디안으로 바꾸기전에 IsLittleEndian의 값을 백업을 해놓고 빅엔디안으로 read/write를 한후에 
	 * 다시 백업한 값으로 복원을 해야한다. 왜냐하면 다른 곳에서도 파일입출력을 하기 위해서이다.
	 */
	//public static boolean IsLittleEndian = true;
	
	
	
	public static TextFormat textFormat = TextFormat.UTF_16;
	
	
	
	//public static int DefaultBufferSize = 10000000;
	public static int DefaultBufferSizeParam = 3;
	
	
	
	
	public static void toBytes(short s, boolean IsLittleEndian, byte[] r) {
		if (IsLittleEndian) {
			r[1] = (byte) (s>>>8);
			r[0] = (byte) (s);
		}
		else {
			r[0] = (byte) (s>>>8);
			r[1] = (byte) (s);
		}
		//return r;
	}
	
	/**2bytes의 버퍼를 char(UTF-16)으로 바꾼다.*/
	public static char toChar(byte[] buf, boolean IsLittleEndian) {		
		short s = IO.toShort(buf, IsLittleEndian);
		char r = (char)s;
		return r;		
	}
	
	public static short toShort(byte[] buf, boolean IsLittleEndian) {
		short r=0;
		if (IsLittleEndian) {	
			short two = (short) (buf[1]<<8 & 0x0000ff00);
			short one = (short) (buf[0]    & 0x000000ff);
			r = (short) (two | one);
		}
		else {		
			// big endian
			short one = (short) (buf[0]<<8 & 0x0000ff00);
			short two = (short) (buf[1]    & 0x000000ff);
			r = (short) (one | two);
		}
		return r;
		
	}
	
	public static void toBytes(long i, boolean IsLittleEndian, byte[] r) {
		//byte[] r = new byte[8];
		if (IsLittleEndian) {
			r[7] = (byte) (i>>>56);
			r[6] = (byte) (i>>>48);
			r[5] = (byte) (i>>>40);
			r[4] = (byte) (i>>>32);
			r[3] = (byte) (i>>>24);
			r[2] = (byte) (i>>>16);
			r[1] = (byte) (i>>>8);
			r[0] = (byte) (i);
		}
		else {
			r[0] = (byte) (i>>>56);
			r[1] = (byte) (i>>>48);
			r[2] = (byte) (i>>>40);
			r[3] = (byte) (i>>>32);
			r[4] = (byte) (i>>>24);
			r[5] = (byte) (i>>>16);
			r[6] = (byte) (i>>>8);
			r[7] = (byte) (i);
		}
		//return r;
	}
	
	public static long toLong(byte[] data, boolean IsLittleEndian) {
		long r=0;
		if (IsLittleEndian) {
			long eight = 	(long)data[7]<<56 & 0xff00000000000000L;
			long seven = 	(long)data[6]<<48 & 0x00ff000000000000L;
			long six = 		(long)data[5]<<40 & 0x0000ff0000000000L;
			long five = 	(long)data[4]<<32 & 0x000000ff00000000L;
			long four = 	(long)data[3]<<24 & 0x00000000ff000000L;
			long three = 	(long)data[2]<<16 & 0x0000000000ff0000L;
			long two = 		(long)data[1]<<8  & 0x000000000000ff00L;
			long one = 		(long)data[0]     & 0x00000000000000ffL;
			/*r = (long) (eight & 0xff00000000000000l | seven & 0x00ff000000000000l | six & 0x0000ff0000000000l | five & 0x000000ff00000000l | 
					four & 0xff000000 | three & 0xff0000 | two & 0xff00 | one & 0xff);*/
			r = (long) (eight | seven | six | five | 
					four | three | two | one );
		}
		else {		
			// big endian
			long one = 		(long)data[0]<<56 			& 0xff00000000000000L;
			long two = 		(long)data[1]<<48 			& 0x00ff000000000000L;
			long three = 	(long)data[2]<<40 			& 0x0000ff0000000000L;
			long four = 	(long)data[3]<<32 			& 0x000000ff00000000L;
			long five = 	(long)data[4]<<24 			& 0x00000000ff000000L;
			long six = 		(long)data[5]<<16 			& 0x0000000000ff0000L;
			long seven = 	(long)data[6]<<8  			& 0x000000000000ff00L;
			long eight = 	(long)data[7]     			& 0x00000000000000ffL;
			r = (long) (one | two | three | four | 
					five | six | seven | eight);
		}
		return r;
	}
	
	
	
	public static void toBytes(int i, boolean IsLittleEndian, byte[] r) {
		if (IsLittleEndian) {
			r[3] = (byte) (i>>>24);
			r[2] = (byte) (i>>>16);
			r[1] = (byte) (i>>>8);
			r[0] = (byte) (i);
		}
		else {
			r[0] = (byte) (i>>>24);
			r[1] = (byte) (i>>>16);
			r[2] = (byte) (i>>>8);
			r[3] = (byte) (i);
		}
	}
	
	
	public static int toInt(byte[] data, boolean IsLittleEndian) {
		int r=0;
		if (data.length==4) {
			if (IsLittleEndian) {		
				int four =  (int)(data[3]<<24 & 0xff000000);
				int three = (int)(data[2]<<16 & 0x00ff0000);
				int two =   (int)(data[1]<<8  & 0x0000ff00);
				int one =   (int)(data[0]     & 0x000000ff);
				r = (int) (four | three | two | one );
			}
			else {		
				// big endian
				int one =   (int)(data[0]<<24 & 0xff000000);
				int two =   (int)(data[1]<<16 & 0x00ff0000);
				int three = (int)(data[2]<<8  & 0x0000ff00);
				int four =  (int)(data[3]     & 0x000000ff);
				//r = (int) (one & 0xff000000 | two & 0xff0000 | three & 0xff00 | four & 0xff);
				r = (int) (one | two | three | four);
			}
		}
		else if (data.length==2) {
			if (IsLittleEndian) {
				int two = (int)((data[1]<<8) & 0x0000ff00);
				int one = (int)(data[0]      & 0x000000ff);
				r = (int) (two | one);
			}
			else {		
				// big endian
				int one = (int)((data[0]<<8) & 0x0000ff00);
				int two = (int)(data[1]      & 0x000000ff);
				r = (int) (one | two);
			}
		}
		return r;
	}
	
	/** 8바이트를 읽는다.*/
	public static long readLong(InputStream bis, boolean IsLittleEndian) {
		byte[] buf = new byte[8];
		try {
			bis.read(buf, 0, buf.length);
		} catch (IOException e) {
			
			Log.e("IO-readLong",e.toString());
		}
		long r = 0;
		r = toLong(buf, IsLittleEndian);
		return r;
	}
	
	public static void writeLong(OutputStream bos, long value, boolean IsLittleEndian) {
		byte[] buf = new byte[8];
		toBytes(value, IsLittleEndian, buf);
		
		try {
			bos.write(buf, 0, buf.length);
		} catch (IOException e) {
			Log.e("IO-writeLong",e.toString());
		}
	}
	
	public static int readInt(InputStream bis, boolean IsLittleEndian) {
		byte[] buf = new byte[4];
		try {
			bis.read(buf, 0, 4);
		} catch (IOException e) {
			
			Log.e("IO-readInt",e.toString());
		}
		int r = 0;
		
		if (IsLittleEndian) {		
			int four =  (int)((buf[3]<<24) & 0xff000000);
			int three = (int)((buf[2]<<16) & 0x00ff0000);
			int two =   (int)((buf[1]<<8)  & 0x0000ff00);
			int one =   (int)(buf[0]       & 0x000000ff);
			r = (int) (four  | three  | two  | one );
		}
		else {		
			// big endian
			int one =    (int)((buf[0]<<24)    & 0xff000000);
			int two =    (int)((buf[1]<<16)    & 0x00ff0000);
			int three =  (int)((buf[2]<<8)     & 0x0000ff00);
			int four =   (int)(buf[3]          & 0x000000ff);
			r = (int) (one | two | three | four);
		}
		return r;
	}
	
	public static void writeInt(OutputStream bos, int value, boolean IsLittleEndian) {
		byte[] buf = new byte[4];
		
		if (IsLittleEndian) {
			buf[3] = (byte) (value>>>24);
			buf[2] = (byte) (value>>>16);
			buf[1] = (byte) (value>>>8);
			buf[0] = (byte) (value);
		}
		else {
			buf[0] = (byte) (value>>>24);
			buf[1] = (byte) (value>>>16);
			buf[2] = (byte) (value>>>8);
			buf[3] = (byte) (value);
		}
		
		try {
			bos.write(buf, 0, 4);
		} catch (IOException e) {
			
			Log.e("IO-writeInt",e.toString());
		}
	}
	
	public static int toUnsignedShort(byte[] buf, boolean IsLittleEndian) {
		int r;
		if (IsLittleEndian) {
			int two = (int)((buf[1]<<8) & 0x0000ff00);
			int one = (int)(buf[0] 		& 0x000000ff);
			r = (int) (two | one);
		}
		else {		
			// big endian
			int one = (int)((buf[0]<<8) & 0x0000ffff);
			int two = (int)(buf[1] 		& 0x000000ff);
			r = (int) (one | two);
		}
		return r;
	}
	
	
	public static int readUnsignedShort(InputStream bis, boolean IsLittleEndian) {
		byte[] buf = new byte[2];
		try {
			bis.read(buf, 0, 2);
		} catch (IOException e) {
			
			Log.e("IO-readInt",e.toString());
		}
		int r = IO.toUnsignedShort(buf, IsLittleEndian);
		return r;
	}
	
	public static short readShort(InputStream bis, boolean IsLittleEndian) {
		byte[] buf = new byte[2];
		try {
			bis.read(buf, 0, 2);
		} catch (IOException e) {
			
			Log.e("IO-readInt",e.toString());
		}
		short r = 0;
		
		if (IsLittleEndian) {
			short two = (short)( (buf[1]<<8) & 0x0000ff00);
			short one = (short)( buf[0]      & 0x000000ff);
			r = (short) (two | one);
		}
		else {		
			// big endian
			short one = (short)( (buf[0]<<8) & 0x0000ff00);
			short two = (short)( buf[1]      & 0x000000ff);
			r = (short) (one | two);
		}
		return r;
	}
	
	public static void writeShort(OutputStream bos, short value, boolean IsLittleEndian) {
		byte[] buf = new byte[2];
		
		if (IsLittleEndian) {
			buf[1] = (byte) (value>>>8);
			buf[0] = (byte) (value);
		}
		else {
			buf[0] = (byte) (value>>>8);
			buf[1] = (byte) (value);
		}
		
		try {
			bos.write(buf, 0, 2);
		} catch (IOException e) {
			
			Log.e("IO-writeInt",e.toString());
		}
	}
	
	public static byte readByte(InputStream bis) {
		byte[] buf = new byte[1];
		try {
			bis.read(buf, 0, buf.length);
		} catch (IOException e) {
			
			Log.e("IO-readByte",e.toString());
		}
		return buf[0];
	}
	
	
	public static boolean readBoolean(InputStream bis) {
		byte[] buf = new byte[1];
		try {
			bis.read(buf, 0, buf.length);
		} catch (IOException e) {
			
			Log.e("IO-readBoolean",e.toString());
		}
		if (buf[0]==0) return false;
		else return true;
	}
	
	public static void writeBoolean(OutputStream bos, boolean value) {
		byte[] buf = new byte[1];
				
		if (!value) buf[0] = 0;
		else buf[0] = 1;		
		
		try {
			bos.write(buf, 0, buf.length);
		} catch (IOException e) {
			
			Log.e("IO-writeBoolean",e.toString());
		}
	}
	
	public static void writeByte(OutputStream bos, byte value) {
		byte[] buf = {value};
		
		try {
			bos.write(buf, 0, buf.length);
		} catch (IOException e) {
			
			Log.e("IO-writeBoolean",e.toString());
		}
	}
	
	
	/**1바이트로 표시된 문자의 최상위 비트는 항상 0이다.
	2바이트 이상으로 표시된 문자의 경우, 
	첫 바이트의 상위 비트들이 그 문자를 표시하는 데 필요한 바이트 수를 결정한다. 
	예를 들어서 2바이트는 110으로 시작하고, 3바이트는 1110으로 시작한다.
	첫 바이트가 아닌 나머지 바이트들은 상위 2비트가 항상 10이다.*/
	public static char readCharUTF16(InputStream bis, TextFormat format, boolean IsLittleEndian) {
		int count=0;
		int codePoint = 0;
		byte[] buf = new byte[2];
		while (true) {
			try {
				count = bis.read(buf, 0, buf.length);					
				if (count<0) break;
				if (buf[0]==0 && buf[1]==0)  {
					break;
				}
				codePoint = IO.toInt(buf, IsLittleEndian);
				char[] arrChar = Character.toChars(codePoint);
				return arrChar[0];
			} catch (Exception e) {
				break;
			}
		}
		return 1;
	}
	
	
	
	public static void writeChar(OutputStream bos, char value, TextFormat format, boolean IsLittleEndian) throws IOException {
		if (format==TextFormat.UTF_8) {
			writeCharUTF8(bos, value, IsLittleEndian);
		}
		else if (format==TextFormat.UTF_16) {
			writeCharUTF16(bos, value, IsLittleEndian);
		}
		else if (format==TextFormat.MS949_Korean) {
			//com.gsoft.common.encoding.MS949.IO.writeCharMS949_korean(bos, value, false);
			writeCharUTF8(bos, value, IsLittleEndian);
		}
	}

	
	static void writeCharUTF8(OutputStream bos, char value, boolean IsLittleEndian) throws IOException {			
		byte[] buf = com.gsoft.common.Charset.endcodeUTF8(value);
		bos.write(buf);
	}
	
	/** buffer에 유니코드 문자 c를 쓰고 offset을 전진시킨다.*/
	static void writeCharUTF8(BufferByte buffer, char c, boolean IsLittleEndian) {
		byte[] buf = com.gsoft.common.Charset.endcodeUTF8(c);
		Array.Copy(buf, 0, buffer.buffer, buffer.offset, buf.length);
		buffer.offset += buf.length;
	}
	
	static void writeCharUTF16(BufferByte buffer, char c, boolean IsLittleEndian) {
		// 지금 현재는 utf-16만
		char[] cBuf = {c};
		String str = new String(cBuf);
		int codePoint = str.codePointAt(0);
		short s = (short) (codePoint & 0x0000ffff);
		byte[] buf = new byte[2];
		IO.toBytes(s, IsLittleEndian, buf);
		Array.Copy(buf, 0, buffer.buffer, buffer.offset, buf.length);
		buffer.offset += 2;
	}
	
	static void writeCharUTF16(OutputStream bos, char value, boolean IsLittleEndian) {
		char[] cBuf = {value};
		String str = new String(cBuf);
		int codePoint = str.codePointAt(0);
		short s = (short) (codePoint & 0x0000ffff);
		IO.writeShort(bos, s, IsLittleEndian);
	}
	
	
	
	
	
	
	
	
	/**영어:1바이트, 한글:3바이트 형식(널문자는 1바이트)으로 변환하여 
	 * ByteBuffer의 offset을 전진시키면서 그 버퍼에 쓴다.
	 * 1바이트로 표시된 문자의 최상위 비트는 항상 0이다.
	2바이트 이상으로 표시된 문자의 경우, 첫 바이트의 상위 비트들이 그 문자를 표시하는 데 필요한 바이트 수를 결정한다. 예를 들어서 2바이트는 110으로 시작하고, 3바이트는 1110으로 시작한다.
	첫 바이트가 아닌 나머지 바이트들은 상위 2비트가 항상 10이다.<br>
	 buffer가 null이 아니면 안드로이드이든 자바이든 자바방식으로 통일하여 
			안드로이드와 자바가 통신이 가능하도록 한다.*/
	public static void writeString(BufferByte buffer, String str, TextFormat format, boolean addsNull, boolean IsLittleEndian) {
		// buffer가 null이 아닐 경우 스트링은 null(두바이트 0)로 끝나야 하므로 
		// buffer에 쓸때도 null로 끝내야 한다. readStringUTF16()을 참조한다.
		if (str==null) return;
		if (addsNull) { str += "\0";}
		char[] buf = new char[str.length()];
		str.getChars(0, str.length(), buf, 0);
		int i;
		
		for (i=0; i<buf.length; i++) {
			writeCharUTF8(buffer, buf[i], IsLittleEndian);
		}
	}
		
	/** inputStream 에서 null을 만날때까지의 바이트 스트림을 읽는다.*/
	public static BufferByte readUntilNull(InputStream is) {
		byte[] buf = new byte[1];
		ArrayListByte r = new ArrayListByte(100);
		while (true) {
			try {
				int count = is.read(buf, 0, 1);
				if (count<0 || buf[0]==0) {					
					break;
				}
				r.add(buf[0]);
			} catch (IOException e) {
				
				e.printStackTrace();
			}
		}
		return new BufferByte(r.list);
		
	}
	
	
	/** offset 이후부터 utf8 형식의 파일에서 스트링을 읽어 리턴한다.
	 * @throws Exception */
	public static int readStringUTF8_Stream(InputStream bis, ArrayListChar buffer) throws Exception {	
		return readStringUTF8_Stream(bis, null, buffer);
	}
				
	
	
	
	/**-1바이트로 표시된 문자의 최상위 비트는 항상 0이다.
	-2바이트 이상으로 표시된 문자의 경우, 
	첫 바이트의 상위 비트들이 그 문자를 표시하는 데 필요한 바이트 수를 결정한다. 
	예를 들어서 2바이트는 110으로 시작하고, 3바이트는 1110으로 시작한다.
	-첫 바이트가 아닌 나머지 바이트들은 상위 2비트가 항상 10이다.
	예를 들어, 
	가(44032, AC00) =-22, -80, -128 =
		첫바이트 : 	  1110(14)   1010(A)   
		두번째바이트 : 10(나머지바이트상위2비트) 11   00(C) 00    
		세번째바이트 : 10(나머지바이트상위2비트) 00(0)   0000(0)
		
	-22 : 22의 2의보수 11 0, 5 10, 2 110, 00010110  
		 따라서 1110(14) 1010(A)
	-80 : 80의 2의보수 40 0, 20 00, 10 000, 5 0000, 2 10000, 01010000, 
		 따라서 10 1100(C) 00
	-128 : 128의 2의보수 64 0, 32 00, 16 000, 8 0000, 4 00000, 2 000000 10000000 
		 따라서 10 00(0) 0000(0)
		 
	가 : char c = 0xac00;*/
public static int readStringUTF8_Stream(InputStream bis, BufferByte buffer, ArrayListChar resultBuffer) throws Exception {
		//byte[] testBuf = new String("위").getBytes();
		byte[] buf = new byte[1];
		int countOfReaded = -1;
		// 여기에서 버퍼를 초기화
		resultBuffer.reset2();
		
		if (buf[0]==-65) {
		}
		
		
		HighArray_char r = new HighArray_char(100);
		
		countOfReaded = readStringUTF8_sub(bis, buffer, r);
		resultBuffer.add(r.toString());
		
		
		
		return countOfReaded;
	}
	
	
	
	/**-1바이트로 표시된 문자의 최상위 비트는 항상 0이다.
	-2바이트 이상으로 표시된 문자의 경우, 
	첫 바이트의 상위 비트들이 그 문자를 표시하는 데 필요한 바이트 수를 결정한다. 
	예를 들어서 2바이트는 110으로 시작하고, 3바이트는 1110으로 시작한다.
	-첫 바이트가 아닌 나머지 바이트들은 상위 2비트가 항상 10이다.
	예를 들어, 
	가(44032, AC00) =-22, -80, -128 =
		첫바이트 : 	  1110(14)   1010(A)   
		두번째바이트 : 10(나머지바이트상위2비트) 11   00(C) 00    
		세번째바이트 : 10(나머지바이트상위2비트) 00(0)   0000(0)
		
	-22 : 22의 2의보수 11 0, 5 10, 2 110, 00010110  
		 따라서 1110(14) 1010(A)
	-80 : 80의 2의보수 40 0, 20 00, 10 000, 5 0000, 2 10000, 01010000, 
		 따라서 10 1100(C) 00
	-128 : 128의 2의보수 64 0, 32 00, 16 000, 8 0000, 4 00000, 2 000000 10000000 
		 따라서 10 00(0) 0000(0)
		 
	가 : char c = 0xac00;*/
	public static HighArray_char readStringUTF8(InputStream bis, BufferByte buffer) throws Exception {
		HighArray_char r = new HighArray_char(100);
		try {
		readStringUTF8_sub(bis, buffer, r);
		}catch(Exception e) {
			throw e;
		}
		
		//String ret = new String(r.toArray());
		//r.destroy();
		return r;
	}
	
	/**@param stopKeyword : Reads until stopKeyword("class"), 
	 * Refer to InterfaceErrorResolver.loadPackageNameAndImportClassNameOfAllJavaFilesInProject()*/
	public static ReturnOfReadString readStringUTF8(String filePath, long curFilePointer, String stopKeyword)  {
		FileInputStream inputStream = null;
		BufferedInputStream bis = null;
		
		
		try {
			inputStream = new FileInputStream(filePath);
			bis = new BufferedInputStream(inputStream);
			HighArray_char r = new HighArray_char(100);
			
			IO.readStringUTF8_sub(bis, null, r, curFilePointer, stopKeyword);
			
			return new ReturnOfReadString(r, TextFormat.UTF_8);
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			if (bis!=null) {
				try {
					bis.close();
				} catch (IOException e) {
					
					e.printStackTrace();
				}
			}
			if (inputStream!=null) {
				try {
					inputStream.close();
				} catch (IOException e) {
					
					e.printStackTrace();
				}
			}
		}
		return null;
	}
	
	public static ReturnOfReadString readStringUTF8(String filePath, long curFilePointer)  {		
		FileInputStream inputStream = null;
		BufferedInputStream bis = null;
		
		
		try {
			inputStream = new FileInputStream(filePath);
			bis = new BufferedInputStream(inputStream);
			HighArray_char r = new HighArray_char(100);
			
			IO.readStringUTF8_sub(bis, null, r, curFilePointer, null);
			
			return new ReturnOfReadString(r, TextFormat.UTF_8);
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			if (bis!=null) {
				try {
					bis.close();
				} catch (IOException e) {
					
					e.printStackTrace();
				}
			}
			if (inputStream!=null) {
				try {
					inputStream.close();
				} catch (IOException e) {
					
					e.printStackTrace();
				}
			}
		}
		return null;
	}
	

	/**@param stopKeyword : Reads until stopKeyword("class"), 
	 * Refer to InterfaceErrorResolver.loadPackageNameAndImportClassNameOfAllJavaFilesInProject()
	 * @param r : result
	 * @param curFilePointer : skip length
	 * @return : countOfReaded : in bytes
	 * @throws Exception
	 */
	private static int readStringUTF8_sub (InputStream bis, BufferByte buffer, HighArray_char r, 
			long curFilePointer, String stopKeyword) throws Exception {
		byte[] buf = new byte[1];
		byte[] bufHangul = new byte[3]; // 건강할건[-27, -127, -91] 건강할강[-27, -70, -73] 일본어[-29, -125, -101]
		int bufHanguleCount=0;
		byte[] bufLatin = new byte[2];
		
		int count=0;
		int mode = 1;
		
		int countOfReaded = 0;
		
		
		ArrayListInt listOfDocuComment_start = new ArrayListInt(1); // /*
		ArrayListInt listOfDocuComment_end = new ArrayListInt(1);   // */
		ArrayListInt listOfComment_start = new ArrayListInt(1);     // //
		ArrayListInt listOfAnnotation_start = new ArrayListInt(1);     // @
		
		
		if (curFilePointer!=0) {
			bis.skip(curFilePointer);
		}		
		
		while (true) {
			try {
				//CommonGUI.showMessage(true, "ReadString count="+countOfReaded, true);
				
				if (buffer==null) {
					count = bis.read(buf, 0, 1);
					if (count<0 || buf[0]==0) {		
						if (count<0) {
							break;
						}
						else if (buf[0]==0) {// null 까지 읽는다.
							countOfReaded++;	
						}
						break;
					}
					if (count==1) {
						countOfReaded++;
					}
				}
				else {
					// buffer.offset-1일 경우에는 문자를 얻어야 하고 그보다 크면 루프가 종료된다.
					if (buffer.offset>=buffer.buffer.length/* || buf[0]==0*/) {
						break;
					}
					
					buf[0] = buffer.buffer[buffer.offset];
					buffer.offset++;
					
					countOfReaded++;
					
					if (buf[0]==0) break; // null 까지 읽는다.
					
					//if (buf[0]=='\\') buf[0] = '/';
				}
								
				if (mode==1) {
					if (0<=buf[0] && buf[0]<=127) {	// 1바이트문자, basic latin 0이상 127이하
						if (buf[0]=='\r') continue;
						r.add((char)buf[0]);
					}
					else {
						//byte msb = (byte)((buf[0] & 0xf0) >>> 4);
						byte msb = (byte) ((buf[0] >>> 4) & 0x0f);
						if (12<=msb && msb<=13) {	// 2바이트 문자
							mode = 2;
							bufHanguleCount = 0;
						}
						else {
							if (msb==14) {	// 3바이트문자
								mode = 3;
								bufHanguleCount = 0;
							}
						}
						bufHangul[bufHanguleCount++] = buf[0];
					}
				}
				else {
					bufHangul[bufHanguleCount++] = buf[0];
					if (mode==3) {
						if (bufHanguleCount==3) {					
							//String str = new String(bufHangul, 0, 3); 
							char ch = com.gsoft.common.Charset.decodeUTF8(bufHangul);
							r.add(ch);
							mode = 1;
							bufHanguleCount = 0;
						}
					}
					else if (mode==2) {
						// LatinSupplement[-61, -87, 0] 
						
						// [-61, -87]
						// 61은 30 1, 15 01, 7 101, 3 1101, 00111101 따라서 -61은 11000011 (c3)
						// 87은 43 1, 21 11, 10 111, 5 0111, 2 10111, 01010111 따라서 10101001 (a9) 
						// 따라서 e9
						
						// [-61, -88]
						// 88은 01011000 따라서 10101000 
						// 따라서 e8
						
						// [-61, -79]
						// 61은 30 1, 15 01, 7 101, 3 1101, 00111101 따라서 -61은 11000011 (c3)
						// 79는 39 1, 19 11, 9 111, 4 1111, 01001111 따라서 -79는 10110001    
						// 따라서 f1
						
						
						
						
						// LatinExtendA 
						// [-17, -69, -65] 이후에 LatinExtendA 두 바이트 문자를 넣는다. 
						
						// 0x0100[-60, -128] 
						// 60은 00111100 따라서 -60은 1100(12) 0100
						// 128은 10000000 따라서 -128은 10000000
						
						// 0x0101[-60, -127]
						// 127은 01111111 따라서 -127은 10000001
						
						// 0x0202[-60, -126]
						
						// 0x017E [-59, -66]
						// 59는 00111011 따라서 -59는 1100(12) 0101
						// 66은 33 0, 16 10, 8 010, 4 0010, 2 00010, 01000010 따라서 -66은 10 111110
						// 첫바이트의 마지막 2비트 01과 두번째 바이트의 마지막 6비트 111110을 합치면 126이 되고,
						// 첫바이트의 마지막 3번째 비트 0x0100 + 126을 더하면 0x017E이 된다.
						
						bufLatin[0] = bufHangul[0]; 
						bufLatin[1] = bufHangul[1];
						char ch = com.gsoft.common.Charset.decodeUTF8(bufLatin);
						r.add(ch);
						mode = 1;
						bufHanguleCount = 0;
					}//mode==2
					else {
						String str = new String(bufHangul, 0, 2);
						r.add(str.charAt(0));
						mode = 1;
						bufHanguleCount = 0;
					}
				} // if (mode!=1)
				
		
				if (stopKeyword!=null && stops(r, listOfDocuComment_start, listOfDocuComment_end, 
						listOfComment_start, listOfAnnotation_start, stopKeyword)) {
					removeCommentOrAnnotation(r, listOfDocuComment_start, listOfDocuComment_end, 
							listOfComment_start, listOfAnnotation_start, stopKeyword);
					return countOfReaded;
				}//if (stopKeyword!=null) {
			} catch (Exception e) {
				
				mode = 1;
				bufHanguleCount = 0;
				//throw new Exception();
			}
		} // while
		
		return countOfReaded;
	}
	
	static boolean stops(HighArray_char r, ArrayListInt listOfDocuComment_start, ArrayListInt listOfDocuComment_end, 
			ArrayListInt listOfComment_start, ArrayListInt listOfAnnotation_start, String stopKeyword) {
		
		if (r.count-2>=0 && r.charAt(r.count-2)=='/') {
			if (r.charAt(r.count-1)=='*') listOfDocuComment_start.add(r.count-2);
			else if (r.charAt(r.count-1)=='/') listOfComment_start.add(r.count-2);
		}
		else if (r.count-2>=0 && r.charAt(r.count-2)=='*') {
			if (r.charAt(r.count-1)=='/') listOfDocuComment_end.add(r.count-2);
		}
		else if (r.count-1>=0 && r.charAt(r.count-1)=='@') listOfAnnotation_start.add(r.count-1);
		
		
		boolean stops  = false;
		// 주석, 애노테이션, 공백이 구분자 역할을 할 경우
		if (r.count-2>=0 && r.charAt(r.count-2)=='/' && r.charAt(r.count-1)=='*') {
			if (r.count-2-stopKeyword.length()-2>=0 && r.charAt(r.count-2-stopKeyword.length()-2)=='*' && r.charAt(r.count-1-stopKeyword.length()-2)=='/') {
				// */class/*
				stops  = true;
			}
			else if (r.count-1-stopKeyword.length()-2>=0 && CompilerHelper.IsBlank(r.charAt(r.count-1-stopKeyword.length()-2))) {
				// class/*
				stops  = true;
			}
			if (!stops) return false;
			if (r.count - stopKeyword.length() - 2 < 0) return false;
			for (int k=0; k<stopKeyword.length(); k++) {
				// r = .... class           stopKeyword=class
				if (stopKeyword.charAt(k)!=r.charAt(r.count - stopKeyword.length() - 2 + k)) {
					stops  = false;
					break;
				}
			}
		}
		else if (r.count-2>=0 && r.charAt(r.count-2)=='/' && r.charAt(r.count-1)=='/') {
			if (r.count-2-stopKeyword.length()-2>=0 && r.charAt(r.count-2-stopKeyword.length()-2)=='*' && r.charAt(r.count-1-stopKeyword.length()-2)=='/') {
				// */class//
				stops  = true;
			}
			else if (r.count-1-stopKeyword.length()-2>=0 && CompilerHelper.IsBlank(r.charAt(r.count-1-stopKeyword.length()-2))) {
				//  class//
				stops  = true;
			}
			if (!stops) return false;
			if (r.count - stopKeyword.length() - 2 < 0) return false;
			for (int k=0; k<stopKeyword.length(); k++) {
				// r = .... class           stopKeyword=class
				if (stopKeyword.charAt(k)!=r.charAt(r.count - stopKeyword.length() - 2 + k)) {
					stops  = false;
					break;
				}
			}
		}
		else if (r.count-1>=0 && CompilerHelper.IsBlank(r.charAt(r.count-1))) {
			if (r.count-1-stopKeyword.length()-2>=0 && r.charAt(r.count-1-stopKeyword.length()-2)=='*' && r.charAt(r.count-1-stopKeyword.length()-1)=='/') {
				// */class 
				stops  = true;
			}
			else if (r.count-1-stopKeyword.length()-1>=0 && CompilerHelper.IsBlank(r.charAt(r.count-1-stopKeyword.length()-1))) {
				//  class 
				stops  = true;
			}
			if (!stops) return false;
			if (r.count - stopKeyword.length() - 1 < 0) return false;
			for (int k=0; k<stopKeyword.length(); k++) {
				// r = .... class           stopKeyword=class
				if (stopKeyword.charAt(k)!=r.charAt(r.count - stopKeyword.length() - 1 + k)) {
					stops  = false;
					break;
				}
			}
		}
		else if (r.count-1>=0 && r.charAt(r.count-1)=='@') {
			if (r.count-1-stopKeyword.length()-2>=0 && r.charAt(r.count-1-stopKeyword.length()-2)=='*' && r.charAt(r.count-1-stopKeyword.length()-1)=='/') {
				// */class@
				stops  = true;
			}
			else if (r.count-1-stopKeyword.length()-1>=0 && CompilerHelper.IsBlank(r.charAt(r.count-1-stopKeyword.length()-1))) {
				//  class@
				stops  = true;
			}
			if (!stops) return false;
			if (r.count - stopKeyword.length() - 1 < 0) return false;
			for (int k=0; k<stopKeyword.length(); k++) {
				// r = .... class           stopKeyword=class
				if (stopKeyword.charAt(k)!=r.charAt(r.count - stopKeyword.length() - 1 + k)) {
					stops  = false;
					break;
				}
			}
		}
		if (stops) {	
			// Found stopKeyword
			if (!isCommentOrAnnotation(r, listOfDocuComment_start, listOfDocuComment_end, 
					listOfComment_start, listOfAnnotation_start)) {
				return true;
			}
		}
		return false;
	}
	static void removeCommentOrAnnotation(HighArray_char r, 
			ArrayListInt listOfDocuComment_start, ArrayListInt listOfDocuComment_end, 
			ArrayListInt listOfComment_start, ArrayListInt listOfAnnotation_start, String stopKeyword) {
		int i, j;
		int end_paired = -1;
		ArrayList listCommentsOrAnnotation = new ArrayList(10);
		ArrayList listBlockComments;
		
		for (i=0; i<listOfDocuComment_start.count; i++) {
			int start = listOfDocuComment_start.getItem(i);
			if (start<end_paired) continue; /* ... /*../*... */
			boolean paired = false;
			for (j=0; j<listOfDocuComment_end.count; j++) {
				int end = listOfDocuComment_end.getItem(j);
				if (start<end) {
					paired = true;
					end_paired = end;
					Point p = new Point();
					p.x = start; p.y = end+1;
					listCommentsOrAnnotation.add(p);
					break;
				}
			}	
			if (!paired) {
				Point p = new Point();
				p.x = start; p.y = r.count-1;
				listCommentsOrAnnotation.add(p);
			}
		}
		listBlockComments = (ArrayList) listCommentsOrAnnotation.clone();
		
		for (i=0; i<listOfComment_start.count; i++) {
			int start = listOfComment_start.getItem(i);
			for (j=0; j<listBlockComments.count; j++) {
				Point p = (Point) listBlockComments.getItem(j);
				if (p.x<=start && start<=p.y) {
					break;
				}
			}
			if (j<listBlockComments.count) continue; // BlockComment
			for (j=start; j<r.count; j++) {
				if (r.getItem(j)=='\n') {
					Point p = new Point();
					p.x = start; p.y = j;
					listCommentsOrAnnotation.add(p);
					break;
				}
			}
		}
		
		for (i=0; i<listOfAnnotation_start.count; i++) {
			int start = listOfAnnotation_start.getItem(i);
			for (j=0; j<listBlockComments.count; j++) {
				Point p = (Point) listBlockComments.getItem(j);
				if (p.x<=start && start<=p.y) {
					break;
				}
			}
			if (j<listBlockComments.count) continue; // BlockComment
			for (j=start; j<r.count; j++) {
				if (r.getItem(j)=='\n') {
					Point p = new Point();
					p.x = start; p.y = j;
					listCommentsOrAnnotation.add(p);
					break;
				}
			}
		}
		HighArray_char newResult = new HighArray_char(100);
		
		for (i=0; i<r.count; i++) {
			for (j=0; j<listCommentsOrAnnotation.count; j++) {
				Point p = (Point) listCommentsOrAnnotation.getItem(j);
				if (p.x<=i && i<=p.y) {
					break;
				}
			}
			if (j<listCommentsOrAnnotation.count) continue; // comment or annotation
			newResult.add(r.getItem(i));
		}
		r.reset2();
		for (i=0; i<newResult.count; i++) {
			r.add(newResult.getItem(i));
		}
		for (i=newResult.count-stopKeyword.length(); i>0; i--) {
			for (j=0; j<stopKeyword.length(); j++) {
				if (r.charAt(i+j)!=stopKeyword.charAt(j)) break;
			}
			if (j==stopKeyword.length()) {
				// found stopKeyword
				// 주석, 애노테이션이 구분자 역할을 할 경우를 대비해서 공백을 넣어준다.
				// public/* */class
				r.insert(i, " ");
				break;
			}
		}
		 
	}
	
	static boolean isCommentOrAnnotation(HighArray_char r, ArrayListInt listOfDocuComment_start, ArrayListInt listOfDocuComment_end, 
			ArrayListInt listOfComment_start, ArrayListInt listOfAnnotation_start) {
		int i, j;
		int end_paired = -1;
		ArrayList listBlockComments = new ArrayList(10);
		
		for (i=0; i<listOfDocuComment_start.count; i++) {
			int start = listOfDocuComment_start.getItem(i);
			if (start<end_paired) continue; /* ... /*../*... */
			boolean paired = false;
			for (j=0; j<listOfDocuComment_end.count; j++) {
				int end = listOfDocuComment_end.getItem(j);
				if (start<end) {
					paired = true;
					end_paired = end;
					Point p = new Point();
					p.x = start; p.y = end;
					listBlockComments.add(p);
					break;
				}
			}	
			if (!paired) return true;
		}
		for (i=r.count-1; i>=0; i--) {
			char c = r.charAt(i);
			if (c=='\n') return false;
			if (i-1>=0 && r.charAt(i-1)=='/' && c=='/') {
				for (j=0; j<listBlockComments.count; j++) {
					Point p = (Point) listBlockComments.getItem(j);
					// If not in BlockComment, return true
					if (!(p.x<i-1 && i-1<p.y)) return true;
				}				
			}
			if (c=='@') {
				for (j=0; j<listBlockComments.count; j++) {
					Point p = (Point) listBlockComments.getItem(j);
					// If not in BlockComment, return true
					if (!(p.x<i && i<p.y)) return true;
				}
			}
		}
		return false;		
	}
	private static int readStringUTF8_sub (InputStream bis, BufferByte buffer, HighArray_char r) throws Exception {
		return IO.readStringUTF8_sub(bis, buffer, r, 0, null);
	}
	
	
		
	
	/** buffer가 null이 아닐 경우 스트링은 null(두바이트 0)로 끝나야 하므로 
	 * buffer에 쓸때도 null로 끝내야 한다.
	 * writeString(BufferByte buffer, String str, TextFormat format)을 참조한다.*/
	private static HighArray_char readStringUTF16(InputStream bis, BufferByte buffer, boolean IsLittleEndian) throws Exception {
		
		int count=0;
		HighArray_char r = new HighArray_char(100);
		int codePoint = 0;
		byte[] buf = new byte[2];
		while (true) {
			try {
				if (buffer==null) {
					count = bis.read(buf, 0, buf.length);					
					if (count<0) break;
					if (buf[0]==0 && buf[1]==0)  {
						break;
					}
					codePoint = IO.toInt(buf, IsLittleEndian);
					char[] arrChar = Character.toChars(codePoint);
					r.add(arrChar[0]);
				}
				else {
					// buffer.offset-2일 경우에는 문자를 얻어야 하고 그보다 크면 루프가 종료된다.
					if (buffer.offset>=buffer.buffer.length/* || (buf[0]==0 && buf[1]==0)*/) {
						break;
					}
					
					buf[0] = buffer.buffer[buffer.offset];
					buf[1] = buffer.buffer[buffer.offset+1];
					buffer.offset += 2;
					
					if (buf[0]==0 && buf[1]==0) break;
					
					
					
					//if (buf[0]=='\\') buf[0] = '/';
					codePoint = IO.toInt(buf, IsLittleEndian);
					char[] arrChar = Character.toChars(codePoint);
					r.add(arrChar[0]);
					
					
					
				}
			} catch (Exception e) {
				break;
			}
		}
		//String ret = new String(r.getItems());
		//r.reset();
		return r;
	}
	
		
	
	public static String readStringKSC_UsingReader(InputStream bis) {
		BufferedReader in
		   = new BufferedReader(new InputStreamReader(bis));
		ArrayListChar r = new ArrayListChar(10000);
		r.resizeInc = 10000;
		char[] buf = new char[10000];
		while (true) {
			try {
				int count = in.read(buf);
				if (count<0) {
					break;
				}
				for (int i=0; i<count; i++) {
					r.add(buf[i]);
				}
			} catch (IOException e) {
				
				e.printStackTrace();
			}
		}
		char[] rStr = r.getItems();
		String ret = new String(rStr);
		r.destroy();
		
		return ret;
	}
	
	
	
	
	/** Java 스트림을 사용하여 파일을 읽는다.*/
	public static HighArray_char readString(InputStream bis, TextFormat format)  throws Exception {
		if (format==TextFormat.UTF_8) {
			return readStringUTF8(bis, null);
		}
		else if (format==TextFormat.UTF_16) {
			return readStringUTF16(bis, null, true);
		}
		else {
			//return com.gsoft.common.encoding.MS949.IO.readStringMS949_korean(bis, false);
			return readStringUTF8(bis, null);
		}
	}
	
	
	/** TextFormat에 상관없이 파일을 읽는다.*/
	public static ReturnOfReadString readString(String filePath)  {		
		FileInputStream inputStream = null;
		BufferedInputStream bis = null;
		
		int i=0;
		for (i=0; i<3; i++) {				
			try {
				inputStream = new FileInputStream(filePath);
				bis = new BufferedInputStream(inputStream);
				if (i==0) {					
					HighArray_char r = readStringUTF8(bis, null);
					return new ReturnOfReadString(r, TextFormat.UTF_8);
				}
				else if (i==1) {
					//String r = com.gsoft.common.encoding.MS949.IO.readStringMS949_korean(bis, false);
					//return new ReturnOfReadString(r, TextFormat.MS949_Korean);
					HighArray_char r = readStringUTF8(bis, null);
					return new ReturnOfReadString(r, TextFormat.UTF_8);
				}
				else {
					HighArray_char r = readStringUTF16(bis, null, true);
					return new ReturnOfReadString(r, TextFormat.UTF_16);
				}
			}catch(Exception e) {
				e.printStackTrace();
			}finally {
				if (bis!=null) {
					try {
						bis.close();
					} catch (IOException e) {
						
						e.printStackTrace();
					}
				}
				if (inputStream!=null) {
					try {
						inputStream.close();
					} catch (IOException e) {
						
						e.printStackTrace();
					}
				}
			}
		}
		return null;
	}
	
	
	
	/** value의 UTF8코드로 인코딩된 바이트 길이를 리턴한다.
	 * Net의 sendFile()에서 호출*/
	public static int getByteLen(char value) {		
		if (value=='\0') return 1;
		byte[] arrCh = Charset.endcodeUTF8(value);
		return arrCh.length;
	}
	
	/** value의 UTF8코드로 인코딩된 바이트 길이를 리턴한다.
	 * Net의 sendFile()에서 호출*/
	public static int getByteLen(String value) {
		int r=0;
		value += "\0";
		char[] buf = new char[value.length()];
		value.getChars(0, value.length(), buf, 0);
		int i;
		for (i=0; i<buf.length; i++) {
			r += getByteLen(buf[i]);
		}
		return r;
	}
	
	
	/*
	public static void writeStringUTF8(OutputStream os, String value, boolean addsNull, boolean IsLittleEndian) throws IOException {
		if (value==null) return;
		
		HighArray_byte r = new HighArray_byte(300); 
		int i;
		for (i=0; i<value.length(); i++) {
			char c = value.charAt(i);
			// '\n' 만 있는 경우 앞에 '\r'을 추가한다.
			if (c=='\n' && (i>0 && value.charAt(i-1)!='\r')) {
				byte[] ret = com.gsoft.common.Charset.endcodeUTF8('\r');
				r.add(ret);
			}
			byte[] buf = com.gsoft.common.Charset.endcodeUTF8(c);
			r.add(buf);
		}
		if (addsNull) {
			byte[] buf = com.gsoft.common.Charset.endcodeUTF8('\0');
			r.add(buf);
		}
		for (i=0; i<r.data.count; i++) {
			ArrayListByte item = (ArrayListByte) r.data.list[i];
			os.write(item.list, 0, item.count);
			//startIndex += item.count;
		}
		
	}*/
	
	
	/*public static void writeStringUTF8(BufferByte os, String value, boolean addsNull, boolean IsLittleEndian) throws IOException {
		if (value==null) return;
		
		HighArray_byte r = new HighArray_byte(300); 
		int i;
		for (i=0; i<value.length(); i++) {
			char c = value.charAt(i);
			// '\n' 만 있는 경우 앞에 '\r'을 추가한다.
			if (c=='\n' && (i>0 && value.charAt(i-1)!='\r')) {
				byte[] ret = com.gsoft.common.Charset.endcodeUTF8('\r');
				r.add(ret);
			}
			byte[] buf = com.gsoft.common.Charset.endcodeUTF8(c);
			r.add(buf);
		}
		if (addsNull) {
			byte[] buf = com.gsoft.common.Charset.endcodeUTF8('\0');
			r.add(buf);
		}
		for (i=0; i<r.data.count; i++) {
			ArrayListByte item = (ArrayListByte) r.data.list[i];
			Array.copy(item.list, 0, os.buffer, os.offset, item.count);
			os.offset += item.count;
			//os.write(item.list, 0, item.count);
		}
		
	}
	*/
	
	
	
	/**1바이트로 표시된 문자의 최상위 비트는 항상 0이다.
	2바이트 이상으로 표시된 문자의 경우, 첫 바이트의 상위 비트들이 그 문자를 표시하는 데 필요한 바이트 수를 결정한다. 예를 들어서 2바이트는 110으로 시작하고, 3바이트는 1110으로 시작한다.
	첫 바이트가 아닌 나머지 바이트들은 상위 2비트가 항상 10이다.
	@param addsNull : 스트링 마지막에 널문자를 추가하려면 true, 아니면 false.<br> 
	.txt 파일에 들어가는 스트링은 하나이므로 널문자 추가가 필요없으나, <br>
	스트링이 여러개나 정수, boolean, 스트링등이 같이 섞어서 들어가는 파일에는 
	스트링 구분을 위해 널문자 추가가 필요하다.
	 * @throws IOException 
	 **/
	public static void writeString(OutputStream os, String value, IO_types.TextFormat format, boolean addsNull, boolean IsLittleEndian) throws IOException {
		
		if (value==null) return;
		
	
				
		char[] buf = null;
		if (addsNull) {
			buf = new char[value.length()+1];		
		}
		else {
			buf = new char[value.length()];
		}
		
		value.getChars(0, value.length(), buf, 0);
		if (addsNull) buf[buf.length-1] = '\0';
		int i;
		
		for (i=0; i<buf.length; i++) {				
			writeChar(os, buf[i], format, IsLittleEndian);
		}
		
		try {
			os.flush();
		} catch (IOException e) {
			
			//e.printStackTrace();
		}
	}
	
	
	/**1바이트로 표시된 문자의 최상위 비트는 항상 0이다.
	2바이트 이상으로 표시된 문자의 경우, 첫 바이트의 상위 비트들이 그 문자를 표시하는 데 필요한 바이트 수를 결정한다. 예를 들어서 2바이트는 110으로 시작하고, 3바이트는 1110으로 시작한다.
	첫 바이트가 아닌 나머지 바이트들은 상위 2비트가 항상 10이다.
	@param addsNull : 스트링 마지막에 널문자를 추가하려면 true, 아니면 false.<br> 
	.txt 파일에 들어가는 스트링은 하나이므로 널문자 추가가 필요없으나, <br>
	스트링이 여러개나 정수, boolean, 스트링등이 같이 섞어서 들어가는 파일에는 
	스트링 구분을 위해 널문자 추가가 필요하다.
	
	@param value : shorter string than HighArray_char, Refer to void writeString(String filename, HighArray_char value, TextFormat format, boolean addsNull, boolean IsLittleEndian)
	 **/
	public static void writeString(String filename, String value, TextFormat format, boolean addsNull, boolean IsLittleEndian) {
		HighArray_char buf = new HighArray_char(100);
		buf.add(value);
		writeString(filename, buf, format, addsNull, IsLittleEndian);
	}
	
	/**1바이트로 표시된 문자의 최상위 비트는 항상 0이다.
	2바이트 이상으로 표시된 문자의 경우, 첫 바이트의 상위 비트들이 그 문자를 표시하는 데 필요한 바이트 수를 결정한다. 예를 들어서 2바이트는 110으로 시작하고, 3바이트는 1110으로 시작한다.
	첫 바이트가 아닌 나머지 바이트들은 상위 2비트가 항상 10이다.
	@param addsNull : 스트링 마지막에 널문자를 추가하려면 true, 아니면 false.<br> 
	.txt 파일에 들어가는 스트링은 하나이므로 널문자 추가가 필요없으나, <br>
	스트링이 여러개나 정수, boolean, 스트링등이 같이 섞어서 들어가는 파일에는 
	스트링 구분을 위해 널문자 추가가 필요하다.
	
	@param value : longer HighArray_char than string, Refer to void writeString(String filename, String value, TextFormat format, boolean addsNull, boolean IsLittleEndian)
	 **/
	public static void writeString(String filename, HighArray_char value, TextFormat format, boolean addsNull, boolean IsLittleEndian) {
		
		if (value==null) return;
		
	
		FileOutputStream fos = null;
		BufferedOutputStream os = null;
		
		try {
			fos = new FileOutputStream(filename);
			os = new BufferedOutputStream(fos);
			
			if (addsNull) {
				//buf = new char[value.count+1];
				value.add('\0');
			}
			
			int i;
			for (i=0; i<value.count; i++) {				
				writeChar(os, value.getItem(i), format, IsLittleEndian);
			}
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		} catch (Exception e) {
			
			e.printStackTrace();
		} finally {
			if (os!=null) {
				try {
					os.flush();
					os.close();
				} catch (IOException e) {
					
					e.printStackTrace();
				}
			}
			if (fos!=null) {
				try {
					fos.close();
				} catch (IOException e) {
					
					e.printStackTrace();
				}
			}
		}
		
	}
	
	
	
	
	public static void writeString_CRLF(String filename, HighArray_char value, TextFormat format, boolean addsNull, 
		int originalOrCRLFOrLF, boolean IsLittleEndian) {
		
		if (value==null) return;
		
	
		FileOutputStream fos = null;
		BufferedOutputStream os = null;
		
		try {
			fos = new FileOutputStream(filename);
			os = new BufferedOutputStream(fos);
			
			if (addsNull) {
				value.add('\0');
			}
			
			int i;
			if (originalOrCRLFOrLF==0) {
				for (i=0; i<value.count; i++) {				
					writeChar(os, value.getItem(i), format, IsLittleEndian);
				}
			}
			else if (originalOrCRLFOrLF==1) {
				for (i=0; i<value.count; i++) {
					// in "\r\n", \r and \n are two chars. But CR and LF are one char.
					// So this function don't modify \r and \n in strings.
					if ((i-1>0 && value.getItem(i-1)!='\r') && (value.getItem(i)=='\n')) {
						writeChar(os, '\r', format, IsLittleEndian);
					}
					writeChar(os, value.getItem(i), format, IsLittleEndian);
				}// for (i=0; i<value.count; i++) {
			}// else if (originalOrCRLFOrLF==1) {
			else {
				for (i=0; i<value.count; i++) {
					// in "\r\n", \r and \n are two chars. But CR and LF are one char.
					// So this function don't modify \r and \n in strings.
					if ((value.getItem(i)=='\r') && (i+1<value.count && value.getItem(i+1)=='\n')) {
						continue;
					}
					writeChar(os, value.getItem(i), format, IsLittleEndian);
				}
			}
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		} catch (Exception e) {
			
			e.printStackTrace();
		} finally {
			if (os!=null) {
				try {
					os.flush();
					os.close();
				} catch (IOException e) {
					
					e.printStackTrace();
				}
			}
			if (fos!=null) {
				try {
					fos.close();
				} catch (IOException e) {
					
					e.printStackTrace();
				}
			}
		}
		
	}
	
	
	
	public static float readFloat(InputStream bis, boolean IsLittleEndian) {
		int intBits = readInt(bis, IsLittleEndian);
		return Float.intBitsToFloat(intBits);
	}
	
	public static void writeFloat(OutputStream bos, float value, boolean IsLittleEndian) {
		int intBits = Float.floatToIntBits(value);
		writeInt(bos, intBits, IsLittleEndian);
	}
	
	/** 8바이트를 읽는다.*/
	public static double readDouble(InputStream bis, boolean IsLittleEndian) {		
		long longBits = readLong(bis, IsLittleEndian);
		return Double.longBitsToDouble(longBits);
	}
	
	public static void writeDouble(OutputStream bos, double value, boolean IsLittleEndian) {
		long longBits = Double.doubleToLongBits(value);
		writeLong(bos, longBits, IsLittleEndian);
	}
	
}