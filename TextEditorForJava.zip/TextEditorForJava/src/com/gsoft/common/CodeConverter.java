package com.gsoft.common;

import java.io.File;

import com.gsoft.common.IO_types.ReturnOfReadString;
import com.gsoft.common.IO_types.TextFormat;
import com.gsoft.common.util.ArrayList;

import com.gsoft.common.FileHelper;
import com.gsoft.common.IO;

public class CodeConverter {
	public static String getRemainder(File file, String curDir) {
		String absFileName = file.getAbsolutePath();
		int i;
		for (i=0; i<curDir.length(); i++) {
			char c = curDir.charAt(i);
			char c2 = absFileName.charAt(i);
			if (c!=c2) break;
		}
		String r = "";
		if (i+1<absFileName.length()) {
			r = absFileName.substring(i+1, absFileName.length());
		}
		return r;
	}
	
	
	
	
	public static void convertToUTF8(String srcPath, String destPath, int originalOrCRLFOrLF) {
		ArrayList list = FileHelper.getFileList(srcPath, true);
		int i;
		if (list.count==0) return;
		//String curDir = ((File)list.getItem(0)).getAbsolutePath();
		
		if (destPath.charAt(destPath.length()-1)==File.separatorChar) {
			destPath = destPath.substring(0, destPath.length()-1);
		}
		
		String curDir = srcPath;
		for (i=0; i<list.count; i++) {
			File file = (File) list.getItem(i);
			String remainder = getRemainder(file, curDir);
			String destFileName = destPath + File.separator + remainder;
			File destFile = new File(destFileName);
			if (file.isDirectory()) {
				destFile.mkdir();
			}
			else { 
				if (!FileHelper.getExt(file.getAbsolutePath()).equals(".java")) {
					continue;
				}
				ReturnOfReadString input = IO.readString(file.getAbsolutePath());
				if (input.result!=null) {
					IO.writeString_CRLF(destFileName, input.result, TextFormat.UTF_8, false, originalOrCRLFOrLF, true);
				}
			}
		}
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		/*String srcFilename = Context.assets_path + File.separator + "lib" + File.separator + "gsoft.zip";
		String srcFilenameExceptExt = FileHelper.getFilenameExceptExt(srcFilename);
		
		String relativeFilename = "com.gsoft.common.ByteCode_Types.Class_Info";
		//String relativeFilename = "com";
		relativeFilename = relativeFilename.replace('.', File.separatorChar);
		relativeFilename += ".class";
		
		String classPath = srcFilenameExceptExt + File.separator + relativeFilename;
		
		relativeFilename = CompilerHelper.fixClassPath(srcFilename, classPath);
		
		InputStream jarFileStream = null;
		try {
			jarFileStream = Util.JarFile.extract(srcFilename, relativeFilename);
		} catch (IOException e) {
			
			e.printStackTrace();
		}*/
		String srcPath =  "D:\\kjy\\eclipse_workspace\\Tetris\\src\\com";
		String destPath = "D:\\kjy\\eclipse_workspace\\Tetris\\src\\꼬리치레";
		int originalOrCRLFOrLF = 0;
		if (args!=null && args.length>0) {
			try {
				originalOrCRLFOrLF = Integer.parseInt(args[0]);
			}catch(Exception e) {
				
			}
		}
		CodeConverter.convertToUTF8(srcPath, destPath, originalOrCRLFOrLF);
		
	}

}