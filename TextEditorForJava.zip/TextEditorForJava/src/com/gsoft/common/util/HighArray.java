package com.gsoft.common.util;

import com.gsoft.common.interfaces.IReset;

import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListIReset;
import com.gsoft.common.util.HighArray_char;

/** 아주 큰 배열을 가변크기(처음 로딩시에는 고정크기 arrayLimit를 갖지만 
 * 수정을 하면 가변크기가 된다.)의 작은 배열 여러개로 나눈 array이다.*/
public class HighArray implements IReset {
	public int arrayLimit;
	
	/**ArrayList[]*/
	public ArrayList data;
	
	
	public int count;

	public int resizeInc = 100;

	
	/** @param arrayLimit : 작은 배열의 limit*/
	public HighArray (int arrayLimit) {
		this.arrayLimit = arrayLimit;
		data = new ArrayList(10);
	}
	
	/** 모든 자원을 해제한다.*/
	public void destroy() {
		int j;
		for (j=0; j<data.list.length; j++) {
			ArrayList list = (ArrayList) data.getItem(j);
			if (list!=null) list.destroy();
			list = null;
		}
		data.destroy();
	}
	
	public int getCount() {
		
		return count;
	}
	
	/**this.count, data.count, arr.count를 모두 0으로 만든다.*/
	public void reset() {
		int i;
		for (i=0; i<data.count; i++) {
			ArrayList arr = (ArrayList) data.getItem(i);
			arr.count = 0;
		}
		data.count = 0;
		this.count = 0;
	}
	
	public Object getItem(int index) {		
		int indexOfData = -1;
		int i;
		int len = 0;
		int oldLen = 0;
		for (i=0; i<data.count; i++) {
			ArrayList arr = (ArrayList) data.getItem(i);
			oldLen = len;
			len += arr.count;
			if (index<len) {
				indexOfData = i;
				break;
			}
		}
		if (index>=len) {
			return null; // ArrayIndexOUtOfBoundsException
		}
		
		int indexInArray = index - oldLen;
		
		ArrayList arrItem = (ArrayList) data.getItem(indexOfData);
		return (Object)arrItem.getItem(indexInArray);
	}
	
	public void setItem(int index, Object item) {
		int indexOfData = -1;
		int i;
		int len = 0;
		int oldLen = 0;
		for (i=0; i<data.count; i++) {
			ArrayList arr = (ArrayList) data.getItem(i);
			oldLen = len;
			len += arr.count;
			if (index<len) {
				indexOfData = i;
				break;
			}
		}
		if (index>=len) {
			return; // ArrayIndexOUtOfBoundsException
		}
		
		int indexInArray = index - oldLen;
		
		ArrayList arrItem = (ArrayList) data.getItem(indexOfData);
		arrItem.list[indexInArray] = item;
	}
	
	public void add(Object c) {
		if (data.count==0) {
			ArrayList newItem = new ArrayList(arrayLimit);
			data.add(newItem);
			newItem.resizeInc = this.resizeInc;
		}
		
		ArrayList item;
		
		// 마지막 item을 얻는다.
		ArrayList arrItem = (ArrayList) data.getItem(data.count-1);
		if (arrItem.count>=arrayLimit) { // 새로운 item을 생성해서 넣는다.
			ArrayList newItem = new ArrayList(arrayLimit);
			newItem.resizeInc = this.resizeInc;
			data.add(newItem);
			item = newItem;
		}
		else {
			item = arrItem;
		}
		
		item.add(c);
		count++;
	}
	
	public void add(Object[] o) {
		int i;
		for (i=0; i<o.length; i++) {
			this.add(o[i]);
		}
	}
	
	public void insert(int index, Object[] arrObjs) {
		int indexOfData = -1;
		int i;
		int len = 0;
		int oldLen = 0;
		for (i=0; i<data.count; i++) {
			ArrayList arr = (ArrayList) data.getItem(i);
			oldLen = len;
			len += arr.count;
			if (index<len) {
				indexOfData = i;
				break;
			}
		}
		
		int indexInArray = index - oldLen;
		
		ArrayList arrItem = (ArrayList) data.getItem(indexOfData);
		
		arrItem.insert(indexInArray, arrObjs);
		count += arrObjs.length;
	}
	
	public void insert(int index, Object obj) {
		int indexOfData = -1;
		int i;
		int len = 0;
		int oldLen = 0;
		for (i=0; i<data.count; i++) {
			ArrayList arr = (ArrayList) data.getItem(i);
			oldLen = len;
			len += arr.count;
			if (index<len) {
				indexOfData = i;
				break;
			}
		}
				
		int indexInArray = index - oldLen;
		
		ArrayList arrItem = (ArrayList) data.getItem(indexOfData);
		
		arrItem.insert(indexInArray, obj);
		count++;
	}
	
	public String toString() {
		int i;
		int len = this.getCount();
		HighArray_char r = new HighArray_char(500); 
		for (i=0; i<len; i++) {
			Object item = this.getItem(i);
			r.add(/*i+":"+*/item.toString());
		}
		return r.getItems();
	}
	
	
	public ArrayListIReset toArrayListIReset() {
		int i;
		int len = this.getCount();
		ArrayListIReset r = new ArrayListIReset(len);
		for (i=0; i<len; i++) {
			r.add((IReset)this.getItem(i));
		}
		return r;
	}
	
	public ArrayList toArrayList() {
		int i;
		int len = this.getCount();
		ArrayList r = new ArrayList(len);
		for (i=0; i<len; i++) {
			r.add((Object)this.getItem(i));
		}
		return r;
	}
	
		
}//public static class HighArray<Object> {