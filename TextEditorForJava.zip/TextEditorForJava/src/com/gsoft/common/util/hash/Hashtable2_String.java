package com.gsoft.common.util.hash;

import com.gsoft.common.interfaces.IReset;
import com.gsoft.common.util.ArrayList;

/** String을 key로 하는 해시테이블*/
public class Hashtable2_String implements IReset {
	public static class HashItem {
		public String key;
		public Object data;
		public HashItem(String key, Object data) {
			this.key = key;
			this.data = data;
		}
	}
	
	ArrayList[] references;
	int initLenOfBucket;
	public int count;
	
	public ArrayList[] getReferences() {
		return this.references;
	}
		
	public void setReferences(ArrayList[] references) {
		this.references = references;
	}
	
	public Object clone() {
		Hashtable2_String hashTable = new Hashtable2_String(this.references.length, initLenOfBucket);
		int i;
		for (i=0; i<hashTable.references.length; i++) {
			if (references[i]!=null) {
				hashTable.references[i] = (ArrayList) this.references[i].clone();
			}
		}
		return hashTable;
	}
	
	public Hashtable2_String(int lenOfIndices, int initLenOfBucket) {
		references = new ArrayList[lenOfIndices];
		this.initLenOfBucket = initLenOfBucket;
	}
	
	public void reset() {
		int i;
		for (i=0; i<references.length; i++) {
			if (references[i] != null)	{
				references[i].count = 0;
			}
		}
		count = 0;
	}
	
	
	
	
	/** 해시테이블을 일차원 배열( (Object in HashItem)[] )로 변환한다.*/
	public ArrayList toArray() {
		ArrayList r = new ArrayList(count);
		int i, j;
		for (i=0; i<references.length; i++) {
			ArrayList list = references[i];
			if (list!=null) {
				for (j=0; j<list.count; j++) {
					HashItem item = (HashItem) list.getItem(j);
					if (item==null) continue;
					r.add(item.data);
				}
			}
		}
		return r;
	}
	
	public void input(String key, Object data) {
		//if (key==null) return;
		char ch;
		if (key==null) {
			return;
		}
		
		if (key.equals("")) {
			ch = 0;
		}
		else {
			ch = key.charAt(0);	
		}
		int index = ch % references.length;
		//int index = ch;
		if (references[index]==null) {
			references[index] = new ArrayList(initLenOfBucket);
		}
		references[index].add(new HashItem(key, data));
		count++;
	}
	
	/** 기존 item을 대체한다.*/
	public synchronized void replace(String key, Object data) {
		char ch = key.charAt(0);
		int index = ch % references.length;
		ArrayList list = references[index];
		int i;
		synchronized(references[index]) {
			for (i=0; i<list.count; i++) {
				HashItem item = (HashItem) list.getItem(i);
				if (item==null) continue;
				if (key.equals(item.key)) {
					item.data = data;
				}
			}
		}
	}
	
	/** key에 의해 검색되는 아이템은 단 한개이거나 여러개이다.
	 * @param isResultMultiful : true이면 key에 의해 검색되는 아이템들은 여러개이고, false이면 단 한개이다.
	 * @return : if (isResultMultiful) returns HashItem[], If not, returns HashItem*/
	public ArrayList getData2(String key, boolean isResultMultiful) {
		char ch;
		if (key.equals("")) {
			ch = 0;
		}
		else {
			ch = key.charAt(0);	
		}
		int index = ch % references.length;
		//int index = ch;
		ArrayList list = references[index];
		if (list==null) return null;
		int i;
		ArrayList r = null;
		if (isResultMultiful) {
			r = new ArrayList(3);
			for (i=0; i<list.count; i++) {
				HashItem item = (HashItem) list.getItem(i);
				if (item==null) continue;
				if (item.key.equals(key)) {
					r.add(item);					
				}
			}
			return r;
		}
		else {
			r = new ArrayList(1);
			for (i=0; i<list.count; i++) {
				HashItem item = (HashItem) list.getItem(i);
				if (item==null) continue;
				if (item.key.equals(key)) {
					r.add(item);
					break;
				}
			}
		}
		return r;
	} //getData()
	
	
	public void deleteData(String key) {
		char ch;
		if (key.equals("")) {
			ch = 0;
		}
		else {
			ch = key.charAt(0);
		}
		int index = ch % references.length;
		
		ArrayList list = references[index];
		if (list==null) return;
		int i;
		for (i=0; i<list.count; i++) {
			HashItem item = (HashItem) list.getItem(i);
			if (item==null) continue;
			if (item.key.equals(key)) {
				
				list.list[i] = null;
			}
		}
	}
	
	/** key에 의해 검색되는 아이템은 단 한개이거나 여러개이다.
	 * @param isResultMultiful : true이면 key에 의해 검색되는 아이템들은 여러개이고, false이면 단 한개이다.
	 * @return : If isResultMultiful, returns ArrayList(Object[]), 
	 * If not isResultMultiful, returns Object*/
	public Object getData(String key, boolean isResultMultiful) {
		if (key==null) {
			return null;
		}
		char ch;
		if (key.equals("")) {
			ch = 0;
		}
		else {
			ch = key.charAt(0);	
		}
		int index = ch % references.length;
		
		ArrayList list = references[index];
		if (list==null) return null;
		int i;
		if (isResultMultiful) {
			ArrayList r = new ArrayList(3);
			for (i=0; i<list.count; i++) {
				HashItem item = (HashItem) list.getItem(i);
				if (item==null) continue;
				if (item.key.equals(key)) {
					r.add(item.data);					
				}
			}
			return r;
		}
		else {
			for (i=0; i<list.count; i++) {
				HashItem item = (HashItem) list.getItem(i);
				if (item==null) continue;
				if (item.key.equals(key)) {
					return item.data;					
				}
			}
		}
		return null;
	} //getData()

	/** key에 의해 검색되는 아이템은 단 한개이다.*/
	public Object getData(String key) {
		if (key==null) return null;
		char ch;
		if (key.equals("")) {
			ch = 0;
		}
		else {
			ch = key.charAt(0);	
		}
		int index = ch % references.length;
		//int index = ch;
		ArrayList list = references[index];
		if (list==null) return null;
		int i;
		for (i=0; i<list.count; i++) {
			HashItem item = (HashItem) list.getItem(i);
			if (item==null) continue;
			if (item.key.equals(key)) {
				return item.data;					
			}
		}
		return null;
	} //getData()
	
	@Override
	public void destroy() {
		
		int i;
		if (this.references!=null) {
			for (i=0; i<references.length; i++) {
				if (references[i] != null)	{
					references[i].destroy();
					references[i] = null;
				}
			}
			count = 0;
			//references = null;
		}
	}
}