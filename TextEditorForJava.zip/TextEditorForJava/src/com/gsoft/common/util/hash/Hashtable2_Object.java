package com.gsoft.common.util.hash;

import com.gsoft.common.util.ArrayList;

/** key 가 integer 인 좀더 일반적인 해시테이블이다.*/
public class Hashtable2_Object {
	
	public static class HashItem {
		int key;
		Object item;
		HashItem(int key, Object item) {
			this.key = key;
			this.item = item;
		}
	}		
	
	ArrayList[] references;
	int initLenOfBucket;
	
	public Hashtable2_Object(int lenOfIndices, int initLenOfBucket) {
		//indices = new int[lenOfIndices];
		references = new ArrayList[lenOfIndices];
		this.initLenOfBucket = initLenOfBucket;
		
	}
	
	public void reset() {
		int i;
		for (i=0; i<references.length; i++) {
			if (references[i] != null)	{
				references[i].reset();
				references[i] = null;
			}
		}
	}
	
	/** 호출시 넣는 정수인 key 와 data 로 HashItem을 만들어서 해시테이블에 넣는다.*/
	public void input(int key, Object data) {
		int index = key % references.length;
		//int index = ch;
		if (references[index]==null) {
			references[index] = new ArrayList(initLenOfBucket);
		}
		references[index].add(new HashItem(key, data));
		
	}
	
	/** 호출시 넣는 정수인 key 로 해시테이블의 HashItem들을 검색해서 
	 * input()시 넣어진 아이템을 찾는다.*/		
	public Object getData(int key) {
		int index = key % references.length;
		//int index = ch;
		ArrayList list = references[index];
		if (list==null) return null;
		int i;
		for (i=0; i<list.count; i++) {
			HashItem hashItem = (HashItem) list.getItem(i);
			if (hashItem.key==key) {
				return hashItem.item;
			}
		}
		return null;
		
	}
	
	
}