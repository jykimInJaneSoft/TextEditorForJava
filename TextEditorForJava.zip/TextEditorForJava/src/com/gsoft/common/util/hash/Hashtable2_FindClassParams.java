package com.gsoft.common.util.hash;

import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.Compiler_types.LoadWayOfFindClassParams;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.hash.Hashtable2_String.HashItem;

import com.gsoft.common.util.hash.Hashtable2_String;

@SuppressWarnings("unused")
public class Hashtable2_FindClassParams extends Hashtable2_String {

	public Hashtable2_FindClassParams(int lenOfIndices, int initLenOfBucket) {
		super(lenOfIndices, initLenOfBucket);
		
	}
	
	public Object clone() {
		Hashtable2_FindClassParams hashTable = new Hashtable2_FindClassParams(this.references.length, initLenOfBucket);
		int i;
		for (i=0; i<hashTable.references.length; i++) {
			if (references[i]!=null) {
				hashTable.references[i] = (ArrayList) this.references[i].clone();
			}
		}
		return hashTable;
	}
	
	/** 기존 item을 대체한다.*/
	public synchronized void replace(String key, FindClassParams classParams) {
		char ch = key.charAt(0);
		int index = ch % references.length;
		ArrayList list = references[index];
		int i;
		synchronized(references[index]) {
			for (i=0; i<list.count; i++) {
				HashItem item = (HashItem) list.getItem(i);
				if (item==null) continue;
				if (key.equals(item.key)) {
					if (classParams.loadWayOfFindClassParams==LoadWayOfFindClassParams.Start2) {						
						item.data = classParams;
					}
					else if (classParams.loadWayOfFindClassParams==LoadWayOfFindClassParams.Start_OnlyInterface) {
						FindClassParams c = (FindClassParams) item.data;
						if (c.loadWayOfFindClassParams==null ||
								c.loadWayOfFindClassParams==LoadWayOfFindClassParams.None ||
								c.loadWayOfFindClassParams==LoadWayOfFindClassParams.ByteCode) {
							item.data = classParams;
						}
					}
					else if (classParams.loadWayOfFindClassParams==LoadWayOfFindClassParams.ByteCode) {
						FindClassParams c = (FindClassParams) item.data;
						if (c.loadWayOfFindClassParams==null ||
								c.loadWayOfFindClassParams==LoadWayOfFindClassParams.None) {
							item.data = classParams;
						}
					}					
				}
			}//for (i=0; i<list.count; i++) {
		}// synchronized(references[index]) {
	}

}
