package com.gsoft.common.util;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.interfaces.IReset;

import com.gsoft.common.util.Array;

public class ArrayListCodeString implements IReset {
	private CodeString[] list;
	public int count=0;
	public int resizeInc=100;
	public String name;
	
	public ArrayListCodeString(int initMaxLength) {
		list = new CodeString[initMaxLength];			
	}
	public ArrayListCodeString(CodeString[] strs) {
		list = new CodeString[strs.length];
		int i;
		for (i=0; i<list.length; i++) {
			list[i] = strs[i];
		}
		count = list.length;
	}
	public void reset() {
		int i;
		for (i=0; i<list.length; i++) {
			list[i] = null;
		}
		count=0;
	}
	public void destroy() {
		int i;
		for (i=0; i<list.length; i++) {
			if (list[i]!=null) list[i].destroy();
			list[i] = null;
		}
		count=0;
	}
	/** count만 0으로 만들고 배열원소는 그대로 놔둔다.*/
	public void reset2() {
		count=0;
	}
	public void add(CodeString e) {
		if (count>=list.length) list = Array.Resize(list, list.length+resizeInc);
		list[count] = e;
		count++;
	}
	
	public void setCodeString(int index, CodeString str) {
		list[index] = str;
	}
	
	public CodeString[] substring(int start, int len) {
		ArrayListCodeString r = new ArrayListCodeString(len);
		int i;
		for (i=start; i<start+len; i++) {
			r.add(this.getItem(i));
		}
		return r.getItems();
	}
	
	synchronized public void insert(int index, ArrayListCodeString listArg) {
		try {
			this.list = Array.InsertNoSpaceError(listArg.list, 0, list, index, listArg.count, this.count);
			count += listArg.count;
		}catch(Exception e) {
		}
	}
	
	public CodeString[] getItems() {
		if (list.length==count) return list;
		return Array.Resize(list,count);
	}
	
	public CodeString getItem(int index) {
		return list[index];
	}
	
	/*public ArrayListCodeString clone() {
		int i;
		ArrayListString r = new ArrayListString(count);
		
		for (i=0; i<count; i++) {
			char[] buf = new char[list[i].length()];
			list[i].getChars(0, buf.length, buf, 0);
			r.add(new String(buf));
		}
		return r;
	}*/
	
	
	synchronized public void delete(int startIndex, int len) throws Exception {
		list = Array.Delete(list, startIndex, len);
		count -= len;
	}
	
}
