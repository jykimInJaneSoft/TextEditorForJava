package com.gsoft.common.util;

import com.gsoft.common.compiler.Number.Hexa;
import com.gsoft.common.util.Util.IndexOfHighArray;

import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListByte;
import com.gsoft.common.util.HighArray_char;

public class HighArray_byte {
	int arrayLimit;
	
	public ArrayList data;
	
	public int count = 0;
	
	public HighArray_byte(int arrayLimit) {
		this.arrayLimit = arrayLimit;
		data = new ArrayList(10);
	}
	
	/** 16진수로 출력한다.*/
	public String toString() {
		int j, k;
		boolean givesSpace = false;
		HighArray_char r = new HighArray_char(500);
		for (j=0; j<data.count; j++) {
			ArrayListByte list = (ArrayListByte) data.getItem(j);
			for (k=0; k<list.count; k++) {
				byte b = list.getItem(k);
				String hexa = Hexa.getHexaString(b);
				r.add(hexa);
				if (givesSpace) r.add(' ');
				givesSpace = !givesSpace;
			}
		}
		return r.getItems();
	}
	
	/** 모든 자원을 해제한다.*/
	public void destroy() {
		int j;
		for (j=0; j<data.list.length; j++) {
			ArrayListByte list = (ArrayListByte) data.getItem(j);
			if (list!=null) list.reset();
			list = null;
		}
		data.destroy();
		count = 0;
	}
	
	
	/** 상대인덱스(arrayNumber,offset)를 절대인덱스로 바꾼다.*/
	public int index(int arrayNumber, int offset) {
		int i;
		int index = 0;
		// 이전 array까지의 개수들의 합
		for (i=0; i<arrayNumber; i++) {
			ArrayListByte arr = (ArrayListByte) data.getItem(i);
			index += arr.count;
		}
		index += offset;
		return index;
	}
	
	/** 절대인덱스를 상대인덱스(arrayNumber,offset)로 바꾼다.*/
	public IndexOfHighArray indexRelative(int index) {
		int indexOfData = -1;
		int i;
		int len = 0;   // 현재 array까지의 개수들의 합
		int oldLen = 0;// 이전 array까지의 개수들의 합
		for (i=0; i<data.count; i++) {
			ArrayListByte arr = (ArrayListByte) data.getItem(i);
			oldLen = len;
			len += arr.count;
			if (index<len) {
				indexOfData = i;
				break;
			}
		}
		if (index>=len) {
			return null; // ArrayIndexOUtOfBoundsException
		}
		
		int indexInArray = index - oldLen; // offset
		return new IndexOfHighArray(indexOfData, indexInArray);
	}
	
	
	/** 절대인덱스를 상대인덱스(arrayNumber,offset)로 바꾼다.*/
	public void indexRelative(Object owner, int index, IndexOfHighArray result) {
		int indexOfData = -1;
		int i;
		int len = 0;    // 현재 array까지의 개수들의 합
		int oldLen = 0; // 이전 array까지의 개수들의 합
		for (i=0; i<data.count; i++) {
			ArrayListByte arr = (ArrayListByte) data.getItem(i);
			oldLen = len;
			len += arr.count;
			if (index<len) {
				indexOfData = i;
				break;
			}
		}
		if (index>=len) {
			return; // ArrayIndexOUtOfBoundsException
		}
		
		int indexInArray = index - oldLen; // offset
		result.arrayNumber = indexOfData;
		result.offset = indexInArray;
	}
	
	
	public int getCount() {
		// 마지막 item을 얻는다.
		/*ArrayListByte arrItem = (ArrayListByte) data.getItem(data.count-1);
		//int len = arrayLimit * (data.count-1) + arrItem.count;
		int i;
		int len = 0;
		for (i=0; i<data.count-1; i++) {
			ArrayListByte arr = (ArrayListByte) data.getItem(i);
			len += arr.count;
		}
		len += arrItem.count;
		return len; */
		return count;
	}
	
	
			
	public byte getItem(int index) {
		//int indexOfData = index / arrayLimit;
		//int indexInArray = index % arrayLimit;
		
		IndexOfHighArray indexOfHigh = this.indexRelative(index);
		
		ArrayListByte arrItem = (ArrayListByte) data.getItem(indexOfHigh.arrayNumber);
		return (byte) arrItem.getItem(indexOfHigh.offset);
	}
	
	public byte[] getItems() {
		byte[] r = new byte[count];
		int i;
		for (i=0; i<r.length; i++) {
			r[i] = getItem(i);
		}
		return r;
	}
	
	
	public void add(byte[] arr) {
		int i;
		int len = arr.length;
		for (i=0; i<len; i++) {
			this.add(arr[i]);
		}
	}
	
	
	
	public void add(byte c) {
		if (data.count==0) {
			ArrayListByte newItem = new ArrayListByte(arrayLimit);
			data.add(newItem);
		}
		
		ArrayListByte item;
		
		// 마지막 item을 얻는다.
		ArrayListByte arrItem = (ArrayListByte) data.getItem(data.count-1);
		if (arrItem.count>=arrayLimit) { // 새로운 item을 생성해서 넣는다.
			ArrayListByte newItem = new ArrayListByte(arrayLimit);
			data.add(newItem);
			item = newItem;
		}
		else {
			item = arrItem;
		}
		
		item.add(c);
		count++;
	}
	
}
