package com.gsoft.common.util;

import com.gsoft.common.util.Array;

public class ArrayListInt {
	public int[] list;
	public int count=0;
	public int capacity=0;
	public int resizeInc=20;
	public ArrayListInt(int initMaxLength) {
		capacity = initMaxLength;
		list = new int[initMaxLength];			
	}
	
	public Object clone() {
		ArrayListInt r = new ArrayListInt(count);
		int i;
		for (i=0; i<count; i++) {
			r.list[i] = this.list[i];
		}
		r.count = this.count;
		return r;
	}
	/** 배열원소는 그대로 놔두고 count만 0으로 만든다.*/
	synchronized public void reset2() {
		count=0;
	}
	synchronized public void setCapacity(int c) {
		capacity = c; 
		list = Array.Resize(list, capacity);
		
	}
	synchronized public void add(int e) {
		if (count>=list.length) {
			capacity = list.length+resizeInc;
			list = Array.Resize(list, capacity);
		}
		list[count] = e;
		count++;
	}
	
	synchronized public void insert(int index, int value) {			
		int[] buf = {value};
		if (list.length < count+buf.length) {
			list = Array.Resize(list, count+resizeInc);
		}
		try {
			Array.Insert(buf, 0, list, index, buf.length, count);
			count += buf.length;
		}catch(Exception e) {
		}
	}
	
	synchronized public void delete(int startIndex, int len) {
		list = Array.Delete(list, startIndex, len);
		count -= len;
	}
	
	synchronized public int[] getItems() {
		if (list.length==count) return list;
		return Array.Resize(list,count);
	}
	
	synchronized public int getItem(int index) {
		try {
		return list[index];
		}catch(Exception e) {
			return -1;
		}
	}
	
}