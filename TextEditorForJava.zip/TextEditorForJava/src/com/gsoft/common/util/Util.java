package com.gsoft.common.util;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Enumeration;
import java.util.jar.JarEntry;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;

import android.graphics.Color;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.CommonGUI;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.FileHelper;
import com.gsoft.common.gui.Control;

import com.gsoft.common.util.HighArray;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.Array;

public class Util {
	/**오프셋 i 를 줄마다 칸수가 같은 스트링으로 변환한다.*/
	public static String getLineOffset(int i) {
		if (0<=i && i<=9) return new String(i+"         ");
		else if (10<=i && i<=99) return new String(i+"        ");
		else if (100<=i && i<=999) return new String(i+"       ");
		else if (1000<=i && i<=9999) return new String(i+"      ");
		else if (10000<=i && i<=99999) return new String(i+"     ");
		else if (100000<=i && i<=999999) return new String(i+"    ");
		else if (1000000<=i && i<=9999999) return new String(i+"   ");
		else if (10000000<=i && i<=99999999) return new String(i+"  ");
		else if (100000000<=i && i<=999999999) return new String(i+" ");
		else return String.valueOf(i);
	}
	
	/**getLineOffset(int i)와 같은 개수의 gap을 얻는다.*/
	public static String getGapOfLineOffset() {
		return new String("          ");
	}
	
	
	
	public static class Math {
		public static int min(int n1, int n2) {
			if (n1>=n2) return n2;
			return n1;
		}
		public static int max(int n1, int n2) {
			if (n1>=n2) return n1;
			return n2;
		}
	}
	
	
	
	
	
	
	public static class IndexOfHighArray {
		/** HighArray 내에 있는 array의 번호, 이것은 data의 인덱스이다.*/
		int arrayNumber;
		/** HighArray 내에 있는 array의 스트링을 가리키는 인덱스*/
		int offset;
		
		IndexOfHighArray(int arrayNumber, int offset) {
			this.arrayNumber = arrayNumber;
			this.offset = offset;
		}
	}
	
	
	
	
	
	
	public static class JarFile {
		/** @param destFilename : '/'으로 시작하는 완벽한 path, 확장자는 .jar 파일
		 * @param srcFilename : '/'으로 시작하는 완벽한 path, 압축을 풀 디렉토리*/
		public static boolean compress(String srcFilename, String destFilename) throws IOException {
			
			return false;
		}
		
		
		/** @param srcFilename : '/'으로 시작하는 완벽한 path, 확장자는 .jar파일
		 * @param relativeFilename : 상대적 파일이름, 
		 * srcFilenameExceptExt+File.separator+relativeFilename는 절대적 파일 경로가 된다.*/
		public static boolean exists(String srcFilename, String relativeFilename)  {
			/*if (relativeFilename.charAt(relativeFilename.length()-1)==File.separatorChar) {
				relativeFilename = relativeFilename.substring(0, relativeFilename.length()-1);
			}*/
			relativeFilename = relativeFilename.replace(File.separatorChar, '/');
			//relativeFilename = relativeFilename.replace('/', File.separatorChar);
			
			
			File file = new File(srcFilename);
			java.util.zip.ZipFile jarFile = null;
			try {
				jarFile = new java.util.zip.ZipFile(file);
				ZipEntry zarEntry = jarFile.getEntry(relativeFilename);
				if (zarEntry!=null) return true;
			} catch (ZipException e) {
				
				if (Common_Settings.g_printsLog) e.printStackTrace();
			} catch (IOException e) {
				
				if (Common_Settings.g_printsLog) e.printStackTrace();
			} finally {
				if (jarFile!=null) {
					try {
						jarFile.close();
					} catch (IOException e) {
						
						e.printStackTrace();
					}
				}
			}
			
			return false;
		}
		
		
		/** @param srcFilename : '/'으로 시작하는 완벽한 path, 확장자는 .jar파일
		 * @param relativeFilename : 상대적 파일이름, 
		 * srcFilename+File.separator+relativeFilename는 절대적 파일 경로가 된다.*/
		public static InputStream extract(String srcFilename, String relativeFilename) throws IOException {
			//relativeFilename = relativeFilename.replace('.', File.separatorChar);
			java.util.zip.ZipFile jarFile = null;
			try {
				File file = new File(srcFilename);
				jarFile = new java.util.zip.ZipFile(file);
				ZipEntry zarEntry = jarFile.getEntry(relativeFilename);
				return jarFile.getInputStream(zarEntry);
			}finally {
				if (jarFile!=null) {
					jarFile.close();
				}
			}
		}
		
		
		
		/** @param srcFilename : '/'으로 시작하는 완벽한 path, 확장자는 .jar파일
		 * @param destFilename : '/'으로 시작하는 완벽한 path, 압축을 풀 디렉토리*/
		public static boolean decompress(String srcFilename, String destFilename) throws IOException {
			File file = new File(srcFilename);
			try {
				File destFile = new File(destFilename);
				destFile.mkdir();
				
				java.util.jar.JarFile jarFile = new java.util.jar.JarFile(file,false);
				Enumeration<JarEntry> entries = jarFile.entries();
				String directoryName;
				File writeFile;
				
				byte[] buf = new byte[10000];
				
				while (entries.hasMoreElements()) {
					JarEntry entry = entries.nextElement();
					String entryName = entry.getName();
					CommonGUI.showMessage(true, entryName);
					if (entry.isDirectory()) {
						directoryName = entry.getName();
						String name = destFilename + File.separator + directoryName;
						writeFile = new File(name);
						writeFile.mkdirs();
					}
					else {
						String filename = entry.getName();
						writeFile = new File(destFilename + File.separator + filename);
						directoryName = FileHelper.getDirectory(writeFile.getAbsolutePath());
						if (directoryName!=null && !directoryName.equals("")) {
							File d = new File(directoryName);
							d.mkdirs();
						}
						
						InputStream is = jarFile.getInputStream(entry);
						FileOutputStream os = new FileOutputStream(writeFile);
						BufferedOutputStream bos = new BufferedOutputStream(os);
						
						
						FileHelper.move(buf, is, bos);
						
						bos.flush();
						bos.close();
						os.close();
						writeFile.setReadable(true);
						writeFile.setWritable(true);
						writeFile.setExecutable(true);
					}
				}
				jarFile.close();
				return true;
			} catch (IOException e1) {
				
				e1.printStackTrace();
				return false;
			}
		}
	}
	
		
	
	
	public static class StringDel {
		public static java.lang.String clone(java.lang.String str) {
			char[] buf = new char[str.length()];
			str.getChars(0, buf.length, buf, 0);
			return new java.lang.String(str);
		}
	}
	
	/**Returns a string formatted with yyyy-MM-dd HH:mm:ss*/
	public static String toDateString(long millis) {
		java.util.Date date = new java.util.Date(millis);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String strLastModified = sdf.format(date);
		return strLastModified;
	}
		
	public static class Date {
		/*static int country;
		static long countryMillis;
		static long userTimeMillis;*/
		
		static int mYoil;
		
		int year;
		int month;
		int date;
		boolean isAM;
		int hour;
		int min;
		int sec;
		
		// 요일
		int day;
		
		//					   0, 1,  2,  3,  4,  5,  6,  7,  8,  9   10, 11, 12
		int[] dayOfMonth = 	  {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
		int[] dayOfMonthSum = {0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365};
		
		//2월29일이 있는 해는 4년마다 반복됩니다. 몇년인지 궁금하시다면, 올림픽이 있는 해를 알아보시면 됩니다.ㅋ

		//(2012, 2016, 2020,...)

		//하지만, 2100년과 같은 100의 배수인 연도에는 윤달이 없고, 
		//2000년과 같은 100의배수이지만 400의 배수인 연도에는 윤달이 존재합니다
		
		// 72, 76, 80, 84, 88, 92, 96, 2000, 2004, 08, 12............16
		int sumOfYearThat2Has29Since1970 = 11; // 1년이 366인 해
		
		int getCountOf0229(int year) {
			int count = year / 4;
			count -= year / 100;
			count += year / 400;
			return count;
		}

		// 윤달(2월이 29일) = 
		public Date(long millisec) {
			//long argMillisec = millisec + countryMillis + userTimeMillis;
			
			final int millisPerSec = 1000;
			//int millisPerMin = 1000 * 60;
			//int millisPerHour = 1000 * 60 * ;
			final int millisPerMin = millisPerSec * 60;
			final long millisPerHour = millisPerMin * 60;
			final long millisPerDay = millisPerHour * 24;
			final long millisPerYear = millisPerDay * 365;
			
			
			int yearSince1970 = (int) (millisec / millisPerYear);
			year = yearSince1970 + 1970;
			
			// year와 1970사이의 2월29일을 갖는 해의 개수를 구한다.
			sumOfYearThat2Has29Since1970 = getCountOf0229(year) - getCountOf0229(1970);
			long millisec0229 = millisec - millisPerDay * sumOfYearThat2Has29Since1970;
			
			long millisRemainder = millisec0229 % millisPerYear;
			
			
			
			// 1년 아래의 날짜수, 즉 364일 이하
			int dateInRemainder = (int) (millisRemainder / millisPerDay);
			
			// millisPerDay아래의 millis
			int millisInDateRemainder = (int)(millisRemainder % millisPerDay);	
			
			
			
			hour = (int)(millisInDateRemainder / millisPerHour);
			
			// millisPerHour아래의 millis
			int millisInHourRemainder = (int)(millisInDateRemainder % millisPerHour);
			
			
			
			min = millisInHourRemainder / millisPerMin;
			
			int millisInMinRemainder = millisInHourRemainder % millisPerMin;
			
			
			
			sec = millisInMinRemainder / millisPerSec;
			
			
			
			int i;
			for (i=dayOfMonthSum.length-1; i>=0; i--) {
				if (dateInRemainder>dayOfMonthSum[i]) {
					break;
				}
			}
			if (i<0) {
				i=0;
				month = 1;
				date = dateInRemainder - dayOfMonthSum[i] + 1;
			}
			else {			
				month = i+1;
				date = dateInRemainder - dayOfMonthSum[i];
			}
			
			
			final long millisPer7Day = millisPerDay * 7;
			
			long millisIn7DayRemainder = millisec0229 % millisPer7Day;
			
			day = (int)((millisIn7DayRemainder+mYoil*millisPerDay) / millisPerDay);
			
			day = day % 7;
		}
		
		// 요일
		public int getDay() {
			return day;
		}
		
		public int getDate() {
			return date;
		}
		
		public int getMonth() {
			return month;
		}
		
		public int getYear() {
			return year;
		}
		
		public int getHour(boolean isHalfDate) {
			if (isHalfDate) {
				if (hour>12) {
					isAM = false;
					return hour-12;
				}
				else {
					isAM = true;
					return hour;
				}
			}
			return hour;
		}
		
		public boolean getIsAM() {
			return isAM;
		}
		
		public int getMin() {
			return min;
		}
		
		public int getSec() {
			return sec;
		}
				
		/*public static void addUserTime(int day, int hour, int min, int yoil) {
			final int millisPerSec = 1000;
			final int millisPerMin = millisPerSec * 60;
			final long millisPerHour = millisPerMin * 60;
			final long millisPerDay = millisPerHour * 24;
			
			userTimeMillis = day * millisPerDay + hour *millisPerHour + min*millisPerMin;
			mYoil = yoil;
		}*/
		
		public static String getCurDateTime(boolean isHalfDate) {
			//Date.setCountry(1);
			//Date.addUserTime(1,9,0,1);
			Date date = new Date(System.currentTimeMillis());
				
			String curTime = " " + String.valueOf(date.getHour(isHalfDate)) + ":" + 
					String.valueOf(date.getMin());
			if (date.getIsAM()) curTime += " AM";
			else curTime += " PM";
			
			switch(date.getDay()) {
			case 0: curTime += " Sun"; break;
			case 1: curTime += " Mon"; break;
			case 2: curTime += " Tue"; break;
			case 3: curTime += " Wed"; break;
			case 4: curTime += " Thu"; break;
			case 5: curTime += " Fri"; break;
			case 6: curTime += " Sat"; break;
			}
				
			String curDate = " " + String.valueOf(date.getMonth()) + "-" + 
					String.valueOf(date.getDate()) + "-" + String.valueOf(date.getYear());
					
			return curTime + "\n" + curDate;
		}
	}
	
	
	
	public static class BufferByte {
		public byte[] buffer;
		public int offset;
		public int len;
		
		public BufferByte() {
			
		}
		
		public BufferByte(byte[] buffer) {
			this.buffer = buffer;
			offset = 0;
			len = buffer.length;
		}
	}
	
	
	
	public static class ObjectPool  {
		public HighArray list;
		public int countOfUsedItems;
		
		public ObjectPool(int initMaxLength) {
			list = new HighArray(initMaxLength);
		}
		public void reset() {
			list.destroy();
		}
		
		/** 풀에 재사용할 아이템을 넣는다.*/
		public void add(Object e) {
			list.add(e);
		}
		
		/** 풀에서 count만큼의 아이템들을 가져온다. 
		 * 만약에 풀에 count개의 아이템이 없으면 null을 리턴한다.*/
		public Object[] getItems(int count) {
			if (list.getCount()-countOfUsedItems<count) return null;
			Object[] r = new Object[count];
			int i;
			int len = countOfUsedItems+count;
			for (i=countOfUsedItems; i<len; i++) {
				r[i] = list.getItem(i);
			}
			countOfUsedItems += count;
			return r;
		}
		
	}
	
	/** View의 OnTouchListener와 onDraw에서 ControlStack을 잠그기(synchronized) 때문에 
	 * 여기서는 잠그지 않는다. 
	 * @author kim ji yun
	 *
	 */
	public static class ControlStack {
		private Control[] list;		
		public int count=0;
		public int resizeInc=20;
		public int capacity=0;
		
		public ControlStack(int initMaxLength) {
			capacity = initMaxLength;
			list = new Control[initMaxLength];
		}
		synchronized public void reset2() {
			count=0;
		}
		synchronized public void setCapacity(int c) {
			capacity = c; 
			list = Array.Resize(list, capacity);
			
		}
		/** 기존 컨트롤 스텍에 있던 컨트롤의 레퍼런스를 모두 삭제하고 새로이 컨트롤을 추가한다.*/
		synchronized public void add(Control e) {
			deleteItem(e.iName);
			
			if (count>=list.length) {
				capacity = list.length+resizeInc;
				list = Array.Resize(list, capacity);
			}			
			list[count] = e;
			count++;
		}
		
		synchronized public Control[] getItems() {
			//if (list.length==count) return list;
			list = Array.Resize(list,count);
			return list;
		}
		
		synchronized public Control getItem(int index) {
			return list[index];
		}
		
		synchronized public Control findItem(int iName) {
			int i;
			for (i=0; i<count; i++) {
				if (list[i].iName==iName) return list[i];
			}
			return null;
		}
		
		synchronized public void deleteLastItem() {
			if (count>0) {
				list[count-1] = null;
				count--;
			}
		}
		
		/** iName을 갖는 컨트롤의 레퍼런스들을 컨트롤 스텍에서 모두 삭제한다.*/
		synchronized public void deleteItem(int iName) {
			int i;
			for (i=count-1; i>=0; i--) {
				if (list[i].iName==iName) {
					try {
						list = Array.Delete(list, i, 1);
						count--;
						if (count<=0) break;
					} catch (Exception e) {
						
						if (Common_Settings.g_printsLog) e.printStackTrace();
					}						
					//break;
				}
			}
		}
		
	}
	
	public static class LinkedList {
		public static class Node {
			public Object data;
			public Node next;
			public Node (Object data, Node next) {
				this.data = data;
				this.next = next;
			}
		}
		
		/** 처음 노드를 가리킨다. 빈리스트이면 null*/
		Node listLinked;
		/** 빈노드*/
		Node head;
		/** 처음에는 빈노드, 리스트의 마지막 노드를 가리킨다.*/
		Node tail;
		int count;
		
		/** 검색 또는 insert 작업을 빠르게하기 위함이다.*/
		//Node cur;
		//int indexOfStartNode;
		
	
		public LinkedList(int initMaxLength) {
			head = new Node(null, null);
			tail = head;
			listLinked = head.next;
		}
		
		public void makeLinkedListFromArray(ArrayList list) {
			int i;
			tail = head;
			if (list.count>0) {
				Node node = new Node(list.getItem(0), null);
				tail.next = node;
				tail = node;
				head.next = node;
			}
			listLinked = head.next;
			
			for (i=1; i<list.count; i++) {
				Node node = new Node(list.getItem(i), null);
				tail.next = node;
				tail = node;
			}
			count = list.count;
		}
		
		public ArrayList makeArrayList() {
			ArrayList r = new ArrayList(count);
			Node n;
			for (n=listLinked; n!=null; n=n.next) {
				r.add(n.data);
			}
			return r;
		}
		
		public Node addToLinkdedList(Object o) {			
			Node newNode = new Node(o, null); 
			tail.next = newNode;
			tail = newNode;
			if (count==0) {
				listLinked = newNode;
				head.next = listLinked; 
			}
			count++;
			return newNode;
		}
		
		public Node insertToLinkdedList(int index, Object o) throws Exception {
			Node newNode = new Node(o, null);
			
			int i;
			//Node nodeCur = listLinked;
			Node nodeCur = head;
			if (listLinked!=null) {  // count>0
				if (index<count) { // 리스트 중간에 넣기
					for (i=0; i<index; i++) {
						nodeCur = nodeCur.next;
					}
					Node nextNode = nodeCur.next;
					nodeCur.next = newNode;
					newNode.next = nextNode;
					if (index==0) {
						listLinked = newNode;
						head.next = newNode;
					}
				}
				else if (index==count) {	// 마지막에 넣기
					tail.next = newNode;
					tail = newNode;
				}
				else {
					throw new Exception("invalid index");
				}
			}
			else {
				if (index==0) {
					head.next = newNode;
					listLinked = newNode;
					tail = newNode;
				}
				else {
					throw new Exception("invalid index");
				}
			}
			
			count++;
			return newNode;
			
		}
		
		/**listLinked를 0의 인덱스로 하여 가장 마지막 노드는 count-1의 인덱스를 갖는다.
		 * base+offset은 인덱스이다. insert되는 노드는 base+offset의 인덱스를 갖는다.
		 * @param startNode : 검색 시작 노드 
		 * @param base : startNode의 인덱스
		 * @param offset : base에서 떨어진 거리
		 * @return : 해당 아이템
		 * @throws Exception
		 */
		public Node insertToLinkdedList(Node startNode, int base, int offset, Object o) throws Exception 
		{
			Node newNode = new Node(o, null);
			
			int i;
			//Node nodeCur = listLinked;
			int index = base+offset;
			Node nodeCur = head;
			if (listLinked!=null) {  // count>0
				if (index<count) { // 리스트 중간에 넣기
					for (i=base; i<index; i++) {
						nodeCur = nodeCur.next;
					}
					Node nextNode = nodeCur.next;
					nodeCur.next = newNode;
					newNode.next = nextNode;
					if (index==0) {
						listLinked = newNode;
						head.next = newNode;
					}
				}
				else if (index==count) {	// 마지막에 넣기
					tail.next = newNode;
					tail = newNode;
				}
				else {
					throw new Exception("invalid index");
				}
			}
			else {
				if (index==0) {
					head.next = newNode;
					listLinked = newNode;
					tail = newNode;
				}
				else {
					throw new Exception("invalid index");
				}
			}
			
			count++;
			return newNode;
			
		}
		
		synchronized public void reset2() {
			head.next = null;
			listLinked = head.next;
			tail = head;
			count=0;
		}

		public Node getItem(int index) throws Exception {
			Node r=null;			
			if (index<count) {
				int i;
				Node nodeCur = listLinked;
				for (i=0; i<=index; i++) {
					r = nodeCur;
					nodeCur=nodeCur.next;
				}
				
				return r;
			}
			else {
				throw new Exception("invalid index");
			}
		}
		
		/** listLinked를 0의 인덱스로 하여 가장 마지막 노드는 count-1의 인덱스를 갖는다.
		 * base+offset은 인덱스이다. 
		 * @param startNode : 검색 시작 노드 
		 * @param base : startNode의 인덱스
		 * @param offset : base에서 떨어진 거리
		 * @return : 해당 아이템
		 * @throws Exception
		 */
		public Node getItem(Node startNode, int base, int offset) throws Exception {
			Node r=null;
			int index = base+offset;
			//this.indexOfStartNode = base; 
			if (index<count) {
				int i;
				Node nodeCur = startNode;
				for (i=base; i<=index; i++) {
					r = nodeCur;
					nodeCur=nodeCur.next;
				}
				return r;
			}
			else {
				throw new Exception("invalid index");
			}
		}
		
	}
	
	
	
	
	public static class StackTracer {
		CodeString message=null;
		
		public StackTracer(Throwable e) {
			StackTraceElement[] arrSTE = e.getStackTrace();
			int i;
			message = new CodeString(e.toString() + "\n",Color.BLACK);
			for (i=0; i<arrSTE.length; i++) {
				CodeString str = 
						(new CodeString(arrSTE[i].getClassName() + "." + arrSTE[i].getMethodName() + "()" + "<",Color.BLACK))
						.concate(new CodeString(""+arrSTE[i].getLineNumber(),Color.RED))
						.concate(new CodeString(">\n",Color.BLACK));
				message = message.concate(str);
			}
			
		}
		
		public CodeString getMessage() {
			return message;
		}
	}
	

}