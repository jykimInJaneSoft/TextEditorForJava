package com.gsoft.common.util;

import com.gsoft.common.interfaces.IReset;

import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListIReset;

public class Sort {
	public static class SortItem {
		public int key;
		public Object obj;
		public SortItem(int key, Object obj) {
			this.key = key;
			this.obj = obj;
		}
		
	}
	
	public static class SortItemLong {
		public long key;
		public Object obj;
		public SortItemLong(long key, Object obj) {
			this.key = key;
			this.obj = obj;
		}
		
	}
	
	public static class SortItemIReset implements IReset {
		public int key;
		public IReset obj;
		public SortItemIReset(int key, IReset obj) {
			this.key = key;
			this.obj = obj;
		}
		@Override
		public void destroy() {
			
			
		}
		
	}
	
	public static SortItemIReset toSortItemIReset(String name, IReset obj) {
		int key = name.charAt(0);
		return new SortItemIReset(key, obj);
	}
	
	/** SortItem[]을 SortItem.key에 의해 오름차순으로 정렬한다.*/
	public static void sort(ArrayListIReset arr) {
		int i, j;
		SortItemIReset temp;
		int len = arr.count;
		for (i=0; i<len; i++) {
			SortItemIReset item_i = (SortItemIReset) arr.getItem(i);
			int min = item_i.key;
			int newMinIndex = i;
			for (j=i+1; j<len; j++) {
				SortItemIReset item_j = (SortItemIReset) arr.getItem(j);
				int cur = item_j.key;
				if (min>cur) {
					newMinIndex = j;
					min = cur;
				}
			}
			// swapping
			SortItemIReset item_newMinIndex = (SortItemIReset) arr.getItem(newMinIndex);
			if (item_i.key>item_newMinIndex.key) {
				temp = item_i;
				//arr[i] = arr[newMinIndex];
				arr.list[i] = (IReset) item_newMinIndex;
				//arr[newMinIndex] = temp;
				arr.list[newMinIndex] = (IReset) temp;
			}
		}
	}
	
	
	
	
	public static SortItem toSortItem(String name, Object obj) {
		int key = name.charAt(0);
		return new SortItem(key, obj);
	}
	
	/** SortItem[]을 SortItem.key에 의해 오름차순으로 정렬한다.*/
	public static void sort(ArrayList arr) {
		int i, j;
		SortItem temp;
		int len = arr.count;
		for (i=0; i<len; i++) {
			SortItem item_i = (SortItem) arr.getItem(i);
			int min = item_i.key;
			int newMinIndex = i;
			for (j=i+1; j<len; j++) {
				SortItem item_j = (SortItem) arr.getItem(j);
				int cur = item_j.key;
				if (min>cur) {
					newMinIndex = j;
					min = cur;
				}
			}
			// swapping
			SortItem item_newMinIndex = (SortItem) arr.getItem(newMinIndex);
			if (item_i.key>item_newMinIndex.key) {
				temp = item_i;
				arr.list[i] = item_newMinIndex;
				arr.list[newMinIndex] = temp;
			}
		}
	}
	
	/** SortItem[]을 SortItem.key에 의해 오름차순으로 정렬한다.*/
	public static void sort(SortItem[] arr) {
		int i, j;
		SortItem temp;
		int len = arr.length;
		for (i=0; i<len; i++) {
			SortItem item_i = arr[i];
			int min = item_i.key;
			int newMinIndex = i;
			for (j=i+1; j<len; j++) {
				SortItem item_j = arr[j];
				int cur = item_j.key;
				if (min>cur) {
					newMinIndex = j;
					min = cur;
				}
			}
			// swapping
			SortItem item_newMinIndex = arr[newMinIndex];
			if (item_i.key>item_newMinIndex.key) {
				temp = item_i;
				arr[i] = item_newMinIndex;
				arr[newMinIndex] = temp;
			}
		}
	}
	
	/** String[]을 오름차순으로 정렬한다.*/
	public static void sort(String[] arr) {
		int i, j;
		String temp;
		int len = arr.length;
		for (i=0; i<len; i++) {
			String item_i = arr[i];
			int min = item_i.charAt(0);
			int newMinIndex = i;
			for (j=i+1; j<len; j++) {
				String item_j = arr[j];
				int cur = item_j.charAt(0);
				if (min>cur) {
					newMinIndex = j;
					min = cur;
				}
			}
			// swapping
			String item_newMinIndex = arr[newMinIndex];
			if (item_i.charAt(0)>item_newMinIndex.charAt(0)) {
				temp = item_i;
				arr[i] = item_newMinIndex;
				arr[newMinIndex] = temp;
			}
		}
	}
	
	
	/** SortItemLong[]을 SortItem.key에 의해 오름차순으로 정렬한다.*/
	public static void sort_Long(ArrayList arr) {
		int i, j;
		SortItemLong temp;
		int len = arr.count;
		for (i=0; i<len; i++) {
			SortItemLong item_i = (SortItemLong) arr.getItem(i);
			long min = item_i.key;
			int newMinIndex = i;
			for (j=i+1; j<len; j++) {
				SortItemLong item_j = (SortItemLong) arr.getItem(j);
				long cur = item_j.key;
				if (min>cur) {
					newMinIndex = j;
					min = cur;
				}
			}
			// swapping
			SortItemLong item_newMinIndex = (SortItemLong) arr.getItem(newMinIndex);
			if (item_i.key>item_newMinIndex.key) {
				temp = item_i;
				//arr[i] = arr[newMinIndex];
				arr.list[i] = item_newMinIndex;
				//arr[newMinIndex] = temp;
				arr.list[newMinIndex] = temp;
			}
		}
	}
	
	
	public static void sort(int[] arr) {
		int i, j;
		int temp;
		int len = arr.length;
		for (i=0; i<len; i++) {
			int min = arr[i];
			int newMinIndex = i;
			for (j=i+1; j<len; j++) { // 가장 작은 값을 선택한다.
				int cur = arr[j];
				if (min>cur) {
					newMinIndex = j;
					min = cur;
				}
			}
			// swapping
			if (arr[i]>arr[newMinIndex]) {
				temp = arr[i];
				arr[i] = arr[newMinIndex];
				arr[newMinIndex] = temp;
			}
		}
	}
	/*
	public static void merge_sort(int[] num, int start, int end, boolean isAcending){ // Array를 두개의 덩어리로 나눔    
		int median = (start + end)/2;     
		if (start < end){         
			merge_sort(num, start, median, isAcending);         
			merge_sort(num, median+1, end, isAcending);          
			merge(num, start, median, end, isAcending);     
		} 
	}  
	private static void merge(int[] num, int start, int median, int end, boolean isAcending){     
		int i,j,k,m,n;     
		int[] tempArr = new int[num.length]; // 임시로 데이터를 저장할 배열    
		i = start;     
		j = median+1;     
		k = start;      
		while (i <= median && j <= end){
			if (isAcending) {
				tempArr[k++] = (num[i] > num [j]) ? num [j++] : num [i++]; 
			}
			else {
				tempArr[k++] = (num[i] < num [j]) ? num [j++] : num [i++];
			}
		}           // 아직 배열에 속하지 못한 부분들을 넣기 위한 부분    
		m = (i > median) ? j : i; // 아직 원소가 남아있는 덩어리가 어디인지 파악    
		n = (i > median) ? end : median; // 마찬가지로, for문의 끝 Index를 정하기 위함임     
		for (; m<=n; m++){ // 앞에서 구한 m, n으로 배열에 속하지 못한 원소들을 채워넣음       
			tempArr[k++] = num[m];     
		}      
		for (m=start; m<=end; m++){         
			num[m] = tempArr[m]; // 임시 배열에서 원래 배열로 데이터 옮기기    
		} 
	} 
	
	public static void merge_sort(String[] strs, int start, int end, boolean isAcending){ // Array를 두개의 덩어리로 나눔    
		int median = (start + end)/2;     
		if (start < end){         
			merge_sort(strs, start, median, isAcending);         
			merge_sort(strs, median+1, end, isAcending);          
			merge(strs, start, median, end, isAcending);     
		} 
	}  
	private static void merge(String[] strs, int start, int median, int end, boolean isAcending){     
		int i,j,k,m,n;     
		String[] tempArr = new String[strs.length]; // 임시로 데이터를 저장할 배열    
		i = start;     
		j = median+1;     
		k = start;      
		while (i <= median && j <= end){
			if (isAcending) {
				tempArr[k++] = (strs[i].compareTo(strs [j]) > 0) ? strs [j++] : strs [i++]; 
			}
			else {
				tempArr[k++] = (strs[i].compareTo(strs [j]) < 0) ? strs [j++] : strs [i++];
			}
		}           // 아직 배열에 속하지 못한 부분들을 넣기 위한 부분    
		m = (i > median) ? j : i; // 아직 원소가 남아있는 덩어리가 어디인지 파악    
		n = (i > median) ? end : median; // 마찬가지로, for문의 끝 Index를 정하기 위함임     
		for (; m<=n; m++){ // 앞에서 구한 m, n으로 배열에 속하지 못한 원소들을 채워넣음       
			tempArr[k++] = strs[m];     
		}      
		for (m=start; m<=end; m++){         
			strs[m] = tempArr[m]; // 임시 배열에서 원래 배열로 데이터 옮기기    
		} 
	}*/
	
	
}