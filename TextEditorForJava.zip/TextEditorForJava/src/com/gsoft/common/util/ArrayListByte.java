package com.gsoft.common.util;

import com.gsoft.common.util.Array;

public class ArrayListByte {
	public byte[] list;
	public int count=0;
	public int capacity=0;
	public int resizeInc=100;
	public ArrayListByte(int initMaxLength) {
		capacity = initMaxLength;
		list = new byte[initMaxLength];			
	}
	public byte getItem(int offset) {
		
		return list[offset];
	}
	synchronized public void reset() {
		count=0;
	}
	synchronized public void setCapacity(int c) {
		capacity = c; 
		list = Array.Resize(list, capacity);
		
	}
	synchronized public void add(byte e) {
		if (count>=list.length) {
			capacity = list.length+resizeInc;
			list = Array.Resize(list, capacity);
		}
		list[count] = e;
		count++;
	}
}
