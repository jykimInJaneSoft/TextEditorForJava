package com.gsoft.common.util;

import com.gsoft.common.interfaces.IReset;
import com.gsoft.common.util.Array;

public class ArrayListString  implements IReset {
	public String[] list;
	public int count=0;
	public int resizeInc=100;
	public ArrayListString(int initMaxLength) {
		list = new String[initMaxLength];			
	}
	public ArrayListString(String[] strs) {
		list = new String[strs.length];
		int i;
		for (i=0; i<list.length; i++) {
			list[i] = strs[i];
		}
		count = list.length;
	}
	
	/**CompilerStack과 Compiler사이의 데이터 공유를 위한 메소드*/
	public void setData(ArrayListString other) {
		this.list = other.list;
		this.count = other.count;
	}
	
	public void destroy() {
		int i;
		for (i=0; i<count; i++) {
			list[i] = null;
		}
		count=0;
	}
	/** 배열원소는 그대로 놔두고 count만 0으로 만든다.*/
	public void reset2() {
		count=0;
	}
	public void add(String e) {
		if (count>=list.length) list = Array.Resize(list, list.length+resizeInc);
		list[count] = e;
		count++;
	}
	public void add(String[] list) {
		int i;
		for (i=0; i<list.length; i++) {
			this.add(list[i]);
		}
	}
	
	public String[] getItems() {
		if (list.length==count) return list;
		return Array.Resize(list,count);
	}
	
	public String getItem(int index) {
		return list[index];
	}
	
	public Object clone() {
		int i;
		ArrayListString r = new ArrayListString(count);
		
		for (i=0; i<count; i++) {
			char[] buf = new char[list[i].length()];
			list[i].getChars(0, buf.length, buf, 0);
			r.add(new String(buf));
		}
		return r;
	}
	
	public void InsertNoSpaceError(String[] src, int srcIndex, int destIndex, int len) {
		this.list = Array.InsertNoSpaceError(src, 0, this.list, 0, len, this.count);
		this.count = this.count + len;
	}
	
	public void InsertNoSpaceError(ArrayListString src, int srcIndex, int destIndex, int len) {
		this.list = Array.InsertNoSpaceError(src, 0, this.list, 0, len, this.count);
		this.count = this.count + len;
	}
	
	
	synchronized public void delete(int startIndex, int len) throws Exception {
		list = Array.Delete(list, startIndex, len);
		count -= len;
	}
	
	/**str이란 아이템을 찾아 그것의 인덱스를 리턴한다. 없으면 -1을 리턴한다.*/
	public int getIndex(String str) {
		int i;
		for (i=0; i<count; i++) {
			if (list[i].equals(str)) return i;
		}
		return -1;
	}
	
}
