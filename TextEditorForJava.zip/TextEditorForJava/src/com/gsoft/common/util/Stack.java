package com.gsoft.common.util;


/** generic, template stack*/
public class Stack
{
    class Node
    {
        public Node NodePtr;
        public Object Data;
        public Node()
        {
            //Data = null;
            NodePtr = null;
        }
    }

    Node head;
    Node top;
    public int len;
    public Stack()
    {
        Node node = new Node();
        head = node;
        top = node;
        len = 0;
    }

    public boolean IsEmpty()
    {
        if (head == top)
            return true;
        return false;
    }

    public void Push(Object data)
    {
        Node node = new Node();
        node.Data = data;
        node.NodePtr = top;
        top = node;
        len++;
    }

    public Object Get()
    {
    	if (top!=null) {
    		return top.Data;
    	}
    	else return null;
    }

    public Object Pop() /*throws Exception*/
    {
        //if (IsEmpty()) throw new Exception("스택이 비어 있습니다.");
        Object data = top.Data;
        top = top.NodePtr;
        len--;
        return data;
    }

}
