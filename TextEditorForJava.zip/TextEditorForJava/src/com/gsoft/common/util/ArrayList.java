package com.gsoft.common.util;

import com.gsoft.common.interfaces.IReset;
import com.gsoft.common.util.Array;

public class ArrayList implements IReset {
	public Object[] list;
	public int count=0;
	public int capacity=0;
	public int resizeInc=100;
	public ArrayList(int initMaxLength) {
		capacity = initMaxLength;
		list = new Object[initMaxLength];			
	}
	public ArrayList(Object[] strs) {
		list = new Object[strs.length];
		int i;
		for (i=0; i<list.length; i++) {
			list[i] = strs[i];
		}
		count = list.length;
	}
	
	public Object clone() {
		ArrayList r = new ArrayList(count);
		int i;
		for (i=0; i<this.count; i++) {
			r.add(this.getItem(i));
		}
		return r;
	}
	
	/**count만 0으로 만든다.*/
	synchronized public void reset() {			
		/*int i;
		for (i=0; i<count; i++) {
			list[i] = null;
		}*/
		count=0;
	}
	synchronized public void setCapacity(int c) {
		capacity = c; 
		list = Array.Resize(list, capacity);
		
	}
	
	public ArrayList resize(int newCount) {
		capacity = newCount;
		list = Array.Resize(list, newCount);
		return this;
	}
	
	synchronized public void add(Object e) {
		if (count>=list.length) {
			capacity = list.length+resizeInc;
			list = Array.Resize(list, capacity);
		}
		list[count] = e;
		count++;
	}
	
	synchronized public void addList(ArrayList list) {
		int i;
		for (i=0; i<list.count; i++) {
			this.add(list.getItem(i));
		}
	}
	
	public void setItem(int index, Object o) {
		if (index>=list.length) {
			capacity = list.length+resizeInc;
			list = Array.Resize(list, capacity);
		}
		this.list[index] = o;
	}
	
	synchronized public void insert(int index, Object e) {
		try {
			Object[] src = {e};
			this.list = Array.InsertNoSpaceError(src, 0, list, index, 1, this.count);
			count++;
		}catch(Exception ex) {
		}
	}
	
	synchronized public void insert(int index, Object[] arr) {
		try {
			Object[] src = arr;
			this.list = Array.InsertNoSpaceError(src, 0, list, index, arr.length, this.count);
			count += arr.length;
		}catch(Exception ex) {
		}
	}
	
	synchronized public Object[] getItems() {
		if (list.length==count) return list;
		return Array.Resize(list,count);
	}
	
	public static ArrayList fromStringArray(String[] stringList) {
		int i;
		ArrayList r = new ArrayList(stringList.length);
		for (i=0; i<stringList.length; i++) {
			r.add(stringList[i]);
		}
		return r;
	}
	
	synchronized public Object getItem(int index) {
		try {
			return list[index];
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	/** item의 내용이 아니라 참조 주소가 같으면 가진 것으로 한다.*/
	public boolean hasItem(Object item) {
		int i;
		for (i=0; i<count; i++)  {
			if (list[i]==item) return true;
		}
		return false;
	}
	
	synchronized public void delete(int startIndex, int len) {
		list = Array.Delete(list, startIndex, len);
		count -= len;
	}
	@Override
	public void destroy() {
		
		int i;
		for (i=0; i<count; i++) {
			list[i] = null;
		}
		count=0;
	}
	
}
