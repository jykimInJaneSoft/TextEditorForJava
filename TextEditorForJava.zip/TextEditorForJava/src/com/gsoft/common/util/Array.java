package com.gsoft.common.util;

import com.gsoft.common.Code.CodeChar;
import com.gsoft.common.Code.CodeString;
import com.gsoft.common.Code.CodeStringType;
import com.gsoft.common.interfaces.IReset;
import com.gsoft.common.gui.Buttons.Button;
import com.gsoft.common.gui.Control;
import com.gsoft.common.gui.edittext.EditRichText_Types;

import com.gsoft.common.util.ArrayListCodeChar;
import com.gsoft.common.util.ArrayListChar;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListIReset;
import com.gsoft.common.util.ArrayListInt;
import com.gsoft.common.util.ArrayListString;

public class Array {
	
	public static void copy(byte[] src, int srcIndex, byte[] dest, int destIndex, int len) {
		int i, k;
		for (i=srcIndex, k=destIndex; i<srcIndex+len; i++, k++) {
			dest[k] = src[i];
		}
	}
	
	public static void Copy(EditRichText_Types.Character[] src, int srcIndex, EditRichText_Types.Character[] dest, int destIndex, int len) {
		int i;
		for (i=srcIndex; i<srcIndex+len; i++) {
			dest[destIndex++] = src[i];
		}		
	}
	
	public static void Copy(Object[] src, int srcIndex, Object[] dest, int destIndex, int len) {
		int i;
		for (i=srcIndex; i<srcIndex+len; i++) {
			dest[destIndex++] = src[i];
		}		
	}
	
	public static void Copy(int[] src, int srcIndex, int[] dest, int destIndex, int len) {
		int i;
		for (i=srcIndex; i<srcIndex+len; i++) {
			dest[destIndex++] = src[i];
		}		
	}
	
	public static void Copy(boolean[] src, int srcIndex, boolean[] dest, int destIndex, int len) {
		int i;
		for (i=srcIndex; i<srcIndex+len; i++) {
			dest[destIndex++] = src[i];
		}		
	}
	
	public static void Copy(byte[] src, int srcIndex, byte[] dest, int destIndex, int len) {
		int i;
		for (i=srcIndex; i<srcIndex+len; i++) {
			dest[destIndex++] = src[i];
		}		
	}
	
	public static void Copy(CodeChar[] src, int srcIndex, CodeChar[] dest, int destIndex, int len) {
		int i;
		for (i=srcIndex; i<srcIndex+len; i++) {
			try {
			dest[destIndex++] = src[i];
			}catch(Exception e) {
				e.printStackTrace();
			}
		}		
	}
	
	
	
	
	
	// 늘릴수도 줄일수도 있다.
	public static IReset[] Resize(IReset[] src, int count) {
		int len;
		if (src.length < count) len = src.length;	// 늘리기
		else len = count;		// 줄이기
		IReset[] r = new IReset[count];
		int i;
		for (i=0; i<len; i++) {
			r[i] = src[i];
		}
		src = null;
		return r;
	}
	
	// 늘릴수도 줄일수도 있다.
	public static EditRichText_Types.Character[] Resize(EditRichText_Types.Character[] src, int count) {
		int len;
		if (src.length < count) len = src.length;	// 늘리기
		else len = count;		// 줄이기
		EditRichText_Types.Character[] r = new EditRichText_Types.Character[count];
		int i;
		for (i=0; i<len; i++) {
			r[i] = src[i];
		}
		src = null;
		return r;
	}
	
	// 늘릴수도 줄일수도 있다.
	public static Object[] Resize(Object[] src, int count) {
		int len;
		if (src.length < count) len = src.length;	// 늘리기
		else len = count;		// 줄이기
		Object[] r = new Object[count];
		int i;
		for (i=0; i<len; i++) {
			r[i] = src[i];
		}
		src = null;
		return r;
	}
	
	public static CodeStringType[] Resize(CodeStringType[] src, int count) {
		int len;
		if (src.length < count) len = src.length;	// 늘리기
		else len = count;		// 줄이기
		CodeStringType[] r = new CodeStringType[count];
		int i;
		for (i=0; i<len; i++) {
			r[i] = src[i];
		}
		src = null;
		return r;
	}
	
	// 늘릴수도 줄일수도 있다.
	public static int[] Resize(int[] src, int count) {
		int len;
		if (src.length < count) len = src.length;	// 늘리기
		else len = count;		// 줄이기
		int[] r = new int[count];
		int i;
		for (i=0; i<len; i++) {
			r[i] = src[i];
		}
		src = null;
		return r;
	}
	
	// 늘릴수도 줄일수도 있다.
	public static Control[] Resize(Control[] src, int count) {
		int len;
		if (src.length < count) len = src.length;	// 늘리기
		else len = count;		// 줄이기
		Control[] r = new Control[count];
		int i;
		for (i=0; i<len; i++) {
			r[i] = src[i];
		}
		src = null;
		return r;
	}
	
	public static Button[] Resize(Button[] src, int count) {
		int len;
		if (src.length < count) len = src.length;	// 늘리기
		else len = count;		// 줄이기
		Button[] r = new Button[count];
		int i;
		for (i=0; i<len; i++) {
			r[i] = src[i];
		}
		src = null;
		return r;
	}
	
	// 늘릴수도 줄일수도 있다.
	public static boolean[] Resize(boolean[] src, int count) {
		int len;
		if (src.length < count) len = src.length;	// 늘리기
		else len = count;		// 줄이기
		boolean[] r = new boolean[count];
		int i;
		for (i=0; i<len; i++) {
			r[i] = src[i];
		}
		src = null;
		return r;
	}
	
	
	
	
	
	public static char[] Resize(char[] src, int count) {
		int len;
		if (src.length > count) len = count;	// 줄이기
		else len = src.length;		// 늘리기
		char[] r = new char[count];
		int i;
		for (i=0; i<len; i++) {
			r[i] = src[i];
		}
		src = null;
		return r;
	}
	
	public static CodeChar[] Resize(CodeChar[] src, int count) {
		int len;
		if (src.length > count) len = count;	// 줄이기
		else len = src.length;		// 늘리기
		CodeChar[] r = new CodeChar[count];
		int i;
		for (i=0; i<len; i++) {
			r[i] = src[i];
		}
		src = null;
		return r;
	}

	public static byte[] Resize(byte[] src, int count) {
		int len;
		if (src.length > count) len = count;	// 줄이기
		else len = src.length;		// 늘리기
		byte[] r = new byte[count];
		int i;
		for (i=0; i<len; i++) {
			r[i] = src[i];
		}
		src = null;
		return r;
	}
	
	public static void Copy(char[] src, int srcIndex, char[] dest, int destIndex, int len) {
		int i;
		for (i=srcIndex; i<srcIndex+len; i++) {
			dest[destIndex++] = src[i];
		}		
	}
	
	public static int[] SubArray(int[] src, int srcIndex, int len) {
		int[] r = new int[len];
		int i;
		int count = 0;
		for (i=srcIndex; i<srcIndex+len; i++) {
			r[count++] = src[i];			
		}
		return r;
	}
		
	
	public static char[] SubArray(char[] src, int srcIndex, int len) {
		char[] r = new char[len];
		int i;
		int count = 0;
		for (i=srcIndex; i<srcIndex+len; i++) {
			r[count++] = src[i];			
		}
		return r;
	}
	
	public static Character[] SubArray(Character[] src, int srcIndex, int len) {
		Character[] r = new Character[len];
		int i;
		int count = 0;
		for (i=srcIndex; i<srcIndex+len; i++) {
			r[count++] = src[i];			
		}
		return r;
	}
	
	public static int Find(int[] src, int srcIndex, int c) {
		int i;
		for (i=srcIndex; i<src.length; i++) {
			if (src[i]==c) return i;
		}
		return -1;
	}
	
	public static int Find(char[] src, int srcIndex, int c) {
		int i;
		for (i=srcIndex; i<src.length; i++) {
			if (src[i]==c) return i;
		}
		return -1;
	}
	
	public static int Find(Object[] src, int srcIndex, Object c) {
		int i;
		for (i=srcIndex; i<src.length; i++) {
			if (src[i]==c) return i;
		}
		return -1;
	}
	
	/** 배열공간크기에 영향을 받는다.*/ 
	public static void Insert(int[] src, int srcIndex, int[] dest, int destIndex, int len, int destCount) throws Exception {
		
		int i;
		if (destCount<0) throw new Exception("Insert 공간부족");
		if (destCount-destIndex<0)  throw new Exception("Insert-NegativeArraySize");
		int[] remainder = Array.SubArray(dest, destIndex, destCount-destIndex);
		for (i=srcIndex; i<srcIndex+len; i++) {
			dest[destIndex++] = src[i];
		}
		Array.Copy(remainder, 0, dest, destIndex, remainder.length);
	}
	
	public static void Insert(String[] src, int srcIndex, String[] dest, int destIndex, int len, int destCount) 
			throws Exception {
		int i;
		if (destCount<0) throw new Exception("Insert 공간부족");
		if (destCount-destIndex<0)  throw new Exception("Insert-NegativeArraySize");
		String[] remainder = Array.SubArray(dest, destIndex, destCount-destIndex);
		for (i=srcIndex; i<srcIndex+len; i++) {
			dest[destIndex++] = src[i];
		}
		Array.Copy(remainder, 0, dest, destIndex, remainder.length);		
	}
	
	
	/** 배열공간크기에 영향을 받는다.*/ 
	public static void Insert(char[] src, int srcIndex, char[] dest, int destIndex, int len, int destCount) throws Exception {
		int i;
		if (destCount<0) throw new Exception("Insert 공간부족");
		if (destCount-destIndex<0)  throw new Exception("Insert-NegativeArraySize");
		char[] remainder = Array.SubArray(dest, destIndex, destCount-destIndex);
		for (i=srcIndex; i<srcIndex+len; i++) {
			dest[destIndex++] = src[i];
		}
		Array.Copy(remainder, 0, dest, destIndex, remainder.length);
	}
	
	public static Object[] Delete(Object[] src, int srcIndex, int len) {
		if (srcIndex+len-1<src.length) {
			Object[] result = new Object[src.length-len];
			Array.Copy(src, 0, result, 0, srcIndex);
			Array.Copy(src, srcIndex+len, result, srcIndex, src.length-(srcIndex+len));
			return result;
		}
		else if (srcIndex>=src.length) {
			return src;
		}
		else {
			Object[] result = new Object[srcIndex];
			Array.Copy(src, 0, result, 0, srcIndex);
			return result;
		}
	}
	
	public static IReset[] Delete(IReset[] src, int srcIndex, int len) {
		if (srcIndex+len-1<src.length) {
			IReset[] result = new IReset[src.length-len];
			Array.Copy(src, 0, result, 0, srcIndex);
			Array.Copy(src, srcIndex+len, result, srcIndex, src.length-(srcIndex+len));
			return result;
		}
		else if (srcIndex>=src.length) {
			return src;
		}
		else {
			IReset[] result = new IReset[srcIndex];
			Array.Copy(src, 0, result, 0, srcIndex);
			return result;
		}
	}
	
	public static EditRichText_Types.Character[] Delete(EditRichText_Types.Character[] src, int srcIndex, int len) {
		if (srcIndex+len-1<src.length) {
			EditRichText_Types.Character[] result = new EditRichText_Types.Character[src.length-len];
			Array.Copy(src, 0, result, 0, srcIndex);
			Array.Copy(src, srcIndex+len, result, srcIndex, src.length-(srcIndex+len));
			return result;
		}
		else if (srcIndex>=src.length) {
			return src;
		}
		else {
			EditRichText_Types.Character[] result = new EditRichText_Types.Character[srcIndex];
			Array.Copy(src, 0, result, 0, srcIndex);
			return result;
		}
	}
	
	public static CodeChar[] Delete(CodeChar[] src, int srcIndex, int len) {
		if (srcIndex+len-1<src.length) {
			CodeChar[] result = new CodeChar[src.length-len];
			Array.Copy(src, 0, result, 0, srcIndex);
			Array.Copy(src, srcIndex+len, result, srcIndex, src.length-(srcIndex+len));
			return result;
		}
		else if (srcIndex>=src.length) {
			return src;
		}
		else {
			CodeChar[] result = new CodeChar[srcIndex];
			Array.Copy(src, 0, result, 0, srcIndex);
			return result;
		}
	}
	
	public static int[] Delete(int[] src, int srcIndex, int len) {
		if (srcIndex+len-1<src.length) {
			int[] result = new int[src.length-len];
			Array.Copy(src, 0, result, 0, srcIndex);
			Array.Copy(src, srcIndex+len, result, srcIndex, src.length-(srcIndex+len));
			return result;
		}
		else if (srcIndex>=src.length) {
			return src;
		}
		else {
			int[] result = new int[srcIndex];
			Array.Copy(src, 0, result, 0, srcIndex);
			return result;
		}
	}
	
	public static char[] Delete(char[] src, int srcIndex, int len) {
		char[] result = new char[src.length-len];
		Array.Copy(src, 0, result, 0, srcIndex);
		Array.Copy(src, srcIndex+len, result, srcIndex, src.length-(srcIndex+len));
		return result;
	}
	


	public static int Find(String[] src, int srcIndex, String c) {
		int i;
		for (i=srcIndex; i<src.length; i++) {
			if (src[i].equals(c)) return i;
		}
		return -1;
	}
	
	
	
	/*public static int Find(EditRichText.Character[] src, int srcIndex, EditRichText.Character c) {
		int i;
		if (c!=null) {
			for (i=srcIndex; i<src.length; i++) {
				if (src[i].equals(c)) return i;
			}
		}
		else {
			for (i=srcIndex; i<src.length; i++) {
				if (src[i]==null) return i;
			}
		}
		return -1;
	}*/
	
	public static void Copy(Control[] src, int srcIndex, Control[] dest, int destIndex, int len) {
		int i;
		for (i=srcIndex; i<srcIndex+len; i++) {
			dest[destIndex++] = src[i];
		}		
	}
	
	public static void Copy(String[] src, int srcIndex, String[] dest, int destIndex, int len) {
		int i;
		for (i=srcIndex; i<srcIndex+len; i++) {
			dest[destIndex++] = src[i];
		}		
	}
	
	public static void Copy(CodeString[] src, int srcIndex, CodeString[] dest, int destIndex, int len) {
		int i;
		for (i=srcIndex; i<srcIndex+len; i++) {
			try {
			dest[destIndex++] = src[i];
			}catch(Exception e) {
				e.printStackTrace();
			}
		}		
	}
	
	
	
	public static String[] SubArray(String[] src, int srcIndex, int len) {
		String[] r = new String[len];
		int i;
		int count = 0;
		for (i=srcIndex; i<srcIndex+len; i++) {
			r[count++] = src[i];			
		}
		return r;
	}
	
	public static Object[] SubArray(Object[] src, int srcIndex, int len) {
		Object[] r = new Object[len];
		int i;
		int count = 0;
		for (i=srcIndex; i<srcIndex+len; i++) {
			r[count++] = src[i];			
		}
		return r;
	}

	
	static int getNullIndex(Object[] arr) {
		int i;
		for (i=0; i<arr.length; i++) {
			if (arr[i]==null)
				return i;
		}
		return arr.length;
	}
	

	public static Object[] InsertNoSpaceError(ArrayList src, int srcIndex, 
			ArrayList dest, int destIndex, int len) {
		if (len<=0) return dest.list;
		int destLength = dest.count;
		Object[] r = new Object[destLength+len];
		if (destIndex>0) {
			Array.Copy(dest.list, 0, r, 0, destIndex);
		}
		Array.Copy(src.list, srcIndex, r, destIndex, len);
		if (destLength>destIndex) {
			Array.Copy(dest.list, destIndex, r, destIndex+len, destLength-destIndex);
		}
		return r;
	}
	
	public static IReset[] InsertNoSpaceError(ArrayListIReset src, int srcIndex, 
			ArrayListIReset dest, int destIndex, int len) {
		if (len<=0) return dest.list;
		int destLength = dest.count;
		IReset[] r = new IReset[destLength+len];
		if (destIndex>0) {
			Array.Copy(dest.list, 0, r, 0, destIndex);
		}
		Array.Copy(src.list, srcIndex, r, destIndex, len);
		if (destLength>destIndex) {
			Array.Copy(dest.list, destIndex, r, destIndex+len, destLength-destIndex);
		}
		return r;
	}
	
	public static int[] InsertNoSpaceError(ArrayListInt src, int srcIndex, 
			ArrayListInt dest, int destIndex, int len) {
		if (len<=0) return dest.list;
		int destLength = dest.count;
		int[] r = new int[destLength+len];
		if (destIndex>0) {
			Array.Copy(dest.list, 0, r, 0, destIndex);
		}
		Array.Copy(src.list, srcIndex, r, destIndex, len);
		if (destLength>destIndex) {
			Array.Copy(dest.list, destIndex, r, destIndex+len, destLength-destIndex);
		}
		return r;
	}
	
	
	public static IReset[] InsertNoSpaceError(IReset[] src, int srcIndex, 
			IReset[] dest, int destIndex, int len, int destCount) {
		if (len<=0) return dest;
		int destLength = destCount;
		IReset[] r = new IReset[destLength+len];
		if (destIndex>0) {
			Array.Copy(dest, 0, r, 0, destIndex);
		}
		Array.Copy(src, srcIndex, r, destIndex, len);
		if (destLength>destIndex) {
			Array.Copy(dest, destIndex, r, destIndex+len, destLength-destIndex);
		}
		return r;
	}
	
	/*public static int[] InsertNoSpaceError(int[] src, int srcIndex, 
			int[] dest, int destIndex, int len) {
		if (len<=0) return dest;
		int destLength = getNullIndex(dest);
		int[] r = new int[destLength+len];
		if (destIndex>0) {
			Array.Copy(dest, 0, r, 0, destIndex);
		}
		Array.Copy(src, srcIndex, r, destIndex, len);
		if (destLength>destIndex) {
			Array.Copy(dest, destIndex, r, destIndex+len, destLength-destIndex);
		}
		return r;
	}*/
	
	public static EditRichText_Types.Character[] InsertNoSpaceError(EditRichText_Types.Character[] src, int srcIndex, 
			EditRichText_Types.Character[] dest, int destIndex, int len, int destCount) {
		if (len<=0) return dest;
		int destLength = destCount;
		EditRichText_Types.Character[] r = new EditRichText_Types.Character[destLength+len];
		if (destIndex>0) {
			Array.Copy(dest, 0, r, 0, destIndex);
		}
		Array.Copy(src, srcIndex, r, destIndex, len);
		if (destLength>destIndex) {
			Array.Copy(dest, destIndex, r, destIndex+len, destLength-destIndex);
		}
		return r;
	}
	
	public static Object[] InsertNoSpaceError(Object[] src, int srcIndex, 
			Object[] dest, int destIndex, int len, int destCount) {
		if (len<=0) return dest;
		int destLength = destCount;
		Object[] r = new Object[destLength+len];
		if (destIndex>0) {
			Array.Copy(dest, 0, r, 0, destIndex);
		}
		Array.Copy(src, srcIndex, r, destIndex, len);
		if (destLength>destIndex) {
			Array.Copy(dest, destIndex, r, destIndex+len, destLength-destIndex);
		}
		return r;
	}
	
	public static CodeChar[] InsertNoSpaceError(CodeChar[] src, int srcIndex, 
			CodeChar[] dest, int destIndex, int len, int destCount) {
		if (len<=0) return dest;
		int destLength = destCount;
		CodeChar[] r = new CodeChar[destLength+len];
		if (destIndex>0) {
			try {
			Array.Copy(dest, 0, r, 0, destIndex);
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		Array.Copy(src, srcIndex, r, destIndex, len);
		if (destLength>destIndex) {
			Array.Copy(dest, destIndex, r, destIndex+len, destLength-destIndex);
		}
		return r;
	}
	
	public static Character[] InsertNoSpaceError(Character[] src, int srcIndex, 
			Character[] dest, int destIndex, int len, int destCount) {
		if (len<=0) return dest;
		int destLength = destCount;
		Character[] r = new Character[destLength+len];
		if (destIndex>0) {
			Array.Copy(dest, 0, r, 0, destIndex);
		}
		Array.Copy(src, srcIndex, r, destIndex, len);
		if (destLength>destIndex) {
			Array.Copy(dest, destIndex, r, destIndex+len, destLength-destIndex);
		}
		return r;
	}
	
	public static String[] InsertNoSpaceError(String[] src, int srcIndex, 
			String[] dest, int destIndex, int len, int destCount) {
		if (len<=0) return dest;
		int destLength = destCount;
		String[] r = new String[destLength+len];
		if (destIndex>0) {
			Array.Copy(dest, 0, r, 0, destIndex);
		}
		Array.Copy(src, srcIndex, r, destIndex, len);
		if (destLength>destIndex) {
			Array.Copy(dest, destIndex, r, destIndex+len, destLength-destIndex);
		}
		return r;
	}
	
	public static String[] InsertNoSpaceError(ArrayListString src, int srcIndex, 
			String[] dest, int destIndex, int len, int destCount) {
		if (len<=0) return dest;
		int destLength = destCount;
		String[] r = new String[destLength+len];
		if (destIndex>0) {
			Array.Copy(dest, 0, r, 0, destIndex);
		}
		Array.Copy(src.list, srcIndex, r, destIndex, len);
		if (destLength>destIndex) {
			Array.Copy(dest, destIndex, r, destIndex+len, destLength-destIndex);
		}
		return r;
	}
	
	public static CodeString[] InsertNoSpaceError(CodeString[] src, int srcIndex, 
			CodeString[] dest, int destIndex, int len, int destCount) {
		if (len<=0) return dest;		
		int destLength = destCount;
		CodeString[] r = new CodeString[destLength+len];
		if (destIndex>0) {
			Array.Copy(dest, 0, r, 0, destIndex);
		}
		try {
		Array.Copy(src, srcIndex, r, destIndex, len);
		}catch(Exception e) {
			e.printStackTrace();
		}
		if (destLength>destIndex) {
			Array.Copy(dest, destIndex, r, destIndex+len, destLength-destIndex);
		}
		return r;
	}
	
	
	
	public static CodeString[] Resize(CodeString[] src, int count) {
		int len;
		if (src.length < count) len = src.length;	// 늘리기
		else len = count;		// 줄이기
		CodeString[] r = new CodeString[count];
		int i;
		for (i=0; i<len; i++) {
			r[i] = src[i];
		}
		return r;
		
	}
	
	public static String[] Resize(String[] src, int count) {
		int len;
		if (src.length < count) len = src.length;	// 늘리기
		else len = count;		// 줄이기
		String[] r = new String[count];
		int i;
		for (i=0; i<len; i++) {
			r[i] = src[i];
		}
		for (i=len; i<count; i++) {
			r[i] = "";
		}
		return r;
		
	}
	
	public static ArrayListCodeChar[] Resize(ArrayListCodeChar[] src, int count) {
		int len;
		if (src.length < count) len = src.length;	// 늘리기
		else len = count;		// 줄이기
		ArrayListCodeChar[] r = new ArrayListCodeChar[count];
		int i;
		for (i=0; i<len; i++) {
			r[i] = src[i];
		}
		return r;
		
	}
	
	public static ArrayListChar[] Resize(ArrayListChar[] src, int count) {
		int len;
		if (src.length < count) len = src.length;	// 늘리기
		else len = count;		// 줄이기
		ArrayListChar[] r = new ArrayListChar[count];
		int i;
		for (i=0; i<len; i++) {
			r[i] = src[i];
		}
		for (i=len; i<count; i++) {
			r[i] = new ArrayListChar(0);
		}
		return r;
		
	}
	
	
	public static Control[] Delete(Control[] src, int srcIndex, int len) throws Exception {
		if (src.length-len<0) throw new Exception("Delete-src.length-len<0");
		Control[] result = new Control[src.length-len];
		if (srcIndex<0) throw new Exception("Delete-srcIndex<0");
		Array.Copy(src, 0, result, 0, srcIndex);
		if (src.length-(srcIndex+len)<0) throw new Exception("Delete-src.length-(srcIndex+len)<0");
		Array.Copy(src, srcIndex+len, result, srcIndex, src.length-(srcIndex+len));
		/*int i;
		for (i=srcIndex; i<srcIndex+len; i++) {
			src[i] = null;
		}*/
		return result;
	}
	
	public static boolean[] Delete(boolean[] src, int srcIndex, int len) throws Exception {
		if (src.length-len<0) throw new Exception("Delete-src.length-len<0");
		boolean[] result = new boolean[src.length-len];
		if (srcIndex<0) throw new Exception("Delete-srcIndex<0");
		Array.Copy(src, 0, result, 0, srcIndex);
		if (src.length-(srcIndex+len)<0) throw new Exception("Delete-src.length-(srcIndex+len)<0");
		Array.Copy(src, srcIndex+len, result, srcIndex, src.length-(srcIndex+len));
		return result;
	}
	
	public static String[] Delete(String[] src, int srcIndex, int len) throws Exception {
		
		if (srcIndex+len-1<src.length) {
			String[] result = new String[src.length-len];
			Array.Copy(src, 0, result, 0, srcIndex);
			Array.Copy(src, srcIndex+len, result, srcIndex, src.length-(srcIndex+len));
			return result;
		}
		else if (srcIndex>=src.length) {
			return src;
		}
		else {
			String[] result = new String[srcIndex];
			Array.Copy(src, 0, result, 0, srcIndex);
			return result;
		}
	}
	
	public static CodeString[] Delete(CodeString[] src, int srcIndex, int len) throws Exception {
		if (src.length-len<0) throw new Exception("Delete-src.length-len<0");
		CodeString[] result = new CodeString[src.length-len];
		if (srcIndex<0) throw new Exception("Delete-srcIndex<0");
		Array.Copy(src, 0, result, 0, srcIndex);
		if (src.length-(srcIndex+len)<0) throw new Exception("Delete-src.length-(srcIndex+len)<0");
		Array.Copy(src, srcIndex+len, result, srcIndex, src.length-(srcIndex+len));
		return result;
	}
	
	public static void destroy(CodeString[] src, int srcIndex, int len) {
		int i;
		for (i=srcIndex; i<srcIndex+len; i++) {
			if (src[i]!=null) {
				src[i].str = null;
				//src[i].destroy();
				src[i] = null;
			}
		}
	}
	
	
	
}