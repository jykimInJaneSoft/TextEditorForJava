package com.gsoft.common.util;

import com.gsoft.common.util.Util.IndexOfHighArray;

import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListChar;

public class HighArray_char {
	public int arrayLimit;
	
	ArrayList data;
	public int count;
	
	public HighArray_char(int arrayLimit) {
		this.arrayLimit = arrayLimit;
		data = new ArrayList(10);
	}
	
	/** 모든 자원을 해제한다.*/
	public void destroy() {
		int j;
		for (j=0; j<data.list.length; j++) {
			ArrayListChar list = (ArrayListChar) data.getItem(j);
			if (list!=null) list.destroy();
			list = null;
		}
		data.destroy();
	}
	
	
	/** 상대인덱스(arrayNumber,offset)를 절대인덱스로 바꾼다.*/
	public int index(int arrayNumber, int offset) {
		int i;
		int index = 0;
		// 이전 array까지의 개수들의 합
		for (i=0; i<arrayNumber; i++) {
			ArrayListChar arr = (ArrayListChar) data.getItem(i);
			index += arr.count;
		}
		index += offset;
		return index;
	}
	
	/** 절대인덱스를 상대인덱스(arrayNumber,offset)로 바꾼다.*/
	public IndexOfHighArray indexRelative(int index) {
		int indexOfData = -1;
		int i;
		int len = 0;   // 현재 array까지의 개수들의 합
		int oldLen = 0;// 이전 array까지의 개수들의 합
		for (i=0; i<data.count; i++) {
			ArrayListChar arr = (ArrayListChar) data.getItem(i);
			oldLen = len;
			len += arr.count;
			if (index<len) {
				indexOfData = i;
				break;
			}
		}
		if (index>=len) {
			return null; // ArrayIndexOUtOfBoundsException
		}
		
		int indexInArray = index - oldLen; // offset
		return new IndexOfHighArray(indexOfData, indexInArray);
	}
	
	
	/** 절대인덱스를 상대인덱스(arrayNumber,offset)로 바꾼다.*/
	public void indexRelative(Object owner, int index, IndexOfHighArray result) {
		int indexOfData = -1;
		int i;
		int len = 0;    // 현재 array까지의 개수들의 합
		int oldLen = 0; // 이전 array까지의 개수들의 합
		for (i=0; i<data.count; i++) {
			ArrayListChar arr = (ArrayListChar) data.getItem(i);
			oldLen = len;
			len += arr.count;
			if (index<len) {
				indexOfData = i;
				break;
			}
		}
		if (index>=len) {
			return; // ArrayIndexOUtOfBoundsException
		}
		
		int indexInArray = index - oldLen; // offset
		result.arrayNumber = indexOfData;
		result.offset = indexInArray;
	}
	
	
	public int getCount() {
		// 마지막 item을 얻는다.
		/*ArrayListChar arrItem = (ArrayListChar) data.getItem(data.count-1);
		//int len = arrayLimit * (data.count-1) + arrItem.count;
		int i;
		int len = 0;
		for (i=0; i<data.count-1; i++) {
			ArrayListChar arr = (ArrayListChar) data.getItem(i);
			len += arr.count;
		}
		len += arrItem.count;
		return len;*/
		return count;
	}
	
	public String getItems() {
		int i;
		char[] r = new char[this.getCount()];
		for (i=0; i<r.length; i++) {
			r[i] = this.getItem(i);
		}
		return new String(r);
	}
			
	public char getItem(int index) {
		IndexOfHighArray indexOfHigh = this.indexRelative(index);
		
		ArrayListChar arrItem = (ArrayListChar) data.getItem(indexOfHigh.arrayNumber);
		return arrItem.getItem(indexOfHigh.offset);
	}
	
	public char charAt(int i) {
		
		return this.getItem(i);
	}
	
	public void insert(int index, String str) {
		IndexOfHighArray indexOfHigh = this.indexRelative(index);
		
		ArrayListChar arrItem = (ArrayListChar) data.getItem(indexOfHigh.arrayNumber);
		arrItem.insert(indexOfHigh.offset, str);
		
		count += str.length();
	}
	
	/** index부터 str길이만큼을 str로 대체한다.*/
	public void replace(int index, String str) {
		int i;
		int len = index + str.length();
		for (i=index; i<len; i++) {
			IndexOfHighArray indexOfHigh = this.indexRelative(i);				
			ArrayListChar arrItem = (ArrayListChar) data.getItem(indexOfHigh.arrayNumber);
			arrItem.list[indexOfHigh.offset] = str.charAt(i-index);
		}
	}
	
	
	public void add(String str) {
		int i;
		int len = str.length();
		for (i=0; i<len; i++) {
			this.add(str.charAt(i));
		}
	}
	
	public void add(HighArray_char str) {
		int i;
		int len = str.count;
		for (i=0; i<len; i++) {
			this.add(str.charAt(i));
		}
	}
	
	
	
	public void add(char c) {
		if (data.count==0) {
			ArrayListChar newItem = new ArrayListChar(arrayLimit);
			data.add(newItem);
		}
		
		ArrayListChar item;
		
		// 마지막 item을 얻는다.
		ArrayListChar arrItem = (ArrayListChar) data.getItem(data.count-1);
		if (arrItem.count>=arrayLimit) { // 새로운 item을 생성해서 넣는다.
			ArrayListChar newItem = new ArrayListChar(arrayLimit);
			data.add(newItem);
			item = newItem;
		}
		else {
			item = arrItem;
		}
		
		item.add(c);
		count++;
	}
	
	public boolean equals(String str) {
		int i;
		if (this.count!=str.length()) return false;
		for (i=0; i<this.count; i++) {
			if (this.getItem(i)!=str.charAt(i)) {
				return false;
			}
		}
		return true;
	}

	public void reset2() {
		
		int i;
		for (i=0; i<data.count; i++) {
			ArrayListChar arr = (ArrayListChar) data.getItem(i);
			arr.count = 0;
		}
		data.count = 0;
		this.count = 0;
	}

	public HighArray_char concat(HighArray_char result) {
		
		this.add(result);
		return this;
	}

	/**startIndex, endIndex : [startIndex, endIndex)*/
	public String substring(int startIndex, int endIndex) {
		
		ArrayListChar r = new ArrayListChar(endIndex-startIndex);
		int i;
		for (i=startIndex; i<endIndex; i++) {
			r.add(this.getItem(i));
		}
		return r.toString();
	}

	
	
}






