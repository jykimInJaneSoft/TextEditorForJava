package com.gsoft.common.util;

import com.gsoft.common.Common_Settings;
import com.gsoft.common.Code.CodeChar;
import com.gsoft.common.Code.CodeString;
import com.gsoft.common.interfaces.IReset;

import com.gsoft.common.util.Array;

public class ArrayListCodeChar implements IReset {
	public CodeChar[] list;
	public int count=0;
	public int capacity=0;
	public int resizeInc=100;
	public ArrayListCodeChar(int initMaxLength) {
		capacity = initMaxLength;
		list = new CodeChar[initMaxLength];			
	}
	public void destroy() {
		
		int i;
		for (i=0; i<list.length; i++) {
			if (list[i]!=null) {
				list[i].destroy();
				list[i] = null;
			}
		}
		list = null;
		count = 0;
		
	}
	/** 배열원소는 그대로 놔두고 count만 0으로 만든다.*/
	synchronized public void reset2() {
		count=0;
	}
	synchronized public void setText(CodeString str) {
		if (count<str.length()) {
			list = Array.Resize(list, str.length());
		}
		int i;
		for (i=0; i<str.length(); i++) {
			list[i] = str.charAt(i);
		}
		count = str.length();
		//list = arr;
	}
	synchronized public void concate(CodeString str) {
		try {
		if (list.length<count+str.count) {
			capacity = count+str.count*5;
			list = Array.Resize(list, capacity);
		}
		Array.Copy(str.listCodeChar, 0, list, count, str.length());
		count += str.length();
		}catch(Exception e) {
			if (Common_Settings.g_printsLog) e.printStackTrace();
		}
	}
	synchronized public void insert(int index, CodeString str) {
		try {
			this.list = Array.InsertNoSpaceError(str.listCodeChar, 0, list, index, str.length(), this.count);
			count += str.length();
		}catch(Exception e) {
		}
	}
	synchronized public void delete(int startIndex, int len) {
		list = Array.Delete(list, startIndex, len);
		count -= len;
	}
	synchronized public void setCapacity(int c) {
		capacity = c; 
		list = Array.Resize(list, capacity);
		
	}
	synchronized public void add(CodeChar e) {
		if (count>=list.length) {
			capacity = list.length+resizeInc;
			list = Array.Resize(list, list.length+resizeInc);
		}
		/*if (list[count]==null) {
			list[count] = e;
		}
		else {
			list[count].copy(e);
		}*/
		list[count] = e;
		count++;
	}
	
	synchronized public CodeChar[] getItems() {
		if (list.length==count) return list;
		return Array.Resize(list,count);
	}
	
	synchronized public CodeChar getItem(int index) {
		return list[index];
	}
	
}
