package com.gsoft.common.util;

import com.gsoft.common.interfaces.IReset;
import com.gsoft.common.util.Array;

public class ArrayListIReset {
	public IReset[] list;
	public int count=0;
	public int capacity=0;
	public int resizeInc=100;
	public ArrayListIReset(int initMaxLength) {
		capacity = initMaxLength;
		list = new IReset[initMaxLength];			
	}
	
	/**CompilerStack과 Compiler사이의 데이터 공유(mlistOf***)를 위한 메소드*/
	/*public void setData(ArrayListIReset other) {
		this.list = other.list;
		this.count = other.count;
	}*/
	
	public Object clone() {
		ArrayListIReset r = new ArrayListIReset(count);
		int i;
		for (i=0; i<count; i++) {
			r.list[i] = this.list[i];
		}
		r.count = this.count;
		return r;
	}
	
	/** 배열원소의 reset()을 호출하여 모든 메모리자원들을 해제한다.*/
	synchronized public void destroy() {				
		int i;
		for (i=0; i<count; i++) {				
			if (list[i]!=null) {
				list[i].destroy();
				list[i] = null;
			}
		}
		count=0;
	}
	/** 배열원소는 그대로 놔두고 count만 0으로 만든다.*/
	public void reset2() {
		count=0;
	}
	synchronized public void setCapacity(int c) {
		capacity = c; 
		list = Array.Resize(list, capacity);
		
	}
	synchronized public void add(IReset e) {
		if (count>=list.length) {
			capacity = list.length+resizeInc;
			list = Array.Resize(list, capacity);
		}
		list[count] = e;
		count++;
	}
	
	synchronized public void insert(int index, IReset e) {
		try {
			IReset[] src = {e};
			this.list = Array.InsertNoSpaceError(src, 0, list, index, 1, this.count);
			count++;
		}catch(Exception ex) {
		}
	}
	
	synchronized public IReset[] getItems() {
		if (list.length==count) return list;
		return Array.Resize(list,count);
	}
	
	synchronized public IReset getItem(int index) {
		return list[index];
	}
	
	/** item의 내용이 아니라 참조 주소가 같으면 가진 것으로 한다.*/
	public boolean hasItem(IReset item) {
		int i;
		for (i=0; i<count; i++)  {
			if (list[i]==item) return true;
		}
		return false;
	}
	
}

