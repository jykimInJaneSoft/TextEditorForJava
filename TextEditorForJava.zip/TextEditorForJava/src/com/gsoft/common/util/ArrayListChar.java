package com.gsoft.common.util;

import com.gsoft.common.util.Array;

@SuppressWarnings("unused")
public class ArrayListChar {
	public char[] list;
	public int count=0;
	public int capacity=0;
	public int resizeInc=100;
	public ArrayListChar(int initMaxLength) {
		capacity = initMaxLength;
		list = new char[initMaxLength];			
	}
	/** 모든 자원을 해제한다.*/
	public void destroy() {
		list = null;
		count = 0;
	}
	/**count만 0로 만든다.*/
	synchronized public void reset2() {
		count=0;
	}
	synchronized public void setText(String str) {
		if (count<str.length()) {
			list = Array.Resize(list, str.length());
		}
		//char[] arr = new char[str.length()];
		str.getChars(0, str.length(), list, 0);
		count = str.length();
	}
	
	synchronized public void insert(int index, String str) {			
		char[] buf = new char[str.length()];
		str.getChars(0, str.length(), buf, 0);
		if (list.length < count+buf.length) {
			list = Array.Resize(list, count+resizeInc);
		}
		try {
			Array.Insert(buf, 0, list, index, buf.length, count);
			count += buf.length;
		}catch(Exception e) {
		}
	}
	
	synchronized public void delete(int startIndex, int len) {
		list = Array.Delete(list, startIndex, len);
		count -= len;
	}
	
	synchronized public void setCapacity(int c) {
		capacity = c; 
		list = Array.Resize(list, capacity);
		
	}
	synchronized public void add(char e) {
		if (count>=list.length) {
			capacity = list.length+resizeInc;
			list = Array.Resize(list, capacity);
		}
		list[count] = e;
		count++;
	}
	
	
	synchronized public void add(String str) {
		if (str==null) {
			int a;
			a=0;
			a++;
		}
		if (count+str.length()>=list.length) {
			capacity = list.length+str.length()+resizeInc;
			list = Array.Resize(list, capacity);
		}
		str.getChars(0, str.length(), list, count);
		count += str.length();
	}
	
	synchronized public char[] getItems() {
		if (list.length==count) return list;
		return Array.Resize(list,count);
	}
	
	synchronized public char getItem(int index) {
		return list[index];
	}
	public char charAt(int index) {
		
		return getItem(index);
	}
	/**CompilerStack과 Compiler사이의 데이터 공유(filename, packageName)를 위한 메소드*/
	public String replace(char oldChar, char newChar) {
		
		String r = this.toString().replace(oldChar, newChar);
		return r;
	}
	
	public String toString() {
		return new String(this.getItems());
	}
	
}
