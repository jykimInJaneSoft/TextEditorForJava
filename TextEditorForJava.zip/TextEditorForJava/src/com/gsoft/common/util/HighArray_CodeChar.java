package com.gsoft.common.util;

import com.gsoft.common.Code.CodeChar;
import com.gsoft.common.Code.CodeString;
import com.gsoft.common.util.Util.IndexOfHighArray;

import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListCodeChar;
import com.gsoft.common.util.HighArray_char;

public class HighArray_CodeChar {
	public int arrayLimit;
	
	ArrayList data;
	
	public int count = 0;
	
	public HighArray_CodeChar(String text, int textColor) {
		if (text==null) return;
		this.arrayLimit = 100;
		data = new ArrayList(10);			
		int i;
		for (i=0; i<text.length(); i++) {
			this.add(new CodeChar(text.charAt(i), textColor));
		}
	}
	
	public HighArray_CodeChar(HighArray_char text, int textColor) {
		this.arrayLimit = 100;
		data = new ArrayList(10);			
		int i;
		for (i=0; i<text.count; i++) {
			this.add(new CodeChar(text.charAt(i), textColor));
		}
	}
	
	public HighArray_CodeChar(int arrayLimit) {
		this.arrayLimit = arrayLimit;
		data = new ArrayList(10);
	}
	
	/** 모든 자원을 해제한다.*/
	public void destroy() {
		int j;
		for (j=0; j<data.list.length; j++) {
			ArrayListCodeChar list = (ArrayListCodeChar) data.getItem(j);
			if (list!=null) list.destroy();
			list = null;
		}
		data.destroy();
		count = 0;
	}
	
	/**CompilerStack과 Compiler사이의 데이터 공유(strInput, strOutput)를 위한 메소드*/
	/*public void setData(HighArray_CodeChar other) {
		this.data = other.data;
		this.count = other.count;
	}*/
	
	
	/** 상대인덱스(arrayNumber,offset)를 절대인덱스로 바꾼다.*/
	public int index(int arrayNumber, int offset) {
		int i;
		int index = 0;
		// 이전 array까지의 개수들의 합
		for (i=0; i<arrayNumber; i++) {
			ArrayListCodeChar arr = (ArrayListCodeChar) data.getItem(i);
			index += arr.count;
		}
		index += offset;
		return index;
	}
	
	/** 절대인덱스를 상대인덱스(arrayNumber,offset)로 바꾼다.*/
	public IndexOfHighArray indexRelative(int index) {
		int indexOfData = -1;
		int i;
		int len = 0;   // 현재 array까지의 개수들의 합
		int oldLen = 0;// 이전 array까지의 개수들의 합
		for (i=0; i<data.count; i++) {
			ArrayListCodeChar arr = (ArrayListCodeChar) data.getItem(i);
			oldLen = len;
			len += arr.count;
			if (index<len) {
				indexOfData = i;
				break;
			}
		}
		if (index>=len) {
			return null; // ArrayIndexOUtOfBoundsException
		}
		
		int indexInArray = index - oldLen; // offset
		return new IndexOfHighArray(indexOfData, indexInArray);
	}
	
	
	/** 절대인덱스를 상대인덱스(arrayNumber,offset)로 바꾼다.*/
	public void indexRelative(Object owner, int index, IndexOfHighArray result) {
		int indexOfData = -1;
		int i;
		int len = 0;    // 현재 array까지의 개수들의 합
		int oldLen = 0; // 이전 array까지의 개수들의 합
		for (i=0; i<data.count; i++) {
			ArrayListCodeChar arr = (ArrayListCodeChar) data.getItem(i);
			oldLen = len;
			len += arr.count;
			if (index<len) {
				indexOfData = i;
				break;
			}
		}
		if (index>=len) {
			return; // ArrayIndexOUtOfBoundsException
		}
		
		int indexInArray = index - oldLen; // offset
		result.arrayNumber = indexOfData;
		result.offset = indexInArray;
	}
	
	
	public int getCount() {
		// 마지막 item을 얻는다.
		/*ArrayListCodeChar arrItem = (ArrayListCodeChar) data.getItem(data.count-1);
		//int len = arrayLimit * (data.count-1) + arrItem.count;
		int i;
		int len = 0;
		for (i=0; i<data.count-1; i++) {
			ArrayListCodeChar arr = (ArrayListCodeChar) data.getItem(i);
			len += arr.count;
		}
		len += arrItem.count;
		return len; */
		return count;
	}
	
	
			
	public CodeChar getItem(int index) {
		IndexOfHighArray indexOfHigh = this.indexRelative(index);
		
		ArrayListCodeChar arrItem = (ArrayListCodeChar) data.getItem(indexOfHigh.arrayNumber);
		return arrItem.getItem(indexOfHigh.offset);
	}
	
	public CodeChar[] getItems() {
		CodeChar[] r = new CodeChar[count];
		int i;
		for (i=0; i<r.length; i++) {
			r[i] = getItem(i);
		}
		return r;
	}
	
	
	public void add(CodeChar[] arr) {
		int i;
		int len = arr.length;
		for (i=0; i<len; i++) {
			this.add(arr[i]);
		}
	}
	
	public void add(CodeString arr) {
		int i;
		if (arr==null) return;
		int len = arr.length();
		for (i=0; i<len; i++) {
			this.add(arr.charAt(i));
		}
	}
	
	public void add(HighArray_CodeChar arr) {
		int i;
		int len = arr.getCount();
		for (i=0; i<len; i++) {
			this.add(arr.getItem(i));
		}
	}
	
	
	
	public void add(CodeChar c) {
		if (data.count==0) {
			ArrayListCodeChar newItem = new ArrayListCodeChar(arrayLimit);
			data.add(newItem);
		}
		
		ArrayListCodeChar item;
		
		// 마지막 item을 얻는다.
		ArrayListCodeChar arrItem = (ArrayListCodeChar) data.getItem(data.count-1);
		if (arrItem.count>=arrayLimit) { // 새로운 item을 생성해서 넣는다.
			ArrayListCodeChar newItem = new ArrayListCodeChar(arrayLimit);
			data.add(newItem);
			item = newItem;
		}
		else {
			item = arrItem;
		}
		
		item.add(c);
		count++;
	}
	
	public boolean equals(String str) {
		int i;
		if (this.count!=str.length()) return false;
		for (i=0; i<this.count; i++) {
			if (this.getItem(i).c!=str.charAt(i)) {
				return false;
			}
		}
		return true;
	}
	
	public CodeString toCodeString() {
		CodeChar[] r = this.getItems();
		return new CodeString(r, r.length);
	}
	
	public String toString() {
		return this.toCodeString().str;
	}
	/**스트링의 앞과 뒷 부분에서 ' ', '\t', '\r', '\n' 을 제거한다.*/
	public HighArray_CodeChar trim() {
		int i;
		int startIndex = -1, endIndex = -1;
		for (i=0; i<this.count; i++) {
			char c = this.getItem(i).c;
			if (!(c==' ' || c=='\t' || c=='\r' || c=='\n')) {
				startIndex = i;
				break;
			}
		}
		for (i=count-1; i>=0; i--) {
			char c = getItem(i).c;
			if (!(c==' ' || c=='\t' || c=='\r' || c=='\n')) {
				endIndex = i;
				break;
			}
		}
		return this.substring2(startIndex, endIndex+1);
	}
	/**start포함, end미포함*/
	public HighArray_CodeChar substring2(int start, int end) {
		
		int len = end-start;
		HighArray_CodeChar r = new HighArray_CodeChar(len);
		int i;
		for (i=0; i<len; i++) {
			r.add(this.getItem(i+start));
		}
		return r;
	}
	/**start포함, end미포함*/
	public CodeString substring(int start, int end) {
		
		int len = end-start;
		ArrayListCodeChar r = new ArrayListCodeChar(len);
		int i;
		for (i=0; i<len; i++) {
			r.add(this.getItem(i+start));
		}
		return new CodeString(r.getItems(), len);
	}

	public int length() {
		
		return count;
	}

	public CodeChar charAt(int i) {
		
		return this.getItem(i);
	}
	
	/**startIndex는 포함, endIndex는 불포함
	 * @param startIndex : HighArray_CodeChar에서의 인덱스
	 * @param endIndex : HighArray_CodeChar에서의 인덱스*/
	public void delete(int startIndex, int endIndex) {
		IndexOfHighArray startIndexRelative = this.indexRelative(startIndex);
		IndexOfHighArray endIndexRelative = this.indexRelative(endIndex);
		
		if (startIndexRelative.arrayNumber==endIndexRelative.arrayNumber) {
			ArrayListCodeChar arrItem = (ArrayListCodeChar) data.getItem(startIndexRelative.arrayNumber);
			int len = endIndexRelative.offset-startIndexRelative.offset;
			arrItem.delete(startIndexRelative.offset, len);
			this.count -= len;
		}
		else {
			ArrayListCodeChar arrItem = (ArrayListCodeChar) data.getItem(startIndexRelative.arrayNumber);
			int len = arrItem.count-1-startIndexRelative.offset+1;
			arrItem.delete(startIndexRelative.offset, len);
			this.count -= len;
			
			int i;
			for (i=startIndexRelative.arrayNumber+1; i<endIndexRelative.arrayNumber; i++) {
				ArrayListCodeChar arrItem2 = (ArrayListCodeChar) data.getItem(i);
				this.count -= arrItem2.count;
				arrItem2.reset2();				
			}
			arrItem = (ArrayListCodeChar) data.getItem(endIndexRelative.arrayNumber);
			len = endIndexRelative.offset;
			arrItem.delete(0, len);
			
			this.count -= len;
		}
	}
	
	
	public void insert(int startIndex, CodeString text) {
		IndexOfHighArray startIndexRelative = this.indexRelative(startIndex);
		ArrayListCodeChar arrItem = (ArrayListCodeChar) data.getItem(startIndexRelative.arrayNumber);
		arrItem.insert(startIndexRelative.offset, text);
		this.count += text.count;
	}

	public HighArray_CodeChar concate(HighArray_CodeChar highArray_CodeChar) {
		
		this.add(highArray_CodeChar);
		return this;
	}

	public HighArray_CodeChar concate(CodeString codeString) {
		
		this.add(codeString);
		return this;
	}
}
