package com.gsoft.dependent;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.ProcessBuilder.Redirect;
import java.nio.ByteBuffer;
import java.util.Map;

import android.content.Context;

import com.gsoft.common.Code.CodeString;
import com.gsoft.common.CommonGUI;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.Events.MotionEvent;
import com.gsoft.common.FileHelper;
import com.gsoft.common.IO;
import com.gsoft.common.IO_types.ReturnOfReadString;
import com.gsoft.common.IO_types.TextFormat;
import com.gsoft.common.Sizing.Rectangle;
import com.gsoft.common.Sizing.Size;
import com.gsoft.common.interfaces.OnTouchListener;
import com.gsoft.common.compiler.Number;
import com.gsoft.common.compiler.ClassCache;
import com.gsoft.common.compiler.CompilerHelper;
import com.gsoft.common.compiler.CompilerStatic;
import com.gsoft.common.compiler.Compiler_types.FindClassParams;
import com.gsoft.common.compiler.Compiler_types.FindFunctionParams;
import com.gsoft.common.compiler.Compiler_types.LoadWayOfFindClassParams;
import com.gsoft.common.compiler.Fullname;
import com.gsoft.common.compiler.classloader.Loader;
import com.gsoft.common.compiler.debug.DebugView.RuturnOfinputSubscriptionToArray;
import com.gsoft.common.compiler.gui.MainClassesList;
import com.gsoft.common.compiler.util.Builder.RunOrDebug;
import com.gsoft.common.compiler.util.Builder;
import com.gsoft.common.compiler.util.OutputDir;
import com.gsoft.common.gui.Buttons.Button;
import com.gsoft.common.gui.Control;
import com.gsoft.common.gui.FileDialog;
import com.gsoft.common.gui.FileDialogEventHandler;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListChar;
import com.gsoft.common.util.ArrayListIReset;
import com.gsoft.common.util.HighArray_char;

@SuppressWarnings("unused")
public class ClassFileRunner {
	/**builder.command를 첫번째 한번만 출력하기 위한 것이다.*/
	public static boolean runFirst = true;
	
	
	/**janeSoft/project/Test/src/Test 디렉토리, 
	 * janeSoft/project/Test/output/Test 디렉토리 등이 될 수 있다.*/
	public static String mAbsFilename;
	
	/**ThreadRunningOrDebuggingAClassFile.runAClassFile_sub2()에서 
	 *자바 프로세스를 실행한 스레드, 이전 자바 프로세스의 콘솔출력을 중단시키기위해 사용한다.
	 */
	static ThreadRunningOrDebuggingAClassFile oldThreadRunningJavaProcess;
	/**ThreadRunningOrDebuggingAClassFile.runAClassFile_sub2()에서 
	 *자바 프로세스를 실행한 스레드들의 리스트, 이전 자바 프로세스들의 콘솔출력을 중단시키기위해 사용한다.
	 */
	static ArrayList listOfThreadsRunningJavaProcess = new ArrayList(10);
	/**jar process[], ThreadRunningOrDebuggingAClassFile.runAClassFile_sub2()에서 
	 *실행한 자바 프로세스들의 리스트, 이전 자바 프로세스들의 콘솔출력을 위한 파일들을 지우기 위해 사용한다.*/
	static ArrayList listOfJavaProcesses = new ArrayList(10);
	
	
	/**ThreadRunningOrDebuggingAClassFile.runAClassFile_sub2()에서 
	 *디버그 프로세스를 실행한 스레드, 이전 디버그 프로세스의 디버그창출력을 중단시키기위해 사용한다.
	 */
	static ThreadRunningOrDebuggingAClassFile oldThreadRunningDebugProcess;
	/**ThreadRunningOrDebuggingAClassFile.runAClassFile_sub2()에서 
	 *디버그 프로세스를 실행한 스레드들의 리스트, 이전 디버그 프로세스들의 디버그창출력을 중단시키기위해 사용한다.
	 */
	static ArrayList listOfThreadsRunningDebugProcess = new ArrayList(10);
	
	/**jdb process[], ThreadRunningOrDebuggingAClassFile.runAClassFile_sub2()에서 
	 *실행한 디버그 프로세스들의 리스트, 이전 디버그 프로세스들의 디버그창출력을 위한 파일들을 지우기 위해 사용한다.*/
	static ArrayList listOfDebugProcesses = new ArrayList(10);


	/** "" means null*/
	public static String debugCommand = "";
	
	/**debugCommand = ""*/
	public static void resetDebugCommand() {
		debugCommand = "";
	}
	/**debugCommand += command*/
	public static void addToDebugCommand(String command) {
		if (debugCommand==null) {
			debugCommand = "";
		}		
		debugCommand += command;
	}
	/**debugCommand = command*/
	public static void replaceDebugCommand(String command) {
		debugCommand = command;		
	}
	
	public static void inputLocalsDebugCommand() {
		replaceDebugCommand("locals\r\n");
	}
	/**Refer to CompilerInterface.callDebugCommmand()*/
	public static void inputPrintDebugCommand(String varName) {
		replaceDebugCommand("print "+varName+"\r\n");
	}
	/**Refer to CompilerInterface.callDebugCommmand()*/
	public static void inputDumpDebugCommand(String objectName) {
		replaceDebugCommand("dump "+objectName+"\r\n");
	}
	
	public static void killThread(ThreadRunningOrDebuggingAClassFile thread) {
		if (thread!=null) {
			thread.haveToDisconnectWithOutputFile = true;
		}
	}
	
	/**oldThreadRunningJavaProcess, oldThreadRunningDebugProcess을 킬한다.*/
	public static void killOldThread() {
		if (oldThreadRunningJavaProcess!=null) {			
			oldThreadRunningJavaProcess.haveToDisconnectWithOutputFile = true;
			listOfThreadsRunningJavaProcess.setItem(listOfThreadsRunningJavaProcess.count-1, null);
			oldThreadRunningJavaProcess = null;
		}
		if (oldThreadRunningDebugProcess!=null) {
			oldThreadRunningDebugProcess.haveToDisconnectWithOutputFile = true;
			listOfThreadsRunningDebugProcess.setItem(listOfThreadsRunningDebugProcess.count-1, null);
			oldThreadRunningDebugProcess = null;
		}
		
		if (listOfJavaProcesses.count>0) {
			Process p = (Process) listOfJavaProcesses.getItem(listOfJavaProcesses.count-1);
			if (p!=null) {
				p.destroy();
				listOfJavaProcesses.setItem(listOfJavaProcesses.count-1, null);
			}
		}
		
		if (listOfDebugProcesses.count>0) {
			Process p = (Process) listOfDebugProcesses.getItem(listOfDebugProcesses.count-1);
			if (p!=null) {
				p.destroy();
				listOfDebugProcesses.setItem(listOfDebugProcesses.count-1, null);
			}
		}
	}
	
	
	
	
	/**콘솔과 에러, 디버그 출력을 위한 파일들을 지운다.*/
	public static void lastOperation() {
		int i;
		for (i=0; i<listOfJavaProcesses.count; i++) {
			Process p = (Process) listOfJavaProcesses.getItem(i);
			if (p!=null) p.destroy();
			ThreadRunningOrDebuggingAClassFile thread = (ThreadRunningOrDebuggingAClassFile) listOfThreadsRunningJavaProcess.getItem(i);
			if (thread!=null) {
				thread.haveToDisconnectWithOutputFile = true;
				if (thread.isAlive()) {
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						
						e.printStackTrace();
					}
				}
			}
		}
		for (i=0; i<listOfDebugProcesses.count; i++) {
			Process p = (Process) listOfDebugProcesses.getItem(i);
			if (p!=null) p.destroy();
			ThreadRunningOrDebuggingAClassFile thread = (ThreadRunningOrDebuggingAClassFile) listOfThreadsRunningDebugProcess.getItem(i);
			if (thread!=null) {
				thread.haveToDisconnectWithOutputFile = true;
				if (thread.isAlive()) {
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						
						e.printStackTrace();
					}
				}
			}
		}
	}
	
	public static class ThreadFindMainClasses extends Thread implements OnTouchListener {
		//private FileDialogEventHandler owner;
		public MainClassesList menuMainClasses;
		public String[] namesOfMenuMainClasses;
		/** menuMainClasses에서 사용자가 선택한 클래스 이름, entry point in a jar*/
		private String selectedClassName;
		
		private RunOrDebug runOrDebug;
		String mAbsFilename;
		
		/**메인함수를 찾는 스레드, mode는 0이다.
		 * @param mode : 0 = runAClassFile_sub(), 1=runAClassFile_sub2()*/
		public ThreadFindMainClasses(String mAbsFilename, RunOrDebug runOrDebug) {
			this.runOrDebug = runOrDebug;
			this.mAbsFilename = mAbsFilename;
		}
		
		/** mode가 0이면 사용자가 선택한 mAbsFilename 디렉토리에서 main함수를 포함하는 클래스들을 찾아서
		menuMainClasses 메뉴를 만들고 그것을 사용자에게 보여준다. 
		mode가 1이면 ThreadRunningOrDebuggingAClassFile 스레드에서 사용자가 선택한 클래스 파일을 entry point로 만들고 
		jar파일로 만들어서 Console창에 결과를 출력하여 보여준다.*/
		public void run() {
			// 사용자가 선택한 mAbsFilename 디렉토리에서 main함수를 포함하는 클래스들을 찾아서
			// menuMainClasses 메뉴를 만들고 그것을 사용자에게 보여준다.
			runAClassFile_sub();
		}
		
		/**사용자가 선택한 mAbsFilename 디렉토리에서 main함수를 포함하는 클래스들을 찾아서
		 *  menuMainClasses 메뉴를 만들고 그것을 사용자에게 보여준다.*/
		void runAClassFile_sub() {
			String absFilename = mAbsFilename;
			
		
			ClassFileRunner.mAbsFilename = absFilename;
			
			// 메인 클래스들을 찾는다.
			ArrayList r = new ArrayList(5);
			findMainClass(absFilename, r);
			
			int i;
			String[] classNames = new String[r.count];
			for (i=0; i<r.count; i++) {
				classNames[i] = ((FindClassParams)r.getItem(i)).name;
			}
			
			if (classNames.length==0) {
				// "Making a jar file and running it...." 메시지를 제거한다.
				CommonGUI.showMessage(true, "couldn't find a class including a main function in "+
						FileHelper.getFilename(ClassFileRunner.mAbsFilename)+ 
						". Open a class including a main func and then run it.");
				return;
			}
			
			File fileAbsFilename = new File(absFilename);
			if (fileAbsFilename.isFile()) {
				// Run1 에서만
				selectedClassName = Fullname.toFullname(2, absFilename);
				Thread threadMakingJarAndRun = new ThreadRunningOrDebuggingAClassFile(this.mAbsFilename, selectedClassName, this.runOrDebug);
				threadMakingJarAndRun.start();
				return;
			}
			
			
			CommonGUI.showMessage(true, 
					classNames.length + " classes including a main function were found. \nSelect a class you want to run.");
			
			// 메뉴 아이템들을 만든다.
			this.namesOfMenuMainClasses = classNames;
			
			this.createMenuMainClasses(false);
			Button[] buttons = this.menuMainClasses.getMenuListButtons(this.namesOfMenuMainClasses);
			this.menuMainClasses.setButtons(buttons);
			
			
			this.menuMainClasses.open(true);
			
			Control.view.postInvalidate();
			
			
		}
		
		void createMenuMainClasses(boolean changeBounds) {
			
			int viewWidth = Control.view.getWidth();
			int viewHeight = Control.view.getHeight();
			int x, y;
			
			float fHeightScale = 0.1f;
			if (namesOfMenuMainClasses.length>10) fHeightScale = 0.8f;
			else if (namesOfMenuMainClasses.length>5) fHeightScale = 0.6f;
			else fHeightScale = 0.3f;
			
			int width=(int) (viewWidth*0.6f);
			int height=(int) (viewHeight*fHeightScale);
			x = viewWidth/2-width/2;
			y = viewHeight/2-height/2;
			Rectangle boundsMainClasses = new Rectangle(x,y,width,height);
			if (!changeBounds) {
				//public MenuWithClosable(String name, Rectangle srcBounds, MenuType menuType, Object owner, 
			    //	String[] namesButtons, Size cellSpacing, boolean selectable,
			    //	OnTouchListener listener)
				//this.menuMainClasses = new MenuWithClosable("MainClasses", boundsMainClasses, 
				//		MenuType.Vertical, owner, this.namesOfMenuMainClasses, new Size(3,3), true, this);
				
				/*this.menuMainClasses.buttons[6].selectable = false;	// MultiSelect 메뉴는 토글로 동작한다.
				this.menuMainClasses.buttons[6].toggleable = true;
				this.menuMainClasses.buttons[6].ColorSelected = Color.YELLOW;*/
				if (this.menuMainClasses!=null) return;
				
				this.menuMainClasses = new MainClassesList( boundsMainClasses, 
						new Size((int)(boundsMainClasses.width*0.75f), (int)(viewHeight*0.06f)));								
				this.menuMainClasses.setOnTouchListener(this);
			}
			else {
				this.menuMainClasses.changeBounds(boundsMainClasses);
			}
			
		}
		
		/**absFilename 디렉토리에서 main()함수를 포함하는 
		 * 클래스의 풀 패스 이름(Test.A, com.gsoft.common.texteditor14.MainActivity와 같은)을 리턴한다.
		 * 재귀적으로 하위 디렉토리에 있는 메인 클래스들을 찾는다.
		 * @param absFilename : 디렉토리 풀 경로 이름이여야 한다. janeSoft/project/Test/src/Test 디렉토리, 
	 * janeSoft/project/Test/output/Test 디렉토리 등이 될 수 있다.*/
		private void findMainClass(String absFilename, ArrayList r) {
						
			File absFile = new File(absFilename);
			if (absFile.isDirectory()) {
				ArrayList fileList = FileHelper.getFileList(absFilename, true);
				int i;
				//ArrayList r = new ArrayList(5);
				for (i=0; i<fileList.count; i++) {
					File file = (File) fileList.getItem(i);
					String classPath = file.getAbsolutePath();
									
					if (file.isDirectory()) {
						continue;
					}
					else {
						String filenameExt = FileHelper.getExt(classPath);
						if (!filenameExt.equals(".class")) continue;
											
						String fullName = Fullname.toFullname(1, classPath);
						// output에 있는 클래스 파일을 대상으로 main함수를 찾는다.
						// 다른 컴파일러로 만들어진 클래스 파일을 output에 넣어서 진입점으로 선택하여 jar파일이 만들어질수 있도록 한다.
						FindClassParams classParams = 
								Loader.loadClass_ClassLoader(CommonGUI.editText_compiler.getCompiler(), classPath, null, fullName, false, 0);
						//FindClassParams classParams = 
						//				Loader.loadClass(CommonGUI.editText_compiler.getCompiler(), fullName);
						if (classParams!=null) {
							this.findMainFunc(classParams, r);
						}
					}
				}
			}
			else {
				String filenameExt = FileHelper.getExt(absFilename);
				if (filenameExt.equals(".class")) {
					String fullName = Fullname.toFullname(1, absFilename);
					FindClassParams classParams = 
							Loader.loadClass_ClassLoader(CommonGUI.editText_compiler.getCompiler(), absFilename, null, fullName, false, 0);
					//FindClassParams classParams = 
					//				Loader.loadClass(CommonGUI.editText_compiler.getCompiler(), fullName);
					if (classParams!=null) {
						this.findMainFunc(classParams, r);
					}
				}
				else if (filenameExt.equals(".java")) {
					String fullName = Fullname.toFullname(2, absFilename);
					FindClassParams classParams = 
									Loader.loadClass(CommonGUI.editText_compiler.getCompiler(), fullName, 0);
					if (classParams!=null) {
						this.findMainFunc(classParams, r);
					}
				}
			}
			
			
		}
		
		/**Finds recursively. <br> 
		 *        C			<br>
		 *     C1       C2		<br>
		 *  C3   C4   C5		<br>
		 * @param classParams : 처음 호출시에는 most-top class가 된다.
		 * @param r : 결과 FindClassParams[]
		 */
		void findMainFunc(FindClassParams classParams, ArrayList r) {
			int j;
			// 자식 클래스부터 찾는다.
			ArrayListIReset listOfChildClasses = classParams.childClasses;
			if (listOfChildClasses!=null) {
				for (j=0; j<listOfChildClasses.count; j++) {
					FindClassParams child = (FindClassParams) listOfChildClasses.getItem(j);
					this.findMainFunc(child, r);
				}
			}
			
			ArrayListIReset listOfFuncs = classParams.listOfFunctionParams;
			for (j=0; j<listOfFuncs.count; j++) {
				FindFunctionParams func = (FindFunctionParams) listOfFuncs.getItem(j);
				if (func.name.equals("main")) {
					r.add(classParams);
					break;
				}
			}
		}

		@Override
		/** 사용자가 메인 함수를 포함하는 클래스들 중의 하나를 선택했을 때 호출된다.*/
		public void onTouchEvent(Object sender, MotionEvent e) {
			
			if (sender instanceof Button) {
				Button button = (Button) sender;
				this.menuMainClasses.open(false);
				
				CommonGUI.showMessage(true, "Making a jar file for "+button.text + " and running it on JVM...");
				
				//runAClassFile_sub2(button.text)
				
				
				// Run에서 사용자가 선택한 클래스에 대해서 jar파일을 만들고 그것을 run한다.
				// 또는 Run1에서 소스 파일 하나에 main 함수가 2개 이상있는 경우
				selectedClassName = button.text;
				Thread threadMakingJarAndRun = new ThreadRunningOrDebuggingAClassFile(mAbsFilename, button.text, this.runOrDebug);
				//threadMakingJarAndRun.setListener(this);
				
				threadMakingJarAndRun.start();
			}
		}
	}
	

	public static class ThreadRunningOrDebuggingAClassFile extends Thread {
		//private FileDialogEventHandler owner;
		/** menuMainClasses에서 사용자가 선택한 클래스 이름, entry point in a jar*/
		String selectedItem;
		
		/**Builder.buildAllAndRun_sub()에서 새로운 프로세스를 run 할 경우 
		 * ThreadRunningOrDebuggingAClassFile(console에 출력하는 스레드)를 종료하는 역할을 한다.*/
		public boolean haveToDisconnectWithOutputFile;
		
		private RunOrDebug runOrDebug;
		
		private long oldOutputFileLength_console = 0;
		private long oldErrorFileLength_console = 0;
		
		private long oldOutputFileLength_debug = 0;
		private long oldErrorFileLength_debug = 0;
		
		private long oldPosInoutputFile_debug = 0;

		private String mAbsFilename;
		
		
		
		/**메인함수를 찾는 스레드와 console에 출력하는 스레드
		 * @param mode : 0 = runAClassFile_sub(), 1=runAClassFile_sub2()
		 * @param selectedItem : 사용자가 선택한 클래스
		 * */
		public ThreadRunningOrDebuggingAClassFile(String mAbsFilename, String selectedItem, RunOrDebug runOrDebug) {
			this.selectedItem = selectedItem;
			this.runOrDebug = runOrDebug;
			this.mAbsFilename = mAbsFilename;
		}
		/** mode가 0이면 사용자가 선택한 mAbsFilename 디렉토리에서 main함수를 포함하는 클래스들을 찾아서
			menuMainClasses 메뉴를 만들고 그것을 사용자에게 보여준다. 
			mode가 1이면 ThreadRunningOrDebuggingAClassFile 스레드에서 사용자가 선택한 클래스 파일을 entry point로 만들고 
			jar파일로 만들어서 Console창에 결과를 출력하여 보여준다.*/
		public void run() {
			// ThreadRunningOrDebuggingAClassFile 스레드에서 사용자가 선택한 클래스 파일을 entry point로 만들고 
			// jar파일로 만들어서 Console창에 결과를 출력하여 보여준다.
			runAClassFile_sub2();
		}
		
		
		void copyClassFilesInJaneSoftLibsAndOtherLibsToOutput() {
			String srcFilePath;
			String dstFilePath = Common_Settings.pathOutput;
			
			srcFilePath = Common_Settings.pathAndroid + File.separator + "janesoft";
			FileHelper.copyFilesIfNotExists(srcFilePath, dstFilePath, true);
			
			int i, j;
			for (i=0; i<Common_Settings.listOfOtherLibs.count; i++) {
				String jarFilePath = Common_Settings.listOfOtherLibs.getItem(i);
				//String srcFileName = FileHelper.getFilename(srcFilePath);
				//srcFilePath += File.separator + srcFileName;
				String[] list = new File(jarFilePath).list();
				if (list!=null) {
					for (j=0; j<list.length; j++) {
						srcFilePath = jarFilePath+File.separator+list[j];
						if (new File(srcFilePath).isDirectory()) {
							FileHelper.copyFilesIfNotExists(srcFilePath, dstFilePath, true);
						}
					}
				}
			}
		}
		
		
		
		/** @param fullClassName : entry point of jar file*/
		void runAClassFile(String fullClassName) {
			String javaBinPath = copyJarExeOrJdbExeFromAssetToJDKOrJRE(false);
			if (javaBinPath==null) {
				CommonGUI.showMessage(true, "Your system doesn't have JDK. Install JDK");
				return;
			}
			
			
			String absFilename = Common_Settings.pathOutput;
			String dir = FileHelper.getDirectory(absFilename);
			String projectName = FileHelper.getFilename(dir);
			String jarFilename = projectName+".jar";
			
			// /sdcard/janeSoft/project/projectName/YYY.jar
			String janeSoftJarDir = Common_Settings.pathProject;
			File fileJarDir = new File(janeSoftJarDir);
			if (!fileJarDir.exists()) {
				// /sdcard/janeSoft/jar가 없으면 디렉토리를 생성한다.
				fileJarDir.mkdirs();
			}
			
			this.copyClassFilesInJaneSoftLibsAndOtherLibsToOutput();
			
			
			File jarFile = new File(janeSoftJarDir+File.separator+jarFilename);
			if (jarFile.exists()) {
				jarFile.delete();
				/*try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					
					if (Common_Settings.g_printsLog) e.printStackTrace();
				}*/
			}
			
		
			
			String entryPoint = fullClassName;
			
			
			String jarExe = null;
			if (File.separator.equals("\\")) {
				jarExe = javaBinPath+File.separator+"jar";
			}
			else {
				jarExe = "jar";
			}
			
			CommonGUI.showMessage(true, "Making "+jarFilename+"...");
			
			
			String[] command = {jarExe, "cfe", jarFile.getAbsolutePath(), entryPoint, "-C", absFilename, "./"};
			ProcessBuilder builder = new ProcessBuilder(command);
			
			if (ClassFileRunner.runFirst) {
				System.out.println(builder.command());
			}
			try {
				Process process = builder.start();
				// 결과가 나올때까지 기다린다.			
				//waitUntilFileCreate(jarFile, 50);
				
				try {
					process.waitFor();
					//Thread.sleep(3000);
				} catch (InterruptedException e) {
					
					e.printStackTrace();
				}
			} catch (IOException e3) {
				
				if (Common_Settings.g_printsLog) e3.printStackTrace();
			}
			
			
			// 메시지를 제거한다.
			//CommonGUI.loggingForMessageBox.setHides(true);
			
			
			
			if (this.runOrDebug==RunOrDebug.Run) {
				CommonGUI.textViewConsole.initialize();
				printToConsole(jarFile, javaBinPath);
			}
			else {
				CommonGUI.textViewConsole.initialize();
				CommonGUI.textViewDebug.initialize();
				printToConsole(jarFile, javaBinPath);
				printToDebugView(jarFile, javaBinPath);
				
			}
			
			
			
			
			//jarFile.setWritable(true);
			
			
			/*if (haveToCallEvent) {
				outputFile_console.delete();
				errorFile.delete();
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					
					if (Common_Settings.g_printsLog) e.printStackTrace();
				}
				this.listener.onEvent(this);
			}	*/
			
			/*
			if (javaProcess!=null) {
				javaProcess.destroy();
			}
			
			if (outputFile_console.exists()) {
				// 스레드마다 하나씩 생성한 콘솔출력을 위한 output 파일을 지운다.
				outputFile_console.delete();
			}*/
			
			/*while (true) {
				if (outputFile_console.exists()) {
					// 스레드마다 하나씩 생성한 콘솔출력을 위한 output 파일을 지운다.
					boolean del = outputFile_console.delete();
					if (del) break;
				}
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					
					e.printStackTrace();
				}
			}*/
			//outputFile_console.setWritable(false);
		}
		
		
		ByteBuffer putToBuffer(ByteBuffer buffer, String command) {
			int i;
			for (i=0; i<command.length(); i++) {
				buffer.putChar(command.charAt(i));
			}
			return buffer;
		}
		
	
		/** 명령줄이나 step으로 인해서 이동할 라인으로 커서와 vScrollPos, hScrollPos을 바꿔서
		 * 페이지를 바꾼다. 다른 소스파일에 있는 라인인 경우를 체크한다.
		 * @param lineNumber
		 */
		void moveToLineNumber(ResultOfGetLineNumberOfStep classNameAndLineNumber, boolean showsDebugLocation) {
			
			//FindClassParams classParams = 
			//		ClassCache.getFindClassParams(CompilerStatic.mlistOfAllClassesHashed, null, classNameAndLineNumber.fullClassName);
			if (classNameAndLineNumber.fullClassName.contains("FFFF")) {
				int a;
				a=0;
				a++;
			}
			/*FindClassParams classParams = 
					Loader.loadClass(CommonGUI.editText_compiler.getCompiler(), classNameAndLineNumber.fullClassName);
			
			// Step completed: "thread=main", java.lang.Thread.exit(), line=754 bci=0 을 만났을때
			// 클래스 캐시에 넣어지지 않은 java.lang.Thread 등
			if (classParams==null) return;*/
			
			FindClassParams classParams = 
					ClassCache.getFindClassParams(CompilerStatic.mlistOfAllClassesHashed[0], null, classNameAndLineNumber.fullClassName, 0);
			
			FindClassParams classInSrc = null;
			if (classParams!=null && classParams.loadWayOfFindClassParams==LoadWayOfFindClassParams.Start2) {				
				classInSrc = classParams;
			}
			else {
				String slashedFullname = classNameAndLineNumber.fullClassName.replace('.', File.separatorChar);
				File srcFile = CompilerStatic.getAbsPath_FromVariousClassPath(2, slashedFullname);
				if (srcFile!=null) {
					classInSrc = Builder.start2_usingCache(srcFile.getAbsolutePath(), classNameAndLineNumber.fullClassName, 0);
				}
			}
			//if (classInSrc!=null) {
				CommonGUI.editText_compiler.moveToLineNumber(classInSrc, classNameAndLineNumber.lineNumber, true, 
						classNameAndLineNumber.fullClassName, true);
			//}
		}
		
		/**디버그창에 출력한다. Debug시에만 호출한다. 
		 * jdb를 실행하여 디버그 명령을 입력받고 실행한다.*/
		void printToDebugView(File jarFile, String javaBinPath) {
			String javaExe = null;
			
			ProcessBuilder builder = null;
			if (File.separator.equals("\\")) {
				// windows
				javaExe = javaBinPath+File.separator+"jdb.exe";
				String[] command = {javaExe, "-attach", "jdbconn", "-sourcepath", Common_Settings.pathProjectSrc};
				builder = new ProcessBuilder(command);
			}
			else {
				// linux
				javaExe = "jdb";
				String[] command = {javaExe, "-attach", "32000", "-sourcepath", Common_Settings.pathProjectSrc};
				builder = new ProcessBuilder(command);
			} 
			
			if (ClassFileRunner.runFirst) {
				System.out.println(builder.command());
				ClassFileRunner.runFirst = false;
			}
			
			if (ClassFileRunner.oldThreadRunningDebugProcess!=null) {
				CommonGUI.showMessage(true, "Closing old debug and java processes...");
				
				//ClassFileRunner.killThread(ClassFileRunner.oldThreadRunningDebugProcess);
				ClassFileRunner.killOldThread();
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					
					e.printStackTrace();
				}
			}
			ClassFileRunner.oldThreadRunningDebugProcess = this;
			ClassFileRunner.listOfThreadsRunningDebugProcess.add(this);
			
			
			// 콘솔출력을 위한 output 파일, 스레드마다 하나씩 파일을 생성한다.
			String janeSoftJarDir = Common_Settings.pathConsoleInputAndError;
			File outputFile_debug = new File(janeSoftJarDir+File.separator+"Debug"/*+System.currentTimeMillis()*/);
			File errorFile_debug = new File(janeSoftJarDir+File.separator+"ErrorFile_Debug"/*+System.currentTimeMillis()*/);
			try {
				outputFile_debug.createNewFile();
				errorFile_debug.createNewFile();
			} catch (IOException e2) {
				if (Common_Settings.g_printsLog) e2.printStackTrace();
			}
			//outputFile_console.setWritable(true);
			
		
			Redirect toOutputFile_debug = Redirect.to(outputFile_debug);		
			builder.redirectOutput(toOutputFile_debug);
			Redirect toErrorFile_debug = Redirect.to(errorFile_debug);		
			builder.redirectError(toErrorFile_debug);
			
			
			String jarFilename = FileHelper.getFilename(jarFile.getAbsolutePath());
			//CommonGUI.showMessage(true, "Running "+jarFilename+"...", false);
			CommonGUI.showMessage(true, "Running "+"jdb"+"...");
						
			
			Process debugProcess = null;
			try {				
				debugProcess = builder.start();				
				ClassFileRunner.listOfDebugProcesses.add(debugProcess);
				
			} catch (IOException e1) {
				
				if (Common_Settings.g_printsLog) e1.printStackTrace();
			}
			
			// 결과가 나올때까지 기다린다.
			waitUntilFileCreate(outputFile_debug, 20);
			
			/*FileDialog fileDialog = owner.owner;
			fileDialog.createAndSetFileListButtons(fileDialog.getCurDir(), fileDialog.category);
			
			fileDialog.fileListOfMultiSelect.destroy();
			fileDialog.filename = null;
			fileDialog.mAbsFilename = null;
			
			// createAndSetFileListButtons() 호출 이후 파일 리스트 버튼마다 토글 상태를 다시 설정한다.
			if (fileDialog.menuFunc.buttons[6].getIsSelected()) {
        		fileDialog.state = com.gsoft.common.gui.FileDialog.State.MultiSelect;
            	fileDialog.enableMultiSelect(true, true);
        	}
        	else {
        		fileDialog.state = com.gsoft.common.gui.FileDialog.State.Normal;
        		fileDialog.enableMultiSelect(false, true);
        	}*/
			
			Thread_printToDebugView thread = new Thread_printToDebugView(this, outputFile_debug, errorFile_debug, debugProcess, jarFile);
			thread.start();
		}
		
		/**DebugView에 디버그 내용을 출력하는 스레드*/
		static class Thread_printToDebugView extends Thread {
			ThreadRunningOrDebuggingAClassFile owner;
			private File outputFile_debug;
			private File errorFile_debug;
			private Process debugProcess;
			private File jarFile;
			
			/**@param debugProcess : jdb 프로세스*/
			Thread_printToDebugView(ThreadRunningOrDebuggingAClassFile owner, 
					File outputFile_debug, File errorFile_debug, Process debugProcess, File jarFile) {
				this.owner = owner;
				this.outputFile_debug = outputFile_debug;
				this.errorFile_debug = errorFile_debug;
				this.debugProcess = debugProcess;
				this.jarFile = jarFile;
				
			}
			public void run() {
				owner.printToDebugView_sub(outputFile_debug, errorFile_debug, debugProcess, jarFile);
			}
		}
		
		/**디버그창에 출력한다. Debug시에만 호출한다. 
		 * jdb를 실행하여 디버그 명령을 입력받고 실행한다.
		 * 스레드가 끝날때 jdb 프로세스를 종료시키고 output파일과 에러 파일을 삭제한다.
		 * @param debugProcess : jdb 프로세스
		 * @param jarFile : 디버그할 jar 파일*/
		void printToDebugView_sub(File outputFile_debug, File errorFile_debug, Process debugProcess, File jarFile) {
			boolean mainThreadExited = false;
			boolean applicationExited = false;
			
			OutputStream os = debugProcess.getOutputStream();
			try {
				int r;
							
				// run이 입력되고 난 후 루프를 돌면서 디버그창에 출력하고 디버그 명령을 입력받아 실행한다.
				while (true) {
				
					if (this.haveToDisconnectWithOutputFile) {
						break;
					}
					
					if (!outputFile_debug.exists()) return;
					if (!errorFile_debug.exists()) return;
							
					try {						
						
						// 디버그 명령을 입력받는다. waiting for event, such as keyboard or mouse
						while (ClassFileRunner.debugCommand.equals("") && !haveToDisconnectWithOutputFile) {
							try {
								ResultOfGetLineNumberOfStep classNameAndLineNumber = this.getLineNumberOfStep(outputFile_debug);
								if (classNameAndLineNumber!=null && classNameAndLineNumber.lineNumber!=-1) {
									moveToLineNumber(classNameAndLineNumber, true);
									r = printToDebugView_sub(outputFile_debug, errorFile_debug);
									if (r==1) {
										mainThreadExited = true;
										return;
									}
									else if (r==2) {
										applicationExited = true;
										CommonGUI.editText_compiler.toJava();
									}
									break;
								}
								Thread.sleep(500);
							} catch (InterruptedException e) {
								
								break;
							}
						}//while (ClassFileRunner.debugCommand.equals("") && !haveToDisconnectWithOutputFile) {
						
						if (haveToDisconnectWithOutputFile) break;
						
						// 디버그 명령을 실행한다.
						if (!ClassFileRunner.debugCommand.equals("")) {
							try {
								IO.writeString(os, ClassFileRunner.debugCommand, TextFormat.UTF_8, false, true);
							}catch(Exception e) {
								break;
							}
							
							try {
								Thread.sleep(2000);
							}catch (Exception e) {
								break;
							}
							
							r = printToDebugView_sub(outputFile_debug, errorFile_debug);
							if (r==2) {
								applicationExited = true;
								CommonGUI.editText_compiler.toJava();
							}
														
							ClassFileRunner.debugCommand = "";
						}
					
					}catch (Exception e) {
						if (Common_Settings.g_printsLog) e.printStackTrace();
						break;
					}
			
					
					
				}// while
			}
			finally {		
				
				// 마지막으로 한번더 출력한다.
				int r = printToDebugView_sub(outputFile_debug, errorFile_debug);
				if (r==2) {
					applicationExited = true;
					CommonGUI.editText_compiler.toJava();
				}
				
				if (debugProcess!=null) {
					//debugProcess.destroy();
					try {
						debugProcess.getErrorStream().close();
						debugProcess.getInputStream().close();
						debugProcess.getOutputStream().close();
					} catch (IOException e1) {
						
						//e1.printStackTrace();
					}
					try {
						Thread.sleep(500);
					} catch (InterruptedException e) {
						
						e.printStackTrace();
					}
				}
				
				/*if (outputFile_debug.exists()) {
					// 스레드마다 하나씩 생성한 콘솔출력을 위한 output 파일을 지운다.
					outputFile_debug.delete();
				}
				if (errorFile_debug.exists()) {
					// 스레드마다 하나씩 생성한 에러출력을 위한 error 파일을 지운다.
					errorFile_debug.delete();
				}*/
			}
		
		}
		
		static class ResultOfGetLineNumberOfStep {
			String fullClassName;
			int lineNumber;
			
			ResultOfGetLineNumberOfStep(String fullClassName, int lineNumber) {
				this.fullClassName = fullClassName;
				this.lineNumber = lineNumber;
			}
			public void destroy() {
				this.fullClassName = null;
			}
		}
		
		ResultOfGetLineNumberOfStep getLineNumberOfStep(File outputFile_debug) {
			ReturnOfReadString r_outputFile = null;
			
			r_outputFile = IO.readStringUTF8(outputFile_debug.getAbsolutePath(), oldPosInoutputFile_debug);
			HighArray_char output = r_outputFile.result;
			int i, j;
			
			boolean found = false;
			if (output.count<=0) {
				if (r_outputFile!=null) {					
					r_outputFile.destroy();
				}
				return null;	
			}
			
			ArrayListChar arrChar = new ArrayListChar(5); 
			for (i=output.count-1; i>=0; i--) {
				if (i-4>=0 && 
						(output.charAt(i-4)=='l' && output.charAt(i-3)=='i' && output.charAt(i-2)=='n' && output.charAt(i-1)=='e' &&
						output.charAt(i)=='=')) {
					for (j=i+1; j<output.count; j++) {
						char c = output.charAt(j); 
						if (c!=' ') {
							arrChar.add(c);
						}
						else {
							found = true;
							break;
						}
					}
					if (found) {
						break;
					}
				}
			}			
			this.oldPosInoutputFile_debug = outputFile_debug.length();
			
			if (!found) {
				if (r_outputFile!=null) {					
					r_outputFile.destroy();
				}
				arrChar.destroy();
				return null;
			}
			
			int lineNumber = Number.parseIntAfterErasingComma(arrChar);
			if (lineNumber==-1) {
				if (r_outputFile!=null) {
					r_outputFile.destroy();
				}
				arrChar.destroy();
				return null;
			}
			
			//"thread=main", TestForDistribution.A.main(), line=16에서 i는 =을 가리킨다. i-7은 )을 가리킨다.
			int endIndexOfLineLocation = i-7;
			for (i=endIndexOfLineLocation; i>=0; i--) {
				if (output.charAt(i)==',') break;
			}
			int startIndexOfLineLocation = i+2;
			String lineFunc = output.substring(startIndexOfLineLocation, endIndexOfLineLocation+1);
			
			// TestForDistribution.A.main()에서 TestForDistribution.A을 찾는다.
			String fullClassName = FileHelper.getFilenameExceptExt(lineFunc);
			fullClassName = fullClassName.replace('$', '.');
			
			
			if (r_outputFile!=null) {
				r_outputFile.destroy();
			}
			arrChar.destroy();
			
			return new ResultOfGetLineNumberOfStep(fullClassName, lineNumber);
		}
		
		/**DebugView에서 The application exited이 출력되었으면 2을 리턴하고
		 * 해당없으면 0을 리턴한다.*/
		int debugExited(HighArray_char debugResult) {
			int i;
			for (i=debugResult.count-1; i>=0; i--) {
				if (i-21>=0 && 
						debugResult.charAt(i-21)=='T' && debugResult.charAt(i-20)=='h' && debugResult.charAt(i-19)=='e' && debugResult.charAt(i-18)==' ' &&
						debugResult.charAt(i-17)=='a' && debugResult.charAt(i-16)=='p' && debugResult.charAt(i-15)=='p' && debugResult.charAt(i-14)=='l' && debugResult.charAt(i-13)=='i' && debugResult.charAt(i-12)=='c' && debugResult.charAt(i-11)=='a' && debugResult.charAt(i-10)=='t' && debugResult.charAt(i-9)=='i' && debugResult.charAt(i-8)=='o' && debugResult.charAt(i-7)=='n' && debugResult.charAt(i-6)==' ' && 
						debugResult.charAt(i-5)=='e' && debugResult.charAt(i-4)=='x' && debugResult.charAt(i-3)=='i' && debugResult.charAt(i-2)=='t' && debugResult.charAt(i-1)=='e' && debugResult.charAt(i)=='d'
					) {
					return 2;
				}
			}
			return 0;
		}
		
		
		/**디버그창에 출력한다. Debug시에만 호출한다.
		 * @return : 1(메인스레드가 종료), 2(애플리케이션 종료), 0(보통일때)*/
		int printToDebugView_sub(File outputFile_debug, File errorFile_debug) {
			ReturnOfReadString r_outputFile = null, r_errorFile = null;
			boolean mainThreadExited = false;
			boolean debugExited = false;
			
			// 디버그 파일의 길이가 바뀔 때에만 디버그창에 출력한다.
			if (oldOutputFileLength_debug==outputFile_debug.length() && 
					oldErrorFileLength_debug==errorFile_debug.length()) return 0;
			
			
			
			//r_outputFile = IO.readString(outputFile_debug.getAbsolutePath());
			r_outputFile = IO.readStringUTF8(outputFile_debug.getAbsolutePath(), oldOutputFileLength_debug);
			r_errorFile = IO.readString(errorFile_debug.getAbsolutePath());
			
			oldOutputFileLength_debug = outputFile_debug.length(); 
			oldErrorFileLength_debug = errorFile_debug.length();
			
			
			ReturnOfReadString r = null;
			if (r_outputFile!=null && r_outputFile.result!=null && !r_outputFile.result.equals("")) {
				// 콘솔 출력이 있으면
				if (r_errorFile!=null && r_errorFile.result!=null && !r_errorFile.result.equals("")) {
					HighArray_char result = r_outputFile.result.concat(r_errorFile.result);
					r  = r_outputFile;
					r.result = result;					
				}
				else {
					r = r_outputFile;					
				}
				
				int exited = debugExited(r_outputFile.result);
				if (exited==1) {
					mainThreadExited = true;
				}
				if (exited==2) {
					debugExited = true;
				}
			}
			else {
				if (r_errorFile!=null && r_errorFile.result!=null && !r_errorFile.result.equals("")) {
					r = r_errorFile;
				}
				else {
					r = null;
				}
			}			
			
			
			if (r!=null) {
				CommonGUI.loggingForMessageBox.setHides(true);
				
				int oldNumOfLines = CommonGUI.textViewDebug.numOfLines-1;
				// Prints only update
				if (CommonGUI.textViewDebug.textArray[oldNumOfLines]==null) {
					CommonGUI.textViewDebug.textArray[oldNumOfLines] = new CodeString("", Common_Settings.textColor);
				}
				CodeString lastLine = CommonGUI.textViewDebug.textArray[oldNumOfLines];
				CodeString updateLines = new CodeString(r.result, Common_Settings.textColor);
				updateLines = lastLine.concate(updateLines);
				
				CommonGUI.textViewDebug.setTextMultiLineBoth(oldNumOfLines, updateLines, 1);
				
				for (int k=oldNumOfLines; k<CommonGUI.textViewDebug.numOfLines; k++) {
					int lastIndex = CommonGUI.textViewDebug.isArray(k); 
					if (lastIndex!=-1) {
						int numOfLinesAdded = CommonGUI.textViewDebug.inputSubscriptionToArray(k, lastIndex);
						k += numOfLinesAdded - 1;
					}
				}
				CommonGUI.textViewDebug.setVScrollPos();
				CommonGUI.textViewDebug.setHScrollPos();
				CommonGUI.textViewDebug.setVScrollBar();			
				CommonGUI.textViewDebug.setHScrollBar();
				
				CommonGUI.textViewDebug.vScrollPosToLastPage();
				CommonGUI.textViewDebug.setHides(false);
				
				Control.view.postInvalidate();
			}// if (r!=null) {
			
			if (r_outputFile!=null) {
				r_outputFile.destroy();
			}
			if (r_errorFile!=null) {
				r_errorFile.destroy();
			}
			if (r!=null) {
				r.destroy();
			}
			
			if (mainThreadExited) return 1;
			if (debugExited) return 2;
			return 0;
		}
		
		/**콘솔창에 출력한다. Run과 Debug시에 모두 호출한다.
		 * java를 실행한다.*/
		@SuppressWarnings("unchecked")
		void printToConsole(File jarFile, String javaBinPath) {
			String javaExe = null;
						
			ProcessBuilder builder = null;
			if (this.runOrDebug==RunOrDebug.Run) {
				if (File.separator.equals("\\")) {
					javaExe = javaBinPath+File.separator+"java.exe";
				}
				else {
					javaExe = "java";
				}
				String[] command = {javaExe, "-jar", jarFile.getAbsolutePath()/*, "-classpath", Common_Settings.pathAndroid_Final*/};
				
				builder = new ProcessBuilder(command);
			}
			else {
				if (File.separator.equals("\\")) {
					// windows
					javaExe = javaBinPath+File.separator+"java.exe";
					String[] command = {javaExe, "-agentlib:jdwp=transport=dt_shmem,address=jdbconn,server=y,suspend=y", 
							"-jar", jarFile.getAbsolutePath()};
					builder = new ProcessBuilder(command);
				}
				else {
					// linux
					javaExe = "java";
					String[] command = {javaExe, "-agentlib:jdwp=transport=dt_socket,address=32000,server=y,suspend=y", 
							"-jar", jarFile.getAbsolutePath()};
					builder = new ProcessBuilder(command);
				}				
			}
			
			// Gives Common_Settings.pathProject to user process
			@SuppressWarnings("rawtypes")
			Map map = builder.environment();
			map.put("user.dir", Common_Settings.pathProject);
			
			// Set user.dir of user process to Common_Settings.pathProject
			// In user process, call of System.getProperty("user.dir") returns Common_Settings.pathProject.
			builder.directory(new File(Common_Settings.pathProject));
			
			if (ClassFileRunner.runFirst) {
				System.out.println(builder.command());
				ClassFileRunner.runFirst = false;
			}
			
			if (ClassFileRunner.oldThreadRunningJavaProcess!=null) {
				CommonGUI.showMessage(true, "Closing streams of an old java process...");
				
				//ClassFileRunner.killThread(ClassFileRunner.oldThreadRunningJavaProcess);
				ClassFileRunner.killOldThread();
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					
					e.printStackTrace();
				}
			}
			ClassFileRunner.oldThreadRunningJavaProcess = this;
			ClassFileRunner.listOfThreadsRunningJavaProcess.add(this);
			
			
			// 콘솔출력을 위한 output 파일, 스레드마다 하나씩 파일을 생성한다.
			String janeSoftJarDir = Common_Settings.pathConsoleInputAndError;
			File outputFile_console = new File(janeSoftJarDir+File.separator+"Console"/*+System.currentTimeMillis()*/);
			File errorFile_console = new File(janeSoftJarDir+File.separator+"ErrorFile_Console"/*+System.currentTimeMillis()*/);
			//File inputFile = new File(janeSoftJarDir+File.separator+"Input"/*+System.currentTimeMillis()*/);
			try {
				outputFile_console.createNewFile();
				errorFile_console.createNewFile();
				//inputFile.createNewFile();
			} catch (IOException e2) {
				if (Common_Settings.g_printsLog) e2.printStackTrace();
			}
			//outputFile_console.setWritable(true);
			
		
			
			Redirect toOutputFile = Redirect.to(outputFile_console);
			Redirect toErrorFile = Redirect.to(errorFile_console);
			builder.redirectOutput(toOutputFile);
			builder.redirectError(toErrorFile);
			//builder.redirectInput(inputFile);
					
			String jarFilename = FileHelper.getFilename(jarFile.getAbsolutePath());
			CommonGUI.showMessage(true, "Running "+jarFilename+" on JVM...");
						
			Process javaProcess = null;
			try {				
				javaProcess = builder.start();				
				ClassFileRunner.listOfJavaProcesses.add(javaProcess);
				
			} catch (IOException e1) {
				
				if (Common_Settings.g_printsLog) e1.printStackTrace();
			}
			
			// 결과가 나올때까지 기다린다.
			waitUntilFileCreate(outputFile_console, 20);
			
			/*FileDialog fileDialog = owner.owner;
			fileDialog.createAndSetFileListButtons(fileDialog.getCurDir(), fileDialog.category);
			
			fileDialog.fileListOfMultiSelect.destroy();
			fileDialog.filename = null;
			fileDialog.mAbsFilename = null;
			
			// createAndSetFileListButtons() 호출 이후 파일 리스트 버튼마다 토글 상태를 다시 설정한다.
			if (fileDialog.menuFunc.buttons[6].getIsSelected()) {
        		fileDialog.state = com.gsoft.common.gui.FileDialog.State.MultiSelect;
            	fileDialog.enableMultiSelect(true, true);
        	}
        	else {
        		fileDialog.state = com.gsoft.common.gui.FileDialog.State.Normal;
        		fileDialog.enableMultiSelect(false, true);
        	}*/
			
			Thread_printToConsole thread = new Thread_printToConsole(this, outputFile_console, errorFile_console, javaProcess);
			thread.start();
		}
		
		/**Console에 자바 프로세스의 System.out을 출력하는 스레드*/
		static class Thread_printToConsole extends Thread {
			ThreadRunningOrDebuggingAClassFile owner;
			private File outputFile_console;
			private File errorFile_console;
			private Process javaProcess;
			
			
			Thread_printToConsole(ThreadRunningOrDebuggingAClassFile owner, 
					File outputFile_console, File errorFile_console, Process javaProcess) {
				this.owner = owner;
				this.outputFile_console = outputFile_console;
				this.errorFile_console = errorFile_console;
				this.javaProcess = javaProcess;
				
			}
			public void run() {
				owner.printToConsole_sub(outputFile_console, errorFile_console, javaProcess);
			}
		}
		
		
		
		/**콘솔창에 출력한다. Run과 Debug시에 모두 호출한다.
		 * java를 실행한다.
		 * 스레드가 끝날때 자바 프로세스를 종료시키고 output파일과 에러 파일을 삭제한다.*/
		void printToConsole_sub(File outputFile_console, File errorFile_console, Process javaProcess) {
			try {
				ReturnOfReadString r_outputFile = null, r_errorFile = null;
				
				//CommonGUI.showMessage(true, "Waiting for printing "+jarFilename+"...", false);
				
				// outputFile과 끊길때까지 계속 루프를 돌면서 output 파일 내용을 콘솔에 출력한다.
				while (true) {
					
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e1) {
						
						if (Common_Settings.g_printsLog) e1.printStackTrace();
					}
					
					if (this.haveToDisconnectWithOutputFile) {
						break;
					}
					
					if (!outputFile_console.exists()) return;
					if (!errorFile_console.exists()) return;
					
					// 콘솔 파일의 길이가 바뀔 때에만 콘솔창에 출력한다.
					if (oldOutputFileLength_console==outputFile_console.length() && 
							oldErrorFileLength_console==errorFile_console.length()) continue;
					
					// Reads only update					
					r_outputFile = IO.readStringUTF8(outputFile_console.getAbsolutePath(), oldOutputFileLength_console);
					r_errorFile = IO.readString(errorFile_console.getAbsolutePath());
					
					oldOutputFileLength_console = outputFile_console.length(); 
					oldErrorFileLength_console = errorFile_console.length();
					
					if (r_outputFile==null) continue;
					if (r_errorFile==null) continue;
					
					ReturnOfReadString r = null;
					if (r_outputFile!=null && r_outputFile.result!=null && !r_outputFile.result.equals("")) {
						// 콘솔 출력이 있으면
						if (r_errorFile!=null && r_errorFile.result!=null && !r_errorFile.result.equals("")) {
							HighArray_char result = r_outputFile.result.concat(r_errorFile.result);
							r  = r_outputFile;
							r.result = result;
						}
						else {
							r = r_outputFile;
						}
					}
					else {
						if (r_errorFile!=null && r_errorFile.result!=null && !r_errorFile.result.equals("")) {
							r = r_errorFile;
						}
						else {
							r = null;
						}
					}
					
					if (r!=null) {
						CommonGUI.loggingForMessageBox.setHides(true);
						
						//CommonGUI.textViewConsole.setText(CommonGUI.textViewConsole.numOfLines-1, updateLines);
						
						// Prints only update
						int oldNumOfLines = CommonGUI.textViewConsole.numOfLines-1;
						if (CommonGUI.textViewConsole.textArray[oldNumOfLines]==null) {
							CommonGUI.textViewConsole.textArray[oldNumOfLines] = new CodeString("", Common_Settings.textColor);
						}
						CodeString lastLine = CommonGUI.textViewConsole.textArray[oldNumOfLines];
						CodeString updateLines = new CodeString(r.result, Common_Settings.textColor);
						updateLines = lastLine.concate(updateLines);
						
						CommonGUI.textViewConsole.setTextMultiLineBoth(oldNumOfLines, updateLines, 1);
						
						CommonGUI.textViewConsole.setVScrollPos();
						CommonGUI.textViewConsole.setHScrollPos();
						CommonGUI.textViewConsole.setVScrollBar();			
						CommonGUI.textViewConsole.setHScrollBar();
						
						CommonGUI.textViewConsole.vScrollPosToLastPage();
						CommonGUI.textViewConsole.setHides(false);
						
						Control.view.postInvalidate();
					}// if (r!=null) {
					
				
				}// while
			}
			finally {
				if (javaProcess!=null) {
					//javaProcess.destroy();
					try {
						javaProcess.getErrorStream().close();
						javaProcess.getInputStream().close();
						javaProcess.getOutputStream().close();
					} catch (IOException e1) {
						
						e1.printStackTrace();
					}
					
					try {
						Thread.sleep(500);
					} catch (InterruptedException e) {
						
						e.printStackTrace();
					}
				}
				
				/*if (outputFile_console.exists()) {
					// 스레드마다 하나씩 생성한 콘솔출력을 위한 output 파일을 지운다.
					outputFile_console.delete();
				}
				if (errorFile_console.exists()) {
					// 스레드마다 하나씩 생성한 에러출력을 위한 error 파일을 지운다.
					errorFile_console.delete();
				}*/
			}
		}
		
		/**ThreadRunningOrDebuggingAClassFile 스레드에서 사용자가 선택한 클래스 파일을 entry point로 만들고 
		 * jar파일로 만들어서 Console창에 결과를 출력하여 보여준다.*/
		void runAClassFile_sub2() {
			runAClassFile(this.selectedItem);
			
		}
		
		/** r의 스트링이 Error: Invalid or corrupt jarfile을 포함하는지를 확인하여 포함하면 true, 
		 * 그렇지 않으면 false를 리턴한다.*/
		public static boolean checkConsoleError(ReturnOfReadString r) {
			//ReturnOfReadString r = IO.readString(errorFile.getAbsolutePath());
			int i;
			HighArray_char result = r.result;
			String[] checkMessage = {"Error: Invalid or corrupt jarfile", "오류"};
			
			int[] lenOfcheckMessage = {checkMessage[0].length(), checkMessage[1].length()};
			int j;
			for (j=0; j<checkMessage.length; j++) {
				for (i=0; i<result.count && i<lenOfcheckMessage[j]; i++) {
					if (result.charAt(i)!=checkMessage[j].charAt(i)) {
						// 다음 checkMessage를 확인한다.
						break;
					}
				}
				if (i==lenOfcheckMessage[j]) {
					return true;
				}
			}
			return false;
		}
		
		
		

      void setJavaHomePath() {
      }
		
		/** path 환경변수로부터 jdk나 jre의 bin을 얻는다.*/
		String getJavaPathFromPath(String path, boolean includesJRE) {
			int indexJava = path.toLowerCase().indexOf("java");
			if (indexJava==-1) {
				return null;
			}
			
			int startIndex=-1, endIndex=-1;
			int i;
			for (i=indexJava-1; i>=0; i--) {
				if (path.charAt(i)==';') {
					startIndex = i+1;
					break;
				}
			}
			for (i=indexJava+1; i<path.length(); i++) {
				if (path.charAt(i)==';') {
					endIndex = i-1;
					break;
				}
			}
			
			String r = null;
			if (startIndex!=-1 && endIndex!=-1) {
				r = path.substring(startIndex, endIndex+1);
				if (r.charAt(r.length()-1)==File.separatorChar) {
					r = r.substring(0, r.length()-1);
				}
				String filename = FileHelper.getFilename(r);
				if (filename.contains("jdk") || (includesJRE && filename.contains("jre"))) {
					if (!filename.equals("bin")) {
						r = r + File.separator + "bin";
					}
				}
			}
			return r;
		}
		
		
		
		
		/** assets의 lib에 있는 jar.exe를 jar.exe이 없는(jdb.exe를 jdb.exe이 없는) 사용자 컴퓨터의 jdk나 jre로 copy한다.
		 * 그리고 FileHelper.getJavaBinPath(includesJRE)을 실행한 후 Common_Settings.pathJavaBin을 설정한다.*/
		String copyJarExeOrJdbExeFromAssetToJDKOrJRE(boolean includesJRE) {
			String javaHomePath = null;
			String javaPath = null;
			String pathEnv = null;
			
			if (Common_Settings.pathJavaBin!=null && new File(Common_Settings.pathJavaBin).exists()) {
				javaHomePath = FileHelper.getDirectory(Common_Settings.pathJavaBin);
			}
			else {
				javaHomePath = System.getProperty("java.home");
				if (javaHomePath.contains("bin")) {
					javaHomePath = FileHelper.getDirectory(javaHomePath);
				}
				pathEnv = System.getenv("path");
			}
			
			
			if (javaHomePath!=null) {
				String lowerCaseJavaHomePath = javaHomePath.toLowerCase();
				if (!includesJRE) {
					if (lowerCaseJavaHomePath.contains("jre")) {
						String JDKPath = FileHelper.getDirectory(javaHomePath);
						javaPath = FileHelper.jdbExists(JDKPath);
						if (javaPath!=null) {
							javaHomePath = JDKPath;
						}
					}
					else {
						if (lowerCaseJavaHomePath.contains("jdk")) {
							javaPath = FileHelper.jdbExists(javaHomePath);
						}
					}
				}
				
				if (!(!includesJRE && lowerCaseJavaHomePath.contains("jre"))) {
					// includesJRE이 false이고 jre를 포함하면 javaPath는 null이 된다.
					if (javaHomePath.charAt(javaHomePath.length()-1)==File.separatorChar) {
						javaPath = javaHomePath + "bin";
					}
					else {
						javaPath = javaHomePath + File.separator + "bin";
					}
				}
				else {
					
				}
			}
			else {
				if (pathEnv==null) return javaPath;
				javaPath = this.getJavaPathFromPath(pathEnv, includesJRE);
				if (javaPath!=null) {
					javaHomePath = FileHelper.getDirectory(javaPath);
					if (javaPath!=null && javaPath.toLowerCase().contains("oracle")) {
						javaPath = null;
						javaHomePath = null;
					}
				}
			}
			
			if (javaPath==null) {
				CommonGUI.showMessage(true, "Finding the JDK...");
				
				String javaBinPath = FileHelper.getJavaBinPath(includesJRE);
				if (javaBinPath!=null) {
					Common_Settings.pathJavaBin = javaBinPath;
				}
				if (javaBinPath==null) return null;
				javaHomePath = FileHelper.getDirectory(javaBinPath);
				System.setProperty("java.home", javaHomePath);
				//System.setProperty("", javaBinPath);
				javaPath = javaBinPath;
				
			}
						
			
			File javaDir = new File(javaPath);
			if (!javaDir.exists()) return javaPath;
			
			if (javaPath.charAt(javaPath.length()-1)==File.separatorChar) {
				javaPath = javaPath.substring(0, javaPath.length()-1);
			}
			
			if (ClassFileRunner.runFirst) {
				System.out.println("JAVA_HOME="+javaHomePath);
				System.out.println("JAVA_PATH="+javaPath);				
			}
			
			
			byte[] buffer = new byte[1000];			
			
			// jar.exe를 이미 갖고 있으면 리턴
			File jarFile = null;
			if (javaHomePath==null) {
				jarFile = new File(javaPath+File.separator+"jar.exe");
			}
			else {
				jarFile = new File(javaHomePath+File.separator+"bin"+File.separator+"jar.exe");
			}
			if (File.separator.equals("/")) {
				// 리눅스에서는 exe 확장자를 뺀다
				jarFile = new File(FileHelper.getFilenameExceptExt(jarFile.getAbsolutePath()));
			}
			
			Context context = Control.activity.getApplicationContext();
			File filesDir = context.getFilesDir();
			String assetPath = FileHelper.getDirectory(filesDir.getAbsolutePath());
			
			if (!jarFile.exists()) {
				String srcFilePath = null;
				if (File.separator.equals("\\")) {
					srcFilePath = assetPath+File.separator + "lib"+File.separator+"Windows"+File.separator+"jar.exe";
				}
				else {
					// 리눅스에서는 exe 확장자를 뺀다
					srcFilePath = assetPath+File.separator + "lib"+File.separator+"Linux"+File.separator+"jar";
				}
				String destFilePath = jarFile.getAbsolutePath();
				try {
					FileHelper.move(buffer, srcFilePath, destFilePath);
				} catch (IOException e1) {
					
					e1.printStackTrace();
				}
			}
			
			
			File jdbFile = null;
			if (javaHomePath==null) {
				jdbFile = new File(javaPath+File.separator+"jdb.exe");
			}
			else {
				jdbFile = new File(javaHomePath+File.separator+"bin"+File.separator+"jdb.exe");
			}
			if (File.separator.equals("/")) {
				// 리눅스에서는 exe 확장자를 뺀다
				jdbFile = new File(FileHelper.getFilenameExceptExt(jdbFile.getAbsolutePath()));
			}
			
			if (!jdbFile.exists()) {
				String srcFilePath = null;
				if (File.separator.equals("\\")) {
					srcFilePath = assetPath+File.separator + "lib"+File.separator+"Windows"+File.separator+"jdb.exe";
				}
				else {
					// 리눅스에서는 exe 확장자를 뺀다
					srcFilePath = assetPath+File.separator + "lib"+File.separator+"Linux"+File.separator+"jdb";
				}
				String destFilePath = jdbFile.getAbsolutePath();
				try {
					FileHelper.move(buffer, srcFilePath, destFilePath);
				} catch (IOException e1) {
					
					e1.printStackTrace();
				}
			}
			
			return javaPath;
		}
		
		
		
		/**file이 생성될때까지 기다린다.
		 * @param loopCount = 최대 500(ms)*loopCount 만큼 기다리게 된다.*/
		void waitUntilFileCreate(File file, int loopCount) {
			int count = 0;
			while (true) {
				long length = file.length(); 
				if (length>0) break;
				if (count>loopCount) break;
				try {					
					Thread.sleep(500);
					count++;
				} catch (InterruptedException e) {
					
				}
			}
		}
		
		
		
		
		/*
		public void setListener(Listener listener) {
			
			this.listener = listener;
		}
		
		@Override
		public void onEvent(Object sender) {
			
			// 사용자가 선택한 클래스에 대해서 jar파일을 만들고 그것을 run한다.
			if (threadMakingJarAndRun!=null && threadMakingJarAndRun.isAlive()) {
				threadMakingJarAndRun.haveToDisconnectWithOutputFile = true;
				
			}
			threadMakingJarAndRun = new ThreadRunningOrDebuggingAClassFile(owner, (byte)1, selectedClassName);
			threadMakingJarAndRun.setListener(this);
			
			threadMakingJarAndRun.start();
		}*/
		
		
		
	}
	
}
