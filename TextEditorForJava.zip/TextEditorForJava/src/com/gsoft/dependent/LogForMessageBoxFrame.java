package com.gsoft.dependent;

import java.awt.Graphics;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.awt.image.BufferedImage;

import javax.swing.JFrame;

import android.graphics.Canvas;

import com.gsoft.common.CommonGUI;
import com.gsoft.common.Sizing.Rectangle;
import com.gsoft.common.gui.Control;
import com.gsoft.common.gui.LoggingScrollable;

@SuppressWarnings("serial")
public class LogForMessageBoxFrame extends JFrame  implements WindowListener {
	Rectangle bounds;
	
	//public boolean hides = true;
	
	/**If true, draw by thread, If not, draw by drawNotThread()*/
	public boolean drawByThread = false;
	
	private ThreadDraw threadDraw;
	public Integer lockObject = new Integer(1);
	public boolean mImage2Changed;
	
	Graphics g;
	Canvas mCanvas2;
	BufferedImage mImage2;

	LoggingScrollable owner;
	
	public LogForMessageBoxFrame(LoggingScrollable owner) {
		this.owner = owner;
		this.setUndecorated(true);
		this.setAlwaysOnTop(false);
		this.setFocusable(false);
		this.setResizable(false);
	}
	
	public void setBounds2(Rectangle bounds) {
		this.bounds = bounds;
		
		int screenX = Control.view.getLocation().x;
		int screenY = Control.view.getLocation().y;
		
		this.setBounds(screenX+bounds.x, screenY+bounds.y, bounds.width, bounds.height);
		
		
		
		this.createBufferedImageAndCanvas(bounds.width, bounds.height);
		
		if (this.drawByThread) {
			startDrawThread();
		}
	}
	
	void createBufferedImageAndCanvas(int width, int height) {
		// 더블 버퍼링
		//if (mImage2!=null) return;
		
		mImage2 = new BufferedImage(width, height, BufferedImage.TYPE_3BYTE_BGR); 
		Graphics gForImage = mImage2.getGraphics();
		//Paint.g = gForImage;
		mCanvas2 = new Canvas(gForImage);
	}
	
	
	
	
	public void startDrawThread() {
		
		if (threadDraw==null) {
			threadDraw = new ThreadDraw(this);
			threadDraw.start();
		}
		
	}
	
	static class ThreadDraw extends Thread {
		boolean exits;
		private LogForMessageBoxFrame owner;
		ThreadDraw(LogForMessageBoxFrame owner) {
			this.owner = owner;
		}
		public void run() {
			draw_sub();
		}
		public void draw_sub() {
			while (!exits) {
				
					if (owner.owner.getIsOpen()) {
						synchronized (owner.lockObject) {
							if (owner.mImage2Changed) {
								//synchronized (CommonGUI.loggingForMessageBox) {							
									CommonGUI.loggingForMessageBox.drawToImage(owner.mCanvas2);
								//}
								owner.mImage2Changed = false;
								sleep2(1000);
								continue;
							}
							if (owner.g==null) {
								owner.g = owner.getGraphics();
							}
							owner.g.drawImage(owner.mImage2, 0, 0, null);
							sleep2(2000);
							continue;
						}
					}
					sleep2(3000);
				
			}
		}
		
		void sleep2(long howLong) {
			try {
				Thread.sleep(howLong);
			} catch (InterruptedException e) {
				
				//e.printStackTrace();
			}
		}	
		
	}
	
	public void drawNotThread() {
		if (owner.getIsOpen()) {			
			while (true) {
				if (this.isDisplayable()) {
					g = getGraphics();
					break;
				}
				else {
					try {
						Thread.sleep(500);
						continue;
					} catch (InterruptedException e) {
						
						e.printStackTrace();
					}
				}
			}
				
			if (mImage2Changed) {
				CommonGUI.loggingForMessageBox.drawToImage(mCanvas2);
				mImage2Changed = false;
			}
			/*try {
				ImageIO.write(mImage2, "png", new File(Common_Settings.pathProject+File.separator+"Test.png"));
			} catch (IOException e) {
				
				e.printStackTrace();
			}*/
			g.drawImage(mImage2, 0, 0, null);		
			
			/*try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}*/
		}
	}
	
	public void wakeUpThread() {
		if (this.threadDraw!=null) 
			this.threadDraw.interrupt();
	}
	
	
	@Override
	public void windowActivated(WindowEvent arg0) {
		
		
	}

	@Override
	public void windowClosed(WindowEvent arg0) {
		
		
	}

	@Override
	public void windowClosing(WindowEvent arg0) {
		
		
	}

	@Override
	public void windowDeactivated(WindowEvent arg0) {
		
		
	}

	@Override
	public void windowDeiconified(WindowEvent arg0) {
		
		
	}

	@Override
	public void windowIconified(WindowEvent arg0) {
		
		
	}

	@Override
	public void windowOpened(WindowEvent arg0) {
		
		
	}
		
}