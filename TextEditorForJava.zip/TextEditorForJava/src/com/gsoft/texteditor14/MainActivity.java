package com.gsoft.texteditor14;

import java.io.File;
import java.io.FileOutputStream;

import android.app.Activity;
import android.content.Context;
import android.view.KeyEvent;

import com.gsoft.common.CommonGUI;
import com.gsoft.common.Common_Settings;
import com.gsoft.common.FileHelper;
import com.gsoft.common.IO;
import com.gsoft.common.IO_types;
import com.gsoft.common.PowerManagement;
import com.gsoft.common.gui.Control;
import com.gsoft.common.gui.IntegrationKeyboard;
import com.gsoft.hardware.HardwareKeyboard;
import com.gsoft.texteditor14.CustomView;
//import com.gsoft.common.Notification;

public class MainActivity extends Activity  {
	CustomView mView;
	
	String title;
	
	public static void main(String[] args) {
		
		// working dir을 설정한다.
		/*if (File.separator.equals("\\")) {
			System.setProperty("user.dir", "C:\\GSoft\\TextEditorForJava\\TextEditorForJava");
		}
		else {
			File usrDir = new File("/usr");
			if (usrDir.exists()) { // 리눅스
				System.setProperty("user.dir", "/home/TextEditorForJava/TextEditorForJava");
			}
			else {
				// 안드로이드
				
			}
		}*/
		
		
		// activity 설정
		MainActivity activity = new MainActivity();
		Control.activity = activity;
		Control.CurrentSystem = "JAVA";
		
		Context context = activity.getApplicationContext();
			
		
		Control.window = activity.getWindow(); 
		PowerManagement.keepScreenOn();
		
		
		
		try {
			// 뷰를 생성해서 컨트롤들을 생성하고 첫번째로 그린다.
			activity.mView = new CustomView(activity, context);
			//Pipe.listener = activity.mView;		
			activity.mView.restoreContents();
			activity.mView.setBounds(Common_Settings.settings.viewX, Common_Settings.settings.viewY, 
					Common_Settings.settings.originalViewWidth, Common_Settings.settings.originalViewHeight);
			
			activity.setContentView(activity.mView);
		
		
		}catch (Exception e) {
        	e.printStackTrace();
        }
		
	}
	

	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (event.getAction()==KeyEvent.ACTION_DOWN) {
			if (keyCode == KeyEvent.KEYCODE_ESCAPE) {
	            // When the user center presses, let them pick a contact.
	        	mView.onBackPressed();
	        	//mView.closeDialog.open();
	        	//Control.setModified(true);
	        	mView.invalidate();
	            return true;
	        }
	       		
			HardwareKeyboard.setKeyCodeAndEvent(keyCode, event);
			CommonGUI.keyboard.onTouchEvent(IntegrationKeyboard.hardwareKeyboard, null);
			mView.invalidate();
			return true;
		}
		return false;
    }
		
	
	/**app이 실행을 멈추고 실행을 재개할 때 호출된다.*/
	protected void onResume() {
		super.onResume();
		mView.resume();		
	}

	/**app이 실행을 멈출 때 호출된다. 예를 들어 home버튼 눌릴 시*/
    protected void onPause() {
    	super.onPause();
    	//Control.exit(true);
    	mView.pause();    	
    }
   
    
    public void destroy() {
    	try{
    		
    	if (!isFinishing()) {  // 여기서 finish()를 안하고 종료하므로 backupText()에 의한 저장을 해야 한다.
			mView.lastOperationExceptNotify();
			super.onDestroy();
			int myPId = android.os.Process.myPid();
			android.os.Process.killProcess(myPId);
			System.exit(0);
			
		}
		else {	// finish called.
			if (Control.isDestroyedExceptNotify) {
				mView.lastOperationExceptNotify();
				super.onDestroy();
				System.exit(0);
				
				int myPId = android.os.Process.myPid();
				android.os.Process.killProcess(myPId);
				
			}
			else {
				boolean r = mView.lastOperation();
				if (!r) {
					return;
				}
				super.onDestroy();
				System.exit(0);
				
				int myPId = android.os.Process.myPid();
				android.os.Process.killProcess(myPId);
				
			}
		}
    	
    	}catch(Exception e) {
    		e.printStackTrace();
    		showMessageToFile((new com.gsoft.common.util.Util.StackTracer(e)).getMessage().str);
    	}
    }
    
    public static void showMessageToFile(String text) {
		FileOutputStream outputStream=null;
		try{
		
		File contextDir = Control.view.getContext().getFilesDir();
		
		String absFilename = contextDir.getAbsolutePath() + File.separator + "ExitReason.txt";
		File file = new File(absFilename);
		
		outputStream = new FileOutputStream(file);
		IO.writeString(outputStream, text, IO_types.TextFormat.UTF_16, false, true);
		}catch(Exception e) {
			
		}
		finally {
			FileHelper.close(outputStream);
		}
	}
  
	
	protected void onDestroy() {
		destroy();
		
	}

}