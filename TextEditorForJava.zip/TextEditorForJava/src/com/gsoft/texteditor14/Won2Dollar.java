package com.gsoft.texteditor14;
import java.util.Scanner;
abstract class Converter{
    abstract protected double convert(double src);
    abstract protected String srcString();
    abstract protected String destString();
    protected double ratio;
    Converter() {
    }     
    public void run(){
    	Scanner scanner = new Scanner(System.in);
       System.out.println(srcString() + "을" + destString() + "로 바꿉니다.");
       System.out.print(srcString() + "을 입력하세요>> ");
       double val = scanner.nextDouble();
       double res = convert(val);
       System.out.println("변환 결과: " + res + destString() + "입니다");
       scanner.close();
    }
}
public class Won2Dollar extends Converter {

double wonsPerDollar;
Won2Dollar(int wonsPerDollar) {
super();
this.wonsPerDollar = wonsPerDollar;
}
protected double convert(double src) {
ratio = (double)1 / wonsPerDollar;
return src * ratio;
}
protected String srcString() {
return "원";
}
   protected String destString() {
    return "달러";
   }   
public static void main(String[] args) {
Won2Dollar w2d = new Won2Dollar(1200);
w2d.run();
}
}