package testForDistribution;

public class C {
	public static void main(String[] args) {
	   for (int i=0; i<7; i++) {
   	   System.out.println("TestForDistribution.C starts");
   	   try {
   	      Thread.sleep(2000);
   	   }catch(Exception e) {
   	   }   	         	      
	   }   	   
	}
}
