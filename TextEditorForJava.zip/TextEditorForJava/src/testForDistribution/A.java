package testForDistribution;

import testForDistribution.B;

@SuppressWarnings("unused")
public class A {
   static int[][] arr2 = {{0, 1}, {2, 3}};
   
	
	public static void main(String[] args) {
	   String name = new String("ABC");
	   String str = name + " class don't have a method " + name + "()" + " of " + name + 
								". You must implement the abstract method.";
		System.out.println("str="+str);
		
		String typeName = "ABC";
		str = "invalid array initialization. : " + typeName + "-" + null;
		System.out.println("str="+str);
		
		str = null + "-"+ "invalid array initialization. : ";
		System.out.println("str="+str);
		
		B bClass = new B();
		System.out.println("bClass.backColors="+bClass.backColors);
		System.out.println("bClass.backColors="+bClass.backColors[0].getBlue());
		
	   
      int k=0;
	//	try {
	       int i, j;
	       for (j=1; j<10; j++) {
	           for (i=1; i<10; i++) {
	              /* if (i==9) if (i==3) {
	                  //continue;
	                for (j=1; j<10; j++) {
	                   for (i=1; i<10; i++) {
	                      if (i==9) if (i==3) continue;
	                   }
	                }
	               }*/

	               int value = j*i;
	               System.out.println(j+"*"+i+"="+value);
	               
	           }
	       }
	       
          //int sum;
	       for (j=0; j<2; j++) {
	          if (j==0 || j==1) {
                int n=3;
                if (j==3) continue;
             }
             int j3=0;
		       if (j==0 || j==1) {
		          int n=3;
             }

             int sum=0;
	          for (i=1; i<=10; i++) {
	             sum += i;	           	               
	             System.out.println("1-"+i+" sum="+sum);
	          }
	       }
	       
	       String c = "a";
	       System.out.println(c);
	       
	       
	       for (j=0; j<10; j++) {
	           for (i=0; i<j; i++) {
	               System.out.print("*");	               
	           }
	           System.out.println("");
	       }
	       
	       char[] arr = {'A', 'B', 'C', 'D', 'E'};
	       for (i=0; !(i-0>=2-0); i++) {
	          if (i==0) {
	             int m;
	             for (m=0; m<arr.length; m++) {
	                System.out.print(arr[m]);
	             }
	             System.out.println("");
	          }
	          else {
	             int m;
	             for (m=arr.length-1; m>=0; m--) {
	                System.out.print(arr[m]);
	             }
	             System.out.println("");
	          }
	       }
	       
	       
	       System.out.println("recursive(1-10)="+recursive(10));
	       
	       checkColor();
	   
		

	}
    
   static int recursive(int f) {     
      if (f==0) return 0;
      return f + recursive(f-1);
   }
   
   static void checkColor() {
      int whiteColor = /*Color.*/rgb(255, 
         255, 255);
      System.out.println("White color="+whiteColor);
       int blackColor = /*Color.*/rgb(0, 0, 0);
      System.out.println("Black color="+blackColor);
   }      
   
   public static int rgb(int r, int g, int b) {
			
			int color = (255 << 24) | (r << 16) | (g << 8) | (b);
			return color;
		}
	
}