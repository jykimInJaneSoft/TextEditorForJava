package testForDistribution;

public class D {
	public static void main(String[] args) {
	   System.out.println("D class started");
	}
}
