package testForDistribution;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JFrame;

@SuppressWarnings("serial")
public class B extends JFrame implements WindowListener {
   Color[] backColors = {Color.BLACK, Color.WHITE, Color.GREEN, Color.RED};
   Color[] frontColors = {Color.WHITE, Color.BLACK, Color.RED, Color.GREEN};
   int indexColor;

	public static void main(String[] args) {
	   String classPath = System.getProperty("java.class.path");
	   System.out.println("classPath="+classPath);
	   classPath += ";"+"C:\\GSoft\\TextEditorForJava\\TextEditorForJava\\janeSoft\\gsoft";
	   //classPath = classPath + ";"+"C:\\GSoft\\TextEditorForJava\\TextEditorForJava\\janeSoft\\gsoft.jar";
	   System.out.println("classPath="+classPath);
	   System.setProperty("java.class.path", classPath);
	   B bClass = new B();	  
	   bClass.setSize(500, 500);
	   bClass.setVisible(true);	  
	}
	
	B() {
	   this.setTitle("B class");
	   this.addWindowListener(this);
	}
	
	public void paint(Graphics g) {
	   Color backColor = this.backColors[indexColor];
	   Color frontColor = this.frontColors[indexColor];
	   Dimension size = this.getSize();
	   g.setColor(backColor);
	   g.fillRect(0, 0, (int)size.getWidth(), (int)size.getHeight());	   
	   
	   g.setColor(frontColor);
	   g.fillRect((int)size.getWidth()/3, (int)size.getHeight()/3, 
	       (int)(size.getWidth()/3), (int)(size.getHeight()/3));
	   
	   indexColor++;
	   if (indexColor==this.backColors.length) indexColor = 0;
	}
	
	/**Invoked when the Window is set to be the active Window.*/
	public void	windowActivated(WindowEvent e) {
	   System.out.println("window activated");
	}
	/**Invoked when a window has been closed as the result of calling dispose on the window.*/
   public void	windowClosed(WindowEvent e) {
      System.out.println("window closed");
   }
   /**Invoked when the user attempts to close the window from the window's system menu.*/
   public void	windowClosing(WindowEvent e) {
      //System.exit(1);
      System.out.println("window closing");
      dispose();
   }
   /**Invoked when a Window is no longer the active Window.*/
   public void	windowDeactivated(WindowEvent e) {
      System.out.println("window deactivated");
   }
   /**Invoked when a window is changed from a minimized to a normal state.*/
   public void	windowDeiconified(WindowEvent e) {
      System.out.println("window deiconified");
   }
   /**Invoked when a window is changed from a normal to a minimized state.*/
   public void	windowIconified(WindowEvent e) {
      System.out.println("window iconified");
   }

   public void	windowOpened(WindowEvent e) {
      System.out.println("window opened");
   }
}

