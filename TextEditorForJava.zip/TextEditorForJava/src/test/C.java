package test;

//import Test2.B;

public class C {
   static int c = 2;
   
   static int func() {
      int i=0;
      if (i==0) {
         return 1;
      }
      else {
         return 2;
      }                        
   }
         
	public static void main(String[] args) {
		try {
		   System.out.println("func()="+func());
		   float f = 0;
		   f += 2;
		   System.out.println("f="+f);
		   
		   int a=2;
		   a+=f;
		   System.out.println("a="+a);
		   
		   if (f==0) {
		      System.out.println("f="+f);
		   }		      
		   
		   ProcessBuilder builder = new ProcessBuilder("chmod", "777", "c:\\Test.txt");
		builder.redirectErrorStream(true);
		   
	       int i;
	       for (i=0; i<5; i++) {
	          System.out.println("main() in C class started.");
				int sleepTime = 3000;
				while (true) //{
					synchronized(System.out) {
							try {
								Thread.sleep((long)sleepTime);
							}catch(Exception e) {    
								e.printStackTrace();
							    System.out.println("interrupted.");
							}finally {
							    System.out.println("finally");
							}
							break;
							//j=0;
					 }
			//	}
			
			}
		}catch(Exception e) {
	    }
    }
}