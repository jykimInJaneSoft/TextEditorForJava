package test;
import janesoft.common.MemoryManager;
import android.graphics.Color;

@SuppressWarnings("unused")
public class A {
  int mVar=0;
  int[] arr=null;
  int[][] arr2;
  
  int[] color1 = {0+0, 1, 2};

  int[][] color2 = {            
       /*{Color.BLACK, Color.WHITE, Color.RED}, //a10
	    {Color.YELLOW,Color.BLUE, Color.GREEN} //a11*/
       {0, 1, 2},
       {3, 4, 5}
  };
  
  static class FFFF {
      FFFF(int p) {
         for (int i=0; i<2; i++) {
            int b;
            int c;
            System.out.println("p="+p);
         }                            
      }      
      
      int f(int a) {
         int i;
         System.out.println("a="+a);
         return a;
      }
  }
  

  /*int[][][] colors3 = {
	{//a0
		{Color.BLACK, Color.WHITE, Color.RED}, //a00
		{Color.YELLOW,Color.BLUE, Color.GREEN} //a01
	},
	 
	{//a1
		{Color.BLACK, Color.WHITE, Color.RED}, //a10
	    {Color.YELLOW,Color.BLUE, Color.GREEN} //a11
	}
	};//2면 2행 3열*/


  A() {
	  System.out.println("A()");

     arr = new int[3];     

     mVar = 1;
     long longValue = 1000;
     System.out.println("longValue="+longValue+" mVar : "+mVar);
     
     float floatValue = -5.0f;
     System.out.println("floatValue="+floatValue+" mVar : "+mVar);
     
     int i=0;
     for (i=0; i<arr.length; i++) {         
         int j=1, j4=0, j5=0, j6=0;
         if (j==0 || j==1) {
             int n=3;
             j = n;
             if (n==3) {
                continue;
             }
         }
         int j3=0;
		   if (j==0 || j==1) {
		       int n=3;
             j = n;
         }


         arr[i] = i+j+j3+j4+j5+j6;
         
         for (i=0; i<arr.length; i++) {
             int j2=1;
             if (j2==0 || j2==1) {
                int n=3;
                //n = j;
                j2 = n;
             }
             arr[i] = i+j2;
         }
     }
   
     for (i=0; i<arr.length; i++) {
         int j = 0;
         if (i==arr.length-1) break;
         System.out.println("A.arr["+i+"]:"+arr[i+j]);
     }

     for (i=0; i<color1.length; i++) {
         int n = 0, k=120;
         System.out.println("A.color1["+i+"]:"+color1[i]);
     }
     for (i=0; i<2; i++) {
         for (int k=0; k<3; k++) {
             int m=0;
             if (m==0) {
                System.out.println("A.color2["+i+"]["+k+"]:"+color2[i][k]);
                break;
             }
         }                           
     }

     func();
     
     
     FFFF ffff = new FFFF(3);
  }  

  void func() {
	  System.out.println("func()");

     int i=0;
     for (i=0; i<arr.length; i++) {
         int j=1;
         arr[i] = i+j;
     }
    
     for (i=0; i<arr.length; i++) {
         int j=0;
         System.out.println("A.arr["+i+"]:"+arr[i+j]);
     }

     arr2 = new int[3][3];
     int count=0;
	//int j;
	//int k=0;
     for (int j=0; j<3; j++) {
    	 int k, n=2;
        for (k=0; k<3; k++) {
        	//int r=0;
            for (int o=0; o<5; o++) {
                int m=3;
                //if (m==3) return;
                arr2[j][k] = count+n+m+o;
            }
            count++;
            System.out.println("A.arr2["+j+"]["+k+"]:"+arr2[j][k]);
        }
     }
  }

  public static void main(String[] args) {	  
     int a=0;
	  int count = 1+2;
	  
	  int[] tempArr = new int[5];
 
     a = 0;
     
     f(2, 3);

     int b=0;
     int c=0;
     
     System.out.println("main");

     if (args!=null && args.length>0) {
         System.out.println("args[0]"+args[0]);
     }	  
		

      count = 0;
      while (b<2) {
         while(a<6) {
    		   count+= a;
		       a++;
   		}
         a=0;
         b++;
         //throw new Exception("에러발생");
      }
      System.out.println("Count : "+count);

      count = 0;
      for (a=0; b<1 && c<1 && a<6; a++) {
             count+=a;
          }

      System.out.println("Count : "+count);

 

      count = 0;
      do {
    		   count+= a;
		       a++;
   		}
      while ((float)a<6);
      System.out.println("Count : "+count);


	  boolean r = false;

     if (false || true) r=true;
     System.out.println("false || true : "+r);


      r = false;
      if ( !(!((float)b<1) && !(c<1)) ) {
          r = true;
      }
      System.out.println("!(!((float)b<1) && !(c<1)) : "+r + " b="+b + " c="+c);


      r = false;
      if (!(!(b<1 && (float)c<1 && b>0) || !(b>0 && c<1))) {
          r = true;
      }
      System.out.println("!(!(b<1 && (float)c<1 && b>0) || !(b>0 && c<1)) : "+r + " b="+b + " c="+c);


      r = false;
      if (!(!(b<1 && (float)c<1 && b>0) && !(b>0 && c<1))) {
          r = true;
      }
      System.out.println("!(!(b<1 && (float)c<1 && b>0) && !(b>0 && c<1)) : "+r + " b="+b + " c="+c);

      r = false; 
      if ( !(!(true && c<1) && !(false || c<0)) ) {
          r = true;
      }      
      System.out.println("!(!(true && c<1) && !(false || c<0)) : "+r + " b="+b + " c="+c);


      r = false;      
      if (!(b<1 && c<1) || !(b<0 || c<0)) {
          r = true;
      }
      System.out.println("!(b<1 && c<1) || !(b<0 || c<0) : "+r + " b="+b + " c="+c);

      r = false;
      if (c<1 && b<1) {
           r = true;
      }
      System.out.println("c<1 && b<1 : "+r + " b="+b + " c="+c);



      count = 0;
      for (b=0; b<2 && c<1; b++)// {
          for (a=0; c<1 && a<6; a++) {
             count+=a;
          }
     // }
		System.out.println("Count : "+count);
	//	int b=0;	
	
	fff();
	
   System.out.println("f2() : "+f2());
   
   A classA = new A();
   
   System.out.println("A.mVar : "+classA.mVar);
   
   long sum = MemoryManager.sumMemory();
   System.out.println("Used Memory="+sum);
   
   String message = MemoryManager.getMessage().toString();
   System.out.println("Heap list="+message);
  
  }
  
  static void fff() {
     int a, b;
     synchronized(System.out) {		
		try {
		     synchronized(System.out) {
				  try {
				     a=0; b=0;
			           System.out.println("a : "+a);
			           synchronized(System.out) {
			    		     for (;a==0; a++) {
					             throw new Exception("에러발생");
					         }
			           }
			           b=0;
				  }
				  catch(NullPointerException npe) {
				     a=1;
				     b=1;
				     System.out.println("a : "+a);
				  }  
				  catch(Exception e) {
				     a=2;
				     e.printStackTrace(System.out);
				     System.out.println(e.getCause());
				     System.out.println(e.getMessage());
		             System.out.println(e.getStackTrace()[0]);
		             System.out.println("a : "+a);				     
				  }
				  finally {
				     a=6;
				     System.out.println("a : "+a);
				  }
				  a=3;
				  System.out.println("a : "+a);
		      }
		}
		catch(Exception e) {
			  a=4;			  
		      System.out.println("a : "+a);
			  e.printStackTrace();
		}
		finally {
			   a=5;
		      System.out.println("a : "+a);
		}
	}

  }     

	static int f(int a, int b) {
	   int c=1;
	   if (false) {
	      Object g= new Integer(0);
	      Object p= new Integer(1);
	      for (a=1; a<3; a++) {
	         int d=0;
	         int f=0;
	         c=0;
	         a=2;
	         System.out.println("p="+p);
	      }
	      c=0;
	   }
	   else if (c==1) {
	      Object g= new Integer(2);
	      Object p= new Integer(3);
	      for (a=1; a<3; a++) {
	         int d=0;
	         int f=0;
	         c=0;
	         a=2;
	         System.out.println("p="+p);
	      }
	      c=1;
	   }
	   else {
	   }
	   return c;
	}
	
	
	static int f2() {
		int a=0;
		try {
			a=0;
		}
		catch(Exception e) {
			a=1;		
		}
		finally {
			a=2;
		}
	   return a;
	}


	/*static void funcCondition() {
		int a=0;
		boolean b1 = true;
		boolean b2 = true;
		boolean b3 = true;
		boolean b4 = false;
	    if ((!b1 && b2 && !b3) || b4) {//false
	        a=1;
	    }
	    System.out.println("a="+a);
	}
	*/  
	  /*public int test1(int a) {
		  while (a<3) {
			  a++;
		  }
		  return a;
	  }*/
}