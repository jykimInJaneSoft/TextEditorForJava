package test;

import com.gsoft.common.FileHelper;

import janesoft.common.MemoryManager;

import java.io.File;

import com.gsoft.common.util.ArrayList;

@SuppressWarnings("unused")
public class E {
	public static void main(String[] args) {
	   String name = "ABC";
	   String str = name + " class don't have a method " + name + "()" + " of " + name + 
								". You must implement the abstract method.";
		System.out.println("str="+str);
	   
      int k=0;
	//	try {
	       int i, j;
	       for (j=1; j<10; j++) {
	           for (i=1; i<10; i++) {
	               if (i==9) if (i==3) {
	                  //continue;
	                for (j=1; j<10; j++) {
	                   for (i=1; i<10; i++) {
	                      if (i==9) if (i==3) continue;
	                   }
	                }
	               }

	               int value = j*i;
	               System.out.println(j+"*"+i+"="+value);
	               
	           }
	       }
	       
          //int sum;
	       for (j=0; j<2; j++) {
	          if (j==0 || j==1) {
                int n=3;
                if (j==3) continue;
             }
             int j3=0;
		       if (j==0 || j==1) {
		          int n=3;
             }

             int sum=0;
	          for (i=1; i<=10; i++) {
	             sum += i;	           	               
	             System.out.println("1-"+i+" sum="+sum);
	          }
	       }
	       
	       String c = "a";
	       System.out.println(c);
	       
	       
	       for (j=0; j<10; j++) {
	           for (i=0; i<j; i++) {
	               System.out.print("*");	               
	           }
	           System.out.println("");
	       }
	       
	       for (j=10; j>=0; j--) {
	           for (i=0; i<j; i++) {
	               System.out.print("*");	               
	           }
	           System.out.println("");
	       }

	       
	       char[] arr = {'A', 'B', 'C', 'D', 'E'};
	       for (i=0; !(i-0>=2-0); i++) {
	          if (i==0) {
	             int m;
	             for (m=0; m<arr.length; m++) {
	                System.out.print(arr[m]);
	             }
	             System.out.println("");
	          }
	          else {
	             int m;
	             for (m=arr.length-1; m>=0; m--) {
	                System.out.print(arr[m]);
	             }
	             System.out.println("");
	          }
	       }
	       
	       
	       System.out.println("recursive(1-10)="+recursive(10));
	       
	       checkColor();
	       
	       checkFileHelper();
	       
	       long sum = MemoryManager.sumMemory();
   System.out.println("Used Memory="+sum);
   
   String message = MemoryManager.getMessage().toString();
   System.out.println("Heap list="+message);
		
	/*	} catch(Exception e) {
		   e.printStackTrace();
		}*/
	}
    
   static int recursive(int f) {     
      if (f==0) return 0;
      return f + recursive(f-1);
   }
   
   static void checkColor() {
      int whiteColor = /*Color.*/rgb(255, 
         255, 255);
      System.out.println("White color="+whiteColor);
       int blackColor = /*Color.*/rgb(0, 0, 0);
      System.out.println("Black color="+blackColor);
   }      
   
   public static int rgb(int r, int g, int b) {
			
			int color = (255 << 24) | (r << 16) | (g << 8) | (b);
			return color;
		}
		
	public static void checkFileHelper() {
	   String partitionName = FileHelper.getPartitionName();
	   System.out.println("partitionName="+partitionName);
	   
	   String curDir = System.getProperties().getProperty("user.dir");
	   System.out.println("curDir="+curDir);
	   System.out.println("getCount(curDir, 'c')="+getCount(curDir, 'c'));
	   System.out.println("isSeparator(File.separator)="+isSeparator(File.separator));
	   System.out.println("isSeparator(File.separatorChar)="+isSeparator(File.separatorChar));
	   
	   File file1 = new File("c:\\Test.txt");
	   File file2 = new File("c:\\Test.txt");
	   System.out.println("equals(file1, file2)="+equals(file1, file2));
	   
	   int i;
	   
	   ArrayList list = /*FileHelper.*/getFileList("D:\\kjy\\음악");
	   System.out.println("File list count="+list.count);
	   //int i;
	   for (i=0; i<list.count; i++) {
	      //System.out.println(list.getItem(i).toString());
	      File file = (File)list.getItem(i);
	      System.out.println(file.getName());
	   }
	   
	   SizeAndCount sizeAndCount = E.getFileSizeAndCount("D:\\kjy\\음악");
	   System.out.println("getFileSizeAndCount()="+sizeAndCount.size+", "+sizeAndCount.count);
	   
	  // String absFilename = "c:\\";
	 //  ArrayList r = getFileList2(absFilename);
	   /*ArrayList r = new ArrayList(50);
	   String absFilename = "c:\\";
	   File file = new File(absFilename); 
		if (file.isDirectory()) {
			String[] fileList = file.list();
			if (fileList!=null && fileList.length>0) {
				for (i=0; i<fileList.length; i++) {
				   if (isSeparator( absFilename.charAt(absFilename.length()-1) )==false)
				      //System.out.println(fileList[i]);
				      r.add(fileList[i]);
				   else 
				      //System.out.println(fileList[i]);
				      r.add(fileList[i]);
				}
			}
		}
		else {
		   //System.out.println(file.getAbsolutePath());
		   r.add(file.getAbsolutePath());
		}*/		   											   
	  /* for (i=0; i<r.count; i++) {
	      System.out.println(r.getItem(i));
	   }*/	         

	}
	
	/** 윈도우즈의 경우에는 c:, d: 등을 리턴하고 안드로이드의 경우에는 ""을 리턴한다.*/
	public static String getPartitionName() {
		String curDir = System.getProperties().getProperty("user.dir");
		if (curDir.length()>1 && curDir.charAt(1)==':') {
			return curDir.substring(0, 2);
		}
		return ""; 
	}
	
	public static int getCount(String path, char c) {
		int i;
		char[] buf = path.toCharArray();
		int count=0;
		for (i=0; i<buf.length; i++) {
			if (buf[i]==c) count++;
		}
		return count;
	}
	
	public static boolean isSeparator(String str)
    {
        if (str.equals(File.separator)/* || str.equals("\\")*/)
            return true;
        return false;
    }
	
	public static boolean isSeparator(char c)
    {
        if (c==File.separator.charAt(0)/* || c=='\\'*/)
            return true;
        return false;
    }
    
    private static boolean equals(String[] strs1, String[] strs2) {
		if (strs1.length!=strs2.length) return false;
		int i, j;
		boolean found;
		for (i=0; i<strs1.length; i++) {
			found=false;
			for (j=0; j<strs2.length; j++) {
				if (strs1[i].equals(strs2[i])) {
					found = true;
					break;
				}
			}
			if (!found) return false;
		}
		return true;
	}
	
	public static boolean equals(File file1, File file2) {
		String name1 = file1.getName();
		String name2 = file2.getName();
		if (!name1.equals(name2)) return false;
		
		long len1 = file1.length();
		long len2 = file2.length();
		if (len1!=len2) return false;
		
		long time1 = file1.lastModified();
		long time2 = file2.lastModified();
		if (time1!=time2) return false;
				
		
		boolean isDir1 = file1.isDirectory();
		boolean isDir2 = file2.isDirectory();
		if (isDir1!=isDir2) return false;
		if (isDir1 && isDir2) {
			String[] fileList1 = file1.list();
			String[] fileList2 = file2.list();
			if (!equals(fileList1, fileList2)) return false;
		}
		return true;
	}
	
	static ArrayList getFileList2(String absFilename) {
	   ArrayList r = new ArrayList(50);
	   File file = new File(absFilename);
	   int i; 
		if (file.isDirectory()) {
			String[] fileList = file.list();
			if (fileList!=null && fileList.length>0) {
				for (i=0; i<fileList.length; i++) {
				   if (!isSeparator( absFilename.charAt(absFilename.length()-1) ))
				      //System.out.println(fileList[i]);
				      r.add(fileList[i]);
				   else 
				      //System.out.println(fileList[i]);
				      r.add(fileList[i]);
				}
			}
			return r;
		}
		else {
		   //System.out.println(file.getAbsolutePath());
		   r.add(file.getAbsolutePath());
		   return r;
		}
	}	   
	
	/** absFilename 안에 있는 모든 디렉토리와 파일들을 리스트(File[])로 리턴한다.*/
	public static ArrayList getFileList(String absFilename) {
		
		ArrayList result = new ArrayList(10);
		
		File file = new File(absFilename); 
		if (file.isDirectory()) {
			result.add(file); // 디렉토리
			
			String[] fileList = file.list();
			if (fileList!=null && fileList.length>0) {
				int i;				
				for (i=0; i<fileList.length; i++) {
					ArrayList r;
					if (!isSeparator( absFilename.charAt(absFilename.length()-1) )) {
						r = /*FileHelper.*/getFileList(absFilename+File.separator+fileList[i]);
					}						
					else {
						r = /*FileHelper.*/getFileList(absFilename+fileList[i]);
					}						
					int j;
					for (j=0; j<r.count; j++) {
						result.add(r.getItem(j));
					}
					/*if (result.count>=Integer.MAX_VALUE/100) {
						return result;
					}*/
				}
			}				
			
			return result;
		}
		else {
			result.add(file);
			return result;
		}
	}
	
	public static class SizeAndCount {
		public long size;
		public int count;
		public SizeAndCount() {
			
		}
		public SizeAndCount(long size, int count) {
			this.size = size;
			this.count = count;
		}
	}
	
	public static SizeAndCount getFileSizeAndCount(String absFilename) {
		SizeAndCount sizeAndCount = null;
		long size = 0;
		int count = 0;
		File file = new File(absFilename); 
		if (file.isDirectory()) {
			String[] fileList = file.list();
			if (fileList!=null && fileList.length>0) {
				int i;				
				for (i=0; i<fileList.length; i++) {
					SizeAndCount sc = null;
					if (!isSeparator( absFilename.charAt(absFilename.length()-1) ))
						sc = /*FileHelper.*/getFileSizeAndCount(absFilename+File.separator+fileList[i]);
					else 
						sc = /*FileHelper.*/getFileSizeAndCount(absFilename+fileList[i]);
					if (sc!=null) {
						size += sc.size;
						count += sc.count;
					}
					//return r;
				}
			}
			
			size += 0; // 디렉토리
			count++;
			sizeAndCount = new SizeAndCount(size,count);
			return sizeAndCount;
		}
		else {
			size += file.length();
			count++;
			sizeAndCount = new SizeAndCount(size,count);
			return sizeAndCount;
		}
	}
	   
}