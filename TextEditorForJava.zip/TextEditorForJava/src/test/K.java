package test;

import com.gsoft.common.Code.CodeChar;
import com.gsoft.common.Code.CodeString;
import com.gsoft.common.util.HighArray_CodeChar;

public class K extends C {
	public static void main(String[] args) {
	   System.out.println("K.c="+K.c);
	   
	   HighArray_CodeChar input = new HighArray_CodeChar(20);
	   input.add(new CodeString("int a=0;\n//abc\nint b=0;\n", 1));
	   
	   int i=0;
	   for (i=0; i<input.count; i++) {
	      if (input.charAt(i).c == '/' && 
          	(i + 1 < input.length() && input.charAt(i + 1).c == '/')) {
          	int startOfComment = i;
          	int endOfComment = -1;
          	int j;
          	for (j = i+2; j < input.length(); j++)
                {
                	if (input.charAt(j).c == '\r' && 
                    		(j + 1 < input.length() && input.charAt(j + 1).c == '\n'))
                    {
                		endOfComment = j + 1;
                		break;
                    }
                	else if (input.charAt(j).c == '\n') {
                		endOfComment = j;
                		break;
                	}
                }
       	   System.out.println("comment : startOfComment="+startOfComment+" endOfComment="+endOfComment);
         }
      
         if (input.charAt(i).c == '/' && 
      		(i + 1 < input.length() && input.charAt(i + 1).c == '*')) {
 		   	int startOfComment = i;
          	int endOfComment = -1;
          	int j;
          	for (j = i+2; j < input.length(); j++)
                {
                	if (input.charAt(j).c == '*' && 
                			(j + 1 < input.length() && input.charAt(j + 1).c == '/'))
                    {
                		endOfComment = j + 1;
                		break;
                    }
                }
      		 System.out.println("block comment : startOfComment="+startOfComment+" endOfComment="+endOfComment);
         }
	   }         
      
      CodeChar[] cs = {input.charAt(0)};           		   
      System.out.println("cs="+cs[0].c);     		   
	}
}
