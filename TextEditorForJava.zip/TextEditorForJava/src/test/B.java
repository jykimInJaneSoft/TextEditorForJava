package test;

import janesoft.common.MemoryManager;

@SuppressWarnings("unused")
public class B {
	public static String BackspaceChar = "%"+"bk";
//	HighArray<FindVarUseParams> listOfAllVarUses;
	int len = "offset_Lookup".length()+1;
	
	static char[] chars_shiftNotPressed = {
		'ㅂ', 'ㅈ', 'ㄷ', 'ㄱ', 'ㅅ',   'ㅠ', 'ㅐ', 'ㅔ', 'ㅚ' , 'ㅢ', 
		'ㅝ', '\'', '.'
	};

	
    
	public static void main(String[] args) {
         	
    	int a4 = 1+2*3;
    	int a1 = 1+2*(-2+3*1);
    	int a2 = 1+2*(2*3-1*2);
    	int a3 = 1*(-2*3-1)+2*(2*3-1);
   	
    	StringBuilder builder = new StringBuilder();
		Object builder2 = (java.lang.Object)builder.append("abc");
		builder = (StringBuilder) builder2;
		builder.append((char)123);
		System.out.println(builder.toString());

		
    	float x=0, y=0;
    	x -= 3;
		y -= 3;
		
		System.out.println("chars_shiftNotPressed[0] = "+chars_shiftNotPressed[0]);
		
		System.out.println(123);
		
	    String abc = "ab";
	    int bTest = 1 + (abc.equals("Forward") ? 1 : 0);
	    boolean isForward = abc.equals("Forward") ? true : false;
	    bTest += abc.equals("Forward") ? 1 : 0;
	    System.out.println("bTest="+bTest);


	    int a = 5;
	 //   int p, q;
    //	p=0; q=0;
    //	float d=3;
    	switch (a) {
         case 'ㄱ': 
        // {
             for (a=0; a<3; a++) {
                 if (a==5) {
                     int p, q;
             	     p=1;q=2;q=p+q;System.out.println("1 in switch(a)"+p+q);//break;
                 }
             }
            // System.out.println("0 in switch(a)");System.out.println("0 in switch(a)");System.out.println("0 in switch(a)");System.out.println("0 in switch(a)");System.out.println("0 in switch(a)");System.out.println("0 in switch(a)");System.out.println("0 in switch(a)");System.out.println("0 in switch(a)");System.out.println("0 in switch(a)");System.out.println("0 in switch(a)");System.out.println("0 in switch(a)");System.out.println("0 in switch(a)");System.out.println("0 in switch(a)");System.out.println("0 in switch(a)");System.out.println("0 in switch(a)");System.out.println("0 in switch(a)");System.out.println("0 in switch(a)");break;
       //  }
         case 'ㄴ': a=0; System.out.println("0 in switch(a)"); //break;        
         case 5: {
             if (a==5) {
                 float d=3;int p=0;
            	  System.out.println("5 in switch(a) d="+d);System.out.println("5 in switch(a)");System.out.println("5 in switch(a)");System.out.println("5 in switch(a)");System.out.println("5 in switch(a)");System.out.println("5 in switch(a)");System.out.println("5 in switch(a)");System.out.println("5 in switch(a)");System.out.println("5 in switch(a)");System.out.println("5 in switch(a)");System.out.println("5 in switch(a)");System.out.println("5 in switch(a)");System.out.println("5 in switch(a)");System.out.println("5 in switch(a)");System.out.println("5 in switch(a)");System.out.println("5 in switch(a)");System.out.println("5 in switch(a)");System.out.println("5 in switch(a)");System.out.println("5 in switch(a)");System.out.println("5 in switch(a)");System.out.println("5 in switch(a)");System.out.println("5 in switch(a)");System.out.println("5 in switch(a)");System.out.println("5 in switch(a)");System.out.println("5 in switch(a)");System.out.println("5 in switch(a)");System.out.println("5 in switch(a)");System.out.println("5 in switch(a)");System.out.println("5 in switch(a)");System.out.println("5 in switch(a)");System.out.println("5 in switch(a)");
            	  //return;
             }
         }
        
 //       case 4: int r=0;
 //        	System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");
         default: System.out.println("default in switch(a)");
       // case 3: int p=0, q=0; System.out.println("3 in switch(a) p+q="+p+q); break;
       }

		a = 0;
      int m=0;
      int p;
      switch (a) {
         case 1:// int m=0; System.out.println("1 in switch(a) m="+m); break;
         case 0: p=0; a=0; System.out.println("0 in switch(a)"); break;        
         case 10: p=0; System.out.println("10 in switch(a)"); System.out.println("10 in switch(a)");System.out.println("10 in switch(a)");System.out.println("10 in switch(a)");System.out.println("10 in switch(a)");System.out.println("10 in switch(a)");System.out.println("10 in switch(a)");System.out.println("10 in switch(a)");System.out.println("10 in switch(a)");System.out.println("10 in switch(a)");System.out.println("10 in switch(a)");System.out.println("10 in switch(a)");System.out.println("10 in switch(a)");System.out.println("10 in switch(a)");System.out.println("10 in switch(a)");System.out.println("10 in switch(a)");System.out.println("10 in switch(a)");System.out.println("10 in switch(a)");System.out.println("10 in switch(a)");System.out.println("10 in switch(a)");System.out.println("10 in switch(a)");System.out.println("10 in switch(a)");System.out.println("10 in switch(a)");System.out.println("10 in switch(a)");System.out.println("10 in switch(a)");System.out.println("10 in switch(a)");System.out.println("10 in switch(a)");System.out.println("10 in switch(a)");System.out.println("10 in switch(a)");System.out.println("10 in switch(a)");System.out.println("10 in switch(a)");System.out.println("10 in switch(a)");
        
        case 4:
         	System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");System.out.println("4 in switch(a)");
         default: System.out.println("default in switch(a)");
        case 3: System.out.println("3 in switch(a)"); break;
       }

		System.out.println("switch(a) ends"); 

		f(2);
	     	
	       A classA = new A();
	   
	       System.out.println("classA.mVar : "+classA.mVar);	

	  
	//  f(i!=0 && j==1 && i==1 ? 3 : 2);
	
		short[][][] arr3 = new short[1][1][2];
arr3[0][0][0] = (short) (arr3[0][0][0] + 1);
	short[][][] arr4 = new short[1][1][2];
arr4[0][0][1] = 2;


		
		if (classA.arr2==null) {
		    System.out.println("a : "+a);
		    classA.arr2 = new int[1][1];
		}
		while (a<3) {
		   // classA.arr2[0][0] += (abc.equals("Forward") ? 3 : 2);
		   // System.out.println("classA.arr2[0][0] : "+classA.arr2[0][0]);
		    a++;
		}
	
		arr3[0][0][0] += (1>0 ? 3 : 2);
		System.out.println("arr3[0][0][0] : "+arr3[0][0][0]);
	
	 	

    	//	System.out.println("A.arr[0] in B class : "+classA.arr[0]);
    	
      long sum = MemoryManager.sumMemory();
      System.out.println("Used Memory="+sum);
   
      String message = MemoryManager.getMessage().toString();
      System.out.println("Heap list="+message);
    }
    static void f(int i) {
	     System.out.println("i: "+i+" (i = i!=0 && j==1 && i==1 ? 3 : 2;)" );
	
	     int[][] arr2 = new int[3][3];
	     int count=0;
	     for (int j=0; j<3; j++) {
	        int k, n=2;
	        for (k=0; k<3; k++) {
	            int r=0;
	            for (int o=0; o<5; o++)// {
	                if (r==0) {
	                    int m=3;
	                    if (m==3) {
	                       arr2[j][k] = count+n+m+o;
	                       continue;
	                    }
	                }
	          //  }
	            count++;
	            System.out.println("arr2["+j+"]["+k+"]:"+arr2[j][k]);
	        }
	     }


    }
   
}