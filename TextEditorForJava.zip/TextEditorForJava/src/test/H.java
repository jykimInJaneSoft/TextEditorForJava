package test;

import com.gsoft.common.util.Array;
import com.gsoft.common.util.ArrayList;
import com.gsoft.common.util.ArrayListChar;
import com.gsoft.common.util.ArrayListInt;
import com.gsoft.common.util.ArrayListString;

@SuppressWarnings("unused")
public class H {  
	public static void main(String[] args) {
	   int i;
	   Object[] arr1 = new Object[3];	   
	   arr1[0] = new Integer(0);
	   arr1[1] = new Integer(1);
      arr1[2] = new Integer(2);

      Object[] arr2 = new Object[arr1.length];
	   Array.Copy(arr1, 0, arr2, 0, arr1.length);
	   
	  
	   for (i=0; i<arr2.length; i++) {
	      System.out.println("arr2["+i+"]="+arr2[i]);
	   }
	   
	   int[] arr_int = {0, 1, 2};
	   arr_int = Array.Resize(arr_int, 5);
	   for (i=0; i<arr_int.length; i++) {
	      System.out.println("arr_int["+i+"]="+arr_int[i]);
	   }
	   
	   ArrayListInt arr1_int = new ArrayListInt(3);
	   if (arr1_int.count==0) {
	      System.out.println("arr1_int.count="+arr1_int.count);
	   }
	   arr1_int.add(0);
	   arr1_int.add(1);
	   arr1_int.add(2);
	   
	   for (i=0; i<arr1_int.count; i++) {
	      System.out.println("arr1_int["+i+"]="+arr1_int.getItem(i));
	   }

	   
	   ArrayListInt arr2_int = new ArrayListInt(3);
	   arr2_int.add(10);
	   arr2_int.add(11);
	   arr2_int.add(12);
	   
	   for (i=0; i<arr2_int.count; i++) {
	      System.out.println("arr2_int["+i+"]="+arr2_int.getItem(i));
	   }
	   /*
	   arr2_int.list = Array.InsertNoSpaceError(arr1_int, 0, arr2_int, 0, arr1_int.count);
	   arr2_int.count += arr1_int.count;
	   	   
	   for (i=0; i<arr2_int.count; i++) {
	      System.out.println("arr2_int["+i+"]="+arr2_int.getItem(i));
	   }*/

	   
	   char[] arrChars = {'a', 'b', 'c'};
	   arrChars = Array.Delete(arrChars, 0, 1);
	   
	   for (i=0; i<arrChars.length; i++) {
	      System.out.println("arrChars["+i+"]="+arrChars[i]);
	   }
	   
	   
	   int indexOfB = Array.Find(arrChars, 0, 'z');
	   //indexOfB = -1;
      System.out.println("indexOfB="+indexOfB);
      
      String[] arrStrs = new String[5];
      arrStrs[0] = "a";
      arrStrs[1] = "b";
      arrStrs[2] = "c";
      
      arrStrs = Array.Resize(arrStrs, 7);
      for (i=0; i<arrStrs.length; i++) {
	      System.out.println("arrStrs["+i+"]="+arrStrs[i]);
	   }
	   
	   arrStrs = Array.SubArray(arrStrs, 0, 2);
	    for (i=0; i<arrStrs.length; i++) {
	      System.out.println("arrStrs["+i+"] after subArray ="+arrStrs[i]);
	   }
	   
	   int r = fff(3);
	   System.out.println("fff(3)="+r);
	   
	   r = fff2(2);
	   System.out.println("fff2(2)="+r);
	   
	}
	
	
	
	static int fff(int a) {
	   try {
	      int b=0;
	      //return 0;
	   }
	   catch(Exception e) {
	      return 2;
	   }
	   return 1;
	}
	
	static synchronized int fff2(int a) {
	   int i;
	   if (a==0) {	      
	      ArrayListChar list = new ArrayListChar(3);
	      list.add("abcd");
	      list.insert(list.count, "efg");
	      String str = new String(list.getItems());
	      System.out.println("ArrayListChar="+str);
	      return 0;
	   }
	   else if(a==1) {
	      ArrayList list = new ArrayList(3);
	      list.add("abcd");
	      list.insert(list.count, "efg");
	      Object[] items = list.getItems();
	      int j;
	      for (j=0; j<items.length; j++) {
	         System.out.println("ArrayList["+j+"]="+items[j]);
	      }
	      return 1;
	   }
	   else {
	      ArrayListString list = new ArrayListString(3);
	      list.add("abcd");
	      list.add("efg");
	      Object[] items = list.getItems();
	      int j;
	      for (j=0; j<items.length; j++) {
	         System.out.println("ArrayListString["+j+"]="+items[j]);
	      }
	      
	      float x = -1 * 0.3f;
	      float y = -1 * 0.2f;
	      int v = (int)(x*y);
	      float xy = x*y;
	      
	      System.out.println("x="+x);
	      System.out.println("y="+y);
	      System.out.println("x+y="+(x+y));
	      System.out.println("x*y="+xy);

	      return 2;
	   }
	   //return 3;
	}




}
