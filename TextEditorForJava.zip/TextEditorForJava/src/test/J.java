package test;


public class J extends K {
   int WordLengthLimit = 100;
   
	public static void main(String[] args) {
	   System.out.println("J.c="+J.c);
	   
	   String name = "ABC";
	   String str = name + " class don't have a method " + name + "()" + " of " + name + 
								". You must implement the abstract method.";
		System.out.println("str="+str);
		char n = '\n';
		System.out.println("'\n'="+(int)n);
		String str2 = "abc\n\tabc";
		System.out.println("str2="+str2);
	}
/*
    boolean isSeparator(String s, String[] separators) {
		int i;
		for (i=0; i<separators.length; i++) {
			if (s.equals(separators[i])) return true;
		}
		return false;
	}*/
	
	boolean isSeparator(char c, String[] separators) {
		int i;
		for (i=0; i<separators.length; i++) {
			if (c==separators[i].charAt(0)) return true;
		}
		return false;
	}
}
