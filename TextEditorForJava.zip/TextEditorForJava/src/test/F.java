package test;

@SuppressWarnings("unused")
public class F {
	public static void main(String[] args) {
	     for (int j=0; j<3; j++) {
    	 int k, n=2;
        for (k=0; k<3; k++) {
        	//int r=0;
        	//int o;
        	if (k==1) continue;
        	//break;
        	//int o;
        	for (int o=0; o<5; o++) {
                int m=3;
                if (k==1) continue;
            }
            
            //count++;
            //System.out.println("A.arr2["+j+"]["+k+"]:"+arr2[j][k]);
        }
     }
	  
	    int a=0;
	  int count = 0; 
     int b=0;
      while (b<2) {
         while(a<6) {
    		   count+= a;
		       a++;
		       System.out.println("Count : "+count);
   		}
         a=0;
         b++;
         //throw new Exception("에러발생");
      }
      System.out.println("Count : "+count);

	}
}
