package test;

import com.gsoft.common.util.ArrayListChar;

public class I {
	public static void main(String[] args) {
	   int i=0;
	   System.out.println("IsHexa(\"0xFF\")="+Hexa.IsHexa("0x01ABCDEFFFFF"));
	   System.out.println("Hexa.getHexaValue(\"0xFF\"))="+Hexa.getHexaValue("0xFF"));
	   System.out.println("Hexa.getHexaValue(\"0xFFFF\"))="+Hexa.getHexaValue("0xFFFF"));
	   System.out.println("Hexa.getHexaString((byte)128)="+Hexa.getHexaString((byte)128));
	   
	   boolean r = false;
	   if (!r) {
	      System.out.println("r="+r);
	   }	      
	   char ch1 = '1', ch2='3';
	   if (!(ch1=='0' && (ch2=='x' || ch2=='X'))) {
	      System.out.println("ch1="+ch1);
	   }
	   
	   char[] chArr = {'1', '!', 'b', '?', 'z', 'Z', 'B'};
	   while (i<chArr.length) {
	      char ch = chArr[i];
   	   if ( !(('0'<=ch && ch<='9') || ('a'<=ch && ch<='f') || ('A'<=ch && ch<='F'))) {					
   			System.out.println("ch="+ch);
   	   }
   	   i++;
	   }
	   
	    i=0;
	   while (i<chArr.length) {
	      char ch = chArr[i];
	      if ( !(('0'<=ch && ch<='9')  || (('a'<=ch && ch<='f') || ('A'<=ch && ch<='F')) ||
			   (ch=='c' || ch=='s' || ch=='i' || ch=='l' || ch=='C' || ch=='S' || ch=='I' || ch=='L'))) {
			   System.out.println("ch="+ch);
			}
			i++;
		}
		
		boolean string_putting = true;
		ArrayListChar input = new ArrayListChar(10);
		input.add("c = \"abc\"");
		System.out.println(input.toString());
		i = 4;
		if ((i>0 && i+1<input.count && (string_putting && (input.getItem(i-1)!='\\' && input.getItem(i)=='\\' && 
      	(input.getItem(i+1)=='"' || input.getItem(i+1)=='\'' || input.getItem(i+1)=='\\'))))) {
      	   // \", \\
      	   //System.out.println(input.toString());
      	   System.out.println("abc");
      }
      else {
         System.out.println("false");
      }                 			   
	}
	
public static class Hexa {
	
		
		/** 16진수가 아니면 0을 리턴, 16진수 char이면 1, 16진수 short이면 2,
		 * 16진수 integer이면 3을 리턴, 16진수 long이면 4를, 
		 * 16진수 float이면 5를, 16진수 double이면 6를 리턴한다.
		 * 16진수 byte이면 7을 리턴한다.*/
		public static int IsHexa(String str) {
			int i;
			char ch1, ch2, ch;
			int lenOfStr = str.length();
			
			if (lenOfStr>2) {
				// 첫번째 문자
				ch1 = str.charAt(0);
				ch2 = str.charAt(1);
				// 16진수인 경우 +, -의 부호가 들어가서는 안된다. 반드시 0x로 시작해야 한다.
				if (!(ch1=='0' && (ch2=='x' || ch2=='X'))) return 0;
				
							
				
				// 중간들
				boolean isDotFound = false;
				// 0x.0011
				if (str.charAt(2)=='.') return 0;
				for (i=2; i<lenOfStr-1; i++) {			
					ch = str.charAt(i);
					if (isDotFound && ch=='.') return 0; // 소수점이 두개 이상인경우
					if (ch=='.') {					
						isDotFound = true;
					}
					if (ch=='-' || ch=='+') return 0;
					if ( !(('0'<=ch && ch<='9') || 
							 ('a'<=ch && ch<='f') || ('A'<=ch && ch<='F'))) {					
						return 0;
					}
				}
				
				
				// 마지막 문자
				ch = str.charAt(lenOfStr-1);
				if (str.contains(".")) { // 실수
					// 16진수의 경우 접미사 f는 사용할수 없다.
					if ( !(('0'<=ch && ch<='9') || (('a'<=ch && ch<='f') || ('A'<=ch && ch<='F')) || 
							(ch=='d' || ch=='D'))) {
						return 0;
					}
				}
				else { // 정수
					if ( !(('0'<=ch && ch<='9')  || (('a'<=ch && ch<='f') || ('A'<=ch && ch<='F')) ||
						(ch=='c' || ch=='s' || ch=='i' || ch=='l' || ch=='C' || ch=='S' || ch=='I' || ch=='L'))) {
						return 0;
					}
				}
			}
			
			else {
				return 0;
			}
			
			int posOfDot = str.indexOf(".");
			if (posOfDot==-1) {// 정수
				if (ch=='c' || ch=='C') return 1;//char
				else if (ch=='s' || ch=='S') return 2;//short
				else if (ch=='i' || ch=='I') return 3;//int
				else if (ch=='l' || ch=='L') return 4;//long
				//else return 3; //접미사가 없으면 int
				else { // 접미사가 없으면
					
					return Hexa.isNumber2OfHexa(str);
					
				}
			}
			if (posOfDot==0 || posOfDot>=str.length()-1)
				return 0;
			else { //실수
				// 16진수의 경우 접미사 f는 사용할수 없다.
				if (ch=='d' || ch=='D') return 6;//double
					
				// 소수점은 있으나 접미사가 없으면
				float f = Float.parseFloat(str);
				if (Float.MIN_VALUE<=f && f<Float.MAX_VALUE) return 5;
				return 6;
			}
		}
		
		/** strHexa가 정수형 16진수일 경우 그것의 십진수 값을 얻는다.*/
		public static int getHexaValue(String strHexa) {
			int r = 0;
			int i, j;
			int count = 0;
			int unit;
			for (i=strHexa.length()-1; i>=2; i--, count++) {
				char c = strHexa.charAt(i);
				int value = Hexa.getHexaValue(c);
				unit = 1;
				for (j=0; j<count; j++) {
					unit *= 16;
				}
				r += value * unit;
			}
			return r;
		}
		
		/** strHexa가 정수형 16진수일 경우 그것의 십진수 값을 얻는다.*/
		public static long getHexaValueLong(String strHexa) {
			long r = 0;
			int i, j;
			int count = 0;
			int unit;
			for (i=strHexa.length()-1; i>=2; i--, count++) {
				char c = strHexa.charAt(i);
				int value = Hexa.getHexaValue(c);
				unit = 1;
				for (j=0; j<count; j++) {
					unit *= 16;
				}
				r += value * unit;
			}
			return r;
		}
		
		/** byte형 정수 b를 16진수로 리턴한다.*/
		public static String getHexaString(byte b) {			
			byte first = 0;
			first = (byte) ((b & 0xF0) >> 4);
			byte second = 0;
			second = (byte) ((b & 0x0F));
			String firstHexa = Hexa.getHexa(first);
			String secondHexa = Hexa.getHexa(second);
			
			return firstHexa + secondHexa;
		}
		
		public static int getHexaValue(char c) {
			switch(c) {
			case '0': return 0;
			case '1': return 1;
			case '2': return 2;
			case '3': return 3;
			case '4': return 4;
			case '5': return 5;
			case '6': return 6;
			case '7': return 7;
			case '8': return 8;
			case '9': return 9;
			case 'a': return 10;
			case 'A': return 10;
			case 'b': return 11;
			case 'B': return 11;
			case 'c': return 12;
			case 'C': return 12;
			case 'd': return 13;
			case 'D': return 13;
			case 'e': return 14;
			case 'E': return 14;
			case 'f': return 15;
			case 'F': return 15;
			}
			//throw new Exception("c is not hexa value.");
			return c;
		}
		
		static String getHexa(byte value) {
			switch(value) {
			case 0: return "0";
			case 1: return "1";
			case 2: return "2";
			case 3: return "3";
			case 4: return "4";
			case 5: return "5";
			case 6: return "6";
			case 7: return "7";
			case 8: return "8";
			case 9: return "9";
			case 10: return "A";
			case 11: return "B";
			case 12: return "C";
			case 13: return "D";
			case 14: return "E";
			case 15: return "F";
			}
			return null;
		}
		
		/** value를 Hexa값을 갖는 스트링으로 리턴한다. 예를 들어 value가 10이면 0A를 리턴한다.*/
		public static String toHexa(byte value) {
			byte b1 = (byte) ((value & 0xf0) >> 4);
			byte b0 = (byte) (value & 0x0f);
			return ""+getHexa(b1)+getHexa(b0);
		}
		
		/** 0x로 시작되는 hexa 값의 정수 타입을 리턴한다.
		 * byte(7), short(2), char(2), int(3), long(4)
		 * 16 진수값에 부호가 있어서는 안된다.*/
		public static int isNumber2OfHexa(String hexaValue) {
			int len = hexaValue.length();
			if (len>2) {
				char c0 = hexaValue.charAt(0);
				char c1 = hexaValue.charAt(1);
				if (c0=='0' && (c1=='x' || c1=='X')) { // 16진수
					int remainder = len - 2;
					// byte 의 경우 8bit이므로 16진수 2개의 자리수가 된다.
					// char, short 의 경우 16bit이므로 16진수 4개의 자리수가 된다.
					// int 의 경우 32bit이므로 16진수 8개의 자리수가 된다.
					if (remainder<=2) return 7; // byte
					else if (remainder<=4) return 2; // short
					else if (remainder<=8) return 3; // int
					else if (remainder<=16) return 4; // long

					return 0;
				}
				return 0;
			}
			return 0;
		}	
	}

}
